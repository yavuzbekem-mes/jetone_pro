-- DB'deki eski yolları düzelt
-- ../kys_dökümanlar/ → kys_dökümanlar/
-- kys_dokumanlar/    → kys_dökümanlar/
UPDATE `dokuman_listesi` SET `dok_yol` = REPLACE(`dok_yol`, '../kys_dökümanlar/', 'kys_dökümanlar/');
UPDATE `dokuman_listesi` SET `dok_yol` = REPLACE(`dok_yol`, 'kys_dokumanlar/', 'kys_dökümanlar/');
-- Çift düzeltmeyi önle (kys_dökümanlar/ zaten doğruysa değişmez)
