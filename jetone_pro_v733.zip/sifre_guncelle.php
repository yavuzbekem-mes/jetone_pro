<?php
/**
 * SMTP Şifresini Güncelle - Tek Seferlik
 * Bu dosyayı çalıştırdıktan sonra silin!
 */
error_reporting(E_ALL); ini_set('display_errors',1);
require_once __DIR__.'/core/config.php';
require_once __DIR__.'/core/db.php';

$key = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';

// Mevcut şifreyi göster
$smtp = $db->query("SELECT id,host,kullanici,sifre FROM entegrasyonlar WHERE tip='smtp' LIMIT 1")->fetch();
if (!$smtp) { die('SMTP entegrasyonu bulunamadı'); }

echo "<pre>";
echo "Host: ".$smtp['host']."\n";
echo "Kullanıcı: ".$smtp['kullanici']."\n";
echo "DB'deki şifre (raw): ".htmlspecialchars($smtp['sifre'])."\n\n";

// Decrypt dene
$d1 = @openssl_decrypt($smtp['sifre'], 'AES-256-CBC', $key, 0, '1234567890123456');
$d2 = @openssl_decrypt($smtp['sifre'], 'AES-256-CBC', 'jetone2024secretkey!!', 0, '1234567890123456');
$b  = @base64_decode($smtp['sifre'], true);

echo "Key1 decrypt: ".htmlspecialchars($d1 ?: '(başarısız)')."\n";
echo "Key2 decrypt: ".htmlspecialchars($d2 ?: '(başarısız)')."\n";
echo "base64 decode: ".htmlspecialchars(($b && ctype_print($b)) ? $b : '(geçersiz)')."\n\n";

// Formdaki yeni şifreyle yeniden kaydet
if ($_POST['sifre'] ?? '') {
    $yeni = trim($_POST['sifre']);
    $enc  = openssl_encrypt($yeni, 'AES-256-CBC', $key, 0, '1234567890123456');
    $test = openssl_decrypt($enc, 'AES-256-CBC', $key, 0, '1234567890123456');
    if ($test === $yeni) {
        $db->prepare("UPDATE entegrasyonlar SET sifre=? WHERE id=?")->execute([$enc, $smtp['id']]);
        echo "✅ Şifre başarıyla güncellendi!\n";
        echo "Yeni encrypted: ".htmlspecialchars($enc)."\n";
        echo "Verify decrypt: ".htmlspecialchars($test)."\n";
    } else {
        echo "❌ Şifreleme doğrulama başarısız!\n";
    }
}
echo "</pre>";
?>
<form method="POST" style="font-family:sans-serif;padding:20px">
  <label>Yeni SMTP Şifresi:</label><br>
  <input type="text" name="sifre" value="" style="padding:8px;width:300px;margin:8px 0"><br>
  <button type="submit" style="background:#F97316;color:#fff;border:none;padding:10px 20px;border-radius:6px;cursor:pointer">Şifreyi Kaydet</button>
</form>
