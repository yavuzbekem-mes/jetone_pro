<?php
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';

$db->exec("CREATE TABLE IF NOT EXISTS mps_plan (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    hat_kodu        VARCHAR(20) NOT NULL,
    urun_kodu       VARCHAR(50) NOT NULL,
    urun_adi        VARCHAR(200),
    siparis_no      VARCHAR(100),           -- üretim emri varsa
    planlanan_miktar INT NOT NULL,
    kapasite_vardiya INT,                   -- adet/vardiya
    cycle_sn        FLOAT,
    parti           INT,
    baslangic_tarih DATE NOT NULL,
    bitis_tarih     DATE NOT NULL,
    baslangic_vardiya ENUM('S','O','G') DEFAULT 'S',
    toplam_vardiya  INT,
    toplam_gun      INT,
    durum           ENUM('Planlandı','Devam Ediyor','Tamamlandı','İptal') DEFAULT 'Planlandı',
    oncelik         INT DEFAULT 0,
    notlar          TEXT,
    olusturan       INT,
    olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_hat_tarih (hat_kodu, baslangic_tarih),
    INDEX idx_urun (urun_kodu),
    INDEX idx_durum (durum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

echo "mps_plan tablosu oluşturuldu/güncellendi.\n";
