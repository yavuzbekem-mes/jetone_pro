<?php
require_once dirname(__DIR__).'/core/config.php';
require_once dirname(__DIR__).'/core/baglanlogo.php';
global $db;
$st = $db->query("SELECT id, fis_id, irsaliye_no, stok_kodu, sonuc, kontrol_tarihi FROM gkk_kontrol_sonuclari ORDER BY id DESC LIMIT 20");
$rows = $st->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
