<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

$d = json_decode(file_get_contents('php://input'), true) ?: [];
$irsaliye_no = trim($d['irsaliye_no'] ?? '');
$stok_kodu   = trim($d['stok_kodu']   ?? '');
$stok_adi    = trim($d['stok_adi']    ?? '');
$miktar      = (float)($d['miktar']   ?? 0);
$birim       = trim($d['birim']       ?? 'ADET');
$tedarikci   = trim($d['tedarikci']   ?? '');
$cari_kodu   = trim($d['cari_kodu']   ?? '');
$karar       = strtoupper(trim($d['karar'] ?? ''));
$aciklama    = trim($d['aciklama']    ?? '');
$mail_to     = trim($d['mail_to']     ?? '');

if(!$irsaliye_no || !$stok_kodu || !in_array($karar,['KABUL','SARTLI_KABUL','RED'])){
    echo json_encode(['success'=>false,'message'=>'Eksik parametre']); exit;
}

global $db, $mes_pdo, $tigerdb_pdo;
if(!$db){ echo json_encode(['success'=>false,'message'=>'DB bağlantısı yok']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES bağlantısı yok']); exit; }

try {
    // ── 1. GKK tablosuna kayıt ────────────────────────────────────────────
    $db->prepare(
        "INSERT INTO gkk_kontrol (irsaliye_no,stok_kodu,stok_adi,miktar,birim,tedarikci,cari_kodu,karar,aciklama,kayit_eden)
         VALUES(?,?,?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE karar=VALUES(karar),aciklama=VALUES(aciklama),kayit_eden=VALUES(kayit_eden),kayit_tarihi=NOW()"
    )->execute([$irsaliye_no,$stok_kodu,$stok_adi,$miktar,$birim,$tedarikci,$cari_kodu,$karar,$aciklama,$kul_adi]);

    // ── 2. PAKETLER güncelle ──────────────────────────────────────────────
    $mes_pdo->beginTransaction();

    if($karar === 'KABUL') {
        // Raf yeri X — onaylı
        $mes_pdo->prepare(
            "UPDATE dbo.PAKETLER SET STOK_YERI='X', KALITE_TARIHI=GETDATE()
             WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=0"
        )->execute([$irsaliye_no, $stok_kodu]);

    } elseif($karar === 'SARTLI_KABUL') {
        // Raf yeri X — şartlı kabul
        $mes_pdo->prepare(
            "UPDATE dbo.PAKETLER SET STOK_YERI='X', KALITE_TARIHI=GETDATE()
             WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=0"
        )->execute([$irsaliye_no, $stok_kodu]);

    } elseif($karar === 'RED') {
        // Ambar=2(Karantina), Raf=RED, AKTIF=2
        $mes_pdo->prepare(
            "UPDATE dbo.PAKETLER SET AMBAR=2, STOK_YERI='RED', AKTIF=2, KALITE_TARIHI=GETDATE()
             WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=0"
        )->execute([$irsaliye_no, $stok_kodu]);

        // ── 3. Logo ambar transferi (sadece RED) ──────────────────────────
        $logo_hata = '';
        try {
            // Token al
            $token = '';
            $tr = $mes_pdo->query("SELECT TOP 1 TOKEN FROM dbo.API_TOKENS ORDER BY ID DESC")?->fetch(PDO::FETCH_ASSOC);
            if($tr) $token = $tr['TOKEN'];

            if($token && $tigerdb_pdo) {
                // Her paketi ayrı ayrı transfer et
                $pkts = $mes_pdo->prepare(
                    "SELECT ID,MIKTAR,BIRIM,AMBAR FROM dbo.PAKETLER
                     WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=2"
                );
                $pkts->execute([$irsaliye_no, $stok_kodu]);
                $paketler_red = $pkts->fetchAll(PDO::FETCH_ASSOC);

                $g_URL = defined('LOGO_API_URL') ? LOGO_API_URL : 'http://localhost:9095/api/v1/';

                foreach($paketler_red as $pkt) {
                    $src_ambar = (int)($pkt['AMBAR']??1);
                    $mik_p     = (float)$pkt['MIKTAR'];
                    $bir_p     = $pkt['BIRIM'];
                    $now_dt    = date('Y-m-d\TH:i:s');
                    $time_val  = (int)date('H')*65536*256 + (int)date('i')*65536 + (int)date('s')*256;

                    $payload = [
                        'INTERNAL_REFERENCE'=>0,'GROUP'=>3,'TYPE'=>25,'NUMBER'=>'~',
                        'DATE'=>$now_dt,'TIME'=>$time_val,'DOC_NUMBER'=>'GKK-RED',
                        'SOURCE_WH'=>$src_ambar,'DEST_WH'=>2,
                        'TRANSACTIONS'=>['items'=>[[
                            'ITEM_CODE'=>$stok_kodu,'LINE_TYPE'=>0,
                            'SOURCEINDEX'=>$src_ambar,'DESTINDEX'=>2,
                            'FACTORYNR'=>0,'LINE_NUMBER'=>1,
                            'QUANTITY'=>$mik_p,'UNIT_CODE'=>$bir_p,
                            'UNIT_CONV1'=>$mik_p,'UNIT_CONV2'=>$mik_p,'EDT_CURR'=>1
                        ]]]
                    ];

                    $ch = curl_init();
                    curl_setopt_array($ch,[
                        CURLOPT_URL            => $g_URL.'itemSlips',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => json_encode($payload),
                        CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$token,'Content-Type: application/json'],
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_SSL_VERIFYHOST => false,
                        CURLOPT_TIMEOUT        => 15,
                    ]);
                    $resp = curl_exec($ch);
                    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);

                    if($code < 200 || $code >= 300) {
                        $logo_hata = "Logo transfer HTTP $code";
                        error_log("[GKK_RED] Logo hata: $logo_hata — $resp");
                    }
                }
            }
        } catch(Throwable $e){
            $logo_hata = $e->getMessage();
            error_log("[GKK_RED] Logo exception: $logo_hata");
        }
    }

    $mes_pdo->commit();

    // ── 4. Mailto linki (RED için) ────────────────────────────────────────
    $mailto_link = '';
    if($karar === 'RED') {
        $konu = rawurlencode("🚨 Kalite Red Bildirimi — $stok_kodu / $irsaliye_no");
        $body = rawurlencode(
            "Sayın Tedarikçi,\r\n\r\n" .
            "Aşağıda belirtilen ürününüz GKK (Giriş Kalite Kontrol) sürecinde RED edilmiştir.\r\n\r\n" .
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n" .
            "İrsaliye No  : $irsaliye_no\r\n" .
            "Stok Kodu    : $stok_kodu\r\n" .
            "Stok Adı     : $stok_adi\r\n" .
            "Miktar       : $miktar $birim\r\n" .
            "Karar Tarihi : ".date('d.m.Y H:i')."\r\n" .
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n\r\n" .
            "Red Nedeni:\r\n$aciklama\r\n\r\n" .
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n\r\n" .
            "İlgili ürün, GKK kararı doğrultusunda Karantina ambarına alınmıştır.\r\n" .
            "Lütfen acil aksiyon alarak firmamızla iletişime geçiniz.\r\n\r\n" .
            "Saygılarımızla,\r\n" .
            "POLİZA ENDÜSTRİ A.Ş.\r\n" .
            "Kalite Kontrol Birimi\r\n" .
            "Kaydeden: $kul_adi"
        );
        $mailto_link = "mailto:$mail_to?subject=$konu&body=$body";
    }

    echo json_encode([
        'success'     => true,
        'message'     => "$karar kararı kaydedildi.",
        'mailto_link' => $mailto_link,
        'logo_hata'   => $logo_hata ?? '',
    ], JSON_UNESCAPED_UNICODE);

} catch(Throwable $e){
    if($mes_pdo && $mes_pdo->inTransaction()) $mes_pdo->rollBack();
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
