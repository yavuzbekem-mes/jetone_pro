<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES bağlantısı yok']); exit; }

$d = json_decode(file_get_contents('php://input'), true) ?: [];

$irsaliye_no = trim($d['irsaliye_no'] ?? '');
$stok_kodu   = strtoupper(trim($d['stok_kodu'] ?? ''));
$stok_adi    = trim($d['stok_adi']    ?? '');
$birim       = strtoupper(trim($d['birim']      ?? 'ADET'));
$tarih       = trim($d['tarih']       ?? date('Y-m-d'));
$calisan     = trim($d['calisan']     ?? '');
$ambar       = (int)($d['ambar']      ?? 1);
$stok_yeri   = strtoupper(trim($d['stok_yeri']  ?? 'X')) ?: 'X';
$lot_no_bilgi= trim($d['lot_no']      ?? '');
$tedarikci   = trim($d['tedarikci']   ?? '');
$paketler    = $d['paketler']         ?? [];

if(!$irsaliye_no || !$stok_kodu || empty($paketler)){
    echo json_encode(['success'=>false,'message'=>'Eksik parametre']); exit;
}

// Stok adı yoksa Tiger'dan çek
if(!$stok_adi && $tigerdb_pdo) {
    try {
        $st=$tigerdb_pdo->prepare("SELECT TOP 1 NAME FROM dbo.LG_222_ITEMS WHERE CODE=? AND ACTIVE=0");
        $st->execute([$stok_kodu]);
        $r=$st->fetch(PDO::FETCH_ASSOC);
        if($r) $stok_adi=$r['NAME'];
    } catch(Throwable $e){}
}

try {
    $mes_pdo->beginTransaction();

    $ins = $mes_pdo->prepare(
        "INSERT INTO dbo.PAKETLER
         (PAKET_NO,ANA_PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,
          URETIM_EMRI_NO,URETIM_TARIHI,CALISAN,ETIKET_TURU,
          ANA_HAMMADDE,STOK_YERI,AMBAR,AKTIF,EKLEYEN,KAYIT_TURU,EKLENME_TARIHI)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'0',?,'SATINALMA',GETDATE())"
    );

    $paket_detaylar = [];
    $ts = (int)(microtime(true)*10000);

    foreach($paketler as $idx => $miktar) {
        $miktar = (float)$miktar;
        if($miktar <= 0) continue;

        $pno = 'LOT'.date('y').sprintf('%08d', ($ts + $idx) % 100000000);

        $ins->execute([
            $pno, $pno, $stok_kodu, $stok_adi, $miktar, $birim,
            $irsaliye_no, $tarih, $tedarikci ?: $calisan, 'HAMMADDE',
            ($lot_no_bilgi ?: 'LOTSUZ'), $stok_yeri, $ambar, $calisan
        ]);

        $paket_detaylar[] = [
            'paket_no'    => $pno,
            'irsaliye_no' => $irsaliye_no,
            'stok_kodu'   => $stok_kodu,
            'stok_adi'    => $stok_adi,
            'miktar'      => $miktar,
            'birim'       => $birim,
            'tarih'       => $tarih,
            'calisan'     => $tedarikci ?: $calisan,
        ];
    }

    $mes_pdo->commit();

    echo json_encode([
        'success'        => true,
        'message'        => count($paket_detaylar).' paket oluşturuldu',
        'paket_detaylar' => $paket_detaylar,
    ], JSON_UNESCAPED_UNICODE|JSON_NUMERIC_CHECK);

} catch(Throwable $e) {
    if($mes_pdo->inTransaction()) $mes_pdo->rollBack();
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
