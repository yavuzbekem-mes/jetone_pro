<?php
/**
 * Montaj Fire Kaydet — Logo REST API ambar transfer (TYPE=25, 01→03)
 * POST JSON: {uretim_emri_id, uretim_emri_no, calisan_id, ekleyen, fire_verileri (JSON string)}
 */
ini_set('display_errors', 0); error_reporting(0);
while (ob_get_level() > 0) ob_end_clean();

require_once dirname(__DIR__, 2) . '/core/config.php';
require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';
require_once dirname(__DIR__, 2) . '/core/auth.php';

while (ob_get_level() > 0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
set_time_limit(120);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/uretim_errors.log');

if (!Auth::girisYapilmisMi()) {
    echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit;
}
$kul = Auth::kullanici();
$kul_adi_mf = '';
if (is_array($kul)) {
    if (!empty($kul['ad_soyad'])) $kul_adi_mf = trim($kul['ad_soyad']);
    elseif (!empty($kul['ad']))    $kul_adi_mf = trim($kul['ad'] . ' ' . ($kul['soyad'] ?? ''));
    elseif (!empty($kul['email'])) $kul_adi_mf = explode('@', $kul['email'])[0];
}
if (!$kul_adi_mf) $kul_adi_mf = 'JETONE';

$json  = file_get_contents('php://input');
$input = json_decode($json, true) ?: [];

$uretim_id  = trim($input['uretim_emri_id'] ?? '');
$uretim_no  = trim($input['uretim_emri_no'] ?? '');
$calisan_id = trim($input['calisan_id']      ?? '');
$ekleyen    = trim($input['ekleyen']         ?? 'jetone');
$is_ist     = trim($input['is_istasyonu']    ?? '');
$fire_json  = $input['fire_verileri']        ?? '[]';
$fireVerileri = is_string($fire_json) ? json_decode($fire_json, true) : $fire_json;

if (!$uretim_no)         { echo json_encode(['success'=>false,'message'=>'Uretim emri no eksik']); exit; }
if (!$calisan_id)        { echo json_encode(['success'=>false,'message'=>'Calisan secilmedi']); exit; }
if (empty($fireVerileri)){ echo json_encode(['success'=>false,'message'=>'Fire verisi yok']); exit; }

// Token
$token = $GLOBALS['API_TOKEN'] ?? '';
if (!$token && $mes_pdo) {
    try {
        $ts = $mes_pdo->query("SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR WHERE DATEDIFF(day,TARIH,GETDATE())=0 ORDER BY ID DESC");
        $tr = $ts->fetch(PDO::FETCH_ASSOC);
        if ($tr) $token = $tr['TOKEN'];
    } catch(Throwable $e) {}
}
if (!$token) { echo json_encode(['success'=>false,'message'=>'API token alinamadi']); exit; }

$g_URL = class_exists('Global_Rest') ? Global_Rest::$g_URL : 'http://192.168.1.100:32001/api/v1/';

$basarili   = [];
$toplamFire = 0;

foreach ($fireVerileri as $item) {
    $stok_kodu  = $item['stok_kodu']   ?? '';
    $stok_adi   = $item['stok_adi']    ?? '';
    $fire_miktar= (float)($item['fire_miktar'] ?? 0);
    $fire_neden = $item['fire_neden']  ?? '';
    $birim      = $item['birim']       ?? 'ADET';

    if ($fire_miktar <= 0 || !$stok_kodu) continue;
    $toplamFire += $fire_miktar;

    // Tiger'dan stok bilgisi ve lot kontrolü
    $itemref = 0; $tracktype = 0; $lotBilgisi = null;
    if ($tigerdb_pdo) {
        try {
            $ss = $tigerdb_pdo->prepare(
                "SELECT TOP 1 IT.LOGICALREF as ITEMREF, IT.TRACKTYPE
                 FROM dbo.LG_222_ITEMS IT WHERE IT.CODE=? AND IT.ACTIVE=0"
            );
            $ss->execute([$stok_kodu]);
            $sr = $ss->fetch(PDO::FETCH_ASSOC);
            if ($sr) { $itemref = (int)$sr['ITEMREF']; $tracktype = (int)$sr['TRACKTYPE']; }

            if ($tracktype == 1 && $itemref > 0) {
                $ls = $tigerdb_pdo->prepare(
                    "SELECT TOP 1 SL.SLTYPE, SL.CODE AS LOT_NO, SL.LOGICALREF AS LOT_REF
                     FROM dbo.LG_222_SERILOTN SL
                     LEFT JOIN dbo.LG_222_SLSLINE SLT ON SL.LOGICALREF=SLT.SLREF
                     WHERE SL.ITEMREF=? AND SL.INVENNO=1
                     GROUP BY SL.SLTYPE, SL.CODE, SL.LOGICALREF
                     HAVING SUM(ISNULL(SLT.REMAMOUNT,0)) >= ?
                     ORDER BY SL.LOGICALREF DESC"
                );
                $ls->execute([$itemref, $fire_miktar]);
                $lotBilgisi = $ls->fetch(PDO::FETCH_ASSOC);
            }
        } catch(Throwable $e) {
            error_log("[MONTAJ_FIRE] Tiger sorgu hatası: " . $e->getMessage());
        }
    }

    // Payload
    $dt   = new DateTime();
    $tarih = $dt->format('Y-m-d\TH:i:s');
    $timeV = (int)$dt->format('H') * 65536 * 256 + (int)$dt->format('i') * 65536 + (int)$dt->format('H') * 256;

    $txItem = [
        "ITEM_CODE"   => $stok_kodu,
        "LINE_TYPE"   => 0,
        "SOURCEINDEX" => 1,
        "DESTINDEX"   => 3,
        "DESCRIPTION" => $fire_neden,
        "AUXIL_CODE"  => $uretim_no,
        "QUANTITY"    => $fire_miktar,
        "UNIT_CODE"   => $birim,
        "EDT_CURR"    => 1,
    ];
    if ($lotBilgisi) {
        $txItem["SL_DETAILS"] = ["items" => [[
            "IOCODE"    => 3,
            "SOURCE_WH" => 1,
            "SL_TYPE"   => $lotBilgisi['SLTYPE'],
            "SL_CODE"   => $lotBilgisi['LOT_NO'],
            "SL_REFERENCE" => $lotBilgisi['LOT_REF'],
            "MU_QUANTITY"  => $fire_miktar,
            "UNIT_CODE"    => $birim,
            "QUANTITY"     => $fire_miktar,
        ]]];
    }

    $payload = json_encode([
        "INTERNAL_REFERENCE" => 0,
        "GROUP" => 3, "TYPE" => 25,
        "NUMBER" => "~",
        "DATE"   => $tarih, "TIME" => $timeV,
        "DOC_NUMBER" => "MONTAJ_FIRE - " . $kul_adi_mf,
        "SOURCE_WH"  => 1, "DEST_WH" => 3,
        "TRANSACTIONS" => ["items" => [$txItem]],
    ], JSON_UNESCAPED_UNICODE);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $g_URL . 'itemSlips',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ["Authorization: Bearer $token","Content-Type: application/json"],
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp   = curl_exec($ch);
    $code   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlE  = curl_error($ch);
    curl_close($ch);

    error_log("[MONTAJ_FIRE] $stok_kodu $fire_miktar $birim → HTTP $code");
    if ($curlE)       { echo json_encode(['success'=>false,'message'=>"cURL: $curlE"]); exit; }
    if ($code < 200 || $code >= 300) {
        $err = json_decode($resp, true);
        echo json_encode(['success'=>false,'message'=>"Logo HTTP $code: " . ($err['Message'] ?? $resp)]); exit;
    }

    $respData = json_decode($resp, true);
    if (empty($respData['INTERNAL_REFERENCE'])) {
        echo json_encode(['success'=>false,'message'=>"Transfer basarisiz: $stok_kodu — " . ($respData['Message'] ?? 'Bilinmiyor')]); exit;
    }

    $tiger_fis_no = $respData['NUMBER'] ?? ('REF-'.$respData['INTERNAL_REFERENCE']);
    $basarili[] = "$stok_kodu ($fire_miktar $birim) — Ref: {$respData['INTERNAL_REFERENCE']}";

    // jetone_pro DB'ye kayıt
    if ($db) {
        try {
            $db->prepare(
                "INSERT INTO montaj_fire_kayitlar
                 (uretim_emri_no, stok_kodu, stok_adi, fire_miktar, birim,
                  fire_nedeni, tiger_fis_no, is_istasyonu, kayit_eden, kayit_tarihi)
                 VALUES (?,?,?,?,?,?,?,?,?,NOW())"
            )->execute([
                $uretim_no, $stok_kodu, $stok_adi, $fire_miktar, $birim,
                $fire_neden, $tiger_fis_no, $is_ist, $kul_adi_mf
            ]);
        } catch (Throwable $dbe) {
            error_log("[MONTAJ_FIRE_DB] " . $dbe->getMessage());
        }
    }
}

echo json_encode([
    'success'     => true,
    'message'     => count($basarili) . " malzeme icin ambar transferi yapildi. Toplam fire: $toplamFire",
    'transferler' => $basarili,
    'toplam_fire' => $toplamFire,
], JSON_UNESCAPED_UNICODE);
