<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['error'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['error'=>'MES baglantisi yok']); exit; }

$id = (int)($_GET['id'] ?? 0);
if(!$id){ echo json_encode(['error'=>'ID eksik']); exit; }

try {
    $st = $mes_pdo->prepare("SELECT * FROM dbo.PAKETLER WHERE ID=?");
    $st->execute([$id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if(!$row){ echo json_encode(['error'=>'Paket bulunamadi']); exit; }
    // Tarih formatlama
    foreach(['URETIM_TARIHI','EKLENME_TARIHI'] as $k){
        if(!empty($row[$k])) $row[$k] = substr($row[$k],0,16);
    }
    echo json_encode($row, JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){
    echo json_encode(['error'=>$e->getMessage()]);
}
