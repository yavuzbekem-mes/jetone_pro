<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
ini_set('log_errors',1); ini_set('error_log',__DIR__.'/uretim_errors.log');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$d = !empty($_POST) ? $_POST : (json_decode(file_get_contents('php://input'),true)?:[]);

$uretim_no = trim($d['uretim_emri_no']??'');
$is_ist    = trim($d['is_istasyonu']  ??'');
$bas_z     = trim($d['baslangic_zamani']??'');
$bit_z     = trim($d['bitis_zamani']  ??'');
$neden     = trim($d['durus_nedeni']  ??'');
$aciklama  = trim($d['aciklama']      ??'');
$ekleyen   = trim($d['ekleyen']       ??'jetone');

if(!$uretim_no||!$bas_z||!$bit_z||!$neden){
    echo json_encode(['success'=>false,'message'=>'Zorunlu alanlar eksik']); exit;
}

try {
    $baslangic = new DateTime($bas_z);
    $bitis     = new DateTime($bit_z);
    if($bitis<=$baslangic){ echo json_encode(['success'=>false,'message'=>'Bitis baslangictan buyuk olmali']); exit; }
    $iv = $baslangic->diff($bitis);
    $sure_dk = $iv->days*24*60 + $iv->h*60 + $iv->i;

    // Diğer seçildiyse aciklama alanını neden olarak kullan
    $neden_final = ($neden === 'Diğer' && !empty($aciklama)) ? 'Diğer: '.$aciklama : $neden;

    // datetime-local T'yi boşluğa çevir (MSSQL uyumu)
    $bas_sql = str_replace('T',' ',$bas_z);
    $bit_sql = str_replace('T',' ',$bit_z);

    $st = $mes_pdo->prepare(
        "INSERT INTO MAKINE_DURUSLARI
         (URETIM_EMRI_NO,IS_ISTASYONU,BASLANGIC_ZAMANI,BITIS_ZAMANI,SURE_DK,DURUS_NEDENI)
         VALUES(?,?,?,?,?,?)"
    );
    $st->execute([$uretim_no,$is_ist,$bas_sql,$bit_sql,$sure_dk,$neden_final]);
    $id = $mes_pdo->lastInsertId();

    $s=$iv->h; $dk=$iv->i;
    $st_txt = $s>0 ? "$s saat $dk dakika" : "$dk dakika";
    error_log("[DURUS_KAYDET] $uretim_no | $neden | $sure_dk dk | ID=$id");
    echo json_encode(['success'=>true,'message'=>"Makine durusu kaydedildi. Sure: $st_txt",'id'=>$id,'sure_dk'=>$sure_dk],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){
    error_log("[DURUS_KAYDET] HATA: ".$e->getMessage());
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
