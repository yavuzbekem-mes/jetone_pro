<?php
/**
 * İkinci Kalite Kaydet
 * 1. MES IKINCI_KALITE INSERT
 * 2. MES PAKETLER INSERT (ETIKET_TURU=IKINCI)
 * 3. Logo FastRealizeFicheGenerate
 * 4. Logo itemSlips TYPE=25 ambar transfer (01→03)
 * 5. Etiket URL dön
 */
ini_set('display_errors', 0); error_reporting(0);
while (ob_get_level() > 0) ob_end_clean();

require_once dirname(__DIR__, 2) . '/core/config.php';
require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';
require_once dirname(__DIR__, 2) . '/core/auth.php';

while (ob_get_level() > 0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/uretim_errors.log');
set_time_limit(120);

if (!Auth::girisYapilmisMi()) { echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if (!$mes_pdo)                { echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$kul = Auth::kullanici();
// Kullanıcı adını güvenli al: ad_soyad → ad+soyad → email prefix → JETONE
$kul_adi = '';
if (is_array($kul)) {
    if (!empty($kul['ad_soyad'])) $kul_adi = trim($kul['ad_soyad']);
    elseif (!empty($kul['ad']))    $kul_adi = trim($kul['ad'] . ' ' . ($kul['soyad'] ?? ''));
    elseif (!empty($kul['email'])) $kul_adi = explode('@', $kul['email'])[0];
}
if (!$kul_adi) $kul_adi = 'JETONE';
error_log("[KUL_ADI-ikinci] session kul=" . json_encode($kul) . " → kul_adi=$kul_adi");

$data = !empty($_POST) ? $_POST : (json_decode(file_get_contents('php://input'), true) ?: []);

$uretim_no     = trim($data['uretim_emri_no'] ?? '');
$uretim_emri_id= trim($data['uretim_emri_id'] ?? '');
$stok_kodu     = trim($data['stok_kodu']       ?? '');
$stok_adi      = trim($data['stok_adi']        ?? '');
$itemref       = trim($data['itemref']         ?? '');
$uomref        = trim($data['uomref']          ?? '');
$birim         = trim($data['birim']           ?? 'ADET');
$calisan_id    = trim($data['calisan_id']      ?? '');
$ekleyen       = trim($data['ekleyen']         ?? 'jetone');
$uretim_tarihi = trim($data['uretim_tarihi']   ?? date('Y-m-d'));

if (!$uretim_no)  { echo json_encode(['success'=>false,'message'=>'Uretim emri no eksik']); exit; }
if (!$calisan_id) { echo json_encode(['success'=>false,'message'=>'Calisan secilmedi']); exit; }

// Defekt miktarları
$defektler = ['ayarfiresi','hammaddelekesi','yaglekesi','cizik',
              'eksikenjeksiyon','catlak','gazlanma','cokuntu','serpme','yanma'];
$dm = []; $toplam = 0;
foreach ($defektler as $d) { $dm[$d] = max(0,(float)($data[$d]??0)); $toplam += $dm[$d]; }
if ($toplam <= 0) { echo json_encode(['success'=>false,'message'=>'En az bir defekt icin miktar girin']); exit; }

// Token al
$token = '';
try {
    $ts = $mes_pdo->query("SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR WHERE DATEDIFF(day,TARIH,GETDATE())=0 ORDER BY ID DESC");
    $tr = $ts->fetch(PDO::FETCH_ASSOC);
    if ($tr) $token = $tr['TOKEN'];
} catch(Throwable $e) {}

$g_URL = class_exists('Global_Rest') ? Global_Rest::$g_URL : 'http://192.168.1.100:32001/api/v1/';

try {
    // ── 1. IKINCI_KALITE INSERT ────────────────────────────────────────────────
    // Tablo gerçek kolonları (orijinal koddan):
    // URETIM_EMRI_NO, STOK_KODU, STOK_ADI, URETIM_TARIHI, CALISAN,
    // AYAR_FIRESİ, HAMMADDE_LEKESI, YAG_LEKESI, CIZIK, EKSIK_ENJEKSIYON,
    // CATLAK, GAZLANMA, COKUNTU, SERPME, YANMA, TOPLAM
    $sql_ik = "INSERT INTO IKINCI_KALITE (
        URETIM_EMRI_NO, STOK_KODU, STOK_ADI, URETIM_TARIHI, CALISAN,
        [AYAR_FIRESİ], HAMMADDE_LEKESI, YAG_LEKESI, CIZIK, EKSIK_ENJEKSIYON,
        CATLAK, GAZLANMA, COKUNTU, SERPME, YANMA, TOPLAM
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $st = $mes_pdo->prepare($sql_ik);
    $st->execute([
        $uretim_no, $stok_kodu, $stok_adi,
        date('Y-m-d H:i:s'), $calisan_id,
        $dm['ayarfiresi'], $dm['hammaddelekesi'], $dm['yaglekesi'],
        $dm['cizik'], $dm['eksikenjeksiyon'], $dm['catlak'],
        $dm['gazlanma'], $dm['cokuntu'], $dm['serpme'], $dm['yanma'],
        $toplam,
    ]);
    error_log("[IK] IKINCI_KALITE INSERT OK | $uretim_no | $toplam adet");

    // ── 2. Paket No üret ──────────────────────────────────────────────────────
    $pn = $mes_pdo->query("SELECT ISNULL(MAX(ID),0)+1 AS NXT FROM PAKETLER")->fetch(PDO::FETCH_ASSOC);
    $paket_id = (int)($pn['NXT']??1);
    $paket_no = 'LOT'.date('y').$paket_id;

    // ── 3. Logo FastRealizeFicheGenerate ──────────────────────────────────────
    $fis_no = '';
    if ($token && $uretim_emri_id && $itemref && $uomref) {
        $str10  = "$uretim_emri_id/$itemref/$toplam/$uomref/1/False/".date('Y-m-d\TH:i:s')."/0";
        $apiUrl = $g_URL . "productions/FastRealizeFicheGenerate/$str10";
        $ch = curl_init();
        curl_setopt_array($ch, [CURLOPT_URL=>$apiUrl, CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_HTTPHEADER=>["Authorization: Bearer $token","Accept: application/json"],
            CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_TIMEOUT=>30]);
        $ar = curl_exec($ch); $ac = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        error_log("[IK] FastRealize HTTP $ac | ".substr($ar,0,100));
        if ($ac >= 200 && $ac < 300) {
            preg_match('/InputfromProdSlips":\s*"([^"]+)"/', $ar, $m);
            $fis_no = $m[1] ?? '';
        }
    }

    // ── 4. PAKETLER INSERT ────────────────────────────────────────────────────
    $sql_pkt = "INSERT INTO PAKETLER (
        STOK_KODU, STOK_ADI, MIKTAR, BIRIM,
        URETIM_EMRI_NO, URETIM_TARIHI, AKTIF,
        CALISAN, ETIKET_TURU, ANA_HAMMADDE,
        FIS_NO, EKLEYEN, KAYIT_TURU, AMBAR,
        STOK_YERI, PAKET_NO, ANA_PAKET_NO, EKLENME_TARIHI
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GETDATE())";
    $mes_pdo->prepare($sql_pkt)->execute([
        $stok_kodu, $stok_adi, $toplam, $birim,
        $uretim_no, date('Y-m-d H:i:s'), '0',
        $calisan_id, 'IKINCI', $stok_adi,
        $fis_no, $kul_adi, 'URETIM', 3,
        'X', $paket_no, $paket_no,
    ]);
    error_log("[IK] PAKETLER INSERT OK | $paket_no");

    // ── 5. Logo ambar transfer (01→03) ────────────────────────────────────────
    if ($token && $tigerdb_pdo) {
        try {
            // Stok lot kontrolü
            $si = $tigerdb_pdo->prepare("SELECT TOP 1 LOGICALREF,TRACKTYPE FROM dbo.LG_222_ITEMS WHERE CODE=? AND ACTIVE=0");
            $si->execute([$stok_kodu]); $si_row = $si->fetch(PDO::FETCH_ASSOC);

            $lot = null;
            if ($si_row && (int)$si_row['TRACKTYPE'] === 1) {
                $ls = $tigerdb_pdo->prepare(
                    "SELECT TOP 1 SL.SLTYPE, SL.CODE AS LOT_NO, SL.LOGICALREF AS LOT_REF
                     FROM dbo.LG_222_SERILOTN SL
                     LEFT JOIN dbo.LG_222_SLSLINE SLT ON SL.LOGICALREF=SLT.SLREF
                     WHERE SL.ITEMREF=? AND SL.INVENNO=1
                     GROUP BY SL.SLTYPE,SL.CODE,SL.LOGICALREF
                     HAVING SUM(ISNULL(SLT.REMAMOUNT,0))>=?
                     ORDER BY SL.LOGICALREF DESC"
                );
                $ls->execute([(int)$si_row['LOGICALREF'], $toplam]);
                $lot = $ls->fetch(PDO::FETCH_ASSOC);
            }

            // Defekt açıklaması
            $def_isimleri = ['ayarfiresi'=>'Ayar','hammaddelekesi'=>'H.Leke','yaglekesi'=>'Yag',
                'cizik'=>'Cizik','eksikenjeksiyon'=>'Ek.Enj','catlak'=>'Catlak',
                'gazlanma'=>'Gaz','cokuntu'=>'Cokuntu','serpme'=>'Serpme','yanma'=>'Yanma'];
            $def_list = [];
            foreach ($dm as $k=>$v) { if ($v>0) $def_list[] = ($def_isimleri[$k]??$k).":$v"; }
            $def_aciklama = "2.Kalite-".implode(',',$def_list);

            $dt = new DateTime();
            $tv = (int)$dt->format('H')*65536*256 + (int)$dt->format('i')*65536 + (int)$dt->format('H')*256;

            $tx = [
                "ITEM_CODE"=>"$stok_kodu","LINE_TYPE"=>0,
                "SOURCEINDEX"=>1,"DESTINDEX"=>3,
                "DESCRIPTION"=>$def_aciklama,
                "AUXIL_CODE"=>$paket_no,
                "QUANTITY"=>$toplam,"UNIT_CODE"=>$birim,
                "EDT_CURR"=>1,
            ];
            if ($lot) {
                $tx["SL_DETAILS"] = ["items"=>[[
                    "IOCODE"=>3,"SOURCE_WH"=>1,
                    "SL_TYPE"=>$lot['SLTYPE'],"SL_CODE"=>$lot['LOT_NO'],"SL_REFERENCE"=>$lot['LOT_REF'],
                    "MU_QUANTITY"=>$toplam,"UNIT_CODE"=>$birim,"QUANTITY"=>$toplam,
                ]]];
            }
            $pl = json_encode([
                "INTERNAL_REFERENCE"=>0,"GROUP"=>3,"TYPE"=>25,"NUMBER"=>"~",
                "DATE"=>$dt->format('Y-m-d\TH:i:s'),"TIME"=>$tv,
                "DOC_NUMBER"=>"2KAL_".$ekleyen,
                "SOURCE_WH"=>1,"DEST_WH"=>3,
                "TRANSACTIONS"=>["items"=>[$tx]],
            ], JSON_UNESCAPED_UNICODE);

            $ch = curl_init();
            curl_setopt_array($ch, [CURLOPT_URL=>$g_URL.'itemSlips', CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$pl,
                CURLOPT_HTTPHEADER=>["Authorization: Bearer $token","Content-Type: application/json"],
                CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_TIMEOUT=>60]);
            $tr = curl_exec($ch); $tc = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            error_log("[IK] Transfer HTTP $tc | ".substr($tr,0,100));

            $tr_data = json_decode($tr, true);
            if (isset($tr_data['INTERNAL_REFERENCE'])) {
                // PAKETLER ambarı güncelle
                $mes_pdo->prepare("UPDATE PAKETLER SET AMBAR='KIRMADEPO' WHERE PAKET_NO=?")
                         ->execute([$paket_no]);
                error_log("[IK] Transfer OK ref={$tr_data['INTERNAL_REFERENCE']}");
            }
        } catch(Throwable $te) {
            error_log("[IK] Transfer HATA (devam ediliyor): ".$te->getMessage());
        }
    }

    // ── 6. Etiket URL ─────────────────────────────────────────────────────────
    $etiket_url = BASE_URL.'/bolumler/uretim/paket_yazdir.php'
        .'?uretim_emri_no='.urlencode($uretim_no)
        .'&malzeme_kodu='.urlencode($stok_kodu)
        .'&malzeme_adi='.urlencode($stok_adi)
        .'&firma_kodu=15601'
        .'&firma_adi='.urlencode('Poliza A.S')
        .'&uretim_tarihi='.urlencode(date('Y-m-d'))
        .'&operator_kodu='.urlencode($calisan_id)
        .'&miktar='.urlencode((string)$toplam)
        .'&lot_no='.urlencode($paket_no)
        .'&etiket_turu=IKINCI';

    echo json_encode([
        'success'    => true,
        'message'    => "$uretim_no: $toplam adet 2. kalite kaydi yapildi. Paket: $paket_no",
        'paket_no'   => $paket_no,
        'etiket_url' => $etiket_url,
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    error_log("[IK_KAYDET] HATA: ".$e->getMessage());
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
