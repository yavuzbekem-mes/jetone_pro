<?php
ini_set('display_errors',0); error_reporting(0);
set_time_limit(15);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

$d    = json_decode(file_get_contents('php://input'),true)?:$_POST;
$id   = (int)($d['id']??0);
$p1   = (float)($d['paket1']??0);
$p2   = (float)($d['paket2']??0);
$pno  = trim($d['paketno']??'');
$sk   = trim($d['stokkodu']??'');
$sa   = trim($d['stokadi']??'');
$bir  = trim($d['birim']??'ADET');
$eno  = trim($d['uretimemrino']??'');
$tar  = trim($d['uretimtarihi']??'');
$cal  = trim($d['calisan']??'');
$etur = trim($d['etiketturu']??'URETIM');
$ahm  = trim($d['anahammadde']??'');
$syk  = trim($d['stokyeri']??'X');
$amb  = (int)($d['ambar']??1);

if(!$id || $p1<=0 || $p2<=0){
    echo json_encode(['success'=>false,'message'=>"Gecersiz (p1=$p1 p2=$p2)"]); exit;
}

try {
    $os = $mes_pdo->prepare("SELECT MIKTAR,AKTIF FROM dbo.PAKETLER WHERE ID=?");
    $os->execute([$id]);
    $orig = $os->fetch(PDO::FETCH_ASSOC);
    if(!$orig){ echo json_encode(['success'=>false,'message'=>'Paket bulunamadi']); exit; }
    if((int)$orig['AKTIF']!==0){ echo json_encode(['success'=>false,'message'=>'Bu paket bolunemez']); exit; }
    if(abs(($p1+$p2)-(float)$orig['MIKTAR'])>0.01){
        echo json_encode(['success'=>false,'message'=>'Toplam hatalı: '.(float)$orig['MIKTAR']]); exit;
    }

    $mes_pdo->beginTransaction();

    $ts   = (int)(microtime(true)*10000);
    $pno1 = 'LOT'.date('y').sprintf('%08d', $ts      % 100000000);
    $pno2 = 'LOT'.date('y').sprintf('%08d', ($ts+7)  % 100000000);

    // INSERT — trigger olduğundan OUTPUT kullanamıyoruz, PAKET_NO ile çekeceğiz
    $ins_sql = "INSERT INTO dbo.PAKETLER
        (PAKET_NO,ANA_PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,
         URETIM_EMRI_NO,URETIM_TARIHI,CALISAN,ETIKET_TURU,
         ANA_HAMMADDE,STOK_YERI,AMBAR,AKTIF,EKLEYEN,EKLENME_TARIHI)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'0',?,GETDATE())";

    // 1. paket — $p1
    $mes_pdo->prepare($ins_sql)
            ->execute([$pno1,$pno,$sk,$sa,$p1,$bir,$eno,$tar,$cal,$etur,$ahm,$syk,$amb,$kul_adi]);

    // 2. paket — $p2
    $mes_pdo->prepare($ins_sql)
            ->execute([$pno2,$pno,$sk,$sa,$p2,$bir,$eno,$tar,$cal,$etur,$ahm,$syk,$amb,$kul_adi]);

    // Orijinali pasif yap
    $mes_pdo->prepare("UPDATE dbo.PAKETLER SET AKTIF='1' WHERE ID=?")->execute([$id]);
    $mes_pdo->commit();

    // DB'den PAKET_NO ile çek — ID olmasa bile
    // Commit sonrası kısa bekle — trigger async olabilir
    usleep(100000); // 100ms

    $fetch = $mes_pdo->prepare(
        "SELECT PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,
                URETIM_EMRI_NO,URETIM_TARIHI,CALISAN,ETIKET_TURU
         FROM dbo.PAKETLER WHERE PAKET_NO IN (?,?) ORDER BY MIKTAR DESC"
    );
    $fetch->execute([$pno1,$pno2]);
    $rows = $fetch->fetchAll(PDO::FETCH_ASSOC);
    error_log("[BOL_FETCH] pno1=$pno1 pno2=$pno2 rows=".count($rows)." ".json_encode(array_column($rows,'MIKTAR')));

    $paket_detaylar = [];
    foreach($rows as $row){
        $paket_detaylar[] = [
            'paket_no'       => $row['PAKET_NO'],
            'stok_kodu'      => $row['STOK_KODU'],
            'stok_adi'       => $row['STOK_ADI'],
            'miktar'         => (float)$row['MIKTAR'],
            'birim'          => $row['BIRIM'],
            'uretim_emri_no' => $row['URETIM_EMRI_NO'],
            'uretim_tarihi'  => substr($row['URETIM_TARIHI']??'',0,10),
            'calisan'        => $row['CALISAN'],
            'etiket_turu'    => $row['ETIKET_TURU']??'URETIM',
            'firma_kodu'     => '15601',
            'firma_adi'      => 'Poliza A.S',
        ];
    }

    // DB'den çekemedik — PHP değişkenlerinden fallback (miktar kesin doğru)
    if(empty($paket_detaylar)) {
        error_log("[BOL_FALLBACK] DB sorgusu boş döndü, fallback kullanılıyor");
        $paket_detaylar = [
            [
                'paket_no'       => $pno1,
                'stok_kodu'      => $sk,
                'stok_adi'       => $sa,
                'miktar'         => $p1,
                'birim'          => $bir,
                'uretim_emri_no' => $eno,
                'uretim_tarihi'  => substr($tar,0,10),
                'calisan'        => $cal,
                'etiket_turu'    => $etur,
                'firma_kodu'     => '15601',
                'firma_adi'      => 'Poliza A.S',
            ],
            [
                'paket_no'       => $pno2,
                'stok_kodu'      => $sk,
                'stok_adi'       => $sa,
                'miktar'         => $p2,
                'birim'          => $bir,
                'uretim_emri_no' => $eno,
                'uretim_tarihi'  => substr($tar,0,10),
                'calisan'        => $cal,
                'etiket_turu'    => $etur,
                'firma_kodu'     => '15601',
                'firma_adi'      => 'Poliza A.S',
            ],
        ];
    }

    echo json_encode([
        'success'        => true,
        'message'        => "$pno1 ($p1) + $pno2 ($p2) — DB: ".implode(', ',array_column($paket_detaylar,'miktar')),
        'paketler'       => [$pno1,$pno2],
        'paket_detaylar' => $paket_detaylar,
    ], JSON_UNESCAPED_UNICODE|JSON_NUMERIC_CHECK);

} catch(Throwable $e){
    if($mes_pdo->inTransaction()) $mes_pdo->rollBack();
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
