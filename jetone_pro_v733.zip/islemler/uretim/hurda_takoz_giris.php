<?php
/**
 * Hurda/Takoz Giriş — Logo REST API fire fişi (TYPE=11)
 * POST FormData veya JSON
 */
ini_set('display_errors', 0);
error_reporting(0);
while (ob_get_level() > 0) ob_end_clean();

require_once dirname(__DIR__, 2) . '/core/config.php';
require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';
require_once dirname(__DIR__, 2) . '/core/auth.php';

while (ob_get_level() > 0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

set_time_limit(120);
ini_set('memory_limit', '256M');
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/uretim_errors.log');

error_log("=== HURDA GIRIS BASLADI " . date('H:i:s') . " ===");

if (!Auth::girisYapilmisMi()) {
    echo json_encode(['success' => false, 'message' => 'Oturum gecersiz']); exit;
}

// ERP kullanıcı adı
$kul = Auth::kullanici();
$kul_adi = '';
if (is_array($kul)) {
    if (!empty($kul['ad_soyad'])) $kul_adi = trim($kul['ad_soyad']);
    elseif (!empty($kul['ad']))    $kul_adi = trim($kul['ad'] . ' ' . ($kul['soyad'] ?? ''));
    elseif (!empty($kul['email'])) $kul_adi = explode('@', $kul['email'])[0];
}
if (!$kul_adi) $kul_adi = 'JETONE';
error_log("[HURDA] kul_adi=$kul_adi");

// Veri al
$json  = file_get_contents('php://input');
$input = json_decode($json, true);
$data  = !empty($input) ? $input : $_POST;

$uretim_no   = trim($data['uretim_emri_no'] ?? '');
$fire_miktari = trim($data['fire_miktari']  ?? '');
$is_istasyonu = trim($data['is_istasyonu']  ?? '');
$itemref      = trim($data['itemref']       ?? '');
$uomref       = trim($data['uomref']        ?? '');
$ekleyen      = trim($data['ekleyen']       ?? 'jetone');
$ambar        = (int)($data['ambar']        ?? 1);

// Validasyon
if (!$uretim_no)  { echo json_encode(['success'=>false,'message'=>'Uretim emri no eksik']); exit; }
if (!$fire_miktari || !is_numeric($fire_miktari) || (float)$fire_miktari <= 0) {
    echo json_encode(['success'=>false,'message'=>'Gecerli fire miktari giriniz']); exit;
}
if (!$is_istasyonu) { echo json_encode(['success'=>false,'message'=>'Is istasyonu eksik']); exit; }
if (!$itemref)    { echo json_encode(['success'=>false,'message'=>'itemref eksik']); exit; }
if (!$uomref)     { echo json_encode(['success'=>false,'message'=>'uomref eksik']); exit; }

// Token al
$token = $GLOBALS['API_TOKEN'] ?? '';
if (!$token && $mes_pdo) {
    try {
        $ts = $mes_pdo->query("SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR WHERE DATEDIFF(day,TARIH,GETDATE())=0 ORDER BY ID DESC");
        $tr = $ts->fetch(PDO::FETCH_ASSOC);
        if ($tr) $token = $tr['TOKEN'];
    } catch(Throwable $e) {}
}
if (!$token) { echo json_encode(['success'=>false,'message'=>'API token alinamadi']); exit; }

// Global_Rest URL
$g_URL = defined('Global_Rest') || class_exists('Global_Rest')
    ? Global_Rest::$g_URL
    : 'http://192.168.1.100:32001/api/v1/';

try {
    if (!$tigerdb_pdo) throw new Exception('Tiger DB baglantisi yok');

    // STEP 1: PRO_LOGICALREF
    error_log("STEP 1: $uretim_no aranıyor");
    $ps = $tigerdb_pdo->prepare("SELECT LOGICALREF FROM dbo.LG_222_PRODORD WHERE FICHENO=?");
    $ps->execute([$uretim_no]);
    $pro = $ps->fetch(PDO::FETCH_ASSOC);
    if (!$pro) throw new Exception("Uretim emri bulunamadi: $uretim_no");
    $pro_logicalref = (int)$pro['LOGICALREF'];
    error_log("STEP 1 OK: LOGICALREF=$pro_logicalref");

    // STEP 2: MES_TAKOZ_HAMMADDELER
    error_log("STEP 2: Takoz hammadde aranıyor");
    $ts = $tigerdb_pdo->prepare(
        "SELECT TOP 1 IS_EMRI_LOGICAL, ANA_HAMMADDE, HAMMADDE_ADI,
                BIRIM, AMBAR, IS_ISTASYONU, POLI_LOGICALREF
         FROM MES_TAKOZ_HAMMADDELER WHERE PRO_LOGICALREF=?"
    );
    $ts->execute([$pro_logicalref]);
    $takoz = $ts->fetch(PDO::FETCH_ASSOC);
    if (!$takoz) throw new Exception("MES_TAKOZ_HAMMADDELER: $uretim_no icin kayit yok");

    $is_emri_logical = $takoz['IS_EMRI_LOGICAL'];
    $hammadde_kodu   = $takoz['ANA_HAMMADDE'];
    $hammadde_adi    = $takoz['HAMMADDE_ADI'];
    $birim_kodu      = $takoz['BIRIM'];
    $ambar_no        = $takoz['AMBAR'];
    $poli_logicalref = $takoz['POLI_LOGICALREF'];
    $is_ist_final    = $is_istasyonu ?: $takoz['IS_ISTASYONU'];
    error_log("STEP 2 OK: Hammadde=$hammadde_kodu, Ambar=$ambar_no");

    // STEP 3: LOT bilgisi
    error_log("STEP 3: Lot aranıyor: $hammadde_kodu >= $fire_miktari");
    $ss = $tigerdb_pdo->prepare(
        "SELECT TOP 1 SOURCE_SLT_REFERENCE, STTRANSREF, LOT_NO, KALAN_MIKTAR
         FROM MES_STOK_KONTROL
         WHERE STOK_KODU=? AND AMBAR_NO=1 AND KALAN_MIKTAR>=?
         ORDER BY KALAN_MIKTAR DESC"
    );
    $ss->execute([$hammadde_kodu, (float)$fire_miktari]);
    $stok = $ss->fetch(PDO::FETCH_ASSOC);
    if (!$stok) throw new Exception("$hammadde_kodu kodlu hammaddede yeterli lot yok (gereken: $fire_miktari $birim_kodu)");

    $source_slt_ref    = (int)$stok['SOURCE_SLT_REFERENCE'];
    $sttransref        = (int)$stok['STTRANSREF'];
    $lot_no            = $stok['LOT_NO'];
    $kullanilacak      = min((float)$fire_miktari, (float)$stok['KALAN_MIKTAR']);
    error_log("STEP 3 OK: LOT=$lot_no, SLT=$source_slt_ref, miktar=$kullanilacak");

    // STEP 4: Payload oluştur
    $tarih      = date('Y-m-d H:i:s');
    $saat       = (int)date('H');
    $dakika     = (int)date('i');
    $time_value = ($saat * 65536 * 256) + ($dakika * 65536) + ($saat * 256);

    $payload = [
        "INTERNAL_REFERENCE" => 0,
        "GROUP"              => 3,
        "TYPE"               => 11,
        "PORDER_TYPE"        => 1,
        "NUMBER"             => "~",
        "DOC_NUMBER"         => $kul_adi,
        "DATE"               => $tarih,
        "TIME"               => $time_value,
        "SOURCE_WH"          => strval($ambar_no),
        "SOURCE_WSCODE"      => $is_ist_final,
        "SPO_DETAIL_CODE"    => intval($is_emri_logical),
        "SRCPOLN_REFERENCE"  => intval($is_emri_logical),
        "CURRSEL_TOTALS"     => 1,
        "TRANSACTIONS"       => [
            "items" => [[
                "LINE_TYPE"            => 0,
                "ITEM_CODE"            => $hammadde_kodu,
                "DESCRIPTION"          => "takoz - " . $kul_adi,
                "QUANTITY"             => floatval($kullanilacak),
                "UNIT_CODE"            => $birim_kodu,
                "PRORD_REFERENCE"      => strval($poli_logicalref),
                "SOURCEINDEX"          => strval($ambar_no),
                "EDT_CURR"             => 1,
                "SL_DETAILS"           => [
                    "items" => [[
                        "SOURCE_MT_REFERENCE"  => strval($sttransref),
                        "SOURCE_SLT_REFERENCE" => strval($source_slt_ref),
                        "QUANTITY"             => strval($kullanilacak),
                        "SOURCE_QUANTITY"      => strval($kullanilacak),
                        "SL_TYPE"              => 1,
                        "SL_CODE"              => $lot_no,
                        "MU_QUANTITY"          => strval($kullanilacak),
                        "UNIT_CODE"            => $birim_kodu,
                        "SOURCE_WH"            => 1,
                        "IOCODE"               => 4,
                    ]]
                ],
            ]]
        ],
    ];

    $json_body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    error_log("STEP 4: API gonderiliyor, payload=" . substr($json_body, 0, 200));

    // STEP 5: API çağrısı
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $g_URL . 'itemSlips',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $json_body,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Bearer $token",
            "Content-Type: application/json",
            "Content-Length: " . strlen($json_body),
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response  = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_err  = curl_error($ch);
    curl_close($ch);

    error_log("STEP 5: HTTP=$http_code, response=" . substr($response, 0, 200));

    if ($curl_err) throw new Exception("cURL: $curl_err");

    // Başarı kontrolü
    if ($http_code === 200 && strpos($response, 'INTERNAL_REFERENCE') !== false) {
        $resp_data = json_decode($response, true);
        $fis_no    = $resp_data['NUMBER'] ?? 'N/A';
        error_log("BASARILI: Fire fisi=$fis_no");

        echo json_encode([
            'success' => true,
            'message' => "$hammadde_kodu kodlu $hammadde_adi hammaddeden $kullanilacak $birim_kodu Hurda(Takoz) girisi yapildi. Fis: $fis_no",
            'data'    => [
                'fis_no'          => $fis_no,
                'uretim_emri_no'  => $uretim_no,
                'hammadde_kodu'   => $hammadde_kodu,
                'fire_miktari'    => $kullanilacak,
                'birim'           => $birim_kodu,
                'lot_no'          => $lot_no,
            ],
        ], JSON_UNESCAPED_UNICODE);
    } else {
        // Hata mesajını parse et
        $hata = "HTTP $http_code";
        if (strpos($response, 'LOError:') !== false) {
            preg_match('/LOError:.*?"([^"]+)"/', $response, $m);
            $hata = $m[1] ?? $hata;
        } elseif ($response) {
            $decoded = json_decode($response, true);
            $hata = $decoded['Message'] ?? $decoded['message'] ?? substr($response, 0, 200);
        }
        throw new Exception("Logo API hatasi: $hata");
    }

} catch (Throwable $e) {
    error_log("HURDA HATA: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
