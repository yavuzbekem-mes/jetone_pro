<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id         = (int)($_GET['id']          ?? 0);
$tamamlayan = trim($_GET['tamamlayan']   ?? '');
if (!$id) { echo '<script>history.back();</script>'; exit; }

try {
    $db->prepare("UPDATE kalip_degisim SET durumu='Tamamlandı', bitis_tarih=NOW(), tamamlayan=? WHERE kalip_id=?")
    ->execute([$tamamlayan, $id]);
    echo '<script>location.href="'.BASE_URL.'/panel.php?sayfa=uretim-kalip-devam&durum=ok";</script>';
} catch (Throwable $e) {
    echo '<script>history.back();</script>';
}
exit;
