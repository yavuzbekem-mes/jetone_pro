<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

$urun_adi       = trim($_POST['urun_adi']       ?? '');
$urun_kodu      = trim($_POST['urun_kodu']      ?? '');
$is_istasyonu   = trim($_POST['is_istasyonu']   ?? '');
$aciliyet       = trim($_POST['aciliyet']       ?? 'Normal');
$vardiya        = (int)($_POST['vardiya']       ?? 1);
$kalip_aciklama = trim($_POST['kalip_aciklama'] ?? '');
$ekleyen        = trim($_POST['ekleyen']        ?? $kul['ad_soyad'] ?? '');

if (!$urun_adi || !$is_istasyonu) {
    echo '<script>history.back();</script>'; exit;
}

try {
    $db->prepare("INSERT INTO kalip_degisim
        (urun_kodu, urun_adi, kalip_aciklama, is_istasyonu, aciliyet, vardiya, ekleyen, durumu, baslama_tarih)
        VALUES (?,?,?,?,?,?,?,'Devam Ediyor', NOW())")
    ->execute([$urun_kodu,$urun_adi,$kalip_aciklama,$is_istasyonu,$aciliyet,$vardiya,$ekleyen]);
    echo '<script>location.href="'.BASE_URL.'/panel.php?sayfa=uretim-kalip-devam&durum=ok";</script>';
} catch (Throwable $e) {
    error_log('kalip_ekle: '.$e->getMessage());
    echo '<script>history.back();</script>';
}
exit;
