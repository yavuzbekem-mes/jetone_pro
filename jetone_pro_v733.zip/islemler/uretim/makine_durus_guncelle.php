<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$raw = json_decode(file_get_contents('php://input'),true)?:$_POST;
$id      = (int)($raw['id']??0);
$bas_z   = trim($raw['baslangic_zamani']??'');
$bit_z   = trim($raw['bitis_zamani']    ??'');
$neden   = trim($raw['durus_nedeni']    ??'');
$aciklama= trim($raw['aciklama']        ??'');

if(!$id||!$bas_z||!$bit_z||!$neden){ echo json_encode(['success'=>false,'message'=>'Eksik alan']); exit; }

try {
    $b=new DateTime($bas_z); $e=new DateTime($bit_z);
    if($e<=$b){ echo json_encode(['success'=>false,'message'=>'Bitis baslangictan buyuk olmali']); exit; }
    $iv=$b->diff($e);
    $sure_dk=$iv->days*24*60+$iv->h*60+$iv->i;

    $neden_final = ($neden === 'Diğer' && !empty($aciklama)) ? 'Diğer: '.$aciklama : $neden;
    $bas_sql = str_replace('T',' ',$bas_z);
    $bit_sql = str_replace('T',' ',$bit_z);
    $st=$mes_pdo->prepare(
        "UPDATE MAKINE_DURUSLARI SET BASLANGIC_ZAMANI=?,BITIS_ZAMANI=?,SURE_DK=?,DURUS_NEDENI=? WHERE ID=?"
    );
    $st->execute([$bas_sql,$bit_sql,$sure_dk,$neden_final,$id]);
    echo json_encode(['success'=>true,'message'=>'Durus guncellendi.','sure_dk'=>$sure_dk],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
