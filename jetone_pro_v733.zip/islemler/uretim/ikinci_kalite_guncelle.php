<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$raw     = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id      = (int)($raw['id']      ?? 0);
$calisan = trim($raw['calisan']   ?? '');
$toplam  = (float)($raw['toplam'] ?? 0);

// Defekt kolonları
$ayar  = (float)($raw['ayar_firesi']       ?? 0);
$hleke = (float)($raw['hammadde_lekesi']   ?? 0);
$yleke = (float)($raw['yag_lekesi']        ?? 0);
$cizik = (float)($raw['cizik']             ?? 0);
$eenj  = (float)($raw['eksik_enjeksiyon']  ?? 0);
$catlak= (float)($raw['catlak']            ?? 0);
$gaz   = (float)($raw['gazlanma']          ?? 0);
$cokun = (float)($raw['cokuntu']           ?? 0);
$serp  = (float)($raw['serpme']            ?? 0);
$yanma = (float)($raw['yanma']             ?? 0);

// Toplam hesapla (güvenlik için server-side)
$toplam_hesap = $ayar+$hleke+$yleke+$cizik+$eenj+$catlak+$gaz+$cokun+$serp+$yanma;
if($toplam_hesap > 0) $toplam = $toplam_hesap;

if(!$id){ echo json_encode(['success'=>false,'message'=>'ID eksik']); exit; }

try {
    $mes_pdo->prepare(
        "UPDATE dbo.IKINCI_KALITE SET
            CALISAN=?, TOPLAM=?,
            [AYAR_FIRESİ]=?, HAMMADDE_LEKESI=?, YAG_LEKESI=?,
            CIZIK=?, EKSIK_ENJEKSIYON=?, CATLAK=?,
            GAZLANMA=?, COKUNTU=?, SERPME=?, YANMA=?
         WHERE ID=?"
    )->execute([$calisan,$toplam,$ayar,$hleke,$yleke,$cizik,$eenj,$catlak,$gaz,$cokun,$serp,$yanma,$id]);
    echo json_encode(['success'=>true,'message'=>"Kayit guncellendi. Toplam: $toplam adet."],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
