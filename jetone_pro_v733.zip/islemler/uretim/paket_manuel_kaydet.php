<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES bağlantısı yok']); exit; }

$d = $_POST;
$stok_kodu    = strtoupper(trim($d['stok_kodu']    ?? ''));
$stok_adi     = trim($d['stok_adi']                ?? '');
$miktar       = (float)($d['miktar']               ?? 0);
$birim        = strtoupper(trim($d['birim']        ?? 'ADET'));
$uretim_emri  = strtoupper(trim($d['uretim_emri_no'] ?? '')) ?: 'MANUEL';
$ambar        = (int)($d['ambar']                  ?? 1);
$stok_yeri    = strtoupper(trim($d['stok_yeri']    ?? 'X')) ?: 'X';
$calisan      = trim($d['calisan']                 ?? '');
$uretim_tar   = trim($d['uretim_tarihi']           ?? date('Y-m-d'));
$etiket_turu  = strtoupper(trim($d['etiket_turu']  ?? 'URETIM'));

if(!$stok_kodu || $miktar<=0){
    echo json_encode(['success'=>false,'message'=>'Stok kodu ve miktar zorunlu']); exit;
}

// Stok adı yoksa Tiger'dan çek
if(!$stok_adi && $tigerdb_pdo) {
    try {
        $st=$tigerdb_pdo->prepare("SELECT TOP 1 NAME FROM dbo.LG_222_ITEMS WHERE CODE=? AND ACTIVE=0");
        $st->execute([$stok_kodu]);
        $r=$st->fetch(PDO::FETCH_ASSOC);
        if($r) $stok_adi=$r['NAME'];
    } catch(Throwable $e){}
}

try {
    $ts   = (int)(microtime(true)*10000);
    $pno  = 'LOT'.date('y').sprintf('%08d', $ts % 100000000);

    $mes_pdo->prepare(
        "INSERT INTO dbo.PAKETLER
         (PAKET_NO,ANA_PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,
          URETIM_EMRI_NO,URETIM_TARIHI,CALISAN,ETIKET_TURU,
          ANA_HAMMADDE,STOK_YERI,AMBAR,AKTIF,EKLEYEN,KAYIT_TURU,EKLENME_TARIHI)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'0',?,'MANUEL',GETDATE())"
    )->execute([
        $pno,$pno,$stok_kodu,$stok_adi,$miktar,$birim,
        $uretim_emri,$uretim_tar,$calisan,$etiket_turu,
        $stok_adi,$stok_yeri,$ambar,$calisan
    ]);

    echo json_encode([
        'success' => true,
        'message' => "Paket oluşturuldu: $pno",
        'paket'   => [
            'paket_no'       => $pno,
            'stok_kodu'      => $stok_kodu,
            'stok_adi'       => $stok_adi,
            'miktar'         => $miktar,
            'birim'          => $birim,
            'uretim_emri_no' => $uretim_emri,
            'uretim_tarihi'  => $uretim_tar,
            'calisan'        => $calisan,
            'etiket_turu'    => $etiket_turu,
        ],
    ], JSON_UNESCAPED_UNICODE|JSON_NUMERIC_CHECK);

} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
