<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

$raw   = json_decode(file_get_contents('php://input'),true)?:$_POST;
$id    = (int)($raw['id']    ?? 0);
$islem = trim($raw['islem']  ?? ''); // ONAYLA veya REDDET
$not   = trim($raw['not']    ?? '');

if(!$id || !in_array($islem,['ONAYLA','REDDET'])){
    echo json_encode(['success'=>false,'message'=>'Gecersiz istek']); exit;
}

try {
    $talep = $db->query("SELECT * FROM iptal_talepler WHERE id=$id")->fetch(PDO::FETCH_ASSOC);
    if(!$talep){ echo json_encode(['success'=>false,'message'=>'Talep bulunamadi']); exit; }
    if($talep['durum']!=='BEKLIYOR'){
        echo json_encode(['success'=>false,'message'=>'Bu talep zaten işleme alınmış: '.$talep['durum']]); exit;
    }

    $yeni_durum = $islem==='ONAYLA' ? 'ONAYLANDI' : 'REDDEDILDI';
    $db->prepare("UPDATE iptal_talepler SET durum=?,islem_yapan=?,islem_tarihi=NOW(),islem_notu=? WHERE id=?")
       ->execute([$yeni_durum,$kul_adi,$not,$id]);

    $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
       ->execute([$id,$islem,$kul_adi,$not]);

    $mesajlar = [];

    if($islem==='ONAYLA') {

        // ── 1. Tiger Logo fiş silme ───────────────────────────────────────────
        $logo_fis_no = trim($talep['logo_fis_no'] ?? '');
        if($logo_fis_no && $tigerdb_pdo) {
            try {
                // Tiger'da bu fiş var mı sadece kontrol et — silme işlemi yapma
                $fs = $tigerdb_pdo->prepare(
                    "SELECT LOGICALREF, FICHENO, CANCELLED
                     FROM dbo.LG_222_02_STFICHE
                     WHERE FICHENO=? AND TRCODE=13"
                );
                $fs->execute([$logo_fis_no]);
                $tiger_fis = $fs->fetch(PDO::FETCH_ASSOC);

                if($tiger_fis) {
                    if((int)$tiger_fis['CANCELLED'] === 1) {
                        // Zaten iptal edilmiş
                        $mesajlar[] = "ℹ️ Logo fişi zaten iptal edilmiş: <b>$logo_fis_no</b>";
                        $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
                           ->execute([$id,'LOGO_FIS_ZATEN_IPTAL',$kul_adi,"Fis: $logo_fis_no"]);
                    } else {
                        // Fiş aktif — manuel silim uyarısı
                        $mesajlar[] = "⚠️ Logo'da bu fiş mevcut, <b>lütfen Logo ERP'den manuel siliniz: $logo_fis_no</b>";
                        $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
                           ->execute([$id,'LOGO_FIS_MANUEL_SILINMELI',$kul_adi,"Fis: $logo_fis_no — Logo'dan manuel silim gerekiyor"]);
                    }
                } else {
                    // Tiger'da hiç bulunamadı
                    $mesajlar[] = "ℹ️ Logo'da bu fiş bulunamadı (daha önce silinmiş): <b>$logo_fis_no</b>";
                    $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
                       ->execute([$id,'LOGO_FIS_BULUNAMADI',$kul_adi,"Fis: $logo_fis_no — Tiger kayıtlarında yok"]);
                }
            } catch(Throwable $te){
                $mesajlar[] = "⚠️ Logo fiş kontrolünde hata: ".$te->getMessage();
                error_log("[IPTAL_ISLEM] Tiger hata: ".$te->getMessage());
            }
        } elseif($logo_fis_no) {
            $mesajlar[] = "⚠️ Tiger bağlantısı yok, fiş durumu kontrol edilemedi: $logo_fis_no";
        }

        // ── 2. MES kaydı sil ─────────────────────────────────────────────────
        if($talep['mes_kayit_id'] && $mes_pdo) {
            try {
                $tablo = $talep['kayit_tipi']==='2K' ? 'dbo.IKINCI_KALITE' : 'dbo.PAKETLER';
                $where = $talep['kayit_tipi']==='1K'
                    ? "ID=? AND ISNULL(ETIKET_TURU,'') NOT IN ('IKINCI','HURDA','FIRE')"
                    : "ID=?";
                $mes_pdo->prepare("DELETE FROM $tablo WHERE $where")
                        ->execute([$talep['mes_kayit_id']]);
                $mesajlar[] = "✅ MES kaydı silindi: " . ($talep['paket_no'] ?: 'ID='.$talep['mes_kayit_id']);
                $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
                   ->execute([$id,'MES_SILINDI',$kul_adi,"$tablo ID=".$talep['mes_kayit_id']." | Paket: ".$talep['paket_no']." | ".$talep['stok_kodu']." x ".$talep['miktar']]);
            } catch(Throwable $me){
                $mesajlar[] = "⚠️ MES kaydı silinemedi: ".$me->getMessage();
                error_log("[IPTAL_ISLEM] MES silme hatası: ".$me->getMessage());
            }
        }
    }

    $temel_msg = $islem==='ONAYLA' ? 'Talep onaylandı.' : 'Talep reddedildi.';
    $full_msg   = $temel_msg . (!empty($mesajlar) ? "\n" . implode("\n", $mesajlar) : '');
    echo json_encode(['success'=>true,'message'=>$full_msg,'detaylar'=>$mesajlar],JSON_UNESCAPED_UNICODE);

} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
