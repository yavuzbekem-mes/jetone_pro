<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/token.php';

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$uretim_no = trim($input['uretim_emri_no'] ?? $_POST['uretim_emri_no'] ?? '');

if (!$uretim_no) { echo json_encode(['success'=>false,'message'=>'uretim_emri_no eksik']); exit; }

try {
    $token = $GLOBALS['API_TOKEN'] ?? '';
    if (!$token) throw new Exception('Token alınamadı');

    $params  = $uretim_no . "/3/1/true/2";
    $api_url = Global_Rest::$g_URL . "productions/ChangePOAndWOStatus/" . $params;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ["Authorization: Bearer $token","Content-Type: application/json"],
        CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_err = curl_error($ch);
    curl_close($ch);

    if ($curl_err) throw new Exception('cURL: '.$curl_err);
    if ($http_code===200) {
        echo json_encode(['success'=>true,'message'=>'Üretim emri başarıyla kapatıldı.','response'=>$response]);
    } else {
        throw new Exception("HTTP $http_code: $response");
    }
} catch(Exception $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
