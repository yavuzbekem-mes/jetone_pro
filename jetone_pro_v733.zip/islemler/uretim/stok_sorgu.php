<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$tigerdb_pdo){ echo json_encode(['success'=>false,'message'=>'Tiger bağlantısı yok']); exit; }

$kod = trim($_GET['kod'] ?? '');
if(!$kod){ echo json_encode(['success'=>false,'message'=>'Kod eksik']); exit; }

try {
    $st = $tigerdb_pdo->prepare(
        "SELECT TOP 1
            IT.CODE,
            IT.NAME,
            UN.CODE AS BIRIM
         FROM dbo.LG_222_ITEMS IT
         LEFT JOIN dbo.LG_222_UNITSETL UN ON UN.UNITSETREF=IT.UNITSETREF AND UN.MAINUNIT=1
         WHERE IT.CODE=? AND IT.CARDTYPE NOT IN (4,22) AND IT.ACTIVE=0"
    );
    $st->execute([$kod]);
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if($row){
        echo json_encode(['success'=>true,'stok'=>[
            'CODE'  => $row['CODE'],
            'NAME'  => $row['NAME'],
            'BIRIM' => $row['BIRIM'] ?: 'ADET',
        ]], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success'=>false,'message'=>"'$kod' stok kodu bulunamadı"]);
    }
} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
