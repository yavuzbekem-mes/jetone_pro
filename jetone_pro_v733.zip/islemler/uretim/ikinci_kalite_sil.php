<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }
if(!$mes_pdo){ echo json_encode(['success'=>false,'message'=>'MES baglantisi yok']); exit; }

$raw = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id  = (int)($raw['id'] ?? 0);
if(!$id){ echo json_encode(['success'=>false,'message'=>'ID eksik']); exit; }

try {
    $mes_pdo->prepare("DELETE FROM dbo.IKINCI_KALITE WHERE ID=?")->execute([$id]);
    echo json_encode(['success'=>true,'message'=>'Kayit silindi.']);
} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
