<?php
/**
 * Üretim Emri Başlat
 * POST JSON: {"uretim_emri_no":"UE-22014694"}
 */
ob_start();
require_once dirname(__DIR__, 2) . '/core/config.php';
require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';
require_once dirname(__DIR__, 2) . '/core/auth.php';
require_once __DIR__ . '/token.php';
ob_end_clean();

header('Content-Type: application/json; charset=utf-8');

if (!Auth::girisYapilmisMi()) { echo json_encode(['success'=>false,'message'=>'Oturum geçersiz']); exit; }

$data = json_decode(file_get_contents('php://input'), true) ?: [];
$uretim_no = trim($data['uretim_emri_no'] ?? '');

if (!$uretim_no) { echo json_encode(['success'=>false,'message'=>'uretim_emri_no eksik']); exit; }
if (!$tigerdb_pdo) { echo json_encode(['success'=>false,'message'=>'Tiger DB bağlantısı yok']); exit; }

try {
    // LOGICALREF'i al
    $ps = $tigerdb_pdo->prepare("SELECT TOP 1 LOGICALREF FROM dbo.LG_222_PRODORD WHERE FICHENO=?");
    $ps->execute([$uretim_no]);
    $row = $ps->fetch(PDO::FETCH_ASSOC);
    if (!$row) { echo json_encode(['success'=>false,'message'=>'Üretim emri bulunamadı']); exit; }

    $token = $GLOBALS['API_TOKEN'] ?? '';
    if (!$token) { echo json_encode(['success'=>false,'message'=>'API token alınamadı']); exit; }

    $ref = (int)$row['LOGICALREF'];
    $url = Global_Rest::$g_URL . "productions/$ref";

    $payload = json_encode(["STATUS" => 1]);
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_CUSTOMREQUEST  => 'PUT',
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Bearer $token",
            "Content-Type: application/json",
        ],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 15,
    ]);
    $yanit = curl_exec($ch);
    $kod   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hata  = curl_error($ch);
    curl_close($ch);

    if ($hata) { echo json_encode(['success'=>false,'message'=>"cURL: $hata"]); exit; }
    if ($kod >= 200 && $kod < 300) {
        echo json_encode(['success'=>true,'message'=>'Üretim emri başlatıldı']);
    } else {
        echo json_encode(['success'=>false,'message'=>"HTTP $kod: $yanit"]);
    }
} catch(Throwable $e) {
    error_log("[ue_durum] " . $e->getMessage());
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
