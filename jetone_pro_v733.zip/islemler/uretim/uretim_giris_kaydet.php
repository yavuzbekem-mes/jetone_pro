<?php
/**
 * Üretim Giriş Kaydet
 * POST JSON — Logo FastRealizeFicheGenerate + MES PAKETLER kaydı
 */
ob_start();
require_once dirname(__DIR__, 2) . '/core/config.php';
require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';
require_once dirname(__DIR__, 2) . '/core/auth.php';

// Global_Rest sınıfı token.php'den geliyor
if (!class_exists('Global_Rest')) {
    require_once __DIR__ . '/token.php';
}

ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/uretim_errors.log');

if (!Auth::girisYapilmisMi()) {
    echo json_encode(['success' => false, 'message' => 'Oturum geçersiz']); exit;
}

// ERP kullanıcı adını al
$kul = Auth::kullanici();
$kul_adi = '';
if (is_array($kul)) {
    if (!empty($kul['ad_soyad'])) $kul_adi = trim($kul['ad_soyad']);
    elseif (!empty($kul['ad']))    $kul_adi = trim($kul['ad'] . ' ' . ($kul['soyad'] ?? ''));
    elseif (!empty($kul['email'])) $kul_adi = explode('@', $kul['email'])[0];
}
if (!$kul_adi) $kul_adi = 'JETONE';
error_log("[URETIM_GIRIS] kul_adi=$kul_adi");

// Veri al
$json      = file_get_contents('php://input');
$json_data = json_decode($json, true);
$data      = !empty($json_data) ? $json_data : $_POST;

if (empty($data)) {
    echo json_encode(['success' => false, 'message' => 'Veri bulunamadı']); exit;
}

$response = ['success' => false, 'message' => ''];

try {
    // Zorunlu alan kontrolleri
    if (empty($data['uretim_emri_id'])) throw new Exception('Üretim emri ID eksik');
    if (empty($data['miktar']) || (int)$data['miktar'] < 1) throw new Exception('Geçersiz miktar');
    if (empty($data['calisan'])) throw new Exception('Çalışan seçilmedi');
    if (empty($data['itemref'])) throw new Exception('itemref eksik — sistem yöneticisiyle iletişime geçin');
    if (empty($data['uomref']))  throw new Exception('uomref eksik — sistem yöneticisiyle iletişime geçin');

    // ── 1. Token al ─────────────────────────────────────────────────────────
    $token = $GLOBALS['API_TOKEN'] ?? '';
    if (!$token) {
        // DB'den bugünün tokenını al
        if ($mes_pdo) {
            $ts = $mes_pdo->query(
                "SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR
                 WHERE DATEDIFF(day,TARIH,GETDATE())=0 ORDER BY ID DESC"
            );
            $tr = $ts->fetch(PDO::FETCH_ASSOC);
            if ($tr) $token = $tr['TOKEN'];
        }
    }
    if (!$token) throw new Exception('API token alınamadı');

    // ── 2. Logo FastRealizeFicheGenerate ────────────────────────────────────
    $oid     = (int)$data['uretim_emri_id'];
    $itemref = (int)$data['itemref'];
    $miktar  = (float)$data['miktar'];
    $uomref  = (int)$data['uomref'];
    $dateNow = date('Y-m-d\TH:i:s');
    // Format: oid/itemref/miktar/uomref/1/False/tarih/0
    $str10   = "$oid/$itemref/$miktar/$uomref/1/False/$dateNow/0";
    $apiUrl  = Global_Rest::$g_URL . "productions/FastRealizeFicheGenerate/$str10";

    error_log("[uretim_giris] API URL: $apiUrl");

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Bearer $token",
            "Content-Type: application/json",
            "Accept: application/json",
        ],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => 30,
    ]);
    $apiResp = curl_exec($ch);
    $httpKod = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    error_log("[uretim_giris] HTTP $httpKod | $apiResp");

    if ($curlErr) throw new Exception("cURL: $curlErr");
    if ($httpKod < 200 || $httpKod >= 300) {
        throw new Exception("Logo API hatası (HTTP $httpKod): $apiResp");
    }

    // API yanıtından Logo fiş no çıkar
    $logo_fis_no = '';
    $apiRespData = json_decode($apiResp, true);
    if (!empty($apiRespData['InputfromProdSlips'])) {
        $logo_fis_no = $apiRespData['InputfromProdSlips'];
    } elseif (!empty($apiRespData['NUMBER'])) {
        $logo_fis_no = $apiRespData['NUMBER'];
    } elseif (preg_match('/"NUMBER"\s*:\s*"([^"]+)"/', $apiResp, $m)) {
        $logo_fis_no = $m[1];
    }

    // ── 3. MES PAKETLER kaydı ───────────────────────────────────────────────
    if (!$mes_pdo) throw new Exception('MES bağlantısı yok');

    $paket_no = 'PKT' . date('y') . str_pad($oid, 6, '0', STR_PAD_LEFT);

    $sql = "INSERT INTO PAKETLER (
        PAKET_NO, STOK_KODU, STOK_ADI,
        MIKTAR, BIRIM, URETIM_EMRI_NO,
        URETIM_TARIHI, AKTIF, CALISAN,
        ETIKET_TURU, ANA_HAMMADDE, STOK_YERI,
        EKLEYEN, FIS_NO, KAYIT_TURU,
        AMBAR, EKLENME_TARIHI
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GETDATE())";

    $st = $mes_pdo->prepare($sql);
    $st->execute([
        $paket_no,
        $data['stok_kodu']     ?? '',
        $data['stok_adi']      ?? '',
        $miktar,
        $data['birim']         ?? 'ADET',
        $data['uretim_emri_no'] ?? '',
        $data['uretim_tarihi'] ?? date('Y-m-d'),
        '0',
        $data['calisan']       ?? '',
        'URETIM',
        $data['ana_hammadde']  ?? '',
        $data['stok_yeri']     ?? 'X',
        $kul_adi ?: ($data['ekleyen'] ?? 'JETONE'),
        $logo_fis_no ?: ($data['uretim_emri_no'] ?? ''),
        'URETIM',
        (int)($data['ambar']   ?? 1),
    ]);

    error_log("[uretim_giris] PAKETLER kaydedildi: $paket_no");

    // ── 4. Etiket URL'si ────────────────────────────────────────────────────
    $etiket_url = BASE_URL . '/bolumler/uretim/paket_yazdir.php'
        . '?uretim_emri_no=' . urlencode($data['uretim_emri_no'] ?? '')
        . '&malzeme_kodu='   . urlencode($data['stok_kodu']      ?? '')
        . '&malzeme_adi='    . urlencode($data['stok_adi']        ?? '')
        . '&firma_kodu=15601'
        . '&firma_adi='      . urlencode('Poliza A.S')
        . '&uretim_tarihi='  . urlencode($data['uretim_tarihi']   ?? date('Y-m-d'))
        . '&operator_kodu='  . urlencode($data['calisan']         ?? '')
        . '&miktar='         . urlencode((string)$miktar)
        . '&lot_no='         . urlencode($paket_no)
        . '&etiket_turu=URETIM';

    $response = [
        'success'    => true,
        'message'    => 'Üretim girişi başarıyla kaydedildi.',
        'paket_no'   => $paket_no,
        'etiket_url' => $etiket_url,
    ];

} catch (Throwable $e) {
    $response = ['success' => false, 'message' => $e->getMessage()];
    error_log("[uretim_giris] HATA: " . $e->getMessage());
}

ob_clean();
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
