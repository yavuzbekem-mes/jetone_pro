<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<script>history.back();</script>'; exit; }

try {
    $db->prepare("DELETE FROM kalip_degisim WHERE kalip_id=?")->execute([$id]);
} catch (Throwable $e) {}
echo '<script>location.href="'.BASE_URL.'/panel.php?sayfa=uretim-kalip-devam&durum=ok";</script>';
exit;
