<?php
/**
 * Logo REST API — Token Yönetimi
 * include edildiğinde $GLOBALS['API_TOKEN'] set edilir.
 */

if (!class_exists('Global_Rest')) {
    class Global_Rest {
        public static $g_URL        = "http://192.168.1.100:32001/api/v1/";
        public static $g_UserName   = "ARS";
        public static $g_UserPass   = "qazwsx123";
        public static $g_FirmNr     = "222";
        public static $clientId     = "ARS";
        public static $clientSecret = "0fQYNl3QTZvTzOD41M8Ee58NQI3Gq+2l3x5FAoQM7Kc=";

        public static function GetToken(): string {
            $url  = self::$g_URL . "token";
            $data = [
                "username"      => self::$g_UserName,
                "password"      => self::$g_UserPass,
                "grant_type"    => "password",
                "firmno"        => self::$g_FirmNr,
                "client_id"     => self::$clientId,
                "client_secret" => self::$clientSecret,
            ];
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_POST           => 1,
                CURLOPT_POSTFIELDS     => http_build_query($data),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT        => 15,
                // VERBOSE KAPALI — HTML output engellenir
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr  = curl_error($ch);
            curl_close($ch);

            if ($curlErr) throw new Exception("cURL: $curlErr");
            if ($httpCode >= 400) throw new Exception("HTTP $httpCode: $response");

            $result = json_decode($response, true);
            if (empty($result['access_token'])) {
                throw new Exception("access_token yok. Yanıt: $response");
            }
            return $result['access_token'];
        }
    }
}

// mes_pdo yoksa yükle
if (!isset($mes_pdo) || !($mes_pdo instanceof PDO)) {
    $baglanlogo = dirname(__DIR__, 2) . '/core/baglanlogo.php';
    if (file_exists($baglanlogo)) {
        require_once $baglanlogo;
    }
}

// Token al/yükle — hata çıktıya yazılmaz, sadece loglanır
if (empty($GLOBALS['API_TOKEN'])) {
    try {
        if (isset($mes_pdo) && $mes_pdo instanceof PDO) {
            $st = $mes_pdo->prepare(
                "SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR
                 WHERE DATEDIFF(day, TARIH, GETDATE()) = 0
                 ORDER BY ID DESC"
            );
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC);

            if ($row && !empty($row['TOKEN'])) {
                $GLOBALS['API_TOKEN'] = $row['TOKEN'];
            } else {
                $token = Global_Rest::GetToken();
                $ins = $mes_pdo->prepare(
                    "INSERT INTO REST_SERVIS_KAYITLAR (TOKEN, TARIH) VALUES (?, GETDATE())"
                );
                $ins->execute([$token]);
                $GLOBALS['API_TOKEN'] = $token;
            }
        } else {
            $GLOBALS['API_TOKEN'] = Global_Rest::GetToken();
        }
    } catch (Exception $e) {
        error_log("[TOKEN] " . $e->getMessage());
    }
}
