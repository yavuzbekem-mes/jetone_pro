<?php
ob_start();
session_start();
header('Content-Type: application/json; charset=utf-8');

try {
    require_once dirname(__DIR__, 2) . '/core/baglanlogo.php';

    if (!isset($tigerdb_pdo)) throw new Exception('tigerdb_pdo yok');

    $uretim_no = trim($_GET['uretim_no'] ?? '');
    if (!$uretim_no) throw new Exception('Üretim numarası eksik');

    $ps = $tigerdb_pdo->prepare("SELECT LOGICALREF FROM LG_222_PRODORD WHERE FICHENO=?");
    $ps->execute([$uretim_no]);
    $pro = $ps->fetch(PDO::FETCH_ASSOC);

    if (!$pro) {
        ob_end_clean();
        echo json_encode(['success'=>false,'message'=>'Üretim emri bulunamadı'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $ref = (int)$pro['LOGICALREF'];

    $sql = "SELECT
        STF.FICHENO AS [FIS NO],
        STL.DATE_ AS [FIS TARIHI],
        CASE STL.TRCODE
            WHEN 11 THEN 'FIRE'
            WHEN 12 THEN 'SARF'
            WHEN 13 THEN 'URETIM'
            ELSE 'DIGER'
        END AS [FIS TURU],
        ITM.CODE AS [MALZEME KODU],
        ITM.NAME AS [MALZEME ADI],
        UNI.CODE AS BIRIM,
        CASE
            WHEN STL.UINFO1=0 THEN STL.AMOUNT
            ELSE STL.AMOUNT * STL.UINFO2 / STL.UINFO1
        END AS MIKTAR
    FROM LG_222_02_STLINE STL
    LEFT JOIN LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
    LEFT JOIN LG_222_ITEMS ITM ON ITM.LOGICALREF=STL.STOCKREF
    LEFT JOIN LG_222_UNITSETL UNI ON UNI.UNITSETREF=STL.USREF AND UNI.LINENR=1
    WHERE STL.TRCODE IN (11,12,13)
      AND STL.PRODORDERREF=?
      AND STL.LPRODSTAT=0
      AND STF.CANCELLED=0
    ORDER BY STL.DATE_ DESC, STL.TRCODE";

    $st = $tigerdb_pdo->prepare($sql);
    $st->execute([$ref]);
    $fisler = $st->fetchAll(PDO::FETCH_ASSOC);

    foreach ($fisler as &$f) {
        if (!empty($f['FIS TARIHI'])) {
            try { $f['FIS_TARIHI'] = (new DateTime($f['FIS TARIHI']))->format('d.m.Y H:i'); }
            catch(Exception $e) { $f['FIS_TARIHI'] = '-'; }
        } else { $f['FIS_TARIHI'] = '-'; }

        $birim  = strtoupper(trim($f['BIRIM'] ?? ''));
        $miktar = floatval($f['MIKTAR'] ?? 0);
        $f['MIKTAR_FORMATTED'] = $birim==='KG'
            ? number_format($miktar,4,',','.')
            : number_format($miktar,0,',','.');
        $f['MIKTAR_RAW']    = $miktar;
        $f['FIS_NO']        = $f['FIS NO']        ?? '';
        $f['FIS_TURU']      = $f['FIS TURU']      ?? '';
        $f['MALZEME_KODU']  = $f['MALZEME KODU']  ?? '';
        $f['MALZEME_ADI']   = $f['MALZEME ADI']   ?? '';
        unset($f['FIS NO'],$f['FIS TURU'],$f['MALZEME KODU'],$f['MALZEME ADI']);
    }
    unset($f);

    ob_end_clean();
    echo json_encode(['success'=>true,'fisler'=>$fisler,'toplam'=>count($fisler)], JSON_UNESCAPED_UNICODE);

} catch(PDOException $e) {
    ob_end_clean();
    echo json_encode(['success'=>false,'message'=>'DB: '.$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()], JSON_UNESCAPED_UNICODE);
} catch(Exception $e) {
    ob_end_clean();
    echo json_encode(['success'=>false,'message'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()], JSON_UNESCAPED_UNICODE);
}
