<?php
ini_set('display_errors',0); error_reporting(0);
while(ob_get_level()>0) ob_end_clean();
require_once dirname(__DIR__,2).'/core/config.php';
require_once dirname(__DIR__,2).'/core/baglanlogo.php';
require_once dirname(__DIR__,2).'/core/auth.php';
while(ob_get_level()>0) ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum gecersiz']); exit; }

$kul = Auth::kullanici();
$kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

$raw = json_decode(file_get_contents('php://input'),true)?:$_POST;
$kayit_tipi    = trim($raw['kayit_tipi']     ?? '1K');
$uretim_emri   = trim($raw['uretim_emri_no'] ?? '');
$paket_no      = trim($raw['paket_no']       ?? '');
$stok_kodu     = trim($raw['stok_kodu']      ?? '');
$stok_adi      = trim($raw['stok_adi']       ?? '');
$miktar        = (float)($raw['miktar']      ?? 0);
$iptal_nedeni  = trim($raw['iptal_nedeni']   ?? '');
$mes_kayit_id  = (int)($raw['mes_kayit_id']  ?? 0);
$logo_fis_no   = trim($raw['logo_fis_no']    ?? '');

if(!$uretim_emri || !$iptal_nedeni){
    echo json_encode(['success'=>false,'message'=>'Üretim emri ve iptal nedeni zorunlu']); exit;
}

try {
    // Talep no üret: IT-20260428-0001
    $tarih_k = date('Ymd');
    $say_r = $db->query("SELECT COUNT(*)+1 FROM iptal_talepler WHERE DATE(talep_tarihi)=CURDATE()");
    $sira = str_pad($say_r->fetchColumn(), 4, '0', STR_PAD_LEFT);
    $talep_no = "IT-$tarih_k-$sira";

    $db->prepare(
        "INSERT INTO iptal_talepler
         (talep_no,kayit_tipi,uretim_emri_no,paket_no,stok_kodu,stok_adi,
          miktar,iptal_nedeni,durum,talep_eden,talep_tarihi,mes_kayit_id,logo_fis_no)
         VALUES(?,?,?,?,?,?,?,?,'BEKLIYOR',?,NOW(),?,?)"
    )->execute([$talep_no,$kayit_tipi,$uretim_emri,$paket_no,$stok_kodu,$stok_adi,
                $miktar,$iptal_nedeni,$kul_adi,$mes_kayit_id,$logo_fis_no]);
    $talep_id = (int)$db->lastInsertId();

    // Log
    $db->prepare("INSERT INTO iptal_log(talep_id,islem,kullanici,detay) VALUES(?,?,?,?)")
       ->execute([$talep_id,'TALEP_OLUSTUR',$kul_adi,"$kayit_tipi | $uretim_emri | $paket_no | $iptal_nedeni"]);

    echo json_encode(['success'=>true,'message'=>"İptal talebi oluşturuldu: $talep_no",'talep_no'=>$talep_no],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
