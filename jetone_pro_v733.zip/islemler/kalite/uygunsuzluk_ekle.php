<?php
/**
 * JETONE.PRO — Uygunsuzluk Ekle + Mail
 * islemler/kalite/uygunsuzluk_ekle.php
 * config.php:71'de echo var — header() kullanma, JS redirect kullan
 */
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

if (!isset($_POST['uygunsuzluk_ekle'])) {
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste";</script>'; exit;
}

$kul = Auth::kullanici();

function n($k) { $v = trim($_POST[$k] ?? ''); return $v !== '' ? $v : null; }
function nd($k) { $v = trim($_POST[$k] ?? ''); return ($v !== '' && $v !== '0000-00-00') ? $v : null; }

$zorunlular = ['takip_no', 'tespit_tarihi', 'uygunsuzluk_yeri', 'uygunsuzluk_sebebi', 'hatali_miktar'];
foreach ($zorunlular as $z) {
    if (empty(trim($_POST[$z] ?? ''))) {
        echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-formu&hata=zorunlu";</script>'; exit;
    }
}

// Görsel yükleme
$gorsel_path = null;
if (!empty($_FILES['uygunsuzluk_gorsel']['name']) && $_FILES['uygunsuzluk_gorsel']['error'] === 0) {
    $dir = $root . '/kys_dokumanlar/uygunsuzluk/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $ext = strtolower(pathinfo($_FILES['uygunsuzluk_gorsel']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-formu&hata=dosya";</script>'; exit;
    }
    if ($_FILES['uygunsuzluk_gorsel']['size'] > 5_000_000) {
        echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-formu&hata=boyut";</script>'; exit;
    }
    $fname = 'uyg_' . date('Ymd_His') . '_' . uniqid() . '.' . $ext;
    if (move_uploaded_file($_FILES['uygunsuzluk_gorsel']['tmp_name'], $dir . $fname)) {
        $gorsel_path = $fname;
    }
}

try {
    $db->prepare("INSERT INTO uygunsuzluk
        (takip_no, tespit_eden_kisi, tespit_tarihi, vardiya, uygunsuzluk_yeri,
         malzeme_adi, malzeme_kodu, malzeme_giris_tarihi, uretim_miktar,
         tedarikci_firma, proses_adi, irsaliye_no, hatali_miktar, uygunsuzluk_sebebi,
         uygunsuzluk_gorsel, kalite_sorumlu, kalite_mudur, uretim_mudur, kayit_tarihi)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())")
    ->execute([
        n('takip_no'), n('tespit_eden_kisi'), nd('tespit_tarihi'), n('vardiya'), n('uygunsuzluk_yeri'),
        n('malzeme_adi'), n('malzeme_kodu'), nd('malzeme_giris_tarihi'), n('uretim_miktar'),
        n('tedarikci_firma'), n('proses_adi'), n('irsaliye_no'), n('hatali_miktar'), n('uygunsuzluk_sebebi'),
        $gorsel_path, n('kalite_sorumlu'), n('kalite_mudur'), n('uretim_mudur'),
    ]);

    $insert_id = $db->lastInsertId();

    // Mail gönder
    $mail_ok = false;
    $phpmailer_path = $root . '/core/class.phpmailer.php';
    if (file_exists($phpmailer_path)) {
        try {
            require_once $phpmailer_path;
            $mail = new PHPMailer();
            $mail->CharSet   = 'UTF-8';
            $mail->IsSMTP();
            $mail->Host      = 'smtp.yandex.com';
            $mail->Port      = 465;
            $mail->SMTPSecure= 'ssl';
            $mail->SMTPAuth  = true;
            $mail->Username  = 'planlama@poliza.com.tr';
            $mail->Password  = 'Yb59Pol*';
            $mail->SMTPDebug = 0;
            $mail->From      = 'planlama@poliza.com.tr';
            $mail->FromName  = 'Uygunsuzluk Formu';
            $mail->Subject   = n('takip_no') . ' — ' . date('d.m.Y') . ' Uygunsuzluk Formu';

            $alicilar = ['planlama@poliza.com.tr','bulent.colak@poliza.com.tr',
                         'kaliteguvence@poliza.com.tr','tarkan.aslan@poliza.com.tr','uretim@poliza.com.tr'];
            foreach ($alicilar as $a) $mail->AddAddress($a);

            if ($gorsel_path && file_exists($root . '/kys_dokumanlar/uygunsuzluk/' . $gorsel_path)) {
                $mail->AddEmbeddedImage($root . '/kys_dokumanlar/uygunsuzluk/' . $gorsel_path, 'uyg_gorsel', $gorsel_path);
            }

            // Mail içeriği — basit HTML tablo
            $yer_map = ['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'];
            $yer = $yer_map[n('uygunsuzluk_yeri')] ?? n('uygunsuzluk_yeri');
            $html = '<html><body style="font-family:Arial;background:#f5f5f5;padding:20px">
<div style="max-width:700px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e5e7eb">
<div style="background:#1E3A5F;color:#fff;padding:16px 20px;font-size:16px;font-weight:800">UYGUNSUZLUK FORMU — ' . htmlspecialchars(n('takip_no')) . '</div>
<table style="width:100%;border-collapse:collapse;font-size:13px">
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb;width:35%">Takip No</td><td style="padding:8px 12px;border:1px solid #e5e7eb;font-family:monospace;font-weight:800">' . htmlspecialchars(n('takip_no')) . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Tespit Tarihi</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . (nd('tespit_tarihi') ? date('d.m.Y', strtotime(nd('tespit_tarihi'))) : '—') . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Tespit Eden</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . htmlspecialchars(n('tespit_eden_kisi') ?? '') . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Uygunsuzluk Yeri</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . htmlspecialchars($yer ?? '') . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Malzeme</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . htmlspecialchars(n('malzeme_adi') ?? '') . ' (' . htmlspecialchars(n('malzeme_kodu') ?? '') . ')</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Tedarikçi</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . htmlspecialchars(n('tedarikci_firma') ?? '') . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Hatalı Miktar</td><td style="padding:8px 12px;border:1px solid #e5e7eb">' . htmlspecialchars(n('hatali_miktar') ?? '') . '</td></tr>
<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Uygunsuzluk Sebebi</td><td style="padding:8px 12px;border:1px solid #e5e7eb;white-space:pre-wrap">' . htmlspecialchars(n('uygunsuzluk_sebebi') ?? '') . '</td></tr>
' . ($gorsel_path ? '<tr><td style="background:#f1f5f9;padding:8px 12px;font-weight:700;border:1px solid #e5e7eb">Görsel</td><td style="padding:8px 12px;border:1px solid #e5e7eb"><img src="cid:uyg_gorsel" style="max-width:300px"></td></tr>' : '') . '
</table>
<div style="padding:14px 20px;font-size:11px;color:#888;border-top:1px solid #e5e7eb;text-align:center">DOKÜMAN NO: FR.06 | REV: 02 | 04.07.2024</div>
</div></body></html>';

            $mail->MsgHTML($html);
            $mail_ok = $mail->Send();
        } catch (Throwable $me) { error_log('Uygunsuzluk mail hatası: ' . $me->getMessage()); }
    }

    $durum = $mail_ok ? 'mailok' : 'ok';
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=' . $durum . '";</script>';

} catch (Throwable $e) {
    error_log('Uygunsuzluk ekle hatası: ' . $e->getMessage());
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-formu&hata=db";</script>';
}
exit;
