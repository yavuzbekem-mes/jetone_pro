<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();
header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

try {
    $limit = (int)($_GET['limit'] ?? 10);
    $limit = min($limit, 200);
    $rows = $db->query("SELECT * FROM hortum_test_kayit ORDER BY id DESC LIMIT $limit")->fetchAll(PDO::FETCH_ASSOC);
    exit(json_encode(['ok'=>true,'data'=>$rows]));
} catch (Throwable $e) {
    exit(json_encode(['ok'=>false,'data'=>[],'msg'=>$e->getMessage()]));
}
