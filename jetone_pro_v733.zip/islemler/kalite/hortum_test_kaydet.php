<?php
/**
 * Hortum test sonucunu DB'ye kaydet
 * POST JSON: { recete_adi, operator, test_baslangic, test_bitis, sure_sn,
 *   asama1: {sonuc,hedef_bar,dusus_bar,sure_sn},
 *   asama2: {sonuc,akis_ldk,min_akis,sure_sn},
 *   genel_sonuc, piston_durum }
 */
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

$d = json_decode(file_get_contents('php://input'), true);
if (!$d) { exit(json_encode(['ok'=>false,'msg'=>'Veri yok'])); }

function n($v,$def=null){ return isset($v)&&$v!==''?$v:$def; }

try {
    $db->prepare("INSERT INTO hortum_test_kayit
        (recete_adi,operatör,test_baslangic,test_bitis,sure_sn,
         asama1_sonuc,asama1_hedef_bar,asama1_dusus_bar,asama1_sure_sn,
         asama2_sonuc,asama2_akis_ldk,asama2_min_akis,asama2_sure_sn,
         genel_sonuc,piston_durum)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    ->execute([
        n($d['recete_adi'],'Bilinmiyor'),
        n($d['operator'],'Anonim'),
        n($d['test_baslangic'],date('Y-m-d H:i:s')),
        n($d['test_bitis'],date('Y-m-d H:i:s')),
        (int)n($d['sure_sn'],0),
        isset($d['asama1']['sonuc']) ? (int)$d['asama1']['sonuc'] : null,
        n($d['asama1']['hedef_bar'] ?? null),
        n($d['asama1']['dusus_bar'] ?? null),
        n($d['asama1']['sure_sn']   ?? null),
        isset($d['asama2']['sonuc']) ? (int)$d['asama2']['sonuc'] : null,
        n($d['asama2']['akis_ldk']  ?? null),
        n($d['asama2']['min_akis']  ?? null),
        n($d['asama2']['sure_sn']   ?? null),
        (int)n($d['genel_sonuc'],0),
        n($d['piston_durum'],'BILINMIYOR'),
    ]);
    exit(json_encode(['ok'=>true,'id'=>(int)$db->lastInsertId()]));
} catch (Throwable $e) {
    exit(json_encode(['ok'=>false,'msg'=>$e->getMessage()]));
}
