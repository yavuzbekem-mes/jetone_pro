<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

$cihaz_id = (int)($_POST['cihaz_id'] ?? 0);
if (!$cihaz_id) { echo '<script>history.back();</script>'; exit; }
function n($k){ $v=trim($_POST[$k]??''); return $v!==''?$v:null; }
function nd($k){ $v=trim($_POST[$k]??''); return ($v!==''&&$v!=='0000-00-00')?$v:null; }

$ekleyen = $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem';
$kal_tarih = nd('kalibrasyon_tarihi') ?? date('Y-m-d');
$sonraki   = nd('sonraki_tarih');

// Sertifika yükle
$sertifika_dosya = null;
if (!empty($_FILES['sertifika']['name']) && $_FILES['sertifika']['error'] === 0) {
    $dir = $root . '/kys_dökümanlar/kalibrasyon/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $ext = strtolower(pathinfo($_FILES['sertifika']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, ['pdf','jpg','jpeg','png','webp']) && $_FILES['sertifika']['size'] <= 10_000_000) {
        $fname = 'cert_' . $cihaz_id . '_' . date('Ymd_His') . '_' . uniqid() . '.' . $ext;
        if (move_uploaded_file($_FILES['sertifika']['tmp_name'], $dir . $fname)) {
            $sertifika_dosya = $fname;
        }
    }
}

try {
    $db->prepare("INSERT INTO kalibrasyon_kayitlar (cihaz_id,kalibrasyon_tarihi,sonraki_tarih,yapan_firma,degerlendirme,durum,sertifika_dosya,aciklama,ekleyen)
        VALUES (?,?,?,?,?,?,?,?,?)")
    ->execute([$cihaz_id,$kal_tarih,$sonraki,n('yapan_firma'),n('degerlendirme'),n('durum')??'OKEY',$sertifika_dosya,n('aciklama'),$ekleyen]);

    // Cihaz tablosunu da güncelle
    $db->prepare("UPDATE kalibrasyon_cihazlar SET son_kalibrasyon=?, sonraki_kalibrasyon=?,
        yapan_firma=COALESCE(?,yapan_firma), degerlendirme=COALESCE(?,degerlendirme), durum=? WHERE id=?")
    ->execute([$kal_tarih,$sonraki,n('yapan_firma'),n('degerlendirme'),n('durum')??'OKEY',$cihaz_id]);

    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-kalibrasyon-detay&id=' . $cihaz_id . '&durum=ok";</script>';
} catch (Throwable $e) {
    error_log('kalibrasyon_kayit_kaydet: '.$e->getMessage());
    echo '<script>history.back();</script>';
}
exit;
