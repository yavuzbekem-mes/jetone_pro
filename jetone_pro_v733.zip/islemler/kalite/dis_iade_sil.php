<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

$data = json_decode(file_get_contents('php://input'), true);
$id   = (int)($data['id'] ?? 0);
if (!$id) { exit(json_encode(['status'=>'error','message'=>'ID gerekli.'])); }

try {
    $db->prepare("DELETE FROM dis_iade_kontrol_listesi WHERE id=?")->execute([$id]);
    exit(json_encode(['status'=>'success']));
} catch (Throwable $e) {
    exit(json_encode(['status'=>'error','message'=>$e->getMessage()]));
}
