<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id  = (int)($_POST['id'] ?? 0);
$tur = trim($_POST['tur'] ?? 'formlar');
if (!$id) { echo '<script>history.back();</script>'; exit; }

try {
    $db->prepare("DELETE FROM dokuman_listesi WHERE id=?")->execute([$id]);
} catch (Throwable $e) {}
echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-dokuman-listesi&kategori=' . urlencode($tur) . '&durum=ok";</script>';
exit;
