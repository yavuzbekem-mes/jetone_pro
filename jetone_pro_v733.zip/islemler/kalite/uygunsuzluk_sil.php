<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_POST['id'] ?? 0);
if (!$id) { echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=no";</script>'; exit; }

try {
    // Görseli sil
    $gorsel = $db->prepare("SELECT uygunsuzluk_gorsel FROM uygunsuzluk WHERE id=?");
    $gorsel->execute([$id]);
    $g = $gorsel->fetchColumn();
    if ($g) { $yol = $root . '/kys_dokumanlar/uygunsuzluk/' . $g; if (file_exists($yol)) unlink($yol); }
    $db->prepare("DELETE FROM uygunsuzluk WHERE id=?")->execute([$id]);
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=silindi";</script>';
} catch (Throwable $e) {
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=no";</script>';
}
exit;
