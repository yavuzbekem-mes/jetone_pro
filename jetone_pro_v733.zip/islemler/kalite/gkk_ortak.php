<?php
/**
 * GKK Ortak fonksiyonlar
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo)) require_once ROOT_DIR.'/core/baglanlogo.php';

// Tablo oluştur
function gkk_tablo_olustur($db) {
    $db->exec("CREATE TABLE IF NOT EXISTS gkk_kontrol_sonuclari (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        fis_id          INT NOT NULL,
        irsaliye_no     VARCHAR(50) NOT NULL,
        satir_id        INT NOT NULL,
        stok_kodu       VARCHAR(50) NOT NULL,
        stok_adi        VARCHAR(255) DEFAULT '',
        miktar          DECIMAL(15,4) DEFAULT 0,
        birim           VARCHAR(20) DEFAULT '',
        sonuc           ENUM('ONAY','SART_ONAY','RED') NOT NULL,
        aciklama        TEXT,
        kontrol_adet    INT DEFAULT 0,
        hata_adet       INT DEFAULT 0,
        logo_fis_no     VARCHAR(50) DEFAULT '',
        kontrol_eden    VARCHAR(100) DEFAULT '',
        kontrol_tarihi  DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_fis (fis_id),
        INDEX idx_irsno (irsaliye_no),
        INDEX idx_stok (stok_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Mevcut tabloya kolonları ekle (varsa hata vermez)
    try { $db->exec("ALTER TABLE gkk_kontrol_sonuclari ADD COLUMN IF NOT EXISTS kontrol_adet INT DEFAULT 0"); } catch(Throwable $e){}
    try { $db->exec("ALTER TABLE gkk_kontrol_sonuclari ADD COLUMN IF NOT EXISTS hata_adet    INT DEFAULT 0"); } catch(Throwable $e){}
}

function etiketAlindiMi_GKK($fis_id, $satir_id, $tigerdb_pdo, $mes_pdo) {
    try {
        $st = $tigerdb_pdo->prepare("SELECT IRSALIYE_NO, STOK_KODU FROM MES_SATINALMA WHERE FIS_ID=? AND SATIR_ID=?");
        $st->execute([$fis_id, $satir_id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if(!$r) return false;
        $st2 = $mes_pdo->prepare("SELECT COUNT(*) FROM dbo.PAKETLER WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=0");
        $st2->execute([trim($r['IRSALIYE_NO']), trim($r['STOK_KODU'])]);
        return (int)$st2->fetchColumn() > 0;
    } catch(Throwable $e) { return false; }
}

function gkkSonucuVar($fis_id, $satir_id, $db) {
    try {
        $st = $db->prepare("SELECT id, sonuc, aciklama, kontrol_adet, hata_adet, logo_fis_no, kontrol_eden, kontrol_tarihi FROM gkk_kontrol_sonuclari WHERE fis_id=? AND satir_id=? LIMIT 1");
        $st->execute([$fis_id, $satir_id]);
        return $st->fetch(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { return false; }
}

function tedarikciEmail($cari_unvani, $db) {
    try {
        $st = $db->prepare("SELECT ilgili_kisi_mail FROM tedarikci_bilgileri WHERE tedarikci_adi LIKE ? AND ilgili_kisi_mail IS NOT NULL AND ilgili_kisi_mail != '' LIMIT 5");
        $st->execute(['%'.$cari_unvani.'%']);
        $rows = $st->fetchAll(PDO::FETCH_COLUMN);
        return array_filter($rows, fn($m) => filter_var(trim($m), FILTER_VALIDATE_EMAIL));
    } catch(Throwable $e) { return []; }
}
