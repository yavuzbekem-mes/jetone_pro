<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id  = (int)($_POST['id'] ?? 0);
$tur = trim($_POST['tur'] ?? 'formlar');
if (!$id) { echo '<script>history.back();</script>'; exit; }

$dok_yol = null;
if (!empty($_FILES['dok_yol']['name']) && $_FILES['dok_yol']['error'] === 0) {
    $dir = $root . '/kys_dökümanlar/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $fname = rand(10000,99999).rand(10000,99999).preg_replace('/[^a-zA-Z0-9._\-]/','',$_FILES['dok_yol']['name']);
    if (move_uploaded_file($_FILES['dok_yol']['tmp_name'], $dir . $fname)) {
        $dok_yol = 'kys_dökümanlar/' . $fname;
    }
}

if ($dok_yol) {
    try {
        $db->prepare("UPDATE dokuman_listesi SET dok_yol=? WHERE id=?")->execute([$dok_yol,$id]);
    } catch (Throwable $e) { error_log('dokuman_yol: '.$e->getMessage()); }
}
echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-dokuman-duzenle&id=' . $id . '";</script>';
exit;
