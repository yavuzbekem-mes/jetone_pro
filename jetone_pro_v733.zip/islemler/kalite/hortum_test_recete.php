<?php
/** Reçete CRUD (GET: liste, POST: ekle/güncelle) */
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();
header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

// DB tabloları yoksa oluştur
try { $db->exec(file_get_contents($root.'/hortum_test.sql')); } catch (Throwable $e) {}

$met = $_SERVER['REQUEST_METHOD'];
if ($met === 'GET') {
    $rows = $db->query("SELECT * FROM hortum_test_recete WHERE aktif=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    exit(json_encode(['ok'=>true,'data'=>$rows]));
}
$d = json_decode(file_get_contents('php://input'),true) ?? $_POST;
$act = $d['action'] ?? 'save';
if ($act === 'delete') {
    $db->prepare("UPDATE hortum_test_recete SET aktif=0 WHERE id=?")->execute([(int)$d['id']]);
    exit(json_encode(['ok'=>true]));
}
if (!empty($d['id'])) {
    $db->prepare("UPDATE hortum_test_recete SET recete_adi=?,hedef_basinc=?,kacak_esigi=?,bekle_sure=?,min_akis=?,stabilize_sure=? WHERE id=?")
    ->execute([$d['recete_adi'],$d['hedef_basinc'],$d['kacak_esigi'],$d['bekle_sure'],$d['min_akis'],$d['stabilize_sure'],(int)$d['id']]);
} else {
    $db->prepare("INSERT INTO hortum_test_recete (recete_adi,hedef_basinc,kacak_esigi,bekle_sure,min_akis,stabilize_sure) VALUES (?,?,?,?,?,?)")
    ->execute([$d['recete_adi'],$d['hedef_basinc'],$d['kacak_esigi'],$d['bekle_sure'],$d['min_akis'],$d['stabilize_sure']]);
    $d['id'] = $db->lastInsertId();
}
exit(json_encode(['ok'=>true,'id'=>(int)$d['id']]));
