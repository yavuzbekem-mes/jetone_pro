<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

if (!isset($_POST['uygunsuzluk_guncelle'])) {
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste";</script>'; exit;
}

$id = (int)($_POST['id'] ?? 0);
if (!$id) { echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=no";</script>'; exit; }

function n($k){ $v=trim($_POST[$k]??''); return $v!==''?$v:null; }
function nd($k){ $v=trim($_POST[$k]??''); return ($v!==''&&$v!=='0000-00-00')?$v:null; }

$data = [
    'degerlendirme_sonucu' => n('degerlendirme_sonucu'),
    'degerlendirme_tarihi' => nd('degerlendirme_tarihi'),
    'karar'                => n('karar'),
    'duzeltici_faaliyet'   => n('duzeltici'),
    'df_no'                => n('df_no'),
    'df_hedef_tarih'       => nd('df_hedef_tarih'),
    'sekizd_no'            => n('sekizd_no'),
    'sekizd_hedef_tarih'   => nd('sekizd_hedef_tarih'),
    'kalite_sorumlu'       => n('kalite_sorumlu'),
    'kalite_mudur'         => n('kalite_mudur'),
    'uretim_mudur'         => n('uretim_mudur'),
];

// Görsel güncelleme
if (!empty($_FILES['uygunsuzluk_gorsel']['name']) && $_FILES['uygunsuzluk_gorsel']['error'] === 0) {
    $dir = $root . '/kys_dokumanlar/uygunsuzluk/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $ext = strtolower(pathinfo($_FILES['uygunsuzluk_gorsel']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        $fname = 'uyg_' . date('Ymd_His') . '_' . uniqid() . '.' . $ext;
        if (move_uploaded_file($_FILES['uygunsuzluk_gorsel']['tmp_name'], $dir . $fname)) {
            // Eski görseli sil
            try {
                $eski = $db->prepare("SELECT uygunsuzluk_gorsel FROM uygunsuzluk WHERE id=?")->execute([$id]);
                $eski_dosya = $db->query("SELECT uygunsuzluk_gorsel FROM uygunsuzluk WHERE id=$id")->fetchColumn();
                if ($eski_dosya && file_exists($dir . $eski_dosya)) unlink($dir . $eski_dosya);
            } catch (Throwable $e) {}
            $data['uygunsuzluk_gorsel'] = $fname;
        }
    }
}

try {
    $set = implode(' = ?, ', array_keys($data)) . ' = ?';
    $vals = array_values($data);
    $vals[] = $id;
    $db->prepare("UPDATE uygunsuzluk SET $set WHERE id=?")->execute($vals);
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-liste&durum=ok";</script>';
} catch (Throwable $e) {
    error_log('Uygunsuzluk güncelle hatası: ' . $e->getMessage());
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-uygunsuzluk-duzenle&id=' . $id . '&durum=no";</script>';
}
exit;
