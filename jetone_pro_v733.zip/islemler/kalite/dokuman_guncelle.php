<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id  = (int)($_POST['id'] ?? 0);
$tur = trim($_POST['tur'] ?? 'formlar');
if (!$id) { echo '<script>history.back();</script>'; exit; }

function n($k){ $v=trim($_POST[$k]??''); return $v!==''?$v:null; }
function nd($k){ $v=trim($_POST[$k]??''); return ($v!==''&&$v!=='0000-00-00')?$v:null; }

// Dosya yönetimi: yeni dosya yüklendiyse kaydet, yoksa mevcut yolu koru
$mevcut_yol = trim($_POST['mevcut_dok_yol'] ?? '');
$dok_yol    = $mevcut_yol ?: null; // varsayılan: mevcut

if (!empty($_FILES['dok_yol']['name']) && $_FILES['dok_yol']['error'] === 0) {
    $dir = $root . '/kys_dökümanlar/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $fname = rand(10000,99999).rand(10000,99999)
           . preg_replace('/[^a-zA-Z0-9._\-]/', '', $_FILES['dok_yol']['name']);
    if (move_uploaded_file($_FILES['dok_yol']['tmp_name'], $dir . $fname)) {
        $dok_yol = 'kys_dökümanlar/' . $fname;
    }
}

try {
    $db->prepare("UPDATE dokuman_listesi
        SET tür=?, dok_adi=?, ref_madde=?, dok_no=?, revize_no=?, durum=?,
            revize_tarih=?, revize_eden=?, dok_yol=?
        WHERE id=?")
    ->execute([
        $tur, n('dok_adi'), n('ref_madde'), n('dok_no'), n('revize_no'),
        n('durum') ?? 'Aktif', nd('revize_tarih'), n('revize_eden'),
        $dok_yol, $id,
    ]);
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-dokuman-duzenle&id=' . $id . '&durum=ok";</script>';
} catch (Throwable $e) {
    error_log('dokuman_guncelle: ' . $e->getMessage());
    echo '<script>history.back();</script>';
}
exit;
