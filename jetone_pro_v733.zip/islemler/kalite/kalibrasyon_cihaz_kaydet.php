<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_POST['id'] ?? 0);
function n($k){ $v=trim($_POST[$k]??''); return $v!==''?$v:null; }
function nd($k){ $v=trim($_POST[$k]??''); return ($v!==''&&$v!=='0000-00-00')?$v:null; }

if (!n('kayit_no') || !n('cihaz_adi')) {
    echo '<script>history.back();</script>'; exit;
}

$periyot = (int)($_POST['periyot_gun'] ?? 365);
$son     = nd('son_kalibrasyon');
$sonraki = nd('sonraki_kalibrasyon');
// Sonraki tarih otomatik hesapla (form'dan gelmediyse)
if ($son && !$sonraki) {
    $sonraki = date('Y-m-d', strtotime($son . ' + ' . $periyot . ' days'));
}

try {
    if ($id) {
        $db->prepare("UPDATE kalibrasyon_cihazlar SET cihaz_adi=?,marka_model=?,olcum_araligi=?,hassasiyet=?,
            kullanim_bolumu=?,periyot_gun=?,son_kalibrasyon=?,sonraki_kalibrasyon=?,yapan_firma=?,
            degerlendirme=?,durum=?,aciklama=? WHERE id=?")
        ->execute([n('cihaz_adi'),n('marka_model'),n('olcum_araligi'),n('hassasiyet'),
            n('kullanim_bolumu'),$periyot,$son,$sonraki,n('yapan_firma'),n('degerlendirme'),n('durum'),n('aciklama'),$id]);
    } else {
        $db->prepare("INSERT INTO kalibrasyon_cihazlar (kayit_no,cihaz_adi,marka_model,olcum_araligi,hassasiyet,
            kullanim_bolumu,periyot_gun,son_kalibrasyon,sonraki_kalibrasyon,yapan_firma,degerlendirme,durum,aciklama)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([n('kayit_no'),n('cihaz_adi'),n('marka_model'),n('olcum_araligi'),n('hassasiyet'),
            n('kullanim_bolumu'),$periyot,$son,$sonraki,n('yapan_firma'),n('degerlendirme'),n('durum')??'OKEY',n('aciklama')]);
    }
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-kalibrasyon-liste&durum=ok";</script>';
} catch (Throwable $e) {
    error_log('kalibrasyon_cihaz_kaydet: '.$e->getMessage());
    echo '<script>history.back();</script>';
}
exit;
