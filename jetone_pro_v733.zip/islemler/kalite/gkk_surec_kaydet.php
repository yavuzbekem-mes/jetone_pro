<?php
/**
 * GKK Süreç Kayıt & Güncelleme Endpoint
 * Tüm aşama geçişlerini ve log kayıtlarını yönetir
 */
ob_start();
ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum geçersiz']); exit; }
$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

global $db;

// Tabloları oluştur
$db->exec("CREATE TABLE IF NOT EXISTS gkk_red_surec (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gkk_id INT NOT NULL UNIQUE,
    irsaliye_no VARCHAR(50) NOT NULL,
    stok_kodu VARCHAR(50) NOT NULL,
    stok_adi VARCHAR(255) DEFAULT '',
    tedarikci_adi VARCHAR(255) DEFAULT '',
    tedarikci_kodu VARCHAR(50) DEFAULT '',
    miktar DECIMAL(15,4) DEFAULT 0,
    birim VARCHAR(20) DEFAULT 'ADET',
    red_tarihi DATETIME,
    red_aciklama TEXT,
    kontrol_eden VARCHAR(100) DEFAULT '',
    aksiyon_tipi ENUM('BEKLIYOR','IADE','AYIKLAMA','SART_ONAY','YENI_SEVKIYAT','DIGER') DEFAULT 'BEKLIYOR',
    asama ENUM('RED','TEDARIKCI_BILDIRIMI','TEDARIKCI_YANITI','AKSIYON_SECIMI','GERCEKLESMIS','KAPANDI') DEFAULT 'RED',
    bildirim_tarihi DATETIME,
    bildirim_yapan VARCHAR(100) DEFAULT '',
    tedarikci_yanit_tarihi DATETIME,
    tedarikci_yanit_notu TEXT,
    yeni_sevkiyat_tarihi DATE,
    gerceklesme_tarihi DATE,
    gerceklesme_notu TEXT,
    olusturan VARCHAR(100) DEFAULT '',
    olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_gkk(gkk_id), INDEX idx_asama(asama)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS gkk_red_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    surec_id INT NOT NULL,
    islem_tipi VARCHAR(50) NOT NULL,
    eski_asama VARCHAR(50) DEFAULT '',
    yeni_asama VARCHAR(50) DEFAULT '',
    aciklama TEXT,
    dosya_yolu VARCHAR(500) DEFAULT '',
    dosya_adi VARCHAR(255) DEFAULT '',
    yapan VARCHAR(100) DEFAULT '',
    tarih DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_surec(surec_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$action   = trim($_POST['action'] ?? $_GET['action'] ?? '');

// GET: log listesi
if($_SERVER['REQUEST_METHOD']==='GET' && isset($_GET['surec_id'])) {
    $sid = (int)$_GET['surec_id'];
    try {
        $ls = $db->prepare("SELECT * FROM gkk_red_log WHERE surec_id=? ORDER BY tarih DESC");
        $ls->execute([$sid]);
        echo json_encode(['success'=>true,'logs'=>$ls->fetchAll(PDO::FETCH_ASSOC),'surec_id'=>$sid]);
    } catch(Throwable $e){ echo json_encode(['success'=>true,'logs'=>[],'error'=>$e->getMessage()]); }
    exit;
}
$surec_id = (int)($_POST['surec_id'] ?? 0);
$gkk_id   = (int)($_POST['gkk_id'] ?? 0);

try {
    // Dosya yükle
    $dosya_yolu = ''; $dosya_adi = '';
    if(!empty($_FILES['belge']['name'])) {
        $ext = strtolower(pathinfo($_FILES['belge']['name'], PATHINFO_EXTENSION));
        if(in_array($ext,['pdf','jpg','jpeg','png','doc','docx','xls','xlsx'])) {
            $yeni_ad = 'gkk_'.$surec_id.'_'.time().'.'.$ext;
            $hedef   = ROOT_DIR.'/uploads/gkk_belgeler/'.$yeni_ad;
            if(move_uploaded_file($_FILES['belge']['tmp_name'], $hedef)) {
                $dosya_yolu = 'uploads/gkk_belgeler/'.$yeni_ad;
                $dosya_adi  = $_FILES['belge']['name'];
            }
        }
    }

    switch($action) {
        // ── GKK red kaydı oluşturulduğunda otomatik süreç başlat
        case 'surec_baslat':
            $gkk_row = $db->prepare("SELECT * FROM gkk_kontrol_sonuclari WHERE id=? AND sonuc='RED'");
            $gkk_row->execute([$gkk_id]);
            $gkk = $gkk_row->fetch(PDO::FETCH_ASSOC);
            if(!$gkk){ echo json_encode(['success'=>false,'message'=>'GKK kaydı bulunamadı']); exit; }

            $db->prepare("INSERT IGNORE INTO gkk_red_surec
                (gkk_id,irsaliye_no,stok_kodu,stok_adi,miktar,birim,red_tarihi,red_aciklama,kontrol_eden,olusturan)
                VALUES(?,?,?,?,?,?,?,?,?,?)")
               ->execute([$gkk_id,$gkk['irsaliye_no'],$gkk['stok_kodu'],$gkk['stok_adi'],
                          $gkk['miktar'],$gkk['birim'],$gkk['kontrol_tarihi'],
                          $gkk['aciklama']??'',$gkk['kontrol_eden'],$kul_adi]);
            $sid = $db->lastInsertId() ?: $db->query("SELECT id FROM gkk_red_surec WHERE gkk_id=$gkk_id")->fetchColumn();
            _log($db,$sid,'RED_OLUSTU','','RED','GKK red kararı ile süreç başlatıldı','',$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true,'surec_id'=>$sid]);
            exit;

        // ── Tedarikçi bildirimi yap
        case 'bildirim_yap':
            $aciklama = trim($_POST['aciklama']??'');
            $db->prepare("UPDATE gkk_red_surec SET asama='TEDARIKCI_BILDIRIMI',bildirim_tarihi=NOW(),bildirim_yapan=? WHERE id=?")
               ->execute([$kul_adi, $surec_id]);
            _log($db,$surec_id,'TEDARIKCI_BILDIRIMI','RED','TEDARIKCI_BILDIRIMI',$aciklama,$dosya_yolu,$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        // ── Tedarikçi yanıtı gir
        case 'tedarikci_yaniti':
            $yanit        = trim($_POST['yanit']??'');
            $sevk_tarihi  = trim($_POST['sevk_tarihi']??'') ?: null;
            $asama_once   = $db->query("SELECT asama FROM gkk_red_surec WHERE id=$surec_id")->fetchColumn();
            $db->prepare("UPDATE gkk_red_surec SET asama='TEDARIKCI_YANITI',tedarikci_yanit_tarihi=NOW(),tedarikci_yanit_notu=?,yeni_sevkiyat_tarihi=? WHERE id=?")
               ->execute([$yanit,$sevk_tarihi,$surec_id]);
            _log($db,$surec_id,'TEDARIKCI_YANITI',$asama_once,'TEDARIKCI_YANITI',$yanit,$dosya_yolu,$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        // ── Aksiyon seç (iade/ayıklama/şartlı/yeni sevkiyat vb.)
        case 'aksiyon_sec':
            $aksiyon_tipi = trim($_POST['aksiyon_tipi']??'BEKLIYOR');
            $aciklama     = trim($_POST['aciklama']??'');
            $asama_once   = $db->query("SELECT asama FROM gkk_red_surec WHERE id=$surec_id")->fetchColumn();
            $db->prepare("UPDATE gkk_red_surec SET asama='AKSIYON_SECIMI',aksiyon_tipi=? WHERE id=?")
               ->execute([$aksiyon_tipi,$surec_id]);
            _log($db,$surec_id,'AKSIYON_SECIMI',$asama_once,'AKSIYON_SECIMI',"Aksiyon: $aksiyon_tipi — $aciklama",$dosya_yolu,$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        // ── Gerçekleşme kaydet
        case 'gerceklesme':
            $not   = trim($_POST['not']??'');
            $tarih = trim($_POST['tarih']??'') ?: date('Y-m-d');
            $asama_once = $db->query("SELECT asama FROM gkk_red_surec WHERE id=$surec_id")->fetchColumn();
            $db->prepare("UPDATE gkk_red_surec SET asama='GERCEKLESMIS',gerceklesme_tarihi=?,gerceklesme_notu=? WHERE id=?")
               ->execute([$tarih,$not,$surec_id]);
            _log($db,$surec_id,'GERCEKLESME',$asama_once,'GERCEKLESMIS',$not,$dosya_yolu,$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        // ── Kapat
        case 'kapat':
            $not = trim($_POST['not']??'');
            $asama_once = $db->query("SELECT asama FROM gkk_red_surec WHERE id=$surec_id")->fetchColumn();
            $db->prepare("UPDATE gkk_red_surec SET asama='KAPANDI' WHERE id=?")
               ->execute([$surec_id]);
            _log($db,$surec_id,'KAPANDI',$asama_once,'KAPANDI',$not,'',$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        // ── Genel not ekle
        case 'not_ekle':
            $not = trim($_POST['not']??'');
            _log($db,$surec_id,'NOT','',$not,$not,$dosya_yolu,$dosya_adi,$kul_adi);
            echo json_encode(['success'=>true]);
            exit;

        default:
            echo json_encode(['success'=>false,'message'=>'Geçersiz action']);
    }
} catch(Throwable $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}

function _log($db,$surec_id,$islem,$eski,$yeni,$aciklama,$dosya_yolu,$dosya_adi,$yapan) {
    $db->prepare("INSERT INTO gkk_red_log (surec_id,islem_tipi,eski_asama,yeni_asama,aciklama,dosya_yolu,dosya_adi,yapan) VALUES(?,?,?,?,?,?,?,?)")
       ->execute([$surec_id,$islem,$eski,$yeni,$aciklama?:'',
                  $dosya_yolu?:'',$dosya_adi?:'',$yapan]);
}
