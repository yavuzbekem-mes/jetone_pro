<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? 'Anonim';

header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

$irs    = trim($_POST['irsaliye_no']    ?? '');
$kod    = trim($_POST['malzeme_kodu']   ?? '');
$adi    = trim($_POST['malzeme_adi']    ?? '');
$miktar = trim($_POST['miktar']         ?? '');
$tipler  = $_POST['hata_tipi']          ?? [];
$mktlar  = $_POST['hata_miktar']        ?? [];
$akslar  = $_POST['alinan_aksiyon']     ?? [];

if (!$irs || !$kod || !$miktar || empty($tipler)) {
    exit(json_encode(['status'=>'error','message'=>'Eksik alan.']));
}

$tarih = date('Y-m-d');
try {
    $db->beginTransaction();
    for ($i = 0; $i < count($tipler); $i++) {
        $hm = (int)($mktlar[$i] ?? 0);
        if ($hm <= 0) continue;
        $db->prepare("INSERT INTO dis_iade_kontrol_listesi
            (irsaliye_no,malzeme_kodu,malzeme_adi,miktar,hata_tipi,hata_miktar,alinan_aksiyon,kul_adi,kayit_tarih)
            VALUES (?,?,?,?,?,?,?,?,?)")
        ->execute([$irs,$kod,$adi,$miktar,$tipler[$i],$hm,$akslar[$i]??'',$kul_adi,$tarih]);
    }
    $db->commit();
    exit(json_encode(['status'=>'success']));
} catch (Throwable $e) {
    $db->rollBack();
    exit(json_encode(['status'=>'error','message'=>$e->getMessage()]));
}
