<?php
ob_start();
ini_set('display_errors',0); error_reporting(E_ALL);
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once __DIR__.'/gkk_ortak.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
set_exception_handler(function($e){
    while(ob_get_level()>0) ob_end_clean();
    echo json_encode(['success'=>false,'message'=>$e->getMessage(),'trace'=>$e->getFile().':'.$e->getLine()]);
    exit;
});
set_error_handler(function($no,$str,$file,$line){
    if($no & (E_ERROR|E_PARSE|E_CORE_ERROR|E_COMPILE_ERROR)){
        while(ob_get_level()>0) ob_end_clean();
        echo json_encode(['success'=>false,'message'=>"PHP Hata: $str",'file'=>"$file:$line"]);
        exit;
    }
    return false;
});

if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum geçersiz']); exit; }

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

global $db;
$d       = json_decode(file_get_contents('php://input'),true)?:[];
$fis_id  = (int)($d['fis_id']   ?? 0);
$satir_id= (int)($d['satir_id'] ?? 0);
$sonuc   = strtoupper(trim($d['sonuc']    ?? ''));
$sk           = strtoupper(trim($d['stok_kodu']?? ''));
$aciklama     = trim($d['aciklama']      ?? '');
$kontrol_adet = max(0,(int)($d['kontrol_adet'] ?? 0));
$hata_adet    = max(0,(int)($d['hata_adet']    ?? 0));

if(!$fis_id || !$satir_id || !in_array($sonuc,['ONAY','SART_ONAY','RED'])){
    echo json_encode(['success'=>false,'message'=>'Eksik parametre']); exit;
}

// İrsaliye no ve stok bilgisi
try {
    $st = $tigerdb_pdo->prepare("SELECT IRSALIYE_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM FROM MES_SATINALMA WHERE FIS_ID=? AND SATIR_ID=?");
    $st->execute([$fis_id,$satir_id]);
    $satir = $st->fetch(PDO::FETCH_ASSOC);
    if(!$satir){ echo json_encode(['success'=>false,'message'=>'Satır bulunamadı']); exit; }
} catch(Throwable $e){ echo json_encode(['success'=>false,'message'=>$e->getMessage()]); exit; }

$irsno    = trim($satir['IRSALIYE_NO']);
$stok_kodu= trim($satir['STOK_KODU']);
$stok_adi = $satir['STOK_ADI']??'';
$miktar   = (float)($satir['MIKTAR']??0);
$birim    = $satir['BIRIM']??'';

// Paketleri çek
try {
    $st2 = $mes_pdo->prepare("SELECT * FROM dbo.PAKETLER WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF IN (0,2)");
    $st2->execute([$irsno,$stok_kodu]);
    $paketler = $st2->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ echo json_encode(['success'=>false,'message'=>'Paket sorgu hatası: '.$e->getMessage()]); exit; }

if(empty($paketler)){ echo json_encode(['success'=>false,'message'=>'Bu kalem için etiket alınmamış']); exit; }

$logo_fis_no = '';
$now = date('Y-m-d H:i:s');

try {
    // ── ONAY veya ŞARTLI ONAY ─────────────────────────────────────────────
    if($sonuc === 'ONAY' || $sonuc === 'SART_ONAY') {
        $raf_yeni = $sonuc === 'ONAY' ? 'GKK_OK' : 'GKK_SART_OK';

        // AKTIF=2 (karantinada) olan paketleri grupla — toplam miktar tek transfer
        $karan_toplam = 0;
        foreach($paketler as $pkg) {
            if((int)($pkg['AKTIF']??0) == 2) $karan_toplam += (float)$pkg['MIKTAR'];
        }

        // Karantina → Merkez(0) transfer (her iki onay türü için)
        if($karan_toplam > 0) {
            try {
                $logo_fis_no = _logoTransfer($stok_kodu,$karan_toplam,$birim,2,0,$sonuc,$tigerdb_pdo,$mes_pdo,$kul_adi);
            } catch(Throwable $transferEx) {
                throw new Exception('Karantina→Merkez transfer başarısız: '.$transferEx->getMessage());
            }
        }

        foreach($paketler as $pkg) {
            $mevcut_raf  = strtoupper(trim($pkg['STOK_YERI']??''));
            $is_karantin = (int)($pkg['AKTIF']??0) == 2;

            if($is_karantin) {
                // Red'den dönüş — raf GKK_RET ise güncelle, başka adres ise koru
                $yeni_raf_karantin = ($mevcut_raf === 'GKK_RET') ? $raf_yeni : $mevcut_raf;
                $mes_pdo->prepare("UPDATE dbo.PAKETLER SET STOK_YERI=?,KALITE_TARIHI=?,AKTIF=0,AMBAR=0 WHERE ID=?")
                        ->execute([$yeni_raf_karantin,$now,$pkg['ID']]);
            } elseif(in_array($mevcut_raf, ['GKK','GKK_RET',''])) {
                $mes_pdo->prepare("UPDATE dbo.PAKETLER SET STOK_YERI=?,KALITE_TARIHI=?,AKTIF=0 WHERE ID=?")
                        ->execute([$raf_yeni,$now,$pkg['ID']]);
            } else {
                // Raf başka adreste — sadece kalite tarihini kaydet
                $mes_pdo->prepare("UPDATE dbo.PAKETLER SET KALITE_TARIHI=?,AKTIF=0 WHERE ID=?")
                        ->execute([$now,$pkg['ID']]);
            }
        }
    }

    // ── RED ────────────────────────────────────────────────────────────────
    if($sonuc === 'RED') {
        // Ambar bazında grupla — aynı ambardaki paketleri tek transfer et
        $ambar_gruplari = [];
        foreach($paketler as $pkg) {
            $amb = (int)($pkg['AMBAR']??1);
            if($amb === 2) continue; // Zaten karantinada, transfer gerekmez
            $ambar_gruplari[$amb] = ($ambar_gruplari[$amb] ?? 0) + (float)$pkg['MIKTAR'];
        }

        // Her ambar grubu için tek bir Logo transferi
        foreach($ambar_gruplari as $kaynak_ambar => $toplam_miktar) {
            try {
                $fis = _logoTransfer($stok_kodu,$toplam_miktar,$birim,$kaynak_ambar,2,'RED',$tigerdb_pdo,$mes_pdo,$kul_adi);
                if($fis) $logo_fis_no = $fis;
            } catch(Throwable $transferEx) {
                throw new Exception('Logo ambar transferi başarısız: '.$transferEx->getMessage());
            }
        }

        // Tüm paketleri güncelle
        foreach($paketler as $pkg) {
            $mevcut_raf = strtoupper(trim($pkg['STOK_YERI']??''));
            // Sadece GKK veya boş ise GKK_RET yap
            // Başka raf adresi (C8.K2 vb.) → raf değişmez, sadece ambar 2 olur
            if(in_array($mevcut_raf, ['GKK', ''])) {
                $yeni_raf = 'GKK_RET';
            } else {
                $yeni_raf = $mevcut_raf; // GKK_OK, GKK_SART_OK, C8.K2 vb. — değişmez
            }
            $mes_pdo->prepare("UPDATE dbo.PAKETLER SET STOK_YERI=?,KALITE_TARIHI=?,AKTIF=2,AMBAR=2 WHERE ID=?")
                    ->execute([$yeni_raf,$now,$pkg['ID']]);
        }
    }

    // GKK sonucunu kaydet (INSERT OR UPDATE)
    gkk_tablo_olustur($db);
    // Kolonlar yoksa ekle (mevcut tablo güncellemesi)
    foreach(['kontrol_adet INT DEFAULT 0','hata_adet INT DEFAULT 0'] as $_col_def) {
        $_col = explode(' ',$_col_def)[0];
        try {
            $chk = $db->query("SHOW COLUMNS FROM gkk_kontrol_sonuclari LIKE '$_col'")->rowCount();
            if(!$chk) $db->exec("ALTER TABLE gkk_kontrol_sonuclari ADD COLUMN $_col_def");
        } catch(Throwable $_ce) {}
    }
    $mevcut = gkkSonucuVar($fis_id,$satir_id,$db);
    if($mevcut) {
        $db->prepare("UPDATE gkk_kontrol_sonuclari SET sonuc=?,aciklama=?,kontrol_adet=?,hata_adet=?,logo_fis_no=?,kontrol_eden=?,kontrol_tarihi=? WHERE id=?")
           ->execute([$sonuc,$aciklama,$kontrol_adet,$hata_adet,$logo_fis_no,$kul_adi,$now,$mevcut['id']]);
    } else {
        $db->prepare("INSERT INTO gkk_kontrol_sonuclari (fis_id,irsaliye_no,satir_id,stok_kodu,stok_adi,miktar,birim,sonuc,aciklama,kontrol_adet,hata_adet,logo_fis_no,kontrol_eden) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$fis_id,$irsno,$satir_id,$stok_kodu,$stok_adi,$miktar,$birim,$sonuc,$aciklama,$kontrol_adet,$hata_adet,$logo_fis_no,$kul_adi]);
    }

    echo json_encode(['success'=>true,'message'=>"$sonuc işlemi tamamlandı.",'logo_fis_no'=>$logo_fis_no]);

} catch(Throwable $e) {
    while(ob_get_level()>0) ob_end_clean();
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'detail'  => get_class($e).' @ '.$e->getFile().':'.$e->getLine()
    ]);
}

// ── Logo Ambar Transfer (montaj_fire_kaydet.php ile aynı yapı) ─────────────
function _logoTransfer($stok_kodu, $miktar, $birim, $kaynak, $hedef, $doc_no, $tdb=null, $mdb=null, $ekleyen='GKK') {
    global $mes_pdo, $tigerdb_pdo;
    if(!$tdb) $tdb = $tigerdb_pdo;
    if(!$mdb) $mdb = $mes_pdo;
    $token = '';
    if($mdb) {
        try {
            $ts = $mdb->query("SELECT TOP 1 TOKEN FROM REST_SERVIS_KAYITLAR WHERE DATEDIFF(day,TARIH,GETDATE())=0 ORDER BY ID DESC");
            $tr = $ts ? $ts->fetch(PDO::FETCH_ASSOC) : null;
            if($tr) $token = trim($tr['TOKEN']);
        } catch(Throwable $te) {}
    }
    $g_URL = class_exists('Global_Rest') ? Global_Rest::$g_URL : 'http://192.168.1.100:32001/api/v1/';
    if(!$token) throw new Exception('Logo API token alınamadı');

    $g_URL = class_exists('Global_Rest') ? Global_Rest::$g_URL : 'http://192.168.1.100:32001/api/v1/';

    // Stok ve lot kontrolü
    $itemref = 0; $tracktype = 0; $lotBilgisi = null; $lotBilgisiTumu = [];
    if($tigerdb_pdo) {
        try {
            $ss = $tdb->prepare("SELECT TOP 1 LOGICALREF AS ITEMREF, TRACKTYPE FROM dbo.LG_222_ITEMS WHERE CODE=? AND ACTIVE=0");
            $ss->execute([$stok_kodu]);
            $sr = $ss->fetch(PDO::FETCH_ASSOC);
            if($sr) { $itemref=(int)$sr['ITEMREF']; $tracktype=(int)$sr['TRACKTYPE']; }

            // Stok miktarı kontrolü
            // Ambar bazında stok: LV_222_01 ve LV_222_02 view'larına bak
            $sm = $tdb->prepare(
                "SELECT ISNULL(SUM(v.ONHAND),0) AS ELDEKI
                 FROM dbo.LG_222_ITEMS it
                 LEFT JOIN (
                     SELECT STOCKREF, INVENNO, ONHAND FROM dbo.LV_222_01_STINVTOT
                     UNION ALL
                     SELECT STOCKREF, INVENNO, ONHAND FROM dbo.LV_222_02_STINVTOT
                 ) v ON it.LOGICALREF=v.STOCKREF AND v.INVENNO=?
                 WHERE it.CODE=? AND it.ACTIVE=0"
            );
            $sm->execute([$kaynak, $stok_kodu]);
            $stok_mik = (float)($sm->fetchColumn() ?: 0);
            if($stok_mik < $miktar) {
                throw new Exception("$stok_kodu için yeterli stok yok — Eldeki: $stok_mik, Gerekli: $miktar (Ambar: $kaynak)");
            }

            if($tracktype > 0 && $itemref > 0) {
                // MES_STOK_KONTROL'den lot çek (hurda_takoz_giris ile aynı yapı)
                try {
                    $ls = $tdb->prepare(
                        "SELECT TOP 1 SOURCE_SLT_REFERENCE, STTRANSREF, LOT_NO, KALAN_MIKTAR
                         FROM MES_STOK_KONTROL
                         WHERE STOK_KODU=? AND AMBAR_NO=? AND KALAN_MIKTAR>0
                         ORDER BY KALAN_MIKTAR DESC"
                    );
                    $ls->execute([$stok_kodu, $kaynak]);
                    $mesLot = $ls->fetch(PDO::FETCH_ASSOC);
                } catch(Throwable $mesEx) {
                    $mesLot = false;
                    // MES_STOK_KONTROL yoksa devam et
                }

                if($mesLot) {
                    $lotBilgisi = [
                        'LOT_NO'     => $mesLot['LOT_NO'],
                        'LOT_REF'    => $mesLot['SOURCE_SLT_REFERENCE'],
                        'STTRANSREF' => $mesLot['STTRANSREF'],
                        'SLTYPE'     => 1,
                        'ALINACAK'   => min((float)$mesLot['KALAN_MIKTAR'], $miktar),
                    ];
                    $lotBilgisiTumu = [$lotBilgisi];
                } else {
                    // MES'te yoksa Tiger SERILOTN'dan dene
                    // Tiger SERILOTN — REMAMOUNT kontrolsüz de dene
                    $ls2 = $tdb->prepare(
                        "SELECT TOP 1 SL.SLTYPE, SL.CODE AS LOT_NO, SL.LOGICALREF AS LOT_REF,
                                 SL.INVENNO AS LOT_INVENNO
                         FROM LG_222_SERILOTN SL
                         WHERE SL.ITEMREF=?
                         ORDER BY CASE WHEN SL.INVENNO=? THEN 0 ELSE 1 END, SL.LOGICALREF DESC"
                    );
                    $ls2->execute([$itemref, $kaynak]);
                    $tigLot = $ls2->fetch(PDO::FETCH_ASSOC);
                    if($tigLot) { $tigLot['LOT_MIKTAR'] = $miktar; $kaynak = (int)$tigLot['LOT_INVENNO']; }

                    // Tiger'da da yoksa PAKETLER.ANA_HAMMADDE'den lot al
                    if(!$tigLot) {
                        try {
                            $lp = $mdb->prepare(
                                "SELECT TOP 1 ANA_HAMMADDE FROM PAKETLER
                                 WHERE URETIM_EMRI_NO=? AND STOK_KODU=?
                                 AND ANA_HAMMADDE IS NOT NULL AND ANA_HAMMADDE NOT IN ('','LOTSUZ')
                                 ORDER BY ID DESC"
                            );
                            $lp->execute([$irsno, $stok_kodu]);
                            $pktLot = $lp->fetchColumn();
                            if($pktLot) {
                                // Tiger'dan bu lot kodunun LOGICALREF'ini al
                                $ll = $tdb->prepare(
                                    "SELECT TOP 1 LOGICALREF, SLTYPE FROM LG_222_SERILOTN
                                     WHERE ITEMREF=? AND CODE=? ORDER BY LOGICALREF DESC"
                                );
                                $ll->execute([$itemref, $pktLot]);
                                $lotRow = $ll->fetch(PDO::FETCH_ASSOC);
                                $tigLot = [
                                    'LOT_NO'      => $pktLot,
                                    'LOT_REF'     => $lotRow ? $lotRow['LOGICALREF'] : 0,
                                    'SLTYPE'      => $lotRow ? $lotRow['SLTYPE'] : 1,
                                    'LOT_MIKTAR'  => $miktar,
                                    'LOT_INVENNO' => $kaynak,
                                    'STTRANSREF'  => 0,
                                ];
                            }
                        } catch(Throwable $pe) {}
                    }
                    if($tigLot) {
                        $tigLot['ALINACAK'] = min((float)$tigLot['LOT_MIKTAR'], $miktar);
                        $tigLot['STTRANSREF'] = 0;
                        $lotBilgisi = $tigLot;
                        $lotBilgisiTumu = [$tigLot];
                    }
                }
            }
        } catch(Throwable $e) {
            // Stok yetersiz exception'ı yukarıya fırlat
            if(str_contains($e->getMessage(), 'yeterli stok') || str_contains($e->getMessage(), 'Eldeki')) throw $e;
            error_log('[GKK_TIGER] '.$e->getMessage());
        }
    }

    // Payload
    $dt    = new DateTime();
    $tarih = $dt->format('Y-m-d\TH:i:s');
    // Logo TIME formatı: saat*3600 + dakika*60 + saniye (saniye cinsinden günün zamanı)
    $timeV = (int)$dt->format('H') * 3600 + (int)$dt->format('i') * 60 + (int)$dt->format('s');

    $txItem = [
        'ITEM_CODE'   => $stok_kodu,
        'LINE_TYPE'   => 0,
        'SOURCEINDEX' => $kaynak,
        'DESTINDEX'   => $hedef,
        'FACTORYNR'   => 0,
        'LINE_NUMBER' => 1,
        'DESCRIPTION' => 'GKK '.$doc_no,
        'QUANTITY'    => $miktar,
        'UNIT_CODE'   => $birim,
        'UNIT_CONV1'  => $miktar,
        'UNIT_CONV2'  => $miktar,
        'EDT_CURR'    => 1,
    ];

    if(!empty($lotBilgisiTumu)) {
        $slItems = [];
        foreach($lotBilgisiTumu as $lot) {
            $slItem = [
                'IOCODE'       => 3,
                'SOURCE_WH'    => $kaynak,
                'SL_TYPE'      => (int)($lot['SLTYPE'] ?? 1),
                'SL_CODE'      => $lot['LOT_NO'],
                'SL_REFERENCE' => (int)($lot['LOT_REF'] ?? 0),
                'MU_QUANTITY'  => (float)$lot['ALINACAK'],
                'UNIT_CODE'    => $birim,
                'QUANTITY'     => (float)$lot['ALINACAK'],
                'SOURCE_QUANTITY' => (float)$lot['ALINACAK'],
                'UNIT_CONV1'   => (float)$lot['ALINACAK'],
                'UNIT_CONV2'   => (float)$lot['ALINACAK'],
            ];
            if(!empty($lot['STTRANSREF']))
                $slItem['SOURCE_MT_REFERENCE']  = strval($lot['STTRANSREF']);
            if(!empty($lot['LOT_REF']))
                $slItem['SOURCE_SLT_REFERENCE'] = strval($lot['LOT_REF']);
            $slItems[] = $slItem;
        }
        $txItem['SL_DETAILS'] = ['items' => $slItems];
    } elseif($lotBilgisi) {
        // Fallback - tek lot
        $txItem['SL_DETAILS'] = ['items'=>[[
            'IOCODE'              => 3,
            'SOURCE_WH'           => $kaynak,
            'SL_TYPE'             => (int)($lotBilgisi['SLTYPE'] ?? 1),
            'SL_CODE'             => $lotBilgisi['LOT_NO'],
            'SL_REFERENCE'        => (int)($lotBilgisi['LOT_REF'] ?? 0),
            'SOURCE_MT_REFERENCE' => strval($lotBilgisi['STTRANSREF'] ?? 0),
            'SOURCE_SLT_REFERENCE'=> strval($lotBilgisi['LOT_REF'] ?? 0),
            'MU_QUANTITY'         => (float)$miktar,
            'UNIT_CODE'           => $birim,
            'QUANTITY'            => (float)$miktar,
            'SOURCE_QUANTITY'     => (float)$miktar,
            'UNIT_CONV1'          => (float)$miktar,
            'UNIT_CONV2'          => (float)$miktar,
        ]]];
    }

    $payload = json_encode([
        'INTERNAL_REFERENCE'  => 0,
        'GROUP'               => 3,
        'TYPE'                => 25,
        'NUMBER'              => '~',
        'DATE'                => $tarih,
        'TIME'                => $timeV,
        'DOC_NUMBER'          => $ekleyen ?: ('GKK-'.$doc_no),
        'SOURCE_WH'           => $kaynak,
        'DEST_WH'             => $hedef,
        'SOURCE_FACTORY_NR'   => 0,
        'SOURCE_DIVISION_NR'  => 0,
        'DEST_FACTORY'        => 0,
        'DEST_DIVISION_NR'    => 0,
        'TRANSACTIONS'        => ['items' => [$txItem]],
    ], JSON_UNESCAPED_UNICODE);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $g_URL.'itemSlips',
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ["Authorization: Bearer $token", "Content-Type: application/json"],
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp  = curl_exec($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlE = curl_error($ch);
    curl_close($ch);

    if($curlE) throw new Exception("cURL: $curlE");
    if($code < 200 || $code >= 300) {
        $mesDbg=''; try{ $dq=$tdb->prepare("SELECT TOP 3 STOK_KODU,AMBAR_NO,LOT_NO,KALAN_MIKTAR FROM MES_STOK_KONTROL WHERE STOK_KODU=? ORDER BY KALAN_MIKTAR DESC"); $dq->execute([$stok_kodu]); $mesDbg=json_encode($dq->fetchAll(PDO::FETCH_ASSOC)); }catch(Throwable $de){ $mesDbg=$de->getMessage(); }
        $tigDbg=''; try{ $dq2=$tdb->prepare("SELECT TOP 3 SL.CODE,SL.INVENNO,SL.LOGICALREF FROM LG_222_SERILOTN SL WHERE SL.ITEMREF=? ORDER BY SL.LOGICALREF DESC"); $dq2->execute([$itemref]); $tigDbg=json_encode($dq2->fetchAll(PDO::FETCH_ASSOC)); }catch(Throwable $de2){ $tigDbg=$de2->getMessage(); }
        throw new Exception("Logo HTTP $code | MES=$mesDbg | TIG=$tigDbg | Yanıt: ".substr($resp,0,150));
    }
    $data = json_decode($resp, true);
    if(empty($data['INTERNAL_REFERENCE'])) {
        throw new Exception("Transfer boş ref | Yanıt: $resp");
    }
    // Fiş no — montaj_fire_kaydet ile aynı yöntem
    return $data['NUMBER'] ?? ('REF-'.(int)$data['INTERNAL_REFERENCE']);
}
