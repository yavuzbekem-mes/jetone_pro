<?php
/**
 * GKK Red Süreç Yönetimi — API endpoint
 * POST: action, gkk_id, ...
 */
ob_start();
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if(!Auth::girisYapilmisMi()){ echo json_encode(['success'=>false,'message'=>'Oturum geçersiz']); exit; }

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

global $db;

// Tabloları oluştur
function gkk_tablolari_olustur($db) {
    // Ana süreç tablosu
    $db->exec("CREATE TABLE IF NOT EXISTS gkk_red_surec (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        gkk_id          INT NOT NULL UNIQUE,
        irsaliye_no     VARCHAR(50) NOT NULL,
        stok_kodu       VARCHAR(50) NOT NULL,
        stok_adi        VARCHAR(255) DEFAULT '',
        tedarikci       VARCHAR(255) DEFAULT '',
        cari_kodu       VARCHAR(50) DEFAULT '',
        miktar          DECIMAL(15,4) DEFAULT 0,
        birim           VARCHAR(20) DEFAULT '',
        kontrol_tarihi  DATETIME,
        hata_orani      DECIMAL(5,2) DEFAULT 0,
        asama           ENUM(
            'RED',
            'TEDARIKCI_BILDIRILDI',
            'TEDARIKCI_YANIT_BEKLENIYOR',
            'TEDARIKCI_YANITI_ALINDI',
            'AKSIYON_BELIRLENDI',
            'GERCEKLESIYOR',
            'KAPANDI'
        ) DEFAULT 'RED',
        aksiyon_turu    ENUM('','IADE','AYIKLAMA','SARTLI_ONAY','YENİ_SEVKIYAT','DIGER') DEFAULT '',
        sorumlu         VARCHAR(100) DEFAULT '',
        planlanan_tarih DATE,
        kapanma_tarihi  DATE,
        aciklama        TEXT,
        olusturan       VARCHAR(100) DEFAULT '',
        olusturma_tar   DATETIME DEFAULT CURRENT_TIMESTAMP,
        guncelleme_tar  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_gkk(gkk_id),
        INDEX idx_asama(asama),
        INDEX idx_irsno(irsaliye_no)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Log tablosu (her adım)
    $db->exec("CREATE TABLE IF NOT EXISTS gkk_red_log (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        surec_id        INT NOT NULL,
        gkk_id          INT NOT NULL,
        asama_oncesi    VARCHAR(50) DEFAULT '',
        asama_sonrasi   VARCHAR(50) NOT NULL,
        not_            TEXT,
        dosya_yolu      VARCHAR(500) DEFAULT '',
        dosya_adi       VARCHAR(255) DEFAULT '',
        kaydeden        VARCHAR(100) DEFAULT '',
        kayit_tarihi    DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_surec(surec_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Tedarikçi yanıtı tablosu
    $db->exec("CREATE TABLE IF NOT EXISTS gkk_tedarikci_yanit (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        surec_id        INT NOT NULL,
        gkk_id          INT NOT NULL,
        yanit_tarihi    DATE,
        yanit_turu      ENUM('KOK_NEDEN','AKSIYON_PLANI','YENI_SEVKIYAT','DIGER') DEFAULT 'DIGER',
        yanit_icerigi   TEXT,
        yeni_sevkiyat_tarih DATE,
        yeni_sevkiyat_miktar DECIMAL(15,4) DEFAULT 0,
        dosya_yolu      VARCHAR(500) DEFAULT '',
        dosya_adi       VARCHAR(255) DEFAULT '',
        kaydeden        VARCHAR(100) DEFAULT '',
        kayit_tarihi    DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_surec(surec_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

try { gkk_tablolari_olustur($db); } catch(Throwable $e){ echo json_encode(['success'=>false,'message'=>'Tablo hatası: '.$e->getMessage()]); exit; }

$input = json_decode(file_get_contents('php://input'),true)?:$_POST;
$action = trim($input['action']??'');

// ── Süreç Başlat ──────────────────────────────────────────────────────────────
if($action === 'surec_baslat') {
    $gkk_id = (int)($input['gkk_id']??0);
    if(!$gkk_id){ echo json_encode(['success'=>false,'message'=>'gkk_id gerekli']); exit; }

    // GKK kaydını çek
    $gkk = $db->prepare("SELECT * FROM gkk_kontrol_sonuclari WHERE id=? AND sonuc='RED'")->execute([$gkk_id]) ?
           $db->prepare("SELECT * FROM gkk_kontrol_sonuclari WHERE id=? AND sonuc='RED'") : null;
    $st = $db->prepare("SELECT * FROM gkk_kontrol_sonuclari WHERE id=? AND sonuc='RED'");
    $st->execute([$gkk_id]);
    $gkk = $st->fetch(PDO::FETCH_ASSOC);
    if(!$gkk){ echo json_encode(['success'=>false,'message'=>'Red kaydı bulunamadı']); exit; }

    // Tedarikçi bilgisi Tiger'dan
    $tedarikci=''; $cari_kodu='';
    if($tigerdb_pdo) {
        try {
            $ts = $tigerdb_pdo->prepare("SELECT TOP 1 C.DEFINITION_ AS CARI, C.CODE AS KOD
                FROM (SELECT CLIENTREF,FICHENO FROM LG_222_01_STFICHE WHERE FICHENO=? AND TRCODE=1
                      UNION ALL SELECT CLIENTREF,FICHENO FROM LG_222_02_STFICHE WHERE FICHENO=? AND TRCODE=1) F
                LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF");
            $ts->execute([$gkk['irsaliye_no'],$gkk['irsaliye_no']]);
            $tr = $ts->fetch(PDO::FETCH_ASSOC);
            if($tr){ $tedarikci=$tr['CARI']; $cari_kodu=$tr['KOD']; }
        } catch(Throwable $e){}
    }

    $ka = (int)($gkk['kontrol_adet']??0);
    $ha = (int)($gkk['hata_adet']??0);
    $oran = $ka>0 ? round(($ha/$ka)*100,2) : 0;

    // Zaten var mı?
    $mevcut = $db->prepare("SELECT id FROM gkk_red_surec WHERE gkk_id=?")->execute([$gkk_id]) ? null : null;
    $chk = $db->prepare("SELECT id,asama FROM gkk_red_surec WHERE gkk_id=?");
    $chk->execute([$gkk_id]);
    $mevcut = $chk->fetch(PDO::FETCH_ASSOC);

    if($mevcut) {
        echo json_encode(['success'=>true,'surec_id'=>$mevcut['id'],'asama'=>$mevcut['asama'],'exists'=>true]);
    } else {
        $db->prepare("INSERT INTO gkk_red_surec (gkk_id,irsaliye_no,stok_kodu,stok_adi,tedarikci,cari_kodu,miktar,birim,kontrol_tarihi,hata_orani,asama,olusturan)
                      VALUES(?,?,?,?,?,?,?,?,?,?,'RED',?)")
           ->execute([$gkk_id,$gkk['irsaliye_no'],$gkk['stok_kodu'],$gkk['stok_adi'],$tedarikci,$cari_kodu,$gkk['miktar'],$gkk['birim'],$gkk['kontrol_tarihi'],$oran,$kul_adi]);
        $surec_id = (int)$db->lastInsertId();
        // İlk log
        $db->prepare("INSERT INTO gkk_red_log (surec_id,gkk_id,asama_oncesi,asama_sonrasi,not_,kaydeden) VALUES(?,?,'','RED','GKK Red kararı - Süreç başlatıldı',?)")
           ->execute([$surec_id,$gkk_id,$kul_adi]);
        echo json_encode(['success'=>true,'surec_id'=>$surec_id,'asama'=>'RED','exists'=>false]);
    }
    exit;
}

// ── Aşama Güncelle ────────────────────────────────────────────────────────────
if($action === 'asama_guncelle') {
    $surec_id    = (int)($input['surec_id']??0);
    $yeni_asama  = trim($input['asama']??'');
    $not_        = trim($input['not']??'');
    $sorumlu     = trim($input['sorumlu']??'');
    $aksiyon_turu= trim($input['aksiyon_turu']??'');
    $plan_tarih  = trim($input['planlanan_tarih']??'');

    if(!$surec_id || !$yeni_asama){ echo json_encode(['success'=>false,'message'=>'Eksik parametre']); exit; }

    $st = $db->prepare("SELECT * FROM gkk_red_surec WHERE id=?");
    $st->execute([$surec_id]);
    $surec = $st->fetch(PDO::FETCH_ASSOC);
    if(!$surec){ echo json_encode(['success'=>false,'message'=>'Süreç bulunamadı']); exit; }

    $kapanma = ($yeni_asama === 'KAPANDI') ? date('Y-m-d') : null;

    $db->prepare("UPDATE gkk_red_surec SET asama=?,sorumlu=?,aksiyon_turu=?,planlanan_tarih=?,kapanma_tarihi=?,aciklama=?,guncelleme_tar=NOW() WHERE id=?")
       ->execute([$yeni_asama, $sorumlu?:$surec['sorumlu'], $aksiyon_turu?:$surec['aksiyon_turu'],
                  $plan_tarih?:$surec['planlanan_tarih'], $kapanma, $not_?:$surec['aciklama'], $surec_id]);

    $db->prepare("INSERT INTO gkk_red_log (surec_id,gkk_id,asama_oncesi,asama_sonrasi,not_,kaydeden) VALUES(?,?,?,?,?,?)")
       ->execute([$surec_id,$surec['gkk_id'],$surec['asama'],$yeni_asama,$not_,$kul_adi]);

    echo json_encode(['success'=>true,'message'=>'Aşama güncellendi']);
    exit;
}

// ── Tedarikçi Yanıtı Kaydet ────────────────────────────────────────────────────
if($action === 'tedarikci_yanit') {
    $surec_id        = (int)($input['surec_id']??0);
    $yanit_turu      = trim($input['yanit_turu']??'DIGER');
    $yanit_icerigi   = trim($input['yanit_icerigi']??'');
    $yanit_tarihi    = trim($input['yanit_tarihi']??date('Y-m-d'));
    $yeni_sev_tarih  = trim($input['yeni_sevkiyat_tarih']??'') ?: null;
    $yeni_sev_mik    = (float)($input['yeni_sevkiyat_miktar']??0);

    if(!$surec_id){ echo json_encode(['success'=>false,'message'=>'surec_id gerekli']); exit; }

    $st = $db->prepare("SELECT gkk_id FROM gkk_red_surec WHERE id=?");
    $st->execute([$surec_id]);
    $surec = $st->fetch(PDO::FETCH_ASSOC);
    if(!$surec){ echo json_encode(['success'=>false,'message'=>'Süreç bulunamadı']); exit; }

    $db->prepare("INSERT INTO gkk_tedarikci_yanit (surec_id,gkk_id,yanit_tarihi,yanit_turu,yanit_icerigi,yeni_sevkiyat_tarih,yeni_sevkiyat_miktar,kaydeden)
                  VALUES(?,?,?,?,?,?,?,?)")
       ->execute([$surec_id,$surec['gkk_id'],$yanit_tarihi,$yanit_turu,$yanit_icerigi,$yeni_sev_tarih,$yeni_sev_mik,$kul_adi]);

    // Aşamayı güncelle
    $db->prepare("UPDATE gkk_red_surec SET asama='TEDARIKCI_YANITI_ALINDI',guncelleme_tar=NOW() WHERE id=?")
       ->execute([$surec_id]);
    $db->prepare("INSERT INTO gkk_red_log (surec_id,gkk_id,asama_oncesi,asama_sonrasi,not_,kaydeden) VALUES(?,(SELECT gkk_id FROM gkk_red_surec WHERE id=?),'TEDARIKCI_YANIT_BEKLENIYOR','TEDARIKCI_YANITI_ALINDI',?,?)")
       ->execute([$surec_id,$surec_id,$yanit_turu.': '.$yanit_icerigi,$kul_adi]);

    echo json_encode(['success'=>true,'message'=>'Tedarikçi yanıtı kaydedildi']);
    exit;
}

// ── Dosya Yükle ────────────────────────────────────────────────────────────────
if($action === 'dosya_yukle' && !empty($_FILES['dosya'])) {
    $surec_id = (int)($_POST['surec_id']??0);
    $tur      = trim($_POST['tur']??'log'); // log veya yanit
    $not_     = trim($_POST['not']??'');

    if(!$surec_id){ echo json_encode(['success'=>false,'message'=>'surec_id gerekli']); exit; }

    $upload_dir = ROOT_DIR.'/uploads/gkk_red/';
    if(!is_dir($upload_dir)) mkdir($upload_dir,0755,true);

    $dosya = $_FILES['dosya'];
    $ext   = strtolower(pathinfo($dosya['name'],PATHINFO_EXTENSION));
    $izin  = ['pdf','jpg','jpeg','png','xlsx','docx','txt'];
    if(!in_array($ext,$izin)){ echo json_encode(['success'=>false,'message'=>'Desteklenmeyen dosya türü']); exit; }

    $yeni_ad = 'gkk_'.$surec_id.'_'.time().'.'.$ext;
    $yol = $upload_dir.$yeni_ad;

    if(!move_uploaded_file($dosya['tmp_name'],$yol)){
        echo json_encode(['success'=>false,'message'=>'Dosya yüklenemedi']); exit;
    }

    $st = $db->prepare("SELECT gkk_id FROM gkk_red_surec WHERE id=?");
    $st->execute([$surec_id]);
    $surec = $st->fetch(PDO::FETCH_ASSOC);

    $db->prepare("INSERT INTO gkk_red_log (surec_id,gkk_id,asama_oncesi,asama_sonrasi,not_,dosya_yolu,dosya_adi,kaydeden) VALUES(?,?,?,?,?,?,?,?)")
       ->execute([$surec_id,$surec['gkk_id']??0,'',($tur==='yanit'?'TEDARIKCI_YANITI_ALINDI':'GERCEKLESIYOR'),$not_,'uploads/gkk_red/'.$yeni_ad,$dosya['name'],$kul_adi]);

    echo json_encode(['success'=>true,'dosya_adi'=>$dosya['name'],'yol'=>'uploads/gkk_red/'.$yeni_ad]);
    exit;
}

// ── Süreç Detayı ────────────────────────────────────────────────────────────────
if($action === 'detay') {
    $surec_id = (int)($input['surec_id']??$input['gkk_id']??0);
    $by_gkk   = !empty($input['gkk_id']) && empty($input['surec_id']);

    $st = $db->prepare($by_gkk
        ? "SELECT * FROM gkk_red_surec WHERE gkk_id=?"
        : "SELECT * FROM gkk_red_surec WHERE id=?");
    $st->execute([$surec_id]);
    $surec = $st->fetch(PDO::FETCH_ASSOC);

    if(!$surec){ echo json_encode(['success'=>false,'message'=>'Süreç bulunamadı']); exit; }

    $logs = $db->prepare("SELECT * FROM gkk_red_log WHERE surec_id=? ORDER BY kayit_tarihi ASC");
    $logs->execute([$surec['id']]);
    $log_list = $logs->fetchAll(PDO::FETCH_ASSOC);

    $yanitlar = $db->prepare("SELECT * FROM gkk_tedarikci_yanit WHERE surec_id=? ORDER BY yanit_tarihi DESC");
    $yanitlar->execute([$surec['id']]);
    $yanit_list = $yanitlar->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success'=>true,'surec'=>$surec,'loglar'=>$log_list,'yanitlar'=>$yanit_list]);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Bilinmeyen action: '.$action]);
