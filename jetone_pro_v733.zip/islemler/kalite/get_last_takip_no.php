<?php
$root = dirname(dirname(__DIR__));
require_once $root . '/core/db.php';
header('Content-Type: application/json');
$yil = preg_replace('/\D/','',$_POST['yil']??date('Y'));
$ay  = str_pad(preg_replace('/\D/','',$_POST['ay']??date('m')),2,'0',STR_PAD_LEFT);
$like = $yil . $ay . '%';
try {
    $st = $db->prepare("SELECT takip_no FROM uygunsuzluk WHERE takip_no LIKE ? ORDER BY takip_no DESC LIMIT 1");
    $st->execute([$like]);
    $last = $st->fetchColumn();
    $last_no = $last ? (int)substr($last, -3) : 0;
    echo json_encode(['last_no' => $last_no]);
} catch (Throwable $e) {
    echo json_encode(['last_no' => 0]);
}
exit;
