<?php
/**
 * JETONE.PRO ERP — İlk Giriş Şifre Değiştirme
 * erp-sifre-degistir.php
 */
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';
require_once __DIR__ . '/core/auth.php';

// Giriş yapılmamışsa giriş sayfasına
if (!Auth::girisYapilmisMi()) {
    header('Location: ' . BASE_URL . '/giris.php'); exit;
}

$kul        = Auth::kullanici();
$ilk_giris  = isset($_GET['ilk']) && $_GET['ilk'] == '1';
$hata       = '';
$basari     = '';

// Zaten şifresini değiştirmişse panele yönlendir (zorla geçiş engeli)
if (!$ilk_giris && ($kul['sifre_degistirildi'] ?? 1) == 1) {
    header('Location: ' . BASE_URL . '/panel.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mevcut      = trim($_POST['mevcut_sifre']  ?? '');
    $yeni        = trim($_POST['yeni_sifre']     ?? '');
    $yeni_tekrar = trim($_POST['yeni_tekrar']    ?? '');

    if (!$mevcut || !$yeni || !$yeni_tekrar) {
        $hata = 'Tüm alanları doldurun.';
    } elseif (strlen($yeni) < 8) {
        $hata = 'Yeni şifre en az 8 karakter olmalıdır.';
    } elseif ($yeni !== $yeni_tekrar) {
        $hata = 'Yeni şifreler eşleşmiyor.';
    } elseif ($mevcut === $yeni) {
        $hata = 'Yeni şifre mevcut şifreden farklı olmalıdır.';
    } else {
        try {
            $stmt = $db->prepare("SELECT sifre_hash FROM kullanicilar WHERE id=? LIMIT 1");
            $stmt->execute([$kul['id']]);
            $row = $stmt->fetch();

            if (!$row || !password_verify($mevcut, $row['sifre_hash'])) {
                $hata = 'Mevcut şifre yanlış.';
            } else {
                $yeni_hash = password_hash($yeni, PASSWORD_DEFAULT);

                // kullanicilar tablosunda sifre_degistirildi kolonu yoksa ekle
                try {
                    $db->exec("ALTER TABLE kullanicilar ADD COLUMN IF NOT EXISTS sifre_degistirildi TINYINT(1) DEFAULT 1");
                } catch (Exception $ex) {}

                $db->prepare("UPDATE kullanicilar SET sifre_hash=?, sifre_degistirildi=1 WHERE id=?")
                   ->execute([$yeni_hash, $kul['id']]);

                // Session'ı güncelle
                $_SESSION['kullanici']['sifre_degistirildi'] = 1;

                Auth::logKaydet($kul['id'], 'sifre_degistir', 'sistem', null, 'ERP şifresi değiştirildi');

                header('Location: ' . BASE_URL . '/panel.php?hosgeldin=1'); exit;
            }
        } catch (Exception $e) {
            $hata = 'Sistem hatası.';
            error_log('[ERPSifreDegistir] ' . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Şifrenizi Belirleyin — Jetone.pro ERP</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--t:#F97316;--t-k:#EA6800;--lac:#1A2E4A;--bg:#F0F2F5;--yuzey:#fff;--kenar:#E4E7EC;--m:#101828;--m2:#667085;--bas:#12B76A;--hat:#F04438;--hat-a:#FEE4E2;--r:8px;--r-lg:12px;--mavi:#2563EB}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Plus Jakarta Sans',system-ui,sans-serif;background:var(--bg);min-height:100vh;display:flex}

.sol{width:400px;flex-shrink:0;background:var(--lac);position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;padding:40px}
.sol-bg{position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 10% 80%,rgba(249,115,22,.2) 0%,transparent 60%),linear-gradient(160deg,#1A2E4A 0%,#080F1A 100%)}
.sol-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:40px 40px}
.sol-ic{position:relative;z-index:1;color:#fff;text-align:center}
.sol-logo{width:72px;height:72px;border-radius:18px;background:var(--t);display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 20px;box-shadow:0 12px 32px rgba(249,115,22,.4)}
.sol-bas{font-size:24px;font-weight:800;letter-spacing:-.5px;margin-bottom:10px}
.sol-alt{font-size:13px;color:rgba(255,255,255,.5);line-height:1.6;margin-bottom:24px}
.adimlar{display:flex;flex-direction:column;gap:10px;text-align:left}
.adim{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:var(--r);padding:10px 14px}
.adim-no{width:24px;height:24px;border-radius:50%;background:var(--t);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0}
.adim-ic div:first-child{font-size:13px;font-weight:700}
.adim-ic div:last-child{font-size:11px;color:rgba(255,255,255,.45)}

.sag{flex:1;display:flex;align-items:center;justify-content:center;padding:32px;overflow-y:auto}
.kart{width:100%;max-width:420px;background:var(--yuzey);border:1px solid var(--kenar);border-radius:16px;padding:36px;box-shadow:0 20px 40px rgba(0,0,0,.1)}
.hosgeldin{background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r-lg);padding:14px;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.hosgeldin-ikon{font-size:24px;flex-shrink:0}
.hosgeldin-ad{font-size:15px;font-weight:800;color:var(--m)}
.hosgeldin-alt{font-size:12px;color:var(--m2)}
.zorunlu-uyari{background:#FEF3E8;border:1.5px solid #FED7AA;border-radius:var(--r-lg);padding:12px 14px;margin-bottom:18px;font-size:13px;color:#92400E;display:flex;align-items:flex-start;gap:8px;font-weight:600}
.hata{background:var(--hat-a);border:1px solid var(--hat);border-radius:var(--r);padding:11px 14px;font-size:13px;color:var(--hat);margin-bottom:14px;font-weight:600}
.f-grup{margin-bottom:14px;position:relative}
.f-et{display:block;font-size:12.5px;font-weight:700;margin-bottom:5px;color:var(--m)}
.f-alan{width:100%;padding:11px 40px 11px 14px;border:1.5px solid var(--kenar);border-radius:var(--r);font-size:14px;font-family:inherit;color:var(--m);background:var(--bg);outline:none;transition:border-color .15s}
.f-alan:focus{border-color:var(--t);box-shadow:0 0 0 4px rgba(249,115,22,.1);background:#fff}
.goz-btn{position:absolute;right:12px;top:34px;background:none;border:none;cursor:pointer;font-size:16px;color:var(--m2)}
.kuvvet-bar-wrap{height:4px;background:var(--kenar);border-radius:2px;margin-top:6px;overflow:hidden}
.kuvvet-bar{height:100%;width:0;border-radius:2px;transition:all .3s}
.kuvvet-et{font-size:11px;margin-top:3px}
.kurallar{list-style:none;margin-top:6px}
.kurallar li{font-size:12px;padding:2px 0;display:flex;align-items:center;gap:6px;color:var(--m2)}
.kurallar li.gecti{color:var(--bas)}
.kurallar li::before{content:'○';font-size:10px}
.kurallar li.gecti::before{content:'✓'}
.btn{width:100%;padding:13px;background:linear-gradient(135deg,var(--t),var(--t-k));color:#fff;border:none;border-radius:var(--r);font-size:15px;font-weight:700;font-family:inherit;cursor:pointer;transition:all .15s;box-shadow:0 4px 14px rgba(249,115,22,.3);margin-top:6px}
.btn:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(249,115,22,.4)}
@media(max-width:640px){.sol{display:none}.sag{padding:20px}}
</style>
</head>
<body>

<div class="sol">
  <div class="sol-bg"></div><div class="sol-grid"></div>
  <div class="sol-ic">
    <div class="sol-logo">🔑</div>
    <div class="sol-bas">Güvenlik Kurulumu</div>
    <div class="sol-alt">
      Hesabınıza ilk kez giriş yaptınız.<br>
      Güvenliğiniz için şifrenizi belirlemeniz gerekiyor.
    </div>
    <div class="adimlar">
      <div class="adim"><div class="adim-no">1</div><div class="adim-ic"><div>Sistemden verilen şifre</div><div>İlk oturum açma şifresi</div></div></div>
      <div class="adim"><div class="adim-no">2</div><div class="adim-ic"><div>Yeni şifre belirle</div><div>En az 8 karakter, güçlü şifre</div></div></div>
      <div class="adim"><div class="adim-no">3</div><div class="adim-ic"><div>Panele erişim</div><div>Tüm yetkilerinizle giriş yapın</div></div></div>
    </div>
  </div>
</div>

<div class="sag">
  <div class="kart">
    <div class="hosgeldin">
      <div class="hosgeldin-ikon">👋</div>
      <div>
        <div class="hosgeldin-ad">Hoş geldiniz, <?php echo htmlspecialchars($kul['ad_soyad'] ?? ''); ?>!</div>
        <div class="hosgeldin-alt"><?php echo htmlspecialchars($kul['email'] ?? ''); ?></div>
      </div>
    </div>

    <?php if ($ilk_giris): ?>
    <div class="zorunlu-uyari">
      <span>⚠️</span>
      <span>Bu işlem zorunludur. Şifrenizi belirlemeden panele erişemezsiniz.</span>
    </div>
    <?php endif; ?>

    <?php if ($hata): ?>
    <div class="hata">❌ <?php echo htmlspecialchars($hata); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="f-grup">
        <label class="f-et"><?php echo $ilk_giris ? 'Sistemden Verilen Şifre' : 'Mevcut Şifre'; ?></label>
        <input type="password" name="mevcut_sifre" id="mevcutSifre" class="f-alan"
               placeholder="••••••••" required autocomplete="current-password">
        <button type="button" class="goz-btn" onclick="goster('mevcutSifre',this)">👁</button>
      </div>

      <div class="f-grup">
        <label class="f-et">Yeni Şifre</label>
        <input type="password" name="yeni_sifre" id="yeniSifre" class="f-alan"
               placeholder="En az 8 karakter" required autocomplete="new-password"
               oninput="sifreKontrol(this.value)">
        <button type="button" class="goz-btn" onclick="goster('yeniSifre',this)">👁</button>
        <div class="kuvvet-bar-wrap"><div class="kuvvet-bar" id="kuvvetBar"></div></div>
        <div class="kuvvet-et" id="kuvvetEt"></div>
        <ul class="kurallar" id="kuralListe">
          <li id="k1">En az 8 karakter</li>
          <li id="k2">En az 1 büyük harf (A-Z)</li>
          <li id="k3">En az 1 rakam (0-9)</li>
          <li id="k4">En az 1 özel karakter (!@#$%...)</li>
        </ul>
      </div>

      <div class="f-grup">
        <label class="f-et">Yeni Şifre Tekrar</label>
        <input type="password" name="yeni_tekrar" id="yeniTekrar" class="f-alan"
               placeholder="Şifreyi tekrar girin" required autocomplete="new-password"
               oninput="tekrarKontrol()">
        <button type="button" class="goz-btn" onclick="goster('yeniTekrar',this)">👁</button>
      </div>

      <button type="submit" class="btn">
        <?php echo $ilk_giris ? '✅ Şifremi Belirle ve Panele Gir' : '🔒 Şifremi Güncelle'; ?>
      </button>
    </form>
  </div>
</div>

<script>
function goster(id, btn) {
  var inp = document.getElementById(id);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.textContent = inp.type === 'text' ? '🙈' : '👁';
}

function sifreKontrol(v) {
  var k1 = v.length >= 8;
  var k2 = /[A-Z]/.test(v);
  var k3 = /[0-9]/.test(v);
  var k4 = /[^A-Za-z0-9]/.test(v);
  var puan = [k1,k2,k3,k4].filter(Boolean).length;

  document.getElementById('k1').className = k1 ? 'gecti' : '';
  document.getElementById('k2').className = k2 ? 'gecti' : '';
  document.getElementById('k3').className = k3 ? 'gecti' : '';
  document.getElementById('k4').className = k4 ? 'gecti' : '';

  var renkler = ['','#F04438','#F79009','#F79009','#12B76A'];
  var etiketler = ['','Zayıf','Orta','İyi','Güçlü'];
  var bar = document.getElementById('kuvvetBar');
  var et  = document.getElementById('kuvvetEt');
  bar.style.width = (puan * 25) + '%';
  bar.style.background = renkler[puan] || '#eee';
  et.textContent = etiketler[puan] || '';
  et.style.color = renkler[puan] || '#999';
}

function tekrarKontrol() {
  var yeni   = document.getElementById('yeniSifre').value;
  var tekrar = document.getElementById('yeniTekrar');
  tekrar.style.borderColor = (yeni && tekrar.value && yeni !== tekrar.value) ? '#F04438' : '';
}
</script>
</body>
</html>
