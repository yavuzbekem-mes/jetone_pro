<?php
/**
 * JETONE.PRO — Portal Kullanıcı Durum Kontrolü
 * portal_durum_kontrol.php
 *
 * Açın: http://localhost:4459/jetone_pro/portal_durum_kontrol.php
 * Kullandıktan sonra silin!
 */
error_reporting(E_ALL); ini_set('display_errors',1);
$db_host='localhost'; $db_adi='jetone_pro'; $db_kul='root'; $db_sifre='';
try {
    $db = new PDO("mysql:host=$db_host;dbname=$db_adi;charset=utf8",$db_kul,$db_sifre);
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch(Exception $e){ die('<pre style="color:red">'.$e->getMessage().'</pre>'); }

$mesajlar = [];

// Tüm portal kullanıcılarını al
$tumKullar = $db->query("SELECT id,tip,kullanici_adi,ad_soyad,durum,son_giris FROM portal_kullanicilari ORDER BY tip,kullanici_adi")->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['aksiyon'])) {
    $aksiyon = $_POST['aksiyon'];
    $kid     = (int)($_POST['kid'] ?? 0);

    if($aksiyon === 'ac' && $kid) {
        $db->prepare("UPDATE portal_kullanicilari SET durum=1 WHERE id=?")->execute([$kid]);
        $mesajlar[] = ['ok'=>true,'msg'=>"#$kid erişimi açıldı"];
    } elseif($aksiyon === 'kapat' && $kid) {
        $db->prepare("UPDATE portal_kullanicilari SET durum=0 WHERE id=?")->execute([$kid]);
        $mesajlar[] = ['ok'=>false,'msg'=>"#$kid erişimi kapatıldı"];
    } elseif($aksiyon === 'hepsini_ac') {
        $db->exec("UPDATE portal_kullanicilari SET durum=1");
        $mesajlar[] = ['ok'=>true,'msg'=>"Tüm portal kullanıcıları açıldı"];
    }
    $tumKullar = $db->query("SELECT id,tip,kullanici_adi,ad_soyad,durum,son_giris FROM portal_kullanicilari ORDER BY tip,kullanici_adi")->fetchAll(PDO::FETCH_ASSOC);
}

$kapali = array_filter($tumKullar, fn($k)=>$k['durum']==0);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Portal Durum</title>
<style>
body{font-family:Arial,sans-serif;background:#111;color:#ccc;padding:20px;font-size:13px}
h1{color:#f97316;font-size:16px}h2{color:#58a6ff;font-size:13px;margin:14px 0 5px;border-bottom:1px solid #333;padding-bottom:3px}
.ok{color:#3fb950;font-weight:bold}.hata{color:#f85149;font-weight:bold}
.uyari{background:#3d1a00;border:1px solid #f97316;border-radius:5px;padding:10px;margin:8px 0;color:#f97316}
.basari{background:#0d2818;border:1px solid #3fb950;border-radius:5px;padding:10px;margin:8px 0;color:#3fb950}
table{width:100%;border-collapse:collapse;font-size:12px;margin-bottom:10px}
th{background:#1a1a1a;color:#888;padding:5px 8px;border:1px solid #333;text-align:left}
td{padding:5px 8px;border:1px solid #333}
.btn{background:#f97316;color:#fff;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;font-size:12px}
.btn-yesil{background:#3fb950}.btn-kirmizi{background:#f04438}.btn:hover{opacity:.85}
</style></head><body>
<h1>Portal Kullanıcı Durum Kontrolü</h1>
<div class="uyari">Bu dosyayı kullandıktan sonra silin: <strong>portal_durum_kontrol.php</strong></div>

<?php foreach($mesajlar as $m): ?>
<div class="<?php echo $m['ok']?'basari':'uyari'; ?>"><?php echo htmlspecialchars($m['msg']); ?></div>
<?php endforeach; ?>

<?php if(count($kapali)>0): ?>
<div class="uyari">⚠️ <?php echo count($kapali); ?> kullanıcının erişimi kapalı! Bunlar portala giriş yapamaz.</div>
<form method="POST" style="margin-bottom:10px">
  <input type="hidden" name="aksiyon" value="hepsini_ac">
  <button type="submit" class="btn btn-yesil" onclick="return confirm('Tüm kapalı hesaplar açılsın mı?')">
    🔓 Tüm Kapalı Hesapları Aç
  </button>
</form>
<?php else: ?>
<div class="basari">✓ Tüm portal kullanıcıları aktif</div>
<?php endif; ?>

<h2>Tüm Portal Kullanıcıları</h2>
<table>
<tr><th>#</th><th>Tip</th><th>Kullanıcı Adı</th><th>Ad Soyad</th><th>Durum</th><th>Son Giriş</th><th>İşlem</th></tr>
<?php foreach($tumKullar as $k): ?>
<tr style="<?php echo $k['durum']==0 ? 'background:#2a1010' : ''; ?>">
  <td><?php echo $k['id']; ?></td>
  <td><?php echo $k['tip']; ?></td>
  <td style="font-family:monospace;color:#f97316"><b><?php echo htmlspecialchars($k['kullanici_adi']); ?></b></td>
  <td><?php echo htmlspecialchars($k['ad_soyad']??''); ?></td>
  <td class="<?php echo $k['durum']?'ok':'hata'; ?>"><?php echo $k['durum'] ? '✓ Açık' : '✗ Kapalı'; ?></td>
  <td style="font-size:11px;color:#666"><?php echo $k['son_giris'] ? date('d.m.Y H:i',strtotime($k['son_giris'])) : '—'; ?></td>
  <td>
    <?php if($k['durum']==0): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="aksiyon" value="ac">
      <input type="hidden" name="kid" value="<?php echo $k['id']; ?>">
      <button type="submit" class="btn btn-yesil">🔓 Aç</button>
    </form>
    <?php else: ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="aksiyon" value="kapat">
      <input type="hidden" name="kid" value="<?php echo $k['id']; ?>">
      <button type="submit" class="btn btn-kirmizi" onclick="return confirm('Erişim kapatılsın mı?')">🔒 Kapat</button>
    </form>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>
</table>

<div style="font-size:11px;color:#666;margin-top:10px">
  ERP Panelinden de yönetmek için: Personel Profil → Portal sekmesi → Toggle switch
</div>
</body></html>
