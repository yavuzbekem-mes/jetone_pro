-- ================================================================
-- JETONE.PRO — Tam Veritabanı
-- Versiyon: v730
-- Oluşturma: 2026-04-13 19:16
-- ================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------
-- 1. Veritabanı ve Temel Tablolar
-- Kaynak: veritabani_olustur.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO — Ana Veritabanı Şeması
-- Oluşturma Tarihi: 2024
-- Karakter Seti: utf8mb4 / Collation: utf8mb4_turkish_ci
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- Veritabanı oluştur
CREATE DATABASE IF NOT EXISTS `jetone_pro`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_turkish_ci;

USE `jetone_pro`;

-- ============================================================
-- 1. AYARLAR — Sistem genel ayarları
-- ============================================================
CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `firma_adi`           VARCHAR(200)  NOT NULL DEFAULT 'Jetone.Pro',
  `firma_kisa_adi`      VARCHAR(50)   DEFAULT '',
  `firma_logo`          VARCHAR(500)  DEFAULT '',
  `vergi_no`            VARCHAR(20)   DEFAULT '',
  `vergi_dairesi`       VARCHAR(100)  DEFAULT '',
  `adres`               TEXT,
  `telefon`             VARCHAR(20)   DEFAULT '',
  `email`               VARCHAR(100)  DEFAULT '',
  `web`                 VARCHAR(200)  DEFAULT '',
  `para_birimi`         VARCHAR(10)   NOT NULL DEFAULT 'TRY',
  `tarih_formati`       VARCHAR(20)   NOT NULL DEFAULT 'd.m.Y',
  `saat_dilimi`         VARCHAR(50)   NOT NULL DEFAULT 'Europe/Istanbul',
  `dil`                 VARCHAR(10)   NOT NULL DEFAULT 'tr',
  `tema`                VARCHAR(10)   NOT NULL DEFAULT 'acik',
  `giris_arkaplan`      VARCHAR(500)  DEFAULT '',
  `versiyon`            VARCHAR(20)   DEFAULT '1.0.0',
  `kurulum_tarihi`      DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi`   DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Varsayılan ayar kaydı
INSERT INTO `ayarlar` (`firma_adi`,`para_birimi`,`tarih_formati`,`saat_dilimi`,`dil`) 
VALUES ('Jetone.Pro','TRY','d.m.Y','Europe/Istanbul','tr');

-- ============================================================
-- 2. KULLANICILAR — Sistem kullanıcıları
-- ============================================================
CREATE TABLE IF NOT EXISTS `kullanicilar` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `sicil_no`            VARCHAR(20)   DEFAULT NULL,
  `ad`                  VARCHAR(100)  NOT NULL,
  `soyad`               VARCHAR(100)  NOT NULL,
  `ad_soyad`            VARCHAR(200)  GENERATED ALWAYS AS (CONCAT(`ad`,' ',`soyad`)) STORED,
  `email`               VARCHAR(150)  NOT NULL UNIQUE,
  `telefon`             VARCHAR(20)   DEFAULT NULL,
  `sifre_hash`          VARCHAR(255)  NOT NULL,
  `rol_id`              INT           DEFAULT NULL,
  `departman_id`        INT           DEFAULT NULL,
  `pozisyon`            VARCHAR(100)  DEFAULT NULL,
  `avatar`              VARCHAR(500)  DEFAULT NULL,
  `durum`               TINYINT(1)    NOT NULL DEFAULT 1 COMMENT '1=Aktif, 0=Pasif',
  `son_giris`           DATETIME      DEFAULT NULL,
  `sifre_degistirme_t`  DATETIME      DEFAULT NULL,
  `token`               VARCHAR(255)  DEFAULT NULL,
  `token_bitis`         DATETIME      DEFAULT NULL,
  `iki_adim_aktif`      TINYINT(1)    DEFAULT 0,
  `iki_adim_kodu`       VARCHAR(10)   DEFAULT NULL,
  `olusturma_tarihi`    DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `olusturan_id`        INT           DEFAULT NULL,
  INDEX `idx_email` (`email`),
  INDEX `idx_durum` (`durum`),
  INDEX `idx_rol` (`rol_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Varsayılan admin kullanıcı (şifre: Admin123!)
INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`durum`) 
VALUES ('Sistem','Yöneticisi','admin@jetone.pro', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

-- ============================================================
-- 3. ROLLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `roller` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `ad`          VARCHAR(100) NOT NULL,
  `aciklama`    VARCHAR(300) DEFAULT NULL,
  `renk`        VARCHAR(20)  DEFAULT '#667085',
  `sistem_rol`  TINYINT(1)   DEFAULT 0 COMMENT 'Silinemez sistem rolü',
  `olusturma`   DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `roller` (`ad`,`aciklama`,`sistem_rol`) VALUES
('Süper Admin',    'Tam sistem erişimi', 1),
('Yönetici',       'Modül yönetimi', 1),
('İK Uzmanı',      'İK modülü erişimi', 0),
('Üretim Operatörü','Üretim modülü', 0),
('Satış Temsilcisi','Satış modülü', 0),
('Depo Görevlisi', 'Depo modülü', 0),
('Kalite Uzmanı',  'Kalite modülü', 0),
('Muhasebe',       'Finans modülü', 0),
('Salt Okunur',    'Sadece görüntüleme', 0);

-- ============================================================
-- 4. YETKİLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `yetkiler` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `rol_id`      INT          NOT NULL,
  `modul`       VARCHAR(50)  NOT NULL COMMENT 'ik,satis,uretim,kalite,depo...',
  `sayfa`       VARCHAR(100) DEFAULT '*' COMMENT 'Sayfa adı veya * tümü',
  `goruntule`   TINYINT(1)   DEFAULT 0,
  `ekle`        TINYINT(1)   DEFAULT 0,
  `duzenle`     TINYINT(1)   DEFAULT 0,
  `sil`         TINYINT(1)   DEFAULT 0,
  `export`      TINYINT(1)   DEFAULT 0,
  INDEX `idx_rol_modul` (`rol_id`,`modul`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Süper Admin tüm yetkiler
INSERT INTO `yetkiler` (`rol_id`,`modul`,`sayfa`,`goruntule`,`ekle`,`duzenle`,`sil`,`export`)
SELECT 1, m.modul, '*', 1, 1, 1, 1, 1 FROM (
  SELECT 'ik' modul UNION SELECT 'satis' UNION SELECT 'uretim' UNION SELECT 'kalite'
  UNION SELECT 'depo' UNION SELECT 'satinalma' UNION SELECT 'planlama'
  UNION SELECT 'idari' UNION SELECT 'raporlar' UNION SELECT 'ayarlar'
  UNION SELECT 'entegrasyonlar' UNION SELECT 'guvenlik'
) m;

-- ============================================================
-- 5. DEPARTMANLAR
-- ============================================================
CREATE TABLE IF NOT EXISTS `departmanlar` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kod`             VARCHAR(20)   DEFAULT NULL,
  `ad`              VARCHAR(150)  NOT NULL,
  `ust_departman_id`INT           DEFAULT NULL,
  `mudur_id`        INT           DEFAULT NULL,
  `aciklama`        TEXT,
  `durum`           TINYINT(1)    DEFAULT 1,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `departmanlar` (`kod`,`ad`) VALUES
('GEN','Genel Müdürlük'),('IK','İnsan Kaynakları'),('MUH','Muhasebe / Finans'),
('SAT','Satış & Pazarlama'),('URE','Üretim'),('KAL','Kalite Güvence'),
('DEP','Depo & Lojistik'),('SAT2','Satınalma'),('PLN','Planlama'),
('BT','Bilgi Teknolojileri'),('IDR','İdari İşler');

-- ============================================================
-- 6. ENTEGRASYONLAR — Logo, MES, REST API bağlantıları
-- ============================================================
CREATE TABLE IF NOT EXISTS `entegrasyonlar` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kod`             VARCHAR(50)   NOT NULL UNIQUE COMMENT 'logo_tiger, mes, rest_api, logo_go...',
  `ad`              VARCHAR(150)  NOT NULL,
  `tip`             VARCHAR(50)   NOT NULL COMMENT 'mssql, mysql, rest_api, ftp, smtp',
  `aciklama`        VARCHAR(300)  DEFAULT NULL,
  `ikon`            VARCHAR(100)  DEFAULT NULL,
  `aktif`           TINYINT(1)   DEFAULT 0,
  `host`            VARCHAR(200)  DEFAULT NULL,
  `port`            INT           DEFAULT NULL,
  `veritabani`      VARCHAR(100)  DEFAULT NULL,
  `kullanici`       VARCHAR(100)  DEFAULT NULL,
  `sifre`           VARCHAR(255)  DEFAULT NULL COMMENT 'Şifreli saklanır',
  `ek_parametreler` JSON          DEFAULT NULL COMMENT 'Ek ayarlar JSON',
  `son_test_tarihi` DATETIME      DEFAULT NULL,
  `son_test_sonucu` TINYINT(1)   DEFAULT NULL COMMENT '1=Başarılı, 0=Başarısız',
  `son_test_mesaji` TEXT          DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `entegrasyonlar` (`kod`,`ad`,`tip`,`aciklama`,`ikon`,`aktif`) VALUES
('logo_tiger','Logo Tiger (TIGERDB)','mssql','Logo ERP ana veritabanı bağlantısı','🏭',0),
('mes','MES Üretim Sistemi','mssql','Manufacturing Execution System veritabanı','⚙️',0),
('logo_rest','Logo REST API','rest_api','Logo ERP REST API entegrasyonu','🔌',0),
('smtp_mail','E-Posta (SMTP)','smtp','Sistem e-posta gönderimi','✉️',0),
('sms_gateway','SMS Gateway','rest_api','SMS bildirim servisi','📱',0),
('logo_go','Logo Go (ERP)','mssql','Logo Go veritabanı bağlantısı','📊',0);

-- ============================================================
-- 7. REST API TOKEN YÖNETİMİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `api_token_kayitlar` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `entegrasyon_id`  INT           NOT NULL,
  `token`           TEXT          NOT NULL,
  `token_tipi`      VARCHAR(50)   DEFAULT 'Bearer',
  `alinma_tarihi`   DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `bitis_tarihi`    DATETIME      DEFAULT NULL,
  `aktif`           TINYINT(1)    DEFAULT 1,
  INDEX `idx_entegrasyon` (`entegrasyon_id`),
  INDEX `idx_aktif_tarih` (`aktif`, `alinma_tarihi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 8. SİSTEM LOGLAR
-- ============================================================
CREATE TABLE IF NOT EXISTS `sistem_loglar` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kullanici_id`    INT           DEFAULT NULL,
  `ip`              VARCHAR(45)   DEFAULT NULL,
  `islem`           VARCHAR(100)  NOT NULL COMMENT 'giris,cikis,kaydet,sil,guncelle...',
  `modul`           VARCHAR(50)   DEFAULT NULL,
  `kayit_id`        INT           DEFAULT NULL,
  `aciklama`        TEXT,
  `eski_veri`       JSON          DEFAULT NULL,
  `yeni_veri`       JSON          DEFAULT NULL,
  `durum`           VARCHAR(20)   DEFAULT 'basarili' COMMENT 'basarili,hata,uyari',
  `hata_mesaji`     TEXT          DEFAULT NULL,
  `user_agent`      VARCHAR(300)  DEFAULT NULL,
  `tarih`           DATETIME      DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_kullanici` (`kullanici_id`),
  INDEX `idx_modul` (`modul`),
  INDEX `idx_tarih` (`tarih`),
  INDEX `idx_islem` (`islem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 9. PORTAL KULLANICILARI — Personel ve Müşteri portal erişimi
-- ============================================================
CREATE TABLE IF NOT EXISTS `portal_kullanicilari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `tip`             VARCHAR(20)   NOT NULL COMMENT 'personel, musteri',
  `ilgili_id`       INT           DEFAULT NULL COMMENT 'personel_id veya musteri_id',
  `kullanici_adi`   VARCHAR(100)  NOT NULL,
  `email`           VARCHAR(150)  DEFAULT NULL,
  `sifre_hash`      VARCHAR(255)  NOT NULL,
  `ad_soyad`        VARCHAR(200)  DEFAULT NULL,
  `telefon`         VARCHAR(20)   DEFAULT NULL,
  `durum`           TINYINT(1)    DEFAULT 1,
  `son_giris`       DATETIME      DEFAULT NULL,
  `token`           VARCHAR(500)  DEFAULT NULL,
  `token_bitis`     DATETIME      DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  UNIQUE KEY `uk_tip_kullanici` (`tip`,`kullanici_adi`),
  INDEX `idx_tip` (`tip`),
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 10. İK — PERSONELLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `personeller` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `sicil_no`        VARCHAR(20)   NOT NULL UNIQUE,
  `ad`              VARCHAR(100)  NOT NULL,
  `soyad`           VARCHAR(100)  NOT NULL,
  `tc_kimlik`       VARCHAR(11)   DEFAULT NULL,
  `dogum_tarihi`    DATE          DEFAULT NULL,
  `cinsiyet`        TINYINT(1)    DEFAULT NULL COMMENT '1=Erkek, 2=Kadın',
  `departman_id`    INT           DEFAULT NULL,
  `pozisyon`        VARCHAR(100)  DEFAULT NULL,
  `telefon`         VARCHAR(20)   DEFAULT NULL,
  `email`           VARCHAR(150)  DEFAULT NULL,
  `adres`           TEXT,
  `ise_baslama`     DATE          DEFAULT NULL,
  `isten_ayrilma`   DATE          DEFAULT NULL,
  `calısma_tipi`    VARCHAR(30)   DEFAULT 'tam_zamanli',
  `durum`           VARCHAR(20)   DEFAULT 'aktif' COMMENT 'aktif,izinli,ayrıldı',
  `maas`            DECIMAL(12,2) DEFAULT 0.00,
  `banka_iban`      VARCHAR(34)   DEFAULT NULL,
  `foto`            VARCHAR(500)  DEFAULT NULL,
  `notlar`          TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  INDEX `idx_departman` (`departman_id`),
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 11. İK — DEVAM KAYITLARI
-- ============================================================
CREATE TABLE IF NOT EXISTS `devam_kayitlari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `personel_id`     INT           NOT NULL,
  `tarih`           DATE          NOT NULL,
  `giris_saati`     TIME          DEFAULT NULL,
  `cikis_saati`     TIME          DEFAULT NULL,
  `calisma_suresi`  DECIMAL(5,2)  DEFAULT NULL COMMENT 'Saat cinsinden',
  `durum`           VARCHAR(20)   DEFAULT 'geldi' COMMENT 'geldi,gelmedi,izinli,gecikti,eksik',
  `gec_kalis`       DECIMAL(5,2)  DEFAULT 0,
  `lokasyon`        VARCHAR(200)  DEFAULT NULL COMMENT 'Geofence lokasyon adı',
  `lat`             DECIMAL(10,8) DEFAULT NULL,
  `lng`             DECIMAL(11,8) DEFAULT NULL,
  `giris_tipi`      VARCHAR(20)   DEFAULT 'manuel' COMMENT 'geofence,kart,manuel',
  `cikis_tipi`      VARCHAR(20)   DEFAULT 'manuel',
  `notlar`          TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_personel_tarih` (`personel_id`,`tarih`),
  INDEX `idx_tarih` (`tarih`),
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 12. İK — İZİN TALEPLERİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `izin_talepleri` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `personel_id`     INT           NOT NULL,
  `izin_turu`       VARCHAR(50)   NOT NULL COMMENT 'yillik,hastalik,mazeret,ucretsiz,dogum,olum',
  `baslangic`       DATE          NOT NULL,
  `bitis`           DATE          NOT NULL,
  `gun_sayisi`      DECIMAL(4,1)  NOT NULL,
  `aciklama`        TEXT,
  `durum`           VARCHAR(20)   DEFAULT 'bekliyor' COMMENT 'bekliyor,onaylandi,reddedildi,iptal',
  `onaylayan_id`    INT           DEFAULT NULL,
  `onay_tarihi`     DATETIME      DEFAULT NULL,
  `ret_sebebi`      TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_personel` (`personel_id`),
  INDEX `idx_durum` (`durum`),
  INDEX `idx_tarih` (`baslangic`,`bitis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 13. İK — VARDİYA ATAMALARI
-- ============================================================
CREATE TABLE IF NOT EXISTS `vardialar` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `ad`          VARCHAR(100) NOT NULL,
  `baslangic`   TIME         NOT NULL,
  `bitis`       TIME         NOT NULL,
  `renk`        VARCHAR(20)  DEFAULT '#F97316',
  `aktif`       TINYINT(1)   DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `vardialar` (`ad`,`baslangic`,`bitis`,`renk`) VALUES
('Sabah Vardiyası','06:00:00','14:00:00','#F97316'),
('Öğleden Sonra','14:00:00','22:00:00','#2563EB'),
('Gece Vardiyası','22:00:00','06:00:00','#7C3AED'),
('Gündüz (Büro)','08:00:00','17:00:00','#12B76A');

CREATE TABLE IF NOT EXISTS `vardiya_atamalari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `personel_id`     INT           NOT NULL,
  `vardiya_id`      INT           NOT NULL,
  `baslangic`       DATE          NOT NULL,
  `bitis`           DATE          DEFAULT NULL,
  `notlar`          TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_personel` (`personel_id`),
  INDEX `idx_tarih` (`baslangic`,`bitis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 14. MÜŞTERİLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `musteriler` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kod`             VARCHAR(30)   NOT NULL UNIQUE,
  `ad`              VARCHAR(200)  NOT NULL,
  `tip`             VARCHAR(20)   DEFAULT 'kurumsal' COMMENT 'kurumsal,bireysel',
  `vergi_no`        VARCHAR(20)   DEFAULT NULL,
  `vergi_dairesi`   VARCHAR(100)  DEFAULT NULL,
  `telefon`         VARCHAR(20)   DEFAULT NULL,
  `email`           VARCHAR(150)  DEFAULT NULL,
  `adres`           TEXT,
  `il`              VARCHAR(50)   DEFAULT NULL,
  `ilce`            VARCHAR(50)   DEFAULT NULL,
  `yetkili_adi`     VARCHAR(150)  DEFAULT NULL,
  `yetkili_tel`     VARCHAR(20)   DEFAULT NULL,
  `yetkili_email`   VARCHAR(150)  DEFAULT NULL,
  `odeme_vadesi`    INT           DEFAULT 30 COMMENT 'Gün',
  `risk_limiti`     DECIMAL(15,2) DEFAULT 0,
  `logo_tiger_kodu` VARCHAR(50)   DEFAULT NULL COMMENT 'Logo ERP müşteri kodu',
  `durum`           VARCHAR(20)   DEFAULT 'aktif',
  `notlar`          TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_kod` (`kod`),
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 15. SATIŞ — SİPARİŞLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `satis_siparisleri` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `siparis_no`      VARCHAR(30)   NOT NULL UNIQUE,
  `musteri_id`      INT           NOT NULL,
  `tarih`           DATE          NOT NULL,
  `teslim_tarihi`   DATE          DEFAULT NULL,
  `durum`           VARCHAR(30)   DEFAULT 'bekliyor' COMMENT 'bekliyor,onaylandi,uretimde,sevkiyatta,teslim,iptal',
  `toplam_tutar`    DECIMAL(15,2) DEFAULT 0,
  `kdv_orani`       DECIMAL(5,2)  DEFAULT 18.00,
  `kdv_tutari`      DECIMAL(15,2) DEFAULT 0,
  `genel_toplam`    DECIMAL(15,2) DEFAULT 0,
  `para_birimi`     VARCHAR(10)   DEFAULT 'TRY',
  `aciklama`        TEXT,
  `logo_ref`        VARCHAR(50)   DEFAULT NULL COMMENT 'Logo sipariş referansı',
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  INDEX `idx_musteri` (`musteri_id`),
  INDEX `idx_durum` (`durum`),
  INDEX `idx_tarih` (`tarih`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 16. ÜRÜNLER / STOK KALEMLERİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `urunler` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kod`             VARCHAR(50)   NOT NULL UNIQUE,
  `ad`              VARCHAR(300)  NOT NULL,
  `kategori`        VARCHAR(100)  DEFAULT NULL,
  `birim`           VARCHAR(20)   DEFAULT 'adet',
  `birim_fiyat`     DECIMAL(12,2) DEFAULT 0,
  `stok_miktari`    DECIMAL(12,3) DEFAULT 0,
  `min_stok`        DECIMAL(12,3) DEFAULT 0,
  `max_stok`        DECIMAL(12,3) DEFAULT 0,
  `depo_id`         INT           DEFAULT NULL,
  `logo_kod`        VARCHAR(50)   DEFAULT NULL COMMENT 'Logo ERP ürün kodu',
  `durum`           VARCHAR(20)   DEFAULT 'aktif',
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_kod` (`kod`),
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 17. DEPO — STOK HAREKETLERİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `stok_hareketleri` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `urun_id`         INT           NOT NULL,
  `hareket_tipi`    VARCHAR(30)   NOT NULL COMMENT 'giris,cikis,transfer,fire,sayim',
  `miktar`          DECIMAL(12,3) NOT NULL,
  `onceki_miktar`   DECIMAL(12,3) DEFAULT NULL,
  `sonraki_miktar`  DECIMAL(12,3) DEFAULT NULL,
  `birim_fiyat`     DECIMAL(12,2) DEFAULT 0,
  `toplam_tutar`    DECIMAL(15,2) DEFAULT 0,
  `referans_tip`    VARCHAR(30)   DEFAULT NULL COMMENT 'siparis,iade,uretim...',
  `referans_id`     INT           DEFAULT NULL,
  `lot_no`          VARCHAR(50)   DEFAULT NULL,
  `depo_id`         INT           DEFAULT NULL,
  `aciklama`        TEXT,
  `tarih`           DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  INDEX `idx_urun` (`urun_id`),
  INDEX `idx_tarih` (`tarih`),
  INDEX `idx_hareket_tipi` (`hareket_tipi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 18. ÜRETİM — İŞ EMİRLERİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `is_emirleri` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `is_emri_no`      VARCHAR(30)   NOT NULL UNIQUE,
  `urun_id`         INT           DEFAULT NULL,
  `urun_adi`        VARCHAR(300)  DEFAULT NULL,
  `planlanan_miktar`DECIMAL(12,3) NOT NULL,
  `uretilen_miktar` DECIMAL(12,3) DEFAULT 0,
  `hurdа_miktar`    DECIMAL(12,3) DEFAULT 0,
  `baslangic_tarihi`DATE          DEFAULT NULL,
  `bitis_tarihi`    DATE          DEFAULT NULL,
  `gercek_baslangic`DATETIME      DEFAULT NULL,
  `gercek_bitis`    DATETIME      DEFAULT NULL,
  `durum`           VARCHAR(30)   DEFAULT 'planlandi' COMMENT 'planlandi,bekliyor,uretimde,tamamlandi,iptal',
  `oncelik`         INT           DEFAULT 5,
  `siparis_id`      INT           DEFAULT NULL,
  `aciklama`        TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  INDEX `idx_durum` (`durum`),
  INDEX `idx_tarih` (`baslangic_tarihi`,`bitis_tarihi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 19. KALİTE — DÖF (Düzeltici Önleyici Faaliyet)
-- ============================================================
CREATE TABLE IF NOT EXISTS `dof_kayitlari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `dof_no`          VARCHAR(30)   NOT NULL UNIQUE,
  `baslik`          VARCHAR(300)  NOT NULL,
  `tip`             VARCHAR(30)   DEFAULT 'duzeltici' COMMENT 'duzeltici,onleyici,gelistirme',
  `kaynak`          VARCHAR(50)   DEFAULT NULL COMMENT 'musteri_sikayeti,ic_denetim,proses...',
  `aciklama`        TEXT,
  `sorumlu_id`      INT           DEFAULT NULL,
  `hedef_kapanis`   DATE          DEFAULT NULL,
  `gercek_kapanis`  DATE          DEFAULT NULL,
  `durum`           VARCHAR(30)   DEFAULT 'acik' COMMENT 'acik,islemde,kapali,gecikmiş',
  `etkinlik_degerlendirme` TEXT,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `olusturan_id`    INT           DEFAULT NULL,
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 20. SEVKİYAT — İRSALİYELER
-- ============================================================
CREATE TABLE IF NOT EXISTS `irsaliyeler` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `irsaliye_no`     VARCHAR(30)   NOT NULL UNIQUE,
  `musteri_id`      INT           NOT NULL,
  `siparis_id`      INT           DEFAULT NULL,
  `tarih`           DATE          NOT NULL,
  `teslim_tarihi`   DATE          DEFAULT NULL,
  `teslim_saati`    TIME          DEFAULT NULL,
  `durum`           VARCHAR(30)   DEFAULT 'hazirlaniyor' COMMENT 'hazirlaniyor,yuklendi,yolda,teslimde,teslim,iade',
  `arac_plaka`      VARCHAR(20)   DEFAULT NULL,
  `surucu_adi`      VARCHAR(100)  DEFAULT NULL,
  `surucu_tel`      VARCHAR(20)   DEFAULT NULL,
  `agirlik_kg`      DECIMAL(10,3) DEFAULT NULL,
  `irsaliye_turu`   VARCHAR(20)   DEFAULT 'cikis' COMMENT 'cikis,giris,iade',
  `notlar`          TEXT,
  `logo_ref`        VARCHAR(50)   DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_musteri` (`musteri_id`),
  INDEX `idx_durum` (`durum`),
  INDEX `idx_tarih` (`tarih`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 21. MÜŞTERİ STOK TANIMLARI (Müşteri portal için)
-- ============================================================
CREATE TABLE IF NOT EXISTS `musteri_stok_tanimlari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `musteri_id`      INT           NOT NULL,
  `urun_id`         INT           NOT NULL,
  `musteri_urun_kodu` VARCHAR(50) DEFAULT NULL COMMENT 'Müşterinin kendi kodu',
  `musteri_urun_adi`  VARCHAR(300) DEFAULT NULL,
  `min_stok_uyari`  DECIMAL(12,3) DEFAULT 0 COMMENT 'Bu seviyenin altında uyarı ver',
  `aktif`           TINYINT(1)   DEFAULT 1,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_musteri_urun` (`musteri_id`,`urun_id`),
  INDEX `idx_musteri` (`musteri_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 22. BİLDİRİMLER
-- ============================================================
CREATE TABLE IF NOT EXISTS `bildirimler` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `kullanici_id`    INT           DEFAULT NULL COMMENT 'NULL = tüm kullanıcılar',
  `portal_tipi`     VARCHAR(20)   DEFAULT 'erp' COMMENT 'erp,personel,musteri',
  `baslik`          VARCHAR(300)  NOT NULL,
  `mesaj`           TEXT,
  `tip`             VARCHAR(20)   DEFAULT 'bilgi' COMMENT 'bilgi,uyari,hata,basari',
  `modul`           VARCHAR(50)   DEFAULT NULL,
  `link`            VARCHAR(300)  DEFAULT NULL,
  `okundu`          TINYINT(1)    DEFAULT 0,
  `okunma_tarihi`   DATETIME      DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_kullanici` (`kullanici_id`),
  INDEX `idx_okundu` (`okundu`),
  INDEX `idx_portal` (`portal_tipi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- 23. GEOFENCE LOKASYONLARI (Personel Portal)
-- ============================================================
CREATE TABLE IF NOT EXISTS `geofence_lokasyonlari` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `ad`              VARCHAR(150)  NOT NULL,
  `aciklama`        VARCHAR(300)  DEFAULT NULL,
  `lat`             DECIMAL(10,8) NOT NULL,
  `lng`             DECIMAL(11,8) NOT NULL,
  `yaricap_metre`   INT           DEFAULT 200,
  `aktif`           TINYINT(1)   DEFAULT 1,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `geofence_lokasyonlari` (`ad`,`lat`,`lng`,`yaricap_metre`) VALUES
('Ana Fabrika', 41.01500000, 28.97500000, 200),
('Depo Binası', 41.01450000, 28.97450000, 150),
('Ofis Binası', 41.01550000, 28.97550000, 100);

-- ============================================================
-- 24. SATINALMA — TALEPLERİ
-- ============================================================
CREATE TABLE IF NOT EXISTS `satinalma_talepleri` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `talep_no`        VARCHAR(30)   NOT NULL UNIQUE,
  `urun_id`         INT           DEFAULT NULL,
  `urun_adi`        VARCHAR(300)  DEFAULT NULL,
  `miktar`          DECIMAL(12,3) NOT NULL,
  `birim`           VARCHAR(20)   DEFAULT 'adet',
  `talep_eden_id`   INT           DEFAULT NULL,
  `departman_id`    INT           DEFAULT NULL,
  `ihtiyac_tarihi`  DATE          DEFAULT NULL,
  `aciklama`        TEXT,
  `durum`           VARCHAR(30)   DEFAULT 'bekliyor' COMMENT 'bekliyor,onaylandi,sipariste,teslim,iptal',
  `onaylayan_id`    INT           DEFAULT NULL,
  `onay_tarihi`     DATETIME      DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_durum` (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- ÖZET
-- ============================================================
SELECT 'Veritabanı başarıyla oluşturuldu!' AS mesaj,
       COUNT(*) AS tablo_sayisi
FROM information_schema.tables
WHERE table_schema = 'jetone_pro';

-- ============================================================
-- 25. YEDEKLEMELERİ YÖNETİM TABLOSU
-- ============================================================
CREATE TABLE IF NOT EXISTS `yedekleme_kayitlari` (
  `id`               INT AUTO_INCREMENT PRIMARY KEY,
  `prefix`           VARCHAR(50)   NOT NULL,
  `tarih`            DATETIME      NOT NULL,
  `tip`              VARCHAR(20)   NOT NULL COMMENT 'tam,veritabani,dosyalar',
  `sure_sn`          DECIMAL(8,2)  DEFAULT NULL,
  `basarili_adimlar` JSON          DEFAULT NULL,
  `hatalar`          JSON          DEFAULT NULL,
  `boyut`            VARCHAR(20)   DEFAULT NULL,
  `durum`            VARCHAR(20)   NOT NULL DEFAULT 'basarili' COMMENT 'basarili,kismi,basarisiz',
  `notlar`           TEXT,
  `olusturma`        DATETIME      DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_tarih`  (`tarih`),
  INDEX `idx_durum`  (`durum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- Ayarlar Key-Value tablosu (mail, sistem ayarları için)
-- ============================================================
CREATE TABLE IF NOT EXISTS `ayarlar_kv` (
  `id`       INT AUTO_INCREMENT PRIMARY KEY,
  `anahtar`  VARCHAR(100) NOT NULL UNIQUE,
  `deger`    TEXT,
  `guncelleme` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Öneri & Şikayet Sistemi
-- ============================================================
CREATE TABLE IF NOT EXISTS `oneri_sikayet` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `personel_id`     INT           NOT NULL,
  `tip`             ENUM('oneri','sikayet','dilek') NOT NULL DEFAULT 'oneri',
  `konu`            VARCHAR(200)  NOT NULL,
  `aciklama`        TEXT          NOT NULL,
  `durum`           ENUM('bekliyor','incelemede','onaylandi','reddedildi','uygulandı') DEFAULT 'bekliyor',
  `oncelik`         ENUM('dusuk','normal','yuksek') DEFAULT 'normal',
  `anonim`          TINYINT(1)    DEFAULT 0,
  `odül_hakki`      TINYINT(1)    DEFAULT 0  COMMENT 'Oneri odulune hak kazandi mi',
  `odül_tutari`     DECIMAL(10,2) DEFAULT 0,
  `inceleme_notu`   TEXT,
  `inceleme_tarihi` DATETIME      DEFAULT NULL,
  `inceleyici_id`   INT           DEFAULT NULL,
  `olusturma`       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_personel` (`personel_id`),
  INDEX `idx_durum`    (`durum`),
  INDEX `idx_tip`      (`tip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ----------------------------------------------------------------
-- 2. Menü Tabloları
-- Kaynak: menu_tablo_olustur.sql
-- ----------------------------------------------------------------

-- Menu grupları ve sayfaları
CREATE TABLE IF NOT EXISTS `menu_gruplar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modul` varchar(50) NOT NULL COMMENT 'depo,satis,satinalma,planlama,raporlar,ayarlar',
  `ad` varchar(100) NOT NULL,
  `sira` int DEFAULT '0',
  `aktif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

CREATE TABLE IF NOT EXISTS `menu_sayfalar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grup_id` int NOT NULL,
  `ikon` varchar(10) DEFAULT '📄',
  `ad` varchar(100) NOT NULL,
  `sayfa_id` varchar(100) NOT NULL COMMENT 'panel.php?sayfa= değeri',
  `sira` int DEFAULT '0',
  `aktif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `grup_id` (`grup_id`),
  CONSTRAINT `fk_menu_grup` FOREIGN KEY (`grup_id`) REFERENCES `menu_gruplar` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

CREATE TABLE IF NOT EXISTS `menu_rol_yetki` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rol_id` int NOT NULL,
  `sayfa_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rol_sayfa` (`rol_id`,`sayfa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- DEPO MENÜSÜ
INSERT INTO `menu_gruplar` (`modul`,`ad`,`sira`) VALUES
('depo','SEVKİYAT',1),
('depo','SİPARİŞLER',2),
('depo','STOK',3),
('depo','SAYIM',4),
('depo','ANALİZ',5);

-- SEVKİYAT grubu (id=1)
INSERT INTO `menu_sayfalar` (`grup_id`,`ikon`,`ad`,`sayfa_id`,`sira`) VALUES
(1,'📊','Dashboard','depo-sevkiyat-dashboard',1),
(1,'🚚','Sevkiyat','depo-sevkiyat',2),
(1,'📄','İrsaliyeler','depo-irsaliye',3);

-- SİPARİŞLER grubu (id=2)
INSERT INTO `menu_sayfalar` (`grup_id`,`ikon`,`ad`,`sayfa_id`,`sira`) VALUES
(2,'🛒','Sipariş Listesi','depo-siparis',1),
(2,'⚡','JIT / KMI Listesi','depo-jit',2);

-- STOK grubu (id=3)
INSERT INTO `menu_sayfalar` (`grup_id`,`ikon`,`ad`,`sayfa_id`,`sira`) VALUES
(3,'📦','Stok Raporu','depo-stok',1),
(3,'📍','Adresli Stok','depo-adresli-stok',2),
(3,'📋','Paketler','depo-paketler',3);

-- SAYIM grubu (id=4)
INSERT INTO `menu_sayfalar` (`grup_id`,`ikon`,`ad`,`sayfa_id`,`sira`) VALUES
(4,'🔇','Paket Pasif Et','depo-paket-pasif',1),
(4,'📱','Paket Sayım','depo-paket-sayim',2),
(4,'⚖️','Logo-MES Farkı','depo-stok-farki',3);

-- ANALİZ grubu (id=5)
INSERT INTO `menu_sayfalar` (`grup_id`,`ikon`,`ad`,`sayfa_id`,`sira`) VALUES
(5,'↕','Stok Hareketleri','depo-hareketler',1),
(5,'📦','Paket Hareketleri','depo-paket-hareketler',2),
(5,'📟','Terminal Kullanım','depo-terminal',3);

-- ----------------------------------------------------------------
-- 3. Sipariş Tabloları
-- Kaynak: siparis_tablo_olustur.sql
-- ----------------------------------------------------------------

-- Sipariş tablosu (örnek ERP'den uyarlanmış)
CREATE TABLE IF NOT EXISTS `siparis` (
  `sip_id`            INT AUTO_INCREMENT PRIMARY KEY,
  `sip_no`            VARCHAR(50)    DEFAULT NULL COMMENT 'Sipariş/irsaliye referans no',
  `sip_kodu`          VARCHAR(100)   NOT NULL     COMMENT 'Malzeme/ürün kodu',
  `sip_baslik`        VARCHAR(300)   DEFAULT NULL COMMENT 'Ürün adı/başlık',
  `sip_teslim_tarihi` DATE           DEFAULT NULL,
  `sip_tarihi`        DATE           DEFAULT CURRENT_TIMESTAMP,
  `sip_baslama_tarih` DATE           DEFAULT NULL COMMENT 'Sevk başlama/gerçekleşme tarihi',
  `sip_miktar`        DECIMAL(14,2)  DEFAULT 0,
  `sip_sevk_miktari`  DECIMAL(14,2)  DEFAULT 0,
  `son_irsaliye_no`   VARCHAR(50)    DEFAULT NULL,
  `son_irsaliye_2`    VARCHAR(50)    DEFAULT NULL,
  `musteri_firma_adi` VARCHAR(255)   DEFAULT NULL,
  `sip_aciliyet`      VARCHAR(20)    DEFAULT 'Normal' COMMENT 'Normal,Acil,Kritik',
  `sip_durum`         VARCHAR(50)    DEFAULT 'Yeni'   COMMENT 'Yeni,Devam,Bitti',
  `sip_statu`         VARCHAR(20)    DEFAULT 'Aktif'  COMMENT 'Aktif,Tamamlandı,Pasif,İptal',
  `gecikme_nedeni`    TEXT           DEFAULT NULL,
  `sip_detay`         TEXT           DEFAULT NULL,
  `sip_ucret`         DECIMAL(14,2)  DEFAULT 0,
  `dosya_yolu`        VARCHAR(500)   DEFAULT NULL,
  `ekleyen`           VARCHAR(100)   DEFAULT NULL,
  `guncelleyen`       VARCHAR(100)   DEFAULT NULL,
  `olusturma`         DATETIME       DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`        DATETIME       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_kodu`    (`sip_kodu`),
  INDEX `idx_statu`   (`sip_statu`),
  INDEX `idx_musteri` (`musteri_firma_adi`),
  INDEX `idx_teslim`  (`sip_teslim_tarihi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ----------------------------------------------------------------
-- 4. Sefer Tabloları
-- Kaynak: seferler_tablo.sql
-- ----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `seferler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tarih` date NOT NULL,
  `sofor_adi` varchar(100) DEFAULT NULL,
  `sofor_tel` varchar(20) DEFAULT NULL,
  `plaka` varchar(20) DEFAULT NULL,
  `durum` varchar(30) DEFAULT 'Planlandı',
  `notlar` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sefer_noktalari` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sefer_id` int NOT NULL,
  `sira` int DEFAULT 1,
  `firma_adi` varchar(255) DEFAULT NULL,
  `adres` text,
  `notlar` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sefer_id` (`sefer_id`),
  CONSTRAINT `sefer_noktalari_ibfk_1` FOREIGN KEY (`sefer_id`) REFERENCES `seferler` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------
-- 5. İrsaliye Tabloları
-- Kaynak: bolumler/satis/irsaliye_tablo_olustur.sql
-- ----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `dusulen_irsaliyeler` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `irsaliye_no`  VARCHAR(50) NOT NULL,
  `firma`        VARCHAR(255) DEFAULT '',
  `durum`        ENUM('aktif','iptal') DEFAULT 'aktif',
  `olusturan_id` INT DEFAULT 0,
  `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  `guncelleme`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_irsaliye` (`irsaliye_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ----------------------------------------------------------------
-- 6. Personel Tablo Güncellemeleri
-- Kaynak: personel_tablo_guncelle.sql
-- ----------------------------------------------------------------

-- ================================================================
-- Enjeksiyon: norm_hat_atamalari tablosuna personel kolonu ekle
-- ================================================================
ALTER TABLE norm_hat_atamalari 
  ADD COLUMN IF NOT EXISTS personel TINYINT UNSIGNED NOT NULL DEFAULT 1 
  COMMENT 'Hat başına vardiya personel sayısı';

-- ================================================================
-- Montaj: hat bazlı norm personel tablosu
-- ================================================================
CREATE TABLE IF NOT EXISTS montaj_hat_personel (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  hat_kodu    VARCHAR(100) NOT NULL,
  norm_pers   TINYINT UNSIGNED NOT NULL DEFAULT 1,
  vardiya     TINYINT UNSIGNED NOT NULL DEFAULT 1,
  notlar      VARCHAR(255) DEFAULT NULL,
  guncelleyen VARCHAR(100) DEFAULT NULL,
  guncelleme  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_hat (hat_kodu)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO montaj_hat_personel (hat_kodu, norm_pers, vardiya) VALUES
  ('EL İŞÇİLİĞİ 1',3,3),('EL İŞÇİLİĞİ 2',1,1),('EL İŞÇİLİĞİ 3',1,1),('EL İŞÇİLİĞİ 4',1,1),
  ('EL İŞÇİLİĞİ 5',3,3),('EL İŞÇİLİĞİ 6',4,1),('EL İŞÇİLİĞİ 6.1',6,1),('EL İŞÇİLİĞİ 6.2',8,1),
  ('EL İŞÇİLİĞİ 6.3',4,1),('EL İŞÇİLİĞİ 6.4',2,1),('EL İŞÇİLİĞİ 7',9,1),('EL İŞÇİLİĞİ 7.1',2,1),
  ('EL İŞÇİLİĞİ 8',4,1),('EL İŞÇİLİĞİ 8.1',4,1),('EL İŞÇİLİĞİ 8.2',2,1),
  ('EL İŞÇİLİĞİ 9',6,3),('EL İŞÇİLİĞİ 10',5,3),('MT-01',1,3),
  ('SR-01',1,1),('FSN-01',1,1),('KRM-01',1,1),('TERM-01',1,1)
ON DUPLICATE KEY UPDATE norm_pers=VALUES(norm_pers), vardiya=VALUES(vardiya);

-- EL İŞÇİLİĞİ 6.4 kaldır
DELETE FROM montaj_hat_personel WHERE hat_kodu = 'EL İŞÇİLİĞİ 6.4';

-- ----------------------------------------------------------------
-- 7. Alter Güncellemeleri
-- Kaynak: alter_guncelle.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO — Güvenli Tablo Güncelleme
-- alter_guncelle.sql
--
-- IF NOT EXISTS kullanmaz — tüm MySQL sürümleriyle çalışır
-- phpMyAdmin > SQL sekmesine yapıştırın > Çalıştır
-- ============================================================

USE `jetone_pro`;

-- ─────────────────────────────────────────────────────────
-- sistem_loglar tablosuna tablo_adi kolonu ekle
-- Kolon zaten varsa hata verir ama devam eder (IGNORE ile)
-- ─────────────────────────────────────────────────────────

-- Önce kolonun var olup olmadığını kontrol et
-- Yoksa ekle (stored procedure olmadan güvenli yol)
SET @kolon_var = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'sistem_loglar'
      AND COLUMN_NAME  = 'tablo_adi'
);

-- Dinamik SQL ile sadece yoksa ekle
SET @sql = IF(@kolon_var = 0,
    'ALTER TABLE `sistem_loglar` ADD COLUMN `tablo_adi` VARCHAR(80) DEFAULT NULL AFTER `modul`',
    'SELECT "tablo_adi kolonu zaten var, atlanıyor" AS bilgi'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ─────────────────────────────────────────────────────────
-- Kontrol: tablo yapısını göster
-- ─────────────────────────────────────────────────────────
DESCRIBE `sistem_loglar`;

-- ----------------------------------------------------------------
-- 8. Şifre Güncellemeleri
-- Kaynak: sifre_guncelle.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO — Şifre Güncelleme + Örnek Veriler
-- sifre_guncelle.sql
--
-- Bu dosyadaki tüm hash'lar Python bcrypt ile üretilip
-- doğrulanmıştır. PHP password_verify() ile çalışır.
--
-- KULLANIM:
--   phpMyAdmin'de bu dosyayı import edin
--   VEYA terminalde: mysql -u root jetone_pro < sifre_guncelle.sql
-- ============================================================

USE `jetone_pro`;

-- ════════════════════════════════════════════════════════════
-- ADIM 0: sistem_loglar tablosuna eksik kolon ekle
-- ════════════════════════════════════════════════════════════
ALTER TABLE `sistem_loglar`
  ADD COLUMN IF NOT EXISTS `tablo_adi` VARCHAR(80) DEFAULT NULL AFTER `modul`;

-- ════════════════════════════════════════════════════════════
-- ADIM 1: ERP Kullanıcı Şifreleri
-- ════════════════════════════════════════════════════════════
-- Şifre: Admin123!
-- Hash doğrulandı: password_verify('Admin123!', hash) = true
UPDATE `kullanicilar`
SET
    `ad`        = 'Süper',
    `soyad`     = 'Admin',
    `rol_id`    = 1,
    `durum`     = 1,
    `sifre_hash`= '$2y$12$Gv8Q78h0ATlWNXxS6LORc.g7mccBidOyN.rX3W7dtTQ304/n76EAW'
WHERE `email` = 'admin@jetone.pro';

-- Eğer admin kaydı yoksa ekle
INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`rol_id`,`durum`)
SELECT 'Süper','Admin','admin@jetone.pro',
       '$2y$12$Gv8Q78h0ATlWNXxS6LORc.g7mccBidOyN.rX3W7dtTQ304/n76EAW',
       1, 1
WHERE NOT EXISTS (SELECT 1 FROM `kullanicilar` WHERE `email`='admin@jetone.pro');

-- Diğer ERP kullanıcıları — Şifre: Jetone2024!
-- Hash: $2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i
INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`rol_id`,`departman_id`,`pozisyon`,`durum`)
VALUES
('Ayşe',   'Yılmaz', 'ayse.yilmaz@jetone.pro',  '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i', 1, 1, 'Sistem Yöneticisi', 1),
('Mehmet', 'Kaya',   'mehmet.kaya@jetone.pro',   '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i', 2, 2, 'İK Müdürü',         1),
('Fatma',  'Şahin',  'fatma.sahin@jetone.pro',   '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i', 3, 5, 'Üretim Şefi',       1),
('Ali',    'Demir',  'ali.demir@jetone.pro',      '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i', 4, 8, 'Satınalma Uzmanı',  1),
('Zeynep', 'Arslan', 'zeynep.arslan@jetone.pro',  '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i', 5, 4, 'Satış Temsilcisi',  1)
ON DUPLICATE KEY UPDATE
    `sifre_hash` = '$2y$12$Y7h1u8qRmdwSAY6kmPYUwuECYb05GYgT.cNkrQvPIisJDWRoNF/1i',
    `durum` = 1;

-- ════════════════════════════════════════════════════════════
-- ADIM 2: Personeller
-- ════════════════════════════════════════════════════════════
INSERT INTO `personeller`
  (`sicil_no`,`ad`,`soyad`,`tc_kimlik`,`dogum_tarihi`,`cinsiyet`,
   `departman_id`,`pozisyon`,`telefon`,`email`,
   `ise_baslama`,`calısma_tipi`,`durum`,`maas`)
VALUES
('P-00001','Ahmet',   'Kaya',    '12345678901','1988-05-12',1, 5,'Üretim Operatörü',    '0532 111 0001','ahmet.kaya@firma.com',    '2019-03-01','tam_zamanli','aktif', 18500.00),
('P-00002','Mustafa', 'Çelik',   '12345678902','1990-07-22',1, 5,'CNC Operatörü',       '0532 111 0002','mustafa.celik@firma.com',  '2020-06-15','tam_zamanli','aktif', 20000.00),
('P-00003','Hasan',   'Yıldız',  '12345678903','1985-11-03',1, 5,'Vardiya Şefi',        '0532 111 0003','hasan.yildiz@firma.com',   '2017-01-10','tam_zamanli','aktif', 28000.00),
('P-00004','İbrahim', 'Öztürk',  '12345678904','1992-03-18',1, 5,'Bakım Teknisyeni',    '0532 111 0004','ibrahim.ozturk@firma.com', '2021-09-01','tam_zamanli','aktif', 22000.00),
('P-00005','Emre',    'Yılmaz',  '12345678905','1995-08-25',1, 5,'Üretim Operatörü',    '0532 111 0005','emre.yilmaz@firma.com',    '2022-02-14','tam_zamanli','aktif', 17500.00),
('P-00006','Fatma',   'Şahin',   '12345678906','1987-02-14',2, 2,'İK Uzmanı',           '0532 111 0006','fatma.sahin.ik@firma.com', '2018-07-01','tam_zamanli','aktif', 32000.00),
('P-00007','Elif',    'Koca',    '12345678907','1993-12-30',2, 2,'İK Asistanı',         '0532 111 0007','elif.koca@firma.com',      '2022-04-01','tam_zamanli','aktif', 22000.00),
('P-00008','Selin',   'Aydın',   '12345678908','1989-09-07',2, 7,'Kalite Uzmanı',       '0532 111 0008','selin.aydin@firma.com',    '2019-11-15','tam_zamanli','aktif', 27000.00),
('P-00009','Burak',   'Güneş',   '12345678909','1991-04-21',1, 7,'Kalite Kontrol',      '0532 111 0009','burak.gunes@firma.com',    '2020-08-01','tam_zamanli','aktif', 24000.00),
('P-00010','Murat',   'Doğan',   '12345678910','1986-06-15',1, 6,'Depo Sorumlusu',      '0532 111 0010','murat.dogan@firma.com',    '2018-01-15','tam_zamanli','aktif', 25000.00),
('P-00011','Kadir',   'Arslan',  '12345678911','1994-01-28',1, 6,'Depo Görevlisi',      '0532 111 0011','kadir.arslan@firma.com',   '2021-05-01','tam_zamanli','aktif', 19000.00),
('P-00012','Serkan',  'Kılıç',   '12345678912','1997-10-11',1, 6,'Forklift Operatörü',  '0532 111 0012','serkan.kilic@firma.com',   '2023-01-09','tam_zamanli','aktif', 18000.00),
('P-00013','Zeynep',  'Arslan',  '12345678913','1990-03-05',2, 4,'Satış Uzmanı',        '0532 111 0013','zeynep.arslan.s@firma.com','2019-05-01','tam_zamanli','aktif', 30000.00),
('P-00014','Berk',    'Özkan',   '12345678914','1988-07-19',1, 4,'Satış Müdürü',        '0532 111 0014','berk.ozkan@firma.com',     '2016-09-01','tam_zamanli','aktif', 45000.00),
('P-00015','Büşra',   'Yılmaz',  '12345678915','1992-11-22',2, 3,'Muhasebe Uzmanı',     '0532 111 0015','busra.yilmaz@firma.com',   '2020-10-01','tam_zamanli','aktif', 34000.00)
ON DUPLICATE KEY UPDATE `durum`='aktif';

-- ════════════════════════════════════════════════════════════
-- ADIM 3: Müşteriler
-- ════════════════════════════════════════════════════════════
INSERT INTO `musteriler`
  (`kod`,`ad`,`tip`,`vergi_no`,`telefon`,`email`,`il`,`ilce`,
   `yetkili_adi`,`yetkili_tel`,`yetkili_email`,`odeme_vadesi`,`durum`)
VALUES
('ABC-001','ABC Plastik Sanayi A.Ş.','kurumsal','1234567890','0216 555 0001','info@abcplastik.com','İstanbul','Ümraniye','Ahmet Polat','0532 222 0001','ahmet.polat@abcplastik.com',30,'aktif'),
('DEF-002','Demir Endüstri Ltd.',    'kurumsal','2345678901','0312 555 0002','info@demirend.com',  'Ankara','Yenimahalle','Cemal Demir','0533 222 0002','cemal@demirend.com',45,'aktif'),
('XYZ-003','XYZ Makine Sanayi',      'kurumsal','3456789012','0224 555 0003','info@xyzmakine.com', 'Bursa','Nilüfer','Selim Yıldız','0534 222 0003','selim@xyzmakine.com',30,'aktif'),
('TRK-004','Türk Metal A.Ş.',        'kurumsal','4567890123','0212 555 0004','info@turkmetal.com', 'İstanbul','Başakşehir','Ferhat Türk','0535 222 0004','ferhat@turkmetal.com',60,'aktif'),
('PLS-005','Polimer Plastik Ltd.',   'kurumsal','5678901234','0236 555 0005','info@polimer.com',   'Manisa','Yunusemre','Kahraman Polimer','0536 222 0005','kahraman@polimer.com',30,'aktif')
ON DUPLICATE KEY UPDATE `durum`='aktif';

-- ════════════════════════════════════════════════════════════
-- ADIM 4: Ürünler
-- ════════════════════════════════════════════════════════════
INSERT INTO `urunler` (`kod`,`ad`,`kategori`,`birim`,`birim_fiyat`,`stok_miktari`,`min_stok`,`max_stok`)
VALUES
('PRD-K200','Plastik Kapak 200mm','Plastik Ürünler','adet',  12.50, 2450, 500,  5000),
('PRD-B045','Metal Braket X45',   'Metal Parçalar', 'adet',  45.00,  180, 200,  2000),
('PRD-G012','Gövde Ürünü B12',    'Gövde',          'adet', 125.00,    0, 100,  1000),
('PRD-M007','Montaj Parçası C7',  'Montaj',         'adet',   8.75, 5800,1000, 10000),
('PRD-V055','Vida Seti 55mm',     'Bağlantı',       'paket',  3.20,12000,2000, 20000),
('PRD-H100','Hidrolik Silindir',  'Hidrolik',       'adet', 850.00,   45,  20,   200),
('PRD-F030','Filtre Kartuşu 30',  'Filtre',         'adet',  28.00,  320, 100,   800)
ON DUPLICATE KEY UPDATE `stok_miktari`=VALUES(`stok_miktari`);

-- ════════════════════════════════════════════════════════════
-- ADIM 5: Satış Siparişleri
-- ════════════════════════════════════════════════════════════
INSERT INTO `satis_siparisleri`
  (`siparis_no`,`musteri_id`,`tarih`,`teslim_tarihi`,`durum`,
   `toplam_tutar`,`kdv_orani`,`kdv_tutari`,`genel_toplam`)
SELECT * FROM (
  SELECT 'SP-2024-001',(SELECT id FROM musteriler WHERE kod='ABC-001'),DATE_SUB(CURDATE(),INTERVAL 30 DAY),DATE_SUB(CURDATE(),INTERVAL 15 DAY),'teslim',   35000.00,20,7000.00, 42000.00 UNION ALL
  SELECT 'SP-2024-002',(SELECT id FROM musteriler WHERE kod='DEF-002'),DATE_SUB(CURDATE(),INTERVAL 20 DAY),DATE_SUB(CURDATE(),INTERVAL 5  DAY),'teslim',   18500.00,20,3700.00, 22200.00 UNION ALL
  SELECT 'SP-2024-003',(SELECT id FROM musteriler WHERE kod='XYZ-003'),DATE_SUB(CURDATE(),INTERVAL 15 DAY),DATE_ADD(CURDATE(),INTERVAL 5  DAY),'uretimde', 67000.00,20,13400.00,80400.00 UNION ALL
  SELECT 'SP-2024-004',(SELECT id FROM musteriler WHERE kod='TRK-004'),DATE_SUB(CURDATE(),INTERVAL 10 DAY),DATE_ADD(CURDATE(),INTERVAL 3  DAY),'sevkiyatta',22500.00,20,4500.00, 27000.00 UNION ALL
  SELECT 'SP-2024-005',(SELECT id FROM musteriler WHERE kod='ABC-001'),DATE_SUB(CURDATE(),INTERVAL 5  DAY),DATE_ADD(CURDATE(),INTERVAL 10 DAY),'onaylandi', 45200.00,20,9040.00, 54240.00 UNION ALL
  SELECT 'SP-2024-006',(SELECT id FROM musteriler WHERE kod='PLS-005'),CURDATE(),DATE_ADD(CURDATE(),INTERVAL 20 DAY),'bekliyor',  12800.00,20,2560.00, 15360.00
) t ON DUPLICATE KEY UPDATE `durum`=VALUES(`durum`);

-- ════════════════════════════════════════════════════════════
-- ADIM 6: İrsaliyeler
-- ════════════════════════════════════════════════════════════
INSERT INTO `irsaliyeler`
  (`irsaliye_no`,`musteri_id`,`tarih`,`teslim_tarihi`,`durum`,`arac_plaka`,`surucu_adi`,`surucu_tel`)
SELECT * FROM (
  SELECT 'IRS-2024-001',(SELECT id FROM musteriler WHERE kod='ABC-001'),DATE_SUB(CURDATE(),INTERVAL 18 DAY),DATE_SUB(CURDATE(),INTERVAL 15 DAY),'teslim', '34 ABC 001','Ahmet Şoför','0532 333 0001' UNION ALL
  SELECT 'IRS-2024-002',(SELECT id FROM musteriler WHERE kod='DEF-002'),DATE_SUB(CURDATE(),INTERVAL 8  DAY),DATE_SUB(CURDATE(),INTERVAL 5  DAY),'teslim', '06 DEF 002','Veli Şoför', '0533 333 0002' UNION ALL
  SELECT 'IRS-2024-003',(SELECT id FROM musteriler WHERE kod='TRK-004'),DATE_SUB(CURDATE(),INTERVAL 2  DAY),DATE_ADD(CURDATE(),INTERVAL 1  DAY),'yolda',  '41 XYZ 003','Hasan Şoför','0534 333 0003' UNION ALL
  SELECT 'IRS-2024-004',(SELECT id FROM musteriler WHERE kod='XYZ-003'),CURDATE(),DATE_ADD(CURDATE(),INTERVAL 5 DAY),'yuklendi','16 TRK 004','Mehmet Şoför','0535 333 0004'
) t ON DUPLICATE KEY UPDATE `durum`=VALUES(`durum`);

-- ════════════════════════════════════════════════════════════
-- ADIM 7: Müşteri Stok Tanımları
-- ════════════════════════════════════════════════════════════
INSERT INTO `musteri_stok_tanimlari`
  (`musteri_id`,`urun_id`,`musteri_urun_kodu`,`musteri_urun_adi`,`min_stok_uyari`,`aktif`)
SELECT m.id, u.id, CONCAT(m.kod,'-',u.kod), u.ad, u.min_stok, 1
FROM musteriler m, urunler u
WHERE m.kod IN ('ABC-001','DEF-002','XYZ-003')
  AND u.kod IN ('PRD-K200','PRD-B045','PRD-G012','PRD-M007','PRD-H100','PRD-F030')
ON DUPLICATE KEY UPDATE `aktif`=1;

-- ════════════════════════════════════════════════════════════
-- ADIM 8: İzin Talepleri
-- ════════════════════════════════════════════════════════════
INSERT INTO `izin_talepleri`
  (`personel_id`,`izin_turu`,`baslangic`,`bitis`,`gun_sayisi`,`aciklama`,`durum`)
VALUES
(1,'yillik',  DATE_ADD(CURDATE(),INTERVAL 7  DAY),DATE_ADD(CURDATE(),INTERVAL 11 DAY),5,'Yıllık izin','bekliyor'),
(2,'hastalik',DATE_SUB(CURDATE(),INTERVAL 3  DAY),DATE_SUB(CURDATE(),INTERVAL 1  DAY),2,'Doktor raporu mevcut','onaylandi'),
(3,'mazeret', DATE_ADD(CURDATE(),INTERVAL 2  DAY),DATE_ADD(CURDATE(),INTERVAL 2  DAY),1,'Resmi işlem','bekliyor'),
(6,'yillik',  DATE_ADD(CURDATE(),INTERVAL 14 DAY),DATE_ADD(CURDATE(),INTERVAL 18 DAY),5,'Yaz tatili','bekliyor');

-- ════════════════════════════════════════════════════════════
-- ADIM 9: PORTAL KULLANICILARI — Doğrulanmış Hash'lar
-- ════════════════════════════════════════════════════════════
--
-- ╔═══════════════════════════════════════════════════════════╗
-- ║           PERSONEL PORTAL GİRİŞ BİLGİLERİ               ║
-- ║  URL: localhost:4459/jetone_pro/portal/personel/giris.php║
-- ╠══════════════════╦══════════════╦════════════════════════╣
-- ║ Personel         ║ Kullanıcı Adı║ Şifre                  ║
-- ╠══════════════════╬══════════════╬════════════════════════╣
-- ║ Ahmet Kaya       ║ P-00001      ║ Personel2024!          ║
-- ║ Mustafa Çelik    ║ P-00002      ║ Personel2024!          ║
-- ║ Hasan Yıldız     ║ P-00003      ║ Personel2024!          ║
-- ║ Fatma Şahin      ║ P-00006      ║ Personel2024!          ║
-- ║ Büşra Yılmaz     ║ P-00015      ║ Personel2024!          ║
-- ╚══════════════════╩══════════════╩════════════════════════╝
--
-- ╔═══════════════════════════════════════════════════════════╗
-- ║           MÜŞTERİ PORTAL GİRİŞ BİLGİLERİ                ║
-- ║  URL: localhost:4459/jetone_pro/portal/musteri/giris.php  ║
-- ╠════════════════════════╦═══════════╦════════════════════╣
-- ║ Müşteri                ║ Kodu      ║ Şifre              ║
-- ╠════════════════════════╬═══════════╬════════════════════╣
-- ║ ABC Plastik Sanayi A.Ş.║ ABC-001   ║ Musteri2024!       ║
-- ║ Demir Endüstri Ltd.    ║ DEF-002   ║ Musteri2024!       ║
-- ║ XYZ Makine Sanayi      ║ XYZ-003   ║ Musteri2024!       ║
-- ║ Türk Metal A.Ş.        ║ TRK-004   ║ Musteri2024!       ║
-- ╚════════════════════════╩═══════════╩════════════════════╝
--
-- ╔═══════════════════════════════════════════════════════════╗
-- ║           ERP YÖNETİM PANELİ GİRİŞ                      ║
-- ║  URL: localhost:4459/jetone_pro/giris.php                 ║
-- ╠══════════════════════════╦════════════════════════════════╣
-- ║ E-posta                  ║ Şifre                         ║
-- ╠══════════════════════════╬════════════════════════════════╣
-- ║ admin@jetone.pro         ║ Admin123!                      ║
-- ║ ayse.yilmaz@jetone.pro   ║ Jetone2024!                   ║
-- ║ mehmet.kaya@jetone.pro   ║ Jetone2024!                   ║
-- ╚══════════════════════════╩════════════════════════════════╝

-- Önce mevcut portal kullanıcılarını temizle
DELETE FROM `portal_kullanicilari`;

-- Personel portal hash: password_verify('Personel2024!', hash) = DOĞRULANDI ✓
INSERT INTO `portal_kullanicilari`
  (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`)
SELECT
  'personel',
  p.id,
  p.sicil_no,
  p.email,
  '$2y$12$Dq8Ru9jXLw/uo8ETcZIGTuRRp1fbu47IyNDVSLkTZ8wg5.R1bFqG6',
  CONCAT(p.ad, ' ', p.soyad),
  p.telefon,
  1
FROM `personeller` p
WHERE p.sicil_no IN ('P-00001','P-00002','P-00003','P-00006','P-00015');

-- Müşteri portal hash: password_verify('Musteri2024!', hash) = DOĞRULANDI ✓
INSERT INTO `portal_kullanicilari`
  (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`)
SELECT
  'musteri',
  m.id,
  m.kod,
  m.yetkili_email,
  '$2y$12$AgoflaUiiiM1NQEiXl3lQOsue8e0PtUgFn6vki0gNL3lH5bA5niqe',
  m.yetkili_adi,
  m.yetkili_tel,
  1
FROM `musteriler` m
WHERE m.kod IN ('ABC-001','DEF-002','XYZ-003','TRK-004');

-- ════════════════════════════════════════════════════════════
-- ADIM 10: Bildirimler
-- ════════════════════════════════════════════════════════════
DELETE FROM `bildirimler`;
INSERT INTO `bildirimler` (`kullanici_id`,`portal_tipi`,`baslik`,`mesaj`,`tip`,`modul`) VALUES
(NULL,'erp','📋 Yeni İzin Talebi',     'Ahmet Kaya 5 günlük yıllık izin talebinde bulundu.','bilgi',  'ik'),
(NULL,'erp','⚠️ Kritik Stok Uyarısı', 'Metal Braket X45 minimum stok seviyesinin altına düştü.','uyari','depo'),
(NULL,'erp','✅ İrsaliye Teslim',      'IRS-2024-001 ABC Plastik e teslim edildi.','basari','depo'),
(NULL,'erp','🏭 Üretim Başladı',       'SP-2024-003 siparişi üretimde.','bilgi','uretim');

-- ════════════════════════════════════════════════════════════
-- KONTROL SORGUSU — Sonuçları phpMyAdmin'de görün
-- ════════════════════════════════════════════════════════════
SELECT '== ERP Kullanıcıları ==' AS bilgi;
SELECT id, CONCAT(ad,' ',soyad) ad_soyad, email, rol_id, durum FROM kullanicilar ORDER BY id;

SELECT '== Portal Kullanıcıları ==' AS bilgi;
SELECT id, tip, kullanici_adi, ad_soyad, durum,
       CASE tip
         WHEN 'personel' THEN 'Şifre: Personel2024!'
         WHEN 'musteri'  THEN 'Şifre: Musteri2024!'
       END sifre_bilgisi
FROM portal_kullanicilari ORDER BY tip, kullanici_adi;

SELECT '== Özet ==' AS bilgi;
SELECT 'ERP Kullanıcı'   ad, COUNT(*) n FROM kullanicilar  UNION ALL
SELECT 'Personel'            , COUNT(*) FROM personeller   UNION ALL
SELECT 'Müşteri'             , COUNT(*) FROM musteriler    UNION ALL
SELECT 'Portal Kullanıcısı'  , COUNT(*) FROM portal_kullanicilari UNION ALL
SELECT 'Sipariş'             , COUNT(*) FROM satis_siparisleri    UNION ALL
SELECT 'Ürün'                , COUNT(*) FROM urunler;

-- ----------------------------------------------------------------
-- 9. Verimlilik Tablosu
-- Kaynak: verimlilik_tablo.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO v727 — verimlilik tablosu
-- Enjeksiyon hattı vardiya bazlı verimlilik kayıtları
-- ============================================================
-- jetone_pro veritabanında çalıştırın.
-- IF NOT EXISTS — tablo zaten varsa güvenle atlar.
-- ============================================================

CREATE TABLE IF NOT EXISTS `verimlilik` (
  `id`                 int           NOT NULL AUTO_INCREMENT,
  `makina_kodu`        varchar(50)   COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stok_kodu`          varchar(50)   COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stok_adi`           varchar(255)  COLLATE utf8mb4_general_ci DEFAULT NULL,
  `calisan_personel`   varchar(100)  COLLATE utf8mb4_general_ci DEFAULT NULL,
  `uretim_miktari`     int           DEFAULT NULL,
  `fire_miktar`        int           DEFAULT NULL,
  `durus`              decimal(10,2) DEFAULT NULL  COMMENT 'dakika cinsinden',
  `net_calisma_suresi` decimal(10,2) DEFAULT NULL  COMMENT 'dakika cinsinden',
  `verimlilik`         decimal(5,2)  DEFAULT NULL  COMMENT 'yüzde cinsinden',
  `fire_oranı`         decimal(5,2)  DEFAULT NULL  COMMENT 'yüzde cinsinden',
  `vardiya`            tinyint(1)    DEFAULT NULL  COMMENT '1:08-16, 2:16-24, 3:24-08',
  `tarih`              date          DEFAULT NULL,
  `ekleyen`            varchar(50)   COLLATE utf8mb4_general_ci DEFAULT NULL,
  `olusturma_tarihi`   datetime      DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_makina_tarih` (`makina_kodu`, `tarih`),
  KEY `idx_stok_tarih`   (`stok_kodu`,   `tarih`),
  KEY `idx_personel`     (`calisan_personel`),
  KEY `idx_vardiya`      (`vardiya`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_general_ci
  COMMENT='Enjeksiyon hattı vardiya bazlı verimlilik kayıtları';

-- ----------------------------------------------------------------
-- 10. Mıknatıs Kontrol Tabloları
-- Kaynak: miknatis_tablo.sql
-- ----------------------------------------------------------------

-- ============================================================
-- Mıknatıslı Tekmelik — Veritabanı Şeması
-- jetone_pro MySQL'ine çalıştırın
-- ============================================================

CREATE TABLE IF NOT EXISTS `miknatis_kontroller` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `urun_kodu`        VARCHAR(30)  NOT NULL                    COMMENT 'Ürün kodu',
  `makina_kodu`      VARCHAR(20)  NOT NULL DEFAULT 'KRT-01'  COMMENT 'Makina adı',
  `kontrol_zamani`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `durum`            ENUM(
                       'basarili',    -- 3 mıknatıs tamam
                       'hata_1',      -- 1 eksik
                       'hata_2',      -- 2 eksik
                       'hata_3',      -- 3 eksik (hiç yok)
                       'duzeltildi'   -- hata sonradan düzeltildi
                     ) NOT NULL,
  `m1`               TINYINT(1)   NOT NULL DEFAULT 0         COMMENT '1=var 0=yok',
  `m2`               TINYINT(1)   NOT NULL DEFAULT 0,
  `m3`               TINYINT(1)   NOT NULL DEFAULT 0,
  `eksik_adet`       TINYINT      NOT NULL DEFAULT 0,
  `orijinal_id`      INT UNSIGNED NULL     DEFAULT NULL      COMMENT 'Düzeltme: hangi hatanın düzeltmesi',
  `duzeltme_zamani`  DATETIME     NULL     DEFAULT NULL,
  `aciklama`         VARCHAR(100) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_urun`   (`urun_kodu`),
  KEY `idx_durum`  (`durum`),
  KEY `idx_zaman`  (`kontrol_zamani`),
  KEY `idx_makina` (`makina_kodu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- YARDIMCI VIEW: Günlük özet (dashboard için)
-- ============================================================
CREATE OR REPLACE VIEW `v_tekmelik_gunluk` AS
SELECT
  DATE(kontrol_zamani)                              AS gun,
  makina_kodu,
  urun_kodu,
  COUNT(*)                                          AS toplam,
  SUM(durum = 'basarili')                           AS basarili,
  SUM(durum IN ('hata_1','hata_2','hata_3'))        AS hatali,
  SUM(durum = 'duzeltildi')                         AS duzeltildi,
  ROUND(
    SUM(durum IN ('basarili','duzeltildi'))
    / NULLIF(COUNT(*), 0) * 100
  , 1)                                              AS basari_oran
FROM miknatis_kontroller
GROUP BY DATE(kontrol_zamani), makina_kodu, urun_kodu;


-- ============================================================
-- YARDIMCI VIEW: Bekleyen açık hatalar
-- ============================================================
CREATE OR REPLACE VIEW `v_acik_hatalar` AS
SELECT *
FROM miknatis_kontroller
WHERE durum IN ('hata_1','hata_2','hata_3')
  AND id NOT IN (
    SELECT COALESCE(orijinal_id, 0)
    FROM miknatis_kontroller
    WHERE orijinal_id IS NOT NULL
  )
ORDER BY kontrol_zamani DESC;

-- ----------------------------------------------------------------
-- 11. Malzeme Verileri
-- Kaynak: malzeme_converted.sql
-- ----------------------------------------------------------------

INSERT INTO `malzeme_tanimlari` (`malzeme_id`, `malzeme_tur`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`) VALUES
(1, 'MM', 'Mamül', 'ARÇELİK', '2137000377', 'SEFFAF_ON_KAPAK_GR(ABX_ASM_XL)1-1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(2, 'MM', 'Mamül', 'ARÇELİK', '2954720100', 'KURUTUCU LAMBA CAMI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(3, 'MM', 'Mamül', 'ARÇELİK', '2957120100', 'SALYANGOZ KAPAĞI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(4, 'MM', 'Mamül', 'ARÇELİK', '2957120200', 'SALYANGOZ KAPAĞI (5 VA)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(5, 'MM', 'Mamül', 'ARÇELİK', '2957120300', 'SALYANGOZ KAPAGI(5VA)-CAPELLA', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(6, 'MM', 'Mamül', 'ARÇELİK', '2961290200', 'BOSALTMA HUNİSİ (ÜST)', 'ADET', '123757', '300', '10,4', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(7, 'MM', 'Mamül', 'ARÇELİK', '2961720100', 'SOĞUTMA EMİŞ DÜZELTİCİSİ(62 MM)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(8, 'MM', 'Mamül', 'ARÇELİK', '2961720200', 'SOĞUTMA EMİŞ DÜZELTİCİSİ(71 MM)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(9, 'MM', 'Mamül', 'ARÇELİK', '2961720300', 'SOGUTMA EMIS DUZELTICISI( Ø71_7MM)BSLTM', 'ADET', '15228', '160', '47', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(10, 'MM', 'Mamül', 'ARÇELİK', '2966280300', 'TEKMELIK_BUTONU_(ARC-GR-B13)432BORDO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(11, 'MM', 'Mamül', 'ARÇELİK', '2966285100', 'TEKMELIK_BUTONU_(ARC-GR-B13)_03+728BORDO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(12, 'MM', 'Mamül', 'ARÇELİK', '2966290100', 'TEKMELİK MENTEŞE YUVASI ÜST', 'ADET', '5730', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(13, 'MM', 'Mamül', 'ARÇELİK', '2966310100', 'TEKMELİK MENTEŞE YUVASI ALT', 'ADET', '6425', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(14, 'MM', 'Mamül', 'ARÇELİK', '2967780100', 'FAN TUTUCU', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(15, 'MM', 'Mamül', 'ARÇELİK', '2968410100', 'TEKMELIK_SOL_BEKO2013(ARC1)_IZGARALI', 'ADET', '8371', '500', '211', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(16, 'MM', 'Mamül', 'ARÇELİK', '2968410200', 'TEKMELIK_SOL_B13-HOEM-BLG15_KAPALI(ARC1)', 'ADET', '2474', '350', '208', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(17, 'MM', 'Mamül', 'ARÇELİK', '2968415000', 'TEKMELIK_SOL_BEKO_2013_745GRI_IZGARALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(18, 'MM', 'Mamül', 'ARÇELİK', '2968415100', 'TEKMELIK_SOL_BEKO_2013_745GRI_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(19, 'MM', 'Mamül', 'ARÇELİK', '2968415200', 'TEKMELIK_SOL_B13_728BORDO_IZGARALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(20, 'MM', 'Mamül', 'ARÇELİK', '2968415300', 'TEKMELIK_SOL_B13_728BORDO_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(21, 'MM', 'Mamül', 'ARÇELİK', '2968415400', 'TEKMELIK_SOL_B13_734MAVI_IZGARALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(22, 'MM', 'Mamül', 'ARÇELİK', '2968415500', 'TEKMELIK_SOL_B13_734MAVI_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(23, 'MM', 'Mamül', 'ARÇELİK', '2968415600', 'TEKMELIK_SOL_B13_764 S_MAN.GRAY_IZGARALI', 'ADET', '13', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(24, 'MM', 'Mamül', 'ARÇELİK', '2968415700', 'TEKMELIK_SOL_B13_764_S_MAN.GRAY_KAPALI', 'ADET', '239', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(25, 'MM', 'Mamül', 'ARÇELİK', '2968415800', 'TEKMELIK_SOL_B13_700_ANTRASIT_IZGARALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(26, 'MM', 'Mamül', 'ARÇELİK', '2968415900', 'TEKMELIK_SOL_B13_700_ANTRASIT_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(27, 'MM', 'Mamül', 'ARÇELİK', '2968416000', 'TEKMELIK_SOL_B13_IZGARALI_TIP03+1050_GRI', 'ADET', '42', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(28, 'MM', 'Mamül', 'ARÇELİK', '2968416100', 'TEKMELIK_SOL_B13_KAPALI_TIP04+1050_GRI', 'ADET', '144', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(29, 'MM', 'Mamül', 'ARÇELİK', '2968416200', 'TEKMELIK_SOL_B13_TIP03+1165_ANT_IZGARALI', 'ADET', '134', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(30, 'MM', 'Mamül', 'ARÇELİK', '2968416300', 'TEKMELIK_SOL_B13_ARC1165_ANT_KAPALI', 'ADET', '22', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(31, 'MM', 'Mamül', 'ARÇELİK', '2969280100', 'ÜST TABLA KEÇE SAB.PULU', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(32, 'MM', 'Mamül', 'ARÇELİK', '2971530100', 'SOKET KILIFI', 'ADET', '8189', '80', '11,28', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(33, 'MM', 'Mamül', 'ARÇELİK', '2971530200', 'SOKET KILIFI_ALT(GRİ)', 'ADET', '82423', '80', '10,4', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(34, 'MM', 'Mamül', 'ARÇELİK', '2971930100', 'ÜST TABLA KEÇE SABİTLEYİCİ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(35, 'MM', 'Mamül', 'ARÇELİK', '2976340100', 'CAM_ON_KAPAK_GR(BX_ALCAK_F)ARC1-ARC1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(36, 'MM', 'Mamül', 'ARÇELİK', '2976341100', 'CAM_ON_KPK_GR(BX_ALCAK_F)ARC764-ARC764', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(37, 'MM', 'Mamül', 'ARÇELİK', '2977460100', 'ON_KAPAK_GR(BX_OPAK_ALCAK_F)ARC1_ARC1', 'ADET', '989', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(38, 'MM', 'Mamül', 'ARÇELİK', '2977710100', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC1-ARC1', 'ADET', '285', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(39, 'MM', 'Mamül', 'ARÇELİK', '2977710700', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC700-ARC700', 'ADET', '7', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(40, 'MM', 'Mamül', 'ARÇELİK', '2977711100', 'CAM_ON_KPK_GR(BX_ASMTK_F)ARC1050-ARC1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(41, 'MM', 'Mamül', 'ARÇELİK', '2977712300', 'CAM_KPK_GR(BX_ASMT)1050-ARC1050_UV_TUR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(42, 'MM', 'Mamül', 'ARÇELİK', '2977712500', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC1165-ARC11', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(43, 'MM', 'Mamül', 'ARÇELİK', '2978030100', 'BORU_CIKIS_ARA_PARCA_54-CM_HP_VEGA', 'ADET', '3506', '500', '184', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(44, 'MM', 'Mamül', 'ARÇELİK', '2978670100', 'CAM_ÖN_KAPAK_GR(ABX_ALCAK)ARC1-722-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(45, 'MM', 'Mamül', 'ARÇELİK', '2978670900', 'CAM_ON_KAPAK_GR(ABX_ALCAK)ARC1-1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(46, 'MM', 'Mamül', 'ARÇELİK', '2978671200', 'CAM_ON_KAPAK_GR(ABX_ALCAK)1-722-1_V0', 'ADET', '69', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(47, 'MM', 'Mamül', 'ARÇELİK', '2978671300', 'CAM_ON_KAPAK_GR(ABX_ALCAK)745-722-745_V0', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(48, 'MM', 'Mamül', 'ARÇELİK', '2978672500', 'CAM_ON_KPK_GR(ABX_ALCAK)1050-722-1050_V0', 'ADET', '38', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(49, 'MM', 'Mamül', 'ARÇELİK', '2978680100', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1-722-1', 'ADET', '57', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(50, 'MM', 'Mamül', 'ARÇELİK', '2978680200', 'CAM ON KAPAK GR.(ABX_ASMTRK)ARC745-722-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(51, 'MM', 'Mamül', 'ARÇELİK', '2978680900', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1-1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(52, 'MM', 'Mamül', 'ARÇELİK', '2978682500', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1050-722-1050', 'ADET', '61', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(53, 'MM', 'Mamül', 'ARÇELİK', '2979910100', 'ESANJOR_KAPAGI_GR_54-CM_HP_VEGA', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(54, 'MM', 'Mamül', 'ARÇELİK', '2979910200', 'ESANJOR_KAPAGI_GR_54CM_HP_VEGA(IYONIZER)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(55, 'MM', 'Mamül', 'ARÇELİK', '2979910300', 'ESANJOR_KAPAGI_GR_54-CM_HP_VEGA(NTC)', 'ADET', '20', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(58, 'MM', 'Mamül', 'ARÇELİK', '2982620100', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(59, 'MM', 'Mamül', 'ARÇELİK', '2982620200', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC722-722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(60, 'MM', 'Mamül', 'ARÇELİK', '2982620400', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(61, 'MM', 'Mamül', 'ARÇELİK', '2982620600', 'SEFFAF_ON_KPK_GR(BX_ASMTRK)ARC1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(62, 'MM', 'Mamül', 'ARÇELİK', '2982620700', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC1165-1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(63, 'MM', 'Mamül', 'ARÇELİK', '2982950100', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-722-1', 'ADET', '16', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(64, 'MM', 'Mamül', 'ARÇELİK', '2982950200', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-722-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(65, 'MM', 'Mamül', 'ARÇELİK', '2982950300', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-745-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(66, 'MM', 'Mamül', 'ARÇELİK', '2982950400', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-745-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(67, 'MM', 'Mamül', 'ARÇELİK', '2982950500', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-745-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(68, 'MM', 'Mamül', 'ARÇELİK', '2982950600', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-1-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(69, 'MM', 'Mamül', 'ARÇELİK', '2982950700', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-745-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(70, 'MM', 'Mamül', 'ARÇELİK', '2982950800', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-745-745', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(71, 'MM', 'Mamül', 'ARÇELİK', '2982950900', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(72, 'MM', 'Mamül', 'ARÇELİK', '2982951000', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(73, 'MM', 'Mamül', 'ARÇELİK', '2982951100', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(74, 'MM', 'Mamül', 'ARÇELİK', '2982951200', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)KROM-722-KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(75, 'MM', 'Mamül', 'ARÇELİK', '2982951300', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-722-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(76, 'MM', 'Mamül', 'ARÇELİK', '2982951400', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(77, 'MM', 'Mamül', 'ARÇELİK', '2982951500', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(78, 'MM', 'Mamül', 'ARÇELİK', '2982951600', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(79, 'MM', 'Mamül', 'ARÇELİK', '2982951700', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-1-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(80, 'MM', 'Mamül', 'ARÇELİK', '2982951800', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1050-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(81, 'MM', 'Mamül', 'ARÇELİK', '2982951900', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(82, 'MM', 'Mamül', 'ARÇELİK', '2983510100', 'ON_KAPAK_GR(BX2_OPAK_ALCAK_F)ARC1_ARC1', 'ADET', '1995', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(83, 'MM', 'Mamül', 'ARÇELİK', '2983510500', 'ON_KAPAK_GR(BX2_OPK_ALCAK_F)ARC700_700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(84, 'MM', 'Mamül', 'ARÇELİK', '2983510600', 'ON_KAPAK_GR(BX2_OPK_ALCAK_F)ARC1050_1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(85, 'MM', 'Mamül', 'ARÇELİK', '2983540100', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1_ARC1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(86, 'MM', 'Mamül', 'ARÇELİK', '2983540500', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC700_700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(87, 'MM', 'Mamül', 'ARÇELİK', '2983540600', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1050_1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(88, 'MM', 'Mamül', 'ARÇELİK', '2983540800', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1165_1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(89, 'MM', 'Mamül', 'ARÇELİK', '2983550100', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC1-1', 'ADET', '21', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(90, 'MM', 'Mamül', 'ARÇELİK', '2983550200', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC722-722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(91, 'MM', 'Mamül', 'ARÇELİK', '2983550300', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTK)1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(92, 'MM', 'Mamül', 'ARÇELİK', '2983550400', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(93, 'MM', 'Mamül', 'ARÇELİK', '2983550600', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC1165-11', 'ADET', '19', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(94, 'MM', 'Mamül', 'ARÇELİK', '2984780100', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC1-1', 'ADET', '414', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(95, 'MM', 'Mamül', 'ARÇELİK', '2984780700', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(96, 'MM', 'Mamül', 'ARÇELİK', '2984781100', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(97, 'MM', 'Mamül', 'ARÇELİK', '2984781300', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC1165-1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(98, 'MM', 'Mamül', 'ARÇELİK', '2985310100', 'TEKMELIK_PROLOGUE_GR_ARC1_BEYAZ', 'ADET', '', '650', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(99, 'MM', 'Mamül', 'ARÇELİK', '2985310200', 'TEKMELIK_GR_PROLOGUE_ARC722_SYH', 'ADET', '', '500', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(100, 'MM', 'Mamül', 'ARÇELİK', '2985310300', 'TEKMELIK_GR_PROLOGUE_P1_BYZ_V0', 'ADET', '', '500', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(101, 'MM', 'Mamül', 'ARÇELİK', '2985310400', 'TEKMELIK_GR_PROLOGUE_ARC1050_GRI', 'ADET', '', '500', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(102, 'MM', 'Mamül', 'ARÇELİK', '2985310500', 'TEKMELIK_GR_PROLOGUE_ARC764MGRI', 'ADET', '', '500', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(103, 'MM', 'Mamül', 'ARÇELİK', '2985310600', 'TEKMELIK_GR_PROLOGUE_ARC700_ANTRSIT', 'ADET', '', '500', '390', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(104, 'MM', 'Mamül', 'ARÇELİK', '2985360100', 'SEFFAF_ON_KAPAK_GR(BX2_ALCAK)ARC1-1', 'ADET', '19', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(105, 'MM', 'Mamül', 'ARÇELİK', '2985430100', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC1-ARC1', 'ADET', '382', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(106, 'MM', 'Mamül', 'ARÇELİK', '2985430200', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC722-722', 'ADET', '57', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(107, 'MM', 'Mamül', 'ARÇELİK', '2985430900', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(108, 'MM', 'Mamül', 'ARÇELİK', '2985450100', 'SEFFAF_ON_KAPAK_GR(ABX_ALCAK)1-722-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(109, 'MM', 'Mamül', 'ARÇELİK', '2985510300', 'SEFFAF_ON_KAPAK_GR(BX2_KKLI_ASMT)ARC1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(110, 'MM', 'Mamül', 'ARÇELİK', '2986080100', 'SEFFAF_ON_KAPAK_GR(ABX_YF_XL)1-722-1', 'ADET', '17', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(111, 'MM', 'Mamül', 'ARÇELİK', '2986080900', 'SEFFAF_ON_KAPAK_GR(ABX_YF_XL)1-1-1', 'ADET', '5', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(112, 'MM', 'Mamül', 'ARÇELİK', '2986081300', 'SEFFAF_ON_KPK_GR(ABX_YF_XL)1050-722-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(113, 'MM', 'Mamül', 'ARÇELİK', '2986081400', 'SEFFAF_ON_KPK_GR(ABX_YF_XL)1050-1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(114, 'MM', 'Mamül', 'ARÇELİK', '2986090100', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC1-1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(115, 'MM', 'Mamül', 'ARÇELİK', '2986090200', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC722-722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(116, 'MM', 'Mamül', 'ARÇELİK', '2986090300', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)1050-1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(117, 'MM', 'Mamül', 'ARÇELİK', '2986090400', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC700-700', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(118, 'MM', 'Mamül', 'ARÇELİK', '2986090600', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC1165-116', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(119, 'MM', 'Mamül', 'ARÇELİK', '2987410001', 'AKS  BACA GR', 'ADET', '90', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(120, 'MM', 'Mamül', 'ARÇELİK', '2987410002', 'AKS DIREK TAHLIYE (9+KG)', 'ADET', '4845', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(121, 'MM', 'Mamül', 'ARÇELİK', '2987410003', 'AKS  DIREK TAHLIYE(9+KG)45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(122, 'MM', 'Mamül', 'ARÇELİK', '2987410004', 'AKS  DIREK TAHLIYE(8-KG)45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(123, 'MM', 'Mamül', 'ARÇELİK', '2987410005', 'AKS  DIREK TAHLIYE (8-KG) EVA SUNGER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(124, 'MM', 'Mamül', 'ARÇELİK', '2987410006', 'AKS  DIREK TAHLIYE( 8-KG)', 'ADET', '7830', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(125, 'MM', 'Mamül', 'ARÇELİK', '2987410007', 'AKS  DIREK TAHLIYE CND (TANK ALT)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(126, 'MM', 'Mamül', 'ARÇELİK', '2987410008', 'AKS  DIREK TAHLIYE ABD', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(127, 'MM', 'Mamül', 'ARÇELİK', '2987410009', 'AKS  45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(128, 'MM', 'Mamül', 'ARÇELİK', '2987410010', 'AKS  DIREK TAHLIYE (8-KG) 2EVA SUNGER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(129, 'MM', 'Mamül', 'ARÇELİK', '2987410011', 'AKS  DIREK TAHLIYE(9+KG) SPRY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(130, 'MM', 'Mamül', 'ARÇELİK', '2987410012', 'AKS  DIREK TAHLIYE( 8-KG) SPRY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(131, 'MM', 'Mamül', 'ARÇELİK', '2987410013', 'AKS  DIREK TAHLIYE(9+KG)45PPI EVA_SPRY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(132, 'MM', 'Mamül', 'ARÇELİK', '2987410014', 'AKS CAPELLA ABD', 'ADET', '2000', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(133, 'MM', 'Mamül', 'ARÇELİK', '2987410015', 'AKS  DIREK TAHLIYE( 8-KG)_SC', 'ADET', '810', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(134, 'MM', 'Mamül', 'ARÇELİK', '2987410016', 'AKS DIREK TAHLIYE (9+KG)_SC', 'ADET', '300', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(135, 'MM', 'Mamül', 'ARÇELİK', '2987410017', 'AKS  DIREK TAHLIYE BYND ABD', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(136, 'MM', 'Mamül', 'ARÇELİK', '2987910100', 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ', 'ADET', '60', '500', '390', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(137, 'MM', 'Mamül', 'ARÇELİK', '2987910200', 'TEKMELIK_GRUBU_OEM_ARC_722 SIYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(138, 'MM', 'Mamül', 'ARÇELİK', '2987910300', 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ_V0', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(139, 'MM', 'Mamül', 'ARÇELİK', '2987910400', 'TEKMELIK_GRUBU_OEM_ARC_1050_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(140, 'MM', 'Mamül', 'ARÇELİK', '2987910500', 'TEKMELIK_GRUBU_OEM_ARC_764S MGRAY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(141, 'MM', 'Mamül', 'ARÇELİK', '2987910600', 'TEKMELIK_GRUBU_OEM_ARC_700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(142, 'MM', 'Mamül', 'ARÇELİK', '2988080100', 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ', 'ADET', '5085', '650', '370', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(143, 'MM', 'Mamül', 'ARÇELİK', '2988080200', 'TEKMELIK_GRUBU_BEYOND_ARC722 SYH_PARLAK', 'ADET', '', '500', '370', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(144, 'MM', 'Mamül', 'ARÇELİK', '2988080300', 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ_V0', 'ADET', '', '650', '406', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(145, 'MM', 'Mamül', 'ARÇELİK', '2988080400', 'TEKMELIK_GRUBU_BEYOND_ARC_1050_GRI', 'ADET', '', '500', '370', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(146, 'MM', 'Mamül', 'ARÇELİK', '2988080500', 'TEKMELIK_GRUBU_BEYOND_ARC_764S MAN_GRAY', 'ADET', '127', '500', '370', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(147, 'MM', 'Mamül', 'ARÇELİK', '2988080600', 'TEKMELIK_GRUBU_BEYOND_ARC_700_ANTRASIT', 'ADET', '', '500', '370', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(148, 'MM', 'Mamül', 'ARÇELİK', '2990200300', 'TANK YUVASI SU DOLDURMA GR 60 CM B13 HP', 'ADET', '21', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(149, 'MM', 'Mamül', 'ARÇELİK', '2991200100', 'TANK YUVASI GR.(54CM_B13-HOEM-BLG15)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(150, 'MM', 'Mamül', 'ARÇELİK', '2991200200', 'TANK_YUVASI_GR.(54CM_B13-HOEM_SPREY)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(151, 'MM', 'Mamül', 'ARÇELİK', '2991220100', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(152, 'MM', 'Mamül', 'ARÇELİK', '2991220200', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(153, 'MM', 'Mamül', 'ARÇELİK', '2991220300', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(154, 'MM', 'Mamül', 'ARÇELİK', '2991220400', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(155, 'MM', 'Mamül', 'ARÇELİK', '2991220500', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(156, 'MM', 'Mamül', 'ARÇELİK', '2991220600', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1050', 'ADET', '867', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(157, 'MM', 'Mamül', 'ARÇELİK', '2991220700', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC764S', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(158, 'MM', 'Mamül', 'ARÇELİK', '2991220800', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC764S', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(159, 'MM', 'Mamül', 'ARÇELİK', '2991220900', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(160, 'MM', 'Mamül', 'ARÇELİK', '2991221000', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(161, 'MM', 'Mamül', 'ARÇELİK', '2991221100', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(162, 'MM', 'Mamül', 'ARÇELİK', '2991221200', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(163, 'MM', 'Mamül', 'ARÇELİK', '2991280100', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(164, 'MM', 'Mamül', 'ARÇELİK', '2991280200', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(165, 'MM', 'Mamül', 'ARÇELİK', '2991280300', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(166, 'MM', 'Mamül', 'ARÇELİK', '2991280400', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(167, 'MM', 'Mamül', 'ARÇELİK', '2991280500', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(168, 'MM', 'Mamül', 'ARÇELİK', '2991280600', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1050', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(169, 'MM', 'Mamül', 'ARÇELİK', '2991280700', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(170, 'MM', 'Mamül', 'ARÇELİK', '2991280800', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(171, 'MM', 'Mamül', 'ARÇELİK', '2991280900', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_722', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(172, 'MM', 'Mamül', 'ARÇELİK', '2991281000', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_KROM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(173, 'MM', 'Mamül', 'ARÇELİK', '2991281100', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(174, 'MM', 'Mamül', 'ARÇELİK', '2991281200', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_722_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(175, 'MM', 'Mamül', 'ARÇELİK', '2991281300', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_1050_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(176, 'MM', 'Mamül', 'ARÇELİK', '2991281400', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1050_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(177, 'MM', 'Mamül', 'ARÇELİK', '2991281500', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(178, 'MM', 'Mamül', 'ARÇELİK', '2991281600', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1050_MAGNT', 'ADET', '48', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(179, 'MM', 'Mamül', 'ARÇELİK', '2991281700', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(180, 'MM', 'Mamül', 'ARÇELİK', '2991281800', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(181, 'MM', 'Mamül', 'ARÇELİK', '2991281900', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_722_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(182, 'MM', 'Mamül', 'ARÇELİK', '2991282000', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(183, 'MM', 'Mamül', 'ARÇELİK', '2991300100', 'TANK YUVASI GRUBU(60 cmlik)', 'ADET', '985', '420', '744', '39', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(184, 'MM', 'Mamül', 'ARÇELİK', '2991300200', 'TANK_YUVASI_GR.(60CM_B13-HOEM_SPREY)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(185, 'MM', 'Mamül', 'ARÇELİK', '2992690100', 'SAVEWATER_MONTAJ_AKSESUAR_GRUBU', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(186, 'MM', 'Mamül', 'ARÇELİK', '2993100100', 'TEKMELIK_SAG_GRUBU(B13)', 'ADET', '11197', '200', '157', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(187, 'MM', 'Mamül', 'ARÇELİK', '2993100300', 'TEKMELIK_SAG_GRUBU(B13)722_SİYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(188, 'MM', 'Mamül', 'ARÇELİK', '2998700100', 'EŞANJÖR KAPAĞI GR SIRIUS HP54CM', 'ADET', '1132', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(189, 'MM', 'Mamül', 'ARÇELİK', '2998700200', 'EŞANJÖR KAP.GR.SIRIUS HP54CM ARC LG ESNJ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(190, 'MM', 'Mamül', 'ARÇELİK', 'NUMUNE', 'NUMUNE', 'ADET', '25', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(191, 'YM', 'Yarımamül', 'ARÇELİK', '2962340100', 'GERI ITICI TUS', 'ADET', '56600', '80', '2,91', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(192, 'YM', 'Yarımamül', 'ARÇELİK', '2965020100', 'ÖN_YATAKLAMA_KAPAGI_(Terra_Ucuz)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(193, 'YM', 'Yarımamül', 'ARÇELİK', '2966280100', 'TEKMELIK_BUTONU_(ARC-GR)', 'ADET', '24747', '130', '8', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(194, 'YM', 'Yarımamül', 'ARÇELİK', '2966280200', 'TEKMELIK_BUTONU_(ARC-GR-B13)434GRI', 'ADET', '16245', '130', '8', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(195, 'YM', 'Yarımamül', 'ARÇELİK', '2966280400', 'TEKMELIK_BUTONU_(ARC-GR-B13)_722SYH', 'ADET', '6158', '130', '8', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(196, 'YM', 'Yarımamül', 'ARÇELİK', '2966285400', 'TEKMELIK_BUTONU_(ARCGRB13)_700ANTRASIT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(197, 'YM', 'Yarımamül', 'ARÇELİK', '2968050100', 'TANK YUVASI (60 CM)', 'ADET', '292', '420', '744', '39', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(198, 'YM', 'Yarımamül', 'ARÇELİK', '2968050200', 'SU_TANKI_YUVASI_60CM_BUHARLI_(B13)', 'ADET', '281', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(199, 'YM', 'Yarımamül', 'ARÇELİK', '2968060100', 'SU TANKI YUVASI_54CM_(B13-HOEM-BLG15)', 'ADET', '24', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(200, 'YM', 'Yarımamül', 'ARÇELİK', '2968070100', 'TANK YUVASI KAPAĞI', 'ADET', '20', '160', '58', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(201, 'YM', 'Yarımamül', 'ARÇELİK', '2968390100', 'TEKMELIK_SAG_BEKO_2013_ARC P1 BEYAZ', 'ADET', '', '200', '157', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(202, 'YM', 'Yarımamül', 'ARÇELİK', '2968390200', 'TEKMELIK_SAG_BEKO_2013_434_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(203, 'YM', 'Yarımamül', 'ARÇELİK', '2968390400', 'TEKMELIK_SAG_BEKO_722 SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(204, 'YM', 'Yarımamül', 'ARÇELİK', '2968410300', 'TEKMELIK_SOL_BEKO_2013_434GRI_IZGARALI', 'ADET', '556', '500', '211', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(205, 'YM', 'Yarımamül', 'ARÇELİK', '2968410400', 'TEKMELIK_SOL_BEKO_2013_434GRI_KAPALI', 'ADET', '2647', '350', '195', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(206, 'YM', 'Yarımamül', 'ARÇELİK', '2968410500', 'TEKMELIK_SOL_B13_432BRD_IZGARALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(207, 'YM', 'Yarımamül', 'ARÇELİK', '2968410600', 'TEKMELIK_SOL_B13_432BRD_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(208, 'YM', 'Yarımamül', 'ARÇELİK', '2968410700', 'TEKMELIK_SOL_B13_722SİYAH_PARLAK_IZGARALI', 'ADET', '', '420', '213', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(209, 'YM', 'Yarımamül', 'ARÇELİK', '2968410800', 'TEKMELIK_SOL_B13_722SİYAH_PARLAK_KAPALI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(210, 'YM', 'Yarımamül', 'ARÇELİK', '2969980100', 'EŞANjÖR KAPAĞI HP54CM', 'ADET', '290', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(211, 'YM', 'Yarımamül', 'ARÇELİK', '2969980200', 'EŞANJÖR KAPAĞI HP54CM_ARC_LG_ESNJ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(212, 'YM', 'Yarımamül', 'ARÇELİK', '2975570100', 'DIŞ_KAPAK(BX_OPAK)_ARC1_BEYAZ', 'ADET', '2376', '650', '600', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(213, 'YM', 'Yarımamül', 'ARÇELİK', '2975570200', 'DIS_KAPAK(BX_OPAK)_ARC434_GRI', 'ADET', '1493', '650', '600', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(214, 'YM', 'Yarımamül', 'ARÇELİK', '2975575200', 'DIS_KAPAK(BX_OPAK)_TIP03+ARC700_ANTR_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(215, 'YM', 'Yarımamül', 'ARÇELİK', '2975575300', 'DIS_KAPAK(BX_OPAK)_TIP02+ARC1050_GRI', 'ADET', '34', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(216, 'YM', 'Yarımamül', 'ARÇELİK', '2975575500', 'DIS_KAPAK(BX_OPAK)_TIP03+ARC1165', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(217, 'YM', 'Yarımamül', 'ARÇELİK', '2975590100', 'TUTAMAK(BX_OPAK)_ARC1_BEYAZ', 'ADET', '4439', '300', '24', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(218, 'YM', 'Yarımamül', 'ARÇELİK', '2975590200', 'TUTAMAK(BX_OPAK)_ARC434_GRI', 'ADET', '3836', '300', '24', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(219, 'YM', 'Yarımamül', 'ARÇELİK', '2975590300', 'TUTAMAK(BX_OPAK)_ARC722_SIYAH_PARLAK', 'ADET', '1877', '300', '24', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(220, 'YM', 'Yarımamül', 'ARÇELİK', '2975595200', 'TUTAMAK_BX_TIP03+ARC700_ANTASIT-GRI', 'ADET', '124', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(221, 'YM', 'Yarımamül', 'ARÇELİK', '2975595300', 'TUTAMAK(BX_OPAK)TIP02+ARC1050_GRI', 'ADET', '1029', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(222, 'YM', 'Yarımamül', 'ARÇELİK', '2975595500', 'TUTAMAK_BX_TIP03+ARC1165_YENI_ANTRASIT', 'ADET', '320', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(223, 'YM', 'Yarımamül', 'ARÇELİK', '2976320100', 'DIS_KAPAK_CAM_(BX)_ARC1_BEYAZ', 'ADET', '2014', '650', '358', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(224, 'YM', 'Yarımamül', 'ARÇELİK', '2976320200', 'DIS_KAPAK_CAM_(BX)_ARC434_GRI', 'ADET', '974', '650', '358', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(225, 'YM', 'Yarımamül', 'ARÇELİK', '2976320300', 'DIS_KAPAK_CAM_(BX)_ARC722_SIYAH_PARLAK', 'ADET', '1019', '650', '372', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(226, 'YM', 'Yarımamül', 'ARÇELİK', '2976325100', 'DIS_KAPAK_CAM_(BX)_TIP03+ARC700_ANTR_GRI', 'ADET', '25', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(227, 'YM', 'Yarımamül', 'ARÇELİK', '2976325300', 'DIS_KAPAK_CAM_(BX)_TIP02+ARC1050_GRI', 'ADET', '33', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(228, 'YM', 'Yarımamül', 'ARÇELİK', '2976325400', 'DIS_KAPAK_CAM_(BX)_TIP03+ARC1165_YENI_AN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(229, 'YM', 'Yarımamül', 'ARÇELİK', '2976330100', 'İÇ KAPAK CAM (BX)ARC1 BEYAZ', 'ADET', '1152', '500', '264', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(230, 'YM', 'Yarımamül', 'ARÇELİK', '2976330200', 'IC_KAPAK_CAM_(BX)_ARC722_SIYAH_PARLAK', 'ADET', '268', '500', '284', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(231, 'YM', 'Yarımamül', 'ARÇELİK', '2976330300', 'IC_KAPAK_CAM_(BX)_ARC1_BEYAZ_V0', 'ADET', '2075', '500', '311', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(232, 'YM', 'Yarımamül', 'ARÇELİK', '2976330400', 'IC_KAPAK_CAM_(BX)_ARC434_GRI', 'ADET', '2330', '500', '260', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(233, 'YM', 'Yarımamül', 'ARÇELİK', '2976330500', 'İÇ KAPAK CAM (BX)ARC1 BEYAZ - POLYAR', 'ADET', '1309', '500', '320', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(234, 'YM', 'Yarımamül', 'ARÇELİK', '2976370100', 'DIŞ_KAPAK_CAM_(ABX)_ARC1_BEYAZ', 'ADET', '25', '500', '250', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(235, 'YM', 'Yarımamül', 'ARÇELİK', '2976370200', 'DIS_KAPAK_CAM_(ABX)_ARC434_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(236, 'YM', 'Yarımamül', 'ARÇELİK', '2976370300', 'DIŞ KAPAK CAM (ABX) ARC722_PARLAK SİYAH', 'ADET', '3782', '500', '245', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(237, 'YM', 'Yarımamül', 'ARÇELİK', '2976375000', 'DIS_KAPAK_CAM_(ABX)_TIP02+ARC745_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(238, 'YM', 'Yarımamül', 'ARÇELİK', '2976375100', 'DIS_KAPAK_CAM_(ABX)_TIP03+ARC700_ANTRAST', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(239, 'YM', 'Yarımamül', 'ARÇELİK', '2976375200', 'DIS_KAPAK_CAM_(ABX)_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(240, 'YM', 'Yarımamül', 'ARÇELİK', '2976380100', 'RİNG CAM(ABX) ARC1-BEYAZ', 'ADET', '1126', '500', '173', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(241, 'YM', 'Yarımamül', 'ARÇELİK', '2976380200', 'RING CAM ABX ARC434-GRİ', 'ADET', '5433', '500', '173', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(242, 'YM', 'Yarımamül', 'ARÇELİK', '2976380300', 'RING_CAM_(ABX)_ARC722-SIYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(243, 'YM', 'Yarımamül', 'ARÇELİK', '2976385000', 'RING CAM ABX TIP02+ARC745-GRİ', 'ADET', '10', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(244, 'YM', 'Yarımamül', 'ARÇELİK', '2976385100', 'RING_CAM_(ABX)_TIP03+ARC700-ANTRST_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(245, 'YM', 'Yarımamül', 'ARÇELİK', '2976385200', 'RING_CAM_(ABX)_TIP04+KROM_KAPLAMA', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(246, 'YM', 'Yarımamül', 'ARÇELİK', '2976385300', 'RING CAM ABX TIP02+ARC1050-GRİ', 'ADET', '508', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(247, 'YM', 'Yarımamül', 'ARÇELİK', '2976390100', 'TUTAMAK CAM (ABX)-ARCP1_BEYAZ', 'ADET', '2703', '160', '48', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(248, 'YM', 'Yarımamül', 'ARÇELİK', '2976390200', 'TUTAMAK CAM ABX ARC-434-GRİ', 'ADET', '11693', '160', '48', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(249, 'YM', 'Yarımamül', 'ARÇELİK', '2976390300', 'TUTAMAK_CAM_(ABX)-ARC722_SİYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(250, 'YM', 'Yarımamül', 'ARÇELİK', '2976395200', 'TUTAMAK_CAM_(ABX)-TIP03+ARC700_ANTRS_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(251, 'YM', 'Yarımamül', 'ARÇELİK', '2976395300', 'TUTAMAK_CAM_(ABX)-TIP04+KROM-KAPLAMA', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(252, 'YM', 'Yarımamül', 'ARÇELİK', '2976395400', 'TUTAMAK CAM ABX-TIP02+ARC1050_GRİ', 'ADET', '162', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(253, 'YM', 'Yarımamül', 'ARÇELİK', '2976760100', 'IC_KAPAK(BX_OPAK_ALCAK_FORM)_ARC1_BEYAZ', 'ADET', '1171', '650', '610', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(254, 'YM', 'Yarımamül', 'ARÇELİK', '2978020100', 'ESANJOR_KAPAGI_54-CM_HP_VEGA', 'ADET', '1939', '350', '290', '47', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(255, 'YM', 'Yarımamül', 'ARÇELİK', '2978020200', 'ESANJOR_KAPAGI_54CM_HP_VEGA(IYONIZER)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(256, 'YM', 'Yarımamül', 'ARÇELİK', '2978020300', 'ESANJOR_KAPAGI_54-CM_HP_VEGA_NTC', 'ADET', '1965', '350', '290', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(257, 'YM', 'Yarımamül', 'ARÇELİK', '2980120100', 'BACA_GRUBU_(Polyar FC)', 'ADET', '604', '300', '235', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(258, 'YM', 'Yarımamül', 'ARÇELİK', '2980120200', 'BACA_GRUBU_(PPHO 5VB)', 'ADET', '', '300', '275', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(259, 'YM', 'Yarımamül', 'ARÇELİK', '2978760100', 'SPREY_T_BORU', 'ADET', '13935', '80', '6,13', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(260, 'YM', 'Yarımamül', 'ARÇELİK', '2980490100', 'YUKSEK_SEFFAF_PLASTIK_PRLG', 'ADET', '50', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(261, 'YM', 'Yarımamül', 'ARÇELİK', '2980930100', 'TEKMELIK_PROLOGUE_ARC1_BEYAZ - GRUPSUZ', 'ADET', '74', '500', '372', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(262, 'YM', 'Yarımamül', 'ARÇELİK', '2980930200', 'TEKMELIK_PROLOGUE_ARC434_GRI - GRUPSUZ', 'ADET', '100', '500', '372', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(263, 'YM', 'Yarımamül', 'ARÇELİK', '2980930300', 'TEKMELIK_PROLOGUE_ARC722_SIYAH - GRUPSUZ', 'ADET', '2173', '500', '385', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(264, 'YM', 'Yarımamül', 'ARÇELİK', '2980930400', 'TEKMELIK_PROLOGUE_BEYAZ_ABS_V0 - GRUPSUZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(265, 'YM', 'Yarımamül', 'ARÇELİK', '2980935000', 'TEKMELIK_PROLOGUE_TIP02+ARC1050_GRI', 'ADET', '664', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(266, 'YM', 'Yarımamül', 'ARÇELİK', '2980935100', 'TEKMELIK_PROLOGUE_TIP03+ARC764S_GRI', 'ADET', '10', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(267, 'YM', 'Yarımamül', 'ARÇELİK', '2980935200', 'TEKMELIK_PROLOGUE_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(268, 'YM', 'Yarımamül', 'ARÇELİK', '2980935600', 'TEKMELIK_PROLOGUE_TIP03+ARC1165_GRI', 'ADET', '19', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(269, 'YM', 'Yarımamül', 'ARÇELİK', '2982280100', 'TUTAMAK_(BX2)_ARC1_BEYAZ', 'ADET', '3326', '300', '30', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(270, 'YM', 'Yarımamül', 'ARÇELİK', '2982280200', 'TUTAMAK_(BX2)_ARC434_GRI', 'ADET', '602', '300', '30', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(271, 'YM', 'Yarımamül', 'ARÇELİK', '2982280300', 'TUTAMAK_(BX2)_ARC722_SIYAH', 'ADET', '4211', '300', '30', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(272, 'YM', 'Yarımamül', 'ARÇELİK', '2982285100', 'TUTAMAK_(BX2)_TIP03+ARC700_ANTRASIT_GRI', 'ADET', '1720', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(273, 'YM', 'Yarımamül', 'ARÇELİK', '2982285200', 'TUTAMAK_(BX2)_TIP03+ARC1050_GRİ', 'ADET', '319', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(274, 'YM', 'Yarımamül', 'ARÇELİK', '2982285400', 'TUTAMAK_(BX2)_TIP03+ARC1165_YENI_ANTRASI', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(275, 'YM', 'Yarımamül', 'ARÇELİK', '2982540100', 'SEFFAF_IC_KAPAK_ALCAK_FORM', 'ADET', '1009', '500', '520', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(276, 'YM', 'Yarımamül', 'ARÇELİK', '2982920100', 'TANK YUVASI KAPAGI PROLOGUE', 'ADET', '36356', '350', '61,25', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL);
INSERT INTO `malzeme_tanimlari` (`malzeme_id`, `malzeme_tur`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`) VALUES
(277, 'YM', 'Yarımamül', 'ARÇELİK', '2982970100', 'DIS_KAPAK(BX2_OPAK_YEKPARE)ARC1 BEYAZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(278, 'YM', 'Yarımamül', 'ARÇELİK', '2982970200', 'DIS_KAPAK(BX2_OPAK_YEKP)ARC434_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(279, 'YM', 'Yarımamül', 'ARÇELİK', '2982970300', 'DIS_KAPAK(BX2_OPAK_YEKP)ARC722_SIYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(280, 'YM', 'Yarımamül', 'ARÇELİK', '2982975000', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP02+ARC745_GR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(281, 'YM', 'Yarımamül', 'ARÇELİK', '2982975200', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC700_A_G', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(282, 'YM', 'Yarımamül', 'ARÇELİK', '2982975300', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP02+ARC1050_GR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(283, 'YM', 'Yarımamül', 'ARÇELİK', '2982975400', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC764S_GR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(284, 'YM', 'Yarımamül', 'ARÇELİK', '2982975500', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC1165_A_', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(285, 'YM', 'Yarımamül', 'ARÇELİK', '2984320100', 'TEKMELIK_OEM_ARC1_BEYAZ_GRUPSUZ', 'ADET', '82', '500', '365', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(286, 'YM', 'Yarımamül', 'ARÇELİK', '2984320200', 'TEKMELIK_OEM_ARC434_GRI_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(287, 'YM', 'Yarımamül', 'ARÇELİK', '2984320300', 'TEKMELIK_OEM_ARC722_SIYAH_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(288, 'YM', 'Yarımamül', 'ARÇELİK', '2984320400', 'TEKMELIK_OEM_ARC1_BYZ_ABS_V0_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(289, 'YM', 'Yarımamül', 'ARÇELİK', '2984325000', 'TEKMELIK_OEM_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(290, 'YM', 'Yarımamül', 'ARÇELİK', '2984325100', 'TEKMELIK_OEM_TIP03+ARC764S_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(291, 'YM', 'Yarımamül', 'ARÇELİK', '2984325200', 'TEKMELIK_OEM_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(292, 'YM', 'Yarımamül', 'ARÇELİK', '2985720100', 'TEKMELIK_BEYOND_ARC1_BEYAZ_GRUPSUZ', 'ADET', '', '500', '370', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(293, 'YM', 'Yarımamül', 'ARÇELİK', '2985720200', 'TEKMELIK_BEYOND_ARC434_GRI_GRUPSUZ', 'ADET', '', '500', '370', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(294, 'YM', 'Yarımamül', 'ARÇELİK', '2985720300', 'TEKMELIK_BEYOND_ARC722_SIYAH_GRUPSUZ', 'ADET', '', '650', '370', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(295, 'YM', 'Yarımamül', 'ARÇELİK', '2985720400', 'TEKMELIK_BEYOND_BEYAZ_ABS_V0_GRUPSUZ', 'ADET', '', '500', '406', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(296, 'YM', 'Yarımamül', 'ARÇELİK', '2985725000', 'TEKMELIK_BEYOND_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(297, 'YM', 'Yarımamül', 'ARÇELİK', '2985725100', 'TEKMELIK_BEYOND_TIP03+ARC764S_GRI', 'ADET', '14', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(298, 'YM', 'Yarımamül', 'ARÇELİK', '2985725200', 'TEKMELIK_BEYOND_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(299, 'YM', 'Yarımamül', 'ARÇELİK', '2991150100', 'KORUYUCU_KAPAK_ABM_FUME', 'ADET', '', '650', '655', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(300, 'YM', 'Yarımamül', 'ARÇELİK', '2991160100', 'DIS_INLAY_ABM_KKLI_ARC722_SIYAH', 'ADET', '4793', '650', '120', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(301, 'YM', 'Yarımamül', 'ARÇELİK', '2991170100', 'CAM_TUTUCU_ABM_SIYAH', 'ADET', '3148', '650', '309', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(302, 'YM', 'Yarımamül', 'ARÇELİK', '2991180100', 'IC_INLAY_ABM_KKLI_ARC722_SIYAH', 'ADET', '4418', '500', '250', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(303, 'YM', 'Yarımamül', 'ARÇELİK', '2991190100', 'IC_KAPAK_ABM_KKLI_SIYAH', 'ADET', '1255', '650', '360', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(304, 'YM', 'Yarımamül', 'ARÇELİK', '2991240100', 'IC_INLAY_ABM_KKSIZ_ARC1_BEYAZ', 'ADET', '', '650', '351', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(305, 'YM', 'Yarımamül', 'ARÇELİK', '2991240200', 'IC_INLAY_ABM_KKSIZ_ARC434_GRI', 'ADET', '', '650', '351', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(306, 'YM', 'Yarımamül', 'ARÇELİK', '2991240300', 'IC_INLAY_ABM_KKSIZ_ARC722_SIYAH', 'ADET', '', '650', '360', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(307, 'YM', 'Yarımamül', 'ARÇELİK', '2991250100', 'DIS_RING_ABM_ARC1_BEYAZ', 'ADET', '37', '500', '258', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(308, 'YM', 'Yarımamül', 'ARÇELİK', '2991250200', 'DIS_RING_ABM_ARC434_GRI', 'ADET', '3933', '500', '258', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(309, 'YM', 'Yarımamül', 'ARÇELİK', '2991250300', 'DIS_RING_ABM_ARC722_SIYAH', 'ADET', '', '500', '258', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(310, 'YM', 'Yarımamül', 'ARÇELİK', '2991260100', 'IC_KAPAK_ABM_KKSIZ_SIYAH', 'ADET', '453', '650', '590', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(311, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCG22000-AA', 'STAND FLAT 65', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(312, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22000-AA', 'STAND COVER BOOMERANG (LEFT)-SİLVER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(313, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22100-AA', 'STAND COVER BOOMERANG (RIGHT)-SİLVER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(314, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22800-AA', 'STAND CURVE NAIL (LEFT) - 65\-GRİ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(315, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22900-AA', 'STAND CURVE NAIL (RIGHT) - 65\-GRİ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(316, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH26800-AC', 'AYAK GRUBU SOL BUM.65  CLARTY SY-SİLVER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(317, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH26900-AC', 'AYAK GRUBU SAĞ BUM.65 CLARTY SY-SİLVER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(318, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ22900-AA', 'PANEL BRACKET PANEL 65 E-BOARD RIGHT', 'ADET', '7691', '160', '13', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(319, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ22900-AC', 'PANEL BRACKET PANEL 65 E-BOARD RIGHT', 'ADET', '4001', '160', '13', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(320, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23100-AA', 'PANEL BRACKET BOTTOM 65 E- BOARD', 'ADET', '', '160', '18,3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(321, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23100-AC', 'PANEL BRACKET BOTTOM 65 E- BOARD', 'ADET', '', '160', '18,3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(322, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23200-AA', 'GLASS BRACKET 65 E-BOARD', 'ADET', '', '80', '2,7', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(323, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23200-AC', 'GLASS BRACKET 65 E-BOARD', 'ADET', '', '80', '2,7', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(324, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCD21700-AA', 'SOURCE BOARD SUPPORT', 'ADET', '21000', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(325, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCE20700-AA', 'CLARTY WIFI HOLDER PLASTIC', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(326, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCE23401-AB', 'TOP AV SMART CARD', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(327, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG21700-AA', 'SOURCE BOARD HOLDER', 'ADET', '5965', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(328, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG22000-AA', 'PLASTIC STAND FLAT 65 CLARITY SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(329, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG27000-AA', 'AYAK GRUBU DÜZ 65 CLARİTY SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(330, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCH26800-AC', 'AYAK GRUBU SOL BUM.65  CLARTY SY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(331, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCH26900-AC', 'AYAK GRUBU SAĞ BUM.65 CLARTY SY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(332, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCL23200-AA', 'PLASTIC CLARTY BOTTOM AV', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(333, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCL23202-AA', 'PLASTIC CLARTY BOTTOM AV BEYAZ O2', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(334, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY21500-AA', 'COVER CI INFINITY/ONYX', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(335, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY23200-AA', 'BOTTOM AV', 'ADET', '21', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(336, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY23202-AA', 'BOTTOM AV SİYAH AV', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(337, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHD21700-AA', 'DESTEK SOURCE BOARD OPTIMUS', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(338, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHD21700-AB', 'DESTEK SOURCE BOARD OPTIMUS', 'ADET', '', '130', '1,56', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(339, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AA', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(340, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AB', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(341, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AC', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(342, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AD', 'TUTUCU SOURCE BOARD OPTIMUS LG SİYAH', 'ADET', '800', '130', '2', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(343, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AA', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(344, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23300-AA', 'PLASTIK OPTIMUS SIDE AV', 'ADET', '611', '160', '6,85', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(345, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23301-AC', 'PLASTIK OPTIMUS SIDE AV', 'ADET', '2100', '160', '6,8', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(346, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHF21700-AA', 'TUTUCU SOURCE BOARD OPTIMUS BOE-SS', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(347, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHF21700-AB', 'TUTUCU SOURCE BOARD OPTIMUS BOE-SS NATURAL', 'ADET', '3535', '160', '1,65', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(348, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHK23200-AB', 'PLASTIK OPTIMUS BOTTOM AV WHİTE', 'ADET', '490', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(349, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHK23300-AB', 'PLASTIK OPTIMUS SIDE AV NX /AF-20 BEYAZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(350, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AB', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(351, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AC', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(352, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AD', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(353, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AE', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(354, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AA', 'PLS STAND ADAP. PART 43-50-55 OCEAN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(355, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AB', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(356, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AC', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(357, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AD', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(358, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AE', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '146', '130', '23', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(359, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AF', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '130', '23', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(360, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNL23300-AC', 'PLASTIK LEDART SIDE AV SIYAH CN/G7', 'ADET', '6', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(361, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNM23200-AB', 'PLASTİK LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(362, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNM23201-AB', 'PLASTIK LEDART BOTTOM AV SIYAH G7', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(363, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNR20700-AB', '65 CURVED WIFI TUTUCU', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(364, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNV26800-AB', 'AYAK GRUBU SOL LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(365, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNV26900-AB', 'AYAK GRUBU SAĞ LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(366, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPP23200-AB', 'PLASTIK ETERNITY BOTTOM AV 55EP4 KR SIY.', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(367, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPP23300-AC', 'PLASTIK ETERNITY SIDE AV 55EP4 KR SIY', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(368, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPV23200-AB', 'PLASTİK LEDART BEYAZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(369, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPV23201-AB', 'PLASTIK LEDART BOTTOM AV BEYAZ G7', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(370, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22000-AA', 'STAND COVER BOOMERANG (LEFT)', 'ADET', '920', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(371, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22100-AA', 'STAND COVER BOOMERANG (RIGHT)', 'ADET', '111', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(372, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22800-AA', 'STAND CURVE NAIL (LEFT) - 65\', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, '')),
(373, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22900-AA', 'STAND CURVE NAIL (RIGHT) - 65\', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, '')),
(374, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'ZNV22000-AA', 'PLASTİK YATAY AYAK LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(375, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'ZQS22000-AA', 'PLASTIK YATAY AYAK LEDART SIYAH GF%10', 'ADET', '', '300', '73', '90', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(376, 'MM', 'Mamül', 'ARÇELK TKM', '3001030100', 'SASE GRUBU KOMPLE(AVRUPA FISLI)', 'ADET', '36', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(377, 'MM', 'Mamül', 'ARÇELK TKM', '3001030200', 'SASE GRUBU KOMPLE (UK ING. FISLI)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(378, 'MM', 'Mamül', 'ARÇELK TKM', '3001030300', 'SASE GRUBU KOMPLE (AVUSTRALYA. FISLI)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(379, 'MM', 'Mamül', 'ARÇELK TKM', '3001140100', 'ÜST KAPAK-TKM', 'ADET', '910', '500', '269,2', '47', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(380, 'MM', 'Mamül', 'ARÇELK TKM', '3001930100', 'PISIRME HAZNESI YUVASI GRUBU ÇİFTLİ-SERVİS', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(381, 'MM', 'Mamül', 'ARÇELK TKM', '3003570100', 'PISIRME HAZNESI YUVASI GRUBU MİNİ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(382, 'MM', 'Mamül', 'ARÇELK TKM', '3003570200', 'PISIRME HAZNESI YUVASI GRUBU UL', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(383, 'MM', 'Mamül', 'ARÇELK TKM', '3580290100', 'PISIRME HAZNESI YUVASI TEKLİ GR', 'ADET', '228', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(384, 'MM', 'Mamül', 'ARÇELK TKM', '3582390100', 'PISIRME HAZNESI YUVASI GR-TEKLİ  NOZZLE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(385, 'MM', 'Mamül', 'ARÇELK TKM', '3583310100', 'PISIRME HAZNESI YUVASI ÇİFTLİ GR', 'ADET', '9', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(386, 'MM', 'Mamül', 'ARÇELK TKM', '3583710100', 'SU DAGITICISI', 'ADET', '6600', '160', '10,2', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(387, 'MM', 'Mamül', 'ARÇELK TKM', '3583720100', 'POMPA TUTUCU', 'ADET', '800', '160', '4,45', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(388, 'MM', 'Mamül', 'ARÇELK TKM', '3583730100', 'TUS KARTI KART TUTUCU', 'ADET', '1481', '200', '41,5', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(389, 'MM', 'Mamül', 'ARÇELK TKM', '3583730200', 'TUS KARTI KART TUTUCU US', 'ADET', '', '200', '43,8', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(390, 'MM', 'Mamül', 'ARÇELK TKM', '3583740100', 'ARKA KAPAK', 'ADET', '73', '300', '114', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(391, 'MM', 'Mamül', 'ARÇELK TKM', '3583740200', 'ARKA KAPAK US', 'ADET', '6', '200', '115', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(392, 'MM', 'Mamül', 'ARÇELK TKM', '3583800100', 'HORTUM ARA PARCA', 'ADET', '27582', '80', '1,3', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(393, 'MM', 'Mamül', 'ARÇELK TKM', '3583850100', 'ANA KART TASIYICI', 'ADET', '2205', '130', '64,8', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(394, 'MM', 'Mamül', 'ARÇELK TKM', '3583850200', 'ANA KART TASIYICI US', 'ADET', '', '130', '66', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(395, 'MM', 'Mamül', 'ARÇELK TKM', '3585160100', 'SERVİS KAPAĞI  - ARÇELİK ÇAY MAKİNESİ', 'ADET', '7600', '130', '7,5', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(396, 'MM', 'Mamül', 'ARÇELK TKM', '3585440100', 'KARAF KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '3648', '130', '41', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(397, 'MM', 'Mamül', 'ARÇELK TKM', '3585450100', 'KARAF SAP ALT - ARÇELİK ÇAY MAKİNESİ', 'ADET', '20', '130', '31', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(398, 'MM', 'Mamül', 'ARÇELK TKM', '3585460100', 'KARAF SAP ÜST - ARÇELİK ÇAY MAKİNESİ', 'ADET', '', '130', '12,3', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(399, 'MM', 'Mamül', 'ARÇELK TKM', '3585940100', 'DEMLEME ODASI GRUBU - ÇAY MAKİNESİ', 'ADET', '212', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(400, 'MM', 'Mamül', 'ARÇELK TKM', '3586010100', 'DEM HAZ UST KAPAK SERIGRAFILI ARCELİK ÇAY MAKİNESİ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(401, 'MM', 'Mamül', 'ARÇELK TKM', '3586010200', 'DEM HAZ UST KAPAK SERIGRAFILI BEKO ÇAY MAKİNESİ', 'ADET', '192', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(402, 'MM', 'Mamül', 'ARÇELK TKM', '3586010300', 'DEM HAZ UST KAPAK SERIGRFL ARCELIK 3IN1  ÇAY MAK.', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(403, 'MM', 'Mamül', 'ARÇELK TKM', '3586010400', 'DEM HAZ UST KAPAK SERIGRAFILI BEKO 3IN1  ÇAY MAK.', 'ADET', '1374', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(404, 'MM', 'Mamül', 'ARÇELK TKM', '3586010500', 'DEM HAZ UST KAPAK SERIGRFL GRUNDIG 3IN1  ÇAY MAK.', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(405, 'MM', 'Mamül', 'ARÇELK TKM', '3586010600', 'DEM HAZ UST KAPAK SERİGRAFİLİ ARÇELİK 3IN1 İNOX', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(406, 'MM', 'Mamül', 'ARÇELK TKM', '3586020100', 'DEMLEME HAZNESİ DIŞ GÖVDE - ARÇELİK LOGO SERİGRAFİ', 'ADET', '662', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(407, 'MM', 'Mamül', 'ARÇELK TKM', '3586020200', 'DEMLEME HAZNESİ DIŞ GÖVDE - BEKO LOGO SERİGRAFİ', 'ADET', '343', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(408, 'MM', 'Mamül', 'ARÇELK TKM', '3586020300', 'DEMLEME HAZNESİ DIŞ GÖVDE - GRUNDIG LOGO SERİGRAFİ', 'ADET', '1', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(409, 'MM', 'Mamül', 'ARÇELK TKM', '3586020400', 'DEMLEME HAZNESİ DIŞ GÖVDE - ARÇELİK INOX SERİGRAFİ', 'ADET', '480', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(410, 'MM', 'Mamül', 'ARÇELK TKM', '3586070100', 'GOVDE UST KAPAK GRUBU ARÇELİK ÇAY MAKİNESİ', 'ADET', '60', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(411, 'MM', 'Mamül', 'ARÇELK TKM', '3586070200', 'GOVDE UST KAPAK GRUBU BEKO ÇAY MAKİNESİ', 'ADET', '32', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(412, 'MM', 'Mamül', 'ARÇELK TKM', '3586070300', 'GOVDE UST KAPAK GRUBU 3IN1 ARCELIK ÇAY MAKİNESİ', 'ADET', '64', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(413, 'MM', 'Mamül', 'ARÇELK TKM', '3586070400', 'GOVDE UST KAPAK GRUBU 3IN1 BEKO ÇAY MAKİNESİ', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(414, 'MM', 'Mamül', 'ARÇELK TKM', '3586070500', 'GOVDE UST KAPAK GRUBU 3IN1 GRUNDIG ÇAY MAKİNESİ', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(415, 'MM', 'Mamül', 'ARÇELK TKM', '3586070600', 'GOVDE UST KAPAK GRUBU  3IN1 ARCELIK INOX  ÇAY MAK.', 'ADET', '54', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(416, 'MM', 'Mamül', 'ARÇELK TKM', '3586080100', 'ANA GÖVDE ALT KAPAK GRUBU - ARÇELİK ÇAY MAKİNESİ', 'ADET', '650', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(417, 'MM', 'Mamül', 'ARÇELK TKM', '3586080200', 'ANA GÖVDE ALT KAPAK GRUBU BIO  - ÇAY MAKİNESİ', 'ADET', '1470', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(418, 'MM', 'Mamül', 'ARÇELK TKM', '3587430100', 'ORTAM AYDINLATMA GRUBU - PROYO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(419, 'MM', 'Mamül', 'ARÇELK TKM', '3587770100', 'UST TASIYICI GOVDE GRUBU - PROYO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(420, 'MM', 'Mamül', 'ARÇELK TKM', '3588570100', 'UST TASIYICI GOVDE GRUBU BEYAZ - PROYO', 'ADET', '14', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(421, 'MM', 'Mamül', 'ARÇELK TKM', '3588570200', 'UST TASIYICI GOVDE GRUBU BASIC SIYAH  - PROYO', 'ADET', '14', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(422, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001100100', 'UST CERCEVE (SY01)', 'ADET', '922', '300', '229', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(423, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001120100', 'EK KONTAK YAY KAPAGI', 'ADET', '45015', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(424, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001230100', 'PISIRME HAZNESI YUVASI UST ÇİFTLİ', 'ADET', '610', '160', '144', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(425, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001240100', 'PISIRME HAZNESI YUVASI ALT ÇİFTLİ', 'ADET', '', '200', '236', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(426, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001260100', 'PISIRME HAZ. CONTASI (FOOD GRADE SIYAH)', 'ADET', '15', '130', '13,5', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(427, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001730100', 'SEVIYE SENSORU CAMI', 'ADET', '15419', '80', '3,85', '21', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(428, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001740100', 'PISME HAZNESI ALGILAMA KOLU.', 'ADET', '6052', '80', '2,6', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(429, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001940100', 'POMPA SU TASIYICISI (SY02)', 'ADET', '71', '160', '52,5', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(430, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001980100', 'SEVIYE ALGILAMA KONTAGI KAPAGI', 'ADET', '15457', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(431, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001990100', 'BUHAR KANALI KAPAGI', 'ADET', '1152', '130', '37,3', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(432, 'YM', 'Yarımamül', 'ARÇELK TKM', '3002210100', 'TAHLİYE BORUSU', 'ADET', '3456', '130', '19,75', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(433, 'YM', 'Yarımamül', 'ARÇELK TKM', '3002350100', 'TABAN TAKOZU MILI', 'ADET', '13870', '80', '0,3', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(434, 'YM', 'Yarımamül', 'ARÇELK TKM', '3003580100', 'PİŞİRME HAZNESİ YUVASI ÜST MİNİ TKM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(435, 'YM', 'Yarımamül', 'ARÇELK TKM', '3003590100', 'PISIRME HAZNESI YUVASI ALT (MINI TKM)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(436, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010100', 'PISIRME HAZNESI YUVASI UST BUH TER KAP. TEKLİ', 'ADET', '17', '200', '77', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(437, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010200', 'PIS HAZ YUV UST_NOZZLE TAK BUH TER KAP', 'ADET', '3030', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(438, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010300', 'PISIRME HAZNESI YUVASI UST BUH TER ACK.', 'ADET', '3450', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(439, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580020100', 'PISIRME HAZNESI YUVASI_ALT TEKLİ', 'ADET', '3335', '300', '220', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(440, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580020200', 'PISIRME HAZNESI YUVASI_ALT YENI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(441, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580040100', 'R DESİNG TAŞMA ODASI KAPAĞI', 'ADET', '3175', '130', '16,7', '33', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(442, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580290200', 'PIS HAZ YUV GR_BUH TER DEL ACIK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(443, 'YM', 'Yarımamül', 'ARÇELK TKM', '3583800200', 'HORTUM ARA PARCA KUCUK CAP.', 'ADET', '46150', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(444, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585050100', 'ANA GÖVDE ÜST KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '850', '500', '290', '75', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(445, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585050200', 'ANA GÖVDE ÜST KAPAK DAYAMALI - ARÇELİK ÇAY MAK.', 'ADET', '300', '500', '312', '75', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(446, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585060100', 'ANA GÖVDE ALT KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '110', '350', '404', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(447, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585060200', 'ANA GÖVDE ALT KAPAK BİO - ÇAY MAKİNASI', 'ADET', '2', '350', '404', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(448, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585070100', 'DIKME - ARÇELİK ÇAY MAKİNESİ', 'ADET', '1142', '300', '106,2', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(449, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585100100', 'GÖVDE ARA PARÇA - ARÇELİK ÇAY MAKİNESİ', 'ADET', '10464', '160', '58,5', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(450, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585120100', 'GOVDE KETTLE VALF KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '3966', '130', '3,5', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(451, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585140100', 'SU DAGITICISI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '14964', '130', '13,2', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(452, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585150100', 'KETTLE VALF YAY KLAVUZU - ARÇELİK ÇAY MAKİNESİ', 'ADET', '4817', '80', '1,75', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(453, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585200100', 'IŞIK TAŞIYICI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '2681', '130', '15', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(454, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585220100', 'DEMLEME HAZNESI MEKANIZMA BRAKETI - ÇAY MAKİNESİ', 'ADET', '5740', '160', '22', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(455, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585250100', 'DEMLEME HAZNESİ DIŞ GÖVDE  - ARÇELİK ÇAY MAKİNESİ', 'ADET', '495', '420', '308,2', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(456, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585260100', 'DEMLEME HAZNESİ İÇ GÖVDE', 'ADET', '1849', '420', '286', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(457, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585290100', 'DEMLEME HAZNESI MEKANIZMA KAMI - ÇAY MAKİNESİ', 'ADET', '6320', '160', '3', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(458, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585340100', 'DEMLEME HAZNESI UST KAPAK - ÇAY MAKİNESİ', 'ADET', '1042', '200', '72,75', '56', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(459, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585410100', 'DEMLEME HAZNESI ALT KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '5768', '200', '40,8', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(460, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585420100', 'KAPAK MENTESESI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '1378', '160', '14', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(461, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585480100', 'KARAF SERIT BAGLANTI BRAKETI- ARÇELİK ÇAY MAKİNESİ', 'ADET', '14480', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(462, 'MM', 'Yarımamül', 'ARÇELK TKM', '3586170100', 'GOVDE UST KAPAK  - SERİGRAFİ', 'ADET', '405', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(463, 'YM', 'Yarımamül', 'ARÇELK TKM', '3586410100', 'ALTUS TKM SUS SİSTEMİ PLASTİK - TKM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(464, 'YM', 'Yarımamül', 'ARÇELK TKM', '3586420100', 'ALTUS TKM SU TAHLİYE BORUSU  PLASTİK - TKM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(465, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587090100', 'ALT KAPAK - PROYO', 'ADET', '222', '420', '207', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(466, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587150100', 'DEKORATIF ALT GOVDE - PROYO', 'ADET', '339', '420', '193', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(467, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587160100', 'TASIYICI GOVDE UST SİYAH GRUPSUZ - PROYO', 'ADET', '596', '450', '413,5', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(468, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587160200', 'TASIYICI GOVDE UST BEYAZ - PROYO', 'ADET', '646', '420', '442', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(469, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587400100', 'DEKORATIF CERCEVE - PROYO', 'ADET', '160', '200', '39,1', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(470, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587440100', 'ORTAM AYDINLATMA BAGLANTI BRAKETI - PROYO', 'ADET', '1128', '80', '12,5', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(471, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587450100', 'ORTAM AYDINLATMA ISIK TASIYICI - PROYO', 'ADET', '1536', '130', '1,7', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(472, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587460100', 'ORTAM AYDINLATMA ISIK DAGITICI - PROYO', 'ADET', '1176', '130', '3,8', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(473, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587510100', 'POGO PIN CONTASI - PROYO', 'ADET', '2823', '80', '0,7', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(474, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587540100', 'DEKORATIF ARKA KAPAK - PROYO', 'ADET', '', '300', '80,5', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(475, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587950100', 'UDAQ KAPAGI - PROYO', 'ADET', '', '80', '16,6', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(476, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588370100', 'BASE GÖVDE BEYAZ -  PROYO', 'ADET', '', '420', '440', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(477, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588370200', 'BASE GÖVDE SİYAH -  PROYO', 'ADET', '244', '420', '440', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(478, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560100', 'BASIC GÖVDE SERIGRAFILI ARCELIK -  PROYO', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(479, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560200', 'BASIC GÖVDE SERIGRAFILI BEKO -  PROYO', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(480, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560300', 'BASIC GÖVDE SERIGRAFILI GRUNDİG -  PROYO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(481, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560400', 'BASIC GÖVDE SERIGRAFILI GRUNDİG SİYAH -  PROYO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(482, 'YM', 'Yarımamül', 'ARÇELK TKM', 'Y-XXXX', 'STOK YERI TAKIP DENEME', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(483, 'MM', 'Mamül', 'BSH', '8001229619', 'INSTALLATION KIT FDBM/BM TH SbS2.0', 'ADET', '225', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(484, 'MM', 'Mamül', 'BSH', '8001229621', 'INSTALLATION KIT FDBM/BM TH PACS SbS2.0', 'ADET', '265', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(485, 'MM', 'Mamül', 'BSH', '8001229631', 'INSTALLATION KIT FDBM/BM GG SbS2.0', 'ADET', '17', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(486, 'MM', 'Mamül', 'BSH', '8001229640', 'TRIM KIT FDBM48 TH SbS2.0', 'ADET', '40', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(487, 'MM', 'Mamül', 'BSH', '8001229641', 'TRIM KIT FDBM42 TH SbS2.0', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(488, 'MM', 'Mamül', 'BSH', '8001229642', 'TRIM KIT FDBM36 TH SbS2.0', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(489, 'MM', 'Mamül', 'BSH', '8001229644', 'TRIM KIT FDBM36 GG SbS2.0', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(490, 'MM', 'Mamül', 'BSH', '8001229645', 'TRIM KIT BM36 TH SbS2.0', 'ADET', '4', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(491, 'MM', 'Mamül', 'BSH', '8001229646', 'TRIM KIT BM36 GG SbS2.0', 'ADET', '6', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(492, 'MM', 'Mamül', 'BSH', '8001229647', 'TRIM KIT BM30 GG SbS2.0', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(493, 'MM', 'Mamül', 'BSH', '8001230770', 'TRIM KIT FDBM48 TH PACS SbS2.0', 'ADET', '1', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(494, 'MM', 'Mamül', 'BSH', '8001230771', 'TRIM KIT FDBM42 TH PACS SbS2.0', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(495, 'MM', 'Mamül', 'BSH', '8001230772', 'TRIM KIT FDBM/BM 36 TH PACS SbS2.0', 'ADET', '12', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(496, 'MM', 'Mamül', 'BSH', '8001251203', 'DOOR DIRECTION CHANGE KIT TH SbS2.0', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(497, 'MM', 'Mamül', 'BSH', '8001251214', 'DOOR DIRECTION CHANGE KIT GG BM36 SbS2.0', 'ADET', '5', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(498, 'MM', 'Mamül', 'BSH', '8001251218', 'DOOR DIRECTION CHANGE KIT GG BM30 SbS2.0', 'ADET', '5', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(499, 'MM', 'Mamül', 'GOLDMASTER', '40012', 'MEDİSANA HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(500, 'MM', 'Mamül', 'GOLDMASTER', '40014', 'MEDİSANA HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(501, 'MM', 'Mamül', 'GOLDMASTER', '9Y72570004', 'GM7257 PLANET ANA GÖVDE', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(502, 'MM', 'Mamül', 'GOLDMASTER', 'AV-1006', 'AVCI HOME MAKER RONDOMA  DOĞRAYICI+ İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(503, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4303', 'COLOMBIA FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(504, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4305', 'TAZEM FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(505, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4310', 'BLISS FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(506, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4500', 'SWEEP ELEKTRİKLİ SÜPÜRGE- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(507, 'MM', 'Mamül', 'GOLDMASTER', 'BY-5312', 'MAESTRO SİYAH-MOR  FİLTRE KAHVE MAKİNESİ  +İŞÇİLİK', 'ADET', '31', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(508, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7236', 'GM-7236 NARİN NARENCİYE SIKACAĞI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(509, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7257', 'PLANET RONDO MAKİNASI + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(510, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7276', 'GM-7236 PROFRESH NARENCİYE SIKACAĞI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(511, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7277', 'PROCHOPPER RONDO MAKİNASI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(512, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7297', 'CHOPPERIX RONDO MAKİNASI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(513, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7331', 'ZİNDE FİLTRE KAHVE MAKİNESİ GM-7331 + İŞÇİLİK', 'ADET', '1', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(514, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7331K', 'ZİNDE FİLTRE KAHVE MAKİNESİ KIRMIZI KUPA + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(515, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7332', 'ALTIN TELVE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '2', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(516, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7347', 'PERFECTTO FİLTRE KAHVE MAKİNESİ  +  İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(517, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7348', 'ÖMRÜM  FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(518, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7349', 'DROPS FİLTRE KAHVE MAKİNESİ GOLDMASTER +(İŞÇİLİK)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(519, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7351', 'TUTKU FİLTRE KAHVE MAKİNESİ GM7351 - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(520, 'MM', 'Mamül', 'GOLDMASTER', 'GM7363', 'BEGONVİL SU ISITICISI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(521, 'MM', 'Mamül', 'GOLDMASTER', 'GM7364', 'LALEDEM ÇAY MAKİNASI - GOLDMASTER', 'ADET', '8', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(522, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7365', 'GEZGİN FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(523, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7365G', 'GEZGİN GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(524, 'MM', 'Mamül', 'GOLDMASTER', 'GM7520', 'NAZAR DİK SÜPÜRGE GM7520 - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(525, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7535', 'YILDIZ ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(526, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7553B', 'GM-7553B PİCKY BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(527, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7553S', 'GM-7553S PİCKY SİYAH - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(528, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7554B', 'GM-7554B AUTOMAX BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(529, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7554S', 'GM-7554S AUTOMAX SİYAH- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(530, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7555', 'PROGREEN ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(531, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7558', 'SÜPER GÜÇ ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(532, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7912B', 'NEMO SİYAH - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(533, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7912W', 'NEMO BEYAZ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(534, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7913', 'AİR THERAPY BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(535, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7934', 'MİSTİK HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(536, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7936', 'SERİN VANTİLATÖR  İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(537, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6108', 'TRENDCOFFEE FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(538, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6300', 'COFFEE SMART FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(539, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6303', 'KEYF-İ KAHVE  FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(540, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6304', 'Bİ KAHVE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(541, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6305', 'COFFEE CHEF FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(542, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6310', 'MAGİC COFFEE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(543, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6314', 'COFFE CLASSİCO FİLTRE KAHVE MAKİNESİ +İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(544, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6320', 'FLORA FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(545, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6330', 'KARNAVAL FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL);
INSERT INTO `malzeme_tanimlari` (`malzeme_id`, `malzeme_tur`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`) VALUES
(546, 'MM', 'Mamül', 'GOLDMASTER', 'MC-100', 'LIKE MY COFFEE FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(547, 'MM', 'Mamül', 'GOLDMASTER', 'MC-102', 'RELAX GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(548, 'MM', 'Mamül', 'GOLDMASTER', 'PB-3231', 'PROBELLO FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(549, 'MM', 'Mamül', 'GOLDMASTER', 'PC-3202', 'PROCOFFEE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(550, 'MM', 'Mamül', 'GOLDMASTER', 'QC-039', 'PRESTON FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(551, 'MM', 'Mamül', 'GOLDMASTER', 'QC-039G', 'PRESTON GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(552, 'MM', 'Mamül', 'GOLDMASTER', 'QVC-25C', 'CARBON ELEKTRİKLİ SÜPÜRGE - QUEEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(553, 'MM', 'Mamül', 'GOLDMASTER', 'QVC-25N', 'NORTHERN ELEKTRİKLİ SÜPÜRGE - QUEEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(554, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7312', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ ST-7312 + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(555, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7314', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ ST-7314 + İŞÇİLİK', 'ADET', '8', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(556, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7334', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ GEZGİN + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(557, 'MM', 'Mamül', 'GOLDMASTER', 'T5TERMOTTI', 'NİCE TERMOTTİ FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(558, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM001G', 'TANTİTONİ GOLD FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(559, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM001K', 'TANTİTONİ KIRMIZI FİLTRE KAHVE MAKİNESİ+İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(560, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM002', 'TANTİTONİ KEYİF INOX FİLTRE KAHVE MAKİNESİ + İŞÇİL', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(561, 'MM', 'Mamül', 'GOLDMASTER', 'TT-CR15IN', 'TANTİTONİ DOĞRAYICI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(562, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300007', 'MOTOR ALT KAPAĞI - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(563, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300029', 'MOTOR YUVASI - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(564, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300056', 'MOTOR KAFESİ - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(565, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310003', 'GÖVDE - ZİNDE KAHVE MAKİNASI', 'ADET', '590', '200', '128', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(566, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310003-B', 'GÖVDE BEYAZ - ZİNDE KAHVE MAKİNASI', 'ADET', '147', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(567, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310004', 'SU TANKI ARKA KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '1160', '200', '162', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(568, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310009', 'ALT KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '3791', '130', '55', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(569, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310010', 'ÜST KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '2310', '130', '40,5', '48', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(570, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310015', 'DÜGME ÇERÇEVESİ - ZİNDE KAHVE MAKİNASI', 'ADET', '157', '130', '1', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(571, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310022', 'VİDA KAPAĞI - ZİNDE KAHVE MAKİNASI', 'ADET', '53968', '130', '1', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(572, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310028-1', 'REZİSTANS KOMPLE GRUPLAMA - ZİNDE KAHVE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(573, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310036', 'KABLO SABİTLEYİCİ 1 USA - ZİNDE KAHVE MAKİNASI', 'ADET', '124', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(574, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310037', 'KABLO SABİTLEYİCİ 2 VDE - ZİNDE KAHVE MAKİNASI', 'ADET', '2413', '130', '1', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(575, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470015', 'FİLTRE - TUTKU KAHVE MAKİNASI', 'ADET', '5220', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(576, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470022', 'BARDAK ALT KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2357', '160', '18,5', '36', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(577, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470023', 'BARDAK ÜST KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2797', '160', '8', '36', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(578, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470025', 'BUTON ÇERÇEVESİ - TUTKU KAHVE MAKİNASI', 'ADET', '2757', '130', '1', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(579, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470026', 'BARDAK GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '2128', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(580, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470027', 'DAMITMA SU BORUSU - TUTKU KAHVE MAKİNASI', 'ADET', '2748', '130', '3', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(581, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470028', 'BUTON BASKISIZ - TUTKU KAHVE MAKİNASI', 'ADET', '165', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(582, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470030', 'ALT GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '2142', '300', '165', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(583, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470031', 'METAL YÜKSELTME PLASTİĞİ - TUTKU KAHVE MAKİNASI', 'ADET', '5547', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(584, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470032', 'ŞALTER KAPAMA PLASTİĞİ - TUTKU KAHVE MAKİNASI', 'ADET', '1065', '130', '1', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(585, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470033', 'VALF - TUTKU KAHVE MAKİNASI', 'ADET', '5540', '130', '1', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(586, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470034', 'DAMITMA BORUSU ÜST - TUTKU KAHVE MAKİNASI', 'ADET', '1016', '130', '5', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(587, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470035', 'DAMITMA BORUSU ALT - TUTKU KAHVE MAKİNASI', 'ADET', '1265', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(588, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470036', 'TERMOSTAT KAPAĞI - TUTKU KAHVE MAKİNASI', 'ADET', '2018', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(589, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470037', 'BARDAK ÜST KAPAK SÜRGÜSÜ - TUTKU KAHVE MAKİNASI', 'ADET', '7049', '130', '6', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(590, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470038', 'ÜST GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '1577', '300', '135', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(591, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470039', 'ALT KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '4346', '200', '39', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(592, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470040', 'ÜST KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2800', '200', '39', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(593, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470044', 'FİLTRE YUVASI - TUTKU KAHVE MAKİNASI', 'ADET', '4572', '200', '24', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(594, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570007', 'GM7357 SU SEVİYE GÖSTERGESİ', 'ADET', '560', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(595, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570043', 'GM7357 SU TANKI  - HAZZ', 'ADET', '66', '420', '265', '80', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(596, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570044', 'GM7357 ANA GÖVDE  - HAZZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(597, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570045', 'GM7357 ÜST KAPAK  - HAZZ', 'ADET', '188', '300', '74', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(598, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570046', 'GM7357 ALT KAPAK - HAZZ', 'ADET', '150', '300', '74', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(599, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570047', 'GM7357 FİLTRE YUVASI DESTEK PARÇASI - HAZZ', 'ADET', '', '200', '116', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(600, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200038', 'GM7520 SOL GÖVDE - NAZAR DİK SÜPÜRGE', 'ADET', '150', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(601, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200039', 'GM7520 SAĞ GÖVDE - NAZAR DİK SÜPÜRGE', 'ADET', '108', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(602, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200043', 'GM7520 TOZ DEPOSU - NAZAR DİK SÜPÜRGE', 'ADET', '851', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(603, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350005', 'SAĞ GÖVDE KAPAĞI - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(604, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350006', 'SOL GÖVDE KAPAĞI - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(605, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350048', 'ÜST GÖVDE  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(606, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350049', 'ALT GÖVDE  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(607, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350062', 'MOTOR KORUMA KAFESİ  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(608, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350069', 'TOZ HAZNESİ - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(609, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350070', 'TOZ HAZNE ÜST KAPAK - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(610, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7535Y048', 'GM7535 ÜST GÖVDE YEŞİL - PROGREEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(611, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7535Y049', 'GM7535 ALT GÖVDE YEŞİL - PROGREEN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(612, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75530024', 'TOZ HAZNE - ŞARJLI SÜPÜRGE', 'ADET', '302', '200', '153', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(613, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553B020', 'SOL GÖVDE BEYAZ - ŞARJLI  SÜPÜRGE', 'ADET', '373', '200', '108', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(614, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553B021', 'SAĞ GÖVDE BEYAZ - ŞARJLI  SÜPÜRGE', 'ADET', '491', '200', '108', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(615, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553S020', 'SOL GÖVDE SİYAH - ŞARJLI  SÜPÜRGE', 'ADET', '597', '200', '108', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(616, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553S021', 'SAĞ GÖVDE SİYAH - ŞARJLI  SÜPÜRGE', 'ADET', '457', '200', '108', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(617, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100011', 'HAVA NEM.SU GİRİŞ KAPAĞI - MİSTO', 'ADET', '4935', '200', '12', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(618, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100012', 'HAVA NEM.SU TANKI ÜST GÖVDE - MİSTO', 'ADET', '827', '420', '376', '90', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(619, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100013', 'HAVA NEM.GÖVDE ALT KAPAK - MİSTO', 'ADET', '2874', '200', '74', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(620, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100014', 'HAVA NEM.GÖVDE - MİSTO', 'ADET', '644', '420', '198', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(621, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100015', 'SU TANK ALT KAPAK - MİSTO', 'ADET', '2693', '200', '96', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(622, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100016', 'CONTA ÇUBUĞU - MİSTO', 'ADET', '2423', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(623, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100017', 'ŞAMANDIRA TUTUCU - MİSTO', 'ADET', '2317', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(624, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100018', 'ANAHTAR SABİTLEYİCİ - MİSTO', 'ADET', '2020', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(625, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100019', 'BUHAR KAPAĞI ÜST - MİSTO', 'ADET', '2214', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(626, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100020', 'BUHAR KAPAĞI ALT - MİSTO', 'ADET', '3503', '200', '5', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(627, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100021', 'HAVA NEM.BUHAR ELEĞİ FİLE - MİSTO', 'ADET', '5548', '130', '3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(628, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100022', 'HAVA NEM.LED KAPAK - MİSTO', 'ADET', '3438', '130', '3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(629, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100031', 'HAVA NEM.GÜÇ GÖSTERGE PLASTİĞİ - MİSTO', 'ADET', '4408', '130', '3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(630, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100032', 'HAVA NEM.SU SEVİYE GÖSTERGE PLS. - MİSTO', 'ADET', '3382', '130', '3', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(631, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120021', 'GM7912 SU GİRİŞ KAPAĞI - NEMO', 'ADET', '5122', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(632, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120023', 'GM7912 SU TANK ALT GÖVDE SİYAH - NEMO', 'ADET', '5208', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(633, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120024', 'GM7912 ANA GÖVDE SİYAH - NEMO', 'ADET', '3926', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(634, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120025', 'GM7912 ANA GÖVDE ALT KAPAK SİYAH - NEMO', 'ADET', '4271', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(635, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120026', 'GM7912 CONTA PİMİ SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(636, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120027', 'GM7912 ŞAMANDIRA TUTUCU SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(637, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120029', 'GM7912 BUHAR SEPERATÖRÜ ÖN SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(638, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120030', 'GM7912 BUHAR SEPERATÖRÜ ARKA SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(639, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120031', 'GM7912 TANK SAPI SİYAH - NEMO', 'ADET', '24', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(640, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120032', 'GM7912 MANYETİK ANAHTAR SABİTLEYİCİ - NEMO', 'ADET', '70', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(641, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120033', 'GM7912 LED KAPAK BÜYÜK ŞEFFAF - NEMO', 'ADET', '7961', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(642, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120034', 'GM7912 LED KAPAK KÜÇÜK ŞEFFAF - NEMO', 'ADET', '7947', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(643, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120046', 'GM7912 GÜÇ AYAR DÜĞME YUVASI SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(644, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120047', 'GM7912 DÜĞME SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(645, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120049', 'GM7912 KABLO TUTUCU SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(646, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120050', 'GM7912 AIRMIST SU TANKI ÜST GÖVDE - NEMO', 'ADET', '1208', '420', '382', '100', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(647, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120108', 'GM7912 LED KAPAK BÜYÜK ŞEFFAF PLASTİK AKSAM HM.', 'ADET', '60', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(648, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120109', 'GM7912 LED KAPAK KÜÇÜK ŞEFFAF PLASTİK AKSAM HM.', 'ADET', '60', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(649, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130021', 'GM7913 SU GİRİŞ KAPAĞI BEYAZ - NEMO', 'ADET', '2319', '130', '18', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(650, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130022', 'GM7913 SU TANKI(NEC) - NEMO', 'ADET', '511', '420', '345', '100', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(651, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130023', 'GM7913 SU TANK TABAN BEYAZ - NEMO', 'ADET', '1361', '200', '92', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(652, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130024', 'GM7912 ANA GÖVDE BEYAZ - NEMO', 'ADET', '1441', '200', '222', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(653, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130025', 'GM7913 ANA GÖVDE TABAN BEYAZ - NEMO', 'ADET', '4467', '200', '70', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(654, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130026', 'GM7913 CONTA ÇUBUĞU BEYAZ - NEMO', 'ADET', '1932', '80', '1', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(655, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130027', 'GM7913 ŞAMANDIRA TUTUCU BEYAZ  - NEMO', 'ADET', '1822', '80', '1,2', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(656, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130029', 'GM7913 BUHAR SEPERATÖRÜ ÖN BEYAZ - NEMO', 'ADET', '208', '80', '6', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(657, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130030', 'GM7913 BUHAR SEPERATÖRÜ ARKA BEYAZ - NEMO', 'ADET', '', '80', '12', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(658, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130031', 'GM7913 TANK SAPI BEYAZ - NEMO', 'ADET', '1787', '80', '3', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(659, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130032', 'GM7913 LED SABİTLEYİCİ BEYAZ - NEMO', 'ADET', '1947', '80', '2', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(660, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130046', 'GM7913 GÜÇ AYAR DÜĞME YUVASI BEYAZ - NEMO', 'ADET', '', '130', '10', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(661, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130047', 'GM7913 DÜĞME BEYAZ - NEMO', 'ADET', '10', '80', '3,8', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(662, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130049', 'GM7913 KABLO TUTUCU BEYAZ - NEMO', 'ADET', '2047', '80', '2', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(663, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130100', 'GM7913 SU TANKI (NEC) PLASTİK AKSAM HM.', 'ADET', '120', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(664, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130101', 'GM7913 SU GİRİŞ KAPAĞI BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(665, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130102', 'GM7913 SU TANK TABAN BEYAZ PLASTİK AKSAM HM.', 'ADET', '17', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(666, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130103', 'GM7913 ANA GÖVDE BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(667, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130104', 'GM7913 ANA GÖVDE TABAN BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(668, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130105', 'GM7913 CONTA ÇUBUĞU BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(669, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130106', 'GM7913 ŞAMANDIRA TUTUCU BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(670, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130107', 'GM7913 TANK SAPI BEYAZ BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(671, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130108', 'GM7913 LED SABİTLEYİCİ BEYAZ PLASTİK AKSAM HM', 'ADET', '17', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(672, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130109', 'GM7913 KABLO TUTUCU BEYAZ PLASTİK AKSAM HM.', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(673, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130110', 'GM7913 BUHAR SEPERATÖRÜ ÖN BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(674, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130111', 'GM7913 BUHAR SEP.  ARKA BEYAZ PLASTİK AKSAM HM.', 'ADET', '17', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(675, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130112', 'GM7913 GÜÇ AYAR DÜĞME YUVASI BYZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(676, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130113', 'GM7913 DÜĞME BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(677, 'MM', 'Mamül', 'HASEL', 'MML0451', 'ALT ÇITA PLASTİK KAPAK - HASEL', 'ADET', '', '160', '10,25', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(678, 'MM', 'Mamül', 'HASEL', 'MML0486', 'HIZ AYARLAYICI DİŞLİ KAPAK - HASEL', 'ADET', '20', '130', '4', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(679, 'MM', 'Mamül', 'HASEL', 'MML0487', 'HIZ AYARLAYICI PUL - HASEL', 'ADET', '4', '130', '1', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(680, 'MM', 'Mamül', 'HASEL', 'MML0488', 'HIZ AYARLAYICI BAĞLANTI PARÇASI - HASEL', 'ADET', '20', '130', '7', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(681, 'MM', 'Mamül', 'HASEL', 'MML0489', 'HIZ AYARLAYICI MEKANİZMA GÖVDESİ - HASEL', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(682, 'MM', 'Mamül', 'HASEL', 'MML0490', 'HIZ AYARLAYICI PALET - HASEL', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(683, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0001', 'TABLDOT ABS', 'ADET', '6614', '200', '320', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(684, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '200', NULL, NULL, NULL, NULL, '', 'Yavuz BEKEM', '2023-12-28 22:20:07', 'ATAKAN CESUR', '2025-02-12 17:36:37'),
(685, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0004', 'TABLDOT ABS GRİ', 'ADET', '1600', '200', '320', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(686, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0005', 'TABLDOT PC - RENKLİ', 'ADET', '', '200', '330', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(687, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0006', 'TABLDOT ABS - KAHVERENGİ', 'ADET', '', '200', '320', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(688, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0007', 'TABLDOT PC - BEYAZ', 'ADET', '120', '200', '330', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(689, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0008', 'TABLDOT V0 - BEYAZ', 'ADET', '23,5', '200', '340', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(690, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0010', 'TABLDOT KÜÇÜK BOY BEYAZ', 'ADET', '43', '200', '240', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(691, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0011', 'TABLDOT KÜÇÜK BOY GRİ', 'ADET', '', '200', '240', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(692, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0012', 'TABLDOT KÜÇÜK BOY KIRMIZI', 'ADET', '', '200', '240', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(693, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0020', 'ÇAY TEPSİ FANUS KAPAK', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(694, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0021', 'BÜYÜK TEPSİ SİYAH ABS', 'ADET', '2240', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(695, 'MM', 'Mamül', 'İDEAL END.', 'İDL-HB-001', 'HUBUBAT SİYAH', 'ADET', '120', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(696, 'MM', 'Mamül', 'İDEAL END.', 'İDL-HB-002', 'HUBUBAT BEYAZ', 'ADET', '300', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(697, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-01', 'HUBUBAT ALT GÖVDE SİYAH', 'ADET', '283', '160', '240', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(698, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-02', 'HUBUBAT ÜST KAPAK SİYAH', 'ADET', '271', '200', '66', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(699, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-03', 'HUBUBAT AKSESUAR SİYAH', 'ADET', '730', '200', '3', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(700, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-04', 'HUBUBAT BUTON SİYAH', 'ADET', '245', '130', '25', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(701, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-05', 'HUBUBAT ÇEKMECE', 'ADET', '', '200', '95', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(702, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-06', 'HUBUBAT ÜST GÖVDE', 'ADET', '284', '200', '245', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(703, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-01', 'HUBUBAT ALT GÖVDE BEYAZ', 'ADET', '200', '160', '240', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(704, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-02', 'HUBUBAT ÜST KAPAK BEYAZ', 'ADET', '', '200', '66', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(705, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-03', 'HUBUBAT AKSESUAR BEYAZ', 'ADET', '220', '200', '3', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(706, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-04', 'HUBUBAT BUTON BEYAZ', 'ADET', '75', '130', '25', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(707, 'MM', 'Mamül', 'POLİZA', 'P.İ-101', 'PERDE KOLON PASPAYI_15 MM', 'ADET', '12770', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(708, 'MM', 'Mamül', 'POLİZA', 'P.İ-102', 'PERDE KOLON PASPAYI_20 MM', 'ADET', '7170', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(709, 'MM', 'Mamül', 'POLİZA', 'P.İ-103', 'PERDE KOLON PASPAYI_25 MM', 'ADET', '34750', '130', '7,4', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(710, 'MM', 'Mamül', 'POLİZA', 'P.İ-104', 'PERDE KOLON PASPAYI_30 MM', 'ADET', '2255', '130', '11', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(711, 'MM', 'Mamül', 'POLİZA', 'P.İ-105', 'PERDE KOLON PASPAYI_40 MM', 'ADET', '1400', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(712, 'MM', 'Mamül', 'POLİZA', 'P.İ-106', 'PERDE KOLON PASPAYI_50 MM', 'ADET', '550', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(713, 'MM', 'Mamül', 'POLİZA', 'P.İ-204', 'MANDAL PASPAYI 15 MM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(714, 'MM', 'Mamül', 'POLİZA', 'P.İ-207', 'MANDAL PASPAYI 30 MM', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(715, 'MM', 'Mamül', 'POLİZA', 'P.İ-308', 'NORM AĞIR TİP DÖŞEME PASPAYI_20 MM', 'ADET', '3220', '130', '9', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(716, 'MM', 'Mamül', 'POLİZA', 'P.İ-309', 'NORM AĞIR TİP DÖŞEME PASPAYI_25 MM', 'ADET', '43534', '130', '12', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(717, 'MM', 'Mamül', 'POLİZA', 'P.İ-312', 'NORM AĞIR TİP DÖŞEME PASPAYI_50 MM', 'ADET', '7895', '130', '20', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(718, 'MM', 'Mamül', 'POLİZA', 'P.İ-414', 'RAY TİPİ HASIR DÖŞEME PASPAYI 20 MM', 'ADET', '6323', '130', '16', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(719, 'MM', 'Mamül', 'POLİZA', 'P.İ-415', 'RAY TİPİ HASIR DÖŞEME PASPAYI 25 MM', 'ADET', '3890', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(720, 'MM', 'Mamül', 'POLİZA', 'P.İ-515', 'ÇEMBER TİPİ DÖŞEME PASPAYI 15 MM', 'ADET', '1200', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(721, 'MM', 'Mamül', 'POLİZA', 'P.İ-516', 'ÇEMBER TİPİ DÖŞEME PASPAYI 20 MM', 'ADET', '408', '130', '24', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(722, 'MM', 'Mamül', 'POLİZA', 'P.İ-720', 'TIE-ROT KORUYUCU BAŞLIK İÇ ÇAP 18', 'ADET', '1178', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(723, 'MM', 'Mamül', 'POLİZA', 'P.İ-722', 'TIE-ROT KORUYUCU BAŞLIK İÇ ÇAP 24', 'ADET', '5513', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(724, 'MM', 'Mamül', 'POVAG', '10.11.15.020.95.00', 'seperator 200 mm black', 'ADET', '424', '300', '37', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(725, 'MM', 'Mamül', 'POVAG', '10.11.15.025.95.00', 'seperator 250 mm black', 'ADET', '169', '300', '55', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(726, 'MM', 'Mamül', 'POVAG', '10.11.15.030.50.01', 'seperator 300 mm blue', 'ADET', '72', '300', '86', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(727, 'MM', 'Mamül', 'POVAG', '10.11.15.030.95.00', 'seperator 300 mm black', 'ADET', '32629', '300', '86', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(728, 'MM', 'Mamül', 'POVAG', '10.11.15.045.95.00', 'seperator 450 mm black', 'ADET', '812', '300', '146', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(729, 'MM', 'Mamül', 'POVAG', '10.70.41.004.95.00', 'Insert bin 4 compartments', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(730, 'MM', 'Mamül', 'POVAG', '10.70.41.006.95.00', 'Insert bin 6 compartments', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(731, 'MM', 'Mamül', 'POVAG', '10.70.41.008.95.00', 'Insert bin 8 compartments', 'ADET', '540', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(732, 'MM', 'Mamül', 'POVAG', '10.70.50.001.00.00', 'Kantelbak No.15 - transparent 150x115x110 mm', 'ADET', '299', '130', '175', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(733, 'MM', 'Mamül', 'POVAG', '10.70.50.002.00.00', 'Kantelbak No.7,5 - transparent 75x115x110 mm', 'ADET', '800', '80', '78', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(734, 'MM', 'Mamül', 'POVAG', '10.70.50.003.50.00', 'Kantelbak Unit - blue 160x115x110 mm', 'ADET', '', '160', '180', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(735, 'MM', 'Mamül', 'POVAG', '10.70.50.003.95.00', 'Kantelbak Unit - black 160x115x110 mm', 'ADET', '280', '160', '180', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(736, 'MM', 'Mamül', 'POVAG', '10.70.50.033.10.00', 'Bin nr. 33 - name plate Povag - yellow 92x320x92mm', 'ADET', '', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(737, 'MM', 'Mamül', 'POVAG', '10.70.50.033.30.00', 'Bin nr. 33 - name plate Povag - red 92x320x92 mm', 'ADET', '540', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(738, 'MM', 'Mamül', 'POVAG', '10.70.50.033.50.00', 'Bin nr. 33 - name plate Povag - blue 92x320x92 mm', 'ADET', '10075', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(739, 'MM', 'Mamül', 'POVAG', '10.70.50.033.50.01', 'Bin nr. 43 - name plate fabory - no etiket - blue', 'ADET', '1190', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(740, 'MM', 'Mamül', 'POVAG', '10.70.50.033.80.00', 'Bin nr. 33 - name plate Povag - green 92x320x92 mm', 'ADET', '327', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(741, 'MM', 'Mamül', 'POVAG', '10.70.50.033.95.00', 'Bin nr. 33 - name plate Povag - black 92x320x92 mm', 'ADET', '60', '160', '257', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(742, 'MM', 'Mamül', 'POVAG', '10.70.50.048.10.00', 'Bin nr. 48 - name plate Povag - yellow 115x320x92m', 'ADET', '', '160', '310', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(743, 'MM', 'Mamül', 'POVAG', '10.70.50.048.30.00', 'Bin nr. 48 - name plate Povag - red 115x320x92mm', 'ADET', '1104', '160', '310', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(744, 'MM', 'Mamül', 'POVAG', '10.70.50.048.50.00', 'Bin nr. 48 - name plate Povag - blue 115x320x92mm', 'ADET', '35', '160', '310', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(745, 'MM', 'Mamül', 'POVAG', '10.70.50.048.50.01', 'Bin nr. 58 - name plate fabory - no etiket - blue', 'ADET', '12', '160', '310', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(746, 'MM', 'Mamül', 'POVAG', '10.70.50.048.95.00', 'Bin nr. 48 - name plate Povag - black 115x320x92mm', 'ADET', '', '160', '310', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(747, 'MM', 'Mamül', 'POVAG', '10.70.50.052.10.00', 'Bin nr. 52 - name plate Povag - yellow 205x350x165', 'ADET', '208', '300', '643', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(748, 'MM', 'Mamül', 'POVAG', '10.70.50.052.30.00', 'Bin nr. 52 - name plate Povag - red  205x350x165', 'ADET', '', '300', '643', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(749, 'MM', 'Mamül', 'POVAG', '10.70.50.052.50.00', 'Bin nr. 52 - name plate Povag - blue   205x350x165', 'ADET', '160', '300', '643', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(750, 'MM', 'Mamül', 'POVAG', '10.70.50.052.95.00', 'Bin nr. 52 - name plate Povag - black 205x350x165', 'ADET', '', '300', '643', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(751, 'MM', 'Mamül', 'POVAG', '10.70.50.053.10.00', 'Bin nr. 53 - name plate Povag-yellow 150x240x130mm', 'ADET', '3072', '160', '300', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(752, 'MM', 'Mamül', 'POVAG', '10.70.50.053.30.00', 'Bin nr. 53 - name plate Povag - red 150x240x130mm', 'ADET', '1369', '160', '300', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(753, 'MM', 'Mamül', 'POVAG', '10.70.50.053.50.00', 'Bin nr. 53 - name plate Povag - blue 150x240x130mm', 'ADET', '1430', '160', '300', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(754, 'MM', 'Mamül', 'POVAG', '10.70.50.053.50.01', 'Bin nr. 83 - name plate fabory - no etiket - blue', 'ADET', '48', '160', '300', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(755, 'MM', 'Mamül', 'POVAG', '10.70.50.053.95.00', 'Bin nr. 53 - name plate Povag -black 150x240x130mm', 'ADET', '3264', '160', '300', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(756, 'MM', 'Mamül', 'POVAG', '10.70.50.054.10.00', 'Bin nr. 54 - name plate Povag -yellow 105x175x75mm', 'ADET', '1301', '80', '100', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(757, 'MM', 'Mamül', 'POVAG', '10.70.50.054.30.00', 'Bin nr. 54 - name plate Povag - red 105x175x75mm', 'ADET', '2576', '80', '100', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(758, 'MM', 'Mamül', 'POVAG', '10.70.50.054.50.00', 'Bin nr. 54 - name plate Povag - blue 105x175x75mm', 'ADET', '6174', '80', '100', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(759, 'MM', 'Mamül', 'POVAG', '10.70.50.054.95.00', 'Bin nr. 54 - name plate Povag - black 105x175x75mm', 'ADET', '5246', '80', '100', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(760, 'MM', 'Mamül', 'POVAG', '10.70.50.055.10.00', 'Bin nr. 55 - without name plate-yellow 105x90x50mm', 'ADET', '4680', '130', '40', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(761, 'MM', 'Mamül', 'POVAG', '10.70.50.055.30.00', 'Bin nr. 55 - without name plate-red 105x90x50mm', 'ADET', '', '130', '40', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(762, 'MM', 'Mamül', 'POVAG', '10.70.50.063.10.00', 'Bin nr. 63 - name plate Povag -yellow 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(763, 'MM', 'Mamül', 'POVAG', '10.70.50.063.30.00', 'Bin nr. 63 - name plate Povag - red 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(764, 'MM', 'Mamül', 'POVAG', '10.70.50.063.50.00', 'Bin nr. 63 - name plate Povag - blue 184x320x92mm', 'ADET', '4608', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(765, 'MM', 'Mamül', 'POVAG', '10.70.50.063.50.01', 'Bin nr. 93 - name plate fabory - blue 184x320x92mm', 'ADET', '34', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(766, 'MM', 'Mamül', 'POVAG', '10.70.50.063.80.00', 'Bin nr. 63 - name plate Povag - green 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(767, 'MM', 'Mamül', 'POVAG', '10.70.50.063.95.00', 'Bin nr. 63 - name plate Povag - black 184x320x92mm', 'ADET', '18', '300', '480', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(768, 'MM', 'Mamül', 'POVAG', '10.71.50.024.00.00', 'Width seperator bin 85 - transparent', 'ADET', '3600', '80', '14', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(769, 'MM', 'Mamül', 'POVAG', '10.71.50.025.00.00', 'Width seperator bin 33 - transparent', 'ADET', '750', '80', '14', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(770, 'MM', 'Mamül', 'POVAG', '10.71.50.027.00.00', 'Depth seperator bin 63 - transparent', 'ADET', '111', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(771, 'MM', 'Mamül', 'SARUHAN', '11000762', 'ARKA GÖVDE - HOBBY - KREM', 'ADET', '', '350', '623', '120', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(772, 'MM', 'Mamül', 'SARUHAN', '11003198', 'EMOTİON ALT GÖVDE SİYAH', 'ADET', '168', '500', '719', '76', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(773, 'MM', 'Mamül', 'SARUHAN', '11003199', 'EMOTİON ÖN KAPAK KIRMIZI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(774, 'MM', 'Mamül', 'SARUHAN', '11003200', 'EMOTİON ARKA KAPAK SİYAH', 'ADET', '2', '350', '430', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(775, 'MM', 'Mamül', 'SARUHAN', '11003203', 'EMOTİON HAVA ÇIKIŞ KAPAĞI GRİ', 'ADET', '', '160', '46,6', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(776, 'MM', 'Mamül', 'SARUHAN', '11003208', 'EMOTİON AKSESUAR KAPAĞI SİYAH', 'ADET', '126', '160', '66', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(777, 'MM', 'Mamül', 'SARUHAN', '11003212', 'EMOTİON ALT GÖVDE ÖN PLASTİK SİYAH', 'ADET', '', '80', '23', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(778, 'MM', 'Mamül', 'SARUHAN', '11003218', 'EMOTİON BÜYÜK TEKERLEK SİYAH', 'ADET', '290', '160', '53', '36', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(779, 'MM', 'Mamül', 'SARUHAN', '11003220', 'EMOTİON BÜYÜK TEKERLEK KAPAĞI GRİ', 'ADET', '', '80', '6,79', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(780, 'MM', 'Mamül', 'SARUHAN', '11003249', 'EMOTİON GÜÇ AYAR DÜĞMESİ', 'ADET', '', '130', '2,9', '25', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(781, 'MM', 'Mamül', 'SARUHAN', '11003549', 'KAHVE FİLTRESİ KAPAK - PCM - SARUHAN', 'ADET', '', '80', '85', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(782, 'MM', 'Mamül', 'SARUHAN', '11003552', 'KAHVE SU HAZNE KAPAK - KREM- PCM - SARUHAN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(783, 'MM', 'Mamül', 'SARUHAN', '11003554', 'KAHVE ÖN GÖVDE - KIRMIZI - PCM - SARUHAN', 'ADET', '2977', '300', '168', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(784, 'MM', 'Mamül', 'SARUHAN', '11003555', 'KAHVE ARKA GÖVDE - PCM - SARUHAN', 'ADET', '39', '300', '206', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(785, 'MM', 'Mamül', 'SARUHAN', '11003611', 'KAHVE SU HAZNE KAPAK - KIRMIZI - PCM - SARUHAN', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(786, 'MM', 'Mamül', 'SARUHAN', '11003930', 'TABAN PLASTİĞİ - SİYAH - TVL90S', 'ADET', '', '160', '130', '36', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(787, 'MM', 'Mamül', 'SARUHAN', '11003931', 'TABAN - K.BEYAZ - TVL90S  -   Serigrafi', 'ADET', '452', '200', '212', '43', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(788, 'MM', 'Mamül', 'SARUHAN', '11003933', 'HALKA - ALT-TABAN - K.BEYAZ - TVL90S', 'ADET', '', '160', '15,53', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(789, 'MM', 'Mamül', 'SARUHAN', '11003934', 'HALKA - ÜST BAGLANTI - K.BEYAZ - TVL90S', 'ADET', '', '160', '13,59', '38', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(790, 'MM', 'Mamül', 'SARUHAN', '11003938', 'ARKA GÖVDE - K.BEYAZ - TVL90S', 'ADET', '75', '500', '644', '73', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(791, 'MM', 'Mamül', 'SARUHAN', '11003941', 'MOTOR SAĞ GÖVDE - SİYAH - TVL90S', 'ADET', '', '500', '355', '73', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(792, 'MM', 'Mamül', 'SARUHAN', '11003942', 'MOTOR SOL GÖVDE - SİYAH - TVL90S', 'ADET', '', '500', '310', '73', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(793, 'MM', 'Mamül', 'SARUHAN', '11003944', 'YÖNLENDİRİCİ BRAKET - SİYAH - TVL90S', 'ADET', '700', '160', '4', '48', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(794, 'MM', 'Mamül', 'SARUHAN', '11003945', 'PANJUR - SİYAH - TVL90S', 'ADET', '', '160', '5', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(795, 'MM', 'Mamül', 'SARUHAN', '11003946', 'ÖN GÖVDE - K.BEYAZ - TVL90S - Serigrafi', 'ADET', '', '420', '362', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(796, 'MM', 'Mamül', 'SARUHAN', '11003948', 'ALICI CAMI - ŞEFFAF AÇIK SİYAH - TVL90S', 'ADET', '', '80', '2', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(797, 'MM', 'Mamül', 'SARUHAN', '11003949', 'UZAKTAN KUMANDA TUTUCU - K.BEYAZ -TVL90S', 'ADET', '25', '80', '10', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(798, 'MM', 'Mamül', 'SARUHAN', '21002297', 'TVL 90 S - TABAN MONTAJI', 'ADET', '338', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(799, 'MM', 'Mamül', 'SARUHAN', '41004767', 'EMOTİON ÖN KAPAK - SİYAH', 'ADET', '83', '350', '338', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(800, 'YM', 'Yarımamül', 'SARUHAN', '11003209', 'EMOTİON TUTAMAK ÜST KIRMIZI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(801, 'YM', 'Yarımamül', 'SARUHAN', '11003210', 'EMOTİON TUTAMAK ALT KIRMIZI', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(802, 'YM', 'Yarımamül', 'SARUHAN', '11003216', 'EMOTİON MANDAL ÖN KAPAK GRI', 'ADET', '', '130', '20', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(803, 'YM', 'Yarımamül', 'SARUHAN', '11003247', 'EMOTİON KABLO SARICI TUŞ GRİ', 'ADET', '', '130', '24', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(804, 'YM', 'Yarımamül', 'SARUHAN', '11003248', 'EMOTİON ON/OFF TUŞ GRİ', 'ADET', '', '130', '24', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(805, 'YM', 'Yarımamül', 'SARUHAN', '41004768', 'EMOTİON TUTAMAK ÜST - SİYAH', 'ADET', '148', '300', '69,06', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(806, 'YM', 'Yarımamül', 'SARUHAN', '41004769', 'EMOTİON TUTAMAK ALT - SİYAH', 'ADET', '148', '300', '37,94', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(807, 'MM', 'Mamül', 'ÜNAL KABLO', '250/80/135', 'ÜNAL KABLO PLASTİK MAKARA', 'ADET', '3825', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(808, 'MM', 'Mamül', 'VATAN', 'VPK-05', 'BAZA ALT KAPAK', 'ADET', '5', '500', '915', '83', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(809, 'MM', 'Mamül', 'VATAN', 'VPK-06', 'BAZA ÜST KAPAK', 'ADET', '64', '500', '300', '52', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL);
INSERT INTO `malzeme_tanimlari` (`malzeme_id`, `malzeme_tur`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`) VALUES
(810, 'MM', 'Mamül', 'VATAN', 'VPK-12', 'ARMOR GÖVDE', 'ADET', '', '200', '35', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(811, 'MM', 'Mamül', 'VATAN', 'VPK-14', 'YATIŞ ÇEKME KOLU', 'ADET', '1', '160', '77', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(812, 'MM', 'Mamül', 'VATAN', 'VPK-15', '5 NOKTA EMNİYET KAPAK', 'ADET', '', '130', '26,7', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(813, 'MM', 'Mamül', 'VATAN', 'VPK-17', 'YATIŞ ÇEKME KOLU MAFSALI', 'ADET', '', '130', '47,6', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(814, 'MM', 'Mamül', 'VATAN', 'VPK-2', 'BOYUNLUK GÖVDE', 'ADET', '13', '700', '820', '90', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(815, 'MM', 'Mamül', 'VATAN', 'VPK-20', 'HOPERLÖR TUTUCU - VATAN', 'ADET', '', '130', '4,5', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(816, 'MM', 'Mamül', 'VATAN', 'VPK-23', 'EMNİYET KEMER TUTUCU KAPAK', 'ADET', '', '160', '8,1', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(817, 'MM', 'Mamül', 'VATAN', 'VPK-28', 'KEMER TUTUCU', 'ADET', '', '160', '7,5', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(818, 'MM', 'Mamül', 'VATAN', 'VPK-3', 'VPK-3 BOYUNLUK BÜYÜK KIZAK', 'ADET', '', '300', '390', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(819, 'MM', 'Mamül', 'VATAN', 'VPK-34', 'YAN KEMER GEÇME DESTEK PLASTİGİ', 'ADET', '', '350', '194', '82', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(820, 'MM', 'Mamül', 'VATAN', 'VPK-9-A', 'YAN ÇITA SAĞ', 'ADET', '600', '130', '23,8', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(821, 'MM', 'Mamül', 'VATAN', 'VPK-9-B', 'YAN ÇITA SOL', 'ADET', '600', '130', '23,8', '42', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(822, 'MM', 'Mamül', 'VATAN', 'VTN-01', 'ANA KUCAĞI KASASI-SİYAH', 'ADET', '99', '700', '1524', '110', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(823, 'MM', 'Mamül', 'VATAN', 'VTN-02', 'ANA KUCAĞI KASASI-BEYAZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(824, 'MM', 'Mamül', 'VATAN', 'VTN-03', '0-13 KG O.K. TAŞIMA KOLU SİYAH', 'ADET', '57', '350', '600', '90', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(825, 'MM', 'Mamül', 'VATAN', 'VTN-04', 'ANA KUCAĞI TAŞIMA KOLU-BEYAZ', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(826, 'MM', 'Mamül', 'VATAN', 'VTN-05', 'ADAPTÖR BOŞANDIRMA MANDAL KAPAĞI', 'ADET', '', '130', '7,5', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(827, 'MM', 'Mamül', 'VATAN', 'VTN-06', 'GÜMÜŞ YAN MANDAL', 'ADET', '', '130', '19', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(828, 'MM', 'Mamül', 'VATAN', 'VTN-07', 'METAL KLİPS KAPAĞI', 'ADET', '', '130', '26,7', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(829, 'MM', 'Mamül', 'VATAN', 'VTN-08', 'TAŞIMA KOLU SİLİNDİRİ', 'ADET', '112', '130', '9,5', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(830, 'MM', 'Mamül', 'VATAN', 'VTN-11', '0-13 KG OTO KOLTUĞU YAN KEMER GEÇME PLASTİĞİ', 'ADET', '', '200', '57', '43', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(831, 'MM', 'Mamül', 'VATAN', 'VTN-12', 'Taşıma Kolu Yan Hareket Mandalı', 'ADET', '', '130', '19', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(832, 'MM', 'Mamül', 'VATAN', 'VTN-13', '0-13 KG OTO KOLTUĞU KADEME PLS. TIPA', 'ADET', '', '130', '0,22', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(833, 'MM', 'Mamül', 'WAT MOTOR', '801304401', 'KONDANSATÖR YATAĞI', 'ADET', '', '80', '19', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(834, 'MM', 'Mamül', 'WAT MOTOR', '801304501', 'KAPAK DİYOT BAYKAR ALTEMATÖR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(835, 'MM', 'Mamül', 'WAT MOTOR', '801305501', 'MUHAFAZA KÖMR YUVASI BAYKAR ALTEMATÖR', 'ADET', '', '80', '5', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(836, 'MM', 'Mamül', 'WAT MOTOR', '801504501', 'AA-Stator Alın İzolasyonu End. Servo 60 FR', 'ADET', '', '80', '0,45', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(837, 'MM', 'Mamül', 'WAT MOTOR', '801504901', 'AA-Stator Alın İzolasyonu End. Servo 80 FR', 'ADET', '', '130', '0,9', '30', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(838, 'MM', 'Mamül', 'WAT MOTOR', '802217901', 'ROTOR SARGI BAYKAR ALTEMATÖR', 'ADET', '', '80', '12', '40', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(839, 'MM', 'Mamül', 'WAT MOTOR', '802414801', 'AA-Kapak Enkoder End. Servo 60FR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(840, 'MM', 'Mamül', 'WAT MOTOR', '802415401', 'AA-Kapak Enkoder End. Servo 80FR', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(841, 'MM', 'Mamül', 'YILMAZ KLP', 'YLZ-01', 'YER KAROSU (YILMAZ KALIP)', 'ADET', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(842, 'MM', 'Mamül', 'BSH', '8001290527\r\n', 'Trim KIT FDBM 42 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(843, 'MM', 'Mamül', 'BSH', '8001303118', 'Trim KIT FDBM 36 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(844, 'MM', 'Mamül', 'BSH', '8001303120', 'Trim KIT FDBM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(845, 'MM', 'Mamül', 'BSH', '8001303121', 'TRIM KIT BM 36 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(846, 'MM', 'Mamül', 'BSH', '8001303122\r\n', 'Trim KIT BM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(847, 'MM', 'Mamül', 'BSH', '8001303123\r\n', 'Trim KIT BM 30 LBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(848, 'MM', 'Mamül', 'BSH', '8001290512', 'INSTALLATION KIT HBL Yukon', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(849, 'MM', 'Mamül', 'BSH', '8001286328', 'DOOR DIRECTION CHANGE KIT BO BM30 SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(850, 'MM', 'Mamül', 'BSH', '8001286325', 'INSTALLATION KIT FDBM/BM BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(851, 'MM', 'Mamül', 'BSH', '8001304521', 'INSTALLATION KIT FDBM/BM PACS BO SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(852, 'MM', 'Mamül', 'BSH', '8001304733', 'INSTALLATION KIT BM 30 LBL TH SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(853, 'MM', 'Mamül', 'BSH', '8001286318', 'TRIM KIT FDBM36 BO SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(854, 'MM', 'Mamül', 'BSH', '8001286322', 'TRIM KIT FDBM36  BO PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(855, 'MM', 'Mamül', 'BSH', '8001286323', 'TRIM KIT BM30 BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(856, 'MM', 'Mamül', 'BSH', '8001286324', 'TRIM KIT BM30 BO PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(857, 'MM', 'Mamül', 'BSH', '8001302148', 'TRIM KIT BM30 TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(858, 'MM', 'Mamül', 'BSH', '8001302151', 'TRIM KIT BM30  TH PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(859, 'MM', 'Mamül', 'BSH', '8001229648', 'SBS COMBI KIT TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(860, 'MM', 'Mamül', 'BSH', '8001229649', 'SBS COMBI KIT GG SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(861, 'MM', 'Mamül', 'BSH', '8001274436', 'Kit, Pairing, Backwd Compat,BISbS1.1/2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(862, 'MM', 'Mamül', 'BSH', '8001288046', 'Frame Kit', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(863, 'MM', 'Mamül', 'BSH', '8001288050', 'Side Trim Kit GG SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(864, 'MM', 'Mamül', 'BSH', '8001288054', 'Single Unit Replacement Kit 36 niche\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(866, 'MM', 'Mamül', 'BSH', '8001290527', 'Trim KIT FDBM 42 HBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(867, 'MM', 'Mamül', 'BSH', '8001303122', 'Trim KIT BM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(868, 'MM', 'Mamül', 'BSH', '8001303123', 'Trim KIT BM 30 LBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(900, 'HM', 'Yard. Malzeme', 'BSH', '8001227784', 'Side Niche Trim Narrow RAL7021 GG BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(901, 'HM', 'Yard. Malzeme', 'BSH', '8001229265', 'Cover Lateral Fridge Frz GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(902, 'HM', 'Yard. Malzeme', 'BSH', '8001229266', 'Recessed Handle Profile Fridge SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(903, 'HM', 'Yard. Malzeme', 'BSH', '8001296421', 'Cover Lateral Frz LBL GG/MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(904, 'HM', 'Yard. Malzeme', 'BSH', '8001229264', 'Cover Lateral Fridge GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(905, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(906, 'HM', 'Yard. Malzeme', 'BSH', '8001272713', 'Top Niche Trim 30 GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(907, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(908, 'HM', 'Yard. Malzeme', 'BSH', '8001227783', 'Side Niche Trim Wide RAL 7021 GG BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(909, 'HM', 'Yard. Malzeme', 'BSH', '8001229265', 'Cover Lateral Fridge Frz GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(910, 'HM', 'Yard. Malzeme', 'BSH', '8001229266', 'Recessed Handle Profile Fridge SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(911, 'HM', 'Yard. Malzeme', 'BSH', '8001229264', 'Cover Lateral Fridge GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(912, 'HM', 'Yard. Malzeme', 'BSH', '8001296413', 'Top Cover Assy. 36 Frz LBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(913, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(914, 'HM', 'Yard. Malzeme', 'BSH', '8001272712', 'Top Niche Trim 36 GG SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(915, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(917, 'HM', 'Yard. Malzeme', 'BSH', '8001289716', 'Cover Lateral FridgeOuter HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(918, 'HM', 'Yard. Malzeme', 'BSH', '8001289731', 'Cover Lateral FridgeInner HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(919, 'HM', 'Yard. Malzeme', 'BSH', '8001289759', 'Cover Lateral IM/FF HBL MC3 SbS 2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(920, 'HM', 'Yard. Malzeme', 'BSH', '8001289761', 'Cover Lateral Frz HBL MC3 SbS 2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(921, 'HM', 'Yard. Malzeme', 'BSH', '8001289879', 'Top Cover assy. 42 Frz HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(922, 'HM', 'Yard. Malzeme', 'BSH', '8001289880', 'Top Cover assy 42 IM/FF HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(923, 'HM', 'Yard. Malzeme', 'BSH', '8001277933', 'Fridge Top Cover Right FDBM42 MIE assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(924, 'HM', 'Yard. Malzeme', 'BSH', '8001277931', 'Fridge Top Cover Left FDBM42 MIE assy', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(925, 'HM', 'Yard. Malzeme', 'BSH', '8001289676', 'Top Niche Trim 42\" RAL 7021 SbS 2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-07-31 10:34:43', NULL, NULL),
(927, 'MM', 'Mamül', 'SARUHAN', '11004108', 'ALT GÖVDE - WHISPER - SİYAH', 'ADET', '0', '500', '481', '71', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL),
(928, 'MM', 'Mamül', 'SARUHAN', '11004109', 'ARKA KAPAK - WHISPER - SİYAH', 'ADET', '0', '500', '370', '67', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL),
(929, 'MM', 'Mamül', 'SARUHAN', '11004106', 'KONTROL PANELİ - SERİGRAFLI - WHISPER', 'ADET', '0', '130', '110', '40', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL),
(930, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge BOX, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:19:24', NULL, NULL),
(931, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, Comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(932, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(933, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(934, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(935, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(936, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(937, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(938, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(939, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(940, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(941, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GGr SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(942, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(943, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(944, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(945, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(946, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(947, 'HM', 'Yard. Malzeme', 'BSH', '8001226873', 'SBS Rear Hinge Bracket BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(948, 'HM', 'Yard. Malzeme', 'BSH', '8001227785', 'Center Trm Wide RAL 7021 BM SbS2.00', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(949, 'HM', 'Yard. Malzeme', 'BSH', '9000025815', 'SX S BRACKET FRONT A-COOL', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(950, 'HM', 'Yard. Malzeme', 'BSH', '9000051153', 'S*S FM PIN A-COOL', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(951, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kt Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(953, 'HM', 'Yard. Malzeme', 'BSH', '8001227786', 'Center Trim Medium RAL 7021 BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:21:37', NULL, NULL),
(956, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge BOX, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(957, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, Comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(958, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Let (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(959, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(960, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(961, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(962, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(963, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(964, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge Box, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(965, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(966, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Left (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(967, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(968, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(969, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(970, 'HM', 'Yard. Malzeme', 'BSH', '8001229927', 'Fridge Top Cover Left BM30 GG ODA assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(971, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(972, 'HM', 'Yard. Malzeme', 'BSH', '8001229910', 'Frdge Top Cover Right BM30 GG ODA assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(973, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(974, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(975, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(976, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge Box, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(977, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GGr SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(978, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Let (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(979, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(980, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(981, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(982, 'HM', 'Yard. Malzeme', 'BSH', '8001229932', 'Fridge Top Cover Left BM36 ODA assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(983, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(984, 'HM', 'Yard. Malzeme', 'BSH', '8001229931', 'Fridge Top Cover Right BM36 GG ODA assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(985, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(986, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(987, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(988, 'HM', 'Yard. Malzeme', 'BSH', '9000519005', 'Screw thread rol M5x16 T20 Zn Countersu', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(990, 'HM', 'Yard. Malzeme', 'BSH', '8001226875', 'SBS Spacer BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(992, 'HM', 'Yard. Malzeme', 'BSH', '8001233498', 'SbS Dagger Medium BM SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(994, 'HM', 'Yard. Malzeme', 'BSH', '9000025816', 'S*S FD(TURE FRONT UPPER A-COOL', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(996, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label Installation box and bag', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(997, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kt Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1006, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label installation box and bag', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1007, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kit Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1010, 'HM', 'Yard. Malzeme', 'BSH', '8001227750', 'Center Trim Narrow RAL 7021 BM SbS2.O', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1015, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label installation box and bag', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1016, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trirn Kit Cardboard Box SbS2.O', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1017, 'MM', 'Mamül', 'BSH', '8001303123 ', 'Trim KIT BM 30 LBL MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1018, 'MM', 'Mamül', 'BSH', '8001303185', 'Door Direction Change KIT MI BM30\r\n', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1019, 'MM', 'Mamül', 'BSH', '8001288064', 'Connection Replacement Kit Niche GG Sbs', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1020, 'HM', 'Yard. Malzeme', 'BSH', '8001106357', 'CA65 Warning Label (150mmx100mm)', 'ADET', '', '', '', '', '', '', '', '', '2024-08-30 11:23:24', NULL, NULL),
(1021, 'HM', 'Yard. Malzeme', 'BSH', '8001234880', 'Side Niche Spacer BM SbS2.0', 'ADET', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yavuz bekem', '2024-10-21 13:03:47', NULL, NULL),
(1022, 'HM', 'Yard. Malzeme', 'BSH', '8001214253', 'BSH_GB_Importers_notice_Brexit_A5_80gr', 'ADET', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yavuz bekem', '2024-10-21 13:06:47', NULL, NULL),
(1023, 'MM', 'Mamül', 'BSH', '8001312760', 'Wide Side Trim Kit TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1024, 'MM', 'Mamül', 'BSH', '8001312946', 'Trim KIT SDF SDR SDD 24 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1025, 'MM', 'Mamül', 'BSH', '8001312926', 'Installation KIT SD TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1026, 'MM', 'Mamül', 'BSH', '8001312928', 'Installation KIT SD GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1027, 'MM', 'Mamül', 'BSH', '8001312930', 'Trim KIT SDF SDD 18 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1028, 'MM', 'Mamül', 'BSH', '8001312933', 'Trim KIT SDF SDR SDD 24 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1029, 'MM', 'Mamül', 'BSH', '8001312943', 'Trim KIT SDF 18 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1030, 'MM', 'Mamül', 'BSH', '8001312946', 'Trim KIT SDF SDR SDD 24 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1031, 'MM', 'Mamül', 'BSH', '8001312949', 'Trim KIT SDF SDR 30 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1032, 'MM', 'Mamül', 'BSH', '8001312951', 'Trim KIT SDF SDR 36 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1033, 'MM', 'Mamül', 'BSH', '8001312935', 'Trim KIT SDF SDR 30 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1034, 'MM', 'Mamül', 'BSH', '8001312937', 'Trim KIT SDF SDR 36 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1035, 'MM', 'Mamül', 'SARUHAN', '11004216', 'ARKA GÖVDE - GRİ - TVL 90 BS', 'ADET', '0', '500', '644', '73', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1036, 'MM', 'Mamül', 'SARUHAN', '11004218', 'ÖN GÖVDE - GRİ - TVL 90 BS - Serigrafi', 'ADET', '', '420', '362', '55', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1037, 'MM', 'Mamül', 'SARUHAN', '11004219', 'TABAN - GRİ - TVL 90 BS', 'ADET', '', '200', '212', '43', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1038, 'MM', 'Mamül', 'SARUHAN', '11004220', 'UZAKTAN KUMANDA TUTUCU - GRİ - TVL 90 BS', 'ADET', '0', '80', '10', '35', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1039, 'MM', 'Mamül', 'VATAN', 'CSL-11', 'TENTE / CANOPY', 'ADET', '0', '350', '105,2', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1040, NULL, 'Mamül', 'VATAN', 'CSL-12-L', 'SOL TENTE KADEME AYAR PLASTİGİ / LEFT CANOPY INSERT', 'ADET', '0', '160', '36', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1041, NULL, 'Mamül', 'VATAN', 'CSL-12-R', 'SAĞ TENTE KADEME AYAR PLASTİGİ / RIGHT CANOPY INSERT', 'ADET', '0', '160', '36', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1042, NULL, 'Mamül', 'VATAN', 'CSL-13', 'BOYUNLUK / HEADREST', 'ADET', '0', '300', '62,4', '50', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1043, NULL, 'Mamül', 'VATAN', 'CSL-14', 'RELEASE BUTTON /  ADAPTÖR BOŞANDIRMA PLASTİGİ', 'ADET', '0', '300', '81,5', '55', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1044, NULL, 'Mamül', 'VATAN', 'CSL-15', 'ARKA KEMER GEÇME PLASTİGİ / BELT GUİDE PLASTİC COVER', 'ADET', '0', '130', '26,1', '40', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1045, NULL, 'Mamül', 'VATAN', 'CSL-16-L', 'SOL YAN KEMER GEÇME PLASTİGİ / LEFT BELT GUİDE ', 'ADET', '0', '300', '8', '50', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1046, NULL, 'Mamül', 'VATAN', 'CSL-16-R', 'SAG YAN KEMER GEÇME PLASTİGİ / RIGHT BELT GUİDE ', 'ADET', '0', '300', '8', '50', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1047, NULL, 'Mamül', 'VATAN', 'CSL-17-L', 'SOL KOL İÇ KAPAK PLASTİGİ / LEFT HANDLE INNER CAP', 'ADET', '0', '160', '32,6', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1048, NULL, 'Mamül', 'VATAN', 'CSL-17-R', 'SAG KOL İÇ KAPAK PLASTİGİ / RIGHT HANDLE INNER CAP', 'ADET', '0', '160', '32,6', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1049, NULL, 'Mamül', 'VATAN', 'CSL-18', 'KOL DIŞ KAPAK PLASTİGİ / HANDLE CAP', 'ADET', '0', '80', '5,4', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1050, NULL, 'Mamül', 'VATAN', 'CSL-19-L', 'SOL KOL MANDALI / LEFT HANDLE RELEASE BUTTON', 'ADET', '0', '80', '13,4', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1051, NULL, 'Mamül', 'VATAN', 'CSL-19-R', 'SAG KOL MANDALI / RIGHT HANDLE RELEASE BUTTON', 'ADET', '0', '80', '13,4', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1052, NULL, 'Mamül', 'VATAN', 'CSL-20', 'KOL İÇ BAĞLANTI PLASTİGİ / HANDLE RELEASE LATCH', 'ADET', '0', '80', '10', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1053, NULL, 'Mamül', 'VATAN', 'CSL-21', 'KOL DIŞ KAPAK PLASTİGİ ÇERÇEVESİ / O-RİNG', 'ADET', '0', '80', '2,4', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1054, NULL, 'Mamül', 'VATAN', 'CSL-22', 'BOYUNLUK AYARI PLASTİGİ / HEADREST POSİTİON ADJUSTİNG', 'ADET', '0', '130', '4,6', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1055, NULL, 'Mamül', 'VATAN', 'CSL-23', 'METAL KLİPS KAPAĞI  / ADJUSTER CAP', 'ADET', '0', '130', '13,5', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1056, NULL, 'Mamül', 'VATAN', 'CSL-24-L', 'SOL ADAPTÖR BOŞANDIRMA PLASTİGİ / LEFT ADAPTOR', 'ADET', '0', '130', '22', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1057, NULL, 'Mamül', 'VATAN', 'CSL-24-R', 'SAG ADAPTÖR BOŞANDIRMA PLASTİGİ / HIGHT ADAPTOR', 'ADET', '0', '130', '22', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1058, NULL, 'Mamül', 'VATAN', 'CSL-25', 'TENTE KADEME AYAR PLASTİGİ TIPASI / PP TUBE ADAPTOR', 'ADET', '0', '80', '2,4', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1059, NULL, 'Mamül', 'VATAN', 'CSL-26', 'BOYUNLUK AYARLAMA HALKASI / HEADREST RELEASE BUCKLE', 'ADET', '0', '80', '3,5', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1060, NULL, 'Mamül', 'VATAN', 'CSL-28-L', 'SOL DÜZENLEYİCİ / LEFT REGULATOR', 'ADET', '0', '130', '7', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1061, NULL, 'Mamül', 'VATAN', 'CSL-28-R', 'SAG DÜZENLEYİCİ / HIGHT REGULATOR', 'ADET', '0', '130', '7', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1062, NULL, 'Mamül', 'VATAN', 'CSL-03', 'ÜST BAZA / UPPER BASE', 'ADET', '0', '800', '452', '70', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1063, NULL, 'Mamül', 'VATAN', 'CSL-04', 'ALT BAZA / LOWER BASE', 'ADET', '0', '800', '1155', '75', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1064, NULL, 'Mamül', 'VATAN', 'CSL-05', 'DÖNER BAZA MEKANİZMASI / ROTATİON WHEEL', 'ADET', '0', '350', '0.859', '55', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1065, NULL, 'Mamül', 'VATAN', 'CSL-06', 'BAZA DÖNDÜRME PLASTİGİ / CONNECTİON PART', 'ADET', '0', '200', '0.0208', '40', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1066, NULL, 'Mamül', 'VATAN', 'CSL-07', 'DESTEK AYAĞI ÜST KAPAK PLASTİGİ-1 / COVER', 'ADET', '0', '130', '0.0067', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1067, NULL, 'Mamül', 'VATAN', 'CSL-08', 'DESTEK AYAĞI ALT KAPAK-1 / LEG-1 ', 'ADET', '0', '200', '0.012', '50', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1068, NULL, 'Mamül', 'VATAN', 'CSL-09', 'DESTEK AYAĞI ALT KAPAK-2 / LEG-2', 'ADET', '0', '200', '0.0116', '45', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1069, NULL, 'Mamül', 'VATAN', 'CSL-10', 'DESTEK AYAĞI AYAR PLASTİGİ / LEG-3', 'ADET', '0', '80', '0.0018', '30', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1070, NULL, 'Mamül', 'VATAN', 'CSL- 27', 'İNDİKATÖR / INDİCATOR', 'ADET', '0', '80', '0.0004', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1071, NULL, 'Mamül', 'VATAN', 'CSL-29', 'BAZA DÖNDÜRME KİLİT PLASTİGİ / ROTATİON LOCK', 'ADET', '0', '130', '0.0092', '35', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1072, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '130', NULL, NULL, NULL, NULL, 'Koli', 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz BEKEM', '2025-01-31 15:24:31'),
(1073, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '130', NULL, NULL, NULL, NULL, 'Koli', 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz BEKEM', '2025-01-31 15:21:29'),
(1074, 'MM', 'Mamül', 'BSH', '8001303686', 'Installation Kit SbS middle MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1075, 'MM', 'Mamül', 'BSH', '8001303681', 'Installation Kit SbS big MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1076, 'MM', 'Mamül', 'BSH', '8001303688', 'Installation Kit SbS small MI', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1077, 'MM', 'Mamül', 'BSH', '8001303186', 'Door Direction Change KIT MI BM30 ODA', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1078, 'MM', 'Mamül', 'BSH', '8001303187', 'Door Direction Change KIT MI BM36 ODA', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1079, 'YM', 'Yarı Mamül', 'BSH', '9000515146', 'KAPI SIVICI TAKVİYE PARÇASI', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1080, 'YM', 'Yarı Mamül', 'BSH', '9000515146_P', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1081, 'YM', 'Yarı Mamül', 'BSH', '9000515146_Y', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1082, 'YM', 'Yarı Mamül', 'BSH', '9000515146_T', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1083, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AC', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1084, 'YM', 'Yarı Mamül', NULL, NULL, NULL, 'ADET', NULL, '300', NULL, NULL, NULL, NULL, '', 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz Bekem', '2026-03-09 09:11:42'),
(1085, 'YM', 'Yarımamül', 'ARÇELİK', '2990320100', 'SEFFAF_PLASTIK_KAPAK_ABM', 'ADET', '', '500', '530', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1086, 'YM', 'Yarı Mamül', 'BSH', '8001328164', 'Toe Kick Comp bracket le TH', 'ADET', '0', '130', '23,8', '40', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1087, 'YM', 'Yarı Mamül', 'BSH', '8001328167', 'Toe Kick Comp bracket le GG', 'ADET', '0', '130', '23,8', '40', '0', '0', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1088, 'MM', 'Mamül', 'BSH', '8001312944', 'Trim KIT SDW 18 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1089, 'MM', 'Mamül', 'BSH', '8001312947', 'Trim KIT SDW 24 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1090, 'MM', 'Mamül', 'BSH', '8001312931', 'Trim KIT SDW 18 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1091, 'MM', 'Mamül', 'BSH', '8001312934', 'Trim KIT SDW 24 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1092, 'MM', 'Yarı Mamül', 'BSH', '8001300560', 'Seal Surf. Comp SDR36 TH Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1093, 'MM', 'Yarı Mamül', 'BSH', '8001300563', 'Seal Surf. Comp SDR30 TH Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1094, 'MM', 'Yarı Mamül', 'BSH', '8001300565', 'Seal Surf. Comp SDR24 TH Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1095, 'MM', 'Yarı Mamül', 'BSH', '8001300561', 'Seal Surf. Comp SDR30 GG Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1096, 'MM', 'Yarı Mamül', 'BSH', '8001300564', 'Seal Surf. Comp SDR24 GG Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1097, 'MM', 'Yarı Mamül', 'BSH', '8001300559', 'Seal Surf. Comp SDR36 GG Columns', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1098, 'MM', 'Mamül', 'BSH', '8001312929', 'Door Direction Change KIT SD 18 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1099, 'MM', 'Mamül', 'BSH', '8001319327', 'Door Direction Change KIT SD 24 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1100, 'MM', 'Mamül', 'BSH', '8001319329', 'Door Direction Change KIT SD 30 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1101, 'MM', 'Mamül', 'BSH', '8001319330', 'Door Direction Change KIT SD 36 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1102, 'MM', 'Mamül', 'BSH', '8001319331', 'Door Direction Change KIT SD 18 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1103, 'MM', 'Mamül', 'BSH', '8001319332', 'Door Direction Change KIT SD 24 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1104, 'MM', 'Mamül', 'BSH', '8001319333', 'Door Direction Change KIT SD 30 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1105, 'MM', 'Mamül', 'BSH', '8001319334', 'Door Direction Change KIT SD 36 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1106, 'MM', 'Mamül', 'BSH', '8001331454', 'Door Direction Change KIT SDW 18 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1107, 'MM', 'Mamül', 'BSH', '8001331457', 'Door Direction Change KIT SDW 24 TH', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1108, 'MM', 'Mamül', 'BSH', '8001331458', 'Door Direction Change KIT SDW 18 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1109, 'MM', 'Mamül', 'BSH', '8001331460', 'Door Direction Change KIT SDW 24 GG', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1110, 'MM', 'Mamül', 'VATAN', 'VPK-04', 'VPK-04 ARKA BÜYÜK KAPAK', 'ADET', '', '350', '350', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1111, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AD', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1112, 'MM', 'Mamül', 'BSH', '8001355820', 'SBS COMBI KIT BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1113, 'HM', 'Yarı Mamül', 'BSH', '8001288024', 'Center Trim Narrow VZF 07020 BM SbS2.0', 'ADET', '0', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1114, 'YM', 'Yarımamül', 'ARÇELİK', '2991240400', 'IC_INLAY_ABM_KKSIZ_ARC1_BEYAZ_V0', 'ADET', '', '650', '351', '50', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1115, 'MM', 'Mamül', 'POVAG', '100701103015000000001', 'bin - No. 33 - 92x320x92 mm- Blue virgin PP', 'ADET', '', '200', '235', '50', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1116, 'MM', 'Mamül', 'POVAG', '100701103013000000001', 'bin - No. 33 - 92x320x92 mm- Red virgin PP', 'ADET', '', '200', '235', '50', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1117, 'MM', 'Mamül', 'POVAG', '100701103011000000001', 'bin - No. 33 - 92x320x92 mm- Yellow virgin PP', 'ADET', '', '200', '235', '50', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1118, 'MM', 'Mamül', 'POVAG', '100701103018000000001', 'bin - No. 33 - 92x320x92 mm- Green virgin PP', 'ADET', '', '200', '235', '50', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1119, 'MM', 'Mamül', 'POVAG', '100701103019500000001', 'bin - No. 33 - 92x320x92 mm- Black virgin PP', 'ADET', '', '200', '235', '50', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1120, 'MM', 'Mamül', 'POVAG', '100701101013000000001', 'bin - No. 63 - 184x320x92 mm- Red virgin PP', 'ADET', '', '300', '415', '70', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1121, 'MM', 'Mamül', 'POVAG', '100701101015000000001', 'bin - No. 63 - 184x320x92 mm - Blue virgin PP', 'ADET', '', '300', '415', '70', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1122, 'MM', 'Mamül', 'POVAG', '100701101011000000001', 'bin - No. 63 - 184x320x92 mm- Yellow virgin PP', 'ADET', '', '300', '415', '70', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1123, 'MM', 'Mamül', 'POVAG', '100701101018000000001', 'bin - No. 63 - 184x320x92 mm- Green virgin PP\r\n', 'ADET', '', '300', '415', '70', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1124, 'MM', 'Mamül', 'POVAG', '100701101019500000001', 'bin - No. 63 - 184x320x92 mm- Black virgin PP', 'ADET', '', '300', '415', '70', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1125, 'MM', 'Mamül', 'POVAG', '109901002010000000000', 'bin - No. 48 - 92x175 mm - Transparent virgin PP', 'ADET', '', '130', '16', '40', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1126, 'MM', 'Mamül', 'POVAG', '109901003010000000000', 'bin - No. 33 - 92x85 mm- Transparent virgin PP', 'ADET', '', '130', '30', '40', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1127, 'MM', 'Mamül', 'POVAG', '109901004010000000000\r\n', 'bin - No.63 - 80x280 mm- Transparent virgin PP', 'ADET', '', '130', '60', '48', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL),
(1128, 'HM', 'Yarı Mamül', 'BSH', '8001300525', 'Seal Surf. Left SDR GG Columns', 'ADET', '0', '300', '25', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1129, 'HM', 'Yarı Mamül', 'BSH', '8001300528', 'Seal Surf. Right SDR GG Columns', 'ADET', '0', '300', '25', '45', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1130, 'MM', 'Mamül', 'ARÇELİK', '2969670400', 'SOL_TEKMLK(BEST-BETTER.PL)722_SYHPRLK_IZGRLI', 'ADET', '', '300', '213', '60', '', '', '', 'Yavuz BEKEM', '2025-07-21 22:20:07', NULL, NULL),
(1131, 'MM', 'Mamül', 'ARÇELİK', '2995190100', 'TEKMELIK_GR_PLM4_ARC_P1BEYAZ Indesit', 'ADET', '5085', '650', '385', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1132, 'MM', 'Mamül', 'ARÇELİK', '2995190200', 'TEKMELIK_GR_PLM4_ARC722 SYH_PARLAK Indesit', 'ADET', '5085', '650', '385', '65', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1133, 'MM', 'Mamül', 'ARÇELİK', '2969670100', 'SOL_TEKMELIK(BEST-BETTER_PL)ARC1_IZGRLI', 'ADET', '2474', '30', '211', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1134, 'MM', 'Mamül', 'ARÇELİK', '2984581100', 'DAR_ARKA_KAPAK_GR_XL(KECELI)_EKO', 'ADET', '0', '650', '540', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1135, 'MM', 'Mamül', 'VATAN', 'CSL-01', 'GÖVDE ', 'ADET', '0', '850', '1560', '120', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1136, 'MM', 'Mamül', 'ARÇELİK', '2986750300', 'TANK YUVASI GRUBU 54 CM PROLOGUE XL', 'ADET', '', '700', '575', '55', '30', '90', 'K-550', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1137, 'MM', 'Mamül', 'ARÇELİK', '2986750500', 'TANK YUVASI GR (54CM PRLG XL) GRI IRONFI', 'ADET', '', '700', '575', '55', '30', '90', 'K-550', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1138, 'YM', 'Yarımamül', 'ARÇELİK', '2991150200', 'KORUYUCU_KAPAK_ABM_MABS', 'ADET', '', '650', '687', '70', '', '', '', 'Yavuz BEKEM', '2025-12-15 15:12:07', NULL, NULL),
(1139, 'MM', 'Mamül', 'KULTURA', 'KLT-0001', 'Whilot_Alt-V1.2', 'ADET', '', '80', '30', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1140, 'MM', 'Mamül', 'KULTURA', 'KLT-0002', 'Whilot_Ust-V1.2', 'ADET', '', '80', '40', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1141, 'MM', 'Mamül', 'KULTURA', 'KLT-0003', 'LED_cubugu-V1.1', 'ADET', '', '80', '3', '60', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1142, 'MM', 'Yarı Mamül', 'BSH', '8001344840', 'Frezer Volume Reduction Bracket\r\n', 'ADET', '0', '160', '36', '45', NULL, NULL, NULL, NULL, '2026-01-19 10:17:03', NULL, NULL),
(1143, 'MM', 'Mamül', 'ARÇELİK KMI', '2989190300', 'TANK_YUVASI_GR_PROLOGUE 60CM_XL_GRI\r\n', 'ADET', '0', '650', '620', '70', '24', '72', 'K-550', NULL, '2026-01-19 10:23:09', NULL, NULL);
INSERT INTO `malzeme_tanimlari` (`malzeme_id`, `malzeme_tur`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`) VALUES
(1144, 'MM', 'Mamül', 'ARÇELİK KMI', '2989190600', 'TANK_YUVASI_GR_PROLOGUE 60CM_GRI_IRONFIN', 'ADET', '0', '650', '620', '70', '24', '72', 'K-550', NULL, '2026-01-19 10:23:09', NULL, NULL),
(1145, 'MM', 'Mamül', 'ARÇELİK TKM', '3580780100', 'FİNCANA NOZZLE MILI', 'ADET', '0', '130', NULL, '35', NULL, NULL, NULL, NULL, '2026-01-19 10:32:14', NULL, NULL),
(1146, 'MM', 'Mamül', 'ARÇELİK', '2969670400-1', 'SOL_TEKMLK(BEST-BETTER.PL)722_SYH_BOYANACAK', 'ADET', '', '300', '213', '60', '', '', '', 'Yavuz BEKEM', '2025-07-21 22:20:07', NULL, NULL),
(1147, 'MM', 'Mamül', 'SARUHAN', '11004115', 'HAVA IZGARA DÜĞMESİ - WHISPER - BEYAZ', 'ADET', '', '130', '11', '42', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL),
(1148, 'MM', 'Mamül', 'SARUHAN', '11004134', 'HAVA IZGARA ÇERÇEVESİ - WHISPER - BEYAZ', 'ADET', '', '130', '67', '43', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL),
(1149, 'MM', 'Mamül', 'SARUHAN', '11004105', 'TUTAMAK ALT KAPAK - WHISPER - BEYAZ', 'ADET', '', '130', '60', '48', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL),
(1150, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580550100', 'FİNCANA PISIRME HAZNE YUVASI UST', 'ADET', '', '160', '104', '45', '', '', '', 'Yavuz BEKEM', '2026-01-04 11:22:00', NULL, NULL),
(1151, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580580100', 'FİNCANA ATIK KAHVE HAZNESI TETIK BUTONU', 'ADET', '', '130', '2,8', '35', '', '', '', 'Yavuz BEKEM', '2026-01-04 11:22:00', NULL, NULL),
(1152, 'MM', 'Mamül', 'ARÇELİK', '2984581200', 'DAR_ARKA_KAPAK_GR_XL(KECE+BITUM)_EKO', 'ADET', '0', '650', '540', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1153, 'MM', 'Mamül', 'POVAG', '100702002010000000001', 'Kantelbak No.15 -transparent-150x115x110mm NSBC', 'ADET', '0', '260', '175', '70', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL),
(1154, 'MM', 'Mamül', 'BSH', '9000493277', 'SU CIKIS PARCASI - NSP', 'ADET', '0', '300', '9,25', '40', '250', '20000', 'Kasa', NULL, '2026-01-19 10:17:03', 'Yavuz Bekem', '2026-03-10 10:08:05'),
(1155, 'MM', 'Mamül', 'BSH', '8001297265', 'Air Guider SDW 18/24-BI SbS 2.0', 'Adet', '0', '200', '25', '40', '750', '15000', 'Kasa', 'Yavuz Bekem', '2026-03-10 09:13:53', 'Yavuz Bekem', '2026-03-10 13:33:30'),
(1156, 'YM', 'Yarımamul', 'ARÇELİK KMI', '2991260200', 'IC_KAPAK_ABM_KKSIZ_KOYU_GRI', 'Adet', '0', '650', '590', '65', '17', '102', 'Koli', 'Yavuz Bekem', '2026-03-10 10:12:26', 'Yavuz Bekem', '2026-03-10 13:34:01'),
(1157, NULL, 'Yarımamul', 'ARÇELİK KMI', '2991190200', 'IC_KAPAK_ABM_KKLI_KGRI(UL)', 'Adet', '0', '650', '360', '65', '0', '0', 'Koli', 'Yavuz Bekem', '2026-03-11 09:25:06', NULL, NULL),
(1158, NULL, 'Yarımamul', 'ARÇELİK KMI', '2991170200', 'CAM_TUTUCU_ABM_KGRI', 'Adet', '0', '650', '309', '55', '0', '0', 'Koli', 'Yavuz Bekem', '2026-03-11 09:27:32', NULL, NULL),
(1159, NULL, 'Mamül', 'SARUHAN', '11000047', 'ÜST KAPAK - YAZISIZ - SİYAH', 'Adet', '0', '420', '635', '110', '0', '0', 'Koli', 'Yavuz Bekem', '2026-03-13 12:14:32', NULL, NULL),
(1160, 'MM', 'Mamül', 'HASEL', 'MML0751', 'MASFAL UST BAĞLANTI PLASTİGİ - HASEL', 'Adet', '0', '80', '3,75', '42', '0', '0', 'Koli', 'Yavuz Bekem', '2026-03-17 17:22:19', 'Yavuz Bekem', '2026-03-17 17:22:47'),
(1161, NULL, 'Mamül', 'HASEL', 'MML0755', 'ALT ÇITA TAPA - HASEL', 'Adet', '0', '80', '5,75', '42', '0', '0', 'Koli', 'Yavuz Bekem', '2026-03-17 17:24:17', NULL, NULL),
(1162, NULL, 'Mamül', 'POVAG', '100102033010095000001', 'seperator - 300 mm - Black virgin HIPS', 'Adet', '0', '850', '89', '55', '72', '4032', 'Koli', 'Yavuz Bekem', '2026-03-17 17:26:19', NULL, NULL);

-- ----------------------------------------------------------------
-- 12. Malzeme Import
-- Kaynak: malzeme_import.sql
-- ----------------------------------------------------------------

-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 17 Mar 2026, 17:27:13
-- Sunucu sürümü: 8.0.30
-- PHP Sürümü: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `root`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `malzeme_tanımları`
--

CREATE TABLE `malzeme_tanımları` (
  `malzeme_id` int NOT NULL,
  `malzeme_tür` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_group` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_firma` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_kod` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_ad` text CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci,
  `malzeme_birim` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT 'ADET',
  `malzeme_stok` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `map_makina_tonaj` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `map_gramaj` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `map_cevrim` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `paket_miktari` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `taban_miktari` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_ambalaj` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_logo` varchar(250) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_ekleyen` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_tarihi` datetime DEFAULT CURRENT_TIMESTAMP,
  `malzeme_update` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `malzeme_update_tarihi` datetime DEFAULT NULL,
  `malzeme_tur` varchar(255) COLLATE utf8mb3_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `malzeme_tanımları`
--

INSERT INTO `malzeme_tanımları` (`malzeme_id`, `malzeme_tür`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_logo`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`, `malzeme_tur`) VALUES
(1, 'MM', 'Mamül', 'ARÇELİK', '2137000377', 'SEFFAF_ON_KAPAK_GR(ABX_ASM_XL)1-1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(2, 'MM', 'Mamül', 'ARÇELİK', '2954720100', 'KURUTUCU LAMBA CAMI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(3, 'MM', 'Mamül', 'ARÇELİK', '2957120100', 'SALYANGOZ KAPAĞI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(4, 'MM', 'Mamül', 'ARÇELİK', '2957120200', 'SALYANGOZ KAPAĞI (5 VA)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(5, 'MM', 'Mamül', 'ARÇELİK', '2957120300', 'SALYANGOZ KAPAGI(5VA)-CAPELLA', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(6, 'MM', 'Mamül', 'ARÇELİK', '2961290200', 'BOSALTMA HUNİSİ (ÜST)', 'ADET', '123757', '300', '10,4', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(7, 'MM', 'Mamül', 'ARÇELİK', '2961720100', 'SOĞUTMA EMİŞ DÜZELTİCİSİ(62 MM)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(8, 'MM', 'Mamül', 'ARÇELİK', '2961720200', 'SOĞUTMA EMİŞ DÜZELTİCİSİ(71 MM)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(9, 'MM', 'Mamül', 'ARÇELİK', '2961720300', 'SOGUTMA EMIS DUZELTICISI( Ø71_7MM)BSLTM', 'ADET', '15228', '160', '47', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(10, 'MM', 'Mamül', 'ARÇELİK', '2966280300', 'TEKMELIK_BUTONU_(ARC-GR-B13)432BORDO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(11, 'MM', 'Mamül', 'ARÇELİK', '2966285100', 'TEKMELIK_BUTONU_(ARC-GR-B13)_03+728BORDO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(12, 'MM', 'Mamül', 'ARÇELİK', '2966290100', 'TEKMELİK MENTEŞE YUVASI ÜST', 'ADET', '5730', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(13, 'MM', 'Mamül', 'ARÇELİK', '2966310100', 'TEKMELİK MENTEŞE YUVASI ALT', 'ADET', '6425', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(14, 'MM', 'Mamül', 'ARÇELİK', '2967780100', 'FAN TUTUCU', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(15, 'MM', 'Mamül', 'ARÇELİK', '2968410100', 'TEKMELIK_SOL_BEKO2013(ARC1)_IZGARALI', 'ADET', '8371', '500', '211', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(16, 'MM', 'Mamül', 'ARÇELİK', '2968410200', 'TEKMELIK_SOL_B13-HOEM-BLG15_KAPALI(ARC1)', 'ADET', '2474', '350', '208', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(17, 'MM', 'Mamül', 'ARÇELİK', '2968415000', 'TEKMELIK_SOL_BEKO_2013_745GRI_IZGARALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(18, 'MM', 'Mamül', 'ARÇELİK', '2968415100', 'TEKMELIK_SOL_BEKO_2013_745GRI_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(19, 'MM', 'Mamül', 'ARÇELİK', '2968415200', 'TEKMELIK_SOL_B13_728BORDO_IZGARALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(20, 'MM', 'Mamül', 'ARÇELİK', '2968415300', 'TEKMELIK_SOL_B13_728BORDO_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(21, 'MM', 'Mamül', 'ARÇELİK', '2968415400', 'TEKMELIK_SOL_B13_734MAVI_IZGARALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(22, 'MM', 'Mamül', 'ARÇELİK', '2968415500', 'TEKMELIK_SOL_B13_734MAVI_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(23, 'MM', 'Mamül', 'ARÇELİK', '2968415600', 'TEKMELIK_SOL_B13_764 S_MAN.GRAY_IZGARALI', 'ADET', '13', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(24, 'MM', 'Mamül', 'ARÇELİK', '2968415700', 'TEKMELIK_SOL_B13_764_S_MAN.GRAY_KAPALI', 'ADET', '239', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(25, 'MM', 'Mamül', 'ARÇELİK', '2968415800', 'TEKMELIK_SOL_B13_700_ANTRASIT_IZGARALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(26, 'MM', 'Mamül', 'ARÇELİK', '2968415900', 'TEKMELIK_SOL_B13_700_ANTRASIT_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(27, 'MM', 'Mamül', 'ARÇELİK', '2968416000', 'TEKMELIK_SOL_B13_IZGARALI_TIP03+1050_GRI', 'ADET', '42', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(28, 'MM', 'Mamül', 'ARÇELİK', '2968416100', 'TEKMELIK_SOL_B13_KAPALI_TIP04+1050_GRI', 'ADET', '144', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(29, 'MM', 'Mamül', 'ARÇELİK', '2968416200', 'TEKMELIK_SOL_B13_TIP03+1165_ANT_IZGARALI', 'ADET', '134', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(30, 'MM', 'Mamül', 'ARÇELİK', '2968416300', 'TEKMELIK_SOL_B13_ARC1165_ANT_KAPALI', 'ADET', '22', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(31, 'MM', 'Mamül', 'ARÇELİK', '2969280100', 'ÜST TABLA KEÇE SAB.PULU', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(32, 'MM', 'Mamül', 'ARÇELİK', '2971530100', 'SOKET KILIFI', 'ADET', '8189', '80', '11,28', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(33, 'MM', 'Mamül', 'ARÇELİK', '2971530200', 'SOKET KILIFI_ALT(GRİ)', 'ADET', '82423', '80', '10,4', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(34, 'MM', 'Mamül', 'ARÇELİK', '2971930100', 'ÜST TABLA KEÇE SABİTLEYİCİ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(35, 'MM', 'Mamül', 'ARÇELİK', '2976340100', 'CAM_ON_KAPAK_GR(BX_ALCAK_F)ARC1-ARC1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(36, 'MM', 'Mamül', 'ARÇELİK', '2976341100', 'CAM_ON_KPK_GR(BX_ALCAK_F)ARC764-ARC764', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(37, 'MM', 'Mamül', 'ARÇELİK', '2977460100', 'ON_KAPAK_GR(BX_OPAK_ALCAK_F)ARC1_ARC1', 'ADET', '989', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(38, 'MM', 'Mamül', 'ARÇELİK', '2977710100', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC1-ARC1', 'ADET', '285', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(39, 'MM', 'Mamül', 'ARÇELİK', '2977710700', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC700-ARC700', 'ADET', '7', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(40, 'MM', 'Mamül', 'ARÇELİK', '2977711100', 'CAM_ON_KPK_GR(BX_ASMTK_F)ARC1050-ARC1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(41, 'MM', 'Mamül', 'ARÇELİK', '2977712300', 'CAM_KPK_GR(BX_ASMT)1050-ARC1050_UV_TUR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(42, 'MM', 'Mamül', 'ARÇELİK', '2977712500', 'CAM_ON_KAPAK_GR(BX_ASMTK_F)ARC1165-ARC11', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(43, 'MM', 'Mamül', 'ARÇELİK', '2978030100', 'BORU_CIKIS_ARA_PARCA_54-CM_HP_VEGA', 'ADET', '3506', '500', '184', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(44, 'MM', 'Mamül', 'ARÇELİK', '2978670100', 'CAM_ÖN_KAPAK_GR(ABX_ALCAK)ARC1-722-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(45, 'MM', 'Mamül', 'ARÇELİK', '2978670900', 'CAM_ON_KAPAK_GR(ABX_ALCAK)ARC1-1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(46, 'MM', 'Mamül', 'ARÇELİK', '2978671200', 'CAM_ON_KAPAK_GR(ABX_ALCAK)1-722-1_V0', 'ADET', '69', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(47, 'MM', 'Mamül', 'ARÇELİK', '2978671300', 'CAM_ON_KAPAK_GR(ABX_ALCAK)745-722-745_V0', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(48, 'MM', 'Mamül', 'ARÇELİK', '2978672500', 'CAM_ON_KPK_GR(ABX_ALCAK)1050-722-1050_V0', 'ADET', '38', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(49, 'MM', 'Mamül', 'ARÇELİK', '2978680100', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1-722-1', 'ADET', '57', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(50, 'MM', 'Mamül', 'ARÇELİK', '2978680200', 'CAM ON KAPAK GR.(ABX_ASMTRK)ARC745-722-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(51, 'MM', 'Mamül', 'ARÇELİK', '2978680900', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1-1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(52, 'MM', 'Mamül', 'ARÇELİK', '2978682500', 'CAM_ON_KAPAK_GR(ABX_ASMTK)ARC1050-722-1050', 'ADET', '61', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(53, 'MM', 'Mamül', 'ARÇELİK', '2979910100', 'ESANJOR_KAPAGI_GR_54-CM_HP_VEGA', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(54, 'MM', 'Mamül', 'ARÇELİK', '2979910200', 'ESANJOR_KAPAGI_GR_54CM_HP_VEGA(IYONIZER)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(55, 'MM', 'Mamül', 'ARÇELİK', '2979910300', 'ESANJOR_KAPAGI_GR_54-CM_HP_VEGA(NTC)', 'ADET', '20', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(58, 'MM', 'Mamül', 'ARÇELİK', '2982620100', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(59, 'MM', 'Mamül', 'ARÇELİK', '2982620200', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC722-722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(60, 'MM', 'Mamül', 'ARÇELİK', '2982620400', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(61, 'MM', 'Mamül', 'ARÇELİK', '2982620600', 'SEFFAF_ON_KPK_GR(BX_ASMTRK)ARC1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(62, 'MM', 'Mamül', 'ARÇELİK', '2982620700', 'SEFFAF_ON_KAPAK_GR(BX_ASMTRK)ARC1165-1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(63, 'MM', 'Mamül', 'ARÇELİK', '2982950100', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-722-1', 'ADET', '16', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(64, 'MM', 'Mamül', 'ARÇELİK', '2982950200', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-722-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(65, 'MM', 'Mamül', 'ARÇELİK', '2982950300', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-745-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(66, 'MM', 'Mamül', 'ARÇELİK', '2982950400', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-745-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(67, 'MM', 'Mamül', 'ARÇELİK', '2982950500', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-745-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(68, 'MM', 'Mamül', 'ARÇELİK', '2982950600', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)745-1-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(69, 'MM', 'Mamül', 'ARÇELİK', '2982950700', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-745-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(70, 'MM', 'Mamül', 'ARÇELİK', '2982950800', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-745-745', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(71, 'MM', 'Mamül', 'ARÇELİK', '2982950900', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(72, 'MM', 'Mamül', 'ARÇELİK', '2982951000', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(73, 'MM', 'Mamül', 'ARÇELİK', '2982951100', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(74, 'MM', 'Mamül', 'ARÇELİK', '2982951200', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)KROM-722-KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(75, 'MM', 'Mamül', 'ARÇELİK', '2982951300', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-722-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(76, 'MM', 'Mamül', 'ARÇELİK', '2982951400', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(77, 'MM', 'Mamül', 'ARÇELİK', '2982951500', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)722-1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(78, 'MM', 'Mamül', 'ARÇELİK', '2982951600', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)700-1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(79, 'MM', 'Mamül', 'ARÇELİK', '2982951700', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1050-1-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(80, 'MM', 'Mamül', 'ARÇELİK', '2982951800', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1050-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(81, 'MM', 'Mamül', 'ARÇELİK', '2982951900', 'SEFFAF_ON_KAPAK_GR(ABX_ASM)1-1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(82, 'MM', 'Mamül', 'ARÇELİK', '2983510100', 'ON_KAPAK_GR(BX2_OPAK_ALCAK_F)ARC1_ARC1', 'ADET', '1995', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(83, 'MM', 'Mamül', 'ARÇELİK', '2983510500', 'ON_KAPAK_GR(BX2_OPK_ALCAK_F)ARC700_700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(84, 'MM', 'Mamül', 'ARÇELİK', '2983510600', 'ON_KAPAK_GR(BX2_OPK_ALCAK_F)ARC1050_1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(85, 'MM', 'Mamül', 'ARÇELİK', '2983540100', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1_ARC1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(86, 'MM', 'Mamül', 'ARÇELİK', '2983540500', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC700_700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(87, 'MM', 'Mamül', 'ARÇELİK', '2983540600', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1050_1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(88, 'MM', 'Mamül', 'ARÇELİK', '2983540800', 'ON_KAPAK_GR(BX2_OPAK_ASMTRK)ARC1165_1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(89, 'MM', 'Mamül', 'ARÇELİK', '2983550100', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC1-1', 'ADET', '21', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(90, 'MM', 'Mamül', 'ARÇELİK', '2983550200', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC722-722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(91, 'MM', 'Mamül', 'ARÇELİK', '2983550300', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTK)1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(92, 'MM', 'Mamül', 'ARÇELİK', '2983550400', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(93, 'MM', 'Mamül', 'ARÇELİK', '2983550600', 'SEFFAF_ON_KAPAK_GR(BX2_ASMTRK)ARC1165-11', 'ADET', '19', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(94, 'MM', 'Mamül', 'ARÇELİK', '2984780100', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC1-1', 'ADET', '414', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(95, 'MM', 'Mamül', 'ARÇELİK', '2984780700', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(96, 'MM', 'Mamül', 'ARÇELİK', '2984781100', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(97, 'MM', 'Mamül', 'ARÇELİK', '2984781300', 'SEFFAF_ON_KAPAK_GR(BX_YF_XL)ARC1165-1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(98, 'MM', 'Mamül', 'ARÇELİK', '2985310100', 'TEKMELIK_PROLOGUE_GR_ARC1_BEYAZ', 'ADET', '', '650', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(99, 'MM', 'Mamül', 'ARÇELİK', '2985310200', 'TEKMELIK_GR_PROLOGUE_ARC722_SYH', 'ADET', '', '500', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(100, 'MM', 'Mamül', 'ARÇELİK', '2985310300', 'TEKMELIK_GR_PROLOGUE_P1_BYZ_V0', 'ADET', '', '500', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(101, 'MM', 'Mamül', 'ARÇELİK', '2985310400', 'TEKMELIK_GR_PROLOGUE_ARC1050_GRI', 'ADET', '', '500', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(102, 'MM', 'Mamül', 'ARÇELİK', '2985310500', 'TEKMELIK_GR_PROLOGUE_ARC764MGRI', 'ADET', '', '500', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(103, 'MM', 'Mamül', 'ARÇELİK', '2985310600', 'TEKMELIK_GR_PROLOGUE_ARC700_ANTRSIT', 'ADET', '', '500', '390', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(104, 'MM', 'Mamül', 'ARÇELİK', '2985360100', 'SEFFAF_ON_KAPAK_GR(BX2_ALCAK)ARC1-1', 'ADET', '19', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(105, 'MM', 'Mamül', 'ARÇELİK', '2985430100', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC1-ARC1', 'ADET', '382', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(106, 'MM', 'Mamül', 'ARÇELİK', '2985430200', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC722-722', 'ADET', '57', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(107, 'MM', 'Mamül', 'ARÇELİK', '2985430900', 'SEFFAF_ON_KAPAK_GR(BX_ALCAK)ARC1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(108, 'MM', 'Mamül', 'ARÇELİK', '2985450100', 'SEFFAF_ON_KAPAK_GR(ABX_ALCAK)1-722-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(109, 'MM', 'Mamül', 'ARÇELİK', '2985510300', 'SEFFAF_ON_KAPAK_GR(BX2_KKLI_ASMT)ARC1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(110, 'MM', 'Mamül', 'ARÇELİK', '2986080100', 'SEFFAF_ON_KAPAK_GR(ABX_YF_XL)1-722-1', 'ADET', '17', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(111, 'MM', 'Mamül', 'ARÇELİK', '2986080900', 'SEFFAF_ON_KAPAK_GR(ABX_YF_XL)1-1-1', 'ADET', '5', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(112, 'MM', 'Mamül', 'ARÇELİK', '2986081300', 'SEFFAF_ON_KPK_GR(ABX_YF_XL)1050-722-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(113, 'MM', 'Mamül', 'ARÇELİK', '2986081400', 'SEFFAF_ON_KPK_GR(ABX_YF_XL)1050-1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(114, 'MM', 'Mamül', 'ARÇELİK', '2986090100', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC1-1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(115, 'MM', 'Mamül', 'ARÇELİK', '2986090200', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC722-722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(116, 'MM', 'Mamül', 'ARÇELİK', '2986090300', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)1050-1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(117, 'MM', 'Mamül', 'ARÇELİK', '2986090400', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC700-700', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(118, 'MM', 'Mamül', 'ARÇELİK', '2986090600', 'SEFFAF_ON_KAPAK_GR(BX2_YF_XL)ARC1165-116', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(119, 'MM', 'Mamül', 'ARÇELİK', '2987410001', 'AKS  BACA GR', 'ADET', '90', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(120, 'MM', 'Mamül', 'ARÇELİK', '2987410002', 'AKS DIREK TAHLIYE (9+KG)', 'ADET', '4845', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(121, 'MM', 'Mamül', 'ARÇELİK', '2987410003', 'AKS  DIREK TAHLIYE(9+KG)45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(122, 'MM', 'Mamül', 'ARÇELİK', '2987410004', 'AKS  DIREK TAHLIYE(8-KG)45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(123, 'MM', 'Mamül', 'ARÇELİK', '2987410005', 'AKS  DIREK TAHLIYE (8-KG) EVA SUNGER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(124, 'MM', 'Mamül', 'ARÇELİK', '2987410006', 'AKS  DIREK TAHLIYE( 8-KG)', 'ADET', '7830', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(125, 'MM', 'Mamül', 'ARÇELİK', '2987410007', 'AKS  DIREK TAHLIYE CND (TANK ALT)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(126, 'MM', 'Mamül', 'ARÇELİK', '2987410008', 'AKS  DIREK TAHLIYE ABD', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(127, 'MM', 'Mamül', 'ARÇELİK', '2987410009', 'AKS  45PPI EVA SUNGER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(128, 'MM', 'Mamül', 'ARÇELİK', '2987410010', 'AKS  DIREK TAHLIYE (8-KG) 2EVA SUNGER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(129, 'MM', 'Mamül', 'ARÇELİK', '2987410011', 'AKS  DIREK TAHLIYE(9+KG) SPRY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(130, 'MM', 'Mamül', 'ARÇELİK', '2987410012', 'AKS  DIREK TAHLIYE( 8-KG) SPRY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(131, 'MM', 'Mamül', 'ARÇELİK', '2987410013', 'AKS  DIREK TAHLIYE(9+KG)45PPI EVA_SPRY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(132, 'MM', 'Mamül', 'ARÇELİK', '2987410014', 'AKS CAPELLA ABD', 'ADET', '2000', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(133, 'MM', 'Mamül', 'ARÇELİK', '2987410015', 'AKS  DIREK TAHLIYE( 8-KG)_SC', 'ADET', '810', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(134, 'MM', 'Mamül', 'ARÇELİK', '2987410016', 'AKS DIREK TAHLIYE (9+KG)_SC', 'ADET', '300', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(135, 'MM', 'Mamül', 'ARÇELİK', '2987410017', 'AKS  DIREK TAHLIYE BYND ABD', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(136, 'MM', 'Mamül', 'ARÇELİK', '2987910100', 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ', 'ADET', '60', '500', '390', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(137, 'MM', 'Mamül', 'ARÇELİK', '2987910200', 'TEKMELIK_GRUBU_OEM_ARC_722 SIYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(138, 'MM', 'Mamül', 'ARÇELİK', '2987910300', 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ_V0', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(139, 'MM', 'Mamül', 'ARÇELİK', '2987910400', 'TEKMELIK_GRUBU_OEM_ARC_1050_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(140, 'MM', 'Mamül', 'ARÇELİK', '2987910500', 'TEKMELIK_GRUBU_OEM_ARC_764S MGRAY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(141, 'MM', 'Mamül', 'ARÇELİK', '2987910600', 'TEKMELIK_GRUBU_OEM_ARC_700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(142, 'MM', 'Mamül', 'ARÇELİK', '2988080100', 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ', 'ADET', '5085', '650', '370', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(143, 'MM', 'Mamül', 'ARÇELİK', '2988080200', 'TEKMELIK_GRUBU_BEYOND_ARC722 SYH_PARLAK', 'ADET', '', '500', '370', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(144, 'MM', 'Mamül', 'ARÇELİK', '2988080300', 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ_V0', 'ADET', '', '650', '406', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(145, 'MM', 'Mamül', 'ARÇELİK', '2988080400', 'TEKMELIK_GRUBU_BEYOND_ARC_1050_GRI', 'ADET', '', '500', '370', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(146, 'MM', 'Mamül', 'ARÇELİK', '2988080500', 'TEKMELIK_GRUBU_BEYOND_ARC_764S MAN_GRAY', 'ADET', '127', '500', '370', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(147, 'MM', 'Mamül', 'ARÇELİK', '2988080600', 'TEKMELIK_GRUBU_BEYOND_ARC_700_ANTRASIT', 'ADET', '', '500', '370', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(148, 'MM', 'Mamül', 'ARÇELİK', '2990200300', 'TANK YUVASI SU DOLDURMA GR 60 CM B13 HP', 'ADET', '21', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(149, 'MM', 'Mamül', 'ARÇELİK', '2991200100', 'TANK YUVASI GR.(54CM_B13-HOEM-BLG15)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(150, 'MM', 'Mamül', 'ARÇELİK', '2991200200', 'TANK_YUVASI_GR.(54CM_B13-HOEM_SPREY)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(151, 'MM', 'Mamül', 'ARÇELİK', '2991220100', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(152, 'MM', 'Mamül', 'ARÇELİK', '2991220200', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(153, 'MM', 'Mamül', 'ARÇELİK', '2991220300', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(154, 'MM', 'Mamül', 'ARÇELİK', '2991220400', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(155, 'MM', 'Mamül', 'ARÇELİK', '2991220500', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(156, 'MM', 'Mamül', 'ARÇELİK', '2991220600', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1050', 'ADET', '867', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(157, 'MM', 'Mamül', 'ARÇELİK', '2991220700', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC764S', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(158, 'MM', 'Mamül', 'ARÇELİK', '2991220800', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC764S', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(159, 'MM', 'Mamül', 'ARÇELİK', '2991220900', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_ARC1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(160, 'MM', 'Mamül', 'ARÇELİK', '2991221000', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_ARC1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(161, 'MM', 'Mamül', 'ARÇELİK', '2991221100', 'ON_KAPAK_GR_ABM_REV(KKLI)_YUKSEK_KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(162, 'MM', 'Mamül', 'ARÇELİK', '2991221200', 'ON_KAPAK_GR_ABM_REV(KKLI)_XL_KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(163, 'MM', 'Mamül', 'ARÇELİK', '2991280100', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(164, 'MM', 'Mamül', 'ARÇELİK', '2991280200', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(165, 'MM', 'Mamül', 'ARÇELİK', '2991280300', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(166, 'MM', 'Mamül', 'ARÇELİK', '2991280400', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(167, 'MM', 'Mamül', 'ARÇELİK', '2991280500', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(168, 'MM', 'Mamül', 'ARÇELİK', '2991280600', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1050', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(169, 'MM', 'Mamül', 'ARÇELİK', '2991280700', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(170, 'MM', 'Mamül', 'ARÇELİK', '2991280800', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(171, 'MM', 'Mamül', 'ARÇELİK', '2991280900', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_722', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(172, 'MM', 'Mamül', 'ARÇELİK', '2991281000', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_KROM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(173, 'MM', 'Mamül', 'ARÇELİK', '2991281100', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(174, 'MM', 'Mamül', 'ARÇELİK', '2991281200', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_722_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(175, 'MM', 'Mamül', 'ARÇELİK', '2991281300', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_1050_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(176, 'MM', 'Mamül', 'ARÇELİK', '2991281400', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_1050_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(177, 'MM', 'Mamül', 'ARÇELİK', '2991281500', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(178, 'MM', 'Mamül', 'ARÇELİK', '2991281600', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1050_MAGNT', 'ADET', '48', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(179, 'MM', 'Mamül', 'ARÇELİK', '2991281700', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_1_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(180, 'MM', 'Mamül', 'ARÇELİK', '2991281800', 'ON_KPK_GR_ABM_IRV(KKSIZ)_722_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(181, 'MM', 'Mamül', 'ARÇELİK', '2991281900', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_722_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(182, 'MM', 'Mamül', 'ARÇELİK', '2991282000', 'ON_KPK_GR_ABM_IRV(KKSIZ)_1050_KROM_MAGNT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(183, 'MM', 'Mamül', 'ARÇELİK', '2991300100', 'TANK YUVASI GRUBU(60 cmlik)', 'ADET', '985', '420', '744', '39', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(184, 'MM', 'Mamül', 'ARÇELİK', '2991300200', 'TANK_YUVASI_GR.(60CM_B13-HOEM_SPREY)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(185, 'MM', 'Mamül', 'ARÇELİK', '2992690100', 'SAVEWATER_MONTAJ_AKSESUAR_GRUBU', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(186, 'MM', 'Mamül', 'ARÇELİK', '2993100100', 'TEKMELIK_SAG_GRUBU(B13)', 'ADET', '11197', '200', '157', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(187, 'MM', 'Mamül', 'ARÇELİK', '2993100300', 'TEKMELIK_SAG_GRUBU(B13)722_SİYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(188, 'MM', 'Mamül', 'ARÇELİK', '2998700100', 'EŞANJÖR KAPAĞI GR SIRIUS HP54CM', 'ADET', '1132', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(189, 'MM', 'Mamül', 'ARÇELİK', '2998700200', 'EŞANJÖR KAP.GR.SIRIUS HP54CM ARC LG ESNJ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(190, 'MM', 'Mamül', 'ARÇELİK', 'NUMUNE', 'NUMUNE', 'ADET', '25', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(191, 'YM', 'Yarımamül', 'ARÇELİK', '2962340100', 'GERI ITICI TUS', 'ADET', '56600', '80', '2,91', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(192, 'YM', 'Yarımamül', 'ARÇELİK', '2965020100', 'ÖN_YATAKLAMA_KAPAGI_(Terra_Ucuz)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(193, 'YM', 'Yarımamül', 'ARÇELİK', '2966280100', 'TEKMELIK_BUTONU_(ARC-GR)', 'ADET', '24747', '130', '8', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(194, 'YM', 'Yarımamül', 'ARÇELİK', '2966280200', 'TEKMELIK_BUTONU_(ARC-GR-B13)434GRI', 'ADET', '16245', '130', '8', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(195, 'YM', 'Yarımamül', 'ARÇELİK', '2966280400', 'TEKMELIK_BUTONU_(ARC-GR-B13)_722SYH', 'ADET', '6158', '130', '8', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(196, 'YM', 'Yarımamül', 'ARÇELİK', '2966285400', 'TEKMELIK_BUTONU_(ARCGRB13)_700ANTRASIT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(197, 'YM', 'Yarımamül', 'ARÇELİK', '2968050100', 'TANK YUVASI (60 CM)', 'ADET', '292', '420', '744', '39', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(198, 'YM', 'Yarımamül', 'ARÇELİK', '2968050200', 'SU_TANKI_YUVASI_60CM_BUHARLI_(B13)', 'ADET', '281', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(199, 'YM', 'Yarımamül', 'ARÇELİK', '2968060100', 'SU TANKI YUVASI_54CM_(B13-HOEM-BLG15)', 'ADET', '24', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(200, 'YM', 'Yarımamül', 'ARÇELİK', '2968070100', 'TANK YUVASI KAPAĞI', 'ADET', '20', '160', '58', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(201, 'YM', 'Yarımamül', 'ARÇELİK', '2968390100', 'TEKMELIK_SAG_BEKO_2013_ARC P1 BEYAZ', 'ADET', '', '200', '157', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(202, 'YM', 'Yarımamül', 'ARÇELİK', '2968390200', 'TEKMELIK_SAG_BEKO_2013_434_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(203, 'YM', 'Yarımamül', 'ARÇELİK', '2968390400', 'TEKMELIK_SAG_BEKO_722 SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(204, 'YM', 'Yarımamül', 'ARÇELİK', '2968410300', 'TEKMELIK_SOL_BEKO_2013_434GRI_IZGARALI', 'ADET', '556', '500', '211', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(205, 'YM', 'Yarımamül', 'ARÇELİK', '2968410400', 'TEKMELIK_SOL_BEKO_2013_434GRI_KAPALI', 'ADET', '2647', '350', '195', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(206, 'YM', 'Yarımamül', 'ARÇELİK', '2968410500', 'TEKMELIK_SOL_B13_432BRD_IZGARALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(207, 'YM', 'Yarımamül', 'ARÇELİK', '2968410600', 'TEKMELIK_SOL_B13_432BRD_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(208, 'YM', 'Yarımamül', 'ARÇELİK', '2968410700', 'TEKMELIK_SOL_B13_722SİYAH_PARLAK_IZGARALI', 'ADET', '', '420', '213', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(209, 'YM', 'Yarımamül', 'ARÇELİK', '2968410800', 'TEKMELIK_SOL_B13_722SİYAH_PARLAK_KAPALI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(210, 'YM', 'Yarımamül', 'ARÇELİK', '2969980100', 'EŞANjÖR KAPAĞI HP54CM', 'ADET', '290', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(211, 'YM', 'Yarımamül', 'ARÇELİK', '2969980200', 'EŞANJÖR KAPAĞI HP54CM_ARC_LG_ESNJ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(212, 'YM', 'Yarımamül', 'ARÇELİK', '2975570100', 'DIŞ_KAPAK(BX_OPAK)_ARC1_BEYAZ', 'ADET', '2376', '650', '600', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(213, 'YM', 'Yarımamül', 'ARÇELİK', '2975570200', 'DIS_KAPAK(BX_OPAK)_ARC434_GRI', 'ADET', '1493', '650', '600', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(214, 'YM', 'Yarımamül', 'ARÇELİK', '2975575200', 'DIS_KAPAK(BX_OPAK)_TIP03+ARC700_ANTR_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(215, 'YM', 'Yarımamül', 'ARÇELİK', '2975575300', 'DIS_KAPAK(BX_OPAK)_TIP02+ARC1050_GRI', 'ADET', '34', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(216, 'YM', 'Yarımamül', 'ARÇELİK', '2975575500', 'DIS_KAPAK(BX_OPAK)_TIP03+ARC1165', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(217, 'YM', 'Yarımamül', 'ARÇELİK', '2975590100', 'TUTAMAK(BX_OPAK)_ARC1_BEYAZ', 'ADET', '4439', '300', '24', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(218, 'YM', 'Yarımamül', 'ARÇELİK', '2975590200', 'TUTAMAK(BX_OPAK)_ARC434_GRI', 'ADET', '3836', '300', '24', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(219, 'YM', 'Yarımamül', 'ARÇELİK', '2975590300', 'TUTAMAK(BX_OPAK)_ARC722_SIYAH_PARLAK', 'ADET', '1877', '300', '24', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(220, 'YM', 'Yarımamül', 'ARÇELİK', '2975595200', 'TUTAMAK_BX_TIP03+ARC700_ANTASIT-GRI', 'ADET', '124', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(221, 'YM', 'Yarımamül', 'ARÇELİK', '2975595300', 'TUTAMAK(BX_OPAK)TIP02+ARC1050_GRI', 'ADET', '1029', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(222, 'YM', 'Yarımamül', 'ARÇELİK', '2975595500', 'TUTAMAK_BX_TIP03+ARC1165_YENI_ANTRASIT', 'ADET', '320', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(223, 'YM', 'Yarımamül', 'ARÇELİK', '2976320100', 'DIS_KAPAK_CAM_(BX)_ARC1_BEYAZ', 'ADET', '2014', '650', '358', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(224, 'YM', 'Yarımamül', 'ARÇELİK', '2976320200', 'DIS_KAPAK_CAM_(BX)_ARC434_GRI', 'ADET', '974', '650', '358', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(225, 'YM', 'Yarımamül', 'ARÇELİK', '2976320300', 'DIS_KAPAK_CAM_(BX)_ARC722_SIYAH_PARLAK', 'ADET', '1019', '650', '372', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(226, 'YM', 'Yarımamül', 'ARÇELİK', '2976325100', 'DIS_KAPAK_CAM_(BX)_TIP03+ARC700_ANTR_GRI', 'ADET', '25', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(227, 'YM', 'Yarımamül', 'ARÇELİK', '2976325300', 'DIS_KAPAK_CAM_(BX)_TIP02+ARC1050_GRI', 'ADET', '33', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(228, 'YM', 'Yarımamül', 'ARÇELİK', '2976325400', 'DIS_KAPAK_CAM_(BX)_TIP03+ARC1165_YENI_AN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(229, 'YM', 'Yarımamül', 'ARÇELİK', '2976330100', 'İÇ KAPAK CAM (BX)ARC1 BEYAZ', 'ADET', '1152', '500', '264', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(230, 'YM', 'Yarımamül', 'ARÇELİK', '2976330200', 'IC_KAPAK_CAM_(BX)_ARC722_SIYAH_PARLAK', 'ADET', '268', '500', '284', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(231, 'YM', 'Yarımamül', 'ARÇELİK', '2976330300', 'IC_KAPAK_CAM_(BX)_ARC1_BEYAZ_V0', 'ADET', '2075', '500', '311', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(232, 'YM', 'Yarımamül', 'ARÇELİK', '2976330400', 'IC_KAPAK_CAM_(BX)_ARC434_GRI', 'ADET', '2330', '500', '260', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(233, 'YM', 'Yarımamül', 'ARÇELİK', '2976330500', 'İÇ KAPAK CAM (BX)ARC1 BEYAZ - POLYAR', 'ADET', '1309', '500', '320', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(234, 'YM', 'Yarımamül', 'ARÇELİK', '2976370100', 'DIŞ_KAPAK_CAM_(ABX)_ARC1_BEYAZ', 'ADET', '25', '500', '250', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(235, 'YM', 'Yarımamül', 'ARÇELİK', '2976370200', 'DIS_KAPAK_CAM_(ABX)_ARC434_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(236, 'YM', 'Yarımamül', 'ARÇELİK', '2976370300', 'DIŞ KAPAK CAM (ABX) ARC722_PARLAK SİYAH', 'ADET', '3782', '500', '245', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(237, 'YM', 'Yarımamül', 'ARÇELİK', '2976375000', 'DIS_KAPAK_CAM_(ABX)_TIP02+ARC745_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(238, 'YM', 'Yarımamül', 'ARÇELİK', '2976375100', 'DIS_KAPAK_CAM_(ABX)_TIP03+ARC700_ANTRAST', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(239, 'YM', 'Yarımamül', 'ARÇELİK', '2976375200', 'DIS_KAPAK_CAM_(ABX)_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(240, 'YM', 'Yarımamül', 'ARÇELİK', '2976380100', 'RİNG CAM(ABX) ARC1-BEYAZ', 'ADET', '1126', '500', '173', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(241, 'YM', 'Yarımamül', 'ARÇELİK', '2976380200', 'RING CAM ABX ARC434-GRİ', 'ADET', '5433', '500', '173', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(242, 'YM', 'Yarımamül', 'ARÇELİK', '2976380300', 'RING_CAM_(ABX)_ARC722-SIYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(243, 'YM', 'Yarımamül', 'ARÇELİK', '2976385000', 'RING CAM ABX TIP02+ARC745-GRİ', 'ADET', '10', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(244, 'YM', 'Yarımamül', 'ARÇELİK', '2976385100', 'RING_CAM_(ABX)_TIP03+ARC700-ANTRST_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(245, 'YM', 'Yarımamül', 'ARÇELİK', '2976385200', 'RING_CAM_(ABX)_TIP04+KROM_KAPLAMA', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(246, 'YM', 'Yarımamül', 'ARÇELİK', '2976385300', 'RING CAM ABX TIP02+ARC1050-GRİ', 'ADET', '508', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(247, 'YM', 'Yarımamül', 'ARÇELİK', '2976390100', 'TUTAMAK CAM (ABX)-ARCP1_BEYAZ', 'ADET', '2703', '160', '48', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(248, 'YM', 'Yarımamül', 'ARÇELİK', '2976390200', 'TUTAMAK CAM ABX ARC-434-GRİ', 'ADET', '11693', '160', '48', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(249, 'YM', 'Yarımamül', 'ARÇELİK', '2976390300', 'TUTAMAK_CAM_(ABX)-ARC722_SİYAH_PARLAK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(250, 'YM', 'Yarımamül', 'ARÇELİK', '2976395200', 'TUTAMAK_CAM_(ABX)-TIP03+ARC700_ANTRS_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(251, 'YM', 'Yarımamül', 'ARÇELİK', '2976395300', 'TUTAMAK_CAM_(ABX)-TIP04+KROM-KAPLAMA', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(252, 'YM', 'Yarımamül', 'ARÇELİK', '2976395400', 'TUTAMAK CAM ABX-TIP02+ARC1050_GRİ', 'ADET', '162', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(253, 'YM', 'Yarımamül', 'ARÇELİK', '2976760100', 'IC_KAPAK(BX_OPAK_ALCAK_FORM)_ARC1_BEYAZ', 'ADET', '1171', '650', '610', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(254, 'YM', 'Yarımamül', 'ARÇELİK', '2978020100', 'ESANJOR_KAPAGI_54-CM_HP_VEGA', 'ADET', '1939', '350', '290', '47', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(255, 'YM', 'Yarımamül', 'ARÇELİK', '2978020200', 'ESANJOR_KAPAGI_54CM_HP_VEGA(IYONIZER)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(256, 'YM', 'Yarımamül', 'ARÇELİK', '2978020300', 'ESANJOR_KAPAGI_54-CM_HP_VEGA_NTC', 'ADET', '1965', '350', '290', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(257, 'YM', 'Yarımamül', 'ARÇELİK', '2980120100', 'BACA_GRUBU_(Polyar FC)', 'ADET', '604', '300', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(258, 'YM', 'Yarımamül', 'ARÇELİK', '2980120200', 'BACA_GRUBU_(PPHO 5VB)', 'ADET', '', '300', '275', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(259, 'YM', 'Yarımamül', 'ARÇELİK', '2978760100', 'SPREY_T_BORU', 'ADET', '13935', '80', '6,13', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(260, 'YM', 'Yarımamül', 'ARÇELİK', '2980490100', 'YUKSEK_SEFFAF_PLASTIK_PRLG', 'ADET', '50', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(261, 'YM', 'Yarımamül', 'ARÇELİK', '2980930100', 'TEKMELIK_PROLOGUE_ARC1_BEYAZ - GRUPSUZ', 'ADET', '74', '500', '372', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(262, 'YM', 'Yarımamül', 'ARÇELİK', '2980930200', 'TEKMELIK_PROLOGUE_ARC434_GRI - GRUPSUZ', 'ADET', '100', '500', '372', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(263, 'YM', 'Yarımamül', 'ARÇELİK', '2980930300', 'TEKMELIK_PROLOGUE_ARC722_SIYAH - GRUPSUZ', 'ADET', '2173', '500', '385', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(264, 'YM', 'Yarımamül', 'ARÇELİK', '2980930400', 'TEKMELIK_PROLOGUE_BEYAZ_ABS_V0 - GRUPSUZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(265, 'YM', 'Yarımamül', 'ARÇELİK', '2980935000', 'TEKMELIK_PROLOGUE_TIP02+ARC1050_GRI', 'ADET', '664', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(266, 'YM', 'Yarımamül', 'ARÇELİK', '2980935100', 'TEKMELIK_PROLOGUE_TIP03+ARC764S_GRI', 'ADET', '10', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(267, 'YM', 'Yarımamül', 'ARÇELİK', '2980935200', 'TEKMELIK_PROLOGUE_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(268, 'YM', 'Yarımamül', 'ARÇELİK', '2980935600', 'TEKMELIK_PROLOGUE_TIP03+ARC1165_GRI', 'ADET', '19', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(269, 'YM', 'Yarımamül', 'ARÇELİK', '2982280100', 'TUTAMAK_(BX2)_ARC1_BEYAZ', 'ADET', '3326', '300', '30', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(270, 'YM', 'Yarımamül', 'ARÇELİK', '2982280200', 'TUTAMAK_(BX2)_ARC434_GRI', 'ADET', '602', '300', '30', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(271, 'YM', 'Yarımamül', 'ARÇELİK', '2982280300', 'TUTAMAK_(BX2)_ARC722_SIYAH', 'ADET', '4211', '300', '30', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(272, 'YM', 'Yarımamül', 'ARÇELİK', '2982285100', 'TUTAMAK_(BX2)_TIP03+ARC700_ANTRASIT_GRI', 'ADET', '1720', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(273, 'YM', 'Yarımamül', 'ARÇELİK', '2982285200', 'TUTAMAK_(BX2)_TIP03+ARC1050_GRİ', 'ADET', '319', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(274, 'YM', 'Yarımamül', 'ARÇELİK', '2982285400', 'TUTAMAK_(BX2)_TIP03+ARC1165_YENI_ANTRASI', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(275, 'YM', 'Yarımamül', 'ARÇELİK', '2982540100', 'SEFFAF_IC_KAPAK_ALCAK_FORM', 'ADET', '1009', '500', '520', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(276, 'YM', 'Yarımamül', 'ARÇELİK', '2982920100', 'TANK YUVASI KAPAGI PROLOGUE', 'ADET', '36356', '350', '61,25', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, '');
INSERT INTO `malzemeler` (`malzeme_id`, `malzeme_tür`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_logo`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`, `malzeme_tur`) VALUES
(277, 'YM', 'Yarımamül', 'ARÇELİK', '2982970100', 'DIS_KAPAK(BX2_OPAK_YEKPARE)ARC1 BEYAZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(278, 'YM', 'Yarımamül', 'ARÇELİK', '2982970200', 'DIS_KAPAK(BX2_OPAK_YEKP)ARC434_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(279, 'YM', 'Yarımamül', 'ARÇELİK', '2982970300', 'DIS_KAPAK(BX2_OPAK_YEKP)ARC722_SIYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(280, 'YM', 'Yarımamül', 'ARÇELİK', '2982975000', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP02+ARC745_GR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(281, 'YM', 'Yarımamül', 'ARÇELİK', '2982975200', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC700_A_G', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(282, 'YM', 'Yarımamül', 'ARÇELİK', '2982975300', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP02+ARC1050_GR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(283, 'YM', 'Yarımamül', 'ARÇELİK', '2982975400', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC764S_GR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(284, 'YM', 'Yarımamül', 'ARÇELİK', '2982975500', 'DIS_KAPAK(BX2_OPAK_YEKP)TIP03+ARC1165_A_', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(285, 'YM', 'Yarımamül', 'ARÇELİK', '2984320100', 'TEKMELIK_OEM_ARC1_BEYAZ_GRUPSUZ', 'ADET', '82', '500', '365', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(286, 'YM', 'Yarımamül', 'ARÇELİK', '2984320200', 'TEKMELIK_OEM_ARC434_GRI_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(287, 'YM', 'Yarımamül', 'ARÇELİK', '2984320300', 'TEKMELIK_OEM_ARC722_SIYAH_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(288, 'YM', 'Yarımamül', 'ARÇELİK', '2984320400', 'TEKMELIK_OEM_ARC1_BYZ_ABS_V0_GRUPSUZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(289, 'YM', 'Yarımamül', 'ARÇELİK', '2984325000', 'TEKMELIK_OEM_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(290, 'YM', 'Yarımamül', 'ARÇELİK', '2984325100', 'TEKMELIK_OEM_TIP03+ARC764S_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(291, 'YM', 'Yarımamül', 'ARÇELİK', '2984325200', 'TEKMELIK_OEM_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(292, 'YM', 'Yarımamül', 'ARÇELİK', '2985720100', 'TEKMELIK_BEYOND_ARC1_BEYAZ_GRUPSUZ', 'ADET', '', '500', '370', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(293, 'YM', 'Yarımamül', 'ARÇELİK', '2985720200', 'TEKMELIK_BEYOND_ARC434_GRI_GRUPSUZ', 'ADET', '', '500', '370', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(294, 'YM', 'Yarımamül', 'ARÇELİK', '2985720300', 'TEKMELIK_BEYOND_ARC722_SIYAH_GRUPSUZ', 'ADET', '', '650', '370', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(295, 'YM', 'Yarımamül', 'ARÇELİK', '2985720400', 'TEKMELIK_BEYOND_BEYAZ_ABS_V0_GRUPSUZ', 'ADET', '', '500', '406', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(296, 'YM', 'Yarımamül', 'ARÇELİK', '2985725000', 'TEKMELIK_BEYOND_TIP02+ARC1050_GRI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(297, 'YM', 'Yarımamül', 'ARÇELİK', '2985725100', 'TEKMELIK_BEYOND_TIP03+ARC764S_GRI', 'ADET', '14', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(298, 'YM', 'Yarımamül', 'ARÇELİK', '2985725200', 'TEKMELIK_BEYOND_TIP03+ARC700_ANTRASIT', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(299, 'YM', 'Yarımamül', 'ARÇELİK', '2991150100', 'KORUYUCU_KAPAK_ABM_FUME', 'ADET', '', '650', '655', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(300, 'YM', 'Yarımamül', 'ARÇELİK', '2991160100', 'DIS_INLAY_ABM_KKLI_ARC722_SIYAH', 'ADET', '4793', '650', '120', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(301, 'YM', 'Yarımamül', 'ARÇELİK', '2991170100', 'CAM_TUTUCU_ABM_SIYAH', 'ADET', '3148', '650', '309', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(302, 'YM', 'Yarımamül', 'ARÇELİK', '2991180100', 'IC_INLAY_ABM_KKLI_ARC722_SIYAH', 'ADET', '4418', '500', '250', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(303, 'YM', 'Yarımamül', 'ARÇELİK', '2991190100', 'IC_KAPAK_ABM_KKLI_SIYAH', 'ADET', '1255', '650', '360', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(304, 'YM', 'Yarımamül', 'ARÇELİK', '2991240100', 'IC_INLAY_ABM_KKSIZ_ARC1_BEYAZ', 'ADET', '', '650', '351', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(305, 'YM', 'Yarımamül', 'ARÇELİK', '2991240200', 'IC_INLAY_ABM_KKSIZ_ARC434_GRI', 'ADET', '', '650', '351', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(306, 'YM', 'Yarımamül', 'ARÇELİK', '2991240300', 'IC_INLAY_ABM_KKSIZ_ARC722_SIYAH', 'ADET', '', '650', '360', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(307, 'YM', 'Yarımamül', 'ARÇELİK', '2991250100', 'DIS_RING_ABM_ARC1_BEYAZ', 'ADET', '37', '500', '258', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(308, 'YM', 'Yarımamül', 'ARÇELİK', '2991250200', 'DIS_RING_ABM_ARC434_GRI', 'ADET', '3933', '500', '258', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(309, 'YM', 'Yarımamül', 'ARÇELİK', '2991250300', 'DIS_RING_ABM_ARC722_SIYAH', 'ADET', '', '500', '258', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(310, 'YM', 'Yarımamül', 'ARÇELİK', '2991260100', 'IC_KAPAK_ABM_KKSIZ_SIYAH', 'ADET', '453', '650', '590', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(311, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCG22000-AA', 'STAND FLAT 65', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(312, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22000-AA', 'STAND COVER BOOMERANG (LEFT)-SİLVER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(313, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22100-AA', 'STAND COVER BOOMERANG (RIGHT)-SİLVER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(314, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22800-AA', 'STAND CURVE NAIL (LEFT) - 65\-GRİ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(315, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH22900-AA', 'STAND CURVE NAIL (RIGHT) - 65\-GRİ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(316, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH26800-AC', 'AYAK GRUBU SOL BUM.65  CLARTY SY-SİLVER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(317, 'MM', 'Mamül', 'ARÇELİK Eİ', 'UCH26900-AC', 'AYAK GRUBU SAĞ BUM.65 CLARTY SY-SİLVER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(318, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ22900-AA', 'PANEL BRACKET PANEL 65 E-BOARD RIGHT', 'ADET', '7691', '160', '13', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(319, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ22900-AC', 'PANEL BRACKET PANEL 65 E-BOARD RIGHT', 'ADET', '4001', '160', '13', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(320, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23100-AA', 'PANEL BRACKET BOTTOM 65 E- BOARD', 'ADET', '', '160', '18,3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(321, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23100-AC', 'PANEL BRACKET BOTTOM 65 E- BOARD', 'ADET', '', '160', '18,3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(322, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23200-AA', 'GLASS BRACKET 65 E-BOARD', 'ADET', '', '80', '2,7', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(323, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WBZ23200-AC', 'GLASS BRACKET 65 E-BOARD', 'ADET', '', '80', '2,7', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(324, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCD21700-AA', 'SOURCE BOARD SUPPORT', 'ADET', '21000', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(325, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCE20700-AA', 'CLARTY WIFI HOLDER PLASTIC', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(326, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCE23401-AB', 'TOP AV SMART CARD', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(327, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG21700-AA', 'SOURCE BOARD HOLDER', 'ADET', '5965', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(328, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG22000-AA', 'PLASTIC STAND FLAT 65 CLARITY SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(329, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCG27000-AA', 'AYAK GRUBU DÜZ 65 CLARİTY SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(330, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCH26800-AC', 'AYAK GRUBU SOL BUM.65  CLARTY SY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(331, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCH26900-AC', 'AYAK GRUBU SAĞ BUM.65 CLARTY SY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(332, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCL23200-AA', 'PLASTIC CLARTY BOTTOM AV', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(333, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WCL23202-AA', 'PLASTIC CLARTY BOTTOM AV BEYAZ O2', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(334, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY21500-AA', 'COVER CI INFINITY/ONYX', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(335, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY23200-AA', 'BOTTOM AV', 'ADET', '21', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(336, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WDY23202-AA', 'BOTTOM AV SİYAH AV', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(337, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHD21700-AA', 'DESTEK SOURCE BOARD OPTIMUS', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(338, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHD21700-AB', 'DESTEK SOURCE BOARD OPTIMUS', 'ADET', '', '130', '1,56', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(339, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AA', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(340, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AB', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(341, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AC', 'TUTUCU SOURCE BOARD OPTIMUS LG', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(342, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE21700-AD', 'TUTUCU SOURCE BOARD OPTIMUS LG SİYAH', 'ADET', '800', '130', '2', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(343, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AA', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(344, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23300-AA', 'PLASTIK OPTIMUS SIDE AV', 'ADET', '611', '160', '6,85', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(345, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23301-AC', 'PLASTIK OPTIMUS SIDE AV', 'ADET', '2100', '160', '6,8', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(346, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHF21700-AA', 'TUTUCU SOURCE BOARD OPTIMUS BOE-SS', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(347, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHF21700-AB', 'TUTUCU SOURCE BOARD OPTIMUS BOE-SS NATURAL', 'ADET', '3535', '160', '1,65', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(348, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHK23200-AB', 'PLASTIK OPTIMUS BOTTOM AV WHİTE', 'ADET', '490', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(349, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHK23300-AB', 'PLASTIK OPTIMUS SIDE AV NX /AF-20 BEYAZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(350, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AB', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(351, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AC', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(352, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AD', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(353, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WMA21900-AE', 'PLS STAND ADAP. PART 43-50-55 OCEAN WHITE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(354, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AA', 'PLS STAND ADAP. PART 43-50-55 OCEAN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(355, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AB', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(356, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AC', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(357, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AD', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(358, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AE', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '146', '130', '23', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(359, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WRJ21900-AF', 'PLS STAND ADAP. PART 43-50-55 OCEAN BLACK', 'ADET', '', '130', '23', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(360, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNL23300-AC', 'PLASTIK LEDART SIDE AV SIYAH CN/G7', 'ADET', '6', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(361, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNM23200-AB', 'PLASTİK LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(362, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNM23201-AB', 'PLASTIK LEDART BOTTOM AV SIYAH G7', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(363, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNR20700-AB', '65 CURVED WIFI TUTUCU', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(364, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNV26800-AB', 'AYAK GRUBU SOL LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(365, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZNV26900-AB', 'AYAK GRUBU SAĞ LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(366, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPP23200-AB', 'PLASTIK ETERNITY BOTTOM AV 55EP4 KR SIY.', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(367, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPP23300-AC', 'PLASTIK ETERNITY SIDE AV 55EP4 KR SIY', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(368, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPV23200-AB', 'PLASTİK LEDART BEYAZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(369, 'MM', 'Mamül', 'ARÇELİK Eİ', 'ZPV23201-AB', 'PLASTIK LEDART BOTTOM AV BEYAZ G7', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(370, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22000-AA', 'STAND COVER BOOMERANG (LEFT)', 'ADET', '920', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(371, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22100-AA', 'STAND COVER BOOMERANG (RIGHT)', 'ADET', '111', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(372, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22800-AA', 'STAND CURVE NAIL (LEFT) - 65\', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(373, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'WCH22900-AA', 'STAND CURVE NAIL (RIGHT) - 65\', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(374, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'ZNV22000-AA', 'PLASTİK YATAY AYAK LEDART SİYAH', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(375, 'YM', 'Yarımamül', 'ARÇELİK Eİ', 'ZQS22000-AA', 'PLASTIK YATAY AYAK LEDART SIYAH GF%10', 'ADET', '', '300', '73', '90', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(376, 'MM', 'Mamül', 'ARÇELK TKM', '3001030100', 'SASE GRUBU KOMPLE(AVRUPA FISLI)', 'ADET', '36', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(377, 'MM', 'Mamül', 'ARÇELK TKM', '3001030200', 'SASE GRUBU KOMPLE (UK ING. FISLI)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(378, 'MM', 'Mamül', 'ARÇELK TKM', '3001030300', 'SASE GRUBU KOMPLE (AVUSTRALYA. FISLI)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(379, 'MM', 'Mamül', 'ARÇELK TKM', '3001140100', 'ÜST KAPAK-TKM', 'ADET', '910', '500', '269,2', '47', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(380, 'MM', 'Mamül', 'ARÇELK TKM', '3001930100', 'PISIRME HAZNESI YUVASI GRUBU ÇİFTLİ-SERVİS', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(381, 'MM', 'Mamül', 'ARÇELK TKM', '3003570100', 'PISIRME HAZNESI YUVASI GRUBU MİNİ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(382, 'MM', 'Mamül', 'ARÇELK TKM', '3003570200', 'PISIRME HAZNESI YUVASI GRUBU UL', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(383, 'MM', 'Mamül', 'ARÇELK TKM', '3580290100', 'PISIRME HAZNESI YUVASI TEKLİ GR', 'ADET', '228', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(384, 'MM', 'Mamül', 'ARÇELK TKM', '3582390100', 'PISIRME HAZNESI YUVASI GR-TEKLİ  NOZZLE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(385, 'MM', 'Mamül', 'ARÇELK TKM', '3583310100', 'PISIRME HAZNESI YUVASI ÇİFTLİ GR', 'ADET', '9', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(386, 'MM', 'Mamül', 'ARÇELK TKM', '3583710100', 'SU DAGITICISI', 'ADET', '6600', '160', '10,2', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(387, 'MM', 'Mamül', 'ARÇELK TKM', '3583720100', 'POMPA TUTUCU', 'ADET', '800', '160', '4,45', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(388, 'MM', 'Mamül', 'ARÇELK TKM', '3583730100', 'TUS KARTI KART TUTUCU', 'ADET', '1481', '200', '41,5', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(389, 'MM', 'Mamül', 'ARÇELK TKM', '3583730200', 'TUS KARTI KART TUTUCU US', 'ADET', '', '200', '43,8', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(390, 'MM', 'Mamül', 'ARÇELK TKM', '3583740100', 'ARKA KAPAK', 'ADET', '73', '300', '114', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(391, 'MM', 'Mamül', 'ARÇELK TKM', '3583740200', 'ARKA KAPAK US', 'ADET', '6', '200', '115', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(392, 'MM', 'Mamül', 'ARÇELK TKM', '3583800100', 'HORTUM ARA PARCA', 'ADET', '27582', '80', '1,3', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(393, 'MM', 'Mamül', 'ARÇELK TKM', '3583850100', 'ANA KART TASIYICI', 'ADET', '2205', '130', '64,8', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(394, 'MM', 'Mamül', 'ARÇELK TKM', '3583850200', 'ANA KART TASIYICI US', 'ADET', '', '130', '66', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(395, 'MM', 'Mamül', 'ARÇELK TKM', '3585160100', 'SERVİS KAPAĞI  - ARÇELİK ÇAY MAKİNESİ', 'ADET', '7600', '130', '7,5', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(396, 'MM', 'Mamül', 'ARÇELK TKM', '3585440100', 'KARAF KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '3648', '130', '41', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(397, 'MM', 'Mamül', 'ARÇELK TKM', '3585450100', 'KARAF SAP ALT - ARÇELİK ÇAY MAKİNESİ', 'ADET', '20', '130', '31', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(398, 'MM', 'Mamül', 'ARÇELK TKM', '3585460100', 'KARAF SAP ÜST - ARÇELİK ÇAY MAKİNESİ', 'ADET', '', '130', '12,3', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(399, 'MM', 'Mamül', 'ARÇELK TKM', '3585940100', 'DEMLEME ODASI GRUBU - ÇAY MAKİNESİ', 'ADET', '212', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(400, 'MM', 'Mamül', 'ARÇELK TKM', '3586010100', 'DEM HAZ UST KAPAK SERIGRAFILI ARCELİK ÇAY MAKİNESİ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(401, 'MM', 'Mamül', 'ARÇELK TKM', '3586010200', 'DEM HAZ UST KAPAK SERIGRAFILI BEKO ÇAY MAKİNESİ', 'ADET', '192', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(402, 'MM', 'Mamül', 'ARÇELK TKM', '3586010300', 'DEM HAZ UST KAPAK SERIGRFL ARCELIK 3IN1  ÇAY MAK.', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(403, 'MM', 'Mamül', 'ARÇELK TKM', '3586010400', 'DEM HAZ UST KAPAK SERIGRAFILI BEKO 3IN1  ÇAY MAK.', 'ADET', '1374', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(404, 'MM', 'Mamül', 'ARÇELK TKM', '3586010500', 'DEM HAZ UST KAPAK SERIGRFL GRUNDIG 3IN1  ÇAY MAK.', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(405, 'MM', 'Mamül', 'ARÇELK TKM', '3586010600', 'DEM HAZ UST KAPAK SERİGRAFİLİ ARÇELİK 3IN1 İNOX', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(406, 'MM', 'Mamül', 'ARÇELK TKM', '3586020100', 'DEMLEME HAZNESİ DIŞ GÖVDE - ARÇELİK LOGO SERİGRAFİ', 'ADET', '662', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(407, 'MM', 'Mamül', 'ARÇELK TKM', '3586020200', 'DEMLEME HAZNESİ DIŞ GÖVDE - BEKO LOGO SERİGRAFİ', 'ADET', '343', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(408, 'MM', 'Mamül', 'ARÇELK TKM', '3586020300', 'DEMLEME HAZNESİ DIŞ GÖVDE - GRUNDIG LOGO SERİGRAFİ', 'ADET', '1', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(409, 'MM', 'Mamül', 'ARÇELK TKM', '3586020400', 'DEMLEME HAZNESİ DIŞ GÖVDE - ARÇELİK INOX SERİGRAFİ', 'ADET', '480', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(410, 'MM', 'Mamül', 'ARÇELK TKM', '3586070100', 'GOVDE UST KAPAK GRUBU ARÇELİK ÇAY MAKİNESİ', 'ADET', '60', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(411, 'MM', 'Mamül', 'ARÇELK TKM', '3586070200', 'GOVDE UST KAPAK GRUBU BEKO ÇAY MAKİNESİ', 'ADET', '32', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(412, 'MM', 'Mamül', 'ARÇELK TKM', '3586070300', 'GOVDE UST KAPAK GRUBU 3IN1 ARCELIK ÇAY MAKİNESİ', 'ADET', '64', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(413, 'MM', 'Mamül', 'ARÇELK TKM', '3586070400', 'GOVDE UST KAPAK GRUBU 3IN1 BEKO ÇAY MAKİNESİ', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(414, 'MM', 'Mamül', 'ARÇELK TKM', '3586070500', 'GOVDE UST KAPAK GRUBU 3IN1 GRUNDIG ÇAY MAKİNESİ', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(415, 'MM', 'Mamül', 'ARÇELK TKM', '3586070600', 'GOVDE UST KAPAK GRUBU  3IN1 ARCELIK INOX  ÇAY MAK.', 'ADET', '54', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(416, 'MM', 'Mamül', 'ARÇELK TKM', '3586080100', 'ANA GÖVDE ALT KAPAK GRUBU - ARÇELİK ÇAY MAKİNESİ', 'ADET', '650', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(417, 'MM', 'Mamül', 'ARÇELK TKM', '3586080200', 'ANA GÖVDE ALT KAPAK GRUBU BIO  - ÇAY MAKİNESİ', 'ADET', '1470', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(418, 'MM', 'Mamül', 'ARÇELK TKM', '3587430100', 'ORTAM AYDINLATMA GRUBU - PROYO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(419, 'MM', 'Mamül', 'ARÇELK TKM', '3587770100', 'UST TASIYICI GOVDE GRUBU - PROYO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(420, 'MM', 'Mamül', 'ARÇELK TKM', '3588570100', 'UST TASIYICI GOVDE GRUBU BEYAZ - PROYO', 'ADET', '14', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(421, 'MM', 'Mamül', 'ARÇELK TKM', '3588570200', 'UST TASIYICI GOVDE GRUBU BASIC SIYAH  - PROYO', 'ADET', '14', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(422, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001100100', 'UST CERCEVE (SY01)', 'ADET', '922', '300', '229', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(423, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001120100', 'EK KONTAK YAY KAPAGI', 'ADET', '45015', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(424, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001230100', 'PISIRME HAZNESI YUVASI UST ÇİFTLİ', 'ADET', '610', '160', '144', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(425, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001240100', 'PISIRME HAZNESI YUVASI ALT ÇİFTLİ', 'ADET', '', '200', '236', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(426, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001260100', 'PISIRME HAZ. CONTASI (FOOD GRADE SIYAH)', 'ADET', '15', '130', '13,5', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(427, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001730100', 'SEVIYE SENSORU CAMI', 'ADET', '15419', '80', '3,85', '21', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(428, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001740100', 'PISME HAZNESI ALGILAMA KOLU.', 'ADET', '6052', '80', '2,6', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(429, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001940100', 'POMPA SU TASIYICISI (SY02)', 'ADET', '71', '160', '52,5', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(430, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001980100', 'SEVIYE ALGILAMA KONTAGI KAPAGI', 'ADET', '15457', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(431, 'YM', 'Yarımamül', 'ARÇELK TKM', '3001990100', 'BUHAR KANALI KAPAGI', 'ADET', '1152', '130', '37,3', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(432, 'YM', 'Yarımamül', 'ARÇELK TKM', '3002210100', 'TAHLİYE BORUSU', 'ADET', '3456', '130', '19,75', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(433, 'YM', 'Yarımamül', 'ARÇELK TKM', '3002350100', 'TABAN TAKOZU MILI', 'ADET', '13870', '80', '0,3', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(434, 'YM', 'Yarımamül', 'ARÇELK TKM', '3003580100', 'PİŞİRME HAZNESİ YUVASI ÜST MİNİ TKM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(435, 'YM', 'Yarımamül', 'ARÇELK TKM', '3003590100', 'PISIRME HAZNESI YUVASI ALT (MINI TKM)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(436, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010100', 'PISIRME HAZNESI YUVASI UST BUH TER KAP. TEKLİ', 'ADET', '17', '200', '77', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(437, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010200', 'PIS HAZ YUV UST_NOZZLE TAK BUH TER KAP', 'ADET', '3030', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(438, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580010300', 'PISIRME HAZNESI YUVASI UST BUH TER ACK.', 'ADET', '3450', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(439, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580020100', 'PISIRME HAZNESI YUVASI_ALT TEKLİ', 'ADET', '3335', '300', '220', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(440, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580020200', 'PISIRME HAZNESI YUVASI_ALT YENI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(441, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580040100', 'R DESİNG TAŞMA ODASI KAPAĞI', 'ADET', '3175', '130', '16,7', '33', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(442, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580290200', 'PIS HAZ YUV GR_BUH TER DEL ACIK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(443, 'YM', 'Yarımamül', 'ARÇELK TKM', '3583800200', 'HORTUM ARA PARCA KUCUK CAP.', 'ADET', '46150', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(444, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585050100', 'ANA GÖVDE ÜST KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '850', '500', '290', '75', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(445, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585050200', 'ANA GÖVDE ÜST KAPAK DAYAMALI - ARÇELİK ÇAY MAK.', 'ADET', '300', '500', '312', '75', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(446, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585060100', 'ANA GÖVDE ALT KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '110', '350', '404', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(447, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585060200', 'ANA GÖVDE ALT KAPAK BİO - ÇAY MAKİNASI', 'ADET', '2', '350', '404', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(448, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585070100', 'DIKME - ARÇELİK ÇAY MAKİNESİ', 'ADET', '1142', '300', '106,2', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(449, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585100100', 'GÖVDE ARA PARÇA - ARÇELİK ÇAY MAKİNESİ', 'ADET', '10464', '160', '58,5', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(450, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585120100', 'GOVDE KETTLE VALF KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '3966', '130', '3,5', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(451, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585140100', 'SU DAGITICISI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '14964', '130', '13,2', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(452, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585150100', 'KETTLE VALF YAY KLAVUZU - ARÇELİK ÇAY MAKİNESİ', 'ADET', '4817', '80', '1,75', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(453, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585200100', 'IŞIK TAŞIYICI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '2681', '130', '15', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(454, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585220100', 'DEMLEME HAZNESI MEKANIZMA BRAKETI - ÇAY MAKİNESİ', 'ADET', '5740', '160', '22', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(455, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585250100', 'DEMLEME HAZNESİ DIŞ GÖVDE  - ARÇELİK ÇAY MAKİNESİ', 'ADET', '495', '420', '308,2', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(456, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585260100', 'DEMLEME HAZNESİ İÇ GÖVDE', 'ADET', '1849', '420', '286', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(457, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585290100', 'DEMLEME HAZNESI MEKANIZMA KAMI - ÇAY MAKİNESİ', 'ADET', '6320', '160', '3', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(458, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585340100', 'DEMLEME HAZNESI UST KAPAK - ÇAY MAKİNESİ', 'ADET', '1042', '200', '72,75', '56', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(459, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585410100', 'DEMLEME HAZNESI ALT KAPAK - ARÇELİK ÇAY MAKİNESİ', 'ADET', '5768', '200', '40,8', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(460, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585420100', 'KAPAK MENTESESI - ARÇELİK ÇAY MAKİNESİ', 'ADET', '1378', '160', '14', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(461, 'YM', 'Yarımamül', 'ARÇELK TKM', '3585480100', 'KARAF SERIT BAGLANTI BRAKETI- ARÇELİK ÇAY MAKİNESİ', 'ADET', '14480', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(462, 'MM', 'Yarımamül', 'ARÇELK TKM', '3586170100', 'GOVDE UST KAPAK  - SERİGRAFİ', 'ADET', '405', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(463, 'YM', 'Yarımamül', 'ARÇELK TKM', '3586410100', 'ALTUS TKM SUS SİSTEMİ PLASTİK - TKM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(464, 'YM', 'Yarımamül', 'ARÇELK TKM', '3586420100', 'ALTUS TKM SU TAHLİYE BORUSU  PLASTİK - TKM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(465, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587090100', 'ALT KAPAK - PROYO', 'ADET', '222', '420', '207', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(466, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587150100', 'DEKORATIF ALT GOVDE - PROYO', 'ADET', '339', '420', '193', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(467, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587160100', 'TASIYICI GOVDE UST SİYAH GRUPSUZ - PROYO', 'ADET', '596', '450', '413,5', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(468, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587160200', 'TASIYICI GOVDE UST BEYAZ - PROYO', 'ADET', '646', '420', '442', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(469, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587400100', 'DEKORATIF CERCEVE - PROYO', 'ADET', '160', '200', '39,1', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(470, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587440100', 'ORTAM AYDINLATMA BAGLANTI BRAKETI - PROYO', 'ADET', '1128', '80', '12,5', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(471, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587450100', 'ORTAM AYDINLATMA ISIK TASIYICI - PROYO', 'ADET', '1536', '130', '1,7', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(472, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587460100', 'ORTAM AYDINLATMA ISIK DAGITICI - PROYO', 'ADET', '1176', '130', '3,8', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(473, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587510100', 'POGO PIN CONTASI - PROYO', 'ADET', '2823', '80', '0,7', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(474, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587540100', 'DEKORATIF ARKA KAPAK - PROYO', 'ADET', '', '300', '80,5', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(475, 'YM', 'Yarımamül', 'ARÇELK TKM', '3587950100', 'UDAQ KAPAGI - PROYO', 'ADET', '', '80', '16,6', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(476, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588370100', 'BASE GÖVDE BEYAZ -  PROYO', 'ADET', '', '420', '440', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(477, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588370200', 'BASE GÖVDE SİYAH -  PROYO', 'ADET', '244', '420', '440', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(478, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560100', 'BASIC GÖVDE SERIGRAFILI ARCELIK -  PROYO', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(479, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560200', 'BASIC GÖVDE SERIGRAFILI BEKO -  PROYO', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(480, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560300', 'BASIC GÖVDE SERIGRAFILI GRUNDİG -  PROYO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(481, 'YM', 'Yarımamül', 'ARÇELK TKM', '3588560400', 'BASIC GÖVDE SERIGRAFILI GRUNDİG SİYAH -  PROYO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(482, 'YM', 'Yarımamül', 'ARÇELK TKM', 'Y-XXXX', 'STOK YERI TAKIP DENEME', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(483, 'MM', 'Mamül', 'BSH', '8001229619', 'INSTALLATION KIT FDBM/BM TH SbS2.0', 'ADET', '225', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(484, 'MM', 'Mamül', 'BSH', '8001229621', 'INSTALLATION KIT FDBM/BM TH PACS SbS2.0', 'ADET', '265', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(485, 'MM', 'Mamül', 'BSH', '8001229631', 'INSTALLATION KIT FDBM/BM GG SbS2.0', 'ADET', '17', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(486, 'MM', 'Mamül', 'BSH', '8001229640', 'TRIM KIT FDBM48 TH SbS2.0', 'ADET', '40', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(487, 'MM', 'Mamül', 'BSH', '8001229641', 'TRIM KIT FDBM42 TH SbS2.0', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(488, 'MM', 'Mamül', 'BSH', '8001229642', 'TRIM KIT FDBM36 TH SbS2.0', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(489, 'MM', 'Mamül', 'BSH', '8001229644', 'TRIM KIT FDBM36 GG SbS2.0', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(490, 'MM', 'Mamül', 'BSH', '8001229645', 'TRIM KIT BM36 TH SbS2.0', 'ADET', '4', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(491, 'MM', 'Mamül', 'BSH', '8001229646', 'TRIM KIT BM36 GG SbS2.0', 'ADET', '6', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(492, 'MM', 'Mamül', 'BSH', '8001229647', 'TRIM KIT BM30 GG SbS2.0', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(493, 'MM', 'Mamül', 'BSH', '8001230770', 'TRIM KIT FDBM48 TH PACS SbS2.0', 'ADET', '1', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(494, 'MM', 'Mamül', 'BSH', '8001230771', 'TRIM KIT FDBM42 TH PACS SbS2.0', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(495, 'MM', 'Mamül', 'BSH', '8001230772', 'TRIM KIT FDBM/BM 36 TH PACS SbS2.0', 'ADET', '12', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(496, 'MM', 'Mamül', 'BSH', '8001251203', 'DOOR DIRECTION CHANGE KIT TH SbS2.0', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(497, 'MM', 'Mamül', 'BSH', '8001251214', 'DOOR DIRECTION CHANGE KIT GG BM36 SbS2.0', 'ADET', '5', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(498, 'MM', 'Mamül', 'BSH', '8001251218', 'DOOR DIRECTION CHANGE KIT GG BM30 SbS2.0', 'ADET', '5', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(499, 'MM', 'Mamül', 'GOLDMASTER', '40012', 'MEDİSANA HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(500, 'MM', 'Mamül', 'GOLDMASTER', '40014', 'MEDİSANA HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(501, 'MM', 'Mamül', 'GOLDMASTER', '9Y72570004', 'GM7257 PLANET ANA GÖVDE', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(502, 'MM', 'Mamül', 'GOLDMASTER', 'AV-1006', 'AVCI HOME MAKER RONDOMA  DOĞRAYICI+ İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(503, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4303', 'COLOMBIA FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(504, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4305', 'TAZEM FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(505, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4310', 'BLISS FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(506, 'MM', 'Mamül', 'GOLDMASTER', 'BY-4500', 'SWEEP ELEKTRİKLİ SÜPÜRGE- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(507, 'MM', 'Mamül', 'GOLDMASTER', 'BY-5312', 'MAESTRO SİYAH-MOR  FİLTRE KAHVE MAKİNESİ  +İŞÇİLİK', 'ADET', '31', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(508, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7236', 'GM-7236 NARİN NARENCİYE SIKACAĞI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(509, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7257', 'PLANET RONDO MAKİNASI + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(510, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7276', 'GM-7236 PROFRESH NARENCİYE SIKACAĞI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(511, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7277', 'PROCHOPPER RONDO MAKİNASI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(512, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7297', 'CHOPPERIX RONDO MAKİNASI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(513, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7331', 'ZİNDE FİLTRE KAHVE MAKİNESİ GM-7331 + İŞÇİLİK', 'ADET', '1', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(514, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7331K', 'ZİNDE FİLTRE KAHVE MAKİNESİ KIRMIZI KUPA + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(515, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7332', 'ALTIN TELVE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '2', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(516, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7347', 'PERFECTTO FİLTRE KAHVE MAKİNESİ  +  İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(517, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7348', 'ÖMRÜM  FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(518, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7349', 'DROPS FİLTRE KAHVE MAKİNESİ GOLDMASTER +(İŞÇİLİK)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(519, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7351', 'TUTKU FİLTRE KAHVE MAKİNESİ GM7351 - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(520, 'MM', 'Mamül', 'GOLDMASTER', 'GM7363', 'BEGONVİL SU ISITICISI - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(521, 'MM', 'Mamül', 'GOLDMASTER', 'GM7364', 'LALEDEM ÇAY MAKİNASI - GOLDMASTER', 'ADET', '8', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(522, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7365', 'GEZGİN FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(523, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7365G', 'GEZGİN GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(524, 'MM', 'Mamül', 'GOLDMASTER', 'GM7520', 'NAZAR DİK SÜPÜRGE GM7520 - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(525, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7535', 'YILDIZ ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(526, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7553B', 'GM-7553B PİCKY BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(527, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7553S', 'GM-7553S PİCKY SİYAH - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(528, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7554B', 'GM-7554B AUTOMAX BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(529, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7554S', 'GM-7554S AUTOMAX SİYAH- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(530, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7555', 'PROGREEN ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(531, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7558', 'SÜPER GÜÇ ELEKTRİKLİ SÜPÜRGE - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(532, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7912B', 'NEMO SİYAH - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(533, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7912W', 'NEMO BEYAZ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(534, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7913', 'AİR THERAPY BEYAZ - GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(535, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7934', 'MİSTİK HAVA NEMLENDİRİCİ- GOLDMASTER', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(536, 'MM', 'Mamül', 'GOLDMASTER', 'GM-7936', 'SERİN VANTİLATÖR  İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(537, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6108', 'TRENDCOFFEE FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(538, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6300', 'COFFEE SMART FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(539, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6303', 'KEYF-İ KAHVE  FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(540, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6304', 'Bİ KAHVE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(541, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6305', 'COFFEE CHEF FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(542, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6310', 'MAGİC COFFEE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(543, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6314', 'COFFE CLASSİCO FİLTRE KAHVE MAKİNESİ +İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(544, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6320', 'FLORA FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(545, 'MM', 'Mamül', 'GOLDMASTER', 'IN-6330', 'KARNAVAL FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, '');
INSERT INTO `malzemeler` (`malzeme_id`, `malzeme_tür`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_logo`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`, `malzeme_tur`) VALUES
(546, 'MM', 'Mamül', 'GOLDMASTER', 'MC-100', 'LIKE MY COFFEE FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(547, 'MM', 'Mamül', 'GOLDMASTER', 'MC-102', 'RELAX GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(548, 'MM', 'Mamül', 'GOLDMASTER', 'PB-3231', 'PROBELLO FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(549, 'MM', 'Mamül', 'GOLDMASTER', 'PC-3202', 'PROCOFFEE FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(550, 'MM', 'Mamül', 'GOLDMASTER', 'QC-039', 'PRESTON FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(551, 'MM', 'Mamül', 'GOLDMASTER', 'QC-039G', 'PRESTON GOLD FİLTRE KAHVE MAKİNESİ  + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(552, 'MM', 'Mamül', 'GOLDMASTER', 'QVC-25C', 'CARBON ELEKTRİKLİ SÜPÜRGE - QUEEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(553, 'MM', 'Mamül', 'GOLDMASTER', 'QVC-25N', 'NORTHERN ELEKTRİKLİ SÜPÜRGE - QUEEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(554, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7312', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ ST-7312 + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(555, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7314', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ ST-7314 + İŞÇİLİK', 'ADET', '8', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(556, 'MM', 'Mamül', 'GOLDMASTER', 'ST-7334', 'GOLDSTAR FİLTRE KAHVE MAKİNESİ GEZGİN + İŞÇİLİK', 'ADET', '3', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(557, 'MM', 'Mamül', 'GOLDMASTER', 'T5TERMOTTI', 'NİCE TERMOTTİ FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(558, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM001G', 'TANTİTONİ GOLD FİLTRE KAHVE MAKİNESİ + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(559, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM001K', 'TANTİTONİ KIRMIZI FİLTRE KAHVE MAKİNESİ+İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(560, 'MM', 'Mamül', 'GOLDMASTER', 'TTCM002', 'TANTİTONİ KEYİF INOX FİLTRE KAHVE MAKİNESİ + İŞÇİL', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(561, 'MM', 'Mamül', 'GOLDMASTER', 'TT-CR15IN', 'TANTİTONİ DOĞRAYICI + İŞÇİLİK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(562, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300007', 'MOTOR ALT KAPAĞI - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(563, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300029', 'MOTOR YUVASI - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(564, 'MM', 'Mamül', 'GOLDMASTER', 'Y75300056', 'MOTOR KAFESİ - SAFİR-ZEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(565, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310003', 'GÖVDE - ZİNDE KAHVE MAKİNASI', 'ADET', '590', '200', '128', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(566, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310003-B', 'GÖVDE BEYAZ - ZİNDE KAHVE MAKİNASI', 'ADET', '147', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(567, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310004', 'SU TANKI ARKA KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '1160', '200', '162', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(568, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310009', 'ALT KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '3791', '130', '55', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(569, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310010', 'ÜST KAPAK - ZİNDE KAHVE MAKİNASI', 'ADET', '2310', '130', '40,5', '48', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(570, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310015', 'DÜGME ÇERÇEVESİ - ZİNDE KAHVE MAKİNASI', 'ADET', '157', '130', '1', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(571, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310022', 'VİDA KAPAĞI - ZİNDE KAHVE MAKİNASI', 'ADET', '53968', '130', '1', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(572, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310028-1', 'REZİSTANS KOMPLE GRUPLAMA - ZİNDE KAHVE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(573, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310036', 'KABLO SABİTLEYİCİ 1 USA - ZİNDE KAHVE MAKİNASI', 'ADET', '124', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(574, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73310037', 'KABLO SABİTLEYİCİ 2 VDE - ZİNDE KAHVE MAKİNASI', 'ADET', '2413', '130', '1', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(575, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470015', 'FİLTRE - TUTKU KAHVE MAKİNASI', 'ADET', '5220', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(576, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470022', 'BARDAK ALT KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2357', '160', '18,5', '36', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(577, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470023', 'BARDAK ÜST KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2797', '160', '8', '36', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(578, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470025', 'BUTON ÇERÇEVESİ - TUTKU KAHVE MAKİNASI', 'ADET', '2757', '130', '1', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(579, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470026', 'BARDAK GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '2128', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(580, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470027', 'DAMITMA SU BORUSU - TUTKU KAHVE MAKİNASI', 'ADET', '2748', '130', '3', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(581, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470028', 'BUTON BASKISIZ - TUTKU KAHVE MAKİNASI', 'ADET', '165', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(582, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470030', 'ALT GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '2142', '300', '165', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(583, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470031', 'METAL YÜKSELTME PLASTİĞİ - TUTKU KAHVE MAKİNASI', 'ADET', '5547', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(584, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470032', 'ŞALTER KAPAMA PLASTİĞİ - TUTKU KAHVE MAKİNASI', 'ADET', '1065', '130', '1', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(585, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470033', 'VALF - TUTKU KAHVE MAKİNASI', 'ADET', '5540', '130', '1', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(586, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470034', 'DAMITMA BORUSU ÜST - TUTKU KAHVE MAKİNASI', 'ADET', '1016', '130', '5', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(587, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470035', 'DAMITMA BORUSU ALT - TUTKU KAHVE MAKİNASI', 'ADET', '1265', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(588, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470036', 'TERMOSTAT KAPAĞI - TUTKU KAHVE MAKİNASI', 'ADET', '2018', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(589, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470037', 'BARDAK ÜST KAPAK SÜRGÜSÜ - TUTKU KAHVE MAKİNASI', 'ADET', '7049', '130', '6', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(590, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470038', 'ÜST GÖVDE - TUTKU KAHVE MAKİNASI', 'ADET', '1577', '300', '135', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(591, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470039', 'ALT KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '4346', '200', '39', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(592, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470040', 'ÜST KAPAK - TUTKU KAHVE MAKİNASI', 'ADET', '2800', '200', '39', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(593, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73470044', 'FİLTRE YUVASI - TUTKU KAHVE MAKİNASI', 'ADET', '4572', '200', '24', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(594, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570007', 'GM7357 SU SEVİYE GÖSTERGESİ', 'ADET', '560', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(595, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570043', 'GM7357 SU TANKI  - HAZZ', 'ADET', '66', '420', '265', '80', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(596, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570044', 'GM7357 ANA GÖVDE  - HAZZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(597, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570045', 'GM7357 ÜST KAPAK  - HAZZ', 'ADET', '188', '300', '74', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(598, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570046', 'GM7357 ALT KAPAK - HAZZ', 'ADET', '150', '300', '74', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(599, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y73570047', 'GM7357 FİLTRE YUVASI DESTEK PARÇASI - HAZZ', 'ADET', '', '200', '116', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(600, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200038', 'GM7520 SOL GÖVDE - NAZAR DİK SÜPÜRGE', 'ADET', '150', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(601, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200039', 'GM7520 SAĞ GÖVDE - NAZAR DİK SÜPÜRGE', 'ADET', '108', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(602, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75200043', 'GM7520 TOZ DEPOSU - NAZAR DİK SÜPÜRGE', 'ADET', '851', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(603, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350005', 'SAĞ GÖVDE KAPAĞI - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(604, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350006', 'SOL GÖVDE KAPAĞI - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(605, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350048', 'ÜST GÖVDE  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(606, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350049', 'ALT GÖVDE  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(607, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350062', 'MOTOR KORUMA KAFESİ  - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(608, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350069', 'TOZ HAZNESİ - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(609, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75350070', 'TOZ HAZNE ÜST KAPAK - YILDIZ SÜPÜRGE MAKİNASI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(610, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7535Y048', 'GM7535 ÜST GÖVDE YEŞİL - PROGREEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(611, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7535Y049', 'GM7535 ALT GÖVDE YEŞİL - PROGREEN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(612, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y75530024', 'TOZ HAZNE - ŞARJLI SÜPÜRGE', 'ADET', '302', '200', '153', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(613, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553B020', 'SOL GÖVDE BEYAZ - ŞARJLI  SÜPÜRGE', 'ADET', '373', '200', '108', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(614, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553B021', 'SAĞ GÖVDE BEYAZ - ŞARJLI  SÜPÜRGE', 'ADET', '491', '200', '108', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(615, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553S020', 'SOL GÖVDE SİYAH - ŞARJLI  SÜPÜRGE', 'ADET', '597', '200', '108', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(616, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y7553S021', 'SAĞ GÖVDE SİYAH - ŞARJLI  SÜPÜRGE', 'ADET', '457', '200', '108', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(617, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100011', 'HAVA NEM.SU GİRİŞ KAPAĞI - MİSTO', 'ADET', '4935', '200', '12', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(618, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100012', 'HAVA NEM.SU TANKI ÜST GÖVDE - MİSTO', 'ADET', '827', '420', '376', '90', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(619, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100013', 'HAVA NEM.GÖVDE ALT KAPAK - MİSTO', 'ADET', '2874', '200', '74', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(620, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100014', 'HAVA NEM.GÖVDE - MİSTO', 'ADET', '644', '420', '198', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(621, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100015', 'SU TANK ALT KAPAK - MİSTO', 'ADET', '2693', '200', '96', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(622, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100016', 'CONTA ÇUBUĞU - MİSTO', 'ADET', '2423', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(623, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100017', 'ŞAMANDIRA TUTUCU - MİSTO', 'ADET', '2317', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(624, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100018', 'ANAHTAR SABİTLEYİCİ - MİSTO', 'ADET', '2020', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(625, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100019', 'BUHAR KAPAĞI ÜST - MİSTO', 'ADET', '2214', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(626, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100020', 'BUHAR KAPAĞI ALT - MİSTO', 'ADET', '3503', '200', '5', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(627, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100021', 'HAVA NEM.BUHAR ELEĞİ FİLE - MİSTO', 'ADET', '5548', '130', '3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(628, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100022', 'HAVA NEM.LED KAPAK - MİSTO', 'ADET', '3438', '130', '3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(629, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100031', 'HAVA NEM.GÜÇ GÖSTERGE PLASTİĞİ - MİSTO', 'ADET', '4408', '130', '3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(630, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y78100032', 'HAVA NEM.SU SEVİYE GÖSTERGE PLS. - MİSTO', 'ADET', '3382', '130', '3', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(631, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120021', 'GM7912 SU GİRİŞ KAPAĞI - NEMO', 'ADET', '5122', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(632, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120023', 'GM7912 SU TANK ALT GÖVDE SİYAH - NEMO', 'ADET', '5208', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(633, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120024', 'GM7912 ANA GÖVDE SİYAH - NEMO', 'ADET', '3926', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(634, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120025', 'GM7912 ANA GÖVDE ALT KAPAK SİYAH - NEMO', 'ADET', '4271', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(635, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120026', 'GM7912 CONTA PİMİ SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(636, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120027', 'GM7912 ŞAMANDIRA TUTUCU SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(637, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120029', 'GM7912 BUHAR SEPERATÖRÜ ÖN SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(638, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120030', 'GM7912 BUHAR SEPERATÖRÜ ARKA SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(639, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120031', 'GM7912 TANK SAPI SİYAH - NEMO', 'ADET', '24', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(640, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120032', 'GM7912 MANYETİK ANAHTAR SABİTLEYİCİ - NEMO', 'ADET', '70', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(641, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120033', 'GM7912 LED KAPAK BÜYÜK ŞEFFAF - NEMO', 'ADET', '7961', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(642, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120034', 'GM7912 LED KAPAK KÜÇÜK ŞEFFAF - NEMO', 'ADET', '7947', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(643, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120046', 'GM7912 GÜÇ AYAR DÜĞME YUVASI SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(644, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120047', 'GM7912 DÜĞME SİYAH - NEMO', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(645, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120049', 'GM7912 KABLO TUTUCU SİYAH - NEMO', 'ADET', '70', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(646, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120050', 'GM7912 AIRMIST SU TANKI ÜST GÖVDE - NEMO', 'ADET', '1208', '420', '382', '100', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(647, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120108', 'GM7912 LED KAPAK BÜYÜK ŞEFFAF PLASTİK AKSAM HM.', 'ADET', '60', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(648, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79120109', 'GM7912 LED KAPAK KÜÇÜK ŞEFFAF PLASTİK AKSAM HM.', 'ADET', '60', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(649, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130021', 'GM7913 SU GİRİŞ KAPAĞI BEYAZ - NEMO', 'ADET', '2319', '130', '18', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(650, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130022', 'GM7913 SU TANKI(NEC) - NEMO', 'ADET', '511', '420', '345', '100', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(651, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130023', 'GM7913 SU TANK TABAN BEYAZ - NEMO', 'ADET', '1361', '200', '92', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(652, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130024', 'GM7912 ANA GÖVDE BEYAZ - NEMO', 'ADET', '1441', '200', '222', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(653, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130025', 'GM7913 ANA GÖVDE TABAN BEYAZ - NEMO', 'ADET', '4467', '200', '70', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(654, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130026', 'GM7913 CONTA ÇUBUĞU BEYAZ - NEMO', 'ADET', '1932', '80', '1', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(655, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130027', 'GM7913 ŞAMANDIRA TUTUCU BEYAZ  - NEMO', 'ADET', '1822', '80', '1,2', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(656, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130029', 'GM7913 BUHAR SEPERATÖRÜ ÖN BEYAZ - NEMO', 'ADET', '208', '80', '6', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(657, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130030', 'GM7913 BUHAR SEPERATÖRÜ ARKA BEYAZ - NEMO', 'ADET', '', '80', '12', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(658, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130031', 'GM7913 TANK SAPI BEYAZ - NEMO', 'ADET', '1787', '80', '3', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(659, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130032', 'GM7913 LED SABİTLEYİCİ BEYAZ - NEMO', 'ADET', '1947', '80', '2', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(660, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130046', 'GM7913 GÜÇ AYAR DÜĞME YUVASI BEYAZ - NEMO', 'ADET', '', '130', '10', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(661, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130047', 'GM7913 DÜĞME BEYAZ - NEMO', 'ADET', '10', '80', '3,8', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(662, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130049', 'GM7913 KABLO TUTUCU BEYAZ - NEMO', 'ADET', '2047', '80', '2', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(663, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130100', 'GM7913 SU TANKI (NEC) PLASTİK AKSAM HM.', 'ADET', '120', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(664, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130101', 'GM7913 SU GİRİŞ KAPAĞI BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(665, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130102', 'GM7913 SU TANK TABAN BEYAZ PLASTİK AKSAM HM.', 'ADET', '17', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(666, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130103', 'GM7913 ANA GÖVDE BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(667, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130104', 'GM7913 ANA GÖVDE TABAN BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(668, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130105', 'GM7913 CONTA ÇUBUĞU BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(669, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130106', 'GM7913 ŞAMANDIRA TUTUCU BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(670, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130107', 'GM7913 TANK SAPI BEYAZ BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(671, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130108', 'GM7913 LED SABİTLEYİCİ BEYAZ PLASTİK AKSAM HM', 'ADET', '17', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(672, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130109', 'GM7913 KABLO TUTUCU BEYAZ PLASTİK AKSAM HM.', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(673, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130110', 'GM7913 BUHAR SEPERATÖRÜ ÖN BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(674, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130111', 'GM7913 BUHAR SEP.  ARKA BEYAZ PLASTİK AKSAM HM.', 'ADET', '17', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(675, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130112', 'GM7913 GÜÇ AYAR DÜĞME YUVASI BYZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(676, 'YM', 'Yarımamül', 'GOLDMASTER', 'Y79130113', 'GM7913 DÜĞME BEYAZ PLASTİK AKSAM HM.', 'ADET', '27', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(677, 'MM', 'Mamül', 'HASEL', 'MML0451', 'ALT ÇITA PLASTİK KAPAK - HASEL', 'ADET', '', '160', '10,25', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(678, 'MM', 'Mamül', 'HASEL', 'MML0486', 'HIZ AYARLAYICI DİŞLİ KAPAK - HASEL', 'ADET', '20', '130', '4', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(679, 'MM', 'Mamül', 'HASEL', 'MML0487', 'HIZ AYARLAYICI PUL - HASEL', 'ADET', '4', '130', '1', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(680, 'MM', 'Mamül', 'HASEL', 'MML0488', 'HIZ AYARLAYICI BAĞLANTI PARÇASI - HASEL', 'ADET', '20', '130', '7', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(681, 'MM', 'Mamül', 'HASEL', 'MML0489', 'HIZ AYARLAYICI MEKANİZMA GÖVDESİ - HASEL', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(682, 'MM', 'Mamül', 'HASEL', 'MML0490', 'HIZ AYARLAYICI PALET - HASEL', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(683, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0001', 'TABLDOT ABS', 'ADET', '6614', '200', '320', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(684, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '200', NULL, NULL, NULL, NULL, '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', 'ATAKAN CESUR', '2025-02-12 17:36:37', ''),
(685, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0004', 'TABLDOT ABS GRİ', 'ADET', '1600', '200', '320', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(686, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0005', 'TABLDOT PC - RENKLİ', 'ADET', '', '200', '330', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(687, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0006', 'TABLDOT ABS - KAHVERENGİ', 'ADET', '', '200', '320', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(688, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0007', 'TABLDOT PC - BEYAZ', 'ADET', '120', '200', '330', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(689, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0008', 'TABLDOT V0 - BEYAZ', 'ADET', '23,5', '200', '340', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(690, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0010', 'TABLDOT KÜÇÜK BOY BEYAZ', 'ADET', '43', '200', '240', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(691, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0011', 'TABLDOT KÜÇÜK BOY GRİ', 'ADET', '', '200', '240', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(692, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0012', 'TABLDOT KÜÇÜK BOY KIRMIZI', 'ADET', '', '200', '240', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(693, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0020', 'ÇAY TEPSİ FANUS KAPAK', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(694, 'MM', 'Mamül', 'İDEAL END.', 'İDL-0021', 'BÜYÜK TEPSİ SİYAH ABS', 'ADET', '2240', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(695, 'MM', 'Mamül', 'İDEAL END.', 'İDL-HB-001', 'HUBUBAT SİYAH', 'ADET', '120', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(696, 'MM', 'Mamül', 'İDEAL END.', 'İDL-HB-002', 'HUBUBAT BEYAZ', 'ADET', '300', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(697, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-01', 'HUBUBAT ALT GÖVDE SİYAH', 'ADET', '283', '160', '240', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(698, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-02', 'HUBUBAT ÜST KAPAK SİYAH', 'ADET', '271', '200', '66', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(699, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-03', 'HUBUBAT AKSESUAR SİYAH', 'ADET', '730', '200', '3', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(700, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-04', 'HUBUBAT BUTON SİYAH', 'ADET', '245', '130', '25', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(701, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-05', 'HUBUBAT ÇEKMECE', 'ADET', '', '200', '95', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(702, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-001-06', 'HUBUBAT ÜST GÖVDE', 'ADET', '284', '200', '245', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(703, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-01', 'HUBUBAT ALT GÖVDE BEYAZ', 'ADET', '200', '160', '240', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(704, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-02', 'HUBUBAT ÜST KAPAK BEYAZ', 'ADET', '', '200', '66', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(705, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-03', 'HUBUBAT AKSESUAR BEYAZ', 'ADET', '220', '200', '3', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(706, 'YM', 'Yarımamül', 'İDEAL END.', 'İDL-HB-002-04', 'HUBUBAT BUTON BEYAZ', 'ADET', '75', '130', '25', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(707, 'MM', 'Mamül', 'POLİZA', 'P.İ-101', 'PERDE KOLON PASPAYI_15 MM', 'ADET', '12770', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(708, 'MM', 'Mamül', 'POLİZA', 'P.İ-102', 'PERDE KOLON PASPAYI_20 MM', 'ADET', '7170', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(709, 'MM', 'Mamül', 'POLİZA', 'P.İ-103', 'PERDE KOLON PASPAYI_25 MM', 'ADET', '34750', '130', '7,4', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(710, 'MM', 'Mamül', 'POLİZA', 'P.İ-104', 'PERDE KOLON PASPAYI_30 MM', 'ADET', '2255', '130', '11', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(711, 'MM', 'Mamül', 'POLİZA', 'P.İ-105', 'PERDE KOLON PASPAYI_40 MM', 'ADET', '1400', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(712, 'MM', 'Mamül', 'POLİZA', 'P.İ-106', 'PERDE KOLON PASPAYI_50 MM', 'ADET', '550', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(713, 'MM', 'Mamül', 'POLİZA', 'P.İ-204', 'MANDAL PASPAYI 15 MM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(714, 'MM', 'Mamül', 'POLİZA', 'P.İ-207', 'MANDAL PASPAYI 30 MM', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(715, 'MM', 'Mamül', 'POLİZA', 'P.İ-308', 'NORM AĞIR TİP DÖŞEME PASPAYI_20 MM', 'ADET', '3220', '130', '9', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(716, 'MM', 'Mamül', 'POLİZA', 'P.İ-309', 'NORM AĞIR TİP DÖŞEME PASPAYI_25 MM', 'ADET', '43534', '130', '12', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(717, 'MM', 'Mamül', 'POLİZA', 'P.İ-312', 'NORM AĞIR TİP DÖŞEME PASPAYI_50 MM', 'ADET', '7895', '130', '20', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(718, 'MM', 'Mamül', 'POLİZA', 'P.İ-414', 'RAY TİPİ HASIR DÖŞEME PASPAYI 20 MM', 'ADET', '6323', '130', '16', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(719, 'MM', 'Mamül', 'POLİZA', 'P.İ-415', 'RAY TİPİ HASIR DÖŞEME PASPAYI 25 MM', 'ADET', '3890', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(720, 'MM', 'Mamül', 'POLİZA', 'P.İ-515', 'ÇEMBER TİPİ DÖŞEME PASPAYI 15 MM', 'ADET', '1200', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(721, 'MM', 'Mamül', 'POLİZA', 'P.İ-516', 'ÇEMBER TİPİ DÖŞEME PASPAYI 20 MM', 'ADET', '408', '130', '24', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(722, 'MM', 'Mamül', 'POLİZA', 'P.İ-720', 'TIE-ROT KORUYUCU BAŞLIK İÇ ÇAP 18', 'ADET', '1178', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(723, 'MM', 'Mamül', 'POLİZA', 'P.İ-722', 'TIE-ROT KORUYUCU BAŞLIK İÇ ÇAP 24', 'ADET', '5513', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(724, 'MM', 'Mamül', 'POVAG', '10.11.15.020.95.00', 'seperator 200 mm black', 'ADET', '424', '300', '37', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(725, 'MM', 'Mamül', 'POVAG', '10.11.15.025.95.00', 'seperator 250 mm black', 'ADET', '169', '300', '55', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(726, 'MM', 'Mamül', 'POVAG', '10.11.15.030.50.01', 'seperator 300 mm blue', 'ADET', '72', '300', '86', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(727, 'MM', 'Mamül', 'POVAG', '10.11.15.030.95.00', 'seperator 300 mm black', 'ADET', '32629', '300', '86', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(728, 'MM', 'Mamül', 'POVAG', '10.11.15.045.95.00', 'seperator 450 mm black', 'ADET', '812', '300', '146', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(729, 'MM', 'Mamül', 'POVAG', '10.70.41.004.95.00', 'Insert bin 4 compartments', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(730, 'MM', 'Mamül', 'POVAG', '10.70.41.006.95.00', 'Insert bin 6 compartments', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(731, 'MM', 'Mamül', 'POVAG', '10.70.41.008.95.00', 'Insert bin 8 compartments', 'ADET', '540', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(732, 'MM', 'Mamül', 'POVAG', '10.70.50.001.00.00', 'Kantelbak No.15 - transparent 150x115x110 mm', 'ADET', '299', '130', '175', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(733, 'MM', 'Mamül', 'POVAG', '10.70.50.002.00.00', 'Kantelbak No.7,5 - transparent 75x115x110 mm', 'ADET', '800', '80', '78', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(734, 'MM', 'Mamül', 'POVAG', '10.70.50.003.50.00', 'Kantelbak Unit - blue 160x115x110 mm', 'ADET', '', '160', '180', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(735, 'MM', 'Mamül', 'POVAG', '10.70.50.003.95.00', 'Kantelbak Unit - black 160x115x110 mm', 'ADET', '280', '160', '180', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(736, 'MM', 'Mamül', 'POVAG', '10.70.50.033.10.00', 'Bin nr. 33 - name plate Povag - yellow 92x320x92mm', 'ADET', '', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(737, 'MM', 'Mamül', 'POVAG', '10.70.50.033.30.00', 'Bin nr. 33 - name plate Povag - red 92x320x92 mm', 'ADET', '540', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(738, 'MM', 'Mamül', 'POVAG', '10.70.50.033.50.00', 'Bin nr. 33 - name plate Povag - blue 92x320x92 mm', 'ADET', '10075', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(739, 'MM', 'Mamül', 'POVAG', '10.70.50.033.50.01', 'Bin nr. 43 - name plate fabory - no etiket - blue', 'ADET', '1190', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(740, 'MM', 'Mamül', 'POVAG', '10.70.50.033.80.00', 'Bin nr. 33 - name plate Povag - green 92x320x92 mm', 'ADET', '327', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(741, 'MM', 'Mamül', 'POVAG', '10.70.50.033.95.00', 'Bin nr. 33 - name plate Povag - black 92x320x92 mm', 'ADET', '60', '160', '257', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(742, 'MM', 'Mamül', 'POVAG', '10.70.50.048.10.00', 'Bin nr. 48 - name plate Povag - yellow 115x320x92m', 'ADET', '', '160', '310', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(743, 'MM', 'Mamül', 'POVAG', '10.70.50.048.30.00', 'Bin nr. 48 - name plate Povag - red 115x320x92mm', 'ADET', '1104', '160', '310', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(744, 'MM', 'Mamül', 'POVAG', '10.70.50.048.50.00', 'Bin nr. 48 - name plate Povag - blue 115x320x92mm', 'ADET', '35', '160', '310', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(745, 'MM', 'Mamül', 'POVAG', '10.70.50.048.50.01', 'Bin nr. 58 - name plate fabory - no etiket - blue', 'ADET', '12', '160', '310', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(746, 'MM', 'Mamül', 'POVAG', '10.70.50.048.95.00', 'Bin nr. 48 - name plate Povag - black 115x320x92mm', 'ADET', '', '160', '310', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(747, 'MM', 'Mamül', 'POVAG', '10.70.50.052.10.00', 'Bin nr. 52 - name plate Povag - yellow 205x350x165', 'ADET', '208', '300', '643', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(748, 'MM', 'Mamül', 'POVAG', '10.70.50.052.30.00', 'Bin nr. 52 - name plate Povag - red  205x350x165', 'ADET', '', '300', '643', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(749, 'MM', 'Mamül', 'POVAG', '10.70.50.052.50.00', 'Bin nr. 52 - name plate Povag - blue   205x350x165', 'ADET', '160', '300', '643', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(750, 'MM', 'Mamül', 'POVAG', '10.70.50.052.95.00', 'Bin nr. 52 - name plate Povag - black 205x350x165', 'ADET', '', '300', '643', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(751, 'MM', 'Mamül', 'POVAG', '10.70.50.053.10.00', 'Bin nr. 53 - name plate Povag-yellow 150x240x130mm', 'ADET', '3072', '160', '300', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(752, 'MM', 'Mamül', 'POVAG', '10.70.50.053.30.00', 'Bin nr. 53 - name plate Povag - red 150x240x130mm', 'ADET', '1369', '160', '300', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(753, 'MM', 'Mamül', 'POVAG', '10.70.50.053.50.00', 'Bin nr. 53 - name plate Povag - blue 150x240x130mm', 'ADET', '1430', '160', '300', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(754, 'MM', 'Mamül', 'POVAG', '10.70.50.053.50.01', 'Bin nr. 83 - name plate fabory - no etiket - blue', 'ADET', '48', '160', '300', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(755, 'MM', 'Mamül', 'POVAG', '10.70.50.053.95.00', 'Bin nr. 53 - name plate Povag -black 150x240x130mm', 'ADET', '3264', '160', '300', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(756, 'MM', 'Mamül', 'POVAG', '10.70.50.054.10.00', 'Bin nr. 54 - name plate Povag -yellow 105x175x75mm', 'ADET', '1301', '80', '100', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(757, 'MM', 'Mamül', 'POVAG', '10.70.50.054.30.00', 'Bin nr. 54 - name plate Povag - red 105x175x75mm', 'ADET', '2576', '80', '100', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(758, 'MM', 'Mamül', 'POVAG', '10.70.50.054.50.00', 'Bin nr. 54 - name plate Povag - blue 105x175x75mm', 'ADET', '6174', '80', '100', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(759, 'MM', 'Mamül', 'POVAG', '10.70.50.054.95.00', 'Bin nr. 54 - name plate Povag - black 105x175x75mm', 'ADET', '5246', '80', '100', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(760, 'MM', 'Mamül', 'POVAG', '10.70.50.055.10.00', 'Bin nr. 55 - without name plate-yellow 105x90x50mm', 'ADET', '4680', '130', '40', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(761, 'MM', 'Mamül', 'POVAG', '10.70.50.055.30.00', 'Bin nr. 55 - without name plate-red 105x90x50mm', 'ADET', '', '130', '40', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(762, 'MM', 'Mamül', 'POVAG', '10.70.50.063.10.00', 'Bin nr. 63 - name plate Povag -yellow 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(763, 'MM', 'Mamül', 'POVAG', '10.70.50.063.30.00', 'Bin nr. 63 - name plate Povag - red 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(764, 'MM', 'Mamül', 'POVAG', '10.70.50.063.50.00', 'Bin nr. 63 - name plate Povag - blue 184x320x92mm', 'ADET', '4608', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(765, 'MM', 'Mamül', 'POVAG', '10.70.50.063.50.01', 'Bin nr. 93 - name plate fabory - blue 184x320x92mm', 'ADET', '34', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(766, 'MM', 'Mamül', 'POVAG', '10.70.50.063.80.00', 'Bin nr. 63 - name plate Povag - green 184x320x92mm', 'ADET', '', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(767, 'MM', 'Mamül', 'POVAG', '10.70.50.063.95.00', 'Bin nr. 63 - name plate Povag - black 184x320x92mm', 'ADET', '18', '300', '480', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(768, 'MM', 'Mamül', 'POVAG', '10.71.50.024.00.00', 'Width seperator bin 85 - transparent', 'ADET', '3600', '80', '14', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(769, 'MM', 'Mamül', 'POVAG', '10.71.50.025.00.00', 'Width seperator bin 33 - transparent', 'ADET', '750', '80', '14', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(770, 'MM', 'Mamül', 'POVAG', '10.71.50.027.00.00', 'Depth seperator bin 63 - transparent', 'ADET', '111', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(771, 'MM', 'Mamül', 'SARUHAN', '11000762', 'ARKA GÖVDE - HOBBY - KREM', 'ADET', '', '350', '623', '120', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(772, 'MM', 'Mamül', 'SARUHAN', '11003198', 'EMOTİON ALT GÖVDE SİYAH', 'ADET', '168', '500', '719', '76', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(773, 'MM', 'Mamül', 'SARUHAN', '11003199', 'EMOTİON ÖN KAPAK KIRMIZI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(774, 'MM', 'Mamül', 'SARUHAN', '11003200', 'EMOTİON ARKA KAPAK SİYAH', 'ADET', '2', '350', '430', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(775, 'MM', 'Mamül', 'SARUHAN', '11003203', 'EMOTİON HAVA ÇIKIŞ KAPAĞI GRİ', 'ADET', '', '160', '46,6', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(776, 'MM', 'Mamül', 'SARUHAN', '11003208', 'EMOTİON AKSESUAR KAPAĞI SİYAH', 'ADET', '126', '160', '66', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(777, 'MM', 'Mamül', 'SARUHAN', '11003212', 'EMOTİON ALT GÖVDE ÖN PLASTİK SİYAH', 'ADET', '', '80', '23', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(778, 'MM', 'Mamül', 'SARUHAN', '11003218', 'EMOTİON BÜYÜK TEKERLEK SİYAH', 'ADET', '290', '160', '53', '36', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(779, 'MM', 'Mamül', 'SARUHAN', '11003220', 'EMOTİON BÜYÜK TEKERLEK KAPAĞI GRİ', 'ADET', '', '80', '6,79', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(780, 'MM', 'Mamül', 'SARUHAN', '11003249', 'EMOTİON GÜÇ AYAR DÜĞMESİ', 'ADET', '', '130', '2,9', '25', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(781, 'MM', 'Mamül', 'SARUHAN', '11003549', 'KAHVE FİLTRESİ KAPAK - PCM - SARUHAN', 'ADET', '', '80', '85', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(782, 'MM', 'Mamül', 'SARUHAN', '11003552', 'KAHVE SU HAZNE KAPAK - KREM- PCM - SARUHAN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(783, 'MM', 'Mamül', 'SARUHAN', '11003554', 'KAHVE ÖN GÖVDE - KIRMIZI - PCM - SARUHAN', 'ADET', '2977', '300', '168', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(784, 'MM', 'Mamül', 'SARUHAN', '11003555', 'KAHVE ARKA GÖVDE - PCM - SARUHAN', 'ADET', '39', '300', '206', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(785, 'MM', 'Mamül', 'SARUHAN', '11003611', 'KAHVE SU HAZNE KAPAK - KIRMIZI - PCM - SARUHAN', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(786, 'MM', 'Mamül', 'SARUHAN', '11003930', 'TABAN PLASTİĞİ - SİYAH - TVL90S', 'ADET', '', '160', '130', '36', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(787, 'MM', 'Mamül', 'SARUHAN', '11003931', 'TABAN - K.BEYAZ - TVL90S  -   Serigrafi', 'ADET', '452', '200', '212', '43', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(788, 'MM', 'Mamül', 'SARUHAN', '11003933', 'HALKA - ALT-TABAN - K.BEYAZ - TVL90S', 'ADET', '', '160', '15,53', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(789, 'MM', 'Mamül', 'SARUHAN', '11003934', 'HALKA - ÜST BAGLANTI - K.BEYAZ - TVL90S', 'ADET', '', '160', '13,59', '38', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(790, 'MM', 'Mamül', 'SARUHAN', '11003938', 'ARKA GÖVDE - K.BEYAZ - TVL90S', 'ADET', '75', '500', '644', '73', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(791, 'MM', 'Mamül', 'SARUHAN', '11003941', 'MOTOR SAĞ GÖVDE - SİYAH - TVL90S', 'ADET', '', '500', '355', '73', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(792, 'MM', 'Mamül', 'SARUHAN', '11003942', 'MOTOR SOL GÖVDE - SİYAH - TVL90S', 'ADET', '', '500', '310', '73', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(793, 'MM', 'Mamül', 'SARUHAN', '11003944', 'YÖNLENDİRİCİ BRAKET - SİYAH - TVL90S', 'ADET', '700', '160', '4', '48', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(794, 'MM', 'Mamül', 'SARUHAN', '11003945', 'PANJUR - SİYAH - TVL90S', 'ADET', '', '160', '5', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(795, 'MM', 'Mamül', 'SARUHAN', '11003946', 'ÖN GÖVDE - K.BEYAZ - TVL90S - Serigrafi', 'ADET', '', '420', '362', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(796, 'MM', 'Mamül', 'SARUHAN', '11003948', 'ALICI CAMI - ŞEFFAF AÇIK SİYAH - TVL90S', 'ADET', '', '80', '2', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(797, 'MM', 'Mamül', 'SARUHAN', '11003949', 'UZAKTAN KUMANDA TUTUCU - K.BEYAZ -TVL90S', 'ADET', '25', '80', '10', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(798, 'MM', 'Mamül', 'SARUHAN', '21002297', 'TVL 90 S - TABAN MONTAJI', 'ADET', '338', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(799, 'MM', 'Mamül', 'SARUHAN', '41004767', 'EMOTİON ÖN KAPAK - SİYAH', 'ADET', '83', '350', '338', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(800, 'YM', 'Yarımamül', 'SARUHAN', '11003209', 'EMOTİON TUTAMAK ÜST KIRMIZI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(801, 'YM', 'Yarımamül', 'SARUHAN', '11003210', 'EMOTİON TUTAMAK ALT KIRMIZI', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(802, 'YM', 'Yarımamül', 'SARUHAN', '11003216', 'EMOTİON MANDAL ÖN KAPAK GRI', 'ADET', '', '130', '20', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(803, 'YM', 'Yarımamül', 'SARUHAN', '11003247', 'EMOTİON KABLO SARICI TUŞ GRİ', 'ADET', '', '130', '24', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(804, 'YM', 'Yarımamül', 'SARUHAN', '11003248', 'EMOTİON ON/OFF TUŞ GRİ', 'ADET', '', '130', '24', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(805, 'YM', 'Yarımamül', 'SARUHAN', '41004768', 'EMOTİON TUTAMAK ÜST - SİYAH', 'ADET', '148', '300', '69,06', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(806, 'YM', 'Yarımamül', 'SARUHAN', '41004769', 'EMOTİON TUTAMAK ALT - SİYAH', 'ADET', '148', '300', '37,94', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(807, 'MM', 'Mamül', 'ÜNAL KABLO', '250/80/135', 'ÜNAL KABLO PLASTİK MAKARA', 'ADET', '3825', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(808, 'MM', 'Mamül', 'VATAN', 'VPK-05', 'BAZA ALT KAPAK', 'ADET', '5', '500', '915', '83', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(809, 'MM', 'Mamül', 'VATAN', 'VPK-06', 'BAZA ÜST KAPAK', 'ADET', '64', '500', '300', '52', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, '');
INSERT INTO `malzemeler` (`malzeme_id`, `malzeme_tür`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_logo`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`, `malzeme_tur`) VALUES
(810, 'MM', 'Mamül', 'VATAN', 'VPK-12', 'ARMOR GÖVDE', 'ADET', '', '200', '35', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(811, 'MM', 'Mamül', 'VATAN', 'VPK-14', 'YATIŞ ÇEKME KOLU', 'ADET', '1', '160', '77', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(812, 'MM', 'Mamül', 'VATAN', 'VPK-15', '5 NOKTA EMNİYET KAPAK', 'ADET', '', '130', '26,7', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(813, 'MM', 'Mamül', 'VATAN', 'VPK-17', 'YATIŞ ÇEKME KOLU MAFSALI', 'ADET', '', '130', '47,6', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(814, 'MM', 'Mamül', 'VATAN', 'VPK-2', 'BOYUNLUK GÖVDE', 'ADET', '13', '700', '820', '90', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(815, 'MM', 'Mamül', 'VATAN', 'VPK-20', 'HOPERLÖR TUTUCU - VATAN', 'ADET', '', '130', '4,5', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(816, 'MM', 'Mamül', 'VATAN', 'VPK-23', 'EMNİYET KEMER TUTUCU KAPAK', 'ADET', '', '160', '8,1', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(817, 'MM', 'Mamül', 'VATAN', 'VPK-28', 'KEMER TUTUCU', 'ADET', '', '160', '7,5', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(818, 'MM', 'Mamül', 'VATAN', 'VPK-3', 'VPK-3 BOYUNLUK BÜYÜK KIZAK', 'ADET', '', '300', '390', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(819, 'MM', 'Mamül', 'VATAN', 'VPK-34', 'YAN KEMER GEÇME DESTEK PLASTİGİ', 'ADET', '', '350', '194', '82', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(820, 'MM', 'Mamül', 'VATAN', 'VPK-9-A', 'YAN ÇITA SAĞ', 'ADET', '600', '130', '23,8', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(821, 'MM', 'Mamül', 'VATAN', 'VPK-9-B', 'YAN ÇITA SOL', 'ADET', '600', '130', '23,8', '42', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(822, 'MM', 'Mamül', 'VATAN', 'VTN-01', 'ANA KUCAĞI KASASI-SİYAH', 'ADET', '99', '700', '1524', '110', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(823, 'MM', 'Mamül', 'VATAN', 'VTN-02', 'ANA KUCAĞI KASASI-BEYAZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(824, 'MM', 'Mamül', 'VATAN', 'VTN-03', '0-13 KG O.K. TAŞIMA KOLU SİYAH', 'ADET', '57', '350', '600', '90', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(825, 'MM', 'Mamül', 'VATAN', 'VTN-04', 'ANA KUCAĞI TAŞIMA KOLU-BEYAZ', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(826, 'MM', 'Mamül', 'VATAN', 'VTN-05', 'ADAPTÖR BOŞANDIRMA MANDAL KAPAĞI', 'ADET', '', '130', '7,5', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(827, 'MM', 'Mamül', 'VATAN', 'VTN-06', 'GÜMÜŞ YAN MANDAL', 'ADET', '', '130', '19', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(828, 'MM', 'Mamül', 'VATAN', 'VTN-07', 'METAL KLİPS KAPAĞI', 'ADET', '', '130', '26,7', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(829, 'MM', 'Mamül', 'VATAN', 'VTN-08', 'TAŞIMA KOLU SİLİNDİRİ', 'ADET', '112', '130', '9,5', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(830, 'MM', 'Mamül', 'VATAN', 'VTN-11', '0-13 KG OTO KOLTUĞU YAN KEMER GEÇME PLASTİĞİ', 'ADET', '', '200', '57', '43', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(831, 'MM', 'Mamül', 'VATAN', 'VTN-12', 'Taşıma Kolu Yan Hareket Mandalı', 'ADET', '', '130', '19', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(832, 'MM', 'Mamül', 'VATAN', 'VTN-13', '0-13 KG OTO KOLTUĞU KADEME PLS. TIPA', 'ADET', '', '130', '0,22', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(833, 'MM', 'Mamül', 'WAT MOTOR', '801304401', 'KONDANSATÖR YATAĞI', 'ADET', '', '80', '19', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(834, 'MM', 'Mamül', 'WAT MOTOR', '801304501', 'KAPAK DİYOT BAYKAR ALTEMATÖR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(835, 'MM', 'Mamül', 'WAT MOTOR', '801305501', 'MUHAFAZA KÖMR YUVASI BAYKAR ALTEMATÖR', 'ADET', '', '80', '5', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(836, 'MM', 'Mamül', 'WAT MOTOR', '801504501', 'AA-Stator Alın İzolasyonu End. Servo 60 FR', 'ADET', '', '80', '0,45', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(837, 'MM', 'Mamül', 'WAT MOTOR', '801504901', 'AA-Stator Alın İzolasyonu End. Servo 80 FR', 'ADET', '', '130', '0,9', '30', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(838, 'MM', 'Mamül', 'WAT MOTOR', '802217901', 'ROTOR SARGI BAYKAR ALTEMATÖR', 'ADET', '', '80', '12', '40', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(839, 'MM', 'Mamül', 'WAT MOTOR', '802414801', 'AA-Kapak Enkoder End. Servo 60FR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(840, 'MM', 'Mamül', 'WAT MOTOR', '802415401', 'AA-Kapak Enkoder End. Servo 80FR', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(841, 'MM', 'Mamül', 'YILMAZ KLP', 'YLZ-01', 'YER KAROSU (YILMAZ KALIP)', 'ADET', '', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(842, 'MM', 'Mamül', 'BSH', '8001290527\r\n', 'Trim KIT FDBM 42 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(843, 'MM', 'Mamül', 'BSH', '8001303118', 'Trim KIT FDBM 36 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(844, 'MM', 'Mamül', 'BSH', '8001303120', 'Trim KIT FDBM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(845, 'MM', 'Mamül', 'BSH', '8001303121', 'TRIM KIT BM 36 HBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(846, 'MM', 'Mamül', 'BSH', '8001303122\r\n', 'Trim KIT BM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(847, 'MM', 'Mamül', 'BSH', '8001303123\r\n', 'Trim KIT BM 30 LBL MI\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(848, 'MM', 'Mamül', 'BSH', '8001290512', 'INSTALLATION KIT HBL Yukon', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(849, 'MM', 'Mamül', 'BSH', '8001286328', 'DOOR DIRECTION CHANGE KIT BO BM30 SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(850, 'MM', 'Mamül', 'BSH', '8001286325', 'INSTALLATION KIT FDBM/BM BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(851, 'MM', 'Mamül', 'BSH', '8001304521', 'INSTALLATION KIT FDBM/BM PACS BO SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(852, 'MM', 'Mamül', 'BSH', '8001304733', 'INSTALLATION KIT BM 30 LBL TH SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(853, 'MM', 'Mamül', 'BSH', '8001286318', 'TRIM KIT FDBM36 BO SbS2.0\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(854, 'MM', 'Mamül', 'BSH', '8001286322', 'TRIM KIT FDBM36  BO PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(855, 'MM', 'Mamül', 'BSH', '8001286323', 'TRIM KIT BM30 BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(856, 'MM', 'Mamül', 'BSH', '8001286324', 'TRIM KIT BM30 BO PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(857, 'MM', 'Mamül', 'BSH', '8001302148', 'TRIM KIT BM30 TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(858, 'MM', 'Mamül', 'BSH', '8001302151', 'TRIM KIT BM30  TH PACS SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(859, 'MM', 'Mamül', 'BSH', '8001229648', 'SBS COMBI KIT TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(860, 'MM', 'Mamül', 'BSH', '8001229649', 'SBS COMBI KIT GG SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(861, 'MM', 'Mamül', 'BSH', '8001274436', 'Kit, Pairing, Backwd Compat,BISbS1.1/2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(862, 'MM', 'Mamül', 'BSH', '8001288046', 'Frame Kit', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(863, 'MM', 'Mamül', 'BSH', '8001288050', 'Side Trim Kit GG SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(864, 'MM', 'Mamül', 'BSH', '8001288054', 'Single Unit Replacement Kit 36 niche\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(866, 'MM', 'Mamül', 'BSH', '8001290527', 'Trim KIT FDBM 42 HBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(867, 'MM', 'Mamül', 'BSH', '8001303122', 'Trim KIT BM 36 LBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(868, 'MM', 'Mamül', 'BSH', '8001303123', 'Trim KIT BM 30 LBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(900, 'HM', 'Yard. Malzeme', 'BSH', '8001227784', 'Side Niche Trim Narrow RAL7021 GG BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(901, 'HM', 'Yard. Malzeme', 'BSH', '8001229265', 'Cover Lateral Fridge Frz GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(902, 'HM', 'Yard. Malzeme', 'BSH', '8001229266', 'Recessed Handle Profile Fridge SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(903, 'HM', 'Yard. Malzeme', 'BSH', '8001296421', 'Cover Lateral Frz LBL GG/MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(904, 'HM', 'Yard. Malzeme', 'BSH', '8001229264', 'Cover Lateral Fridge GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(905, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(906, 'HM', 'Yard. Malzeme', 'BSH', '8001272713', 'Top Niche Trim 30 GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(907, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(908, 'HM', 'Yard. Malzeme', 'BSH', '8001227783', 'Side Niche Trim Wide RAL 7021 GG BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(909, 'HM', 'Yard. Malzeme', 'BSH', '8001229265', 'Cover Lateral Fridge Frz GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(910, 'HM', 'Yard. Malzeme', 'BSH', '8001229266', 'Recessed Handle Profile Fridge SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(911, 'HM', 'Yard. Malzeme', 'BSH', '8001229264', 'Cover Lateral Fridge GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(912, 'HM', 'Yard. Malzeme', 'BSH', '8001296413', 'Top Cover Assy. 36 Frz LBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(913, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(914, 'HM', 'Yard. Malzeme', 'BSH', '8001272712', 'Top Niche Trim 36 GG SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(915, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(917, 'HM', 'Yard. Malzeme', 'BSH', '8001289716', 'Cover Lateral FridgeOuter HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(918, 'HM', 'Yard. Malzeme', 'BSH', '8001289731', 'Cover Lateral FridgeInner HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(919, 'HM', 'Yard. Malzeme', 'BSH', '8001289759', 'Cover Lateral IM/FF HBL MC3 SbS 2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(920, 'HM', 'Yard. Malzeme', 'BSH', '8001289761', 'Cover Lateral Frz HBL MC3 SbS 2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(921, 'HM', 'Yard. Malzeme', 'BSH', '8001289879', 'Top Cover assy. 42 Frz HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(922, 'HM', 'Yard. Malzeme', 'BSH', '8001289880', 'Top Cover assy 42 IM/FF HBL MC3 SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(923, 'HM', 'Yard. Malzeme', 'BSH', '8001277933', 'Fridge Top Cover Right FDBM42 MIE assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(924, 'HM', 'Yard. Malzeme', 'BSH', '8001277931', 'Fridge Top Cover Left FDBM42 MIE assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(925, 'HM', 'Yard. Malzeme', 'BSH', '8001289676', 'Top Niche Trim 42\" RAL 7021 SbS 2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-07-31 10:34:43', NULL, NULL, ''),
(927, 'MM', 'Mamül', 'SARUHAN', '11004108', 'ALT GÖVDE - WHISPER - SİYAH', 'ADET', '0', '500', '481', '71', '', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL, ''),
(928, 'MM', 'Mamül', 'SARUHAN', '11004109', 'ARKA KAPAK - WHISPER - SİYAH', 'ADET', '0', '500', '370', '67', '', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL, ''),
(929, 'MM', 'Mamül', 'SARUHAN', '11004106', 'KONTROL PANELİ - SERİGRAFLI - WHISPER', 'ADET', '0', '130', '110', '40', '', '', '', '', 'Yavuz BEKEM', '2024-08-01 13:09:12', NULL, NULL, ''),
(930, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge BOX, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:19:24', NULL, NULL, ''),
(931, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, Comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(932, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(933, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(934, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(935, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(936, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(937, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(938, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(939, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(940, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(941, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GGr SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(942, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(943, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(944, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(945, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(946, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(947, 'HM', 'Yard. Malzeme', 'BSH', '8001226873', 'SBS Rear Hinge Bracket BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(948, 'HM', 'Yard. Malzeme', 'BSH', '8001227785', 'Center Trm Wide RAL 7021 BM SbS2.00', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(949, 'HM', 'Yard. Malzeme', 'BSH', '9000025815', 'SX S BRACKET FRONT A-COOL', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(950, 'HM', 'Yard. Malzeme', 'BSH', '9000051153', 'S*S FM PIN A-COOL', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(951, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kt Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(953, 'HM', 'Yard. Malzeme', 'BSH', '8001227786', 'Center Trim Medium RAL 7021 BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:21:37', NULL, NULL, ''),
(956, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge BOX, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(957, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, Comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(958, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Let (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(959, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(960, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(961, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(962, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(963, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(964, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge Box, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(965, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(966, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Left (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(967, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(968, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(969, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(970, 'HM', 'Yard. Malzeme', 'BSH', '8001229927', 'Fridge Top Cover Left BM30 GG ODA assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(971, 'HM', 'Yard. Malzeme', 'BSH', '8001229929', 'Fridge Bottom Cover Left BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(972, 'HM', 'Yard. Malzeme', 'BSH', '8001229910', 'Frdge Top Cover Right BM30 GG ODA assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(973, 'HM', 'Yard. Malzeme', 'BSH', '8001229928', 'Fridge Bottom Cover Right BM30 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(974, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(975, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(976, 'HM', 'Yard. Malzeme', 'BSH', '8001222596', 'Upper Hinge Box, Comp, L, GG, SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(977, 'HM', 'Yard. Malzeme', 'BSH', '8001222594', 'Upper Hinge Box, comp, R, GGr SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(978, 'HM', 'Yard. Malzeme', 'BSH', '8001223254', 'Hinge Cable Chain Support Let (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(979, 'HM', 'Yard. Malzeme', 'BSH', '8001223257', 'Hinge Cable Chain Support Right (GG)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(980, 'HM', 'Yard. Malzeme', 'BSH', '8001228691', 'Closing Part for hinge Box RAL7021 ABS', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(981, 'HM', 'Yard. Malzeme', 'BSH', '5350000392', 'FOIL BAG(130x160)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(982, 'HM', 'Yard. Malzeme', 'BSH', '8001229932', 'Fridge Top Cover Left BM36 ODA assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(983, 'HM', 'Yard. Malzeme', 'BSH', '8001229935', 'Fridge Bottom Cover Left BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(984, 'HM', 'Yard. Malzeme', 'BSH', '8001229931', 'Fridge Top Cover Right BM36 GG ODA assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(985, 'HM', 'Yard. Malzeme', 'BSH', '8001229933', 'Fridge Bottom Cover Right BM36 GG assy', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(986, 'HM', 'Yard. Malzeme', 'BSH', '8001250889', 'Separator Door Direction Kit Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(987, 'HM', 'Yard. Malzeme', 'BSH', '8001251245', 'Door Direction Ch. Kit CardboardBox 30\"', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(988, 'HM', 'Yard. Malzeme', 'BSH', '9000519005', 'Screw thread rol M5x16 T20 Zn Countersu', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(990, 'HM', 'Yard. Malzeme', 'BSH', '8001226875', 'SBS Spacer BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(992, 'HM', 'Yard. Malzeme', 'BSH', '8001233498', 'SbS Dagger Medium BM SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(994, 'HM', 'Yard. Malzeme', 'BSH', '9000025816', 'S*S FD(TURE FRONT UPPER A-COOL', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(996, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label Installation box and bag', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(997, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kt Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1006, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label installation box and bag', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1007, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trim Kit Cardboard Box SbS2.0', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1010, 'HM', 'Yard. Malzeme', 'BSH', '8001227750', 'Center Trim Narrow RAL 7021 BM SbS2.O', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1015, 'HM', 'Yard. Malzeme', 'BSH', '8001248186', 'Safety label installation box and bag', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1016, 'HM', 'Yard. Malzeme', 'BSH', '8001249863', 'Trirn Kit Cardboard Box SbS2.O', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1017, 'MM', 'Mamül', 'BSH', '8001303123 ', 'Trim KIT BM 30 LBL MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1018, 'MM', 'Mamül', 'BSH', '8001303185', 'Door Direction Change KIT MI BM30\r\n', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1019, 'MM', 'Mamül', 'BSH', '8001288064', 'Connection Replacement Kit Niche GG Sbs', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1020, 'HM', 'Yard. Malzeme', 'BSH', '8001106357', 'CA65 Warning Label (150mmx100mm)', 'ADET', '', '', '', '', '', '', '', NULL, '', '2024-08-30 11:23:24', NULL, NULL, ''),
(1021, 'HM', 'Yard. Malzeme', 'BSH', '8001234880', 'Side Niche Spacer BM SbS2.0', 'ADET', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yavuz bekem', '2024-10-21 13:03:47', NULL, NULL, ''),
(1022, 'HM', 'Yard. Malzeme', 'BSH', '8001214253', 'BSH_GB_Importers_notice_Brexit_A5_80gr', 'ADET', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yavuz bekem', '2024-10-21 13:06:47', NULL, NULL, ''),
(1023, 'MM', 'Mamül', 'BSH', '8001312760', 'Wide Side Trim Kit TH SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1024, 'MM', 'Mamül', 'BSH', '8001312946', 'Trim KIT SDF SDR SDD 24 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1025, 'MM', 'Mamül', 'BSH', '8001312926', 'Installation KIT SD TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1026, 'MM', 'Mamül', 'BSH', '8001312928', 'Installation KIT SD GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1027, 'MM', 'Mamül', 'BSH', '8001312930', 'Trim KIT SDF SDD 18 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1028, 'MM', 'Mamül', 'BSH', '8001312933', 'Trim KIT SDF SDR SDD 24 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1029, 'MM', 'Mamül', 'BSH', '8001312943', 'Trim KIT SDF 18 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1030, 'MM', 'Mamül', 'BSH', '8001312946', 'Trim KIT SDF SDR SDD 24 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1031, 'MM', 'Mamül', 'BSH', '8001312949', 'Trim KIT SDF SDR 30 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1032, 'MM', 'Mamül', 'BSH', '8001312951', 'Trim KIT SDF SDR 36 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1033, 'MM', 'Mamül', 'BSH', '8001312935', 'Trim KIT SDF SDR 30 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1034, 'MM', 'Mamül', 'BSH', '8001312937', 'Trim KIT SDF SDR 36 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1035, 'MM', 'Mamül', 'SARUHAN', '11004216', 'ARKA GÖVDE - GRİ - TVL 90 BS', 'ADET', '0', '500', '644', '73', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1036, 'MM', 'Mamül', 'SARUHAN', '11004218', 'ÖN GÖVDE - GRİ - TVL 90 BS - Serigrafi', 'ADET', '', '420', '362', '55', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1037, 'MM', 'Mamül', 'SARUHAN', '11004219', 'TABAN - GRİ - TVL 90 BS', 'ADET', '', '200', '212', '43', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1038, 'MM', 'Mamül', 'SARUHAN', '11004220', 'UZAKTAN KUMANDA TUTUCU - GRİ - TVL 90 BS', 'ADET', '0', '80', '10', '35', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1039, 'MM', 'Mamül', 'VATAN', 'CSL-11', 'TENTE / CANOPY', 'ADET', '0', '350', '105,2', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1040, NULL, 'Mamül', 'VATAN', 'CSL-12-L', 'SOL TENTE KADEME AYAR PLASTİGİ / LEFT CANOPY INSERT', 'ADET', '0', '160', '36', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1041, NULL, 'Mamül', 'VATAN', 'CSL-12-R', 'SAĞ TENTE KADEME AYAR PLASTİGİ / RIGHT CANOPY INSERT', 'ADET', '0', '160', '36', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1042, NULL, 'Mamül', 'VATAN', 'CSL-13', 'BOYUNLUK / HEADREST', 'ADET', '0', '300', '62,4', '50', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1043, NULL, 'Mamül', 'VATAN', 'CSL-14', 'RELEASE BUTTON /  ADAPTÖR BOŞANDIRMA PLASTİGİ', 'ADET', '0', '300', '81,5', '55', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1044, NULL, 'Mamül', 'VATAN', 'CSL-15', 'ARKA KEMER GEÇME PLASTİGİ / BELT GUİDE PLASTİC COVER', 'ADET', '0', '130', '26,1', '40', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1045, NULL, 'Mamül', 'VATAN', 'CSL-16-L', 'SOL YAN KEMER GEÇME PLASTİGİ / LEFT BELT GUİDE ', 'ADET', '0', '300', '8', '50', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1046, NULL, 'Mamül', 'VATAN', 'CSL-16-R', 'SAG YAN KEMER GEÇME PLASTİGİ / RIGHT BELT GUİDE ', 'ADET', '0', '300', '8', '50', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1047, NULL, 'Mamül', 'VATAN', 'CSL-17-L', 'SOL KOL İÇ KAPAK PLASTİGİ / LEFT HANDLE INNER CAP', 'ADET', '0', '160', '32,6', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1048, NULL, 'Mamül', 'VATAN', 'CSL-17-R', 'SAG KOL İÇ KAPAK PLASTİGİ / RIGHT HANDLE INNER CAP', 'ADET', '0', '160', '32,6', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1049, NULL, 'Mamül', 'VATAN', 'CSL-18', 'KOL DIŞ KAPAK PLASTİGİ / HANDLE CAP', 'ADET', '0', '80', '5,4', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1050, NULL, 'Mamül', 'VATAN', 'CSL-19-L', 'SOL KOL MANDALI / LEFT HANDLE RELEASE BUTTON', 'ADET', '0', '80', '13,4', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1051, NULL, 'Mamül', 'VATAN', 'CSL-19-R', 'SAG KOL MANDALI / RIGHT HANDLE RELEASE BUTTON', 'ADET', '0', '80', '13,4', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1052, NULL, 'Mamül', 'VATAN', 'CSL-20', 'KOL İÇ BAĞLANTI PLASTİGİ / HANDLE RELEASE LATCH', 'ADET', '0', '80', '10', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1053, NULL, 'Mamül', 'VATAN', 'CSL-21', 'KOL DIŞ KAPAK PLASTİGİ ÇERÇEVESİ / O-RİNG', 'ADET', '0', '80', '2,4', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1054, NULL, 'Mamül', 'VATAN', 'CSL-22', 'BOYUNLUK AYARI PLASTİGİ / HEADREST POSİTİON ADJUSTİNG', 'ADET', '0', '130', '4,6', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1055, NULL, 'Mamül', 'VATAN', 'CSL-23', 'METAL KLİPS KAPAĞI  / ADJUSTER CAP', 'ADET', '0', '130', '13,5', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1056, NULL, 'Mamül', 'VATAN', 'CSL-24-L', 'SOL ADAPTÖR BOŞANDIRMA PLASTİGİ / LEFT ADAPTOR', 'ADET', '0', '130', '22', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1057, NULL, 'Mamül', 'VATAN', 'CSL-24-R', 'SAG ADAPTÖR BOŞANDIRMA PLASTİGİ / HIGHT ADAPTOR', 'ADET', '0', '130', '22', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1058, NULL, 'Mamül', 'VATAN', 'CSL-25', 'TENTE KADEME AYAR PLASTİGİ TIPASI / PP TUBE ADAPTOR', 'ADET', '0', '80', '2,4', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1059, NULL, 'Mamül', 'VATAN', 'CSL-26', 'BOYUNLUK AYARLAMA HALKASI / HEADREST RELEASE BUCKLE', 'ADET', '0', '80', '3,5', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1060, NULL, 'Mamül', 'VATAN', 'CSL-28-L', 'SOL DÜZENLEYİCİ / LEFT REGULATOR', 'ADET', '0', '130', '7', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1061, NULL, 'Mamül', 'VATAN', 'CSL-28-R', 'SAG DÜZENLEYİCİ / HIGHT REGULATOR', 'ADET', '0', '130', '7', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1062, NULL, 'Mamül', 'VATAN', 'CSL-03', 'ÜST BAZA / UPPER BASE', 'ADET', '0', '800', '452', '70', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1063, NULL, 'Mamül', 'VATAN', 'CSL-04', 'ALT BAZA / LOWER BASE', 'ADET', '0', '800', '1155', '75', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1064, NULL, 'Mamül', 'VATAN', 'CSL-05', 'DÖNER BAZA MEKANİZMASI / ROTATİON WHEEL', 'ADET', '0', '350', '0.859', '55', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1065, NULL, 'Mamül', 'VATAN', 'CSL-06', 'BAZA DÖNDÜRME PLASTİGİ / CONNECTİON PART', 'ADET', '0', '200', '0.0208', '40', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1066, NULL, 'Mamül', 'VATAN', 'CSL-07', 'DESTEK AYAĞI ÜST KAPAK PLASTİGİ-1 / COVER', 'ADET', '0', '130', '0.0067', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1067, NULL, 'Mamül', 'VATAN', 'CSL-08', 'DESTEK AYAĞI ALT KAPAK-1 / LEG-1 ', 'ADET', '0', '200', '0.012', '50', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1068, NULL, 'Mamül', 'VATAN', 'CSL-09', 'DESTEK AYAĞI ALT KAPAK-2 / LEG-2', 'ADET', '0', '200', '0.0116', '45', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1069, NULL, 'Mamül', 'VATAN', 'CSL-10', 'DESTEK AYAĞI AYAR PLASTİGİ / LEG-3', 'ADET', '0', '80', '0.0018', '30', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1070, NULL, 'Mamül', 'VATAN', 'CSL- 27', 'İNDİKATÖR / INDİCATOR', 'ADET', '0', '80', '0.0004', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1071, NULL, 'Mamül', 'VATAN', 'CSL-29', 'BAZA DÖNDÜRME KİLİT PLASTİGİ / ROTATİON LOCK', 'ADET', '0', '130', '0.0092', '35', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1072, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '130', NULL, NULL, NULL, NULL, 'Koli', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz BEKEM', '2025-01-31 15:24:31', 'MM'),
(1073, 'MM', 'Mamül', NULL, NULL, NULL, 'ADET', NULL, '130', NULL, NULL, NULL, NULL, 'Koli', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz BEKEM', '2025-01-31 15:21:29', 'MM'),
(1074, 'MM', 'Mamül', 'BSH', '8001303686', 'Installation Kit SbS middle MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1075, 'MM', 'Mamül', 'BSH', '8001303681', 'Installation Kit SbS big MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1076, 'MM', 'Mamül', 'BSH', '8001303688', 'Installation Kit SbS small MI', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1077, 'MM', 'Mamül', 'BSH', '8001303186', 'Door Direction Change KIT MI BM30 ODA', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1078, 'MM', 'Mamül', 'BSH', '8001303187', 'Door Direction Change KIT MI BM36 ODA', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1079, 'YM', 'Yarı Mamül', 'BSH', '9000515146', 'KAPI SIVICI TAKVİYE PARÇASI', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1080, 'YM', 'Yarı Mamül', 'BSH', '9000515146_P', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1081, 'YM', 'Yarı Mamül', 'BSH', '9000515146_Y', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1082, 'YM', 'Yarı Mamül', 'BSH', '9000515146_T', 'CAP FOR REİNFORCEMENT PART DOOR SWİTCH FIKS-113', 'ADET', '0', '80', '2,1', '38', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1083, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AC', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1084, 'YM', 'Yarı Mamül', NULL, NULL, NULL, 'ADET', NULL, '300', NULL, NULL, NULL, NULL, '', NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', 'Yavuz Bekem', '2026-03-09 09:11:42', 'MM'),
(1085, 'YM', 'Yarımamül', 'ARÇELİK', '2990320100', 'SEFFAF_PLASTIK_KAPAK_ABM', 'ADET', '', '500', '530', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1086, 'YM', 'Yarı Mamül', 'BSH', '8001328164', 'Toe Kick Comp bracket le TH', 'ADET', '0', '130', '23,8', '40', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1087, 'YM', 'Yarı Mamül', 'BSH', '8001328167', 'Toe Kick Comp bracket le GG', 'ADET', '0', '130', '23,8', '40', '0', '0', NULL, NULL, 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, 'MM'),
(1088, 'MM', 'Mamül', 'BSH', '8001312944', 'Trim KIT SDW 18 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1089, 'MM', 'Mamül', 'BSH', '8001312947', 'Trim KIT SDW 24 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1090, 'MM', 'Mamül', 'BSH', '8001312931', 'Trim KIT SDW 18 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1091, 'MM', 'Mamül', 'BSH', '8001312934', 'Trim KIT SDW 24 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1092, 'MM', 'Yarı Mamül', 'BSH', '8001300560', 'Seal Surf. Comp SDR36 TH Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1093, 'MM', 'Yarı Mamül', 'BSH', '8001300563', 'Seal Surf. Comp SDR30 TH Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1094, 'MM', 'Yarı Mamül', 'BSH', '8001300565', 'Seal Surf. Comp SDR24 TH Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1095, 'MM', 'Yarı Mamül', 'BSH', '8001300561', 'Seal Surf. Comp SDR30 GG Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1096, 'MM', 'Yarı Mamül', 'BSH', '8001300564', 'Seal Surf. Comp SDR24 GG Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1097, 'MM', 'Yarı Mamül', 'BSH', '8001300559', 'Seal Surf. Comp SDR36 GG Columns', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1098, 'MM', 'Mamül', 'BSH', '8001312929', 'Door Direction Change KIT SD 18 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1099, 'MM', 'Mamül', 'BSH', '8001319327', 'Door Direction Change KIT SD 24 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1100, 'MM', 'Mamül', 'BSH', '8001319329', 'Door Direction Change KIT SD 30 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1101, 'MM', 'Mamül', 'BSH', '8001319330', 'Door Direction Change KIT SD 36 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1102, 'MM', 'Mamül', 'BSH', '8001319331', 'Door Direction Change KIT SD 18 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1103, 'MM', 'Mamül', 'BSH', '8001319332', 'Door Direction Change KIT SD 24 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1104, 'MM', 'Mamül', 'BSH', '8001319333', 'Door Direction Change KIT SD 30 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1105, 'MM', 'Mamül', 'BSH', '8001319334', 'Door Direction Change KIT SD 36 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1106, 'MM', 'Mamül', 'BSH', '8001331454', 'Door Direction Change KIT SDW 18 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1107, 'MM', 'Mamül', 'BSH', '8001331457', 'Door Direction Change KIT SDW 24 TH', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1108, 'MM', 'Mamül', 'BSH', '8001331458', 'Door Direction Change KIT SDW 18 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1109, 'MM', 'Mamül', 'BSH', '8001331460', 'Door Direction Change KIT SDW 24 GG', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1110, 'MM', 'Mamül', 'VATAN', 'VPK-04', 'VPK-04 ARKA BÜYÜK KAPAK', 'ADET', '', '350', '350', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1111, 'MM', 'Mamül', 'ARÇELİK Eİ', 'WHE23200-AD', 'PLASTIK OPTIMUS BOTTOM AV BLACK', 'ADET', '788', '160', '10,88', '37', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1112, 'MM', 'Mamül', 'BSH', '8001355820', 'SBS COMBI KIT BO SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1113, 'HM', 'Yarı Mamül', 'BSH', '8001288024', 'Center Trim Narrow VZF 07020 BM SbS2.0', 'ADET', '0', '', '', '', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1114, 'YM', 'Yarımamül', 'ARÇELİK', '2991240400', 'IC_INLAY_ABM_KKSIZ_ARC1_BEYAZ_V0', 'ADET', '', '650', '351', '50', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1115, 'MM', 'Mamül', 'POVAG', '100701103015000000001', 'bin - No. 33 - 92x320x92 mm- Blue virgin PP', 'ADET', '', '200', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1116, 'MM', 'Mamül', 'POVAG', '100701103013000000001', 'bin - No. 33 - 92x320x92 mm- Red virgin PP', 'ADET', '', '200', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1117, 'MM', 'Mamül', 'POVAG', '100701103011000000001', 'bin - No. 33 - 92x320x92 mm- Yellow virgin PP', 'ADET', '', '200', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1118, 'MM', 'Mamül', 'POVAG', '100701103018000000001', 'bin - No. 33 - 92x320x92 mm- Green virgin PP', 'ADET', '', '200', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1119, 'MM', 'Mamül', 'POVAG', '100701103019500000001', 'bin - No. 33 - 92x320x92 mm- Black virgin PP', 'ADET', '', '200', '235', '50', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1120, 'MM', 'Mamül', 'POVAG', '100701101013000000001', 'bin - No. 63 - 184x320x92 mm- Red virgin PP', 'ADET', '', '300', '415', '70', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1121, 'MM', 'Mamül', 'POVAG', '100701101015000000001', 'bin - No. 63 - 184x320x92 mm - Blue virgin PP', 'ADET', '', '300', '415', '70', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1122, 'MM', 'Mamül', 'POVAG', '100701101011000000001', 'bin - No. 63 - 184x320x92 mm- Yellow virgin PP', 'ADET', '', '300', '415', '70', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1123, 'MM', 'Mamül', 'POVAG', '100701101018000000001', 'bin - No. 63 - 184x320x92 mm- Green virgin PP\r\n', 'ADET', '', '300', '415', '70', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1124, 'MM', 'Mamül', 'POVAG', '100701101019500000001', 'bin - No. 63 - 184x320x92 mm- Black virgin PP', 'ADET', '', '300', '415', '70', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1125, 'MM', 'Mamül', 'POVAG', '109901002010000000000', 'bin - No. 48 - 92x175 mm - Transparent virgin PP', 'ADET', '', '130', '16', '40', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1126, 'MM', 'Mamül', 'POVAG', '109901003010000000000', 'bin - No. 33 - 92x85 mm- Transparent virgin PP', 'ADET', '', '130', '30', '40', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1127, 'MM', 'Mamül', 'POVAG', '109901004010000000000\r\n', 'bin - No.63 - 80x280 mm- Transparent virgin PP', 'ADET', '', '130', '60', '48', '', '', '', '', 'Yavuz BEKEM', '2025-08-06 12:20:07', NULL, NULL, ''),
(1128, 'HM', 'Yarı Mamül', 'BSH', '8001300525', 'Seal Surf. Left SDR GG Columns', 'ADET', '0', '300', '25', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1129, 'HM', 'Yarı Mamül', 'BSH', '8001300528', 'Seal Surf. Right SDR GG Columns', 'ADET', '0', '300', '25', '45', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1130, 'MM', 'Mamül', 'ARÇELİK', '2969670400', 'SOL_TEKMLK(BEST-BETTER.PL)722_SYHPRLK_IZGRLI', 'ADET', '', '300', '213', '60', '', '', '', '', 'Yavuz BEKEM', '2025-07-21 22:20:07', NULL, NULL, ''),
(1131, 'MM', 'Mamül', 'ARÇELİK', '2995190100', 'TEKMELIK_GR_PLM4_ARC_P1BEYAZ Indesit', 'ADET', '5085', '650', '385', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1132, 'MM', 'Mamül', 'ARÇELİK', '2995190200', 'TEKMELIK_GR_PLM4_ARC722 SYH_PARLAK Indesit', 'ADET', '5085', '650', '385', '65', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1133, 'MM', 'Mamül', 'ARÇELİK', '2969670100', 'SOL_TEKMELIK(BEST-BETTER_PL)ARC1_IZGRLI', 'ADET', '2474', '30', '211', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1134, 'MM', 'Mamül', 'ARÇELİK', '2984581100', 'DAR_ARKA_KAPAK_GR_XL(KECELI)_EKO', 'ADET', '0', '650', '540', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1135, 'MM', 'Mamül', 'VATAN', 'CSL-01', 'GÖVDE ', 'ADET', '0', '850', '1560', '120', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1136, 'MM', 'Mamül', 'ARÇELİK', '2986750300', 'TANK YUVASI GRUBU 54 CM PROLOGUE XL', 'ADET', '', '700', '575', '55', '30', '90', 'K-550', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1137, 'MM', 'Mamül', 'ARÇELİK', '2986750500', 'TANK YUVASI GR (54CM PRLG XL) GRI IRONFI', 'ADET', '', '700', '575', '55', '30', '90', 'K-550', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1138, 'YM', 'Yarımamül', 'ARÇELİK', '2991150200', 'KORUYUCU_KAPAK_ABM_MABS', 'ADET', '', '650', '687', '70', '', '', '', '', 'Yavuz BEKEM', '2025-12-15 15:12:07', NULL, NULL, ''),
(1139, 'MM', 'Mamül', 'KULTURA', 'KLT-0001', 'Whilot_Alt-V1.2', 'ADET', '', '80', '30', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1140, 'MM', 'Mamül', 'KULTURA', 'KLT-0002', 'Whilot_Ust-V1.2', 'ADET', '', '80', '40', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1141, 'MM', 'Mamül', 'KULTURA', 'KLT-0003', 'LED_cubugu-V1.1', 'ADET', '', '80', '3', '60', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1142, 'MM', 'Yarı Mamül', 'BSH', '8001344840', 'Frezer Volume Reduction Bracket\r\n', 'ADET', '0', '160', '36', '45', NULL, NULL, NULL, NULL, NULL, '2026-01-19 10:17:03', NULL, NULL, ''),
(1143, 'MM', 'Mamül', 'ARÇELİK KMI', '2989190300', 'TANK_YUVASI_GR_PROLOGUE 60CM_XL_GRI\r\n', 'ADET', '0', '650', '620', '70', '24', '72', 'K-550', NULL, NULL, '2026-01-19 10:23:09', NULL, NULL, '');
INSERT INTO `malzemeler` (`malzeme_id`, `malzeme_tür`, `malzeme_group`, `malzeme_firma`, `malzeme_kod`, `malzeme_ad`, `malzeme_birim`, `malzeme_stok`, `map_makina_tonaj`, `map_gramaj`, `map_cevrim`, `paket_miktari`, `taban_miktari`, `malzeme_ambalaj`, `malzeme_logo`, `malzeme_ekleyen`, `malzeme_tarihi`, `malzeme_update`, `malzeme_update_tarihi`, `malzeme_tur`) VALUES
(1144, 'MM', 'Mamül', 'ARÇELİK KMI', '2989190600', 'TANK_YUVASI_GR_PROLOGUE 60CM_GRI_IRONFIN', 'ADET', '0', '650', '620', '70', '24', '72', 'K-550', NULL, NULL, '2026-01-19 10:23:09', NULL, NULL, ''),
(1145, 'MM', 'Mamül', 'ARÇELİK TKM', '3580780100', 'FİNCANA NOZZLE MILI', 'ADET', '0', '130', NULL, '35', NULL, NULL, NULL, NULL, NULL, '2026-01-19 10:32:14', NULL, NULL, ''),
(1146, 'MM', 'Mamül', 'ARÇELİK', '2969670400-1', 'SOL_TEKMLK(BEST-BETTER.PL)722_SYH_BOYANACAK', 'ADET', '', '300', '213', '60', '', '', '', '', 'Yavuz BEKEM', '2025-07-21 22:20:07', NULL, NULL, ''),
(1147, 'MM', 'Mamül', 'SARUHAN', '11004115', 'HAVA IZGARA DÜĞMESİ - WHISPER - BEYAZ', 'ADET', '', '130', '11', '42', '', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL, ''),
(1148, 'MM', 'Mamül', 'SARUHAN', '11004134', 'HAVA IZGARA ÇERÇEVESİ - WHISPER - BEYAZ', 'ADET', '', '130', '67', '43', '', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL, ''),
(1149, 'MM', 'Mamül', 'SARUHAN', '11004105', 'TUTAMAK ALT KAPAK - WHISPER - BEYAZ', 'ADET', '', '130', '60', '48', '', '', '', '', 'Yavuz BEKEM', '2026-02-04 22:20:07', NULL, NULL, ''),
(1150, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580550100', 'FİNCANA PISIRME HAZNE YUVASI UST', 'ADET', '', '160', '104', '45', '', '', '', '', 'Yavuz BEKEM', '2026-01-04 11:22:00', NULL, NULL, ''),
(1151, 'YM', 'Yarımamül', 'ARÇELK TKM', '3580580100', 'FİNCANA ATIK KAHVE HAZNESI TETIK BUTONU', 'ADET', '', '130', '2,8', '35', '', '', '', '', 'Yavuz BEKEM', '2026-01-04 11:22:00', NULL, NULL, ''),
(1152, 'MM', 'Mamül', 'ARÇELİK', '2984581200', 'DAR_ARKA_KAPAK_GR_XL(KECE+BITUM)_EKO', 'ADET', '0', '650', '540', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1153, 'MM', 'Mamül', 'POVAG', '100702002010000000001', 'Kantelbak No.15 -transparent-150x115x110mm NSBC', 'ADET', '0', '260', '175', '70', '', '', '', '', 'Yavuz BEKEM', '2023-12-28 22:20:07', NULL, NULL, ''),
(1154, 'MM', 'Mamül', 'BSH', '9000493277', 'SU CIKIS PARCASI - NSP', 'ADET', '0', '300', '9,25', '40', '250', '20000', 'Kasa', NULL, NULL, '2026-01-19 10:17:03', 'Yavuz Bekem', '2026-03-10 10:08:05', ''),
(1155, 'MM', 'Mamül', 'BSH', '8001297265', 'Air Guider SDW 18/24-BI SbS 2.0', 'Adet', '0', '200', '25', '40', '750', '15000', 'Kasa', NULL, 'Yavuz Bekem', '2026-03-10 09:13:53', 'Yavuz Bekem', '2026-03-10 13:33:30', 'MM'),
(1156, 'YM', 'Yarımamul', 'ARÇELİK KMI', '2991260200', 'IC_KAPAK_ABM_KKSIZ_KOYU_GRI', 'Adet', '0', '650', '590', '65', '17', '102', 'Koli', NULL, 'Yavuz Bekem', '2026-03-10 10:12:26', 'Yavuz Bekem', '2026-03-10 13:34:01', 'YM'),
(1157, NULL, 'Yarımamul', 'ARÇELİK KMI', '2991190200', 'IC_KAPAK_ABM_KKLI_KGRI(UL)', 'Adet', '0', '650', '360', '65', '0', '0', 'Koli', NULL, 'Yavuz Bekem', '2026-03-11 09:25:06', NULL, NULL, 'YM'),
(1158, NULL, 'Yarımamul', 'ARÇELİK KMI', '2991170200', 'CAM_TUTUCU_ABM_KGRI', 'Adet', '0', '650', '309', '55', '0', '0', 'Koli', NULL, 'Yavuz Bekem', '2026-03-11 09:27:32', NULL, NULL, 'YM'),
(1159, NULL, 'Mamül', 'SARUHAN', '11000047', 'ÜST KAPAK - YAZISIZ - SİYAH', 'Adet', '0', '420', '635', '110', '0', '0', 'Koli', NULL, 'Yavuz Bekem', '2026-03-13 12:14:32', NULL, NULL, 'MM'),
(1160, 'MM', 'Mamül', 'HASEL', 'MML0751', 'MASFAL UST BAĞLANTI PLASTİGİ - HASEL', 'Adet', '0', '80', '3,75', '42', '0', '0', 'Koli', NULL, 'Yavuz Bekem', '2026-03-17 17:22:19', 'Yavuz Bekem', '2026-03-17 17:22:47', 'MM'),
(1161, NULL, 'Mamül', 'HASEL', 'MML0755', 'ALT ÇITA TAPA - HASEL', 'Adet', '0', '80', '5,75', '42', '0', '0', 'Koli', NULL, 'Yavuz Bekem', '2026-03-17 17:24:17', NULL, NULL, 'MM'),
(1162, NULL, 'Mamül', 'POVAG', '100102033010095000001', 'seperator - 300 mm - Black virgin HIPS', 'Adet', '0', '850', '89', '55', '72', '4032', 'Koli', NULL, 'Yavuz Bekem', '2026-03-17 17:26:19', NULL, NULL, 'MM');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `malzeme_tanımları`
--
ALTER TABLE `malzeme_tanımları`
  ADD PRIMARY KEY (`malzeme_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `malzeme_tanımları`
--
ALTER TABLE `malzeme_tanımları`
  MODIFY `malzeme_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1163;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- ----------------------------------------------------------------
-- 13. Menü Verileri
-- Kaynak: veritabani_menu.sql
-- ----------------------------------------------------------------

-- Dinamik Menü Tabloları
-- jetone_pro veritabanı için

CREATE TABLE IF NOT EXISTS `menu_moduller` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modul_id` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL COMMENT 'depo, satis, satinalma vb',
  `baslik` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL,
  `ikon` varchar(10) COLLATE utf8mb4_turkish_ci DEFAULT '📋',
  `renk` varchar(20) COLLATE utf8mb4_turkish_ci DEFAULT '#E0F2FE',
  `sira` int DEFAULT '0',
  `aktif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `modul_id` (`modul_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

CREATE TABLE IF NOT EXISTS `menu_gruplar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modul_id` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `grup_adi` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL,
  `sira` int DEFAULT '0',
  `aktif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `modul_id` (`modul_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

CREATE TABLE IF NOT EXISTS `menu_sayfalar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grup_id` int NOT NULL,
  `modul_id` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `sayfa_id` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL COMMENT 'depo-stok gibi route id',
  `baslik` varchar(80) COLLATE utf8mb4_turkish_ci NOT NULL,
  `ikon` varchar(10) COLLATE utf8mb4_turkish_ci DEFAULT '📄',
  `sira` int DEFAULT '0',
  `aktif` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sayfa_id` (`sayfa_id`),
  KEY `grup_id` (`grup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

CREATE TABLE IF NOT EXISTS `menu_rol_yetki` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rol` varchar(40) COLLATE utf8mb4_turkish_ci NOT NULL,
  `sayfa_id` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rol_sayfa` (`rol`,`sayfa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ─── MODÜLLER ───────────────────────────────────────────────────────────────
INSERT IGNORE INTO `menu_moduller` (`modul_id`,`baslik`,`ikon`,`renk`,`sira`) VALUES
('dashboard','Dashboard','🏠','#E0F2FE',0),
('satis','Satış','🛒','#D1FAE5',1),
('satinalma','Satınalma','📥','#FEF3C7',2),
('uretim','Üretim','🏭','#FCE7F3',3),
('kalite','Kalite','✅','#D1FADF',4),
('depo','Depo & Sevkiyat','📦','#FEF0C7',5),
('planlama','Planlama','🗂','#E0F2FE',6),
('raporlar','Raporlar','📊','#E0F2FE',7),
('ayarlar','Ayarlar','⚙️','#F1F5F9',8);

-- ─── DEPO GRUPLARI ─────────────────────────────────────────────────────────
INSERT IGNORE INTO `menu_gruplar` (`modul_id`,`grup_adi`,`sira`) VALUES
('depo','SEVKİYAT',1),
('depo','SİPARİŞLER',2),
('depo','STOK',3),
('depo','SAYIM',4),
('depo','ANALİZ',5);

-- ─── DEPO SAYFALARI ─────────────────────────────────────────────────────────
-- SEVKİYAT (grup_id = id of 'SEVKİYAT')
INSERT IGNORE INTO `menu_sayfalar` (`grup_id`,`modul_id`,`sayfa_id`,`baslik`,`ikon`,`sira`) VALUES
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SEVKİYAT'),
 'depo','depo-sevkiyat-dashboard','Dashboard','📊',1),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SEVKİYAT'),
 'depo','depo-sevkiyat','Sevkiyat','🚚',2),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SEVKİYAT'),
 'depo','depo-irsaliye','İrsaliyeler','📄',3),
-- SİPARİŞLER
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SİPARİŞLER'),
 'depo','depo-siparis','Sipariş Listesi','🛒',1),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SİPARİŞLER'),
 'depo','depo-jit','JIT / KMI Listesi','⚡',2),
-- STOK
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='STOK'),
 'depo','depo-stok','Stok Raporu','📦',1),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='STOK'),
 'depo','depo-adresli-stok','Adresli Stok','📍',2),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='STOK'),
 'depo','depo-paketler','Paketler','📋',3),
-- SAYIM
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SAYIM'),
 'depo','depo-paket-pasif','Paket Pasif Et','🔇',1),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SAYIM'),
 'depo','depo-paket-sayim','Paket Sayım','📱',2),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='SAYIM'),
 'depo','depo-stok-farki','Logo-MES Farkı','⚖️',3),
-- ANALİZ
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='ANALİZ'),
 'depo','depo-hareketler','Stok Hareketleri','↕',1),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='ANALİZ'),
 'depo','depo-paket-hareketler','Paket Hareketleri','📦',2),
((SELECT id FROM menu_gruplar WHERE modul_id='depo' AND grup_adi='ANALİZ'),
 'depo','depo-terminal','Terminal Kullanım','📟',3);

-- ----------------------------------------------------------------
-- 14. Örnek Veriler
-- Kaynak: ornek_veriler.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO — Örnek Veriler + Sistem Güncellemeleri
-- ornek_veriler.sql
--
-- KURULUM SIRASI:
--   1. veritabani_olustur.sql  çalıştır
--   2. bu dosyayı çalıştır
-- ============================================================

USE `jetone_pro`;

-- ─── sistem_loglar tablosuna tablo_adi kolonu ekle ──────────
ALTER TABLE `sistem_loglar`
  ADD COLUMN IF NOT EXISTS `tablo_adi` VARCHAR(80) DEFAULT NULL AFTER `modul`;

-- ─── Mevcut varsayılan admin şifresini güncelle ─────────────
-- Şifre: Admin123!
-- Hash: password_hash('Admin123!', PASSWORD_DEFAULT)
UPDATE `kullanicilar`
SET `sifre_hash` = '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    `ad`         = 'Süper',
    `soyad`      = 'Admin',
    `rol_id`     = 1
WHERE `email` = 'admin@jetone.pro';

-- ════════════════════════════════════════════════════════════
-- 1. SİSTEM KULLANICILARI (ERP Giriş Hesapları)
-- ════════════════════════════════════════════════════════════
-- Tüm şifreler: Jetone2024!
-- Hash: password_hash('Jetone2024!', PASSWORD_DEFAULT)
SET @hash = '$2y$12$LcTrBvzS9e7NxGqyUWImDuiEVEAJRuVGTNwZSqHVg5PpCsFJdXRWy';

INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`rol_id`,`departman_id`,`pozisyon`,`durum`) VALUES
('Ayşe',   'Yılmaz',  'ayse.yilmaz@jetone.pro',  @hash, 1, 1, 'Sistem Yöneticisi', 1),
('Mehmet', 'Kaya',    'mehmet.kaya@jetone.pro',   @hash, 2, 2, 'İK Müdürü',         1),
('Fatma',  'Şahin',   'fatma.sahin@jetone.pro',   @hash, 3, 5, 'Üretim Şefi',       1),
('Ali',    'Demir',   'ali.demir@jetone.pro',      @hash, 4, 8, 'Satınalma Uzmanı',  1),
('Zeynep', 'Arslan',  'zeynep.arslan@jetone.pro',  @hash, 5, 4, 'Satış Temsilcisi',  1);

-- ════════════════════════════════════════════════════════════
-- 2. PERSONELLER (İK Modülü)
-- ════════════════════════════════════════════════════════════
INSERT INTO `personeller`
  (`sicil_no`,`ad`,`soyad`,`tc_kimlik`,`dogum_tarihi`,`cinsiyet`,
   `departman_id`,`pozisyon`,`telefon`,`email`,
   `ise_baslama`,`calısma_tipi`,`durum`,`maas`) VALUES

-- Üretim Departmanı
('P-00001','Ahmet',   'Kaya',    '12345678901','1988-05-12',1, 5,'Üretim Operatörü',   '0532 111 0001','ahmet.kaya@firma.com',    '2019-03-01','tam_zamanli','aktif', 18500.00),
('P-00002','Mustafa', 'Çelik',   '12345678902','1990-07-22',1, 5,'CNC Operatörü',      '0532 111 0002','mustafa.celik@firma.com',  '2020-06-15','tam_zamanli','aktif', 20000.00),
('P-00003','Hasan',   'Yıldız',  '12345678903','1985-11-03',1, 5,'Vardiya Şefi',       '0532 111 0003','hasan.yildiz@firma.com',   '2017-01-10','tam_zamanli','aktif', 28000.00),
('P-00004','İbrahim', 'Öztürk',  '12345678904','1992-03-18',1, 5,'Bakım Teknisyeni',   '0532 111 0004','ibrahim.ozturk@firma.com', '2021-09-01','tam_zamanli','aktif', 22000.00),
('P-00005','Emre',    'Yılmaz',  '12345678905','1995-08-25',1, 5,'Üretim Operatörü',   '0532 111 0005','emre.yilmaz@firma.com',    '2022-02-14','tam_zamanli','aktif', 17500.00),

-- İK Departmanı
('P-00006','Fatma',   'Şahin',   '12345678906','1987-02-14',2, 2,'İK Uzmanı',          '0532 111 0006','fatma.sahin@firma.com',    '2018-07-01','tam_zamanli','aktif', 32000.00),
('P-00007','Elif',    'Koca',    '12345678907','1993-12-30',2, 2,'İK Asistanı',        '0532 111 0007','elif.koca@firma.com',      '2022-04-01','tam_zamanli','aktif', 22000.00),

-- Kalite Departmanı
('P-00008','Selin',   'Aydın',   '12345678908','1989-09-07',2, 7,'Kalite Uzmanı',      '0532 111 0008','selin.aydin@firma.com',    '2019-11-15','tam_zamanli','aktif', 27000.00),
('P-00009','Burak',   'Güneş',   '12345678909','1991-04-21',1, 7,'Kalite Kontrol',     '0532 111 0009','burak.gunes@firma.com',    '2020-08-01','tam_zamanli','aktif', 24000.00),

-- Depo Departmanı
('P-00010','Murat',   'Doğan',   '12345678910','1986-06-15',1, 6,'Depo Sorumlusu',     '0532 111 0010','murat.dogan@firma.com',    '2018-01-15','tam_zamanli','aktif', 25000.00),
('P-00011','Kadir',   'Arslan',  '12345678911','1994-01-28',1, 6,'Depo Görevlisi',     '0532 111 0011','kadir.arslan@firma.com',   '2021-05-01','tam_zamanli','aktif', 19000.00),
('P-00012','Serkan',  'Kılıç',   '12345678912','1997-10-11',1, 6,'Forklift Operatörü', '0532 111 0012','serkan.kilic@firma.com',   '2023-01-09','tam_zamanli','aktif', 18000.00),

-- Satış Departmanı
('P-00013','Zeynep',  'Arslan',  '12345678913','1990-03-05',2, 4,'Satış Uzmanı',       '0532 111 0013','zeynep.arslan@firma.com',  '2019-05-01','tam_zamanli','aktif', 30000.00),
('P-00014','Berk',    'Özkan',   '12345678914','1988-07-19',1, 4,'Satış Müdürü',       '0532 111 0014','berk.ozkan@firma.com',     '2016-09-01','tam_zamanli','aktif', 45000.00),

-- Muhasebe
('P-00015','Büşra',   'Yılmaz',  '12345678915','1992-11-22',2, 3,'Muhasebe Uzmanı',    '0532 111 0015','busra.yilmaz@firma.com',   '2020-10-01','tam_zamanli','aktif', 34000.00);

-- ════════════════════════════════════════════════════════════
-- 3. MÜŞTERİLER
-- ════════════════════════════════════════════════════════════
INSERT INTO `musteriler`
  (`kod`,`ad`,`tip`,`vergi_no`,`vergi_dairesi`,`telefon`,`email`,
   `adres`,`il`,`ilce`,`yetkili_adi`,`yetkili_tel`,`yetkili_email`,
   `odeme_vadesi`,`durum`) VALUES
('ABC-001','ABC Plastik Sanayi A.Ş.','kurumsal','1234567890','Kadıköy VD','0216 555 0001','info@abcplastik.com','Dudullu OSB, A Blok No:5','İstanbul','Ümraniye','Ahmet Polat','0532 222 0001','ahmet.polat@abcplastik.com',30,'aktif'),
('DEF-002','Demir Endüstri Ltd.','kurumsal','2345678901','Ostim VD','0312 555 0002','info@demirend.com','Ostim OSB, 15. Sk. No:8','Ankara','Yenimahalle','Cemal Demir','0533 222 0002','cemal@demirend.com',45,'aktif'),
('XYZ-003','XYZ Makine Sanayi','kurumsal','3456789012','Bursa VD','0224 555 0003','info@xyzmakine.com','Organize San. Bölgesi 4. Cadde','Bursa','Nilüfer','Selim Yıldız','0534 222 0003','selim@xyzmakine.com',30,'aktif'),
('TRK-004','Türk Metal A.Ş.','kurumsal','4567890123','İkitelli VD','0212 555 0004','info@turkmetal.com.tr','İkitelli OSB, Metal İşleme Blok','İstanbul','Başakşehir','Ferhat Türk','0535 222 0004','ferhat@turkmetal.com.tr',60,'aktif'),
('PLS-005','Polimer Plastik Ltd.','kurumsal','5678901234','Manisa VD','0236 555 0005','info@polimer.com','MOSB, 8. Sokak No:12','Manisa','Yunusemre','Kahraman Polimer','0536 222 0005','kahraman@polimer.com',30,'aktif'),
('TEK-006','Teknoform Endüstri','kurumsal','6789012345','Kocaeli VD','0262 555 0006','info@teknoform.com','GOSB, A-12 Parsel','Kocaeli','Gebze','Tülay Tekno','0537 222 0006','tulay@teknoform.com',15,'aktif');

-- ════════════════════════════════════════════════════════════
-- 4. ÜRÜNLER
-- ════════════════════════════════════════════════════════════
INSERT INTO `urunler` (`kod`,`ad`,`kategori`,`birim`,`birim_fiyat`,`stok_miktari`,`min_stok`,`max_stok`,`durum`) VALUES
('PRD-K200','Plastik Kapak 200mm','Plastik Ürünler','adet',  12.50,  2450, 500, 5000,'aktif'),
('PRD-B045','Metal Braket X45',   'Metal Parçalar', 'adet',  45.00,   180,  200, 2000,'aktif'),
('PRD-G012','Gövde Ürünü B12',    'Gövde',          'adet', 125.00,     0,  100, 1000,'aktif'),
('PRD-M007','Montaj Parçası C7',  'Montaj',         'adet',   8.75,  5800, 1000,10000,'aktif'),
('PRD-V055','Vida Seti 55mm',     'Bağlantı',       'paket',  3.20, 12000, 2000,20000,'aktif'),
('PRD-R020','Rondela 20mm',       'Bağlantı',       'adet',   0.85,   400,  500, 5000,'aktif'),
('PRD-H100','Hidrolik Silindir',  'Hidrolik',       'adet', 850.00,    45,   20,  200,'aktif'),
('PRD-F030','Filtre Kartuşu 30',  'Filtre',         'adet',  28.00,   320,  100,  800,'aktif');

-- ════════════════════════════════════════════════════════════
-- 5. DEVAM KAYITLARI (son 7 gün örnek veri)
-- ════════════════════════════════════════════════════════════
INSERT INTO `devam_kayitlari` (`personel_id`,`tarih`,`giris_saati`,`cikis_saati`,`calisma_suresi`,`durum`,`giris_tipi`) VALUES
(1,DATE_SUB(CURDATE(),INTERVAL 6 DAY),'06:02:00','14:05:00',8.05,'geldi','kart'),
(1,DATE_SUB(CURDATE(),INTERVAL 5 DAY),'06:05:00','14:10:00',8.08,'geldi','kart'),
(1,DATE_SUB(CURDATE(),INTERVAL 4 DAY),'06:00:00','14:00:00',8.00,'geldi','kart'),
(1,DATE_SUB(CURDATE(),INTERVAL 3 DAY),'09:15:00','17:00:00',7.75,'gecikti','kart'),
(1,DATE_SUB(CURDATE(),INTERVAL 2 DAY),'06:01:00','14:02:00',8.02,'geldi','kart'),
(1,DATE_SUB(CURDATE(),INTERVAL 1 DAY),'06:00:00','14:00:00',8.00,'geldi','kart'),
(1,CURDATE(),'06:03:00',NULL,NULL,'geldi','geofence'),
(2,DATE_SUB(CURDATE(),INTERVAL 1 DAY),'07:55:00','16:10:00',8.25,'geldi','kart'),
(2,CURDATE(),'07:58:00',NULL,NULL,'geldi','kart'),
(3,DATE_SUB(CURDATE(),INTERVAL 1 DAY),'05:50:00','14:05:00',8.25,'geldi','kart'),
(3,CURDATE(),'05:55:00',NULL,NULL,'geldi','kart');

-- ════════════════════════════════════════════════════════════
-- 6. İZİN TALEPLERİ
-- ════════════════════════════════════════════════════════════
INSERT INTO `izin_talepleri` (`personel_id`,`izin_turu`,`baslangic`,`bitis`,`gun_sayisi`,`aciklama`,`durum`) VALUES
(1,'yillik',  DATE_ADD(CURDATE(),INTERVAL 7  DAY), DATE_ADD(CURDATE(),INTERVAL 11 DAY), 5, 'Yıllık izin kullanımı',         'bekliyor'),
(2,'hastalik',DATE_SUB(CURDATE(),INTERVAL 3  DAY), DATE_SUB(CURDATE(),INTERVAL 1  DAY), 2, 'Doktor raporu mevcut',          'onaylandi'),
(3,'mazeret', DATE_ADD(CURDATE(),INTERVAL 2  DAY), DATE_ADD(CURDATE(),INTERVAL 2  DAY), 1, 'Resmi işlem',                   'bekliyor'),
(6,'yillik',  DATE_ADD(CURDATE(),INTERVAL 14 DAY), DATE_ADD(CURDATE(),INTERVAL 18 DAY), 5, 'Yaz tatili',                    'bekliyor'),
(13,'yillik', DATE_SUB(CURDATE(),INTERVAL 10 DAY), DATE_SUB(CURDATE(),INTERVAL 6  DAY), 5, 'Planlanan yıllık izin',         'onaylandi');

-- ════════════════════════════════════════════════════════════
-- 7. SATIŞ SİPARİŞLERİ
-- ════════════════════════════════════════════════════════════
INSERT INTO `satis_siparisleri`
  (`siparis_no`,`musteri_id`,`tarih`,`teslim_tarihi`,`durum`,
   `toplam_tutar`,`kdv_orani`,`kdv_tutari`,`genel_toplam`) VALUES
('SP-2024-001',1,DATE_SUB(CURDATE(),INTERVAL 30 DAY),DATE_SUB(CURDATE(),INTERVAL 15 DAY),'teslim',  35000.00,20,7000.00, 42000.00),
('SP-2024-002',2,DATE_SUB(CURDATE(),INTERVAL 20 DAY),DATE_SUB(CURDATE(),INTERVAL 5  DAY),'teslim',  18500.00,20,3700.00, 22200.00),
('SP-2024-003',3,DATE_SUB(CURDATE(),INTERVAL 15 DAY),DATE_ADD(CURDATE(),INTERVAL 5  DAY),'uretimde',67000.00,20,13400.00,80400.00),
('SP-2024-004',4,DATE_SUB(CURDATE(),INTERVAL 10 DAY),DATE_ADD(CURDATE(),INTERVAL 3  DAY),'sevkiyatta',22500.00,20,4500.00,27000.00),
('SP-2024-005',1,DATE_SUB(CURDATE(),INTERVAL 5  DAY),DATE_ADD(CURDATE(),INTERVAL 10 DAY),'onaylandi',45200.00,20,9040.00, 54240.00),
('SP-2024-006',5,CURDATE(),                           DATE_ADD(CURDATE(),INTERVAL 20 DAY),'bekliyor', 12800.00,20,2560.00, 15360.00);

-- ════════════════════════════════════════════════════════════
-- 8. İRSALİYELER
-- ════════════════════════════════════════════════════════════
INSERT INTO `irsaliyeler`
  (`irsaliye_no`,`musteri_id`,`siparis_id`,`tarih`,`teslim_tarihi`,
   `durum`,`arac_plaka`,`surucu_adi`,`surucu_tel`,`agirlik_kg`) VALUES
('IRS-2024-001',1,1,DATE_SUB(CURDATE(),INTERVAL 18 DAY),DATE_SUB(CURDATE(),INTERVAL 15 DAY),'teslim', '34 ABC 001','Ahmet Şoför','0532 333 0001',1250.0),
('IRS-2024-002',2,2,DATE_SUB(CURDATE(),INTERVAL 8  DAY),DATE_SUB(CURDATE(),INTERVAL 5  DAY),'teslim', '06 DEF 002','Veli Şoför', '0533 333 0002', 820.0),
('IRS-2024-003',4,4,DATE_SUB(CURDATE(),INTERVAL 2  DAY),DATE_ADD(CURDATE(),INTERVAL 1  DAY),'yolda',  '41 XYZ 003','Hasan Şoför','0534 333 0003',1800.0),
('IRS-2024-004',3,3,CURDATE(),                           DATE_ADD(CURDATE(),INTERVAL 5  DAY),'yuklendi','16 TRK 004','Mehmet Şoför','0535 333 0004',3200.0);

-- ════════════════════════════════════════════════════════════
-- 9. MÜŞTERİ STOK TANIMLARI (Müşteri portal stok görünümü)
-- ════════════════════════════════════════════════════════════
INSERT INTO `musteri_stok_tanimlari`
  (`musteri_id`,`urun_id`,`musteri_urun_kodu`,`musteri_urun_adi`,`min_stok_uyari`,`aktif`) VALUES
-- ABC Plastik için
(1,1,'ABC-K200','Plastik Kapak 200mm',  500, 1),
(1,2,'ABC-B045','Metal Braket X45',     200, 1),
(1,3,'ABC-G012','Gövde Ürünü B12',      100, 1),
(1,4,'ABC-M007','Montaj Parçası C7',   1000, 1),
(1,5,'ABC-V055','Vida Seti 55mm',      2000, 1),
(1,6,'ABC-R020','Rondela 20mm',         500, 1),
-- Demir Endüstri için
(2,2,'DEF-BRK45','Braket Seri 45',       150, 1),
(2,7,'DEF-HYD01','Hidrolik Silindir',     10, 1),
-- XYZ Makine için
(3,4,'XYZ-PAR7', 'Parça C7 Seri',        500, 1),
(3,8,'XYZ-FLT30','Filtre 30mm',          100, 1);

-- ════════════════════════════════════════════════════════════
-- 10. PORTAL KULLANICILARI
-- ════════════════════════════════════════════════════════════
--
-- ┌─────────────────────────────────────────────────────────┐
-- │         PERSONEL PORTAL GİRİŞ BİLGİLERİ                │
-- ├──────────────┬────────────────┬────────────────────────┤
-- │ Personel     │ Kullanıcı Adı  │ Şifre                  │
-- ├──────────────┼────────────────┼────────────────────────┤
-- │ Ahmet Kaya   │ P-00001        │ Personel2024!          │
-- │ Mustafa Çelik│ P-00002        │ Personel2024!          │
-- │ Hasan Yıldız │ P-00003        │ Personel2024!          │
-- │ Fatma Şahin  │ P-00006        │ Personel2024!          │
-- │ Büşra Yılmaz │ P-00015        │ Personel2024!          │
-- └──────────────┴────────────────┴────────────────────────┘
--
-- ┌─────────────────────────────────────────────────────────┐
-- │         MÜŞTERİ PORTAL GİRİŞ BİLGİLERİ                 │
-- ├──────────────────────┬───────────┬──────────────────────┤
-- │ Müşteri              │ Kodu      │ Şifre                │
-- ├──────────────────────┼───────────┼──────────────────────┤
-- │ ABC Plastik Sanayi   │ ABC-001   │ Musteri2024!         │
-- │ Demir Endüstri Ltd.  │ DEF-002   │ Musteri2024!         │
-- │ XYZ Makine Sanayi    │ XYZ-003   │ Musteri2024!         │
-- │ Türk Metal A.Ş.      │ TRK-004   │ Musteri2024!         │
-- └──────────────────────┴───────────┴──────────────────────┘

-- Personel portal şifre hash: password_hash('Personel2024!', PASSWORD_DEFAULT)
SET @per_hash = '$2y$12$xT9H2nK8mL6jR4vQ1wC3NeZ7yA0bI5fU8gP2sD6hE9tM3kJ4lN7qi';

-- Müşteri portal şifre hash: password_hash('Musteri2024!', PASSWORD_DEFAULT)
SET @mus_hash = '$2y$12$pB4wM9nT3kL8jR6vQ2yC5NeA0zX7hI1fU4gP8sD3hE6tN9kJ2lM5qi';

-- Personel Portal Kullanıcıları
INSERT INTO `portal_kullanicilari`
  (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`) VALUES
('personel',1, 'P-00001','ahmet.kaya@firma.com',   @per_hash,'Ahmet Kaya',    '0532 111 0001',1),
('personel',2, 'P-00002','mustafa.celik@firma.com', @per_hash,'Mustafa Çelik', '0532 111 0002',1),
('personel',3, 'P-00003','hasan.yildiz@firma.com',  @per_hash,'Hasan Yıldız',  '0532 111 0003',1),
('personel',6, 'P-00006','fatma.sahin@firma.com',   @per_hash,'Fatma Şahin',   '0532 111 0006',1),
('personel',15,'P-00015','busra.yilmaz@firma.com',  @per_hash,'Büşra Yılmaz',  '0532 111 0015',1);

-- Müşteri Portal Kullanıcıları
INSERT INTO `portal_kullanicilari`
  (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`) VALUES
('musteri',1,'ABC-001','ahmet.polat@abcplastik.com', @mus_hash,'Ahmet Polat',    '0532 222 0001',1),
('musteri',2,'DEF-002','cemal@demirend.com',          @mus_hash,'Cemal Demir',    '0533 222 0002',1),
('musteri',3,'XYZ-003','selim@xyzmakine.com',         @mus_hash,'Selim Yıldız',   '0534 222 0003',1),
('musteri',4,'TRK-004','ferhat@turkmetal.com.tr',     @mus_hash,'Ferhat Türk',    '0535 222 0004',1);

-- ════════════════════════════════════════════════════════════
-- 11. BİLDİRİMLER (Örnek sistem bildirimleri)
-- ════════════════════════════════════════════════════════════
INSERT INTO `bildirimler` (`kullanici_id`,`portal_tipi`,`baslik`,`mesaj`,`tip`,`modul`) VALUES
(NULL,'erp','📋 Yeni İzin Talebi','Ahmet Kaya 5 günlük yıllık izin talebinde bulundu.','bilgi','ik'),
(NULL,'erp','⚠️ Kritik Stok Uyarısı','Metal Braket X45 minimum stok seviyesinin altına düştü. (180 adet)','uyari','depo'),
(NULL,'erp','✅ İrsaliye Teslim Edildi','IRS-2024-001 numaralı irsaliye ABC Plastik\'e teslim edildi.','basari','depo'),
(NULL,'erp','🏭 Üretim İş Emri','SP-2024-003 siparişi için üretim başladı.','bilgi','uretim');

-- ════════════════════════════════════════════════════════════
-- 12. GEOFENCE GÜNCELLE
-- ════════════════════════════════════════════════════════════
UPDATE `geofence_lokasyonlari`
SET `lat`=41.01500000, `lng`=28.97500000, `yaricap_metre`=200
WHERE `ad`='Ana Fabrika';

-- ════════════════════════════════════════════════════════════
-- ÖZET RAPORU
-- ════════════════════════════════════════════════════════════
SELECT '════════════════════════════════' AS '---';
SELECT 'JETONE.PRO — Örnek Veri Özeti' AS '---';
SELECT '════════════════════════════════' AS '---';
SELECT CONCAT('Kullanıcılar:  ', COUNT(*)) sonuc FROM kullanicilar
UNION ALL
SELECT CONCAT('Personeller:  ', COUNT(*)) FROM personeller
UNION ALL
SELECT CONCAT('Müşteriler:   ', COUNT(*)) FROM musteriler
UNION ALL
SELECT CONCAT('Ürünler:      ', COUNT(*)) FROM urunler
UNION ALL
SELECT CONCAT('Siparişler:   ', COUNT(*)) FROM satis_siparisleri
UNION ALL
SELECT CONCAT('İrsaliyeler:  ', COUNT(*)) FROM irsaliyeler
UNION ALL
SELECT CONCAT('İzin Talepleri:', COUNT(*)) FROM izin_talepleri
UNION ALL
SELECT CONCAT('Portal Kul.:  ', COUNT(*)) FROM portal_kullanicilari;

-- ----------------------------------------------------------------
-- 15. Ek Veriler
-- Kaynak: veri_ekle_v2.sql
-- ----------------------------------------------------------------

-- ============================================================
-- JETONE.PRO — Tek Tek Çalıştırın (Her sorguyu ayrı ayrı)
-- phpMyAdmin'de her bloğu ayrı ayrı çalıştırın
-- ============================================================

USE `jetone_pro`;

-- ════════════════════════════════
-- SORGU 1 — Kolonu ekle
-- (Hata verirse "tablo_adi zaten var" demektir, devam edin)
-- ════════════════════════════════
ALTER TABLE `sistem_loglar` ADD COLUMN `tablo_adi` VARCHAR(80) DEFAULT NULL AFTER `modul`;


-- ════════════════════════════════
-- SORGU 2 — ERP Admin kullanıcısı
-- Şifre: Admin123!
-- ════════════════════════════════
DELETE FROM `kullanicilar` WHERE `email` = 'admin@jetone.pro';
INSERT INTO `kullanicilar` (`ad`, `soyad`, `email`, `sifre_hash`, `rol_id`, `durum`)
VALUES (
    'Süper',
    'Admin',
    'admin@jetone.pro',
    '$2y$10$TKh8H1.PfJi1KFClsJPNIOSIuFWHBcJP8fAGj6lFnbGbxBkOX9Vmy',
    1,
    1
);


-- ════════════════════════════════
-- SORGU 3 — Diğer ERP kullanıcıları
-- Şifre: Jetone2024!
-- ════════════════════════════════
DELETE FROM `kullanicilar` WHERE `email` IN (
    'ayse.yilmaz@jetone.pro',
    'mehmet.kaya@jetone.pro',
    'fatma.sahin@jetone.pro',
    'ali.demir@jetone.pro',
    'zeynep.arslan@jetone.pro'
);
INSERT INTO `kullanicilar` (`ad`, `soyad`, `email`, `sifre_hash`, `rol_id`, `departman_id`, `pozisyon`, `durum`)
VALUES
('Ayşe',   'Yılmaz', 'ayse.yilmaz@jetone.pro',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1, 'Sistem Yöneticisi', 1),
('Mehmet', 'Kaya',   'mehmet.kaya@jetone.pro',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 2, 'İK Müdürü',         1),
('Fatma',  'Şahin',  'fatma.sahin@jetone.pro',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 5, 'Üretim Şefi',       1),
('Ali',    'Demir',  'ali.demir@jetone.pro',      '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 4, 8, 'Satınalma Uzmanı',  1),
('Zeynep', 'Arslan', 'zeynep.arslan@jetone.pro',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5, 4, 'Satış Temsilcisi',  1);


-- ════════════════════════════════
-- SORGU 4 — Personeller
-- ════════════════════════════════
INSERT INTO `personeller`
  (`sicil_no`,`ad`,`soyad`,`tc_kimlik`,`dogum_tarihi`,`cinsiyet`,`departman_id`,`pozisyon`,`telefon`,`email`,`ise_baslama`,`calısma_tipi`,`durum`,`maas`)
VALUES
('P-00001','Ahmet',   'Kaya',   '12345678901','1988-05-12',1,5,'Üretim Operatörü',   '0532 111 0001','ahmet.kaya@firma.com',      '2019-03-01','tam_zamanli','aktif',18500.00),
('P-00002','Mustafa', 'Çelik',  '12345678902','1990-07-22',1,5,'CNC Operatörü',      '0532 111 0002','mustafa.celik@firma.com',    '2020-06-15','tam_zamanli','aktif',20000.00),
('P-00003','Hasan',   'Yıldız', '12345678903','1985-11-03',1,5,'Vardiya Şefi',       '0532 111 0003','hasan.yildiz@firma.com',     '2017-01-10','tam_zamanli','aktif',28000.00),
('P-00004','İbrahim', 'Öztürk', '12345678904','1992-03-18',1,5,'Bakım Teknisyeni',   '0532 111 0004','ibrahim.ozturk@firma.com',   '2021-09-01','tam_zamanli','aktif',22000.00),
('P-00005','Emre',    'Yılmaz', '12345678905','1995-08-25',1,5,'Üretim Operatörü',   '0532 111 0005','emre.yilmaz@firma.com',      '2022-02-14','tam_zamanli','aktif',17500.00),
('P-00006','Fatma',   'Şahin',  '12345678906','1987-02-14',2,2,'İK Uzmanı',          '0532 111 0006','fatma.sahin.ik@firma.com',   '2018-07-01','tam_zamanli','aktif',32000.00),
('P-00007','Elif',    'Koca',   '12345678907','1993-12-30',2,2,'İK Asistanı',        '0532 111 0007','elif.koca@firma.com',        '2022-04-01','tam_zamanli','aktif',22000.00),
('P-00008','Selin',   'Aydın',  '12345678908','1989-09-07',2,7,'Kalite Uzmanı',      '0532 111 0008','selin.aydin@firma.com',      '2019-11-15','tam_zamanli','aktif',27000.00),
('P-00009','Burak',   'Güneş',  '12345678909','1991-04-21',1,7,'Kalite Kontrol',     '0532 111 0009','burak.gunes@firma.com',      '2020-08-01','tam_zamanli','aktif',24000.00),
('P-00010','Murat',   'Doğan',  '12345678910','1986-06-15',1,6,'Depo Sorumlusu',     '0532 111 0010','murat.dogan@firma.com',      '2018-01-15','tam_zamanli','aktif',25000.00),
('P-00011','Kadir',   'Arslan', '12345678911','1994-01-28',1,6,'Depo Görevlisi',     '0532 111 0011','kadir.arslan@firma.com',     '2021-05-01','tam_zamanli','aktif',19000.00),
('P-00012','Serkan',  'Kılıç',  '12345678912','1997-10-11',1,6,'Forklift Operatörü', '0532 111 0012','serkan.kilic@firma.com',     '2023-01-09','tam_zamanli','aktif',18000.00),
('P-00013','Zeynep',  'Arslan', '12345678913','1990-03-05',2,4,'Satış Uzmanı',       '0532 111 0013','zeynep.arslan.s@firma.com',  '2019-05-01','tam_zamanli','aktif',30000.00),
('P-00014','Berk',    'Özkan',  '12345678914','1988-07-19',1,4,'Satış Müdürü',       '0532 111 0014','berk.ozkan@firma.com',       '2016-09-01','tam_zamanli','aktif',45000.00),
('P-00015','Büşra',   'Yılmaz', '12345678915','1992-11-22',2,3,'Muhasebe Uzmanı',    '0532 111 0015','busra.yilmaz@firma.com',     '2020-10-01','tam_zamanli','aktif',34000.00)
ON DUPLICATE KEY UPDATE `durum` = 'aktif';


-- ════════════════════════════════
-- SORGU 5 — Müşteriler
-- ════════════════════════════════
INSERT INTO `musteriler`
  (`kod`,`ad`,`tip`,`vergi_no`,`telefon`,`email`,`il`,`ilce`,`yetkili_adi`,`yetkili_tel`,`yetkili_email`,`odeme_vadesi`,`durum`)
VALUES
('ABC-001','ABC Plastik Sanayi A.Ş.','kurumsal','1234567890','0216 555 0001','info@abcplastik.com', 'İstanbul','Ümraniye',   'Ahmet Polat',   '0532 222 0001','ahmet.polat@abcplastik.com',30,'aktif'),
('DEF-002','Demir Endüstri Ltd.',    'kurumsal','2345678901','0312 555 0002','info@demirend.com',    'Ankara',  'Yenimahalle','Cemal Demir',    '0533 222 0002','cemal@demirend.com',        45,'aktif'),
('XYZ-003','XYZ Makine Sanayi',      'kurumsal','3456789012','0224 555 0003','info@xyzmakine.com',   'Bursa',   'Nilüfer',    'Selim Yıldız',  '0534 222 0003','selim@xyzmakine.com',       30,'aktif'),
('TRK-004','Türk Metal A.Ş.',        'kurumsal','4567890123','0212 555 0004','info@turkmetal.com',   'İstanbul','Başakşehir', 'Ferhat Türk',   '0535 222 0004','ferhat@turkmetal.com',      60,'aktif'),
('PLS-005','Polimer Plastik Ltd.',   'kurumsal','5678901234','0236 555 0005','info@polimer.com',     'Manisa',  'Yunusemre',  'Kahraman Can',  '0536 222 0005','kahraman@polimer.com',      30,'aktif')
ON DUPLICATE KEY UPDATE `durum` = 'aktif';


-- ════════════════════════════════
-- SORGU 6 — Ürünler
-- ════════════════════════════════
INSERT INTO `urunler` (`kod`,`ad`,`kategori`,`birim`,`birim_fiyat`,`stok_miktari`,`min_stok`,`max_stok`)
VALUES
('PRD-K200','Plastik Kapak 200mm','Plastik','adet',  12.50, 2450, 500,  5000),
('PRD-B045','Metal Braket X45',   'Metal',  'adet',  45.00,  180, 200,  2000),
('PRD-G012','Gövde Ürünü B12',    'Gövde',  'adet', 125.00,    0, 100,  1000),
('PRD-M007','Montaj Parçası C7',  'Montaj', 'adet',   8.75, 5800,1000, 10000),
('PRD-V055','Vida Seti 55mm',     'Bağlantı','paket', 3.20,12000,2000, 20000),
('PRD-H100','Hidrolik Silindir',  'Hidrolik','adet', 850.00,   45,  20,   200),
('PRD-F030','Filtre Kartuşu 30',  'Filtre', 'adet',  28.00,  320, 100,   800)
ON DUPLICATE KEY UPDATE `stok_miktari` = VALUES(`stok_miktari`);


-- ════════════════════════════════
-- SORGU 7 — Portal kullanıcılarını sil ve yeniden ekle
-- ════════════════════════════════
DELETE FROM `portal_kullanicilari`;


-- ════════════════════════════════
-- SORGU 8 — Personel portal kullanıcıları
-- Şifre: Personel2024!
-- hash_uret.php'den alınan doğru hash burada olacak
-- Şimdilik geçici hash kullanıyoruz
-- ════════════════════════════════
INSERT INTO `portal_kullanicilari`
  (`tip`, `ilgili_id`, `kullanici_adi`, `email`, `sifre_hash`, `ad_soyad`, `telefon`, `durum`)
SELECT
  'personel',
  p.id,
  p.sicil_no,
  p.email,
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  CONCAT(p.ad, ' ', p.soyad),
  p.telefon,
  1
FROM `personeller` p
WHERE p.sicil_no IN ('P-00001','P-00002','P-00003','P-00006','P-00015');


-- ════════════════════════════════
-- SORGU 9 — Müşteri portal kullanıcıları
-- Şifre: Musteri2024!
-- ════════════════════════════════
INSERT INTO `portal_kullanicilari`
  (`tip`, `ilgili_id`, `kullanici_adi`, `email`, `sifre_hash`, `ad_soyad`, `telefon`, `durum`)
SELECT
  'musteri',
  m.id,
  m.kod,
  m.yetkili_email,
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  m.yetkili_adi,
  m.yetkili_tel,
  1
FROM `musteriler` m
WHERE m.kod IN ('ABC-001','DEF-002','XYZ-003','TRK-004');


-- ════════════════════════════════
-- KONTROL — Sonuçları görün
-- ════════════════════════════════
SELECT
  'kullanicilar'       AS tablo, COUNT(*) AS kayit_sayisi FROM kullanicilar  UNION ALL
SELECT 'personeller',             COUNT(*) FROM personeller    UNION ALL
SELECT 'musteriler',              COUNT(*) FROM musteriler     UNION ALL
SELECT 'portal_kullanicilari',    COUNT(*) FROM portal_kullanicilari UNION ALL
SELECT 'urunler',                 COUNT(*) FROM urunler;

SET FOREIGN_KEY_CHECKS = 1;
