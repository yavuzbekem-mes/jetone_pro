-- miknatis_kontroller tablosuna ip_adresi kolonu ekle
ALTER TABLE `miknatis_kontroller`
  ADD COLUMN `ip_adresi` VARCHAR(45) NULL DEFAULT NULL COMMENT 'ESP32 IP adresi'
  AFTER `makina_kodu`;
