-- ================================================================
-- MIKNATİS CİHAZ TANIM GÜNCELLEMESİ
-- TKM-001 gibi eski kodları malzeme kodlarıyla değiştirir
-- phpMyAdmin'de çalıştırın
-- ================================================================

CREATE TABLE IF NOT EXISTS `miknatis_cihaz_tanim` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `makina_kodu` VARCHAR(20) NOT NULL,
  `urun_kodu`   VARCHAR(30) NOT NULL,
  `aktif`       TINYINT(1) NOT NULL DEFAULT 1,
  `guncelleme`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `guncelleyen` VARCHAR(100),
  UNIQUE KEY uk_makina (makina_kodu)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `miknatis_cihaz_tanim` (makina_kodu, urun_kodu, aktif, guncelleyen) VALUES
  ('KRT-01','2985310100',1,'admin'),
  ('KRT-02','2985310200',1,'admin'),
  ('KRT-03','2985310300',1,'admin'),
  ('KRT-04','2985310400',1,'admin'),
  ('KRT-05','2987910100',1,'admin'),
  ('KRT-06','2987910200',1,'admin'),
  ('KRT-07','2988080100',1,'admin'),
  ('KRT-08','2988080200',1,'admin')
ON DUPLICATE KEY UPDATE
  urun_kodu   = VALUES(urun_kodu),
  aktif       = VALUES(aktif),
  guncelleyen = VALUES(guncelleyen),
  guncelleme  = NOW();

-- Kontrol
SELECT makina_kodu, urun_kodu, aktif, guncelleme FROM miknatis_cihaz_tanim ORDER BY makina_kodu;
