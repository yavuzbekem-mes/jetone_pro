<?php
/**
 * Etiket Dışı Stok Kodları
 * Route: ayarlar-etiket-haric
 */
if(!defined('ROOT_DIR')) require_once dirname(__DIR__).'/core/config.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

global $db;

// Tablo yoksa oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS etiket_haric_kodlar (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        stok_kodu   VARCHAR(100) NOT NULL UNIQUE,
        aciklama    VARCHAR(255) DEFAULT '',
        ekleyen     VARCHAR(100) DEFAULT '',
        eklenme_tar DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch(Throwable $e) {}

$mesaj = ''; $hata = '';

// Sil
if(isset($_GET['sil']) && is_numeric($_GET['sil'])) {
    try {
        $db->prepare("DELETE FROM etiket_haric_kodlar WHERE id=?")->execute([(int)$_GET['sil']]);
        $mesaj = 'Kod silindi.';
    } catch(Throwable $e){ $hata = $e->getMessage(); }
}

// Ekle
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['stok_kodu'])) {
    $kul = Auth::kullanici(); $kul_adi='';
    if(is_array($kul)){
        if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
        elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    }
    $kodlar = array_filter(array_map('trim', explode("\n", strtoupper($_POST['stok_kodu']))));
    $aciklama = trim($_POST['aciklama']??'');
    $eklenen = 0; $atlanan = 0;
    foreach($kodlar as $kod) {
        if(!$kod) continue;
        try {
            $db->prepare("INSERT IGNORE INTO etiket_haric_kodlar (stok_kodu,aciklama,ekleyen) VALUES(?,?,?)")
               ->execute([$kod, $aciklama, $kul_adi]);
            $eklenen++;
        } catch(Throwable $e){ $atlanan++; }
    }
    $mesaj = "$eklenen kod eklendi" . ($atlanan?" ($atlanan zaten vardı)":'') . '.';
}

// Liste
$liste = $db->query("SELECT * FROM etiket_haric_kodlar ORDER BY eklenme_tar DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🚫 Etiket Dışı Stok Kodları</h1>
    <div class="s-yol">Ayarlar / <b>Etiket Dışı Kodlar</b></div>
  </div>
</div>

<div class="s-body">
<div>

<?php if($mesaj):?>
<div style="background:#D1FAE5;color:#065F46;padding:10px 16px;border-radius:var(--r);margin-bottom:14px;font-size:13px;font-weight:600">
  ✅ <?=htmlspecialchars($mesaj)?>
</div>
<?php endif;?>
<?php if($hata):?>
<div style="background:#FEF2F2;color:#7F1D1D;padding:10px 16px;border-radius:var(--r);margin-bottom:14px;font-size:13px">
  ⚠️ <?=htmlspecialchars($hata)?>
</div>
<?php endif;?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:16px;align-items:flex-start">

<!-- Sol: Ekle Formu -->
<div>
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #DC2626">
    <div style="padding:14px;background:#FEF2F2;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#DC2626">➕ Kod Ekle</div>
      <div style="font-size:11px;color:var(--m3);margin-top:2px">Birden fazla kod için her satıra bir kod girin</div>
    </div>
    <div style="padding:18px">
      <form method="POST" action="">
        <input type="hidden" name="sayfa" value="ayarlar-etiket-haric">
        <div style="margin-bottom:12px">
          <label class="form-et">Stok Kodu(ları) <span style="color:#DC2626">*</span></label>
          <textarea name="stok_kodu" class="form-alan" rows="5"
                    placeholder="2961440008&#10;E17651&#10;188957"
                    style="resize:vertical;text-transform:uppercase;font-family:monospace"
                    oninput="this.value=this.value.toUpperCase()"></textarea>
        </div>
        <div style="margin-bottom:16px">
          <label class="form-et">Açıklama (opsiyonel)</label>
          <input type="text" name="aciklama" class="form-alan" placeholder="Neden hariç tutulduğu...">
        </div>
        <button type="submit" class="btn" style="width:100%;padding:11px;background:#DC2626;color:#fff;font-weight:800">
          🚫 Listeye Ekle
        </button>
      </form>
    </div>
  </div>

  <div class="kart" style="padding:14px;margin-top:12px;background:#FEF3C7;border-left:4px solid #F59E0B">
    <div style="font-size:12px;color:#92400E;font-weight:700;margin-bottom:6px">⚠️ Nasıl Çalışır?</div>
    <div style="font-size:11px;color:#78350F;line-height:1.6">
      Bu listedeki stok kodlarına ait irsaliyeler, Satınalma → Etiket Al listesinde <b>görüntülenmez</b>.
      Etiket alınması gereken kodlar için kullanın.
    </div>
  </div>
</div>

<!-- Sağ: Mevcut Liste -->
<div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #6B7280">
  <div style="padding:14px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <span style="font-weight:800;font-size:13px">🚫 Hariç Tutulan Kodlar</span>
    <span style="font-size:12px;color:var(--m3);background:var(--kenar-a);padding:2px 10px;border-radius:12px"><?=count($liste)?> kod</span>
  </div>
  <?php if(empty($liste)):?>
  <div style="padding:30px;text-align:center;color:var(--m3)">
    <div style="font-size:32px;margin-bottom:8px">✅</div>
    <div>Henüz hariç tutulan kod yok.</div>
  </div>
  <?php else:?>
  <div style="overflow-y:auto;max-height:500px">
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead style="position:sticky;top:0;background:#1E293B;color:#fff">
      <tr>
        <th style="padding:8px 12px;text-align:left">Stok Kodu</th>
        <th style="padding:8px 12px;text-align:left">Açıklama</th>
        <th style="padding:8px 12px;text-align:left">Ekleyen</th>
        <th style="padding:8px 12px;text-align:left">Tarih</th>
        <th style="padding:8px 12px;text-align:center">Sil</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($liste as $i=>$row):?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$i%2===0?'#fff':'var(--kenar-a)'?>">
      <td style="padding:7px 12px;font-weight:800;font-family:monospace;color:#DC2626"><?=htmlspecialchars($row['stok_kodu'])?></td>
      <td style="padding:7px 12px;font-size:11px;color:var(--m2)"><?=htmlspecialchars($row['aciklama']??'')?></td>
      <td style="padding:7px 12px;font-size:11px;color:var(--m3)"><?=htmlspecialchars($row['ekleyen']??'')?></td>
      <td style="padding:7px 12px;font-size:11px;color:var(--m3)"><?=htmlspecialchars(substr($row['eklenme_tar']??'',0,16))?></td>
      <td style="padding:7px 12px;text-align:center">
        <a href="?sayfa=ayarlar-etiket-haric&sil=<?=$row['id']?>"
           onclick="return confirm('<?=htmlspecialchars($row['stok_kodu'])?> kodunu listeden çıkar?')"
           style="padding:3px 10px;background:#FEE2E2;color:#7F1D1D;border-radius:5px;font-size:11px;font-weight:700;text-decoration:none">✕</a>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

</div><!-- /grid -->
</div><!-- /max-width -->
</div><!-- /s-body -->
