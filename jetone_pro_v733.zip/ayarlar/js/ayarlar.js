// ayarlar/js/ayarlar.js

document.addEventListener('DOMContentLoaded', () => {

  // Genel Ayarlar formu
  const formGenel = document.getElementById('formGenelAyarlar');
  if (formGenel) {
    formGenel.addEventListener('submit', async e => {
      e.preventDefault();
      const btn = formGenel.querySelector('[type=submit]');
      JT.yukle(btn, true);
      const r = await JT.ajax('../ayarlar/ajax/genel-kaydet.php', JT.formVeri(formGenel));
      JT.yukle(btn, false);
      JT.bildirim(r.ok ? 'Ayarlar kaydedildi!' : (r.hata || 'Hata'), r.ok ? 'basari' : 'hata');
    });
  }

  const formBolgesel = document.getElementById('formBolgeselAyarlar');
  if (formBolgesel) {
    formBolgesel.addEventListener('submit', async e => {
      e.preventDefault();
      const btn = formBolgesel.querySelector('[type=submit]');
      JT.yukle(btn, true);
      const r = await JT.ajax('../ayarlar/ajax/genel-kaydet.php', JT.formVeri(formBolgesel));
      JT.yukle(btn, false);
      JT.bildirim(r.ok ? 'Bölgesel ayarlar kaydedildi!' : (r.hata || 'Hata'), r.ok ? 'basari' : 'hata');
    });
  }
});
