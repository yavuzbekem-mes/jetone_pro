<?php
/**
 * Ayarlar — ortak başlık & yetki kontrolü
 * Her ayarlar-X.php dosyası bu dosyayı include eder
 */
if (!defined('BASE_URL')) { header('Location: ../panel.php?sayfa=ayarlar-firma'); exit; }
Auth::zorunlu();
$kul       = Auth::kullanici();
$super_adm = ((int)($kul['rol_id'] ?? 0) === 1);
$A = [];
try { $A = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: []; } catch (Exception $e) {}
