<?php
require_once dirname(__DIR__).'/core/config.php';
require_once dirname(__DIR__).'/core/db.php';
require_once dirname(__DIR__).'/core/auth.php';
require_once dirname(__DIR__).'/core/baglanlogo.php';
Auth::zorunlu();

// Sadece Süper Admin görebilir
$kul     = Auth::kullanici();
$rol_id  = (int)($kul['rol_id'] ?? 0);
$rol_adi = '';
try { $rol_adi = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1") && ($tmp=$db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1")) && $tmp->execute([$rol_id]) ? $tmp->fetchColumn() : ''; } catch(Throwable $e){}
try { $rs=$db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1"); $rs->execute([$rol_id]); $rol_adi=$rs->fetchColumn()?:''; } catch(Throwable $e){}
$super = ($rol_id===1 || strtolower(trim($rol_adi))==='süper admin');
if (!$super) {
    echo '<div class="s-bar"><div><h1 class="s-bas">🔒 Erişim Reddedildi</h1></div></div>';
    echo '<div class="kart" style="padding:40px;text-align:center"><div style="font-size:48px">🔒</div><div style="font-size:16px;font-weight:700;margin-top:12px">Bu sayfa sadece Süper Admin erişimine açıktır.</div></div>';
    return;
}

$custom_sql     = trim($_POST['custom_sql'] ?? '');
$conn_sel       = $_POST['conn'] ?? 'db';
$custom_results = null;
$custom_error   = '';
$custom_table   = '';
$affected_rows  = null;
$deleted_rows   = [];
$exec_time      = 0;

if ($custom_sql !== '') {
    // Bağlantıyı seç
    $pdo_conn = match($conn_sel) {
        'mes_pdo'     => $mes_pdo     ?? null,
        'tigerdb_pdo' => $tigerdb_pdo ?? null,
        default       => $db,
    };

    if (!$pdo_conn instanceof PDO) {
        $custom_error = "Seçilen bağlantı (" . htmlspecialchars($conn_sel) . ") aktif değil veya bulunamadı.";
    } else {
        try {
            // DELETE öncesi kayıtları çek
            if (preg_match('/^\s*DELETE\s+FROM\s+(\S+)\s*(WHERE\s+.+)?$/is', $custom_sql, $m)) {
                try {
                    $sel = $pdo_conn->query("SELECT * FROM {$m[1]} " . ($m[2]??''));
                    $deleted_rows = $sel->fetchAll(PDO::FETCH_ASSOC);
                } catch(Throwable $e) {}
            }

            $t0   = microtime(true);
            $stmt = $pdo_conn->query($custom_sql);
            $exec_time = round((microtime(true)-$t0)*1000,1);
            $col_count = $stmt->columnCount();

            if ($col_count > 0) {
                $custom_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($custom_results)) {
                    $cols = array_keys($custom_results[0]);
                    $th = implode('', array_map(fn($c)=>"<th>".htmlspecialchars($c)."</th>", $cols));
                    $custom_table .= "<thead><tr>$th</tr></thead><tfoot><tr>$th</tr></tfoot><tbody>";
                    foreach ($custom_results as $row) {
                        $custom_table .= '<tr>' . implode('', array_map(fn($v)=>'<td>'.htmlspecialchars((string)($v??'')).'</td>', $row)) . '</tr>';
                    }
                    $custom_table .= '</tbody>';
                }
            } else {
                $affected_rows = $stmt->rowCount();
            }
        } catch(Throwable $e) {
            $custom_error = $e->getMessage();
        }
    }
}

$conn_labels = ['db'=>'MySQL (ERP)', 'mes_pdo'=>'MES SQL Server', 'tigerdb_pdo'=>'Tiger SQL Server'];
$conn_renk   = ['db'=>'#1D4ED8','mes_pdo'=>'#065F46','tigerdb_pdo'=>'#92400E'];
$db_durum = [
    'db'          => ($db instanceof PDO),
    'mes_pdo'     => (($mes_pdo ?? null) instanceof PDO),
    'tigerdb_pdo' => (($tigerdb_pdo ?? null) instanceof PDO),
];
?>
<style>
.sql-editor {
    width:100%; box-sizing:border-box;
    font-family:'Courier New',Courier,monospace;
    font-size:13px; line-height:1.6;
    border:2px solid #1E3A5F;
    border-radius:8px; padding:12px;
    background:#0F172A; color:#E2E8F0;
    resize:vertical; min-height:120px;
    outline:none;
}
.sql-editor:focus { border-color:#3B82F6; box-shadow:0 0 0 3px rgba(59,130,246,.2); }
.conn-radio { display:none; }
.conn-label {
    display:inline-flex; align-items:center; gap:6px;
    padding:7px 14px; border-radius:8px; cursor:pointer;
    border:2px solid #E2E8F0; font-size:12px; font-weight:700;
    transition:.15s; color:#374151;
}
.conn-radio:checked + .conn-label {
    border-color:var(--c); background:var(--c); color:#fff;
}
#sqlResTable th { background:#1E3A5F !important; color:#fff !important; }
#sqlResTable td, #sqlResTable th { border:1px solid #CBD5E1 !important; white-space:nowrap !important; font-size:12px; }
.sql-status { display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; padding:8px 14px; border-radius:8px; }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚙️ SQL Sorgu Konsolu</h1>
    <div class="s-yol">Ayarlar / <b>SQL Konsolu</b>
      <span style="background:#DC2626;color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:8px;margin-left:8px">SÜPER ADMİN</span>
    </div>
  </div>
</div>

<!-- Uyarı -->
<div style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#92400E;font-weight:600">
  ⚠️ Bu sayfa canlı veritabanına doğrudan sorgu çalıştırır. <code>DELETE</code>, <code>UPDATE</code>, <code>DROP</code> komutlarını dikkatli kullanın.
</div>

<!-- Editor Kartı -->
<div class="kart" style="padding:16px;margin-bottom:12px">
  <form method="POST" id="sqlForm">

    <!-- DB seçimi -->
    <div style="margin-bottom:12px">
      <label class="form-etiket" style="margin-bottom:8px;display:block">Veritabanı Bağlantısı</label>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <?php foreach($conn_labels as $k=>$lbl):
          $ok = $db_durum[$k];
          $c  = $conn_renk[$k];
        ?>
        <div>
          <input type="radio" name="conn" value="<?php echo $k;?>" id="conn_<?php echo $k;?>" class="conn-radio"
            <?php echo ($conn_sel===$k)?'checked':'';?> <?php echo $ok?'':'disabled';?>>
          <label for="conn_<?php echo $k;?>" class="conn-label" style="--c:<?php echo $c;?>;<?php echo $ok?'':'opacity:.45;cursor:not-allowed';?>">
            <span style="width:8px;height:8px;border-radius:50%;background:<?php echo $ok?'#16A34A':'#DC2626';?>;display:inline-block"></span>
            <?php echo $lbl;?>
            <?php if(!$ok):?><span style="font-size:9px;opacity:.7">(bağlı değil)</span><?php endif;?>
          </label>
        </div>
        <?php endforeach;?>
      </div>
    </div>

    <!-- SQL Editor -->
    <div style="margin-bottom:10px">
      <label class="form-etiket" style="margin-bottom:6px;display:flex;justify-content:space-between">
        <span>SQL Sorgusu</span>
        <span style="font-size:11px;color:#94A3B8;font-weight:400">Ctrl+Enter ile çalıştır</span>
      </label>
      <textarea name="custom_sql" id="sqlEditor" class="sql-editor" rows="6"
        placeholder="-- Örnek:&#10;SELECT TOP 10 * FROM LG_222_ITEMS&#10;&#10;-- veya MySQL:&#10;SELECT * FROM kullanicilar LIMIT 10"><?php echo htmlspecialchars($custom_sql);?></textarea>
    </div>

    <!-- Butonlar -->
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">
        ▶ Çalıştır
      </button>
      <button type="button" onclick="document.getElementById('sqlEditor').value=''"
        style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 16px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">
        🗑 Temizle
      </button>
      <!-- Örnek sorgular -->
      <div style="margin-left:auto;display:flex;gap:6px;flex-wrap:wrap">
        <?php
        $ornekler = [
            ['MySQL Kullanıcılar','SELECT id,ad,soyad,email FROM kullanicilar LIMIT 20','db'],
            ['Tiger Stok','SELECT TOP 20 CODE,NAME,STGRPCODE FROM LG_222_ITEMS WHERE CARDTYPE NOT IN(4,22)','tigerdb_pdo'],
            ['MES Paketler','SELECT TOP 20 PAKET_NO,STOK_KODU,MIKTAR,AMBAR,AKTIF FROM MES..PAKETLER','mes_pdo'],
        ];
        foreach($ornekler as [$ad,$sql,$cn]):?>
        <button type="button" class="ornek-btn"
          onclick="document.getElementById('sqlEditor').value=<?php echo json_encode($sql);?>;document.querySelector('input[value=\'<?php echo $cn;?>\']').checked=true"
          style="background:#F8FAFC;border:1px solid #E2E8F0;color:#374151;padding:5px 10px;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer">
          <?php echo htmlspecialchars($ad);?>
        </button>
        <?php endforeach;?>
      </div>
    </div>

  </form>
</div>

<!-- Sonuç -->
<?php if($custom_sql !== ''): ?>
<div class="kart" style="overflow:hidden;padding:0">
  <!-- Sonuç başlığı -->
  <div style="padding:10px 14px;background:#F8FAFC;border-bottom:1px solid #E2E8F0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span style="font-size:12px;font-weight:700;color:#374151">Sorgu Sonucu</span>
      <span style="background:<?php echo $conn_renk[$conn_sel]??'#374151';?>;color:#fff;padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700">
        <?php echo $conn_labels[$conn_sel]??$conn_sel;?>
      </span>
      <?php if($exec_time>0):?>
      <span style="background:#E0F2FE;color:#0369A1;padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700">⏱ <?php echo $exec_time;?>ms</span>
      <?php endif;?>
    </div>
    <?php if(!empty($custom_results)):?>
    <span style="background:#D1FAE5;color:#065F46;padding:3px 10px;border-radius:8px;font-size:11px;font-weight:700">
      <?php echo count($custom_results);?> satır
    </span>
    <?php endif;?>
  </div>

  <?php if($custom_error): ?>
  <div style="padding:16px">
    <div style="background:#FEE2E2;border:1px solid #FECACA;border-radius:8px;padding:12px 16px">
      <div style="font-weight:700;color:#991B1B;margin-bottom:4px">❌ Hata</div>
      <code style="font-size:12px;color:#7F1D1D;word-break:break-all"><?php echo htmlspecialchars($custom_error);?></code>
    </div>
  </div>

  <?php elseif($affected_rows !== null): ?>
  <div style="padding:16px">
    <div style="background:#D1FAE5;border:1px solid #86EFAC;border-radius:8px;padding:12px 16px">
      <div style="font-weight:700;color:#065F46;margin-bottom:4px">✅ Sorgu Tamamlandı</div>
      <div style="font-size:13px;color:#065F46">Etkilenen satır sayısı: <strong><?php echo $affected_rows;?></strong></div>
    </div>
    <?php if(!empty($deleted_rows)):?>
    <div style="margin-top:12px">
      <div style="font-size:12px;font-weight:700;color:#374151;margin-bottom:6px">🗂 Silinen Kayıtlar (<?php echo count($deleted_rows);?> adet):</div>
      <div style="overflow-x:auto">
      <table id="sqlResTable" style="width:100%;border-collapse:collapse">
        <thead><tr><?php foreach(array_keys($deleted_rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></thead>
        <tfoot><tr><?php foreach(array_keys($deleted_rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></tfoot>
        <tbody>
        <?php foreach($deleted_rows as $r): ?>
        <tr><?php foreach($r as $v) echo '<td>'.htmlspecialchars((string)($v??'')).'</td>';?></tr>
        <?php endforeach;?>
        </tbody>
      </table>
      </div>
    </div>
    <?php endif;?>
  </div>

  <?php elseif(!empty($custom_results)): ?>
  <div style="overflow-x:auto">
  <table id="sqlResTable" style="width:100%;border-collapse:collapse">
    <?php echo $custom_table;?>
  </table>
  </div>

  <?php else: ?>
  <div style="padding:30px;text-align:center;color:#94A3B8;font-size:13px">Sorgu herhangi bir sonuç döndürmedi.</div>
  <?php endif;?>
</div>
<?php endif;?>

<script>
// Ctrl+Enter ile gönder
document.getElementById('sqlEditor').addEventListener('keydown',function(e){
    if(e.ctrlKey && e.key==='Enter'){
        e.preventDefault();
        document.getElementById('sqlForm').submit();
    }
});
// Tab tuşu ile girinti
document.getElementById('sqlEditor').addEventListener('keydown',function(e){
    if(e.key==='Tab'){
        e.preventDefault();
        var s=this.selectionStart,en=this.selectionEnd;
        this.value=this.value.substring(0,s)+'    '+this.value.substring(en);
        this.selectionStart=this.selectionEnd=s+4;
    }
});
</script>
<?php if(!empty($custom_results)||!empty($deleted_rows)):?>
<script>
$(document).ready(function(){
    var tbl = $('#sqlResTable');
    if(tbl.find('tbody tr').length > 0) {
        tbl.DataTable({
            initComplete:function(){
                this.api().columns().every(function(){
                    var col=this,th=$(col.footer());if(!th||!th.length)return;
                    var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                        .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                    col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
                });
            },
            language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
            scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
            dom:'Bfrtip',
            buttons:[
                {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'sql_sorgu_<?php echo date("Ymd_His");?>'},
                'copyHtml5','print'
            ]
        });
    }
});
</script>
<?php endif;?>
