<?php
require_once dirname(__DIR__).'/core/config.php';
require_once dirname(__DIR__).'/core/db.php';
require_once dirname(__DIR__).'/core/auth.php';
Auth::zorunlu();

// Tablo oluştur (yoksa)
try {
    $db->exec("CREATE TABLE IF NOT EXISTS menu_moduller (
        id INT AUTO_INCREMENT PRIMARY KEY,
        modul_id VARCHAR(30) NOT NULL,
        baslik VARCHAR(60) NOT NULL,
        ikon VARCHAR(10) DEFAULT '📋',
        renk VARCHAR(20) DEFAULT '#E0F2FE',
        sira INT DEFAULT 0,
        aktif TINYINT(1) DEFAULT 1,
        UNIQUE KEY modul_id (modul_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS menu_gruplar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        modul_id VARCHAR(30) NOT NULL,
        grup_adi VARCHAR(60) NOT NULL,
        sira INT DEFAULT 0,
        aktif TINYINT(1) DEFAULT 1,
        KEY modul_id (modul_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS menu_sayfalar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        grup_id INT NOT NULL,
        modul_id VARCHAR(30) NOT NULL,
        sayfa_id VARCHAR(60) NOT NULL,
        baslik VARCHAR(80) NOT NULL,
        ikon VARCHAR(10) DEFAULT '📄',
        sira INT DEFAULT 0,
        aktif TINYINT(1) DEFAULT 1,
        UNIQUE KEY sayfa_id (sayfa_id),
        KEY grup_id (grup_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS menu_rol_yetki (
        id INT AUTO_INCREMENT PRIMARY KEY,
        rol VARCHAR(40) NOT NULL,
        sayfa_id VARCHAR(60) NOT NULL,
        UNIQUE KEY rol_sayfa (rol, sayfa_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

$mesaj = $mesaj_tip = '';
$aktif_tab = $_GET['tab'] ?? 'sayfalar';

// ─── POST İŞLEMLERİ ──────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $islem = $_POST['islem'] ?? '';

    // Sayfa ekle/güncelle
    if ($islem === 'sayfa_kaydet') {
        $id       = (int)($_POST['id']??0);
        $grup_id  = (int)$_POST['grup_id'];
        $modul_id = trim($_POST['modul_id']??'');
        $sayfa_id = trim($_POST['sayfa_id']??'');
        $baslik   = trim($_POST['baslik']??'');
        $ikon     = trim($_POST['ikon']??'📄');
        $sira     = (int)($_POST['sira']??0);
        $aktif    = isset($_POST['aktif'])?1:0;
        if (!$sayfa_id||!$baslik||!$grup_id) { $mesaj='Zorunlu alanları doldurun.';$mesaj_tip='hata'; }
        else {
            if ($id) {
                $db->prepare("UPDATE menu_sayfalar SET grup_id=?,modul_id=?,sayfa_id=?,baslik=?,ikon=?,sira=?,aktif=? WHERE id=?")
                   ->execute([$grup_id,$modul_id,$sayfa_id,$baslik,$ikon,$sira,$aktif,$id]);
                $mesaj='Sayfa güncellendi.';
            } else {
                $db->prepare("INSERT INTO menu_sayfalar (grup_id,modul_id,sayfa_id,baslik,ikon,sira,aktif) VALUES (?,?,?,?,?,?,?)")
                   ->execute([$grup_id,$modul_id,$sayfa_id,$baslik,$ikon,$sira,$aktif]);
                $mesaj='Sayfa eklendi.';
            }
            $mesaj_tip='basarili';
        }
    }

    // Sayfa sil
    if ($islem === 'sayfa_sil') {
        $db->prepare("DELETE FROM menu_sayfalar WHERE id=?")->execute([(int)$_POST['id']]);
        $db->prepare("DELETE FROM menu_rol_yetki WHERE sayfa_id=?")->execute([$_POST['sayfa_id']??'']);
        $mesaj='Sayfa silindi.'; $mesaj_tip='basarili';
    }

    // Grup ekle/güncelle
    if ($islem === 'grup_kaydet') {
        $id       = (int)($_POST['id']??0);
        $modul_id = trim($_POST['modul_id']??'');
        $grup_adi = trim($_POST['grup_adi']??'');
        $sira     = (int)($_POST['sira']??0);
        $aktif    = isset($_POST['aktif'])?1:0;
        if (!$modul_id||!$grup_adi) { $mesaj='Zorunlu alanları doldurun.';$mesaj_tip='hata'; }
        else {
            if ($id) {
                $db->prepare("UPDATE menu_gruplar SET modul_id=?,grup_adi=?,sira=?,aktif=? WHERE id=?")->execute([$modul_id,$grup_adi,$sira,$aktif,$id]);
                $mesaj='Grup güncellendi.';
            } else {
                $db->prepare("INSERT INTO menu_gruplar (modul_id,grup_adi,sira,aktif) VALUES (?,?,?,?)")->execute([$modul_id,$grup_adi,$sira,$aktif]);
                $mesaj='Grup eklendi.';
            }
            $mesaj_tip='basarili';
        }
    }

    // Grup sil
    if ($islem === 'grup_sil') {
        $db->prepare("DELETE FROM menu_gruplar WHERE id=?")->execute([(int)$_POST['id']]);
        $mesaj='Grup silindi.'; $mesaj_tip='basarili';
    }

    // Yetki kaydet
    if ($islem === 'yetki_kaydet') {
        $rol = trim($_POST['rol']??'');
        if ($rol) {
            $db->prepare("DELETE FROM menu_rol_yetki WHERE rol=?")->execute([$rol]);
            $sayfalar = $_POST['sayfalar']??[];
            foreach($sayfalar as $sid) {
                try { $db->prepare("INSERT INTO menu_rol_yetki (rol,sayfa_id) VALUES (?,?)")->execute([$rol,$sid]); } catch(Throwable $e){}
            }
            $mesaj='Yetkiler kaydedildi.'; $mesaj_tip='basarili';
        }
    }
}

// ─── VERİ ÇEK ────────────────────────────────────────────────────────────────
$moduller = $db->query("SELECT * FROM menu_moduller ORDER BY sira,baslik")->fetchAll(PDO::FETCH_ASSOC);
$gruplar  = $db->query("SELECT g.*,m.baslik modul_baslik FROM menu_gruplar g LEFT JOIN menu_moduller m ON g.modul_id=m.modul_id ORDER BY g.modul_id,g.sira,g.grup_adi")->fetchAll(PDO::FETCH_ASSOC);
$sayfalar = $db->query("SELECT s.*,g.grup_adi,m.baslik modul_baslik FROM menu_sayfalar s LEFT JOIN menu_gruplar g ON s.grup_id=g.id LEFT JOIN menu_moduller m ON s.modul_id=m.modul_id ORDER BY s.modul_id,s.sira,s.baslik")->fetchAll(PDO::FETCH_ASSOC);

// Roller (users tablosundan)
$roller = [];
try { $roller = $db->query("SELECT DISTINCT rol FROM users WHERE rol IS NOT NULL AND rol!='' ORDER BY rol")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e){}
if (empty($roller)) $roller = ['admin','depo','satis','satinalma','planlama','kalite','uretim'];

$sel_rol = $_GET['rol'] ?? ($roller[0]??'admin');
$rol_yetkileri = [];
try {
    $ry = $db->prepare("SELECT sayfa_id FROM menu_rol_yetki WHERE rol=?");
    $ry->execute([$sel_rol]);
    $rol_yetkileri = $ry->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e){}
?>
<style>
.my-tabs { display:flex;gap:4px;margin-bottom:14px;flex-wrap:wrap }
.my-tab  { padding:7px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;border:2px solid #E2E8F0;background:#F8FAFC;color:#374151;text-decoration:none }
.my-tab.aktif { background:#1E3A5F;color:#fff;border-color:#1E3A5F }
.my-form { background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:14px;margin-bottom:12px }
.my-form-row { display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:10px }
#tblSayfalar th, #tblGruplar th { background:#1E3A5F !important; color:#fff !important; }
#tblSayfalar td, #tblSayfalar th, #tblGruplar td, #tblGruplar th { border:1px solid #000 !important; white-space:nowrap !important; }
.yetki-modul { background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:10px;overflow:hidden }
.yetki-modul-head { background:#1E3A5F;color:#fff;padding:8px 14px;font-weight:700;font-size:12px;display:flex;align-items:center;justify-content:space-between }
.yetki-grup { padding:6px 14px;border-bottom:1px solid #F1F5F9 }
.yetki-grup-ad { font-size:10px;font-weight:700;color:#94A3B8;text-transform:uppercase;margin-bottom:4px }
.yetki-cbx-row { display:flex;flex-wrap:wrap;gap:8px }
.yetki-cbx { display:flex;align-items:center;gap:5px;font-size:12px;cursor:pointer }
.yetki-cbx input { width:15px;height:15px;cursor:pointer }
</style>

<div class="s-bar">
  <div><h1 class="s-bas">⚙️ Menü Yönetimi</h1>
    <div class="s-yol">Ayarlar / <b>Dinamik Menü & Rol Yetkileri</b></div>
  </div>
</div>

<?php if($mesaj):?>
<div style="background:<?php echo $mesaj_tip==='basarili'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $mesaj_tip==='basarili'?'#065F46':'#991B1B';?>;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-weight:600">
  <?php echo $mesaj_tip==='basarili'?'✅':'❌';?> <?php echo htmlspecialchars($mesaj);?>
</div>
<?php endif;?>

<!-- Sekmeler -->
<div class="my-tabs">
  <a href="?sayfa=ayarlar-menu&tab=sayfalar" class="my-tab <?php echo $aktif_tab==='sayfalar'?'aktif':'';?>">📄 Sayfalar</a>
  <a href="?sayfa=ayarlar-menu&tab=gruplar"  class="my-tab <?php echo $aktif_tab==='gruplar'?'aktif':'';?>">📂 Gruplar</a>
  <a href="?sayfa=ayarlar-menu&tab=yetkiler" class="my-tab <?php echo $aktif_tab==='yetkiler'?'aktif':'';?>">🔑 Rol Yetkileri</a>
  <a href="?sayfa=ayarlar-menu&tab=sql"      class="my-tab <?php echo $aktif_tab==='sql'?'aktif':'';?>">🗃 SQL Oluştur</a>
</div>

<?php if($aktif_tab==='sayfalar'): ?>
<!-- SAYFALAR TAB -->
<div class="my-form">
  <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:10px" id="sayfaFormBaslik">➕ Yeni Sayfa Ekle</div>
  <form method="POST">
    <input type="hidden" name="islem" value="sayfa_kaydet">
    <input type="hidden" name="id" id="sfId" value="0">
    <div class="my-form-row">
      <div><label class="form-etiket">Grup *</label>
        <select name="grup_id" id="sfGrupId" class="form-alan">
          <option value="">— Grup Seçin —</option>
          <?php foreach($gruplar as $g):?>
          <option value="<?php echo $g['id'];?>"><?php echo htmlspecialchars($g['modul_baslik']??$g['modul_id']);?> / <?php echo htmlspecialchars($g['grup_adi']);?></option>
          <?php endforeach;?>
        </select></div>
      <div><label class="form-etiket">Modül *</label>
        <select name="modul_id" id="sfModulId" class="form-alan">
          <?php foreach($moduller as $m):?>
          <option value="<?php echo $m['modul_id'];?>"><?php echo htmlspecialchars($m['baslik']);?></option>
          <?php endforeach;?>
        </select></div>
      <div><label class="form-etiket">Sayfa ID (Route) *</label>
        <input type="text" name="sayfa_id" id="sfSayfaId" class="form-alan" placeholder="depo-stok"></div>
      <div><label class="form-etiket">Başlık *</label>
        <input type="text" name="baslik" id="sfBaslik" class="form-alan" placeholder="Stok Raporu"></div>
      <div><label class="form-etiket">İkon</label>
        <input type="text" name="ikon" id="sfIkon" class="form-alan" placeholder="📦" style="font-size:18px"></div>
      <div><label class="form-etiket">Sıra</label>
        <input type="number" name="sira" id="sfSira" class="form-alan" value="0"></div>
      <div style="display:flex;align-items:flex-end">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;padding:8px 0">
          <input type="checkbox" name="aktif" id="sfAktif" checked style="width:16px;height:16px"> Aktif
        </label>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
      <button type="button" onclick="sayfaFormTemizle()" style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">✕ Temizle</button>
    </div>
  </form>
</div>

<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblSayfalar" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:80px;text-align:center">İşlem</th>
    <th>İkon</th><th>Başlık</th><th>Sayfa ID</th>
    <th>Modül</th><th>Grup</th>
    <th style="text-align:center">Sıra</th><th style="text-align:center">Aktif</th>
  </tr></thead>
  <tfoot><tr><th>İşlem</th><th>İkon</th><th>Başlık</th><th>Sayfa ID</th><th>Modül</th><th>Grup</th><th>Sıra</th><th>Aktif</th></tr></tfoot>
  <tbody>
  <?php foreach($sayfalar as $s):?>
  <tr>
    <td style="text-align:center;white-space:nowrap">
      <button onclick="sayfaDuzenle(<?php echo htmlspecialchars(json_encode($s));?>)"
        style="background:#0369A1;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer;margin-right:3px">✏️</button>
      <form method="POST" style="display:inline" onsubmit="return confirm('Silmek istiyor musunuz?')">
        <input type="hidden" name="islem" value="sayfa_sil">
        <input type="hidden" name="id" value="<?php echo $s['id'];?>">
        <input type="hidden" name="sayfa_id" value="<?php echo htmlspecialchars($s['sayfa_id']);?>">
        <button type="submit" style="background:#DC2626;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer">🗑</button>
      </form>
    </td>
    <td style="font-size:16px;text-align:center"><?php echo $s['ikon'];?></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($s['baslik']);?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px"><?php echo htmlspecialchars($s['sayfa_id']);?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($s['modul_baslik']??$s['modul_id']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($s['grup_adi']??'');?></td>
    <td style="text-align:center"><?php echo $s['sira'];?></td>
    <td style="text-align:center">
      <span style="background:<?php echo $s['aktif']?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $s['aktif']?'#065F46':'#991B1B';?>;padding:2px 8px;border-radius:100px;font-size:10px;font-weight:700">
        <?php echo $s['aktif']?'✅':'❌';?>
      </span>
    </td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<script>
function sayfaDuzenle(s) {
    document.getElementById('sfId').value      = s.id;
    document.getElementById('sfGrupId').value  = s.grup_id;
    document.getElementById('sfModulId').value = s.modul_id;
    document.getElementById('sfSayfaId').value = s.sayfa_id;
    document.getElementById('sfBaslik').value  = s.baslik;
    document.getElementById('sfIkon').value    = s.ikon;
    document.getElementById('sfSira').value    = s.sira;
    document.getElementById('sfAktif').checked = s.aktif==1;
    document.getElementById('sayfaFormBaslik').textContent = '✏️ Sayfa Düzenle: ' + s.baslik;
    window.scrollTo(0,0);
}
function sayfaFormTemizle() {
    document.getElementById('sfId').value='0';
    document.getElementById('sfSayfaId').value='';
    document.getElementById('sfBaslik').value='';
    document.getElementById('sfIkon').value='📄';
    document.getElementById('sfSira').value='0';
    document.getElementById('sfAktif').checked=true;
    document.getElementById('sayfaFormBaslik').textContent='➕ Yeni Sayfa Ekle';
}
$(document).ready(function(){
    $('#tblSayfalar').DataTable({
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'400px',paging:false,scrollX:true,
        columnDefs:[{orderable:false,targets:0}],
        dom:'Bfrtip',buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt'}]
    });
});
</script>

<?php elseif($aktif_tab==='gruplar'): ?>
<!-- GRUPLAR TAB -->
<div class="my-form">
  <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:10px" id="grupFormBaslik">➕ Yeni Grup Ekle</div>
  <form method="POST">
    <input type="hidden" name="islem" value="grup_kaydet">
    <input type="hidden" name="id" id="gId" value="0">
    <div class="my-form-row">
      <div><label class="form-etiket">Modül *</label>
        <select name="modul_id" id="gModulId" class="form-alan">
          <?php foreach($moduller as $m):?>
          <option value="<?php echo $m['modul_id'];?>"><?php echo htmlspecialchars($m['baslik']);?></option>
          <?php endforeach;?>
        </select></div>
      <div><label class="form-etiket">Grup Adı *</label>
        <input type="text" name="grup_adi" id="gGrupAdi" class="form-alan" placeholder="STOK" style="text-transform:uppercase"></div>
      <div><label class="form-etiket">Sıra</label>
        <input type="number" name="sira" id="gSira" class="form-alan" value="0"></div>
      <div style="display:flex;align-items:flex-end">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;padding:8px 0">
          <input type="checkbox" name="aktif" id="gAktif" checked style="width:16px;height:16px"> Aktif
        </label>
      </div>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
  </form>
</div>
<div class="kart" style="overflow:hidden;padding:0">
<table id="tblGruplar" style="width:100%;border-collapse:collapse">
  <thead><tr><th style="width:80px;text-align:center">İşlem</th><th>Modül</th><th>Grup Adı</th><th style="text-align:center">Sıra</th><th style="text-align:center">Aktif</th></tr></thead>
  <tfoot><tr><th>İşlem</th><th>Modül</th><th>Grup Adı</th><th>Sıra</th><th>Aktif</th></tr></tfoot>
  <tbody>
  <?php foreach($gruplar as $g):?>
  <tr>
    <td style="text-align:center;white-space:nowrap">
      <button onclick="grupDuzenle(<?php echo htmlspecialchars(json_encode($g));?>)"
        style="background:#0369A1;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer;margin-right:3px">✏️</button>
      <form method="POST" style="display:inline" onsubmit="return confirm('Silmek istiyor musunuz?')">
        <input type="hidden" name="islem" value="grup_sil">
        <input type="hidden" name="id" value="<?php echo $g['id'];?>">
        <button type="submit" style="background:#DC2626;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer">🗑</button>
      </form>
    </td>
    <td style="font-size:11px"><?php echo htmlspecialchars($g['modul_baslik']??$g['modul_id']);?></td>
    <td style="font-weight:700"><?php echo htmlspecialchars($g['grup_adi']);?></td>
    <td style="text-align:center"><?php echo $g['sira'];?></td>
    <td style="text-align:center">
      <span style="background:<?php echo $g['aktif']?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $g['aktif']?'#065F46':'#991B1B';?>;padding:2px 8px;border-radius:100px;font-size:10px;font-weight:700">
        <?php echo $g['aktif']?'✅':'❌';?>
      </span>
    </td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
<script>
function grupDuzenle(g) {
    document.getElementById('gId').value=''+g.id;
    document.getElementById('gModulId').value=g.modul_id;
    document.getElementById('gGrupAdi').value=g.grup_adi;
    document.getElementById('gSira').value=g.sira;
    document.getElementById('gAktif').checked=g.aktif==1;
    document.getElementById('grupFormBaslik').textContent='✏️ Grup Düzenle: '+g.grup_adi;
    window.scrollTo(0,0);
}
$(document).ready(function(){$('#tblGruplar').DataTable({language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},paging:false,scrollX:true,dom:'Bfrtip',buttons:['excelHtml5'],columnDefs:[{orderable:false,targets:0}]});});
</script>

<?php elseif($aktif_tab==='yetkiler'): ?>
<!-- YETKİLER TAB -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
  <span style="font-size:12px;font-weight:700;color:#374151">Rol Seç:</span>
  <?php foreach($roller as $r):?>
  <a href="?sayfa=ayarlar-menu&tab=yetkiler&rol=<?php echo urlencode($r);?>"
     style="padding:5px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none;background:<?php echo $r===$sel_rol?'#1E3A5F':'#F1F5F9';?>;color:<?php echo $r===$sel_rol?'#fff':'#374151';?>;border:1px solid <?php echo $r===$sel_rol?'#1E3A5F':'#E2E8F0';?>">
    <?php echo htmlspecialchars($r);?>
  </a>
  <?php endforeach;?>
</div>

<form method="POST">
  <input type="hidden" name="islem" value="yetki_kaydet">
  <input type="hidden" name="rol" value="<?php echo htmlspecialchars($sel_rol);?>">

  <div style="font-size:13px;font-weight:700;color:#1E3A5F;margin-bottom:10px">
    🔑 <b><?php echo htmlspecialchars($sel_rol);?></b> rolü için sayfa yetkileri
  </div>

  <?php
  // Modül → Grup → Sayfa hiyerarşisini oluştur
  $hiyerarsi = [];
  foreach($sayfalar as $s) {
      $mid = $s['modul_id'];
      $gad = $s['grup_adi'] ?? 'Diğer';
      if(!isset($hiyerarsi[$mid])) $hiyerarsi[$mid]=['baslik'=>$s['modul_baslik']??$mid,'gruplar'=>[]];
      if(!isset($hiyerarsi[$mid]['gruplar'][$gad])) $hiyerarsi[$mid]['gruplar'][$gad]=[];
      $hiyerarsi[$mid]['gruplar'][$gad][]=$s;
  }
  foreach($hiyerarsi as $mid=>$modul):?>
  <div class="yetki-modul">
    <div class="yetki-modul-head">
      <span><?php echo htmlspecialchars($modul['baslik']);?></span>
      <label style="display:flex;align-items:center;gap:5px;font-size:11px;cursor:pointer;font-weight:400">
        <input type="checkbox" class="modul-hepsi" data-modul="<?php echo $mid;?>"
          onchange="modulHepsi(this,'<?php echo $mid;?>')"> Hepsini Seç
      </label>
    </div>
    <?php foreach($modul['gruplar'] as $gad=>$grp_sayfalar):?>
    <div class="yetki-grup">
      <div class="yetki-grup-ad"><?php echo htmlspecialchars($gad);?></div>
      <div class="yetki-cbx-row">
        <?php foreach($grp_sayfalar as $s):
          $checked = in_array($s['sayfa_id'],$rol_yetkileri)?'checked':'';
        ?>
        <label class="yetki-cbx">
          <input type="checkbox" name="sayfalar[]" value="<?php echo htmlspecialchars($s['sayfa_id']);?>"
            class="modul-cbx-<?php echo $mid;?>" <?php echo $checked;?>>
          <?php echo $s['ikon'];?> <?php echo htmlspecialchars($s['baslik']);?>
        </label>
        <?php endforeach;?>
      </div>
    </div>
    <?php endforeach;?>
  </div>
  <?php endforeach;?>

  <div style="margin-top:14px">
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:10px 24px;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer">💾 Yetkileri Kaydet</button>
  </div>
</form>
<script>
function modulHepsi(cb, mid) {
    document.querySelectorAll('.modul-cbx-'+mid).forEach(function(c){ c.checked=cb.checked; });
}
</script>

<?php elseif($aktif_tab==='sql'): ?>
<!-- SQL TAB -->
<div class="kart" style="padding:14px">
  <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:10px">🗃 Mevcut Menü Yapısını SQL Olarak İndir</div>
  <p style="font-size:12px;color:#64748B;margin-bottom:10px">
    Aşağıdaki SQL dosyasını veritabanınıza çalıştırarak tabloları ve depo menü kayıtlarını oluşturabilirsiniz.
    <a href="<?php echo BASE_URL;?>/veritabani_menu.sql" style="color:#1D4ED8;font-weight:700" download>📥 veritabani_menu.sql İndir</a>
  </p>
  <div style="font-weight:700;font-size:12px;color:#374151;margin-bottom:6px">Mevcut Sayfalar (<?php echo count($sayfalar);?> kayıt):</div>
  <?php if(empty($sayfalar)):?>
  <div style="background:#FEF9C3;padding:12px;border-radius:8px;font-size:12px;color:#92400E">
    ⚠️ Henüz kayıt yok. Veritabanınıza <code>veritabani_menu.sql</code> dosyasını çalıştırın.
  </div>
  <?php else:?>
  <div style="background:#D1FAE5;padding:10px;border-radius:8px;font-size:12px;color:#065F46;font-weight:600">
    ✅ <?php echo count($sayfalar);?> sayfa, <?php echo count($gruplar);?> grup, <?php echo count($moduller);?> modül kayıtlı.
  </div>
  <?php endif;?>
</div>
<?php endif;?>
