<?php
require_once dirname(__DIR__).'/core/config.php';
require_once dirname(__DIR__).'/core/db.php';
require_once dirname(__DIR__).'/core/auth.php';
Auth::zorunlu();

$kul = Auth::kullanici();
if (($kul['rol_adi'] ?? '') !== 'Süper Admin') {
    echo '<div style="padding:20px;color:#991B1B">Bu sayfaya erişim yetkiniz yok.</div>';
    exit;
}

// Tablo yoksa oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS sistem_ayarlari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        anahtar VARCHAR(100) NOT NULL UNIQUE,
        deger TEXT NULL,
        aciklama VARCHAR(255) NULL,
        guncelleme DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

$mesaj = ''; $hata = '';

if (!empty($_POST['kaydet'])) {
    $groq_key   = trim($_POST['groq_api_key'] ?? '');
    $groq_model = trim($_POST['groq_model'] ?? 'llama-3.3-70b-versatile');
    try {
        $db->prepare("INSERT INTO sistem_ayarlari (anahtar,deger,aciklama)
            VALUES ('groq_api_key',?,'Groq API Anahtarı')
            ON DUPLICATE KEY UPDATE deger=VALUES(deger)")->execute([$groq_key]);
        $db->prepare("INSERT INTO sistem_ayarlari (anahtar,deger,aciklama)
            VALUES ('groq_model',?,'Groq Model')
            ON DUPLICATE KEY UPDATE deger=VALUES(deger)")->execute([$groq_model]);
        $mesaj = '✅ Ayarlar kaydedildi.';
    } catch(Throwable $e) { $hata = '❌ '.$e->getMessage(); }
}

// Mevcut değerler
$groq_key   = '';
$groq_model = 'llama-3.3-70b-versatile';
try {
    $rows = $db->query("SELECT anahtar, deger FROM sistem_ayarlari WHERE anahtar IN ('groq_api_key','groq_model')")->fetchAll(PDO::FETCH_KEY_PAIR);
    $groq_key   = $rows['groq_api_key'] ?? '';
    $groq_model = $rows['groq_model']   ?? 'llama-3.3-70b-versatile';
} catch(Throwable $e) {}

$gizli = $groq_key ? substr($groq_key,0,8).'...'.substr($groq_key,-4) : '';
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🤖 AI Asistan Ayarları</h1>
    <div class="s-yol">Ayarlar / <b>Yapay Zeka</b></div>
  </div>
</div>

<?php if($mesaj):?><div style="background:#D1FAE5;color:#065F46;padding:10px 14px;border-radius:8px;margin-bottom:12px;font-weight:600"><?php echo $mesaj;?></div><?php endif;?>
<?php if($hata):?><div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:12px;font-weight:600"><?php echo $hata;?></div><?php endif;?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:900px">

<div class="kart" style="padding:20px">
  <div style="font-size:13px;font-weight:700;color:#1E3A5F;margin-bottom:16px">⚡ Groq API Ayarları</div>

  <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:12px 14px;margin-bottom:16px;font-size:12px;color:#065F46">
    <strong>🆓 Groq Ücretsiz Tier:</strong><br>
    • Günde 14,400 istek<br>
    • Dakikada 30 istek<br>
    • llama-3.3-70b-versatile modeli<br>
    <a href="https://console.groq.com" target="_blank" style="color:#065F46;font-weight:700">→ console.groq.com</a> adresinden key al
  </div>

  <form method="POST">
    <div style="margin-bottom:12px">
      <label class="form-etiket">Groq API Anahtarı (gsk_...)</label>
      <input type="password" name="groq_api_key" class="form-alan"
        placeholder="gsk_..."
        value="<?php echo htmlspecialchars($groq_key);?>"
        style="font-family:monospace;font-size:12px">
      <?php if($gizli):?>
      <div style="font-size:11px;color:#16A34A;margin-top:4px;font-weight:600">
        ✅ Kayıtlı: <code><?php echo $gizli;?></code>
      </div>
      <?php else:?>
      <div style="font-size:11px;color:#EF4444;margin-top:4px">⚠️ API anahtarı girilmemiş</div>
      <?php endif;?>
    </div>

    <div style="margin-bottom:16px">
      <label class="form-etiket">Model</label>
      <select name="groq_model" class="form-alan">
        <option value="llama-3.3-70b-versatile" <?php echo $groq_model==='llama-3.3-70b-versatile'?'selected':'';?>>
          llama-3.3-70b-versatile (Önerilen)
        </option>
        <option value="llama-3.1-8b-instant" <?php echo $groq_model==='llama-3.1-8b-instant'?'selected':'';?>>
          llama-3.1-8b-instant (Hızlı, küçük)
        </option>
        <option value="mixtral-8x7b-32768" <?php echo $groq_model==='mixtral-8x7b-32768'?'selected':'';?>>
          mixtral-8x7b-32768
        </option>
        <option value="gemma2-9b-it" <?php echo $groq_model==='gemma2-9b-it'?'selected':'';?>>
          gemma2-9b-it
        </option>
      </select>
    </div>

    <button type="submit" name="kaydet" value="1"
      style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      💾 Kaydet
    </button>
  </form>
</div>

<div class="kart" style="padding:20px">
  <div style="font-size:13px;font-weight:700;color:#1E3A5F;margin-bottom:12px">📊 AI Asistan Yetenekleri</div>
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead><tr style="background:#F1F5F9">
      <th style="padding:7px;border:1px solid #E2E8F0;text-align:left">Soru</th>
      <th style="padding:7px;border:1px solid #E2E8F0;text-align:left">Veri Kaynağı</th>
    </tr></thead>
    <tbody>
      <?php foreach([
        ['📦 Siparişler','siparis tablosu — aktif, kalan, geciken'],
        ['🏭 Üretim','mps_plan — hat, durum, kalan'],
        ['👷 Personel','personeller + devam_kayitlari'],
        ['⚠️ Stok','Tiger LG_222 (bağlantı varsa)'],
        ['🛒 Satınalma','Tiger ORFLINE — termin, gecikme'],
        ['💬 Genel','Tüm özet veriler'],
      ] as [$tip,$veri]):?>
      <tr>
        <td style="padding:6px 7px;border:1px solid #E2E8F0"><?php echo $tip;?></td>
        <td style="padding:6px 7px;border:1px solid #E2E8F0;color:#475569;font-size:11px"><?php echo $veri;?></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>

  <div style="margin-top:14px;background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;padding:10px 12px;font-size:11px;color:#92400E">
    <strong>⚡ Groq Hız:</strong> Yanıt genellikle 1-3 saniye.<br>
    <strong>🆓 Ücretsiz Limit:</strong> Günde 14,400 istek (ERP için fazlası).<br>
    <strong>🔒 Gizlilik:</strong> Veriler Groq sunucularına gidiyor — hassas veri gönderme.
  </div>
</div>

</div>
