<?php
require_once dirname(__DIR__).'/core/config.php';
require_once dirname(__DIR__).'/core/db.php';
require_once dirname(__DIR__).'/core/auth.php';
Auth::zorunlu();

$mesaj = $mesaj_tip = '';
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// ── POST işlemleri — yeni şema (modul_id, grup_adi, baslik) ──────
if ($action === 'grup_ekle') {
    $modul_id = trim($_POST['modul_id']??'');
    $grup_adi = trim($_POST['grup_adi']??'');
    $sira     = (int)($_POST['sira']??0);
    if ($modul_id && $grup_adi) {
        $db->prepare("INSERT INTO menu_gruplar (modul_id,grup_adi,sira,aktif) VALUES (?,?,?,1)")->execute([$modul_id,$grup_adi,$sira]);
        $mesaj='Grup eklendi.'; $mesaj_tip='basarili';
    }
}
if ($action === 'grup_guncelle') {
    $id=$_POST['id']; $grup_adi=trim($_POST['grup_adi']??''); $sira=(int)($_POST['sira']??0); $aktif=(int)($_POST['aktif']??1);
    $db->prepare("UPDATE menu_gruplar SET grup_adi=?,sira=?,aktif=? WHERE id=?")->execute([$grup_adi,$sira,$aktif,$id]);
    $mesaj='Grup güncellendi.'; $mesaj_tip='basarili';
}
if ($action === 'grup_sil') {
    $id=(int)($_GET['id']??0);
    $db->prepare("DELETE FROM menu_sayfalar WHERE grup_id=?")->execute([$id]);
    $db->prepare("DELETE FROM menu_gruplar WHERE id=?")->execute([$id]);
    $mesaj='Grup silindi.'; $mesaj_tip='basarili';
}
if ($action === 'sayfa_ekle') {
    $grup_id=(int)($_POST['grup_id']??0);
    $modul_id=trim($_POST['modul_id']??'');
    $ikon=trim($_POST['ikon']??'📄');
    $baslik=trim($_POST['baslik']??'');
    $sayfa_id=trim($_POST['sayfa_id']??'');
    $dosya_yolu=trim($_POST['dosya_yolu']??'');
    $sira=(int)($_POST['sira']??0);
    if ($grup_id && $baslik && $sayfa_id) {
        try {
            // dosya_yolu kolonu varsa kullan
            try {
                $db->prepare("INSERT INTO menu_sayfalar (grup_id,modul_id,sayfa_id,baslik,ikon,sira,aktif,dosya_yolu) VALUES (?,?,?,?,?,?,1,?)")
                   ->execute([$grup_id,$modul_id,$sayfa_id,$baslik,$ikon,$sira,$dosya_yolu?:null]);
            } catch(Throwable $e2) {
                $db->prepare("INSERT INTO menu_sayfalar (grup_id,modul_id,sayfa_id,baslik,ikon,sira,aktif) VALUES (?,?,?,?,?,?,1)")
                   ->execute([$grup_id,$modul_id,$sayfa_id,$baslik,$ikon,$sira]);
            }
            $mesaj='Sayfa eklendi.'; $mesaj_tip='basarili';
        } catch(Throwable $e) { $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
    }
}
if ($action === 'sayfa_guncelle') {
    $id=$_POST['id']; $ikon=trim($_POST['ikon']??'📄'); $baslik=trim($_POST['baslik']??'');
    $sayfa_id=trim($_POST['sayfa_id']??''); $dosya_yolu=trim($_POST['dosya_yolu']??'');
    $sira=(int)($_POST['sira']??0); $aktif=(int)($_POST['aktif']??1);
    $db->prepare("UPDATE menu_sayfalar SET ikon=?,baslik=?,sayfa_id=?,sira=?,aktif=?,dosya_yolu=? WHERE id=?")->execute([$ikon,$baslik,$sayfa_id,$sira,$aktif,$dosya_yolu?:null,$id]);
    $mesaj='Sayfa güncellendi.'; $mesaj_tip='basarili';
}
if ($action === 'sayfa_sil') {
    $id=(int)($_GET['id']??0);
    $sp=$db->query("SELECT sayfa_id FROM menu_sayfalar WHERE id=$id")->fetchColumn();
    if($sp) $db->prepare("DELETE FROM menu_rol_yetki WHERE sayfa_id=?")->execute([$sp]);
    $db->prepare("DELETE FROM menu_sayfalar WHERE id=?")->execute([$id]);
    $mesaj='Sayfa silindi.'; $mesaj_tip='basarili';
}
if ($action === 'rol_yetki_kaydet') {
    $rol=trim($_POST['rol']??'');
    if ($rol) {
        $db->prepare("DELETE FROM menu_rol_yetki WHERE rol=?")->execute([$rol]);
        if (!empty($_POST['sayfalar'])) {
            $ins=$db->prepare("INSERT IGNORE INTO menu_rol_yetki (rol,sayfa_id) VALUES (?,?)");
            foreach($_POST['sayfalar'] as $sp) $ins->execute([$rol,$sp]);
        }
        $mesaj='Rol yetkileri kaydedildi.'; $mesaj_tip='basarili';
    }
}

// ── VERİ ÇEK ─────────────────────────────────────────────────────
// Modüller DB'den
$tum_moduller = [];
try {
    $tum_moduller = $db->query("SELECT modul_id,baslik,ikon FROM menu_moduller WHERE aktif=1 ORDER BY sira")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

$selModul = $_GET['modul'] ?? ($tum_moduller[0]['modul_id'] ?? 'depo');

// Seçili modülün grupları
$gruplar = [];
try {
    $st=$db->prepare("SELECT * FROM menu_gruplar WHERE modul_id=? ORDER BY sira,id");
    $st->execute([$selModul]);
    $gruplar=$st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

// Sayfalar
$sayfalar = [];
if (!empty($gruplar)) {
    $gids=implode(',',array_column($gruplar,'id'));
    try {
        $rows=$db->query("SELECT * FROM menu_sayfalar WHERE grup_id IN ($gids) ORDER BY sira,id")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $s) $sayfalar[$s['grup_id']][]=$s;
    } catch(Throwable $e) {}
}

// Tüm sayfalar (yetki sekmesi için)
$tum_sayfalar = [];
try {
    $tum_sayfalar=$db->query("SELECT ms.*,mg.modul_id,mg.grup_adi FROM menu_sayfalar ms JOIN menu_gruplar mg ON ms.grup_id=mg.id ORDER BY mg.modul_id,mg.sira,ms.sira")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

// Roller
$roller = [];
try { $roller=$db->query("SELECT DISTINCT rol FROM menu_rol_yetki UNION SELECT ad FROM roller ORDER BY 1")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e){}
try { $r2=$db->query("SELECT ad FROM roller ORDER BY ad")->fetchAll(PDO::FETCH_COLUMN); $roller=array_unique(array_merge($roller,$r2)); } catch(Throwable $e){}
if (empty($roller)) $roller = ['admin','yonetici','operasyon','depo','muhasebe'];

$selRol = $_GET['rol'] ?? '';
$rol_yetkileri = [];
if ($selRol) {
    $ry=$db->prepare("SELECT sayfa_id FROM menu_rol_yetki WHERE rol=?");
    $ry->execute([$selRol]);
    $rol_yetkileri=array_column($ry->fetchAll(PDO::FETCH_ASSOC),'sayfa_id');
}

$aktif_tab = $_GET['tab'] ?? 'menu';
?>
<style>
.mn-tabs{display:flex;gap:4px;margin-bottom:14px;border-bottom:2px solid #E2E8F0;padding-bottom:0}
.mn-tab{padding:8px 18px;font-size:12px;font-weight:700;cursor:pointer;border:none;background:none;color:#64748B;border-bottom:3px solid transparent;margin-bottom:-2px;border-radius:4px 4px 0 0}
.mn-tab.aktif{color:#1E3A5F;border-bottom-color:#1E3A5F;background:#F8FAFC}
.mn-grup-kart{background:#fff;border:1px solid #E2E8F0;border-radius:10px;overflow:hidden;margin-bottom:10px}
.mn-grup-baslik{background:#1E3A5F;color:#fff;padding:8px 14px;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:space-between}
.mn-sayfa-satir{display:flex;align-items:center;gap:10px;padding:8px 14px;border-bottom:1px solid #F1F5F9;font-size:12px}
.mn-sayfa-satir:last-child{border-bottom:none}
.mn-badge{background:#EFF6FF;color:#1D4ED8;padding:2px 7px;border-radius:100px;font-size:10px;font-weight:700}
.mn-badge.pasif{background:#FEE2E2;color:#DC2626}
.mn-btn-sm{padding:4px 10px;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;border:none}
.mn-btn-ekle{background:#1E3A5F;color:#fff}
.mn-btn-sil{background:#FEE2E2;color:#DC2626;border:1px solid #FECACA}
.mn-btn-duzenle{background:#EFF6FF;color:#1D4ED8;border:1px solid #BFDBFE}
.yetki-blok{border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;margin-bottom:8px}
.yetki-blok-baslik{background:#F8FAFC;padding:7px 12px;font-size:11px;font-weight:700;color:#374151;border-bottom:1px solid #E2E8F0}
.yetki-satirlar{padding:8px 12px;display:flex;flex-wrap:wrap;gap:8px}
.yetki-item{display:flex;align-items:center;gap:5px;font-size:12px}
.yetki-item input[type=checkbox]{width:16px;height:16px;cursor:pointer}
</style>

<div class="s-bar">
  <div><h1 class="s-bas">🗂 Menü Yönetimi</h1>
    <div class="s-yol">Ayarlar / <b>Dinamik Menü & Rol Yetkileri</b></div>
  </div>
</div>

<?php if($mesaj):?>
<div style="background:<?php echo $mesaj_tip==='basarili'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $mesaj_tip==='basarili'?'#065F46':'#991B1B';?>;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-weight:600">
  <?php echo $mesaj_tip==='basarili'?'✅':'❌';?> <?php echo htmlspecialchars($mesaj);?>
</div>
<?php endif;?>

<div class="mn-tabs">
  <button class="mn-tab <?php echo $aktif_tab==='menu'?'aktif':'';?>"
    onclick="location.href='<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=menu&modul=<?php echo $selModul;?>'">
    🗂 Menü Düzenle
  </button>
  <button class="mn-tab <?php echo $aktif_tab==='yetki'?'aktif':'';?>"
    onclick="location.href='<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=yetki&rol=<?php echo urlencode($selRol);?>'">
    🎭 Rol Yetkileri
  </button>
</div>

<?php if($aktif_tab==='menu'): ?>
<div style="display:grid;grid-template-columns:200px 1fr;gap:14px;align-items:start">

<!-- Modül listesi -->
<div class="kart" style="padding:10px">
  <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:8px;text-transform:uppercase">Modül</div>
  <?php foreach($tum_moduller as $m):?>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=menu&modul=<?php echo $m['modul_id'];?>"
    style="display:block;padding:8px 10px;border-radius:6px;font-size:12px;font-weight:600;text-decoration:none;margin-bottom:2px;
    background:<?php echo $m['modul_id']===$selModul?'#1E3A5F':'transparent';?>;
    color:<?php echo $m['modul_id']===$selModul?'#fff':'#374151';?>">
    <?php echo $m['ikon'];?> <?php echo htmlspecialchars($m['baslik']);?>
  </a>
  <?php endforeach;?>
</div>

<div>
  <!-- Grup ekle -->
  <div class="kart" style="padding:12px;margin-bottom:12px">
    <div style="font-size:12px;font-weight:700;color:#1E3A5F;margin-bottom:8px">➕ Yeni Grup Ekle</div>
    <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
      <input type="hidden" name="action" value="grup_ekle">
      <input type="hidden" name="modul_id" value="<?php echo $selModul;?>">
      <div><label class="form-etiket">Grup Adı</label><input type="text" name="grup_adi" class="form-alan" placeholder="Ör: STOK" required></div>
      <div><label class="form-etiket">Sıra</label><input type="number" name="sira" class="form-alan" value="0" style="width:70px"></div>
      <button type="submit" class="mn-btn-sm mn-btn-ekle" style="padding:8px 16px;font-size:12px">➕ Ekle</button>
    </form>
  </div>

  <?php foreach($gruplar as $g):?>
  <div class="mn-grup-kart">
    <div class="mn-grup-baslik">
      <span><?php echo htmlspecialchars($g['grup_adi']);?>
        <span class="mn-badge" style="background:rgba(255,255,255,.2);color:#fff"><?php echo $g['aktif']?'Aktif':'Pasif';?></span>
        <span style="opacity:.6;font-size:10px;margin-left:4px">s:<?php echo $g['sira'];?></span>
      </span>
      <div style="display:flex;gap:6px">
        <button class="mn-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;border:none"
          onclick="var el=document.getElementById('gg<?php echo $g['id'];?>');el.style.display=el.style.display==='none'?'block':'none'">✏️</button>
        <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=menu&modul=<?php echo $selModul;?>&action=grup_sil&id=<?php echo $g['id'];?>"
          onclick="return confirm('Grubu ve sayfalarını sil?')"
          style="background:rgba(220,38,38,.5);color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;text-decoration:none">🗑</a>
      </div>
    </div>
    <div id="gg<?php echo $g['id'];?>" style="display:none;padding:10px 14px;background:#F8FAFC;border-bottom:1px solid #E2E8F0">
      <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="action" value="grup_guncelle"><input type="hidden" name="id" value="<?php echo $g['id'];?>">
        <div><label class="form-etiket">Grup Adı</label><input type="text" name="grup_adi" class="form-alan" value="<?php echo htmlspecialchars($g['grup_adi']);?>" required></div>
        <div><label class="form-etiket">Sıra</label><input type="number" name="sira" class="form-alan" value="<?php echo $g['sira'];?>" style="width:70px"></div>
        <div><label class="form-etiket">Aktif</label>
          <select name="aktif" class="form-alan" style="width:80px">
            <option value="1" <?php echo $g['aktif']?'selected':'';?>>Evet</option>
            <option value="0" <?php echo !$g['aktif']?'selected':'';?>>Hayır</option>
          </select></div>
        <button type="submit" class="mn-btn-sm mn-btn-ekle" style="padding:7px 14px;font-size:12px">💾 Kaydet</button>
      </form>
    </div>

    <?php foreach(($sayfalar[$g['id']]??[]) as $s):?>
    <div class="mn-sayfa-satir">
      <span style="font-size:18px"><?php echo $s['ikon'];?></span>
      <span style="flex:1;font-weight:600"><?php echo htmlspecialchars($s['baslik']);?></span>
      <code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:10px;color:#64748B"><?php echo htmlspecialchars($s['sayfa_id']);?></code>
      <span class="mn-badge <?php echo $s['aktif']?'':'pasif';?>"><?php echo $s['aktif']?'Aktif':'Pasif';?></span>
      <button class="mn-btn-sm mn-btn-duzenle"
        onclick="var el=document.getElementById('sp<?php echo $s['id'];?>');el.style.display=el.style.display==='none'?'block':'none'">✏️</button>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=menu&modul=<?php echo $selModul;?>&action=sayfa_sil&id=<?php echo $s['id'];?>"
        onclick="return confirm('Sil?')" class="mn-btn-sm mn-btn-sil">🗑</a>
    </div>
    <div id="sp<?php echo $s['id'];?>" style="display:none;padding:8px 14px;background:#FFFBEB;border-bottom:1px solid #FDE68A">
      <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="action" value="sayfa_guncelle"><input type="hidden" name="id" value="<?php echo $s['id'];?>">
        <div><label class="form-etiket">İkon</label><input type="text" name="ikon" class="form-alan" value="<?php echo htmlspecialchars($s['ikon']);?>" style="width:60px"></div>
        <div><label class="form-etiket">Adı</label><input type="text" name="baslik" class="form-alan" value="<?php echo htmlspecialchars($s['baslik']);?>" required></div>
        <div><label class="form-etiket">Sayfa ID</label><input type="text" name="sayfa_id" class="form-alan" value="<?php echo htmlspecialchars($s['sayfa_id']);?>" required></div>
        <div style="flex:2;min-width:200px"><label class="form-etiket">Dosya Yolu</label><input type="text" name="dosya_yolu" class="form-alan" value="<?php echo htmlspecialchars($s['dosya_yolu']??'');?>" placeholder="bolumler/depo/stok.php"></div>
        <div><label class="form-etiket">Sıra</label><input type="number" name="sira" class="form-alan" value="<?php echo $s['sira'];?>" style="width:70px"></div>
        <div><label class="form-etiket">Aktif</label>
          <select name="aktif" class="form-alan" style="width:80px">
            <option value="1" <?php echo $s['aktif']?'selected':'';?>>Evet</option>
            <option value="0" <?php echo !$s['aktif']?'selected':'';?>>Hayır</option>
          </select></div>
        <button type="submit" class="mn-btn-sm mn-btn-ekle" style="padding:7px 14px;font-size:12px">💾 Kaydet</button>
      </form>
    </div>
    <?php endforeach;?>

    <div style="padding:8px 14px;background:#F0FDF4;border-top:1px solid #86EFAC">
      <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="action" value="sayfa_ekle">
        <input type="hidden" name="grup_id" value="<?php echo $g['id'];?>">
        <input type="hidden" name="modul_id" value="<?php echo $selModul;?>">
        <div><label class="form-etiket">İkon</label><input type="text" name="ikon" class="form-alan" value="📄" style="width:60px"></div>
        <div><label class="form-etiket">Adı</label><input type="text" name="baslik" class="form-alan" placeholder="Sayfa Adı" required></div>
        <div>
          <label class="form-etiket">Sayfa ID
            <span style="color:#64748B;font-weight:400;font-size:10px">— URL'de görünür</span>
          </label>
          <input type="text" name="sayfa_id" class="form-alan" placeholder="<?php echo $selModul;?>-yeni-sayfa" required
            style="font-family:monospace">
        </div>
        <div>
          <label class="form-etiket">Dosya Yolu
            <span style="color:#64748B;font-weight:400;font-size:10px">— boş bırakılırsa otomatik</span>
          </label>
          <input type="text" name="dosya_yolu" class="form-alan" placeholder="bolumler/<?php echo $selModul;?>/dosya.php"
            style="font-family:monospace;width:220px">
        </div>
        <div><label class="form-etiket">Sıra</label><input type="number" name="sira" class="form-alan" value="0" style="width:70px"></div>
        <button type="submit" class="mn-btn-sm mn-btn-ekle" style="padding:7px 14px;font-size:12px">➕ Sayfa Ekle</button>
      </form>
      <div style="font-size:10px;color:#64748B;margin-top:6px;font-family:monospace">
        💡 Otomatik çözümleme: <b><?php echo $selModul;?>-konu-adi</b> → <b>bolumler/<?php echo $selModul;?>/konu_adi.php</b>
      </div>
    </div>
  </div>
  <?php endforeach;?>
  <?php if(empty($gruplar)):?>
  <div style="background:#F1F5F9;padding:30px;text-align:center;color:#888;border-radius:8px">Bu modül için henüz grup yok.</div>
  <?php endif;?>
</div>
</div>

<?php else: ?>
<!-- ROL YETKİLERİ -->
<div style="display:grid;grid-template-columns:180px 1fr;gap:14px;align-items:start">
<div class="kart" style="padding:10px">
  <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:8px;text-transform:uppercase">Rol Seç</div>
  <?php foreach($roller as $r):?>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ayarlar-menu&tab=yetki&rol=<?php echo urlencode($r);?>"
    style="display:block;padding:8px 10px;border-radius:6px;font-size:12px;font-weight:600;text-decoration:none;margin-bottom:2px;
    background:<?php echo $r===$selRol?'#1E3A5F':'transparent';?>;
    color:<?php echo $r===$selRol?'#fff':'#374151';?>">
    🎭 <?php echo htmlspecialchars($r);?>
  </a>
  <?php endforeach;?>
</div>
<div>
  <?php if($selRol):?>
  <div style="font-size:13px;font-weight:700;color:#1E3A5F;margin-bottom:10px">🎭 "<?php echo htmlspecialchars($selRol);?>" — menü yetkileri</div>
  <form method="POST">
    <input type="hidden" name="action" value="rol_yetki_kaydet">
    <input type="hidden" name="rol" value="<?php echo htmlspecialchars($selRol);?>">
    <?php
    $gruplu=[]; $modul_baslik=[];
    foreach($tum_moduller as $m) $modul_baslik[$m['modul_id']]=$m['ikon'].' '.$m['baslik'];
    foreach($tum_sayfalar as $s){
        $k=$s['modul_id'].'||'.$s['grup_adi'];
        $gruplu[$k][]=$s;
    }
    $son_modul='';
    foreach($gruplu as $key=>$sp_list):
        [$mk,$ga]=explode('||',$key,2);
        if($mk!==$son_modul){
            if($son_modul!=='') echo '</div>';
            echo '<div style="margin-bottom:12px"><div style="font-weight:800;font-size:13px;color:#1E3A5F;margin-bottom:6px;border-bottom:2px solid #E2E8F0;padding-bottom:4px">'.htmlspecialchars($modul_baslik[$mk]??$mk).'</div>';
            $son_modul=$mk;
        }
    ?>
    <div class="yetki-blok">
      <div class="yetki-blok-baslik"><?php echo htmlspecialchars($ga);?></div>
      <div class="yetki-satirlar">
        <?php foreach($sp_list as $s): $chk=in_array($s['sayfa_id'],$rol_yetkileri)?'checked':''; ?>
        <label class="yetki-item">
          <input type="checkbox" name="sayfalar[]" value="<?php echo htmlspecialchars($s['sayfa_id']);?>" <?php echo $chk;?>>
          <?php echo $s['ikon'];?> <?php echo htmlspecialchars($s['baslik']);?>
          <code style="background:#F1F5F9;padding:0 4px;border-radius:3px;font-size:9px;color:#64748B"><?php echo htmlspecialchars($s['sayfa_id']);?></code>
        </label>
        <?php endforeach;?>
      </div>
    </div>
    <?php endforeach; if($son_modul!=='') echo '</div>';?>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:10px 24px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">💾 Kaydet</button>
      <button type="button" onclick="document.querySelectorAll('.yetki-satirlar input').forEach(c=>c.checked=true)"
        style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:10px 16px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✅ Tümünü Seç</button>
      <button type="button" onclick="document.querySelectorAll('.yetki-satirlar input').forEach(c=>c.checked=false)"
        style="background:#FEE2E2;border:1px solid #FECACA;color:#DC2626;padding:10px 16px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✕ Temizle</button>
    </div>
  </form>
  <?php else:?>
  <div style="background:#F1F5F9;padding:40px;text-align:center;color:#888;border-radius:8px">
    <div style="font-size:32px;margin-bottom:8px">🎭</div>
    <div style="font-weight:600">Sol taraftan bir rol seçin.</div>
  </div>
  <?php endif;?>
</div>
</div>
<?php endif;?>
