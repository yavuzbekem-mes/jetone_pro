<?php
/**
 * Portal Kullanıcıları — ayarlar/bilesen/portal-kullanicilari.php
 */
$stmt = $db->prepare("
    SELECT p.*, 
           COALESCE(per.ad_soyad, m.ad) AS ilgili_ad
    FROM portal_kullanicilari p
    LEFT JOIN personeller per ON p.tip='personel' AND p.ilgili_id=per.id
    LEFT JOIN musteriler   m  ON p.tip='musteri'  AND p.ilgili_id=m.id
    ORDER BY p.tip, p.ad_soyad
");
$stmt->execute();
$portalKullanicilar = $stmt->fetchAll();

$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad, sicil_no FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();
$musteriler  = $db->query("SELECT id, ad, kod FROM musteriler WHERE durum='aktif' ORDER BY ad")->fetchAll();
?>

<div class="kart" style="margin-bottom:16px">
  <div class="kart-ust">
    <div class="kart-bas">👥 Portal Kullanıcıları</div>
    <button class="btn btn-t btn-sm" onclick="portalKulEkle()">+ Kullanıcı Ekle</button>
  </div>

  <!-- Filtre sekmeleri -->
  <div style="display:flex;gap:0;border-bottom:1px solid var(--kenar);margin-bottom:14px">
    <button class="portal-tab aktif" onclick="portalTab('tumu',this)">Tümü (<?php echo count($portalKullanicilar); ?>)</button>
    <button class="portal-tab" onclick="portalTab('personel',this)">🧑 Personel (<?php echo count(array_filter($portalKullanicilar, fn($k)=>$k['tip']==='personel')); ?>)</button>
    <button class="portal-tab" onclick="portalTab('musteri',this)">🚚 Müşteri (<?php echo count(array_filter($portalKullanicilar, fn($k)=>$k['tip']==='musteri')); ?>)</button>
  </div>

  <table class="tablo" id="portalKulTable">
    <thead>
      <tr>
        <th>Tip</th>
        <th>Kullanıcı Adı</th>
        <th>Ad Soyad</th>
        <th>İlgili Kayıt</th>
        <th>Son Giriş</th>
        <th>Durum</th>
        <th>İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($portalKullanicilar)): ?>
      <tr><td colspan="7" style="text-align:center;padding:30px;color:var(--m2)">Henüz portal kullanıcısı eklenmedi</td></tr>
      <?php else: foreach ($portalKullanicilar as $ku): ?>
      <tr data-tip="<?php echo $ku['tip']; ?>">
        <td>
          <span class="roz" style="background:<?php echo $ku['tip']==='personel' ? '#FEF3E8' : '#E0F2FE'; ?>;color:<?php echo $ku['tip']==='personel' ? '#EA6800' : '#0284C7'; ?>">
            <?php echo $ku['tip']==='personel' ? '🧑 Personel' : '🚚 Müşteri'; ?>
          </span>
        </td>
        <td><b><?php echo htmlspecialchars($ku['kullanici_adi']); ?></b></td>
        <td><?php echo htmlspecialchars($ku['ad_soyad'] ?? '—'); ?></td>
        <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($ku['ilgili_ad'] ?? '—'); ?></td>
        <td style="font-size:12px;color:var(--m2)">
          <?php echo $ku['son_giris'] ? date('d.m.Y H:i', strtotime($ku['son_giris'])) : '—'; ?>
        </td>
        <td>
          <span class="roz" style="background:<?php echo $ku['durum'] ? '#D1FADF' : '#FEE4E2'; ?>;color:<?php echo $ku['durum'] ? '#0A8F4E' : '#F04438'; ?>">
            <?php echo $ku['durum'] ? '✓ Aktif' : '✗ Pasif'; ?>
          </span>
        </td>
        <td>
          <button class="btn btn-sm btn-b" onclick="portalKulDuzenle(<?php echo $ku['id']; ?>)">✏</button>
          <button class="btn btn-sm btn-b" onclick="portalKulSifreReset(<?php echo $ku['id']; ?>)" title="Şifre Sıfırla">🔑</button>
          <button class="btn btn-sm" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer" onclick="portalKulSil(<?php echo $ku['id']; ?>)">🗑</button>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div id="portalKulModal" class="modal-overlay" style="display:none">
  <div class="modal" style="max-width:480px">
    <div class="modal-header">
      <div><div class="modal-baslik" id="pkModalBaslik">Portal Kullanıcısı Ekle</div></div>
      <button class="modal-kapat" onclick="document.getElementById('portalKulModal').style.display='none'">✕</button>
    </div>
    <div class="modal-body">
      <form id="portalKulForm">
        <input type="hidden" name="id" id="pkId">
        <div class="form-grup">
          <label class="form-et">Portal Tipi <span class="zorunlu">*</span></label>
          <select class="form-alan" name="tip" id="pkTip" onchange="pkTipDegis(this.value)">
            <option value="personel">🧑 Personel Portalı</option>
            <option value="musteri">🚚 Müşteri Portalı</option>
          </select>
        </div>
        <div class="form-grup" id="grpPersonel">
          <label class="form-et">Personel</label>
          <select class="form-alan" name="ilgili_id_personel">
            <option value="">— Seçin —</option>
            <?php foreach ($personeller as $p): ?>
            <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?> (<?php echo $p['sicil_no']; ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup" id="grpMusteri" style="display:none">
          <label class="form-et">Müşteri</label>
          <select class="form-alan" name="ilgili_id_musteri">
            <option value="">— Seçin —</option>
            <?php foreach ($musteriler as $m): ?>
            <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['ad']); ?> (<?php echo $m['kod']; ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grid-2">
          <div class="form-grup">
            <label class="form-et">Kullanıcı Adı <span class="zorunlu">*</span></label>
            <input type="text" class="form-alan" name="kullanici_adi" id="pkKulAdi" required>
          </div>
          <div class="form-grup">
            <label class="form-et">Ad Soyad</label>
            <input type="text" class="form-alan" name="ad_soyad" id="pkAdSoyad">
          </div>
          <div class="form-grup">
            <label class="form-et">E-posta</label>
            <input type="email" class="form-alan" name="email" id="pkEmail">
          </div>
          <div class="form-grup">
            <label class="form-et">Telefon</label>
            <input type="text" class="form-alan" name="telefon" id="pkTelefon">
          </div>
          <div class="form-grup">
            <label class="form-et">Şifre <span id="sifreZorunlu" class="zorunlu">*</span></label>
            <input type="password" class="form-alan" name="sifre" id="pkSifre" placeholder="En az 8 karakter">
          </div>
          <div class="form-grup">
            <label class="form-et">Durum</label>
            <select class="form-alan" name="durum" id="pkDurum">
              <option value="1">✓ Aktif</option>
              <option value="0">✗ Pasif</option>
            </select>
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-b" onclick="document.getElementById('portalKulModal').style.display='none'">İptal</button>
      <button class="btn btn-t" onclick="portalKulKaydet()">💾 Kaydet</button>
    </div>
  </div>
</div>

<script>
const PK_VERI = <?php echo json_encode(array_column($portalKullanicilar, null, 'id'), JSON_UNESCAPED_UNICODE); ?>;

function portalTab(tip, btn) {
  document.querySelectorAll('.portal-tab').forEach(t => t.classList.remove('aktif'));
  btn.classList.add('aktif');
  document.querySelectorAll('#portalKulTable tbody tr').forEach(tr => {
    tr.style.display = (tip === 'tumu' || tr.dataset.tip === tip) ? '' : 'none';
  });
}

function portalKulEkle() {
  document.getElementById('pkId').value = '';
  document.getElementById('portalKulForm').reset();
  document.getElementById('pkModalBaslik').textContent = 'Portal Kullanıcısı Ekle';
  document.getElementById('sifreZorunlu').style.display = '';
  document.getElementById('portalKulModal').style.display = 'flex';
}

function pkTipDegis(tip) {
  document.getElementById('grpPersonel').style.display = tip==='personel' ? '' : 'none';
  document.getElementById('grpMusteri').style.display  = tip==='musteri'  ? '' : 'none';
}

function portalKulKaydet() {
  const form = document.getElementById('portalKulForm');
  const data = Object.fromEntries(new FormData(form));
  const tip = data.tip;
  data.ilgili_id = tip==='personel' ? data.ilgili_id_personel : data.ilgili_id_musteri;

  JT.ajax((typeof BASE_URL!=='undefined'?BASE_URL:'')+'/ayarlar/ajax/portal-kul-kaydet.php', data).then(r => {
    if (r.ok) { JT.bildirim('Kaydedildi!', 'basari'); location.reload(); }
    else JT.bildirim(r.hata || 'Hata', 'hata');
  });
}

function portalKulSifreReset(id) {
  if (!confirm('Şifreyi sıfırlamak istediğinize emin misiniz?')) return;
  JT.ajax((typeof BASE_URL!=='undefined'?BASE_URL:'')+'/ayarlar/ajax/portal-kul-sifre-reset.php', { id }).then(r => {
    JT.bildirim(r.mesaj || (r.ok ? 'Şifre sıfırlandı' : 'Hata'), r.ok ? 'basari' : 'hata');
  });
}

function portalKulSil(id) {
  if (!confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')) return;
  JT.ajax((typeof BASE_URL!=='undefined'?BASE_URL:'')+'/ayarlar/ajax/portal-kul-sil.php', { id }).then(r => {
    if (r.ok) location.reload();
    else JT.bildirim(r.hata, 'hata');
  });
}
</script>
