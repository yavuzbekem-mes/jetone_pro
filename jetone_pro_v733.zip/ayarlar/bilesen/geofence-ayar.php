<?php
/**
 * Ayarlar — Geofence / İş Yeri Konum Yönetimi
 * ayarlar/bilesen/geofence-ayar.php
 */

// Geofence işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['gf_islem'])) {
    $islem = $_POST['gf_islem'];
    try {
        if ($islem === 'kaydet_lokasyon') {
            $id      = (int)($_POST['gf_id'] ?? 0);
            $ad      = trim($_POST['gf_ad'] ?? '');
            $lat     = (float)str_replace(',', '.', $_POST['gf_lat'] ?? '0');
            $lng     = (float)str_replace(',', '.', $_POST['gf_lng'] ?? '0');
            $yaricap = max(50, min(5000, (int)($_POST['gf_yaricap'] ?? 200)));
            $aciklama= trim($_POST['gf_aciklama'] ?? '');

            if (!$ad || !$lat || !$lng) {
                $gf_hata = 'Ad, enlem ve boylam zorunludur.';
            } else {
                if ($id) {
                    $db->prepare("UPDATE geofence_lokasyonlari SET ad=?,lat=?,lng=?,yaricap_metre=?,aciklama=? WHERE id=?")
                       ->execute([$ad, $lat, $lng, $yaricap, $aciklama ?: null, $id]);
                    $gf_basari = "'$ad' lokasyonu güncellendi.";
                } else {
                    $db->prepare("INSERT INTO geofence_lokasyonlari (ad,lat,lng,yaricap_metre,aciklama,aktif) VALUES (?,?,?,?,?,1)")
                       ->execute([$ad, $lat, $lng, $yaricap, $aciklama ?: null]);
                    $gf_basari = "'$ad' eklendi.";
                }
                Auth::logKaydet(Auth::kullanici()['id']??null,'geofence_kaydet','ayarlar',null,"$ad ($lat,$lng) ±{$yaricap}m");
            }

        } elseif ($islem === 'toggle') {
            $id = (int)$_POST['gf_id'];
            $db->prepare("UPDATE geofence_lokasyonlari SET aktif = NOT aktif WHERE id=?")->execute([$id]);

        } elseif ($islem === 'sil') {
            $id = (int)$_POST['gf_id'];
            $stmt = $db->prepare("SELECT ad FROM geofence_lokasyonlari WHERE id=?");
            $stmt->execute([$id]); $row = $stmt->fetch();
            $db->prepare("DELETE FROM geofence_lokasyonlari WHERE id=?")->execute([$id]);
            $gf_basari = ($row['ad']??'Lokasyon') . " silindi.";

        } elseif ($islem === 'genel_ayar') {
            $zorunlu = (int)($_POST['gf_zorunlu'] ?? 0);
            // ayarlar tablosunda anahtar/deger yapısı yoksa geofence kolonları kullan
            try {
                $db->exec("INSERT INTO ayarlar (anahtar,deger) VALUES ('geofence_zorunlu','$zorunlu')
                           ON DUPLICATE KEY UPDATE deger='$zorunlu'");
            } catch (Exception $e) {
                // Alternatif: ayarlar tablosuna doğrudan kolon
            }
            $gf_basari = 'Genel ayarlar kaydedildi.';
        }
    } catch (Exception $e) {
        $gf_hata = 'Hata: ' . $e->getMessage();
    }
}

// Verileri çek
$lokasyonlar = [];
try {
    $lokasyonlar = $db->query("SELECT * FROM geofence_lokasyonlari ORDER BY aktif DESC, id ASC")->fetchAll();
} catch (Exception $e) { $lokasyonlar = []; }

$gf_zorunlu = false;
try {
    $gz = $db->query("SELECT deger FROM ayarlar WHERE anahtar='geofence_zorunlu' LIMIT 1")->fetchColumn();
    $gf_zorunlu = (bool)$gz;
} catch (Exception $e) {}

// Aktif lokasyon
$aktif_lok = null;
foreach ($lokasyonlar as $l) { if ($l['aktif']) { $aktif_lok = $l; break; } }
?>

<?php if (!empty($gf_hata)): ?>
<div style="background:#FEE4E2;border:1px solid #F04438;border-radius:8px;padding:12px 14px;margin-bottom:14px;color:#F04438;font-weight:600">❌ <?php echo htmlspecialchars($gf_hata); ?></div>
<?php endif; ?>
<?php if (!empty($gf_basari)): ?>
<div style="background:#D1FADF;border:1px solid #12B76A;border-radius:8px;padding:12px 14px;margin-bottom:14px;color:#0A8F4E;font-weight:600">✅ <?php echo htmlspecialchars($gf_basari); ?></div>
<?php endif; ?>

<!-- ─── Genel Ayar ─── -->
<div class="kart" style="margin-bottom:14px">
  <div class="kart-ust">
    <div class="kart-bas">📍 Geofence Genel Ayar</div>
    <?php if ($aktif_lok): ?>
    <span class="roz" style="background:#D1FADF;color:#0A8F4E">✓ Aktif: <?php echo htmlspecialchars($aktif_lok['ad']); ?></span>
    <?php endif; ?>
  </div>

  <form method="POST">
    <input type="hidden" name="gf_islem" value="genel_ayar">
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:4px 0">
      <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:14px">
        <div id="gfSwitch" onclick="gfToggleSwitch()"
             style="width:48px;height:26px;border-radius:13px;background:<?php echo $gf_zorunlu?'#12B76A':'#D1D5DB'; ?>;cursor:pointer;position:relative;transition:background .2s;flex-shrink:0">
          <div style="position:absolute;top:3px;<?php echo $gf_zorunlu?'right:3px':'left:3px'; ?>;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.2);transition:all .2s" id="gfKnob"></div>
        </div>
        <div>
          <div style="font-weight:700" id="gfSwitchYazi"><?php echo $gf_zorunlu ? 'Geofence Zorunlu' : 'Geofence İsteğe Bağlı'; ?></div>
          <div style="font-size:12px;color:var(--m2)" id="gfSwitchAlt"><?php echo $gf_zorunlu ? 'İş yeri dışından giriş/çıkış reddedilir' : 'İş yeri dışından giriş uyarıyla kaydedilir'; ?></div>
        </div>
        <input type="checkbox" name="gf_zorunlu" value="1" id="gfZorunluInp" <?php echo $gf_zorunlu?'checked':''; ?> style="display:none">
      </label>
      <button type="submit" class="btn btn-t btn-sm" style="margin-left:auto">Kaydet</button>
    </div>
  </form>
</div>

<!-- ─── Lokasyon Ekle/Düzenle ─── -->
<div class="kart" style="margin-bottom:14px">
  <div class="kart-ust">
    <div class="kart-bas" id="gfFormBaslik">➕ Yeni Lokasyon Ekle</div>
    <button class="btn btn-b btn-sm" onclick="konumAlGF()">📍 Mevcut Konumumu Kullan</button>
  </div>

  <form method="POST" id="gfForm">
    <input type="hidden" name="gf_islem" value="kaydet_lokasyon">
    <input type="hidden" name="gf_id" id="gfId" value="0">

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Lokasyon Adı <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="gf_ad" id="gfAd"
               placeholder="Örn: Ana Fabrika, Depo" required>
      </div>
      <div class="form-grup">
        <label class="form-et">Yarıçap (metre) <span class="zorunlu">*</span>
          <span style="font-size:11px;color:var(--m2);font-weight:400">— Giriş kabul mesafesi</span>
        </label>
        <input type="number" class="form-alan" name="gf_yaricap" id="gfYaricap"
               value="200" min="50" max="5000">
      </div>
      <div class="form-grup">
        <label class="form-et">Enlem — Latitude <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="gf_lat" id="gfLat"
               placeholder="41.290089" required oninput="haritaGuncelle()">
      </div>
      <div class="form-grup">
        <label class="form-et">Boylam — Longitude <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="gf_lng" id="gfLng"
               placeholder="27.969982" required oninput="haritaGuncelle()">
      </div>
      <div class="form-grup form-span-2">
        <label class="form-et">Açıklama (İsteğe bağlı)</label>
        <input type="text" class="form-alan" name="gf_aciklama" id="gfAciklama"
               placeholder="Fabrika ana girişi...">
      </div>
    </div>

    <!-- Koordinat yardımı -->
    <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r);padding:12px 14px;margin-bottom:14px">
      <div style="font-size:12px;font-weight:700;color:#1D4ED8;margin-bottom:6px">📌 Koordinat Nasıl Bulunur?</div>
      <div style="font-size:12px;color:#3730A3;line-height:1.6">
        <b>Google Maps:</b> Konuma sağ tıkla → Koordinatı kopyala → Enlem, Boylam şeklinde yapıştır<br>
        <b>Mevcut Konum:</b> Sağdaki "📍 Mevcut Konumumu Kullan" butonuna tıkla<br>
        <b>Varsayılan:</b> <code style="background:#fff;padding:2px 6px;border-radius:4px">41.290089, 27.969982</code> → Poliza Endüstri, Çerkezköy
      </div>
    </div>

    <!-- Harita önizleme -->
    <div style="margin-bottom:14px">
      <label class="form-et">🗺️ Harita Önizleme</label>
      <div id="haritaOnizleme" style="width:100%;height:260px;border-radius:var(--r);border:1.5px solid var(--kenar);overflow:hidden;background:#F0F2F5;display:flex;align-items:center;justify-content:center;color:var(--m2);font-size:13px">
        Koordinat girerek haritayı görüntüleyin
      </div>
    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button type="submit" class="btn btn-t">💾 Lokasyonu Kaydet</button>
      <button type="button" class="btn btn-b" onclick="gfFormuSifirla()">✕ Temizle</button>
    </div>
  </form>
</div>

<!-- ─── Lokasyon Listesi ─── -->
<div class="kart">
  <div class="kart-ust"><div class="kart-bas">📍 Kayıtlı Lokasyonlar (<?php echo count($lokasyonlar); ?>)</div></div>

  <?php if (empty($lokasyonlar)): ?>
  <div style="padding:30px;text-align:center;color:var(--m2)">
    <div style="font-size:32px;margin-bottom:8px">📍</div>
    Henüz lokasyon eklenmemiş. Yukarıdan ilk lokasyonu ekleyin.
  </div>
  <?php else: ?>
  <table class="tablo">
    <thead>
      <tr>
        <th>Lokasyon Adı</th>
        <th>Koordinat</th>
        <th>Yarıçap</th>
        <th>Açıklama</th>
        <th>Durum</th>
        <th>İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($lokasyonlar as $l): ?>
    <tr style="<?php echo $l['aktif'] ? '' : 'opacity:.6'; ?>">
      <td>
        <div style="font-weight:700"><?php echo htmlspecialchars($l['ad']); ?></div>
        <?php if ($l['aktif']): ?><span class="roz" style="background:#D1FADF;color:#0A8F4E;font-size:10px">Aktif</span><?php endif; ?>
      </td>
      <td>
        <div style="font-family:monospace;font-size:12px;color:var(--t)">
          <?php echo number_format($l['lat'],6); ?>, <?php echo number_format($l['lng'],6); ?>
        </div>
        <a href="https://maps.google.com/?q=<?php echo $l['lat']; ?>,<?php echo $l['lng']; ?>" target="_blank"
           style="font-size:11px;color:var(--mavi)">Google Maps'te Gör ↗</a>
      </td>
      <td>
        <div style="font-weight:700;color:var(--t)"><?php echo $l['yaricap_metre']; ?>m</div>
        <div style="font-size:11px;color:var(--m2)">yarıçap</div>
      </td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($l['aciklama']??'—'); ?></td>
      <td>
        <span class="roz" style="background:<?php echo $l['aktif']?'#D1FADF':'#F4F5F7'; ?>;color:<?php echo $l['aktif']?'#0A8F4E':'#667085'; ?>">
          <?php echo $l['aktif'] ? '✓ Aktif' : '⏸ Pasif'; ?>
        </span>
      </td>
      <td>
        <div style="display:flex;gap:5px;flex-wrap:wrap">
          <button class="btn btn-sm btn-b" title="Düzenle"
                  onclick='gfDuzenle(<?php echo htmlspecialchars(json_encode($l), ENT_QUOTES); ?>)'>✏️</button>
          <form method="POST" style="display:inline">
            <input type="hidden" name="gf_islem" value="toggle">
            <input type="hidden" name="gf_id" value="<?php echo $l['id']; ?>">
            <button type="submit" class="btn btn-sm btn-b" title="<?php echo $l['aktif']?'Durdur':'Aktif Et'; ?>">
              <?php echo $l['aktif'] ? '⏸' : '▶'; ?>
            </button>
          </form>
          <form method="POST" style="display:inline"
                onsubmit="return confirm('<?php echo htmlspecialchars($l['ad']); ?> silinsin mi?')">
            <input type="hidden" name="gf_islem" value="sil">
            <input type="hidden" name="gf_id" value="<?php echo $l['id']; ?>">
            <button type="submit" class="btn btn-sm"
                    style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer">🗑</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<script>
// ── Toggle switch ──────────────────────────────────────
function gfToggleSwitch() {
    var inp = document.getElementById('gfZorunluInp');
    var sw  = document.getElementById('gfSwitch');
    var kn  = document.getElementById('gfKnob');
    var yw  = document.getElementById('gfSwitchYazi');
    var ya  = document.getElementById('gfSwitchAlt');
    var aktif = !inp.checked;
    inp.checked = aktif;
    sw.style.background = aktif ? '#12B76A' : '#D1D5DB';
    kn.style.right = aktif ? '3px' : 'auto';
    kn.style.left  = aktif ? 'auto' : '3px';
    yw.textContent = aktif ? 'Geofence Zorunlu' : 'Geofence İsteğe Bağlı';
    ya.textContent = aktif ? 'İş yeri dışından giriş/çıkış reddedilir' : 'İş yeri dışından giriş uyarıyla kaydedilir';
}

// ── Harita önizleme (OpenStreetMap) ───────────────────
var haritaTimeout = null;
function haritaGuncelle() {
    clearTimeout(haritaTimeout);
    haritaTimeout = setTimeout(function(){
        var lat = document.getElementById('gfLat').value.replace(',','.');
        var lng = document.getElementById('gfLng').value.replace(',','.');
        var yk  = document.getElementById('gfYaricap').value || 200;
        if (!lat || !lng || isNaN(parseFloat(lat)) || isNaN(parseFloat(lng))) return;
        var div = document.getElementById('haritaOnizleme');
        // OpenStreetMap iframe
        var zoom = yk < 100 ? 17 : yk < 300 ? 16 : yk < 1000 ? 15 : 14;
        div.innerHTML = '<iframe width="100%" height="260" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" '
            + 'src="https://www.openstreetmap.org/export/embed.html?bbox='
            + (parseFloat(lng)-0.005)+','+( parseFloat(lat)-0.005)+','+(parseFloat(lng)+0.005)+','+(parseFloat(lat)+0.005)
            + '&amp;layer=mapnik&amp;marker='+lat+','+lng
            + '" style="border:0;width:100%;height:260px"></iframe>';
    }, 800);
}

// ── Düzenle ────────────────────────────────────────────
function gfDuzenle(l) {
    document.getElementById('gfId').value        = l.id;
    document.getElementById('gfAd').value        = l.ad;
    document.getElementById('gfLat').value       = l.lat;
    document.getElementById('gfLng').value       = l.lng;
    document.getElementById('gfYaricap').value   = l.yaricap_metre;
    document.getElementById('gfAciklama').value  = l.aciklama || '';
    document.getElementById('gfFormBaslik').textContent = '✏️ Lokasyon Düzenle: ' + l.ad;
    haritaGuncelle();
    document.getElementById('gfForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Sıfırla ────────────────────────────────────────────
function gfFormuSifirla() {
    document.getElementById('gfId').value       = '0';
    document.getElementById('gfAd').value       = '';
    document.getElementById('gfLat').value      = '';
    document.getElementById('gfLng').value      = '';
    document.getElementById('gfYaricap').value  = '200';
    document.getElementById('gfAciklama').value = '';
    document.getElementById('gfFormBaslik').textContent = '➕ Yeni Lokasyon Ekle';
    document.getElementById('haritaOnizleme').innerHTML = 'Koordinat girerek haritayı görüntüleyin';
}

// ── Mevcut konum al ────────────────────────────────────
function konumAlGF() {
    if (!navigator.geolocation) { alert('Tarayıcı konum desteklemiyor'); return; }
    var btn = event.target;
    btn.disabled = true; btn.textContent = '⏳ Konum alınıyor...';
    navigator.geolocation.getCurrentPosition(
        function(p) {
            var lat = p.coords.latitude.toFixed(6);
            var lng = p.coords.longitude.toFixed(6);
            document.getElementById('gfLat').value = lat;
            document.getElementById('gfLng').value = lng;
            btn.disabled = false; btn.textContent = '📍 Mevcut Konumumu Kullan';
            haritaGuncelle();
            JT.bildirim('Konum alındı: ' + lat + ', ' + lng, 'basari');
        },
        function(err) {
            btn.disabled = false; btn.textContent = '📍 Mevcut Konumumu Kullan';
            JT.bildirim('Konum alınamadı: ' + err.message, 'hata');
        },
        { timeout: 10000, enableHighAccuracy: true }
    );
}

// Sayfa yüklenince aktif lokasyonu haritada göster
<?php if ($aktif_lok): ?>
document.getElementById('gfLat').value = '<?php echo $aktif_lok['lat']; ?>';
document.getElementById('gfLng').value = '<?php echo $aktif_lok['lng']; ?>';
document.getElementById('gfAd').value  = '<?php echo htmlspecialchars($aktif_lok['ad']); ?>';
document.getElementById('gfYaricap').value = '<?php echo $aktif_lok['yaricap_metre']; ?>';
document.getElementById('gfId').value  = '<?php echo $aktif_lok['id']; ?>';
document.getElementById('gfFormBaslik').textContent = '✏️ Lokasyon Düzenle: <?php echo htmlspecialchars($aktif_lok['ad']); ?>';
haritaGuncelle();
<?php endif; ?>
</script>
