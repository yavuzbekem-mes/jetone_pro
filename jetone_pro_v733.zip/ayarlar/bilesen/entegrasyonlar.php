<?php
/**
 * Entegrasyonlar Bileşeni — ayarlar/bilesen/entegrasyonlar.php
 */
$stmt = $db->query("SELECT * FROM entegrasyonlar ORDER BY id");
$entegrasyonlar = $stmt->fetchAll();
$tipRenkler = [
    'mssql'    => ['renk'=>'#0078D4','ad'=>'SQL Server'],
    'mysql'    => ['renk'=>'#00758F','ad'=>'MySQL'],
    'rest_api' => ['renk'=>'#F97316','ad'=>'REST API'],
    'smtp'     => ['renk'=>'#12B76A','ad'=>'E-Posta'],
];
?>
<div class="kart">
  <div class="kart-ust">
    <div class="kart-bas">🔌 Sistem Entegrasyonları</div>
    <div style="font-size:12px;color:var(--m2)">Bağlantı bilgilerini girerek entegrasyonları etkinleştirin</div>
  </div>

  <div class="ent-grid">
    <?php foreach ($entegrasyonlar as $ent): ?>
    <?php $tip = $tipRenkler[$ent['tip']] ?? ['renk'=>'#667085','ad'=>$ent['tip']]; ?>
    <div class="ent-kart <?php echo $ent['aktif'] ? 'aktif' : ''; ?>" id="ent-<?php echo $ent['id']; ?>">
      <div class="ent-kart-ust">
        <div class="ent-ikon"><?php echo $ent['ikon'] ?? '🔌'; ?></div>
        <div class="ent-bilgi">
          <div class="ent-ad"><?php echo htmlspecialchars($ent['ad']); ?></div>
          <div class="ent-tip" style="background:<?php echo $tip['renk']; ?>20;color:<?php echo $tip['renk']; ?>"><?php echo $tip['ad']; ?></div>
        </div>
        <div class="ent-durum-toggle">
          <button class="toggle <?php echo $ent['aktif'] ? 'aktif' : ''; ?>"
                  onclick="entToggle(<?php echo $ent['id']; ?>, this)"
                  data-id="<?php echo $ent['id']; ?>">
          </button>
        </div>
      </div>

      <?php if ($ent['son_test_tarihi']): ?>
      <div class="ent-son-test <?php echo $ent['son_test_sonucu'] ? 'ok' : 'hata'; ?>">
        <?php echo $ent['son_test_sonucu'] ? '✓' : '✗'; ?>
        Son test: <?php echo date('d.m.Y H:i', strtotime($ent['son_test_tarihi'])); ?>
        — <?php echo htmlspecialchars(substr($ent['son_test_mesaji'] ?? '', 0, 60)); ?>
      </div>
      <?php endif; ?>

      <div class="ent-aksiyonlar">
        <button class="btn btn-sm btn-b" onclick="entDuzenle(<?php echo $ent['id']; ?>)">✏ Düzenle</button>
        <button class="btn btn-sm btn-b" onclick="entTest(<?php echo $ent['id']; ?>)">🔍 Test Et</button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Entegrasyon Düzenleme Modalı -->
<div id="entModal" class="modal-overlay" style="display:none">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <div>
        <div class="modal-baslik" id="entModalBaslik">Entegrasyon Ayarları</div>
        <div class="modal-alt" id="entModalAlt"></div>
      </div>
      <button class="modal-kapat" onclick="entModalKapat()">✕</button>
    </div>
    <div class="modal-body" id="entModalBody">
      <form id="entForm">
        <input type="hidden" name="id" id="entId">
        <div class="form-grid-2">
          <div class="form-grup form-span-2">
            <label class="form-et">Sunucu / Host <span class="zorunlu">*</span></label>
            <input type="text" class="form-alan" name="host" id="entHost"
                   placeholder="örn: POLIZASERVER veya 192.168.1.100:32001">
          </div>
          <div class="form-grup" id="grpPort">
            <label class="form-et">Port</label>
            <input type="number" class="form-alan" name="port" id="entPort" placeholder="1433">
          </div>
          <div class="form-grup" id="grpVt">
            <label class="form-et">Veritabanı Adı <span class="zorunlu">*</span></label>
            <input type="text" class="form-alan" name="veritabani" id="entVt"
                   placeholder="örn: TIGERDB">
          </div>
          <div class="form-grup">
            <label class="form-et">Kullanıcı Adı <span class="zorunlu">*</span></label>
            <input type="text" class="form-alan" name="kullanici" id="entKul"
                   placeholder="örn: sa">
          </div>
          <div class="form-grup">
            <label class="form-et">Şifre</label>
            <input type="password" class="form-alan" name="sifre" id="entSifre"
                   placeholder="Değiştirmek için girin">
          </div>
        </div>

        <!-- SMTP için ek alanlar -->
        <div id="smtpEkAlanlar" style="display:none">
          <div class="form-grup form-span-2" id="grpSmtpSecure">
            <label class="form-et">Şifreleme</label>
            <select class="form-alan" name="smtp_secure" id="entSmtpSecure">
              <option value="tls">TLS (Port 587)</option>
              <option value="ssl">SSL (Port 465)</option>
              <option value="">Yok (Port 25)</option>
            </select>
          </div>
          <div class="form-grup form-span-2">
            <label class="form-et">Gönderici Adı</label>
            <input type="text" class="form-alan" name="smtp_from_name" id="entSmtpFromName" placeholder="Jetone ERP">
          </div>
          <div class="form-grup form-span-2">
            <label class="form-et">Test E-posta Gönder</label>
            <div style="display:flex;gap:8px">
              <input type="email" class="form-alan" name="test_mail" id="entTestMail" placeholder="test@ornek.com" style="flex:1">
              <button type="button" onclick="smtpTestMail()" style="background:var(--t);color:#fff;border:none;padding:0 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap">📤 Gönder</button>
            </div>
          </div>
        </div>

        <!-- REST API için ek alanlar -->
        <div id="restEkAlanlar" style="display:none">
          <hr style="margin:14px 0;border-color:var(--kenar)">
          <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:10px;text-transform:uppercase">REST API Parametreleri</div>
          <div class="form-grid-2">
            <div class="form-grup">
              <label class="form-et">Firma No</label>
              <input type="text" class="form-alan" name="firm_no" id="entFirmNo" placeholder="222">
            </div>
            <div class="form-grup">
              <label class="form-et">Client ID</label>
              <input type="text" class="form-alan" name="client_id" id="entClientId">
            </div>
            <div class="form-grup form-span-2">
              <label class="form-et">Client Secret</label>
              <input type="text" class="form-alan" name="client_secret" id="entClientSecret">
            </div>
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-b" onclick="entModalKapat()">İptal</button>
      <div style="display:flex;gap:8px">
        <button class="btn btn-b" onclick="entTest(document.getElementById('entId').value)">🔍 Test Et</button>
        <button class="btn btn-t" onclick="entKaydet()">💾 Kaydet</button>
      </div>
    </div>
  </div>
</div>

<script>
// Entegrasyon verisi (PHPden aktariliyor)
const ENT_VERI = <?php echo json_encode(array_column($entegrasyonlar, null, 'id'), JSON_UNESCAPED_UNICODE); ?>;

function entDuzenle(id) {
  const ent = ENT_VERI[id];
  if (!ent) return;

  document.getElementById('entId').value         = ent.id;
  document.getElementById('entHost').value       = ent.host || '';
  document.getElementById('entPort').value       = ent.port || '';
  document.getElementById('entVt').value         = ent.veritabani || '';
  document.getElementById('entKul').value        = ent.kullanici || '';
  document.getElementById('entSifre').value      = '';
  document.getElementById('entModalBaslik').textContent = ent.ad + ' Ayarları';
  document.getElementById('entModalAlt').textContent    = ent.aciklama || '';

  // REST API ek alanlar
  const ekPar = JSON.parse(ent.ek_parametreler || '{}');
  const restGrup = document.getElementById('restEkAlanlar');
  if (ent.tip === 'rest_api') {
    restGrup.style.display = 'block';
    document.getElementById('entFirmNo').value      = ekPar.firm_no || '';
    document.getElementById('entClientId').value    = ekPar.client_id || '';
    document.getElementById('entClientSecret').value = ekPar.client_secret || '';
    document.getElementById('grpVt').style.display  = 'none';
    document.getElementById('grpPort').style.display = 'none';
  } else if (ent.tip === 'mssql') {
    restGrup.style.display = 'none';
    document.getElementById('smtpEkAlanlar').style.display = 'none';
    document.getElementById('grpVt').style.display   = '';
    document.getElementById('grpPort').style.display  = 'none';
  } else if (ent.tip === 'smtp') {
    restGrup.style.display = 'none';
    document.getElementById('grpVt').style.display   = 'none';
    document.getElementById('grpPort').style.display  = '';
    document.getElementById('smtpEkAlanlar').style.display = '';
    // SMTP ek alanları doldur
    const ekPar = JSON.parse(ent.ek_parametreler || '{}');
    document.getElementById('entSmtpSecure').value    = ekPar.smtp_secure || 'tls';
    document.getElementById('entSmtpFromName').value  = ekPar.smtp_from_name || '';
    // Label'ları smtp için düzenle
    document.querySelector('[for="entHost"], label[for="entHost"]') && (document.querySelector('label[for="entHost"]') || document.querySelectorAll('.form-et')[0]);
  } else {
    restGrup.style.display = 'none';
    document.getElementById('smtpEkAlanlar').style.display = 'none';
    document.getElementById('grpVt').style.display   = '';
    document.getElementById('grpPort').style.display  = '';
  }

  document.getElementById('entModal').style.display = 'flex';
}

function entModalKapat() {
  document.getElementById('entModal').style.display = 'none';
}

function entKaydet() {
  const form = document.getElementById('entForm');
  const data = Object.fromEntries(new FormData(form));
  // SMTP ek alanlarını ekle
  const smtpSecureEl = document.getElementById('entSmtpSecure');
  if (smtpSecureEl && smtpSecureEl.closest('#smtpEkAlanlar') && smtpSecureEl.closest('#smtpEkAlanlar').style.display !== 'none') {
    data.smtp_secure    = smtpSecureEl.value;
    data.smtp_from_name = document.getElementById('entSmtpFromName')?.value || '';
  }
  JT.ajax((typeof BASE_URL!=='undefined'?BASE_URL:'')+'/ayarlar/ajax/entegrasyon-kaydet.php', data).then(r => {
    if (r.ok) {
      JT.bildirim('Ayarlar kaydedildi!', 'basari');
      entModalKapat();
      location.reload();
    } else {
      JT.bildirim(r.hata || 'Kayıt hatası', 'hata');
    }
  });
}

function entTest(id) {
  const btn = event?.target;
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Test ediliyor...'; }

  // Formdaki ANLIQ değerleri oku (kaydetmeden test et)
  var form = document.getElementById('entForm');
  var formData = form ? Object.fromEntries(new FormData(form)) : {};

  // id formda yoksa parametre olarak geleni kullan
  var testId = formData.id || id;

  // Formdaki degerleri de gonder - DBdeki eskiyle degil, su anki degerle test et
  var payload = {
    id:          testId,
    host:        document.getElementById('entHost')  ? document.getElementById('entHost').value.trim()   : '',
    veritabani:  document.getElementById('entVt')    ? document.getElementById('entVt').value.trim()     : '',
    kullanici:   document.getElementById('entKul')   ? document.getElementById('entKul').value.trim()    : '',
    sifre:       document.getElementById('entSifre') ? document.getElementById('entSifre').value         : '',
    port:        document.getElementById('entPort')  ? document.getElementById('entPort').value          : '',
    firm_no:     document.getElementById('entFirmNo')      ? document.getElementById('entFirmNo').value      : '',
    client_id:   document.getElementById('entClientId')    ? document.getElementById('entClientId').value    : '',
    client_secret: document.getElementById('entClientSecret') ? document.getElementById('entClientSecret').value : '',
  };

  var baseUrl = typeof BASE_URL !== 'undefined' ? BASE_URL : '';
  fetch(baseUrl + '/ayarlar/ajax/entegrasyon-test.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: {'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},
    body: JSON.stringify(payload)
  })
  .then(function(r){ return r.json(); })
  .then(function(r) {
    if (btn) { btn.disabled = false; btn.textContent = '🔍 Test Et'; }

    var renk  = r.ok ? '#D1FADF' : '#FEE4E2';
    var brenk = r.ok ? '#0A8F4E' : '#F04438';
    var html  = '<div id="testSonucModal" style="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px">'
      + '<div style="background:#fff;border-radius:14px;padding:28px;max-width:520px;width:100%;box-shadow:0 24px 48px rgba(0,0,0,.2)">'
      + '<div style="font-size:32px;text-align:center;margin-bottom:10px">' + (r.ok ? '✅' : '❌') + '</div>'
      + '<div style="font-size:16px;font-weight:800;text-align:center;margin-bottom:14px;color:' + brenk + '">'
      + (r.ok ? 'Bağlantı Başarılı' : 'Bağlantı Başarısız') + '</div>'
      + '<div style="background:' + renk + ';border-radius:8px;padding:12px 14px;font-size:13px;margin-bottom:12px;color:' + brenk + ';font-weight:600">'
      + (r.mesaj || '') + '</div>';

    if (r.sure) html += '<div style="font-size:12px;color:#667085;margin-bottom:8px">⏱ Yanıt süresi: ' + r.sure + '</div>';

    if (r.detay && r.detay.length > 0) {
      r.detay.forEach(function(d){
        html += '<div style="font-size:12px;background:#F0F4FF;border-radius:6px;padding:8px 10px;margin-bottom:6px;color:#3730A3">' + d + '</div>';
      });
    }

    html += '<button onclick="document.getElementById(\'testSonucModal\').remove();" '
      + 'style="width:100%;padding:12px;background:' + (r.ok?'#12B76A':'#F04438') + ';color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;margin-top:4px">'
      + (r.ok ? '✓ Tamam' : '✕ Kapat') + '</button>'
      + '</div></div>';

    document.body.insertAdjacentHTML('beforeend', html);
  })
  .catch(function(err) {
    if (btn) { btn.disabled = false; btn.textContent = '🔍 Test Et'; }
    alert('İstek hatası: ' + err.message);
  });
}
function entToggle(id, btn) {
  JT.ajax((typeof BASE_URL!=='undefined'?BASE_URL:'')+'/ayarlar/ajax/entegrasyon-toggle.php', { id }).then(r => {
    if (r.ok) {
      btn.classList.toggle('aktif');
      document.getElementById('ent-' + id).classList.toggle('aktif', r.aktif);
    }
  });
}

function smtpTestMail() {
  var hedef = document.getElementById('entTestMail').value.trim();
  if (!hedef) { alert('Test e-posta adresi girin'); return; }
  var btn = event.target;
  btn.disabled = true; btn.textContent = '⏳ Gönderiliyor...';
  var base = typeof BASE_URL !== 'undefined' ? BASE_URL : '';
  fetch(base+'/ayarlar/ajax/entegrasyon-test.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      id:           document.getElementById('entId').value,
      host:         document.getElementById('entHost').value,
      port:         document.getElementById('entPort').value,
      kullanici:    document.getElementById('entKul').value,
      sifre:        document.getElementById('entSifre').value,
      smtp_secure:  document.getElementById('entSmtpSecure').value,
      test_mail:    hedef,
      aksiyon:      'smtp_test_mail'
    })
  }).then(function(r){return r.json();}).then(function(r){
    btn.disabled = false; btn.textContent = '📤 Gönder';
    var msg = r.mesaj || (r.ok ? 'Mail gönderildi!' : 'Hata');
    var html = '<div style="padding:20px;background:'+(r.ok?'#D1FAE5':'#FEE2E2')+';border-radius:12px;margin:12px 0;font-size:14px">'
      +'<div style="font-weight:800;margin-bottom:6px">'+(r.ok?'✅ Başarılı':'❌ Hata')+'</div>'
      +'<div>'+msg+'</div>';
    if (r.detay && r.detay.length) {
      html += '<ul style="margin:8px 0 0;padding-left:18px;font-size:12px">';
      r.detay.forEach(function(d){ html += '<li>'+d+'</li>'; });
      html += '</ul>';
    }
    html += '</div>';
    var sonuc = document.getElementById('testSonucAlani');
    if (!sonuc) {
      sonuc = document.createElement('div');
      sonuc.id = 'testSonucAlani';
      document.getElementById('entModalBody').appendChild(sonuc);
    }
    sonuc.innerHTML = html;
  }).catch(function(e){
    btn.disabled=false; btn.textContent='📤 Gönder';
    alert('Bağlantı hatası: '+e.message);
  });
}
</script>
