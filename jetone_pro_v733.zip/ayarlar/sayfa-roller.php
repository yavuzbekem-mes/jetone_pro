<?php
// JSON isteği ise _base.php'yi dahil etme
$is_json_req = ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['_islem']??'')==='yetki_kaydet');
if (!$is_json_req) {
    include __DIR__ . '/_base.php';
} else {
    ob_start();
    include __DIR__ . '/_base.php';
    ob_end_clean();
}

// Modül tanımları - panel.js ile senkronize
$moduller_tanim = [
    'ik'        => ['ad'=>'İnsan Kaynakları', 'ikon'=>'👥', 'renk'=>'#EDE9FE',
        'sayfalar'=>['ik-personeller'=>'Personel Listesi','ik-devam'=>'Devam Kayıtları','ik-izinler'=>'İzin Talepleri','ik-mesai'=>'Fazla Mesai','ik-vardiya'=>'Vardiya','ik-bordro'=>'Bordro','ik-maas'=>'Maaş/Ödeme','ik-turnover'=>'Turnover','ik-anket'=>'Memnuniyet Anketi','ik-ihtar-listesi'=>'İhtar Tutanakları','ik-perf-listesi'=>'Performans','ik-duyuru-listesi'=>'Duyurular','ik-oneri'=>'Öneri & Şikayet']],
    'satis'     => ['ad'=>'Satış & CRM',      'ikon'=>'💼', 'renk'=>'#FEF9C3',
        'sayfalar'=>['satis-musteriler'=>'Müşteriler','satis-firsatlar'=>'Fırsatlar','satis-teklifler'=>'Teklifler','satis-siparisler'=>'Siparişler']],
    'satinalma' => ['ad'=>'Satınalma',         'ikon'=>'🛒', 'renk'=>'#D1FAE5',
        'sayfalar'=>['satinalma-talepler'=>'Talepler','satinalma-teklifler'=>'Teklifler','satinalma-siparisler'=>'Siparişler','satinalma-tedarikciler'=>'Tedarikçiler']],
    'uretim'    => ['ad'=>'Üretim',            'ikon'=>'🏭', 'renk'=>'#FEE2E2',
        'sayfalar'=>['uretim-is-emirleri'=>'İş Emirleri','uretim-cizelge'=>'Çizelge','uretim-makine'=>'Makine','uretim-oee'=>'OEE','uretim-recete'=>'Reçete']],
    'planlama'  => ['ad'=>'Planlama',          'ikon'=>'🗂', 'renk'=>'#E0E7FF',
        'sayfalar'=>['planlama-mps'=>'MPS','planlama-mrp'=>'MRP','planlama-kapasite'=>'Kapasite','planlama-malzeme'=>'Malzeme']],
    'kalite'    => ['ad'=>'Kalite',            'ikon'=>'✅', 'renk'=>'#DCFCE7',
        'sayfalar'=>['kalite-muayene'=>'Muayene','kalite-dof'=>'DOF','kalite-denetim'=>'Denetim','kalite-sertifika'=>'Sertifika']],
    'depo'      => ['ad'=>'Depo & Sevkiyat',  'ikon'=>'📦', 'renk'=>'#FEF3C7',
        'sayfalar'=>['depo-stok'=>'Stok','depo-hareketler'=>'Hareketler','depo-irsaliye'=>'İrsaliye','depo-sevkiyat'=>'Sevkiyat','depo-iade'=>'İade']],
    'idari'     => ['ad'=>'İdari İşler',      'ikon'=>'🏢', 'renk'=>'#F0FDF4',
        'sayfalar'=>['idari-arac-listesi'=>'Araçlar','idari-teklif-listesi'=>'Teklifler','idari-sozlesme-listesi'=>'Sözleşmeler','idari-demirbas-listesi'=>'Demirbaş','idari-servis'=>'Servis','idari-yemek'=>'Yemek Menü']],
    'raporlar'  => ['ad'=>'Raporlar',          'ikon'=>'📊', 'renk'=>'#E0F2FE',
        'sayfalar'=>['raporlar-genel'=>'Genel Raporlar']],
    'ayarlar'   => ['ad'=>'Ayarlar',           'ikon'=>'⚙️', 'renk'=>'#F8FAFC',
        'sayfalar'=>['ayarlar-firma'=>'Firma','ayarlar-kullanici'=>'Kullanıcılar','ayarlar-roller'=>'Roller','ayarlar-portal'=>'Portal Kullanıcıları','ayarlar-mail'=>'E-posta','ayarlar-geofence'=>'Geofence']],
];

// Mevcut roller
try { $roller = $db->query("SELECT * FROM roller ORDER BY id")->fetchAll(); } catch(Throwable $e){ $roller=[]; }

// Seçili rol
$aktif_rol_id = (int)($_GET['rol_id'] ?? ($roller[0]['id'] ?? 0));

// Kaydet
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $islem = $_POST['_islem'] ?? '';
    try {
        if ($islem === 'yetki_kaydet') {
            ob_clean();
            header('Content-Type: application/json; charset=utf-8');
            $rid = (int)($_POST['rol_id'] ?? 0);
            if (!$rid) { echo json_encode(['ok'=>false,'hata'=>'Rol ID gerekli']); exit; }
            // Önce bu rolün tüm yetkilerini sil
            $db->prepare("DELETE FROM yetkiler WHERE rol_id=?")->execute([$rid]);
            // Yenilerini ekle
            $moduller_post = $_POST['modul'] ?? [];
            foreach ($moduller_tanim as $modul_key => $modul_veri) {
                $goruntule = isset($moduller_post[$modul_key]['goruntule']) ? 1 : 0;
                if (!$goruntule) continue;
                // Modül seviyesi kaydet
                $db->prepare("INSERT INTO yetkiler (rol_id,modul,sayfa,goruntule,ekle,duzenle,sil,export) VALUES (?,?,'*',?,?,?,?,?)")
                   ->execute([$rid, $modul_key, 1,
                       isset($moduller_post[$modul_key]['ekle']) ? 1 : 0,
                       isset($moduller_post[$modul_key]['duzenle']) ? 1 : 0,
                       isset($moduller_post[$modul_key]['sil']) ? 1 : 0,
                       isset($moduller_post[$modul_key]['export']) ? 1 : 0,
                   ]);
                // Sayfa kısıtlamaları
                $sayfalar_post = $_POST['sayfa'][$modul_key] ?? [];
                foreach ($modul_veri['sayfalar'] as $sayfa_id => $sayfa_ad) {
                    $s_goster = isset($sayfalar_post[$sayfa_id]) ? 1 : 0;
                    if (!$s_goster) {
                        $db->prepare("INSERT INTO yetkiler (rol_id,modul,sayfa,goruntule,ekle,duzenle,sil,export) VALUES (?,?,?,0,0,0,0,0)")
                           ->execute([$rid, $modul_key, $sayfa_id]);
                    }
                }
            }
            header('Content-Type: application/json');
            echo json_encode(['ok'=>true]);
            exit;
        } elseif ($islem === 'rol_ekle') {
            $ad = trim($_POST['rol_adi'] ?? '');
            $ack = trim($_POST['rol_aciklama'] ?? '');
            $renk = $_POST['rol_renk'] ?? '#667085';
            if ($ad) {
                $db->prepare("INSERT INTO roller (ad,aciklama,renk) VALUES (?,?,?)")->execute([$ad,$ack,$renk]);
                $yeni_id = $db->lastInsertId();
                header("Location: ?sayfa=ayarlar-roller&rol_id=$yeni_id");
                exit;
            }
        } elseif ($islem === 'rol_sil') {
            $rid = (int)($_POST['rol_id'] ?? 0);
            $n = (int)$db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE rol_id=?")->execute([$rid]) ?: 0;
            $s = $db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE rol_id=?"); $s->execute([$rid]); $n=(int)$s->fetchColumn();
            if ($n > 0) {
                $hata_msg = "Bu role $n kullanıcı bağlı. Önce kullanıcıları başka role atayın.";
            } else {
                $db->prepare("DELETE FROM yetkiler WHERE rol_id=?")->execute([$rid]);
                $db->prepare("DELETE FROM roller WHERE id=? AND sistem_rol=0")->execute([$rid]);
                header("Location: ?sayfa=ayarlar-roller");
                exit;
            }
        }
    } catch(Throwable $e){ $hata_msg = $e->getMessage(); }
}

// Aktif rolün mevcut yetkileri
$mevcut_yetkiler = [];
if ($aktif_rol_id) {
    try {
        $rows = $db->prepare("SELECT modul, sayfa, goruntule, ekle, duzenle, sil, export FROM yetkiler WHERE rol_id=?");
        $rows->execute([$aktif_rol_id]);
        foreach ($rows->fetchAll() as $y) {
            if ($y['sayfa'] === '*') {
                $mevcut_yetkiler[$y['modul']]['_modul'] = $y;
            } else {
                $mevcut_yetkiler[$y['modul']]['sayfalar'][$y['sayfa']] = $y;
            }
        }
    } catch(Throwable $e) {}
}

$aktif_rol = null;
foreach ($roller as $r) { if ($r['id'] == $aktif_rol_id) { $aktif_rol = $r; break; } }
$is_super = $aktif_rol && ($aktif_rol['id'] == 1 || ($aktif_rol['sistem_rol'] ?? 0));
?>
<div class="s-bar">
  <div><h1 class="s-bas">🎭 Roller & Yetkiler</h1><div class="s-yol">Ayarlar / <b>Roller</b></div></div>
  <button onclick="document.getElementById('yeniRolModal').style.display='flex'" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">+ Yeni Rol</button>
</div>

<div class="s-body">
<?php if (!empty($hata_msg)): ?><div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:14px;font-weight:600">❌ <?php echo htmlspecialchars($hata_msg); ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:240px 1fr;gap:14px">

  <!-- Sol: Rol Listesi -->
  <div>
    <div class="kart" style="overflow:hidden">
      <div class="kart-bas" style="padding:12px 16px;border-bottom:1px solid var(--kenar)">Roller</div>
      <?php foreach ($roller as $r):
        $aktif = $r['id'] == $aktif_rol_id;
        $renk = $r['renk'] ?? '#667085';
      ?>
      <a href="?sayfa=ayarlar-roller&rol_id=<?php echo $r['id']; ?>"
         style="display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid var(--kenar);text-decoration:none;background:<?php echo $aktif?'var(--ta)':''; ?>;border-left:3px solid <?php echo $aktif?'var(--t)':'transparent'; ?>">
        <span style="width:10px;height:10px;border-radius:50%;background:<?php echo htmlspecialchars($renk); ?>;flex-shrink:0"></span>
        <div style="flex:1">
          <div style="font-size:13px;font-weight:<?php echo $aktif?'700':'500'; ?>;color:<?php echo $aktif?'var(--t)':'var(--m)'; ?>"><?php echo htmlspecialchars($r['ad']); ?></div>
          <?php $kul_say = (int)$db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE rol_id=?")->execute([$r['id']]) ?: 0;
          $ks_stmt = $db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE rol_id=?"); $ks_stmt->execute([$r['id']]); $ks=(int)$ks_stmt->fetchColumn(); ?>
          <div style="font-size:11px;color:var(--m2)"><?php echo $ks; ?> kullanıcı</div>
        </div>
        <?php if ($r['sistem_rol'] ?? 0): ?>
        <span style="font-size:9px;background:#FEF3C7;color:#92400E;padding:2px 6px;border-radius:8px;font-weight:700">SİSTEM</span>
        <?php else: ?>
        <form method="POST" style="display:inline" onsubmit="return confirm('Silinsin mi?')">
          <input type="hidden" name="_islem" value="rol_sil">
          <input type="hidden" name="rol_id" value="<?php echo $r['id']; ?>">
          <button type="submit" style="background:#FEE2E2;color:#EF4444;border:none;width:22px;height:22px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button>
        </form>
        <?php endif; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Sağ: Yetki Matrisi -->
  <div>
    <?php if ($aktif_rol): ?>
    <form id="yetkiForm">
      <input type="hidden" name="_islem" value="yetki_kaydet">
      <input type="hidden" name="rol_id" value="<?php echo $aktif_rol_id; ?>">

      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="width:14px;height:14px;border-radius:50%;background:<?php echo htmlspecialchars($aktif_rol['renk']??'#667085'); ?>;display:inline-block"></span>
          <span style="font-size:16px;font-weight:800"><?php echo htmlspecialchars($aktif_rol['ad']); ?></span>
          <?php if ($is_super): ?><span style="font-size:11px;background:#FEF3C7;color:#92400E;padding:3px 8px;border-radius:8px;font-weight:700">Süper Admin — Tüm Yetkiler</span><?php endif; ?>
        </div>
        <?php if (!$is_super): ?>
        <button type="button" onclick="kaydet()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 24px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">💾 Kaydet</button>
        <?php endif; ?>
      </div>

      <?php if ($is_super): ?>
      <div class="kart" style="padding:20px;text-align:center;color:var(--m2)">
        <div style="font-size:32px;margin-bottom:8px">⚡</div>
        <div style="font-weight:700">Süper Admin rolü tüm modül ve sayfalara tam erişime sahiptir.</div>
        <div style="font-size:12px;margin-top:4px">Bu rol kısıtlanamaz.</div>
      </div>
      <?php else: ?>

      <!-- Tüm İzin Ver / Kaldır -->
      <div class="kart" style="padding:12px 16px;margin-bottom:12px;display:flex;gap:10px;align-items:center">
        <span style="font-size:12px;color:var(--m2);font-weight:600">Hızlı Seçim:</span>
        <button type="button" onclick="tumunuSec(true)"  style="padding:6px 14px;background:#D1FAE5;color:#065F46;border:none;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">✅ Tümüne İzin Ver</button>
        <button type="button" onclick="tumunuSec(false)" style="padding:6px 14px;background:#FEE2E2;color:#991B1B;border:none;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">❌ Tüm İzinleri Kaldır</button>
      </div>

      <!-- Modül Yetki Kartları -->
      <?php foreach ($moduller_tanim as $modul_key => $modul_veri):
        $my = $mevcut_yetkiler[$modul_key]['_modul'] ?? null;
        $m_goruntule = $my ? (int)$my['goruntule'] : 0;
        $m_ekle      = $my ? (int)$my['ekle'] : 0;
        $m_duzenle   = $my ? (int)$my['duzenle'] : 0;
        $m_sil       = $my ? (int)$my['sil'] : 0;
        $m_export    = $my ? (int)$my['export'] : 0;
      ?>
      <div class="kart" style="overflow:hidden;margin-bottom:10px" id="kart_<?php echo $modul_key; ?>">
        <!-- Modül başlık -->
        <div style="padding:12px 16px;display:flex;align-items:center;gap:12px;background:<?php echo htmlspecialchars($modul_veri['renk']); ?>;border-bottom:1px solid var(--kenar)">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;flex:1" onclick="event.stopPropagation()">
            <input type="checkbox" name="modul[<?php echo $modul_key; ?>][goruntule]" value="1"
              id="m_<?php echo $modul_key; ?>"
              <?php echo $m_goruntule ? 'checked' : ''; ?>
              onchange="modulDegis('<?php echo $modul_key; ?>',this.checked)"
              style="width:18px;height:18px;accent-color:var(--t)">
            <span style="font-size:15px"><?php echo $modul_veri['ikon']; ?></span>
            <span style="font-size:14px;font-weight:800"><?php echo htmlspecialchars($modul_veri['ad']); ?></span>
          </label>
          <!-- İşlem izinleri -->
          <div style="display:flex;gap:6px;align-items:center" id="islem_<?php echo $modul_key; ?>" class="<?php echo $m_goruntule?'':'gizli'; ?>">
            <?php foreach (['ekle'=>'➕ Ekle','duzenle'=>'✏️ Düzenle','sil'=>'🗑 Sil','export'=>'📊 Export'] as $izin=>$etiket):
              $checked = ${'m_'.$izin} ? 'checked' : '';
            ?>
            <label style="display:flex;align-items:center;gap:4px;font-size:11px;font-weight:600;color:var(--m2);cursor:pointer;white-space:nowrap">
              <input type="checkbox" name="modul[<?php echo $modul_key; ?>][<?php echo $izin; ?>]" value="1"
                <?php echo $checked; ?> style="accent-color:var(--t)">
              <?php echo $etiket; ?>
            </label>
            <?php endforeach; ?>
          </div>
          <!-- Sayfa detayı toggle -->
          <button type="button" onclick="sayfaToggle('<?php echo $modul_key; ?>')"
            style="background:rgba(0,0,0,.06);border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;color:var(--m2)"
            id="toggle_<?php echo $modul_key; ?>">▼ Sayfalar</button>
        </div>

        <!-- Sayfa listesi (gizli başlar) -->
        <div id="sayfalar_<?php echo $modul_key; ?>" style="display:none">
          <div style="padding:10px 16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px">
            <?php foreach ($modul_veri['sayfalar'] as $sayfa_id => $sayfa_ad):
              // Sayfa kapalıysa (goruntule=0 kaydı varsa) işaretleme kaldır
              $s_yetki = $mevcut_yetkiler[$modul_key]['sayfalar'][$sayfa_id] ?? null;
              // Eğer özel kayıt yoksa modül görüntüleme iznini miras al
              $s_goster = $s_yetki === null ? $m_goruntule : (int)$s_yetki['goruntule'];
            ?>
            <label style="display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-size:12px;background:var(--bg)">
              <input type="checkbox" name="sayfa[<?php echo $modul_key; ?>][<?php echo $sayfa_id; ?>]" value="1"
                <?php echo $s_goster ? 'checked' : ''; ?>
                class="sp_<?php echo $modul_key; ?>"
                style="accent-color:var(--t);width:15px;height:15px">
              <?php echo htmlspecialchars($sayfa_ad); ?>
            </label>
            <?php endforeach; ?>
          </div>
          <div style="padding:6px 16px 10px;display:flex;gap:8px">
            <button type="button" onclick="sayfaTumSec('<?php echo $modul_key; ?>',true)"  style="font-size:11px;padding:3px 10px;background:#D1FAE5;color:#065F46;border:none;border-radius:5px;cursor:pointer;font-weight:600">Tümünü Seç</button>
            <button type="button" onclick="sayfaTumSec('<?php echo $modul_key; ?>',false)" style="font-size:11px;padding:3px 10px;background:#FEE2E2;color:#991B1B;border:none;border-radius:5px;cursor:pointer;font-weight:600">Tümünü Kaldır</button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>

      <div style="display:flex;justify-content:flex-end;margin-top:8px">
        <?php if (!$is_super): ?>
        <button type="button" onclick="kaydet()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:12px 32px;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit">💾 Değişiklikleri Kaydet</button>
        <?php endif; ?>
      </div>
    </form>
    <?php else: ?>
    <div class="kart" style="padding:40px;text-align:center;color:var(--m2)">Sol taraftan bir rol seçin.</div>
    <?php endif; ?>
  </div>
</div>
</div>

<!-- Yeni Rol Modal -->
<div id="yeniRolModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center">
  <div style="background:rgba(255,255,255,0.92);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:420px;border:1px solid rgba(255,255,255,0.6);box-shadow:0 20px 60px rgba(0,0,0,0.15)">
    <div style="font-size:16px;font-weight:800;margin-bottom:16px">➕ Yeni Rol Oluştur</div>
    <form method="POST">
      <input type="hidden" name="_islem" value="rol_ekle">
      <label class="form-etiket">Rol Adı *</label>
      <input type="text" name="rol_adi" class="form-alan" placeholder="Örn: Muhasebe Uzmanı" required style="margin-bottom:10px">
      <label class="form-etiket">Açıklama</label>
      <input type="text" name="rol_aciklama" class="form-alan" placeholder="Kısa açıklama" style="margin-bottom:10px">
      <label class="form-etiket">Renk</label>
      <input type="color" name="rol_renk" value="#F97316" style="width:100%;height:38px;border-radius:8px;border:1px solid var(--kenar);cursor:pointer;margin-bottom:16px">
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" onclick="document.getElementById('yeniRolModal').style.display='none'" style="padding:10px 20px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
        <button type="submit" style="padding:10px 20px;background:var(--t);color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">Oluştur</button>
      </div>
    </form>
  </div>
</div>

<style>
.gizli { display:none !important; }
</style>

<script>
var AYARLAR_AJAX = '<?php echo BASE_URL; ?>/ayarlar/ajax/yetki-kaydet.php';
function modulDegis(key, aktif) {
  var islemDiv = document.getElementById('islem_' + key);
  var sayfaCbs = document.querySelectorAll('.sp_' + key);
  if (islemDiv) { if (aktif) islemDiv.classList.remove('gizli'); else islemDiv.classList.add('gizli'); }
  sayfaCbs.forEach(function(cb) { cb.checked = aktif; cb.disabled = !aktif; });
}

function sayfaToggle(key) {
  var div = document.getElementById('sayfalar_' + key);
  var btn = document.getElementById('toggle_' + key);
  if (div.style.display === 'none') { div.style.display = ''; btn.textContent = '▲ Sayfalar'; }
  else { div.style.display = 'none'; btn.textContent = '▼ Sayfalar'; }
}

function sayfaTumSec(key, val) {
  document.querySelectorAll('.sp_' + key).forEach(function(cb) { cb.checked = val; });
}

function tumunuSec(val) {
  document.querySelectorAll('input[name^="modul"][name$="[goruntule]"]').forEach(function(cb) {
    cb.checked = val;
    var key = cb.name.match(/modul\[([^\]]+)\]/)[1];
    modulDegis(key, val);
  });
}

function kaydet() {
  var fd = new FormData(document.getElementById('yetkiForm'));
  fetch(AYARLAR_AJAX, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){
    if (r.ok) {
      var btn = document.querySelector('[onclick="kaydet()"]');
      if (btn) { var orig=btn.textContent; btn.textContent='✅ Kaydedildi!'; setTimeout(function(){btn.textContent=orig;},2000); }
    } else { alert('Hata: ' + (r.hata||'?')); }
  }).catch(function(){ alert('Bağlantı hatası'); });
}

// Sayfa yüklenince mevcut duruma göre disable
document.querySelectorAll('input[name^="modul"][name$="[goruntule]"]').forEach(function(cb) {
  if (!cb.checked) {
    var key = cb.name.match(/modul\[([^\]]+)\]/)[1];
    document.querySelectorAll('.sp_' + key).forEach(function(s){ s.disabled = true; });
  }
});
</script>
