<?php include __DIR__ . '/_base.php';
$basari = $hata = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $db->prepare("UPDATE ayarlar SET para_birimi=?,tarih_formati=?,saat_dilimi=?,dil=? WHERE id=1")
           ->execute([$_POST['para_birimi']??'TRY',$_POST['tarih_formati']??'d.m.Y',$_POST['saat_dilimi']??'Europe/Istanbul',$_POST['dil']??'tr']);
        $basari='Bölgesel ayarlar güncellendi.';
        $A = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: [];
    } catch (Exception $e) { $hata=$e->getMessage(); }
}
?>
<div class="s-bar"><div><h1 class="s-bas">🌍 Bölgesel Ayarlar</h1><div class="s-yol">Ayarlar / <b>Bölgesel</b></div></div></div>
<div class="s-body">
<?php if ($basari): ?><div style="background:#D1FADF;border:1px solid #86EFAC;color:#0A8F4E;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">✅ <?php echo htmlspecialchars($basari); ?></div><?php endif; ?>
<form method="POST">
<div class="kart">
  <div class="kart-ust"><div class="kart-bas">🌍 Format & Dil Ayarları</div></div>
  <div class="form-grid-2">
    <div class="form-grup">
      <label class="form-et">Para Birimi</label>
      <select class="form-alan" name="para_birimi">
        <?php foreach(['TRY'=>'₺ Türk Lirası','USD'=>'$ Amerikan Doları','EUR'=>'€ Euro','GBP'=>'£ İngiliz Sterlini'] as $v=>$l): ?>
        <option value="<?php echo $v; ?>" <?php echo ($A['para_birimi']??'TRY')===$v?'selected':''; ?>><?php echo $l; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-grup">
      <label class="form-et">Tarih Formatı</label>
      <select class="form-alan" name="tarih_formati">
        <option value="d.m.Y" <?php echo ($A['tarih_formati']??'')==='d.m.Y'?'selected':''; ?>>GG.AA.YYYY (<?php echo date('d.m.Y'); ?>)</option>
        <option value="Y-m-d" <?php echo ($A['tarih_formati']??'')==='Y-m-d'?'selected':''; ?>>YYYY-AA-GG (<?php echo date('Y-m-d'); ?>)</option>
        <option value="d/m/Y" <?php echo ($A['tarih_formati']??'')==='d/m/Y'?'selected':''; ?>>GG/AA/YYYY (<?php echo date('d/m/Y'); ?>)</option>
      </select>
    </div>
    <div class="form-grup">
      <label class="form-et">Saat Dilimi</label>
      <select class="form-alan" name="saat_dilimi">
        <option value="Europe/Istanbul" <?php echo ($A['saat_dilimi']??'')==='Europe/Istanbul'?'selected':''; ?>>Europe/Istanbul (UTC+3)</option>
        <option value="UTC">UTC (GMT+0)</option>
        <option value="Europe/London">Europe/London</option>
      </select>
    </div>
    <div class="form-grup">
      <label class="form-et">Dil</label>
      <select class="form-alan" name="dil">
        <option value="tr" <?php echo ($A['dil']??'tr')==='tr'?'selected':''; ?>>🇹🇷 Türkçe</option>
        <option value="en" <?php echo ($A['dil']??'')==='en'?'selected':''; ?>>🇬🇧 English</option>
      </select>
    </div>
  </div>
  <div style="margin-top:14px"><button type="submit" class="btn btn-t">💾 Kaydet</button></div>
</div>
</form>
</div>
