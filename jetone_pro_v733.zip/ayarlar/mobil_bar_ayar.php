<?php
/**
 * Mobil Alt Bar Sayfa Seçici
 * Route: ayarlar-mobil-bar
 */
if(!defined('ROOT_DIR')) require_once dirname(__DIR__).'/core/config.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

// Tüm modüller ve sayfaları çek
$moduller = []; $modul_sayfalar = [];
try {
    $mod_r = $db->query("SELECT modul_id,baslik,ikon FROM menu_moduller WHERE aktif=1 ORDER BY sira");
    $moduller = $mod_r->fetchAll(PDO::FETCH_ASSOC);

    $spy_r = $db->query(
        "SELECT s.sayfa_id, s.baslik, s.ikon, s.modul_id,
                g.grup_adi, g.id as grup_id
         FROM menu_sayfalar s
         LEFT JOIN menu_gruplar g ON g.id=s.grup_id
         WHERE s.aktif=1
         ORDER BY s.modul_id, g.sira, s.sira"
    );
    foreach($spy_r->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $modul_sayfalar[$s['modul_id']][] = $s;
    }
} catch(Throwable $e){ error_log("[MOBİL_BAR] ".$e->getMessage()); }

// Mevcut kayıtlı ayarları çek
$kayitli = [];
try {
    $kr = $db->query("SELECT modul_id, sayfa_id, sira FROM mobil_bar_ayarlar WHERE aktif=1 ORDER BY modul_id,sira");
    foreach($kr->fetchAll(PDO::FETCH_ASSOC) as $k) {
        $kayitli[$k['modul_id']][] = $k['sayfa_id'];
    }
} catch(Throwable $e){}

// POST — kaydet
$mesaj = ''; $mesaj_tip = '';
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['modul_id'])) {
    $mid     = trim($_POST['modul_id']);
    $secili  = (array)($_POST['sayfalar'] ?? []);
    $secili  = array_slice(array_filter($secili), 0, 4); // max 4
    try {
        $db->prepare("DELETE FROM mobil_bar_ayarlar WHERE modul_id=?")->execute([$mid]);
        $ins = $db->prepare("INSERT INTO mobil_bar_ayarlar(modul_id,sayfa_id,sira,aktif) VALUES(?,?,?,1)");
        foreach($secili as $sira=>$sid) {
            $ins->execute([$mid, $sid, $sira]);
        }
        $mesaj = 'Ayarlar kaydedildi.';
        $mesaj_tip = 'success';
        $kayitli[$mid] = $secili;
    } catch(Throwable $e){
        $mesaj = 'Hata: '.$e->getMessage();
        $mesaj_tip = 'error';
    }
}

$aktif_mid = $_GET['mid'] ?? ($_POST['modul_id'] ?? ($moduller[0]['modul_id'] ?? ''));
?>
<div class="s-yol">Ayarlar / <b>Mobil Bar Ayarları</b></div>
<style>
.mb-grid{display:grid;grid-template-columns:220px 1fr;gap:20px}
.mb-modul-list{background:var(--yuzey);border-radius:var(--r-xl);box-shadow:var(--shadow);overflow:hidden}
.mb-modul-btn{display:flex;align-items:center;gap:10px;width:100%;padding:12px 16px;border:none;background:none;cursor:pointer;text-align:left;border-bottom:1px solid var(--kenar);font-size:13px;font-weight:600;color:var(--m2);transition:background .12s}
.mb-modul-btn:hover{background:var(--kenar-a)}
.mb-modul-btn.aktif{background:var(--t-a);color:var(--t);font-weight:800}
.mb-kart{background:var(--yuzey);border-radius:var(--r-xl);box-shadow:var(--shadow)}
.mb-sayfa-item{display:flex;align-items:center;gap:12px;padding:10px 14px;border-bottom:1px solid var(--kenar);cursor:pointer;transition:background .12s;border-radius:0}
.mb-sayfa-item:hover{background:var(--kenar-a)}
.mb-sayfa-item.secili{background:#EDE9FE}
.mb-sayfa-item input[type=checkbox]{width:18px;height:18px;accent-color:var(--t);cursor:pointer;flex-shrink:0}
.mb-preview{display:flex;align-items:center;justify-content:center;gap:8px;padding:16px;background:#1E293B;border-radius:var(--r);margin-top:12px}
.mb-prev-btn{display:flex;flex-direction:column;align-items:center;gap:3px;padding:8px 14px;border-radius:8px;background:rgba(255,255,255,.08);color:#fff;font-size:10px;min-width:56px}
.mb-prev-btn.aktif{background:var(--t);color:#fff}
@media(max-width:700px){.mb-grid{grid-template-columns:1fr}}
</style>

<?php if($mesaj): ?>
<div style="padding:12px 16px;border-radius:var(--r);margin-bottom:16px;
            background:<?=$mesaj_tip==='success'?'#D1FAE5':'#FEE2E2'?>;
            color:<?=$mesaj_tip==='success'?'#065F46':'#7F1D1D'?>;font-weight:600">
  <?=$mesaj_tip==='success'?'✅':'❌'?> <?=htmlspecialchars($mesaj)?>
</div>
<?php endif; ?>

<div style="background:#EDE9FE;border:1px solid #C4B5FD;border-radius:var(--r);padding:12px 16px;margin-bottom:16px;font-size:12px;color:#5B21B6">
  📱 Her modül için <b>en fazla 4 sayfa</b> seçebilirsiniz. Mobil alt bar'da seçilen sayfalar + Ana Sayfa + Menü butonu gösterilir.
</div>

<div class="mb-grid">
  <!-- Modül listesi -->
  <div class="mb-modul-list">
    <div style="padding:12px 16px;border-bottom:2px solid var(--kenar);font-weight:800;font-size:13px">📱 Modüller</div>
    <?php foreach($moduller as $m): ?>
    <button class="mb-modul-btn <?=$m['modul_id']===$aktif_mid?'aktif':''?>"
            onclick="modülSec('<?=htmlspecialchars($m['modul_id'])?>')">
      <span style="font-size:18px"><?=htmlspecialchars($m['ikon'])?></span>
      <span><?=htmlspecialchars($m['baslik'])?></span>
      <?php $say=count($kayitli[$m['modul_id']]??[]); ?>
      <?php if($say>0): ?>
      <span style="margin-left:auto;background:var(--t);color:#fff;border-radius:12px;padding:1px 7px;font-size:10px;font-weight:700"><?=$say?></span>
      <?php endif; ?>
    </button>
    <?php endforeach; ?>
  </div>

  <!-- Sağ panel — seçili modülün sayfaları -->
  <div>
    <?php foreach($moduller as $m):
      $mid   = $m['modul_id'];
      $sec   = $kayitli[$mid] ?? [];
      $splar = $modul_sayfalar[$mid] ?? [];
      // Gruplara ayır
      $grp_sp = [];
      foreach($splar as $s) { $grp_sp[$s['grup_adi'] ?: 'Genel'][] = $s; }
    ?>
    <div id="panel-<?=htmlspecialchars($mid)?>" style="display:<?=$mid===$aktif_mid?'block':'none'?>">
      <div class="mb-kart" style="padding:0;overflow:hidden">
        <div style="padding:14px 18px;border-bottom:2px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:15px;font-weight:800"><?=htmlspecialchars($m['ikon'])?> <?=htmlspecialchars($m['baslik'])?> — Bar Sayfaları</span>
          <span id="sayac-<?=htmlspecialchars($mid)?>" style="font-size:12px;color:var(--m3)">
            <?=count($sec)?>/4 seçili
          </span>
        </div>

        <form method="POST" id="form-<?=htmlspecialchars($mid)?>">
          <input type="hidden" name="modul_id" value="<?=htmlspecialchars($mid)?>">

          <?php foreach($grp_sp as $grp_adi => $grp_sayfalar): ?>
          <div style="padding:8px 14px;background:var(--kenar-a);font-size:11px;font-weight:700;color:var(--m3);text-transform:uppercase;letter-spacing:.5px">
            <?=htmlspecialchars($grp_adi)?>
          </div>
          <?php foreach($grp_sayfalar as $s):
            $is_sec = in_array($s['sayfa_id'], $sec);
          ?>
          <label class="mb-sayfa-item <?=$is_sec?'secili':''?>"
                 id="lbl-<?=htmlspecialchars($mid)?>-<?=htmlspecialchars($s['sayfa_id'])?>">
            <input type="checkbox" name="sayfalar[]"
                   value="<?=htmlspecialchars($s['sayfa_id'])?>"
                   <?=$is_sec?'checked':''?>
                   onchange="checkboxDegisti('<?=htmlspecialchars($mid)?>', this)">
            <span style="font-size:18px"><?=htmlspecialchars($s['ikon']??'📄')?></span>
            <div>
              <div style="font-weight:600;font-size:13px"><?=htmlspecialchars($s['baslik'])?></div>
              <div style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($s['sayfa_id'])?></div>
            </div>
          </label>
          <?php endforeach; ?>
          <?php endforeach; ?>

          <!-- Önizleme -->
          <div style="padding:16px 18px;border-top:1px solid var(--kenar)">
            <div style="font-size:12px;font-weight:700;color:var(--m3);margin-bottom:8px">📱 Önizleme</div>
            <div class="mb-preview" id="preview-<?=htmlspecialchars($mid)?>">
              <?php
              $prev_items = [['ikon'=>'🏠','baslik'=>'Ana']];
              foreach($sec as $sid) {
                foreach($splar as $s) {
                    if($s['sayfa_id']===$sid) {
                        $prev_items[] = ['ikon'=>$s['ikon']??'📄','baslik'=>mb_substr($s['baslik'],0,6)];
                        break;
                    }
                }
              }
              $prev_items[] = ['ikon'=>'☰','baslik'=>'Menü'];
              foreach($prev_items as $pi): ?>
              <div class="mb-prev-btn"><?=htmlspecialchars($pi['ikon'])?><span><?=htmlspecialchars($pi['baslik'])?></span></div>
              <?php endforeach; ?>
            </div>
            <div id="uyari-<?=htmlspecialchars($mid)?>" style="display:none;color:#DC2626;font-size:11px;margin-top:6px">⚠️ En fazla 4 sayfa seçebilirsiniz.</div>
          </div>

          <div style="padding:14px 18px;border-top:1px solid var(--kenar);display:flex;justify-content:flex-end;gap:10px">
            <button type="button" onclick="temizle('<?=htmlspecialchars($mid)?>')"
                    class="btn" style="padding:10px 18px;background:var(--kenar-a);color:var(--m2)">
              ↺ Temizle
            </button>
            <button type="submit" class="btn btn-t" style="padding:10px 22px">
              💾 Kaydet
            </button>
          </div>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
var aktifMid = '<?=htmlspecialchars($aktif_mid)?>';
var modSayfalar = <?=json_encode($modul_sayfalar, JSON_UNESCAPED_UNICODE)?>;

function modülSec(mid) {
    document.querySelectorAll('[id^="panel-"]').forEach(function(el){ el.style.display='none'; });
    document.querySelectorAll('.mb-modul-btn').forEach(function(el){ el.classList.remove('aktif'); });
    var p = document.getElementById('panel-'+mid);
    if(p) p.style.display='block';
    event.currentTarget.classList.add('aktif');
    aktifMid = mid;
}

function checkboxDegisti(mid, cb) {
    var form = document.getElementById('form-'+mid);
    var secili = Array.from(form.querySelectorAll('input[type=checkbox]:checked'));
    var sayac  = document.getElementById('sayac-'+mid);
    var uyari  = document.getElementById('uyari-'+mid);

    if(secili.length > 4) {
        cb.checked = false;
        uyari.style.display = 'block';
        setTimeout(function(){ uyari.style.display='none'; }, 2500);
        return;
    }

    // Label rengini güncelle
    var lbl = document.getElementById('lbl-'+mid+'-'+cb.value);
    if(lbl) lbl.classList.toggle('secili', cb.checked);

    if(sayac) sayac.textContent = secili.length + '/4 seçili';

    // Önizlemeyi güncelle
    guncellePrev(mid);
}

function guncellePrev(mid) {
    var form = document.getElementById('form-'+mid);
    if(!form) return;
    var secili = Array.from(form.querySelectorAll('input[type=checkbox]:checked')).map(function(c){ return c.value; });
    var sayfalar = modSayfalar[mid] || [];
    var items = [{ikon:'🏠',baslik:'Ana'}];
    secili.forEach(function(sid){
        var s = sayfalar.find(function(p){ return p.sayfa_id===sid; });
        if(s) items.push({ikon:s.ikon||'📄', baslik:s.baslik.substring(0,6)});
    });
    items.push({ikon:'☰',baslik:'Menü'});
    var prev = document.getElementById('preview-'+mid);
    if(!prev) return;
    prev.innerHTML = items.map(function(it){
        return '<div class="mb-prev-btn"><span style="font-size:18px">'+it.ikon+'</span><span>'+it.baslik+'</span></div>';
    }).join('');
}

function temizle(mid) {
    var form = document.getElementById('form-'+mid);
    if(!form) return;
    form.querySelectorAll('input[type=checkbox]:checked').forEach(function(cb){
        cb.checked = false;
        var lbl = document.getElementById('lbl-'+mid+'-'+cb.value);
        if(lbl) lbl.classList.remove('secili');
    });
    var sayac = document.getElementById('sayac-'+mid);
    if(sayac) sayac.textContent = '0/4 seçili';
    guncellePrev(mid);
}
</script>
