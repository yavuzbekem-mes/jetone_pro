<?php include __DIR__ . '/_base.php';

// Personeller (portalsız olanlar)
$personeller = [];
$musteriler  = [];
try {
    $personeller = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, p.sicil_no, d.ad dept_adi,
        (SELECT id FROM portal_kullanicilari WHERE ilgili_id=p.id AND tip='personel' LIMIT 1) portal_id
        FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif' ORDER BY p.ad")->fetchAll();
} catch(Throwable $e){}

try {
    $musteriler = $db->query("SELECT m.id, m.ad, m.email,
        (SELECT id FROM portal_kullanicilari WHERE ilgili_id=m.id AND tip='musteri' LIMIT 1) portal_id
        FROM musteriler m ORDER BY m.ad")->fetchAll();
} catch(Throwable $e){}

// Portal kullanıcıları - personel
$per_portal = [];
try {
    try {
        $per_portal = $db->query("SELECT pk.id, pk.ilgili_id, pk.kullanici_adi, pk.durum, pk.son_giris,
            IFNULL(pk.sifre_degistirildi, 0) sifre_degistirildi,
            CONCAT(p.ad,' ',p.soyad) personel_adi, p.sicil_no, d.ad dept_adi
            FROM portal_kullanicilari pk
            JOIN personeller p ON pk.ilgili_id=p.id
            LEFT JOIN departmanlar d ON p.departman_id=d.id
            WHERE pk.tip='personel' ORDER BY p.ad")->fetchAll();
    } catch(Throwable $e2) {
        $per_portal = $db->query("SELECT pk.id, pk.ilgili_id, pk.kullanici_adi, pk.durum, pk.son_giris, 0 sifre_degistirildi,
            CONCAT(p.ad,' ',p.soyad) personel_adi, p.sicil_no, d.ad dept_adi
            FROM portal_kullanicilari pk
            JOIN personeller p ON pk.ilgili_id=p.id
            LEFT JOIN departmanlar d ON p.departman_id=d.id
            WHERE pk.tip='personel' ORDER BY p.ad")->fetchAll();
    }
} catch(Throwable $e){}

// Portal kullanıcıları - müşteri
$mus_portal = [];
try {
    $mus_portal = $db->query("SELECT pk.id, pk.ilgili_id, pk.kullanici_adi, pk.ad_soyad,
        pk.email, pk.telefon, pk.durum, pk.son_giris,
        COALESCE(m.ad, pk.ad_soyad) musteri_adi,
        COALESCE(m.email, pk.email) musteri_email
        FROM portal_kullanicilari pk
        LEFT JOIN musteriler m ON pk.ilgili_id=m.id AND pk.ilgili_id > 0
        WHERE pk.tip='musteri'
        ORDER BY musteri_adi")->fetchAll();
} catch(Throwable $e){}

$aktif_tab = $_GET['tab'] ?? 'personel';
?>
<div class="s-bar">
  <div><h1 class="s-bas">🌐 Portal Kullanıcıları</h1><div class="s-yol">Ayarlar / <b>Portal</b></div></div>
</div>

<!-- Tab bar -->
<div style="display:flex;gap:0;border-bottom:2px solid var(--kenar);margin:0 0 16px;padding:0 24px">
  <?php foreach(['personel'=>'🧑‍💼 Personel Portalı','musteri'=>'🏢 Müşteri Portalı'] as $tab=>$et): ?>
  <a href="?sayfa=ayarlar-portal&tab=<?php echo $tab; ?>"
     style="padding:10px 20px;font-size:13px;font-weight:700;text-decoration:none;border-bottom:2px solid <?php echo $aktif_tab===$tab?'var(--t)':'transparent'; ?>;margin-bottom:-2px;color:<?php echo $aktif_tab===$tab?'var(--t)':'var(--m2)'; ?>">
    <?php echo $et; ?>
    <span style="background:<?php echo $aktif_tab===$tab?'var(--t)':'#F3F4F6'; ?>;color:<?php echo $aktif_tab===$tab?'#fff':'#6B7280'; ?>;font-size:10px;font-weight:800;padding:1px 7px;border-radius:10px;margin-left:6px">
      <?php echo $tab==='personel'?count($per_portal):count($mus_portal); ?>
    </span>
  </a>
  <?php endforeach; ?>
</div>

<div class="s-body">

<?php if ($aktif_tab === 'personel'): ?>
<!-- ═══════════════ PERSONEL PORTALI ═══════════════ -->
<div style="display:grid;grid-template-columns:1fr 340px;gap:14px">

  <!-- Liste -->
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
      <div class="kart-bas">Personel Portal Kullanıcıları (<?php echo count($per_portal); ?>)</div>
      <input type="text" placeholder="Ara..." oninput="filtrele(this,'perTable')" class="form-alan" style="width:160px;padding:6px 10px">
    </div>
    <table class="tablo" id="perTable">
      <thead><tr><th>Personel</th><th>Bölüm</th><th>Kullanıcı Adı</th><th style="text-align:center">Erişim</th><th style="text-align:center">Şifre</th><th>Son Giriş</th><th style="text-align:center">İşlem</th></tr></thead>
      <tbody>
      <?php if (empty($per_portal)): ?>
      <tr><td colspan="7" style="text-align:center;padding:30px;color:var(--m2)">Henüz personel portal kullanıcısı yok.</td></tr>
      <?php else: foreach ($per_portal as $pk): ?>
      <tr>
        <td>
          <div style="font-weight:700"><?php echo htmlspecialchars($pk['personel_adi']); ?></div>
          <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($pk['sicil_no']??''); ?></div>
        </td>
        <td style="font-size:12px"><?php echo htmlspecialchars($pk['dept_adi']??'—'); ?></td>
        <td><code style="font-size:12px;background:var(--bg);padding:2px 8px;border-radius:4px;color:var(--t);font-weight:700"><?php echo htmlspecialchars($pk['kullanici_adi']); ?></code></td>
        <td style="text-align:center">
          <span style="background:<?php echo $pk['durum']?'#D1FAE5':'#FEE2E2'; ?>;color:<?php echo $pk['durum']?'#065F46':'#991B1B'; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
            <?php echo $pk['durum']?'✓ Aktif':'✗ Pasif'; ?>
          </span>
        </td>
        <td style="text-align:center">
          <span style="background:<?php echo ($pk['sifre_degistirildi']??0)?'#D1FAE5':'#FEF3C7'; ?>;color:<?php echo ($pk['sifre_degistirildi']??0)?'#065F46':'#92400E'; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
            <?php echo ($pk['sifre_degistirildi']??0)?'Değiştirildi':'⚠ İlk Şifre'; ?>
          </span>
        </td>
        <td style="font-size:11px;color:var(--m2)"><?php echo $pk['son_giris']?date('d.m.Y H:i',strtotime($pk['son_giris'])):'Henüz girmedi'; ?></td>
        <td style="text-align:center">
          <div style="display:flex;gap:4px;justify-content:center">
            <button onclick="sifreReset(<?php echo $pk['id']; ?>,'personel')" title="Şifre Sıfırla" style="background:#FEF3C7;color:#92400E;border:none;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:13px">🔑</button>
            <button onclick="erisimToggle(<?php echo $pk['id']; ?>,<?php echo $pk['durum']; ?>,'personel')" title="<?php echo $pk['durum']?'Kapat':'Aç'; ?>" style="background:<?php echo $pk['durum']?'#FEE2E2':'#D1FAE5'; ?>;color:<?php echo $pk['durum']?'#991B1B':'#065F46'; ?>;border:none;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:13px"><?php echo $pk['durum']?'🔒':'🔓'; ?></button>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Sağ: Personel Ekle -->
  <div>
    <div class="kart" style="padding:18px">
      <div class="kart-bas" style="margin-bottom:14px">➕ Portal Erişimi Ver</div>
      <div style="font-size:12px;color:var(--m2);margin-bottom:10px">Portala erişimi olmayan personeller:</div>
      <div style="max-height:400px;overflow-y:auto;display:grid;gap:4px">
        <?php foreach ($personeller as $p):
          if ($p['portal_id']) continue; // Zaten var
        ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;border:1px solid var(--kenar);border-radius:8px;background:var(--bg)">
          <div>
            <div style="font-size:13px;font-weight:600"><?php echo htmlspecialchars($p['ad_soyad']); ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($p['sicil_no']??''); ?> · <?php echo htmlspecialchars($p['dept_adi']??''); ?></div>
          </div>
          <button onclick="portalEkle(<?php echo $p['id']; ?>,'personel','<?php echo htmlspecialchars(addslashes($p['ad_soyad'])); ?>')"
            style="background:var(--t);color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer;font-size:11px;font-weight:700;white-space:nowrap">
            + Ekle
          </button>
        </div>
        <?php endforeach; ?>
        <?php
        $eksiz = array_filter($personeller, function($p){ return !$p['portal_id']; });
        if (empty($eksiz)): ?>
        <div style="text-align:center;padding:20px;color:var(--m2);font-size:13px">Tüm personele portal erişimi verilmiş.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- ═══════════════ MÜŞTERİ PORTALI ═══════════════ -->
<div style="display:grid;grid-template-columns:1fr 340px;gap:14px">

  <!-- Liste -->
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
      <div class="kart-bas">Müşteri Portal Kullanıcıları (<?php echo count($mus_portal); ?>)</div>
      <input type="text" placeholder="Ara..." oninput="filtrele(this,'musTable')" class="form-alan" style="width:160px;padding:6px 10px">
    </div>
    <table class="tablo" id="musTable">
      <thead><tr><th>Müşteri</th><th>E-posta</th><th>Kullanıcı Adı</th><th style="text-align:center">Erişim</th><th>Son Giriş</th><th style="text-align:center">İşlem</th></tr></thead>
      <tbody>
      <?php if (empty($mus_portal)): ?>
      <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--m2)">Henüz müşteri portal kullanıcısı yok.</td></tr>
      <?php else: foreach ($mus_portal as $mk): ?>
      <tr>
        <td style="font-weight:700"><?php echo htmlspecialchars($mk['musteri_adi']); ?></td>
        <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($mk['musteri_email']??'—'); ?></td>
        <td><code style="font-size:12px;background:var(--bg);padding:2px 8px;border-radius:4px;color:#0284C7;font-weight:700"><?php echo htmlspecialchars($mk['kullanici_adi']); ?></code></td>
        <td style="text-align:center">
          <span style="background:<?php echo $mk['durum']?'#D1FAE5':'#FEE2E2'; ?>;color:<?php echo $mk['durum']?'#065F46':'#991B1B'; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
            <?php echo $mk['durum']?'✓ Aktif':'✗ Pasif'; ?>
          </span>
        </td>
        <td style="font-size:11px;color:var(--m2)"><?php echo $mk['son_giris']?date('d.m.Y H:i',strtotime($mk['son_giris'])):'Henüz girmedi'; ?></td>
        <td style="text-align:center">
          <div style="display:flex;gap:4px;justify-content:center">
            <button onclick="sifreReset(<?php echo $mk['id']; ?>,'musteri')" title="Şifre Sıfırla" style="background:#FEF3C7;color:#92400E;border:none;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:13px">🔑</button>
            <button onclick="erisimToggle(<?php echo $mk['id']; ?>,<?php echo $mk['durum']; ?>,'musteri')" style="background:<?php echo $mk['durum']?'#FEE2E2':'#D1FAE5'; ?>;color:<?php echo $mk['durum']?'#991B1B':'#065F46'; ?>;border:none;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:13px"><?php echo $mk['durum']?'🔒':'🔓'; ?></button>
            <button onclick="portalSil(<?php echo $mk['id']; ?>)" style="background:#FEE2E2;color:#EF4444;border:none;padding:5px 8px;border-radius:6px;cursor:pointer;font-size:13px">🗑</button>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Sağ: Müşteri Ekle -->
  <div>
    <div class="kart" style="padding:18px;margin-bottom:14px">
      <div class="kart-bas" style="margin-bottom:14px">➕ Müşteri Portal Erişimi</div>
      <div style="max-height:350px;overflow-y:auto;display:grid;gap:4px">
        <?php foreach ($musteriler as $m):
          if ($m['portal_id']) continue;
        ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;border:1px solid var(--kenar);border-radius:8px;background:var(--bg)">
          <div>
            <div style="font-size:13px;font-weight:600"><?php echo htmlspecialchars($m['ad']); ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($m['email']??''); ?></div>
          </div>
          <button onclick="portalEkle(<?php echo $m['id']; ?>,'musteri','<?php echo htmlspecialchars(addslashes($m['ad'])); ?>')"
            style="background:#0284C7;color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer;font-size:11px;font-weight:700;white-space:nowrap">
            + Ekle
          </button>
        </div>
        <?php endforeach; ?>
        <?php
        $mus_eksiz = array_filter($musteriler, function($m){ return !$m['portal_id']; });
        if (empty($mus_eksiz)): ?>
        <div style="text-align:center;padding:20px;color:var(--m2);font-size:13px">Tüm müşterilere portal erişimi verilmiş.</div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Manuel Ekle -->
    <div class="kart" style="padding:18px">
      <div class="kart-bas" style="margin-bottom:12px">✏️ Manuel Kullanıcı Ekle</div>
      <div style="display:grid;gap:8px">
        <div><label class="form-etiket">Kullanıcı Adı *</label><input type="text" id="manKulAdi" class="form-alan" placeholder="musteri@firma"></div>
        <div><label class="form-etiket">Ad Soyad *</label><input type="text" id="manAdSoyad" class="form-alan"></div>
        <div><label class="form-etiket">E-posta</label><input type="email" id="manEmail" class="form-alan"></div>
        <div><label class="form-etiket">Telefon</label><input type="text" id="manTel" class="form-alan"></div>
        <button onclick="manuelEkle()" style="background:#0284C7;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">💾 Kaydet</button>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
</div>

<script>
var AJAX_URL = '<?php echo BASE_URL; ?>/ayarlar/ajax/portal-kul-kaydet.php';
var ISLEM_URL = '<?php echo BASE_URL; ?>/ayarlar/ajax/portal-kul-islem.php';

function filtrele(inp, tabloId) {
  var q = inp.value.toLowerCase();
  document.querySelectorAll('#' + tabloId + ' tbody tr').forEach(function(tr) {
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function portalEkle(ilgili_id, tip, ad) {
  if (!confirm('"' + ad + '" için portal erişimi oluşturulsun mu?')) return;
  var fd = new FormData();
  fd.append('islem', 'ekle'); fd.append('tip', tip); fd.append('ilgili_id', ilgili_id);
  fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){
    if (r.ok) { alert('✅ Kullanıcı oluşturuldu!\nKullanıcı adı: ' + r.kullanici_adi + '\nŞifre: ' + r.sifre); location.reload(); }
    else alert('Hata: ' + (r.hata||'?'));
  }).catch(function(){ alert('Bağlantı hatası'); });
}

function manuelEkle() {
  var adi = document.getElementById('manKulAdi').value.trim();
  var ad  = document.getElementById('manAdSoyad').value.trim();
  if (!adi || !ad) { alert('Kullanıcı adı ve ad soyad zorunlu'); return; }
  var fd = new FormData();
  fd.append('islem','manuel'); fd.append('tip','musteri');
  fd.append('kullanici_adi', adi); fd.append('ad_soyad', ad);
  fd.append('email', document.getElementById('manEmail').value);
  fd.append('telefon', document.getElementById('manTel').value);
  fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){
    if (r.ok) { alert('✅ Oluşturuldu!\nKullanıcı adı: ' + r.kullanici_adi + '\nŞifre: ' + r.sifre); location.reload(); }
    else alert('Hata: ' + (r.hata||'?'));
  }).catch(function(){ alert('Bağlantı hatası'); });
}

function sifreReset(id, tip) {
  if (!confirm('Şifre sıfırlansın mı?')) return;
  var fd = new FormData(); fd.append('islem','sifre_sifirla'); fd.append('id', id); fd.append('tip', tip);
  fetch(ISLEM_URL, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){ if(r.ok) alert('✅ Yeni şifre: ' + r.sifre); else alert('Hata: '+(r.hata||'?')); })
  .catch(function(){ alert('Bağlantı hatası'); });
}

function erisimToggle(id, mevcut, tip) {
  if (!confirm(mevcut ? 'Erişim kapatılsın mı?' : 'Erişim açılsın mı?')) return;
  var fd = new FormData(); fd.append('islem','toggle'); fd.append('id', id); fd.append('durum', mevcut?0:1);
  fetch(ISLEM_URL, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){ if(r.ok) location.reload(); else alert('Hata: '+(r.hata||'?')); })
  .catch(function(){ alert('Bağlantı hatası'); });
}

function portalSil(id) {
  if (!confirm('Bu portal kullanıcısı silinsin mi?')) return;
  var fd = new FormData(); fd.append('islem','sil'); fd.append('id', id);
  fetch(ISLEM_URL, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){ if(r.ok) location.reload(); else alert('Hata: '+(r.hata||'?')); })
  .catch(function(){ alert('Bağlantı hatası'); });
}
</script>
