<?php include __DIR__ . '/_base.php';
$basari = $hata = '';
$mailAyar = [];
try {
    $rows = $db->query("SELECT anahtar,deger FROM ayarlar_kv WHERE anahtar LIKE 'mail_%'")->fetchAll();
    foreach ($rows as $r) $mailAyar[$r['anahtar']] = $r['deger'];
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $alanlar = ['mail_host','mail_port','mail_user','mail_gonderen','mail_ad','mail_sifrele'];
    try {
        foreach ($alanlar as $k) {
            $v = trim($_POST[$k]??'');
            $db->exec("INSERT INTO ayarlar_kv (anahtar,deger) VALUES ('$k','".addslashes($v)."') ON DUPLICATE KEY UPDATE deger='".addslashes($v)."'");
        }
        if (!empty($_POST['mail_sifre'])) {
            $v = trim($_POST['mail_sifre']);
            $db->exec("INSERT INTO ayarlar_kv (anahtar,deger) VALUES ('mail_sifre','".addslashes($v)."') ON DUPLICATE KEY UPDATE deger='".addslashes($v)."'");
        }
        $basari = 'E-posta ayarları kaydedildi.';
        $rows = $db->query("SELECT anahtar,deger FROM ayarlar_kv WHERE anahtar LIKE 'mail_%'")->fetchAll();
        foreach ($rows as $r) $mailAyar[$r['anahtar']] = $r['deger'];
    } catch (Exception $e) { $hata=$e->getMessage(); }
}
?>
<div class="s-bar">
  <div><h1 class="s-bas">📧 E-posta Ayarları</h1><div class="s-yol">Ayarlar / <b>E-posta</b></div></div>
</div>
<div class="s-body">
<?php if ($basari): ?><div style="background:#D1FADF;border:1px solid #86EFAC;color:#0A8F4E;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">✅ <?php echo htmlspecialchars($basari); ?></div><?php endif; ?>
<?php if ($hata): ?><div style="background:#FEE4E2;border:1px solid #F04438;color:#F04438;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>
<form method="POST">
<div class="kart">
  <div class="kart-ust"><div class="kart-bas">📧 SMTP Sunucu Ayarları</div></div>
  <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r);padding:12px 14px;margin-bottom:14px;font-size:13px;color:#1D4ED8">
    ℹ️ Bildirim, şifre sıfırlama ve portal e-postaları için SMTP sunucu bilgilerini girin.
  </div>
  <div class="form-grid-2">
    <div class="form-grup">
      <label class="form-et">SMTP Sunucu</label>
      <input type="text" class="form-alan" name="mail_host" value="<?php echo htmlspecialchars($mailAyar['mail_host']??''); ?>" placeholder="smtp.gmail.com">
    </div>
    <div class="form-grup">
      <label class="form-et">SMTP Port</label>
      <input type="number" class="form-alan" name="mail_port" value="<?php echo $mailAyar['mail_port']??587; ?>" placeholder="587">
    </div>
    <div class="form-grup">
      <label class="form-et">Kullanıcı Adı / E-posta</label>
      <input type="text" class="form-alan" name="mail_user" value="<?php echo htmlspecialchars($mailAyar['mail_user']??''); ?>" placeholder="gonderici@firma.com">
    </div>
    <div class="form-grup">
      <label class="form-et">Şifre <span style="font-size:11px;color:var(--m2);font-weight:400">(boş bırakılırsa değişmez)</span></label>
      <input type="password" class="form-alan" name="mail_sifre" placeholder="••••••••">
    </div>
    <div class="form-grup">
      <label class="form-et">Gönderen E-posta</label>
      <input type="email" class="form-alan" name="mail_gonderen" value="<?php echo htmlspecialchars($mailAyar['mail_gonderen']??''); ?>" placeholder="noreply@firma.com">
    </div>
    <div class="form-grup">
      <label class="form-et">Gönderen Adı</label>
      <input type="text" class="form-alan" name="mail_ad" value="<?php echo htmlspecialchars($mailAyar['mail_ad']??''); ?>" placeholder="Jetone.Pro ERP">
    </div>
    <div class="form-grup">
      <label class="form-et">Şifreleme</label>
      <select class="form-alan" name="mail_sifrele">
        <option value="tls" <?php echo ($mailAyar['mail_sifrele']??'tls')==='tls'?'selected':''; ?>>TLS (önerilen)</option>
        <option value="ssl" <?php echo ($mailAyar['mail_sifrele']??'')==='ssl'?'selected':''; ?>>SSL</option>
        <option value="" <?php echo ($mailAyar['mail_sifrele']??'')===''?'selected':''; ?>>Şifrelemesiz</option>
      </select>
    </div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap">
    <button type="submit" class="btn btn-t">💾 Kaydet</button>
    <button type="button" class="btn btn-b" onclick="mailTest()">📤 Test E-postası Gönder</button>
  </div>
</div>
</form>
</div>
<script>
function mailTest() {
  var email = prompt('Test e-postası gönderilecek adres:');
  if (!email) return;
  JT.ajax('<?php echo BASE_URL; ?>/ayarlar/ajax/mail-test.php', {email:email})
    .then(function(r){ JT.bildirim(r.ok?'Test e-postası gönderildi!':r.hata||'Gönderilemedi', r.ok?'basari':'hata'); });
}
</script>
