<?php include __DIR__ . '/_base.php';
$basari = $hata = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['_islem'])) {
    try {
        $db->prepare("UPDATE ayarlar SET firma_adi=?,firma_kisa_adi=?,vergi_no=?,vergi_dairesi=?,telefon=?,email=?,web=?,adres=? WHERE id=1")
           ->execute([trim($_POST['firma_adi']??''),trim($_POST['firma_kisa_adi']??''),trim($_POST['vergi_no']??''),trim($_POST['vergi_dairesi']??''),trim($_POST['telefon']??''),trim($_POST['email']??''),trim($_POST['web']??''),trim($_POST['adres']??'')]);
        $basari='Firma bilgileri güncellendi.';
        $A = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: [];
    } catch (Exception $e) { $hata=$e->getMessage(); }
}
?>
<div class="s-bar"><div><h1 class="s-bas">🏢 Firma Bilgileri</h1><div class="s-yol">Ayarlar / <b>Firma</b></div></div></div>
<div class="s-body">
<?php if ($basari): ?><div style="background:#D1FADF;border:1px solid #86EFAC;color:#0A8F4E;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">✅ <?php echo htmlspecialchars($basari); ?></div><?php endif; ?>
<?php if ($hata): ?><div style="background:#FEE4E2;border:1px solid #F04438;color:#F04438;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>
<form method="POST">
<input type="hidden" name="_islem" value="firma">
<div class="kart">
  <div class="kart-ust"><div class="kart-bas">🏢 Firma Kimlik Bilgileri</div></div>
  <div class="form-grid-2">
    <?php $fb=['firma_adi'=>['Firma Adı *','text',true],'firma_kisa_adi'=>['Kısa Ad / Marka','text',false],'vergi_no'=>['Vergi No','text',false],'vergi_dairesi'=>['Vergi Dairesi','text',false],'telefon'=>['Telefon','tel',false],'email'=>['E-posta','email',false],'web'=>['Web Sitesi','url',false]];
    foreach ($fb as $n=>[$et,$tp,$zo]): ?>
    <div class="form-grup">
      <label class="form-et"><?php echo $et; ?></label>
      <input type="<?php echo $tp; ?>" class="form-alan" name="<?php echo $n; ?>" value="<?php echo htmlspecialchars($A[$n]??''); ?>" <?php echo $zo?'required':''; ?>>
    </div>
    <?php endforeach; ?>
    <div class="form-grup form-span-2">
      <label class="form-et">Adres</label>
      <textarea class="form-alan" name="adres" rows="3"><?php echo htmlspecialchars($A['adres']??''); ?></textarea>
    </div>
  </div>
  <div style="margin-top:14px"><button type="submit" class="btn btn-t">💾 Kaydet</button></div>
</div>
</form>
</div>
