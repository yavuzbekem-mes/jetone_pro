<?php include __DIR__ . '/_base.php';
$kullanicilar = [];
try {
    $kullanicilar = $db->query("SELECT k.*,r.ad rol_adi FROM kullanicilar k LEFT JOIN roller r ON k.rol_id=r.id ORDER BY k.durum DESC,k.ad")->fetchAll();
} catch (Exception $e) {}
?>
<div class="s-bar">
  <div><h1 class="s-bas">👤 ERP Kullanıcıları</h1><div class="s-yol">Ayarlar / <b>ERP Kullanıcıları</b></div></div>
  <div style="display:flex;gap:8px">
    <input type="text" id="kulArama" class="form-alan" style="width:200px" placeholder="Ara..." oninput="kulFiltrele()">
  </div>
</div>
<div class="s-body">
<div class="kart">
  <div class="kart-ust">
    <div class="kart-bas">ERP Kullanıcıları (<?php echo count($kullanicilar); ?>)</div>
  </div>
  <table class="tablo" id="kulTable">
    <thead><tr><th>Ad Soyad</th><th>E-posta</th><th>Rol</th><th>Durum</th><th>Şifre</th><th>Son Giriş</th><th>İşlem</th></tr></thead>
    <tbody>
    <?php foreach ($kullanicilar as $u): ?>
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:32px;height:32px;border-radius:50%;background:var(--t-a);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:var(--t);flex-shrink:0">
            <?php echo mb_strtoupper(mb_substr($u['ad'],0,1).mb_substr($u['soyad']??'',0,1)); ?>
          </div>
          <div>
            <div style="font-weight:700"><?php echo htmlspecialchars($u['ad'].' '.($u['soyad']??'')); ?></div>
            <?php if (($u['sifre_degistirildi']??1)==0): ?>
            <span style="font-size:10px;background:#FEF0C7;color:#B45309;padding:1px 5px;border-radius:8px">İlk Şifre</span>
            <?php endif; ?>
          </div>
        </div>
      </td>
      <td style="font-size:12px"><?php echo htmlspecialchars($u['email']); ?></td>
      <td><span class="roz" style="background:var(--t-a);color:var(--t)"><?php echo htmlspecialchars($u['rol_adi']??'—'); ?></span></td>
      <td><span class="roz" style="background:<?php echo $u['durum']?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo $u['durum']?'#0A8F4E':'#F04438'; ?>"><?php echo $u['durum']?'✓ Aktif':'✗ Pasif'; ?></span></td>
      <td><span class="roz" style="background:<?php echo ($u['sifre_degistirildi']??1)?'#D1FADF':'#FEF0C7'; ?>;color:<?php echo ($u['sifre_degistirildi']??1)?'#0A8F4E':'#B45309'; ?>"><?php echo ($u['sifre_degistirildi']??1)?'✓':'⚠ İlk'; ?></span></td>
      <td style="font-size:11px;color:var(--m2)"><?php echo $u['son_giris']?date('d.m.Y H:i',strtotime($u['son_giris'])):'—'; ?></td>
      <td>
        <div style="display:flex;gap:4px">
          <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=kullanici-profil&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-b" title="Profil">👤</a>
          <?php if ($super_adm): ?>
          <button class="btn btn-sm btn-b" onclick="erpSifreReset(<?php echo $u['id']; ?>,'<?php echo htmlspecialchars($u['email']); ?>')" title="Şifre Sıfırla">🔑</button>
          <button class="btn btn-sm btn-b" onclick="erpToggle(<?php echo $u['id']; ?>,<?php echo $u['durum']; ?>)" title="<?php echo $u['durum']?'Kapat':'Aç'; ?>"><?php echo $u['durum']?'🔒':'🔓'; ?></button>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
</div>
<script>
function kulFiltrele() {
  var q = document.getElementById('kulArama').value.toLowerCase();
  document.querySelectorAll('#kulTable tbody tr').forEach(function(tr){
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
function erpSifreReset(id, email) {
  if (!confirm(email+' şifresi sıfırlansın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',{islem:'sifre_sifirla',erp_kul_id:id})
    .then(function(r){ if(r.ok) alert('✅ Yeni şifre: '+r.yeni_sifre); else JT.bildirim(r.hata,'hata'); });
}
function erpToggle(id, mevcut) {
  if (!confirm(mevcut?'Hesap kapatılsın mı?':'Hesap açılsın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',{islem:'toggle_erisim',erp_kul_id:id})
    .then(function(r){ if(r.ok){JT.bildirim(r.mesaj,'basari');setTimeout(function(){location.reload();},800);}else JT.bildirim(r.hata,'hata'); });
}
</script>
