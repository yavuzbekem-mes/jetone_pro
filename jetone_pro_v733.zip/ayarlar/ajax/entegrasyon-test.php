<?php
/**
 * Entegrasyon Bağlantı Testi
 * ayarlar/ajax/entegrasyon-test.php
 */
// AJAX endpoint: PHP hataları JSON'u bozmasın
ob_start();
ini_set('display_errors', 0);
error_reporting(0);

require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';

// Output buffer'ı temizle (varsa PHP uyarıları)
ob_clean();
header('Content-Type: application/json; charset=utf-8');

/**
 * PHP native SMTP ile mail gönder (PHPMailer gerektirmez)
 */
function smtpTestGonder($host, $port, $secure, $user, $pass, $to, $fromName='Jetone ERP') {
    $log = [];
    $err = '';
    
    try {
        $ctx = stream_context_create([
            'ssl' => ['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]
        ]);
        
        if ($secure === 'ssl') {
            $fp = @stream_socket_client("ssl://$host:$port", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
        } else {
            $fp = @fsockopen($host, $port, $errno, $errstr, 15);
        }
        
        if (!$fp) return ['ok'=>false,'hata'=>"Bağlantı kurulamadı: $errstr ($errno)",'log'=>$log];
        
        stream_set_timeout($fp, 15);
        
        $read = function() use ($fp, &$log) {
            $r = fgets($fp, 512);
            $log[] = '< ' . trim($r);
            return $r;
        };
        $write = function($s) use ($fp, &$log) {
            $log[] = '> ' . trim($s);
            return fputs($fp, $s);
        };
        
        $read(); // 220 greeting
        $write("EHLO jetone.pro
");
        $resp = '';
        while ($line = fgets($fp, 512)) {
            $resp .= $line;
            $log[] = '< ' . trim($line);
            if (substr($line, 3, 1) == ' ') break;
        }
        
        if ($secure === 'tls') {
            $write("STARTTLS
");
            $read();
            stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $write("EHLO jetone.pro
");
            while ($line = fgets($fp, 512)) {
                $log[] = '< ' . trim($line);
                if (substr($line, 3, 1) == ' ') break;
            }
        }
        
        $write("AUTH LOGIN
");
        $read();
        $write(base64_encode($user) . "
");
        $read();
        $write(base64_encode($pass) . "
");
        $authResp = $read();
        
        if (substr($authResp, 0, 3) !== '235') {
            fclose($fp);
            return ['ok'=>false,'hata'=>'Kimlik doğrulama başarısız: ' . trim($authResp),'log'=>$log];
        }
        
        $write("MAIL FROM:<$user>
");
        $read();
        $write("RCPT TO:<$to>
");
        $read();
        $write("DATA
");
        $read();
        
        $date = date('r');
        $body = "Date: $date
"
              . "From: $fromName <$user>
"
              . "To: $to
"
              . "Subject: Jetone ERP - SMTP Test Maili
"
              . "MIME-Version: 1.0
"
              . "Content-Type: text/plain; charset=UTF-8
"
              . "
"
              . "Merhaba,

"
              . "Bu bir Jetone ERP test mailidir.
"
              . "SMTP ayarlariniz dogru calisiyor!

"
              . "Sunucu: $host:$port
"
              . "Tarih: " . date('d.m.Y H:i:s') . "
";
        
        $write($body . "
.
");
        $dataResp = $read();
        
        $write("QUIT
");
        fclose($fp);
        
        if (substr($dataResp, 0, 3) === '250') {
            return ['ok'=>true,'log'=>$log];
        } else {
            return ['ok'=>false,'hata'=>'Mail kabul edilmedi: ' . trim($dataResp),'log'=>$log];
        }
        
    } catch (Throwable $e) {
        return ['ok'=>false,'hata'=>$e->getMessage(),'log'=>$log];
    }
}

Auth::zorunlu();

$d  = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id = (int)($d['id'] ?? 0);

// Form değerleri doğrudan geldiyse DB'ye gerek yok
$ent = null;
if (!empty($d['host'])) {
    // Formdaki anlık değerleri kullan
    $ent = [
        'id'          => $id,
        'tip'         => '', // aşağıda DB'den alınacak
        'host'        => trim($d['host'] ?? ''),
        'port'        => (int)($d['port'] ?? 0) ?: null,
        'veritabani'  => trim($d['veritabani'] ?? ''),
        'kullanici'   => trim($d['kullanici'] ?? ''),
        'sifre'       => null, // ham olarak geldi, şifreleme YOK
        'ek_parametreler' => json_encode(array_filter([
            'firm_no'       => trim($d['firm_no'] ?? ''),
            'client_id'     => trim($d['client_id'] ?? ''),
            'client_secret' => trim($d['client_secret'] ?? ''),
        ])),
    ];
    // tip için DB'den oku
    if ($id) {
        try {
            $ts = $db->prepare("SELECT tip FROM entegrasyonlar WHERE id=? LIMIT 1");
            $ts->execute([$id]);
            $tr = $ts->fetch();
            if ($tr) $ent['tip'] = $tr['tip'];
        } catch (Exception $e) {}
    }
    // Şifre: form boşsa DB'deki şifreli halini çöz, doluysa direkt kullan
    if (!empty($d['sifre'])) {
        $sifre = $d['sifre']; // form'dan geldi — düz metin
    } else {
        // DB'den al
        try {
            $ss = $db->prepare("SELECT sifre FROM entegrasyonlar WHERE id=? LIMIT 1");
            $ss->execute([$id]);
            $sr = $ss->fetch();
            $key   = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
            $sifreli = $sr['sifre'] ?? '';
            $sifre = $sifreli ? (openssl_decrypt($sifreli,'AES-256-CBC',$key,0,'1234567890123456') ?: $sifreli) : '';
        } catch (Exception $e) { $sifre = ''; }
    }
} elseif ($id) {
    // Sadece id geldi — DB'den oku
    $stmt = $db->prepare("SELECT * FROM entegrasyonlar WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
    $ent = $stmt->fetch();
    if (!$ent) Auth::json(['ok'=>false,'hata'=>'Entegrasyon bulunamadı.']);

    $key   = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
    $sifre = '';
    if (!empty($ent['sifre'])) {
        $sifre = openssl_decrypt($ent['sifre'], 'AES-256-CBC', $key, 0, '1234567890123456');
        if ($sifre === false) $sifre = $ent['sifre'];
    }
} else {
    Auth::json(['ok'=>false,'hata'=>'Geçersiz istek.']);
}

$baslangic = microtime(true);
$sonuc = false;
$mesaj = '';
$detay = [];

try {
    switch ($ent['tip']) {

        // ── MSSQL (TIGERDB / MES) ────────────────────────────
        case 'mssql':
            $host = trim($ent['host'] ?: 'localhost');
            $vt   = trim($ent['veritabani'] ?: '');
            $user = trim($ent['kullanici']  ?: '');
            $port = (int)($ent['port'] ?: 0);

            $serverStr = ($port && $port !== 1433) ? "$host,$port" : $host;
            $dsn = "sqlsrv:server=$serverStr;Database=$vt";

            $son_hata = '';

            // 1. Girilen host ile dene (POLIZASERVER veya 192.168.1.100)
            try {
                $pdo = new PDO($dsn, $user, $sifre, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
                $pdo->query("SELECT 1");
                $sonuc = true;
                $mesaj = "✅ SQL Server bağlantısı başarılı — $vt @ $host";
                $detay[] = "DSN: $dsn";
                break;
            } catch (Throwable $e1) {
                $son_hata = $e1->getMessage();
            }

            // 2. Hostname ise IP'ye çevirip tekrar dene (VPN'de DNS çalışmayabilir)
            if (!filter_var($host, FILTER_VALIDATE_IP)) {
                $ip = @gethostbyname($host);
                if ($ip && $ip !== $host) {
                    $serverStr2 = ($port && $port !== 1433) ? "$ip,$port" : $ip;
                    $dsn2 = "sqlsrv:server=$serverStr2;Database=$vt";
                    try {
                        $pdo2 = new PDO($dsn2, $user, $sifre, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
                        $pdo2->query("SELECT 1");
                        $sonuc = true;
                        $mesaj = "✅ Bağlantı başarılı (IP ile) — $vt @ $ip";
                        $detay[] = "'$host' → $ip olarak çözümlendi";
                        $detay[] = "💡 Host alanına '$ip' yazmanız önerilir";
                        break;
                    } catch (Throwable $e2) {
                        $son_hata = $e2->getMessage();
                    }
                } else {
                    $detay[] = "DNS çözümlemesi başarısız: '$host' IP'ye çevrilemedi";
                    $detay[] = "💡 Host alanına '192.168.1.100' gibi direkt IP yazın";
                }
            }

            // İkisi de başarısız — hatayı fırlat
            throw new Exception($son_hata ?: "Bağlantı kurulamadı");

        // ── REST API (Logo Tiger REST) ────────────────────────
        case 'rest_api':
            $ek        = json_decode($ent['ek_parametreler'] ?? '{}', true) ?: [];
            // host değeri: "http://192.168.1.100:32001/api/v1/" formatında olabilir
            $rawHost   = rtrim($ent['host'], '/');
            // Eğer /api/v1 ile bitiyorsa token endpoint'i farklı
            if (preg_match('#/api/v[0-9]+$#i', $rawHost)) {
                // http://host:port/api/v1 → token → http://host:port/api/v1/token
                $baseUrl  = $rawHost;
                $tokenUrl = $baseUrl . '/token';
            } else {
                $baseUrl  = $rawHost;
                $tokenUrl = $baseUrl . '/api/v1/token';
            }

            // Token isteği — verilen örnek kodla birebir
            $postData = http_build_query([
                'username'      => $ent['kullanici'],
                'password'      => $sifre,
                'grant_type'    => 'password',
                'firmno'        => $ek['firm_no']       ?? $ek['firma_no'] ?? '1',
                'client_id'     => $ek['client_id']     ?? '',
                'client_secret' => $ek['client_secret'] ?? '',
            ]);

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $tokenUrl,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $postData,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_VERBOSE        => false,
            ]);

            $yanit   = curl_exec($ch);
            $httpKod = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($curlErr) {
                // curl bağlantı hatası — sunucuya ulaşamıyor
                if (strpos($curlErr,'timed out') !== false || strpos($curlErr,'Connection refused') !== false) {
                    $mesaj = "❌ Sunucuya ulaşılamıyor: $curlErr";
                    $detay[] = "URL: $tokenUrl";
                    $detay[] = "192.168.1.100 adresine erişiminiz var mı? Aynı ağda mısınız?";
                } else {
                    $mesaj = "❌ Bağlantı hatası: $curlErr";
                    $detay[] = "URL: $tokenUrl";
                }
                break;
            }
            if ($httpKod >= 400) {
                $mesaj = "❌ HTTP $httpKod — Yanıt: " . substr($yanit,0,200);
                break;
            }

            $sonucJson = json_decode($yanit, true);
            if (!empty($sonucJson['access_token'])) {
                $token = $sonucJson['access_token'];
                $sonuc = true;
                $mesaj = "✅ Logo REST API token alındı. HTTP $httpKod";
                $detay[] = 'Token (ilk 40 karakter): ' . substr($token, 0, 40) . '...';

                // Token'ı api_token_kayitlar tablosuna kaydet
                try {
                    $entId = $db->query("SELECT id FROM entegrasyonlar WHERE kod='logo_rest' LIMIT 1")->fetchColumn();
                    if ($entId) {
                        $db->prepare("UPDATE api_token_kayitlar SET aktif=0 WHERE entegrasyon_id=?")->execute([$entId]);
                        $db->prepare("INSERT INTO api_token_kayitlar (entegrasyon_id,token,aktif) VALUES (?,?,1)")->execute([$entId,$token]);
                    }
                } catch (Exception $ignore) {}
                $GLOBALS['API_TOKEN'] = $token;
            } else {
                $mesaj = "❌ Token alınamadı. Yanıt: " . substr($yanit,0,300);
                $detay[] = "URL: $tokenUrl";
            }
            break;

        // ── MySQL ─────────────────────────────────────────────
        case 'mysql':
            $port = $ent['port'] ?: 3306;
            $dsn  = "mysql:host={$ent['host']};port=$port;dbname={$ent['veritabani']};charset=utf8mb4";
            $pdo  = new PDO($dsn, $ent['kullanici'], $sifre, [PDO::ATTR_TIMEOUT=>5]);
            $pdo->query("SELECT 1");
            $sonuc = true;
            $mesaj = "✅ MySQL bağlantısı başarılı — {$ent['veritabani']}";
            break;

        // ── SMTP ──────────────────────────────────────────────
        case 'smtp':
            $host      = $ent['host']    ?: 'localhost';
            $port      = $ent['port']    ?: 587;
            $kullanici = $ent['kullanici'] ?? '';
            $sifre_raw = $ent['sifre']   ?? '';
            $ekPar     = json_decode($ent['ek_parametreler'] ?? '{}', true) ?: [];
            $secure    = $ekPar['smtp_secure'] ?? ($port == 465 ? 'ssl' : 'tls');
            $fromName  = $ekPar['smtp_from_name'] ?? 'Jetone ERP';

            // Override with form values if provided
            if (!empty($d['host']))      $host      = $d['host'];
            if (!empty($d['port']))      $port      = (int)$d['port'];
            if (!empty($d['kullanici'])) $kullanici = $d['kullanici'];
            if (!empty($d['sifre']))     $sifre_raw = $d['sifre'];
            if (isset($d['smtp_secure'])) $secure   = $d['smtp_secure'];

            // Hedef mail adresi varsa gerçek mail gönder
            $hedef = $d['test_mail'] ?? $d['aksiyon'] ?? '';
            $aksiyon = $d['aksiyon'] ?? '';

            if ($aksiyon === 'smtp_test_mail' && filter_var($hedef, FILTER_VALIDATE_EMAIL)) {
                // PHP native SMTP ile test maili gönder
                try {
                    $smtpResult = smtpTestGonder($host, $port, $secure, $kullanici, $sifre_raw, $hedef, $fromName);
                    if ($smtpResult['ok']) {
                        $sonuc = true;
                        $mesaj = "✅ Test maili gönderildi: $hedef";
                    } else {
                        $mesaj = '❌ Mail gönderilemedi: ' . $smtpResult['hata'];
                        $detay[] = 'Host: ' . $host . ':' . $port . ' (' . $secure . ')';
                        $detay[] = 'Kullanıcı: ' . $kullanici;
                        if (!empty($smtpResult['log'])) {
                            foreach ($smtpResult['log'] as $l) $detay[] = $l;
                        }
                    }
                } catch (Throwable $ex) {
                    $mesaj = '❌ ' . $ex->getMessage();
                }
            } else {
                // Sadece bağlantı testi
                $ctx = null;
                if ($secure === 'ssl') {
                    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
                    $fp = @stream_socket_client("ssl://$host:$port", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
                } else {
                    $fp = @fsockopen($host, $port, $errno, $errstr, 10);
                }
                if ($fp) {
                    fclose($fp);
                    $sonuc = true;
                    $mesaj = "✅ SMTP bağlantısı başarılı — $host:$port ($secure)";
                    $detay[] = "Gerçek test için 'Test E-posta Gönder' butonunu kullanın";
                } else {
                    $mesaj = "❌ SMTP bağlantısı başarısız: $errstr ($errno)";
                    $detay[] = "Host: $host | Port: $port | Secure: $secure";
                }
            }
            break;

        default:
            $mesaj = "Bu entegrasyon tipi için test desteklenmiyor: {$ent['tip']}";
    }
} catch (Throwable $e) {
    $ham_hata = $e->getMessage();
    $mesaj = "❌ " . $ham_hata;

    if (strpos($ham_hata, 'could not find driver') !== false) {
        // pdo_sqlsrv yüklü değil
        $mesaj = "❌ pdo_sqlsrv sürücüsü bulunamadı.";
        $detay[] = "Laragon → PHP → Eklentiler → pdo_sqlsrv_83_nts_x64 işaretleyin";
        $detay[] = "Ham hata: " . $ham_hata;

    } elseif (strpos($ham_hata, 'Named Pipes') !== false
           || strpos($ham_hata, 'Could not open a connection') !== false
           || strpos($ham_hata, 'SQL Server') !== false
           || strpos($ham_hata, 'Unable to connect') !== false
           || strpos($ham_hata, 'network-related') !== false) {
        // pdo_sqlsrv kurulu ama sunucuya ulaşılamıyor
        $mesaj = "❌ SQL Server'a bağlanılamadı — sunucuya erişilemiyor.";
        $detay[] = "Ham hata: " . $ham_hata;
        $detay[] = "Sunucu: " . ($ent['host']??'?') . " — Ağ bağlantısını kontrol edin";
        $detay[] = "Fabrika dışındaysanız VPN bağlantısını kontrol edin (POLIZA-OPVPN)";
        $detay[] = "Windows Güvenlik Duvarında SQL Server portuna (1433) izin verildiğinden emin olun";

    } else {
        // Diğer hatalar
        $mesaj = "❌ Bağlantı hatası";
        $detay[] = "Ham hata: " . $ham_hata;
        $detay[] = "DSN: sqlsrv:server=" . ($ent['host']??'?') . ";Database=" . ($ent['veritabani']??'?');
    }
}

$sure = round((microtime(true) - $baslangic) * 1000); // ms

// Sonucu DB'ye kaydet
try {
    $db->prepare("UPDATE entegrasyonlar SET son_test_tarihi=NOW(), son_test_sonucu=?, son_test_mesaji=? WHERE id=?")
       ->execute([$sonuc?1:0, mb_substr($mesaj,0,500), $id]);
} catch (Exception $ignore) {}

Auth::json([
    'ok'    => $sonuc,
    'mesaj' => $mesaj,
    'sure'  => $sure . 'ms',
    'detay' => $detay,
]);
