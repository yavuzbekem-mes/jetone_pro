<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
// ayarlar/ajax/genel-kaydet.php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
$d = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$izinli = ['firma_adi','firma_kisa_adi','vergi_no','vergi_dairesi','telefon','email','adres','web','para_birimi','tarih_formati','saat_dilimi','dil','tema'];
$guncelle = [];
foreach ($izinli as $alan) {
    if (isset($d[$alan])) $guncelle[] = "$alan = " . $db->quote($d[$alan]);
}
if (empty($guncelle)) Auth::json(['ok'=>false,'hata'=>'Güncellenecek alan yok.']);
$db->exec("UPDATE ayarlar SET " . implode(', ', $guncelle) . " LIMIT 1");
Auth::logKaydet(Auth::kullanici()['id'] ?? null, 'ayarlar_guncelle', 'ayarlar');
Auth::json(['ok'=>true]);
