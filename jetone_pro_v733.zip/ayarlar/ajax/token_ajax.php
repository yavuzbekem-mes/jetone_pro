<?php
// Tüm hata çıktılarını engelle — sadece JSON dön
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Tüm output buffer'ları temizle
while (ob_get_level() > 0) { ob_end_clean(); }
ob_start();

// Bağımlılıkları yükle
if (!defined('ROOT_DIR')) {
    require_once dirname(__DIR__, 2) . '/core/config.php';
}
if (!isset($mes_pdo)) {
    require_once ROOT_DIR . '/core/baglanlogo.php';
}
if (!class_exists('Auth')) {
    require_once ROOT_DIR . '/core/auth.php';
}

// Buffer'ı temizle ve JSON header yaz
while (ob_get_level() > 0) { ob_end_clean(); }
header('Content-Type: application/json; charset=utf-8');

// Oturum kontrolü
if (!Auth::girisYapilmisMi()) {
    echo json_encode(['basari' => false, 'mesaj' => 'Oturum gecersiz']); exit;
}
if (!isset($mes_pdo) || !$mes_pdo) {
    echo json_encode(['basari' => false, 'mesaj' => 'MES baglantisi yok']); exit;
}

// Global_Rest sınıfını burada tanımla — token.php include etme
if (!class_exists('Global_Rest')) {
    class Global_Rest {
        public static $g_URL        = "http://192.168.1.100:32001/api/v1/";
        public static $g_UserName   = "ARS";
        public static $g_UserPass   = "qazwsx123";
        public static $g_FirmNr     = "222";
        public static $clientId     = "ARS";
        public static $clientSecret = "0fQYNl3QTZvTzOD41M8Ee58NQI3Gq+2l3x5FAoQM7Kc=";

        public static function GetToken(): string {
            $url  = self::$g_URL . "token";
            $data = [
                "username"      => self::$g_UserName,
                "password"      => self::$g_UserPass,
                "grant_type"    => "password",
                "firmno"        => self::$g_FirmNr,
                "client_id"     => self::$clientId,
                "client_secret" => self::$clientSecret,
            ];
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_POST           => 1,
                CURLOPT_POSTFIELDS     => http_build_query($data),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT        => 15,
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr  = curl_error($ch);
            curl_close($ch);
            if ($curlErr)         throw new Exception("cURL: $curlErr");
            if ($httpCode >= 400) throw new Exception("HTTP $httpCode");
            $result = json_decode($response, true);
            if (empty($result['access_token'])) throw new Exception("access_token yok");
            return $result['access_token'];
        }
    }
}

$aksiyon = trim($_POST['aksiyon'] ?? '');

// ── Yeni Token Al ─────────────────────────────────────────────────────────────
if ($aksiyon === 'yeni_token') {
    try {
        $token = Global_Rest::GetToken();
        $ins = $mes_pdo->prepare(
            "INSERT INTO REST_SERVIS_KAYITLAR (TOKEN, TARIH) VALUES (?, GETDATE())"
        );
        $ins->execute([$token]);
        echo json_encode(['basari' => true, 'mesaj' => 'Yeni token alindi ve kaydedildi.']);
    } catch (Throwable $e) {
        error_log("[TOKEN_AJAX] yeni_token: " . $e->getMessage());
        echo json_encode(['basari' => false, 'mesaj' => $e->getMessage()]);
    }
    exit;
}

// ── Token Sil ─────────────────────────────────────────────────────────────────
if ($aksiyon === 'token_sil') {
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) { echo json_encode(['basari' => false, 'mesaj' => 'Gecersiz ID']); exit; }
    try {
        $mes_pdo->prepare("DELETE FROM REST_SERVIS_KAYITLAR WHERE ID = ?")->execute([$id]);
        echo json_encode(['basari' => true, 'mesaj' => 'Token silindi.']);
    } catch (Throwable $e) {
        echo json_encode(['basari' => false, 'mesaj' => $e->getMessage()]);
    }
    exit;
}

// ── Token Test ────────────────────────────────────────────────────────────────
if ($aksiyon === 'token_test') {
    $token = trim($_POST['token'] ?? '');
    if (!$token) { echo json_encode(['basari' => false, 'mesaj' => 'Token bos']); exit; }
    try {
        // Token test: /api/v1/token ile yenile — 200 = geçerli sunucu erişimi var
        // Alternatif: GET /productions?$top=1 ile dene, 401=geçersiz
        $url = rtrim(Global_Rest::$g_URL, '/') . '/productions?$top=1';
        $ch  = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                "Authorization: Bearer $token",
                "Accept: application/json",
            ],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT        => 10,
        ]);
        $yanit = curl_exec($ch);
        $kod   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $kerr  = curl_error($ch);
        curl_close($ch);

        if ($kerr) throw new Exception("cURL: $kerr");

        // 401/403 = token geçersiz; diğer tüm kodlar = token geçerli (sunucu yanıt veriyor)
        $gecerli = ($kod !== 0 && $kod !== 401 && $kod !== 403);
        echo json_encode([
            'basari' => $gecerli,
            'mesaj'  => $gecerli ? "Gecerli (HTTP $kod)" : "Gecersiz (HTTP $kod)",
        ]);
    } catch (Throwable $e) {
        echo json_encode(['basari' => false, 'mesaj' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['basari' => false, 'mesaj' => 'Bilinmeyen aksiyon']);
