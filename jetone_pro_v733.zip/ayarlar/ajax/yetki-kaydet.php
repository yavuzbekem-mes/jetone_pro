<?php
ini_set('display_errors', 0);
error_reporting(0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz istek']); exit;
}

$rid = (int)($_POST['rol_id'] ?? 0);
if (!$rid) { echo json_encode(['ok'=>false,'hata'=>'Rol ID gerekli']); exit; }

// Süper Admin kısıtlanamaz
if ($rid === 1) { echo json_encode(['ok'=>false,'hata'=>'Süper Admin değiştirilemez']); exit; }

$moduller_listesi = ['ik','satis','satinalma','uretim','planlama','kalite','depo','idari','raporlar','ayarlar'];

try {
    // Bu rolün yetkilerini sil
    $db->prepare("DELETE FROM yetkiler WHERE rol_id=?")->execute([$rid]);

    $moduller_post = $_POST['modul'] ?? [];
    $sayfalar_post = $_POST['sayfa'] ?? [];

    foreach ($moduller_listesi as $modul_key) {
        $goruntule = isset($moduller_post[$modul_key]['goruntule']) ? 1 : 0;
        if (!$goruntule) continue;

        // Modül genel izni
        $db->prepare("INSERT INTO yetkiler (rol_id,modul,sayfa,goruntule,ekle,duzenle,sil,export) VALUES (?,?,'*',?,?,?,?,?)")
           ->execute([
               $rid, $modul_key, 1,
               isset($moduller_post[$modul_key]['ekle'])    ? 1 : 0,
               isset($moduller_post[$modul_key]['duzenle']) ? 1 : 0,
               isset($moduller_post[$modul_key]['sil'])     ? 1 : 0,
               isset($moduller_post[$modul_key]['export'])  ? 1 : 0,
           ]);

        // Kapalı sayfalar için kayıt ekle
        $secili_sayfalar = $sayfalar_post[$modul_key] ?? [];
        // Tüm sayfa listesi
        $tum_sayfalar_map = [
            'ik'=>['ik-personeller','ik-devam','ik-izinler','ik-mesai','ik-vardiya','ik-bordro','ik-maas','ik-turnover','ik-anket','ik-ihtar-listesi','ik-perf-listesi','ik-duyuru-listesi','ik-oneri'],
            'satis'=>['satis-musteriler','satis-firsatlar','satis-teklifler','satis-siparisler'],
            'satinalma'=>['satinalma-talepler','satinalma-teklifler','satinalma-siparisler','satinalma-tedarikciler'],
            'uretim'=>['uretim-is-emirleri','uretim-cizelge','uretim-makine','uretim-oee','uretim-recete'],
            'planlama'=>['planlama-mps','planlama-mrp','planlama-kapasite','planlama-malzeme'],
            'kalite'=>['kalite-muayene','kalite-dof','kalite-denetim','kalite-sertifika'],
            'depo'=>['depo-stok','depo-hareketler','depo-irsaliye','depo-sevkiyat','depo-iade'],
            'idari'=>['idari-arac-listesi','idari-teklif-listesi','idari-sozlesme-listesi','idari-demirbas-listesi','idari-servis','idari-yemek'],
            'raporlar'=>['raporlar-genel'],
            'ayarlar'=>['ayarlar-firma','ayarlar-bolgesel','ayarlar-mail','ayarlar-roller','ayarlar-kullanici','ayarlar-portal','ayarlar-geofence','ayarlar-enteg'],
        ];

        foreach (($tum_sayfalar_map[$modul_key] ?? []) as $sayfa_id) {
            if (!isset($secili_sayfalar[$sayfa_id])) {
                // Bu sayfa seçilmemiş - kapalı kayıt ekle
                $db->prepare("INSERT IGNORE INTO yetkiler (rol_id,modul,sayfa,goruntule,ekle,duzenle,sil,export) VALUES (?,?,?,0,0,0,0,0)")
                   ->execute([$rid, $modul_key, $sayfa_id]);
            }
        }
    }
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
