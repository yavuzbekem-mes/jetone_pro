<?php
ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$islem = $_POST['islem'] ?? '';

try {
    if ($islem === 'ekle') {
        // Mevcut personel/müşteriye portal erişimi ver
        $tip       = $_POST['tip'] ?? 'personel';
        $ilgili_id = (int)($_POST['ilgili_id'] ?? 0);
        if (!$ilgili_id) { echo json_encode(['ok'=>false,'hata'=>'ID gerekli']); exit; }

        // Kullanıcı adı ve şifre oluştur
        if ($tip === 'personel') {
            $p = $db->prepare("SELECT ad, soyad, sicil_no, email FROM personeller WHERE id=? LIMIT 1");
            $p->execute([$ilgili_id]); $p = $p->fetch();
            if (!$p) { echo json_encode(['ok'=>false,'hata'=>'Personel bulunamadı']); exit; }
            $kul_adi = $p['sicil_no'] ?: ('P-'.str_pad($ilgili_id,5,'0',STR_PAD_LEFT));
            $ad_soyad = $p['ad'].' '.$p['soyad'];
            $email = $p['email'] ?? '';
        } else {
            $m = $db->prepare("SELECT ad, email FROM musteriler WHERE id=? LIMIT 1");
            $m->execute([$ilgili_id]); $m = $m->fetch();
            if (!$m) { echo json_encode(['ok'=>false,'hata'=>'Müşteri bulunamadı']); exit; }
            $email_base = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $m['ad']));
            $kul_adi = $email_base ?: ('M-'.$ilgili_id);
            $ad_soyad = $m['ad'];
            $email = $m['email'] ?? '';
        }

        // Benzersiz kullanıcı adı
        $base = $kul_adi; $suffix = 0;
        while ($db->prepare("SELECT id FROM portal_kullanicilari WHERE kullanici_adi=? LIMIT 1")->execute([$kul_adi]) && 
               $db->prepare("SELECT id FROM portal_kullanicilari WHERE kullanici_adi=? LIMIT 1")->execute([$kul_adi]) &&
               ($chk = $db->prepare("SELECT id FROM portal_kullanicilari WHERE kullanici_adi=? LIMIT 1")) &&
               $chk->execute([$kul_adi]) && $chk->fetch()) {
            $suffix++; $kul_adi = $base.$suffix;
        }

        $sifre = ucfirst(strtolower(preg_replace('/[^a-zA-Z]/','',$ad_soyad) ?: 'Portal')).'2024!';
        $hash  = password_hash($sifre, PASSWORD_DEFAULT);

        $db->prepare("INSERT INTO portal_kullanicilari (tip,ilgili_id,kullanici_adi,ad_soyad,email,sifre_hash,durum) VALUES (?,?,?,?,?,?,1)")
           ->execute([$tip,$ilgili_id,$kul_adi,$ad_soyad,$email,$hash]);

        echo json_encode(['ok'=>true,'kullanici_adi'=>$kul_adi,'sifre'=>$sifre]);

    } elseif ($islem === 'manuel') {
        // Manuel müşteri portal kullanıcısı
        $kul_adi  = trim($_POST['kullanici_adi'] ?? '');
        $ad_soyad = trim($_POST['ad_soyad'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $tel      = trim($_POST['telefon'] ?? '');
        if (!$kul_adi || !$ad_soyad) { echo json_encode(['ok'=>false,'hata'=>'Kullanıcı adı ve ad soyad zorunlu']); exit; }

        $chk = $db->prepare("SELECT id FROM portal_kullanicilari WHERE kullanici_adi=? LIMIT 1");
        $chk->execute([$kul_adi]);
        if ($chk->fetch()) { echo json_encode(['ok'=>false,'hata'=>'Bu kullanıcı adı zaten kullanılıyor']); exit; }

        // Önce musteriler tablosuna ekle - otomatik kod üret
        $son_kod = $db->query("SELECT MAX(CAST(SUBSTRING(kod,3) AS UNSIGNED)) FROM musteriler WHERE kod LIKE 'M-%'")->fetchColumn();
        $yeni_kod = 'M-' . str_pad(((int)$son_kod + 1), 4, '0', STR_PAD_LEFT);
        $db->prepare("INSERT INTO musteriler (kod, ad, email, telefon) VALUES (?,?,?,?)")
           ->execute([$yeni_kod, $ad_soyad, $email, $tel]);
        $musteri_id = (int)$db->lastInsertId();

        $sifre = 'Portal2024!';
        $hash  = password_hash($sifre, PASSWORD_DEFAULT);
        $db->prepare("INSERT INTO portal_kullanicilari (tip,ilgili_id,kullanici_adi,ad_soyad,email,telefon,sifre_hash,durum) VALUES ('musteri',?,?,?,?,?,?,1)")
           ->execute([$musteri_id,$kul_adi,$ad_soyad,$email,$tel,$hash]);

        echo json_encode(['ok'=>true,'kullanici_adi'=>$kul_adi,'sifre'=>$sifre,'musteri_id'=>$musteri_id]);
    } else {
        echo json_encode(['ok'=>false,'hata'=>'Geçersiz işlem']);
    }
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
