<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
// ayarlar/ajax/portal-kul-sil.php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
$d = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id = (int)($d['id'] ?? 0);
if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);
$db->prepare("DELETE FROM portal_kullanicilari WHERE id=?")->execute([$id]);
Auth::json(['ok'=>true]);
