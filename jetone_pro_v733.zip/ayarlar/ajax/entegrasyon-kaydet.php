<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Entegrasyon Kaydet — ayarlar/ajax/entegrasyon-kaydet.php
 */
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';

ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();

$d = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id = (int)($d['id'] ?? 0);

if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);

// Ek parametreler (REST API için)
$ekPar = [];
if (!empty($d['firm_no']))       $ekPar['firm_no']       = $d['firm_no'];
if (!empty($d['client_id']))     $ekPar['client_id']     = $d['client_id'];
if (!empty($d['client_secret'])) $ekPar['client_secret'] = $d['client_secret'];
// SMTP ek alanlar
if (isset($d['smtp_secure']))    $ekPar['smtp_secure']    = $d['smtp_secure'];
if (!empty($d['smtp_from_name']))$ekPar['smtp_from_name'] = trim($d['smtp_from_name']);

// Şifreyi sakla (AES-256-CBC ile şifrele)
$sifre = null;
if (!empty($d['sifre'])) {
    $key   = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
    $raw   = trim($d['sifre']);
    $enc   = openssl_encrypt($raw, 'AES-256-CBC', $key, 0, '1234567890123456');
    // Doğrulama: hemen çöz ve karşılaştır
    $test  = openssl_decrypt($enc, 'AES-256-CBC', $key, 0, '1234567890123456');
    $sifre = ($test === $raw) ? $enc : base64_encode($raw); // şifreleme başarısızsa base64
}

try {
    $sql = "UPDATE entegrasyonlar SET
                host         = :host,
                port         = :port,
                veritabani   = :vt,
                kullanici    = :kul,
                ek_parametreler = :ekpar,
                guncelleme   = NOW()
            WHERE id = :id";

    if ($sifre) $sql = str_replace('guncelleme', 'sifre = :sifre, guncelleme', $sql);

    $stmt = $db->prepare($sql);
    $bind = [
        ':host'  => trim($d['host'] ?? ''),
        ':port'  => !empty($d['port']) ? (int)$d['port'] : null,
        ':vt'    => trim($d['veritabani'] ?? ''),
        ':kul'   => trim($d['kullanici'] ?? ''),
        ':ekpar' => empty($ekPar) ? null : json_encode($ekPar),
        ':id'    => $id,
    ];
    if ($sifre) $bind[':sifre'] = $sifre;

    $stmt->execute($bind);
    Auth::logKaydet($GLOBALS['_SESSION']['kullanici']['id'] ?? null, 'entegrasyon_guncelle', 'entegrasyonlar', $id);
    Auth::json(['ok' => true]);

} catch (Throwable $e) {
    error_log('[EntKaydet] ' . $e->getMessage());
    Auth::json(['ok' => false, 'hata' => 'Kayıt sırasında hata oluştu.']);
}
