<?php
ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$islem = $_POST['islem'] ?? '';
$id    = (int)($_POST['id'] ?? 0);
if (!$id && $islem !== 'manuel') { echo json_encode(['ok'=>false,'hata'=>'ID gerekli']); exit; }

try {
    if ($islem === 'sifre_sifirla') {
        $r = $db->prepare("SELECT ad_soyad FROM portal_kullanicilari WHERE id=? LIMIT 1");
        $r->execute([$id]); $r = $r->fetch();
        $sifre = 'Portal'.date('Y').'!';
        $hash  = password_hash($sifre, PASSWORD_DEFAULT);
        $db->prepare("UPDATE portal_kullanicilari SET sifre_hash=?, sifre_degistirildi=0 WHERE id=?")->execute([$hash,$id]);
        echo json_encode(['ok'=>true,'sifre'=>$sifre]);

    } elseif ($islem === 'toggle') {
        $durum = (int)($_POST['durum'] ?? 0);
        $db->prepare("UPDATE portal_kullanicilari SET durum=? WHERE id=?")->execute([$durum,$id]);
        echo json_encode(['ok'=>true]);

    } elseif ($islem === 'sil') {
        $db->prepare("DELETE FROM portal_kullanicilari WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]);
    } else {
        echo json_encode(['ok'=>false,'hata'=>'Geçersiz işlem']);
    }
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
