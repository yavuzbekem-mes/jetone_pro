<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
// ayarlar/ajax/portal-kul-sifre-reset.php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
$d = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id = (int)($d['id'] ?? 0);
if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);
// Geçici şifre oluştur
$gecici = 'J' . strtoupper(substr(uniqid(), -6));
$hash   = password_hash($gecici, PASSWORD_DEFAULT);
$db->prepare("UPDATE portal_kullanicilari SET sifre_hash=? WHERE id=?")->execute([$hash, $id]);
Auth::json(['ok'=>true,'mesaj'=>"Yeni şifre: $gecici (kullanıcıya bildirin)"]);
