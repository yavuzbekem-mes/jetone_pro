<?php
/**
 * Ayarlar — Panel içinde çalışır (kendi HTML yapısı YOK)
 * ayarlar/index.php
 */

// Bağımsız erişim engeli
if (!defined('BASE_URL')) {
    header('Location: ../panel.php?sayfa=ayarlar'); exit;
}
Auth::zorunlu();

$kul       = Auth::kullanici();
$super_adm = ((int)($kul['rol_id'] ?? 0) === 1);

// AYARLAR kaydını çek
$A = [];
try {
    $A = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: [];
} catch (Exception $e) {}

// POST işlemleri
$basari = $hata = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $islem = $_POST['_islem'] ?? '';
    try {
        if ($islem === 'firma') {
            $db->prepare("UPDATE ayarlar SET firma_adi=?,firma_kisa_adi=?,vergi_no=?,vergi_dairesi=?,telefon=?,email=?,web=?,adres=? WHERE id=1")
               ->execute([
                   trim($_POST['firma_adi']      ?? ''),
                   trim($_POST['firma_kisa_adi'] ?? ''),
                   trim($_POST['vergi_no']        ?? ''),
                   trim($_POST['vergi_dairesi']   ?? ''),
                   trim($_POST['telefon']         ?? ''),
                   trim($_POST['email']           ?? ''),
                   trim($_POST['web']             ?? ''),
                   trim($_POST['adres']           ?? ''),
               ]);
            $basari = 'Firma bilgileri güncellendi.';

        } elseif ($islem === 'bolgesel') {
            $db->prepare("UPDATE ayarlar SET para_birimi=?,tarih_formati=?,saat_dilimi=? WHERE id=1")
               ->execute([$_POST['para_birimi']??'TRY',$_POST['tarih_formati']??'d.m.Y',$_POST['saat_dilimi']??'Europe/Istanbul']);
            $basari = 'Bölgesel ayarlar güncellendi.';

        } elseif ($islem === 'mail') {
            $ayarlar_mail = [
                'mail_host'     => trim($_POST['mail_host']     ?? ''),
                'mail_port'     => (int)($_POST['mail_port']    ?? 587),
                'mail_user'     => trim($_POST['mail_user']     ?? ''),
                'mail_sifre'    => trim($_POST['mail_sifre']    ?? ''),
                'mail_gonderen' => trim($_POST['mail_gonderen'] ?? ''),
                'mail_ad'       => trim($_POST['mail_ad']       ?? ''),
                'mail_sifrele'  => $_POST['mail_sifrele']       ?? 'tls',
            ];
            foreach ($ayarlar_mail as $k => $v) {
                try {
                    $db->exec("INSERT INTO ayarlar_kv (anahtar,deger) VALUES ('$k','".addslashes($v)."')
                               ON DUPLICATE KEY UPDATE deger='".addslashes($v)."'");
                } catch (Exception $e) {
                    // ayarlar_kv yoksa ana tabloya ekle
                }
            }
            $basari = 'E-posta ayarları kaydedildi.';

        } elseif ($islem === 'rol_ekle') {
            $ad  = trim($_POST['rol_adi'] ?? '');
            $ack = trim($_POST['rol_aciklama'] ?? '');
            if ($ad) {
                $db->prepare("INSERT INTO roller (ad,aciklama) VALUES (?,?)")->execute([$ad,$ack]);
                $basari = "'$ad' rolü eklendi.";
            }
        } elseif ($islem === 'rol_sil') {
            $rid = (int)$_POST['rol_id'];
            $kulSayisi = $db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE rol_id=?");
            $kulSayisi->execute([$rid]); $n = (int)$kulSayisi->fetchColumn();
            if ($n > 0) { $hata = "Bu role atanmış $n kullanıcı var. Önce rol değiştirin."; }
            else { $db->prepare("DELETE FROM roller WHERE id=?")->execute([$rid]); $basari = 'Rol silindi.'; }
        }
    } catch (Exception $e) {
        $hata = $e->getMessage();
    }
    // Ayarları yeniden çek
    try { $A = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: []; } catch (Exception $e) {}
}

// Verileri çek
try { $roller = $db->query("SELECT r.*, (SELECT COUNT(*) FROM kullanicilar WHERE rol_id=r.id) kul_sayisi FROM roller ORDER BY id")->fetchAll(); } catch (Exception $e) { $roller = []; }
try { $kullanicilar_erp = $db->query("SELECT k.*, r.ad rol_adi FROM kullanicilar k LEFT JOIN roller r ON k.rol_id=r.id ORDER BY k.ad")->fetchAll(); } catch (Exception $e) { $kullanicilar_erp = []; }
try { $portal_kullar = $db->query("SELECT pk.*, CASE pk.tip WHEN 'personel' THEN (SELECT CONCAT(ad,' ',soyad) FROM personeller WHERE id=pk.ilgili_id) WHEN 'musteri' THEN (SELECT ad FROM musteriler WHERE id=pk.ilgili_id) END ilgili_adi FROM portal_kullanicilari ORDER BY tip,kullanici_adi")->fetchAll(); } catch (Exception $e) { $portal_kullar = []; }

// URL'deki sekme
// Aktif sekmeyi belirle — URL'den veya varsayılan
$aktif_sekme = 'firma';
if (!empty($_GET['sekme'])) {
    $izinli = ['firma','bolgesel','mail','roller','kullanici','portal','geofence','enteg'];
    $s = preg_replace('/[^a-z]/', '', strtolower($_GET['sekme']));
    if (in_array($s, $izinli)) $aktif_sekme = $s;
}
?>

<?php if ($basari): ?><div class="uyari-basari" style="background:#D1FADF;border:1px solid #86EFAC;color:#0A8F4E;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">✅ <?php echo htmlspecialchars($basari); ?></div><?php endif; ?>
<?php if ($hata): ?><div class="uyari-hata" style="background:#FEE4E2;border:1px solid #F04438;color:#F04438;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>

<!-- ═══ FİRMA ═══ -->
<div class="ayar-blok" id="blok-firma" style="display:<?php echo $aktif_sekme==='firma'?'block':'none'; ?>">
  <form method="POST">
    <input type="hidden" name="_islem" value="firma">
    <div class="kart" style="margin-bottom:14px">
      <div class="kart-ust"><div class="kart-bas">🏢 Firma Bilgileri</div></div>
      <div class="form-grid-2">
        <?php
        $fb = [
          'firma_adi'      => ['Firma Adı','text',true],
          'firma_kisa_adi' => ['Kısa Ad / Marka','text',false],
          'vergi_no'       => ['Vergi No','text',false],
          'vergi_dairesi'  => ['Vergi Dairesi','text',false],
          'telefon'        => ['Telefon','tel',false],
          'email'          => ['E-posta','email',false],
          'web'            => ['Web Sitesi','url',false],
        ];
        foreach ($fb as $n=>[$et,$tp,$zo]):
        ?>
        <div class="form-grup">
          <label class="form-et"><?php echo $et; ?><?php echo $zo?' <span class="zorunlu">*</span>':''; ?></label>
          <input type="<?php echo $tp; ?>" class="form-alan" name="<?php echo $n; ?>"
                 value="<?php echo htmlspecialchars($A[$n]??''); ?>" <?php echo $zo?'required':''; ?>>
        </div>
        <?php endforeach; ?>
        <div class="form-grup form-span-2">
          <label class="form-et">Adres</label>
          <textarea class="form-alan" name="adres" rows="2"><?php echo htmlspecialchars($A['adres']??''); ?></textarea>
        </div>
      </div>
      <div style="margin-top:12px"><button type="submit" class="btn btn-t">💾 Kaydet</button></div>
    </div>
  </form>
</div>

<!-- ═══ BÖLGESEL ═══ -->
<div class="ayar-blok" id="blok-bolgesel" style="display:none">
  <form method="POST">
    <input type="hidden" name="_islem" value="bolgesel">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🌍 Bölgesel & Format Ayarları</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Para Birimi</label>
          <select class="form-alan" name="para_birimi">
            <?php foreach (['TRY'=>'₺ Türk Lirası','USD'=>'$ Amerikan Doları','EUR'=>'€ Euro','GBP'=>'£ İngiliz Sterlini'] as $v=>$l): ?>
            <option value="<?php echo $v; ?>" <?php echo ($A['para_birimi']??'TRY')===$v?'selected':''; ?>><?php echo $l; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Tarih Formatı</label>
          <select class="form-alan" name="tarih_formati">
            <option value="d.m.Y" <?php echo ($A['tarih_formati']??'')==='d.m.Y'?'selected':''; ?>>GG.AA.YYYY — <?php echo date('d.m.Y'); ?></option>
            <option value="Y-m-d" <?php echo ($A['tarih_formati']??'')==='Y-m-d'?'selected':''; ?>>YYYY-AA-GG — <?php echo date('Y-m-d'); ?></option>
            <option value="d/m/Y" <?php echo ($A['tarih_formati']??'')==='d/m/Y'?'selected':''; ?>>GG/AA/YYYY — <?php echo date('d/m/Y'); ?></option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Saat Dilimi</label>
          <select class="form-alan" name="saat_dilimi">
            <option value="Europe/Istanbul" <?php echo ($A['saat_dilimi']??'')==='Europe/Istanbul'?'selected':''; ?>>Europe/Istanbul (UTC+3)</option>
            <option value="UTC">UTC (GMT+0)</option>
            <option value="Europe/London">Europe/London</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Dil</label>
          <select class="form-alan" name="dil">
            <option value="tr" <?php echo ($A['dil']??'tr')==='tr'?'selected':''; ?>>🇹🇷 Türkçe</option>
            <option value="en" <?php echo ($A['dil']??'')==='en'?'selected':''; ?>>🇬🇧 English</option>
          </select>
        </div>
      </div>
      <div style="margin-top:12px"><button type="submit" class="btn btn-t">💾 Kaydet</button></div>
    </div>
  </form>
</div>

<!-- ═══ E-POSTA ═══ -->
<div class="ayar-blok" id="blok-mail" style="display:none">
  <?php
  $mailAyar = [];
  try {
    $rows = $db->query("SELECT anahtar,deger FROM ayarlar_kv WHERE anahtar LIKE 'mail_%'")->fetchAll();
    foreach ($rows as $r) $mailAyar[$r['anahtar']] = $r['deger'];
  } catch (Exception $e) {}
  ?>
  <form method="POST">
    <input type="hidden" name="_islem" value="mail">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📧 SMTP E-posta Ayarları</div></div>
      <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r);padding:12px 14px;margin-bottom:14px;font-size:13px;color:#1D4ED8">
        ℹ️ Şifre sıfırlama, bildirim ve portal e-postaları için SMTP ayarlarını girin.
      </div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">SMTP Sunucu</label>
          <input type="text" class="form-alan" name="mail_host" value="<?php echo htmlspecialchars($mailAyar['mail_host']??''); ?>" placeholder="smtp.gmail.com">
        </div>
        <div class="form-grup">
          <label class="form-et">SMTP Port</label>
          <input type="number" class="form-alan" name="mail_port" value="<?php echo $mailAyar['mail_port']??587; ?>" placeholder="587">
        </div>
        <div class="form-grup">
          <label class="form-et">Kullanıcı Adı / E-posta</label>
          <input type="text" class="form-alan" name="mail_user" value="<?php echo htmlspecialchars($mailAyar['mail_user']??''); ?>" placeholder="gonderici@firma.com">
        </div>
        <div class="form-grup">
          <label class="form-et">Şifre / Uygulama Şifresi</label>
          <input type="password" class="form-alan" name="mail_sifre" value="<?php echo htmlspecialchars($mailAyar['mail_sifre']??''); ?>" placeholder="••••••••">
        </div>
        <div class="form-grup">
          <label class="form-et">Gönderen E-posta</label>
          <input type="email" class="form-alan" name="mail_gonderen" value="<?php echo htmlspecialchars($mailAyar['mail_gonderen']??''); ?>" placeholder="noreply@firma.com">
        </div>
        <div class="form-grup">
          <label class="form-et">Gönderen Adı</label>
          <input type="text" class="form-alan" name="mail_ad" value="<?php echo htmlspecialchars($mailAyar['mail_ad']??''); ?>" placeholder="Jetone.Pro ERP">
        </div>
        <div class="form-grup">
          <label class="form-et">Şifreleme</label>
          <select class="form-alan" name="mail_sifrele">
            <option value="tls" <?php echo ($mailAyar['mail_sifrele']??'tls')==='tls'?'selected':''; ?>>TLS (önerilen)</option>
            <option value="ssl" <?php echo ($mailAyar['mail_sifrele']??'')==='ssl'?'selected':''; ?>>SSL</option>
            <option value="" <?php echo ($mailAyar['mail_sifrele']??'')===''?'selected':''; ?>>Yok</option>
          </select>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <button type="submit" class="btn btn-t">💾 Kaydet</button>
        <button type="button" class="btn btn-b" onclick="mailTest()">📤 Test E-postası Gönder</button>
      </div>
    </div>
  </form>
</div>

<!-- ═══ ROLLER ═══ -->
<div class="ayar-blok" id="blok-roller" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 340px;gap:14px">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🎭 Roller</div></div>
      <?php if (empty($roller)): ?>
      <div style="padding:24px;text-align:center;color:var(--m2)">Rol bulunamadı</div>
      <?php else: ?>
      <table class="tablo">
        <thead><tr><th>Rol Adı</th><th>Açıklama</th><th>Kullanıcı</th><th>İşlem</th></tr></thead>
        <tbody>
        <?php foreach ($roller as $r): ?>
        <tr>
          <td><b><?php echo htmlspecialchars($r['ad']); ?></b></td>
          <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($r['aciklama']??'—'); ?></td>
          <td><span class="roz"><?php echo $r['kul_sayisi']; ?> kullanıcı</span></td>
          <td>
            <?php if ($r['kul_sayisi'] == 0 && $super_adm): ?>
            <form method="POST" style="display:inline" onsubmit="return confirm('Rol silinsin mi?')">
              <input type="hidden" name="_islem" value="rol_sil">
              <input type="hidden" name="rol_id" value="<?php echo $r['id']; ?>">
              <button type="submit" class="btn btn-sm" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer">🗑</button>
            </form>
            <?php else: ?>
            <span style="font-size:11px;color:var(--m3)">Sistem rolü</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>

    <?php if ($super_adm): ?>
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">➕ Yeni Rol Ekle</div></div>
      <form method="POST">
        <input type="hidden" name="_islem" value="rol_ekle">
        <div class="form-grup">
          <label class="form-et">Rol Adı <span class="zorunlu">*</span></label>
          <input type="text" class="form-alan" name="rol_adi" placeholder="Örn: Muhasebe" required>
        </div>
        <div class="form-grup">
          <label class="form-et">Açıklama</label>
          <textarea class="form-alan" name="rol_aciklama" rows="2" placeholder="Bu rolün yetki kapsamı..."></textarea>
        </div>
        <button type="submit" class="btn btn-t" style="width:100%">➕ Rol Ekle</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- ═══ ERP KULLANICILARI ═══ -->
<div class="ayar-blok" id="blok-kullanici" style="display:none">
  <div class="kart">
    <div class="kart-ust">
      <div class="kart-bas">👤 ERP Kullanıcıları (<?php echo count($kullanicilar_erp); ?>)</div>
      <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ayarlar-yeni-kullanici" class="btn btn-t btn-sm">+ Yeni Kullanıcı</a>
    </div>
    <?php if (empty($kullanicilar_erp)): ?>
    <div style="padding:24px;text-align:center;color:var(--m2)">Kullanıcı bulunamadı</div>
    <?php else: ?>
    <table class="tablo">
      <thead><tr><th>Ad Soyad</th><th>E-posta</th><th>Rol</th><th>Durum</th><th>Son Giriş</th><th>İşlem</th></tr></thead>
      <tbody>
      <?php foreach ($kullanicilar_erp as $u): ?>
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="width:30px;height:30px;border-radius:50%;background:var(--t-a);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:var(--t);flex-shrink:0">
              <?php echo mb_strtoupper(mb_substr($u['ad'],0,1).mb_substr($u['soyad']??'',0,1)); ?>
            </div>
            <div>
              <div style="font-weight:700"><?php echo htmlspecialchars($u['ad'].' '.($u['soyad']??'')); ?></div>
              <?php if (($u['sifre_degistirildi']??1)==0): ?>
              <span style="font-size:10px;background:#FEF0C7;color:#B45309;padding:1px 5px;border-radius:8px">İlk Şifre</span>
              <?php endif; ?>
            </div>
          </div>
        </td>
        <td style="font-size:12px"><?php echo htmlspecialchars($u['email']); ?></td>
        <td><span class="roz" style="background:var(--t-a);color:var(--t)"><?php echo htmlspecialchars($u['rol_adi']??'—'); ?></span></td>
        <td><span class="roz" style="background:<?php echo $u['durum']?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo $u['durum']?'#0A8F4E':'#F04438'; ?>"><?php echo $u['durum']?'✓ Aktif':'✗ Pasif'; ?></span></td>
        <td style="font-size:11px;color:var(--m2)"><?php echo $u['son_giris'] ? date('d.m.Y H:i',strtotime($u['son_giris'])) : '—'; ?></td>
        <td>
          <div style="display:flex;gap:4px">
            <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=kullanici-profil&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-b" title="Profil">👤</a>
            <?php if ($super_adm): ?>
            <button class="btn btn-sm btn-b" onclick="erpKulSifreReset(<?php echo $u['id']; ?>,'<?php echo htmlspecialchars($u['email']); ?>')" title="Şifre Sıfırla">🔑</button>
            <button class="btn btn-sm btn-b" onclick="erpKulToggle(<?php echo $u['id']; ?>,<?php echo $u['durum']; ?>)" title="<?php echo $u['durum']?'Kapat':'Aç'; ?>"><?php echo $u['durum']?'🔒':'🔓'; ?></button>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- ═══ PORTAL KULLANICILARI ═══ -->
<div class="ayar-blok" id="blok-portal" style="display:none">
  <div class="kart">
    <div class="kart-ust">
      <div class="kart-bas">🌐 Portal Kullanıcıları (<?php echo count($portal_kullar); ?>)</div>
      <div style="display:flex;gap:6px">
        <input type="text" id="portalArama" class="form-alan" style="width:200px" placeholder="Ara..." oninput="portalFiltrele()">
        <select id="portalTipFilter" class="form-alan" style="width:130px" onchange="portalFiltrele()">
          <option value="">Tümü</option>
          <option value="personel">Personel</option>
          <option value="musteri">Müşteri</option>
        </select>
      </div>
    </div>
    <?php if (empty($portal_kullar)): ?>
    <div style="padding:24px;text-align:center;color:var(--m2)">Portal kullanıcısı bulunamadı</div>
    <?php else: ?>
    <table class="tablo" id="portalTable">
      <thead><tr><th>Kullanıcı Adı</th><th>Ad</th><th>Tip</th><th>Durum</th><th>Şifre</th><th>Son Giriş</th><th>İşlem</th></tr></thead>
      <tbody>
      <?php foreach ($portal_kullar as $pk): ?>
      <tr data-tip="<?php echo $pk['tip']; ?>">
        <td><code style="font-size:13px;background:var(--bg);padding:2px 6px;border-radius:4px;font-weight:700;color:var(--t)"><?php echo htmlspecialchars($pk['kullanici_adi']); ?></code></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($pk['ilgili_adi']??($pk['ad_soyad']??'—')); ?></td>
        <td><span class="roz" style="background:<?php echo $pk['tip']==='personel'?'#FEF3E8':'#E0F2FE'; ?>;color:<?php echo $pk['tip']==='personel'?'#B45309':'#0284C7'; ?>"><?php echo $pk['tip']==='personel'?'🧑‍💼 Personel':'🏢 Müşteri'; ?></span></td>
        <td><span class="roz" style="background:<?php echo $pk['durum']?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo $pk['durum']?'#0A8F4E':'#F04438'; ?>"><?php echo $pk['durum']?'✓ Aktif':'✗ Pasif'; ?></span></td>
        <td><span class="roz" style="background:<?php echo ($pk['sifre_degistirildi']??0)?'#D1FADF':'#FEF0C7'; ?>;color:<?php echo ($pk['sifre_degistirildi']??0)?'#0A8F4E':'#B45309'; ?>"><?php echo ($pk['sifre_degistirildi']??0)?'✓ Değiştirildi':'⚠ İlk Şifre'; ?></span></td>
        <td style="font-size:11px;color:var(--m2)"><?php echo $pk['son_giris'] ? date('d.m.Y H:i',strtotime($pk['son_giris'])) : 'Henüz girmedi'; ?></td>
        <td>
          <div style="display:flex;gap:4px">
            <button class="btn btn-sm btn-b" onclick="portalSifreReset(<?php echo $pk['id']; ?>,'<?php echo $pk['tip']; ?>')" title="Şifre Sıfırla">🔑</button>
            <button class="btn btn-sm btn-b" onclick="portalToggle(<?php echo $pk['id']; ?>,<?php echo $pk['durum']; ?>,'<?php echo $pk['tip']; ?>')" title="<?php echo $pk['durum']?'Erişimi Kapat':'Erişimi Aç'; ?>"><?php echo $pk['durum']?'🔒':'🔓'; ?></button>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- ═══ GEOFENCE ═══ -->
<div class="ayar-blok" id="blok-geofence" style="display:none">
  <?php include __DIR__ . '/bilesen/geofence-ayar.php'; ?>
</div>

<!-- ═══ ENTEGRASYONLAR ═══ -->
<div class="ayar-blok" id="blok-enteg" style="display:none">
  <?php
  $entegDosya = __DIR__ . '/bilesen/entegrasyonlar.php';
  if (file_exists($entegDosya)) include $entegDosya;
  else echo '<div class="kart"><div style="padding:24px;text-align:center;color:var(--m2)">🔌 Entegrasyon ayarları yakında</div></div>';
  ?>
</div>

<script>
function ayarSekme(id, el) {
  document.querySelectorAll('.ayar-blok').forEach(function(b){ b.style.display='none'; });
  document.querySelectorAll('.ayar-sekme-btn').forEach(function(b){
    b.style.background='none'; b.style.color='var(--m2)';
  });
  document.getElementById('blok-'+id).style.display='block';
  el.style.background='var(--t)'; el.style.color='#fff';

  // Sol sidebar'daki aktif öğeyi güncelle
  document.querySelectorAll('.nav-it').forEach(function(n){ n.classList.remove('aktif'); });
  var navId = 'ayarlar__'+id;
  var navEl = document.querySelector('.nav-it[onclick*="'+navId+'"]');
  if (navEl) navEl.classList.add('aktif');

  // Tarayıcı URL'ini güncelle (sayfayı yenilemeden)
  if (window.history && window.history.replaceState) {
    var url = new URL(window.location.href);
    url.searchParams.set('sekme', id);
    window.history.replaceState(null, '', url.toString());
  }
}

// Portal arama
function portalFiltrele() {
  var q   = document.getElementById('portalArama').value.toLowerCase();
  var tip = document.getElementById('portalTipFilter').value;
  document.querySelectorAll('#portalTable tbody tr').forEach(function(tr){
    var txt = tr.textContent.toLowerCase();
    var t   = tr.dataset.tip;
    tr.style.display = (!q || txt.includes(q)) && (!tip || t===tip) ? '' : 'none';
  });
}

// ERP kullanıcı şifre sıfırla
function erpKulSifreReset(id, email) {
  if (!confirm(email + ' kullanıcısının şifresi sıfırlansın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php', {islem:'sifre_sifirla',erp_kul_id:id})
    .then(function(r){
      if (r.ok) alert('✅ Yeni şifre: ' + r.yeni_sifre + '\n\nE-posta: ' + r.email);
      else JT.bildirim(r.hata,'hata');
    });
}
function erpKulToggle(id, mevcut) {
  if (!confirm(mevcut?'Hesap kapatılsın mı?':'Hesap açılsın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php', {islem:'toggle_erisim',erp_kul_id:id})
    .then(function(r){
      if (r.ok) { JT.bildirim(r.mesaj,'basari'); setTimeout(function(){ location.reload(); },800); }
      else JT.bildirim(r.hata,'hata');
    });
}

// Portal şifre sıfırla
function portalSifreReset(id, tip) {
  if (!confirm('Portal şifresi sıfırlansın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-portal-islem.php', {id:id, islem:'sifre_sifirla'})
    .then(function(r){
      if (r.ok) alert('✅ Yeni şifre: ' + r.yeni_sifre);
      else JT.bildirim(r.hata,'hata');
    });
}
function portalToggle(id, mevcut, tip) {
  if (!confirm(mevcut?'Erişim kapatılsın mı?':'Erişim açılsın mı?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-portal-islem.php', {id:id, islem:'toggle_erisim'})
    .then(function(r){
      if (r.ok) { JT.bildirim(r.mesaj,'basari'); setTimeout(function(){ location.reload(); },800); }
      else JT.bildirim(r.hata,'hata');
    });
}

// Mail test
function mailTest() {
  var email = prompt('Test e-postası gönderilecek adres:');
  if (!email) return;
  JT.ajax('<?php echo BASE_URL; ?>/ayarlar/ajax/mail-test.php', {email:email})
    .then(function(r){
      if (r.ok) JT.bildirim('Test e-postası gönderildi!','basari');
      else JT.bildirim(r.hata||'Gönderim başarısız','hata');
    });
}
</script>
