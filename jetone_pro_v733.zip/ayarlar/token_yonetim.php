<?php
/**
 * Logo REST API Token Yönetimi
 * panel.php: 'uretim-token-yonetim' => 'bolumler/uretim/token_yonetim.php'
 */
// panel.php zaten config/db/baglanlogo/auth yüklüyor
// Direkt çağrı için de güvenli yükleme
if (!defined('ROOT_DIR')) {
    require_once dirname(__DIR__) . '/core/config.php';
}
if (!class_exists('Auth')) {
    require_once ROOT_DIR . '/core/auth.php';
}
if (!isset($mes_pdo)) {
    require_once ROOT_DIR . '/core/baglanlogo.php';
}
Auth::zorunlu();

// ─── Tokenleri listele ────────────────────────────────────────────────────────
$tokenler = [];
$hata     = '';
if (!$mes_pdo) {
    $hata = 'MES veritabanı bağlantısı kurulamadı.';
} else {
    try {
        $st = $mes_pdo->query("SELECT TOP 50 ID, TOKEN, TARIH FROM dbo.REST_SERVIS_KAYITLAR ORDER BY ID DESC");
        $tokenler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
        $hata = $e->getMessage();
    }
}

// Bugün geçerli token var mı?
$gecerli_token = null;
foreach ($tokenler as $tk) {
    $tarih_str = substr($tk['TARIH'] ?? '', 0, 10);
    if ($tarih_str === date('Y-m-d')) { $gecerli_token = $tk; break; }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔑 Logo REST API Token Yönetimi</h1>
    <div class="s-yol">Ayarlar / <b>Logo API Token Yönetimi</b></div>
  </div>
  <button id="btnYeniToken" class="btn btn-t" onclick="yeniToken()">
    ＋ Yeni Token Al
  </button>
</div>

<div class="s-body">

<?php if($hata): ?>
<div style="padding:12px;margin-bottom:14px;background:#FEF2F2;color:#7F1D1D;border:1px solid #FECACA;border-radius:var(--r-lg);font-size:13px">
  ⚠️ <?=htmlspecialchars($hata)?>
</div>
<?php endif; ?>

<!-- Durum Kartı -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:20px" class="ozet-grid">
  <div class="kart" style="border-left:4px solid <?=$gecerli_token?'#16A34A':'#DC2626'?>">
    <div style="font-size:11px;color:var(--m3);font-weight:700;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px">Bugünkü Token</div>
    <div style="font-size:15px;font-weight:800;color:<?=$gecerli_token?'#16A34A':'#DC2626'?>">
      <?=$gecerli_token ? '✅ Aktif' : '❌ Yok'?>
    </div>
    <?php if($gecerli_token): ?>
    <div style="font-size:11px;color:var(--m3);margin-top:4px"><?=htmlspecialchars(substr($gecerli_token['TARIH']??'',0,16))?></div>
    <?php endif; ?>
  </div>
  <div class="kart" style="border-left:4px solid var(--t)">
    <div style="font-size:11px;color:var(--m3);font-weight:700;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px">Toplam Kayıt</div>
    <div style="font-size:22px;font-weight:900;color:var(--t)"><?=count($tokenler)?></div>
  </div>
  <div class="kart" style="border-left:4px solid #6B7280">
    <div style="font-size:11px;color:var(--m3);font-weight:700;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px">API URL</div>
    <div style="font-size:11px;font-family:monospace;color:var(--m2);word-break:break-all"><?=htmlspecialchars(defined("Global_Rest") || class_exists("Global_Rest") ? Global_Rest::$g_URL : "http://192.168.1.100:32001/api/v1/")?></div>
  </div>
</div>

<!-- AJAX Mesaj -->
<div id="ajax-mesaj" style="display:none;padding:12px 16px;border-radius:var(--r);font-size:13px;font-weight:600;margin-bottom:14px"></div>

<!-- Token Listesi -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <span style="font-weight:800;font-size:13px">🗂️ Token Geçmişi (Son 50)</span>
    <span style="font-size:11px;color:var(--m3)">Token ilk/son 20 karakter gösterilir</span>
  </div>
  <?php if(empty($tokenler) && !$hata): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Token kaydı bulunamadı.</div>
  <?php else: ?>
  <div style="overflow:auto;max-height:600px">
  <table style="width:100%;border-collapse:collapse;font-size:12.5px">
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:var(--kenar-a);border-bottom:2px solid var(--kenar)">
        <th style="padding:10px 14px;text-align:left;font-weight:700;color:var(--m2);white-space:nowrap">#</th>
        <th style="padding:10px 14px;text-align:left;font-weight:700;color:var(--m2)">Token (Kısaltılmış)</th>
        <th style="padding:10px 14px;text-align:left;font-weight:700;color:var(--m2);white-space:nowrap">Tarih</th>
        <th style="padding:10px 14px;text-align:center;font-weight:700;color:var(--m2);white-space:nowrap">Durum</th>
        <th style="padding:10px 14px;text-align:center;font-weight:700;color:var(--m2);white-space:nowrap;min-width:180px">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($tokenler as $i=>$t):
      $tarih_str = substr($t['TARIH']??'',0,10);
      $bugun = ($tarih_str === date('Y-m-d'));
      $token_goster = strlen($t['TOKEN']??'') > 40
        ? substr($t['TOKEN'],0,20) . '...' . substr($t['TOKEN'],-20)
        : ($t['TOKEN']??'');
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bugun?'#F0FDF4':'var(--yuzey)'?>">
      <td style="padding:10px 14px;color:var(--m3);font-weight:700"><?=$i+1?></td>
      <td style="padding:10px 14px">
        <div style="display:flex;align-items:center;gap:8px">
          <code style="font-size:11.5px;background:var(--bg);padding:3px 8px;border-radius:6px;color:var(--m2);font-family:monospace;border:1px solid var(--kenar)">
            <?=htmlspecialchars($token_goster)?>
          </code>
          <button onclick="kopyala('<?=htmlspecialchars($t['TOKEN']??'')?>', this)"
                  style="border:none;background:none;cursor:pointer;color:var(--m3);font-size:13px;padding:2px 4px;border-radius:4px;transition:all .15s"
                  title="Kopyala">📋</button>
        </div>
      </td>
      <td style="padding:10px 14px;color:var(--m2);white-space:nowrap;font-size:12px">
        <?=htmlspecialchars(substr($t['TARIH']??'',0,16))?>
        <?php if($bugun): ?>
        <span style="margin-left:6px;font-size:9px;font-weight:700;padding:1px 6px;border-radius:10px;background:#D1FAE5;color:#065F46">BUGÜN</span>
        <?php endif; ?>
      </td>
      <td style="padding:10px 14px;text-align:center">
        <?php if($bugun): ?>
        <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#D1FAE5;color:#065F46">✅ Aktif</span>
        <?php else: ?>
        <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:var(--kenar-a);color:var(--m3)">Süresi Geçmiş</span>
        <?php endif; ?>
      </td>
      <td style="padding:10px 14px;text-align:center">
        <div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap">
          <button onclick="tokenTest('<?=htmlspecialchars($t['TOKEN']??'')?>', <?=(int)$t['ID']?>)"
                  class="btn btn-b btn-sm" id="test-btn-<?=(int)$t['ID']?>">
            🔍 Test Et
          </button>
          <button onclick="tokenSil(<?=(int)$t['ID']?>, this)"
                  class="btn btn-sm" style="background:#FEE2E2;color:#7F1D1D;border:1px solid #FECACA"
                  id="sil-btn-<?=(int)$t['ID']?>">
            🗑 Sil
          </button>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

</div><!-- /s-body -->

<style>
@media(max-width:600px){.ozet-grid{grid-template-columns:1fr!important}}
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function mesajGoster(txt, tip) {
    var el = document.getElementById('ajax-mesaj');
    if (!el) return;
    el.textContent = txt;
    el.style.display = 'block';
    el.style.background = tip === 'ok' ? '#D1FAE5' : '#FEF2F2';
    el.style.color       = tip === 'ok' ? '#065F46' : '#7F1D1D';
    el.style.border      = '1px solid ' + (tip === 'ok' ? '#A7F3D0' : '#FECACA');
    clearTimeout(el._t);
    el._t = setTimeout(function() { el.style.display = 'none'; }, 5000);
}

function yeniToken() {
    Swal.fire({
        title: 'Yeni Token Aliniyor...',
        text: 'Logo REST API baglantisi kuruluyor, lutfen bekleyin.',
        icon: 'info',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        didOpen: function() { Swal.showLoading(); }
    });

    var fd = new FormData();
    fd.append('aksiyon', 'yeni_token');

    fetch(BASE_URL + '/ayarlar/ajax/token_ajax.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.basari) {
                Swal.fire({
                    title: 'Token Alindi!',
                    text: 'Yeni token basariyla alindi ve kaydedildi.',
                    icon: 'success',
                    confirmButtonColor: '#16A34A',
                    confirmButtonText: 'Tamam'
                }).then(function() { location.reload(); });
            } else {
                Swal.fire({
                    title: 'Token Alinamadi!',
                    text: d.mesaj || 'Bilinmeyen hata.',
                    icon: 'error',
                    confirmButtonColor: '#DC2626'
                });
            }
        })
        .catch(function(e) {
            Swal.fire({
                title: 'Baglanti Hatasi',
                text: e.message,
                icon: 'error',
                confirmButtonColor: '#DC2626'
            });
        });
}

function tokenTest(token, id) {
    var btn = document.getElementById('test-btn-' + id);
    if (btn) { btn.disabled = true; btn.textContent = '...'; }

    Swal.fire({
        title: 'Token Test Ediliyor...',
        text: 'API baglantisi kontrol ediliyor.',
        icon: 'info',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        didOpen: function() { Swal.showLoading(); }
    });

    var fd = new FormData();
    fd.append('aksiyon', 'token_test');
    fd.append('token', token);

    fetch(BASE_URL + '/ayarlar/ajax/token_ajax.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            Swal.fire({
                title: d.basari ? 'Token Gecerli!' : 'Token Gecersiz!',
                text: d.mesaj,
                icon: d.basari ? 'success' : 'error',
                confirmButtonColor: d.basari ? '#16A34A' : '#DC2626',
                timer: 3000,
                timerProgressBar: true
            });
            if (btn) {
                btn.textContent = d.basari ? 'Gecerli' : 'Gecersiz';
                btn.style.color = d.basari ? '#16A34A' : '#DC2626';
                setTimeout(function() {
                    btn.textContent = 'Test Et';
                    btn.style.color = '';
                    btn.disabled = false;
                }, 3500);
            }
        })
        .catch(function(e) {
            Swal.fire({ title: 'Hata', text: e.message, icon: 'error', confirmButtonColor: '#DC2626' });
            if (btn) { btn.disabled = false; btn.textContent = 'Test Et'; }
        });
}

function tokenSil(id, buton) {
    Swal.fire({
        title: 'Token Silinsin mi?',
        text: 'Bu token kalici olarak silinecek.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#DC2626',
        cancelButtonColor: '#6B7280',
        confirmButtonText: 'Evet, Sil',
        cancelButtonText: 'Iptal'
    }).then(function(r) {
        if (!r.isConfirmed) return;

        buton.disabled = true;
        buton.textContent = '...';

        var fd = new FormData();
        fd.append('aksiyon', 'token_sil');
        fd.append('id', id);

        fetch(BASE_URL + '/ayarlar/ajax/token_ajax.php', { method: 'POST', body: fd })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.basari) {
                    Swal.fire({
                        title: 'Silindi!',
                        text: 'Token basariyla silindi.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    var satir = buton.closest('tr');
                    if (satir) {
                        satir.style.opacity = '0.3';
                        setTimeout(function() { satir.remove(); }, 600);
                    }
                } else {
                    Swal.fire({ title: 'Hata!', text: d.mesaj, icon: 'error', confirmButtonColor: '#DC2626' });
                    buton.disabled = false;
                    buton.textContent = 'Sil';
                }
            })
            .catch(function(e) {
                Swal.fire({ title: 'Hata', text: e.message, icon: 'error', confirmButtonColor: '#DC2626' });
                buton.disabled = false;
                buton.textContent = 'Sil';
            });
    });
}

function kopyala(metin, buton) {
    navigator.clipboard.writeText(metin).then(function() {
        var eski = buton.textContent;
        buton.textContent = 'Kopyalandi';
        setTimeout(function() { buton.textContent = eski; }, 1500);
    }).catch(function() {
        mesajGoster('Kopyalama basarisiz', 'hata');
    });
}
</script>
