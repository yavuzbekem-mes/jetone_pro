<?php include __DIR__ . '/_base.php';
$dosya = __DIR__ . '/bilesen/entegrasyonlar.php';
if (file_exists($dosya)) include $dosya;
else echo '<div class="kart"><div style="padding:24px;text-align:center;color:var(--m2)">Entegrasyon bileşeni bulunamadı.</div></div>';
