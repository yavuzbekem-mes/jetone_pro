<?php
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';
$mevcut = array_column($db->query("SHOW COLUMNS FROM mps_plan")->fetchAll(PDO::FETCH_ASSOC),'Field');
if (!in_array('personel_sayisi',$mevcut)) {
    $db->exec("ALTER TABLE mps_plan ADD COLUMN personel_sayisi INT DEFAULT 1");
    echo "personel_sayisi eklendi\n";
} else echo "zaten var\n";
