<?php
/**
 * JETONE.PRO — Şifre Hash Üretici
 * hash_uret.php
 *
 * Bu dosyayı tarayıcıdan açın:
 * http://localhost:4459/jetone_pro/hash_uret.php
 *
 * Çalışan ALTER TABLE SQL'ini üretir.
 * Kullandıktan sonra bu dosyayı SİLİN!
 */

// Güvenlik: sadece localhost'tan erişim
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ip, ['127.0.0.1','::1','localhost'])) {
    http_response_code(403);
    die('Sadece localhost\'tan erişilebilir.');
}

// Şifreler
$sifreler = [
    'admin_erp'      => ['email' => 'admin@jetone.pro',           'sifre' => 'Admin123!'],
    'ayse_erp'       => ['email' => 'ayse.yilmaz@jetone.pro',     'sifre' => 'Jetone2024!'],
    'mehmet_erp'     => ['email' => 'mehmet.kaya@jetone.pro',     'sifre' => 'Jetone2024!'],
    'fatma_erp'      => ['email' => 'fatma.sahin@jetone.pro',     'sifre' => 'Jetone2024!'],
    'ali_erp'        => ['email' => 'ali.demir@jetone.pro',       'sifre' => 'Jetone2024!'],
    'zeynep_erp'     => ['email' => 'zeynep.arslan@jetone.pro',   'sifre' => 'Jetone2024!'],
    'per_portal'     => ['sicil' => 'P-00001 ~ P-00015',          'sifre' => 'Personel2024!'],
    'mus_portal'     => ['kod'   => 'ABC-001 ~ TRK-004',          'sifre' => 'Musteri2024!'],
];

// Hash'leri üret
$hashler = [];
foreach ($sifreler as $key => $v) {
    $hashler[$key] = [
        'info'  => $v,
        'hash'  => password_hash($v['sifre'], PASSWORD_BCRYPT, ['cost' => 10]),
        'sifre' => $v['sifre'],
    ];
    // Doğrula
    $hashler[$key]['dogrulama'] = password_verify($v['sifre'], $hashler[$key]['hash']) ? '✅ OK' : '❌ HATA';
}

$per_hash = $hashler['per_portal']['hash'];
$mus_hash = $hashler['mus_portal']['hash'];

?><!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Hash Üretici</title>
<style>
body{font-family:monospace;background:#0D1117;color:#C9D1D9;padding:24px;line-height:1.7}
h1{color:#F97316;font-size:18px;margin-bottom:16px}
h2{color:#58A6FF;font-size:14px;margin:20px 0 8px}
.ok{color:#3FB950}
.hata{color:#F85149}
.sql{background:#161B22;border:1px solid #30363D;border-radius:8px;padding:16px;white-space:pre-wrap;word-break:break-all;font-size:12px;color:#A5D6FF;margin-bottom:16px}
.btn{background:#F97316;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-family:monospace;font-size:13px;margin-bottom:8px}
.btn:hover{background:#EA6800}
table{border-collapse:collapse;width:100%;font-size:12px;margin-bottom:16px}
td,th{padding:6px 12px;border:1px solid #30363D;text-align:left}
th{background:#161B22;color:#8B949E}
.uyari{background:#3D1A00;border:1px solid #F97316;border-radius:8px;padding:12px;color:#F97316;margin-bottom:16px;font-size:13px}
</style>
</head>
<body>
<h1>🔑 Jetone.pro — PHP Şifre Hash Üretici</h1>
<div class="uyari">⚠️ Bu dosyayı kullandıktan sonra MUTLAKA silin: <code>jetone_pro/hash_uret.php</code></div>

<h2>Üretilen Hash'ler (PHP <?php echo PHP_VERSION; ?> — Doğrulanmış)</h2>
<table>
<tr><th>Kullanıcı</th><th>Şifre</th><th>Hash</th><th>Doğrulama</th></tr>
<?php foreach ($hashler as $k => $v): ?>
<tr>
  <td><?php echo $k; ?></td>
  <td><b><?php echo $v['sifre']; ?></b></td>
  <td style="font-size:10px;word-break:break-all"><?php echo $v['hash']; ?></td>
  <td class="<?php echo strpos($v['dogrulama'],'OK') !== false ? 'ok' : 'hata'; ?>"><?php echo $v['dogrulama']; ?></td>
</tr>
<?php endforeach; ?>
</table>

<h2>📋 Kopyalayıp phpMyAdmin'de Çalıştırın</h2>
<button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('sql').innerText).then(()=>alert('Kopyalandı!'))">📋 SQL'i Kopyala</button>

<div class="sql" id="sql">-- ============================================================
-- JETONE.PRO — Şifre Güncelleme (PHP <?php echo PHP_VERSION; ?> ile üretildi)
-- Tarih: <?php echo date('Y-m-d H:i:s'); ?>

-- phpMyAdmin > SQL sekmesine yapıştırıp çalıştırın
-- ============================================================

USE `jetone_pro`;

-- ─── 1. ERP Kullanıcı Tablosunu Güncelle ───────────────────

-- Admin varsa güncelle, yoksa ekle
INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`rol_id`,`durum`)
VALUES ('Süper','Admin','admin@jetone.pro','<?php echo $hashler['admin_erp']['hash']; ?>',1,1)
ON DUPLICATE KEY UPDATE
  `sifre_hash` = '<?php echo $hashler['admin_erp']['hash']; ?>',
  `rol_id` = 1,
  `durum` = 1;

INSERT INTO `kullanicilar` (`ad`,`soyad`,`email`,`sifre_hash`,`rol_id`,`departman_id`,`pozisyon`,`durum`)
VALUES
('Ayşe','Yılmaz','ayse.yilmaz@jetone.pro','<?php echo $hashler['ayse_erp']['hash']; ?>',1,1,'Sistem Yöneticisi',1),
('Mehmet','Kaya','mehmet.kaya@jetone.pro','<?php echo $hashler['mehmet_erp']['hash']; ?>',2,2,'İK Müdürü',1),
('Fatma','Şahin','fatma.sahin@jetone.pro','<?php echo $hashler['fatma_erp']['hash']; ?>',3,5,'Üretim Şefi',1),
('Ali','Demir','ali.demir@jetone.pro','<?php echo $hashler['ali_erp']['hash']; ?>',4,8,'Satınalma Uzmanı',1),
('Zeynep','Arslan','zeynep.arslan@jetone.pro','<?php echo $hashler['zeynep_erp']['hash']; ?>',5,4,'Satış Temsilcisi',1)
ON DUPLICATE KEY UPDATE
  `sifre_hash` = VALUES(`sifre_hash`),
  `durum` = 1;

-- ─── 2. Personeller ────────────────────────────────────────

INSERT INTO `personeller`
  (`sicil_no`,`ad`,`soyad`,`tc_kimlik`,`dogum_tarihi`,`cinsiyet`,`departman_id`,`pozisyon`,`telefon`,`email`,`ise_baslama`,`calısma_tipi`,`durum`,`maas`)
VALUES
('P-00001','Ahmet','Kaya','12345678901','1988-05-12',1,5,'Üretim Operatörü','0532 111 0001','ahmet.kaya@firma.com','2019-03-01','tam_zamanli','aktif',18500.00),
('P-00002','Mustafa','Çelik','12345678902','1990-07-22',1,5,'CNC Operatörü','0532 111 0002','mustafa.celik@firma.com','2020-06-15','tam_zamanli','aktif',20000.00),
('P-00003','Hasan','Yıldız','12345678903','1985-11-03',1,5,'Vardiya Şefi','0532 111 0003','hasan.yildiz@firma.com','2017-01-10','tam_zamanli','aktif',28000.00),
('P-00004','İbrahim','Öztürk','12345678904','1992-03-18',1,5,'Bakım Teknisyeni','0532 111 0004','ibrahim.ozturk@firma.com','2021-09-01','tam_zamanli','aktif',22000.00),
('P-00005','Emre','Yılmaz','12345678905','1995-08-25',1,5,'Üretim Operatörü','0532 111 0005','emre.yilmaz@firma.com','2022-02-14','tam_zamanli','aktif',17500.00),
('P-00006','Fatma','Şahin','12345678906','1987-02-14',2,2,'İK Uzmanı','0532 111 0006','fatma.sahin.ik@firma.com','2018-07-01','tam_zamanli','aktif',32000.00),
('P-00007','Elif','Koca','12345678907','1993-12-30',2,2,'İK Asistanı','0532 111 0007','elif.koca@firma.com','2022-04-01','tam_zamanli','aktif',22000.00),
('P-00008','Selin','Aydın','12345678908','1989-09-07',2,7,'Kalite Uzmanı','0532 111 0008','selin.aydin@firma.com','2019-11-15','tam_zamanli','aktif',27000.00),
('P-00009','Burak','Güneş','12345678909','1991-04-21',1,7,'Kalite Kontrol','0532 111 0009','burak.gunes@firma.com','2020-08-01','tam_zamanli','aktif',24000.00),
('P-00010','Murat','Doğan','12345678910','1986-06-15',1,6,'Depo Sorumlusu','0532 111 0010','murat.dogan@firma.com','2018-01-15','tam_zamanli','aktif',25000.00),
('P-00011','Kadir','Arslan','12345678911','1994-01-28',1,6,'Depo Görevlisi','0532 111 0011','kadir.arslan@firma.com','2021-05-01','tam_zamanli','aktif',19000.00),
('P-00012','Serkan','Kılıç','12345678912','1997-10-11',1,6,'Forklift Operatörü','0532 111 0012','serkan.kilic@firma.com','2023-01-09','tam_zamanli','aktif',18000.00),
('P-00013','Zeynep','Arslan','12345678913','1990-03-05',2,4,'Satış Uzmanı','0532 111 0013','zeynep.arslan.s@firma.com','2019-05-01','tam_zamanli','aktif',30000.00),
('P-00014','Berk','Özkan','12345678914','1988-07-19',1,4,'Satış Müdürü','0532 111 0014','berk.ozkan@firma.com','2016-09-01','tam_zamanli','aktif',45000.00),
('P-00015','Büşra','Yılmaz','12345678915','1992-11-22',2,3,'Muhasebe Uzmanı','0532 111 0015','busra.yilmaz@firma.com','2020-10-01','tam_zamanli','aktif',34000.00)
ON DUPLICATE KEY UPDATE `durum`='aktif';

-- ─── 3. Müşteriler ─────────────────────────────────────────

INSERT INTO `musteriler` (`kod`,`ad`,`tip`,`vergi_no`,`telefon`,`email`,`il`,`ilce`,`yetkili_adi`,`yetkili_tel`,`yetkili_email`,`odeme_vadesi`,`durum`)
VALUES
('ABC-001','ABC Plastik Sanayi A.Ş.','kurumsal','1234567890','0216 555 0001','info@abcplastik.com','İstanbul','Ümraniye','Ahmet Polat','0532 222 0001','ahmet.polat@abcplastik.com',30,'aktif'),
('DEF-002','Demir Endüstri Ltd.','kurumsal','2345678901','0312 555 0002','info@demirend.com','Ankara','Yenimahalle','Cemal Demir','0533 222 0002','cemal@demirend.com',45,'aktif'),
('XYZ-003','XYZ Makine Sanayi','kurumsal','3456789012','0224 555 0003','info@xyzmakine.com','Bursa','Nilüfer','Selim Yıldız','0534 222 0003','selim@xyzmakine.com',30,'aktif'),
('TRK-004','Türk Metal A.Ş.','kurumsal','4567890123','0212 555 0004','info@turkmetal.com','İstanbul','Başakşehir','Ferhat Türk','0535 222 0004','ferhat@turkmetal.com',60,'aktif'),
('PLS-005','Polimer Plastik Ltd.','kurumsal','5678901234','0236 555 0005','info@polimer.com','Manisa','Yunusemre','Kahraman Can','0536 222 0005','kahraman@polimer.com',30,'aktif')
ON DUPLICATE KEY UPDATE `durum`='aktif';

-- ─── 4. Portal Kullanıcılarını Temizle ve Yeniden Ekle ─────

DELETE FROM `portal_kullanicilari`;

-- Personel portal (Şifre: Personel2024!)
INSERT INTO `portal_kullanicilari` (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`)
SELECT
  'personel',
  p.id,
  p.sicil_no,
  p.email,
  '<?php echo $per_hash; ?>',
  CONCAT(p.ad,' ',p.soyad),
  p.telefon,
  1
FROM `personeller` p
WHERE p.sicil_no IN ('P-00001','P-00002','P-00003','P-00006','P-00015')
  AND EXISTS (SELECT 1 FROM personeller WHERE id=p.id);

-- Müşteri portal (Şifre: Musteri2024!)
INSERT INTO `portal_kullanicilari` (`tip`,`ilgili_id`,`kullanici_adi`,`email`,`sifre_hash`,`ad_soyad`,`telefon`,`durum`)
SELECT
  'musteri',
  m.id,
  m.kod,
  m.yetkili_email,
  '<?php echo $mus_hash; ?>',
  m.yetkili_adi,
  m.yetkili_tel,
  1
FROM `musteriler` m
WHERE m.kod IN ('ABC-001','DEF-002','XYZ-003','TRK-004');

-- ─── 5. Ürünler ────────────────────────────────────────────

INSERT INTO `urunler` (`kod`,`ad`,`kategori`,`birim`,`birim_fiyat`,`stok_miktari`,`min_stok`,`max_stok`)
VALUES
('PRD-K200','Plastik Kapak 200mm','Plastik','adet',12.50,2450,500,5000),
('PRD-B045','Metal Braket X45','Metal','adet',45.00,180,200,2000),
('PRD-G012','Gövde Ürünü B12','Gövde','adet',125.00,0,100,1000),
('PRD-M007','Montaj Parçası C7','Montaj','adet',8.75,5800,1000,10000),
('PRD-V055','Vida Seti 55mm','Bağlantı','paket',3.20,12000,2000,20000),
('PRD-H100','Hidrolik Silindir','Hidrolik','adet',850.00,45,20,200),
('PRD-F030','Filtre Kartuşu 30','Filtre','adet',28.00,320,100,800)
ON DUPLICATE KEY UPDATE `stok_miktari`=VALUES(`stok_miktari`);

-- ─── 6. Kontrol ────────────────────────────────────────────

SELECT 'ERP Kullanıcıları' tablo, COUNT(*) n FROM kullanicilar
UNION ALL SELECT 'Personeller', COUNT(*) FROM personeller
UNION ALL SELECT 'Müşteriler', COUNT(*) FROM musteriler
UNION ALL SELECT 'Portal Kullanıcıları', COUNT(*) FROM portal_kullanicilari
UNION ALL SELECT 'Ürünler', COUNT(*) FROM urunler;
</div>

<h2>✅ Giriş Bilgileri Özeti</h2>
<table>
<tr><th>Portal</th><th>URL</th><th>Kullanıcı Adı / E-posta</th><th>Şifre</th></tr>
<tr><td>ERP Yönetim</td><td>/jetone_pro/giris.php</td><td>admin@jetone.pro</td><td><b>Admin123!</b></td></tr>
<tr><td>ERP Yönetim</td><td>/jetone_pro/giris.php</td><td>ayse.yilmaz@jetone.pro</td><td><b>Jetone2024!</b></td></tr>
<tr><td>Personel Portal</td><td>/jetone_pro/portal/personel/giris.php</td><td>P-00001</td><td><b>Personel2024!</b></td></tr>
<tr><td>Personel Portal</td><td>/jetone_pro/portal/personel/giris.php</td><td>P-00002</td><td><b>Personel2024!</b></td></tr>
<tr><td>Müşteri Portal</td><td>/jetone_pro/portal/musteri/giris.php</td><td>ABC-001</td><td><b>Musteri2024!</b></td></tr>
<tr><td>Müşteri Portal</td><td>/jetone_pro/portal/musteri/giris.php</td><td>DEF-002</td><td><b>Musteri2024!</b></td></tr>
</table>

<div class="uyari">🗑️ İşlem bittikten sonra bu dosyayı silin: <code>del jetone_pro\hash_uret.php</code></div>
</body>
</html>
