@echo off
title JETONE MOXA Bridge Server
echo ╔══════════════════════════════════════╗
echo ║  JETONE MOXA WebSocket Bridge v1.0  ║
echo ╚══════════════════════════════════════╝
cd /d "%~dp0"
IF NOT EXIST node_modules (
  echo Bağımlılıklar yükleniyor...
  npm install
)
echo.
echo Başlatılıyor... ws://localhost:5050
echo MOXA: 192.168.127.254:502
echo.
node moxa_server.js
pause
