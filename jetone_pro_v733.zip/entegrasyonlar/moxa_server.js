/**
 * JETONE.PRO — MOXA E1212 WebSocket Bridge Server
 * Çalıştırma: node moxa_server.js
 * 
 * MOXA E1212 Modbus TCP pin haritası:
 * --- ÇIKIŞLAR (DO) — Modbus Coil ----
 *   D10 → Coil 0 → Vakum Kompresör Röle
 *   D11 → Coil 1 → Valf Röle (hava girişi)
 *   D12 → Coil 2 → Piston Röle
 *   D13 → Coil 3 → Yedek Röle
 * --- GİRİŞLER (DI) — Modbus Discrete Input ---
 *   DI00 → Input 0 → Basınç Ölçer (düşük basınç)
 *   DI01 → Input 1 → Basınç Ölçer (yüksek basınç)
 *   DI02 → Input 2 → Sensör (ürün var/yok)
 *   DI03 → Input 3 → Start Butonu
 *   DI04 → Input 4 → Stop Butonu
 */

const net     = require('net');
const http    = require('http');
const WebSocket = require('ws');

// ── Konfigürasyon ─────────────────────────────────────────
const CFG = {
  moxa: {
    host    : process.env.MOXA_HOST || '192.168.127.254',
    port    : parseInt(process.env.MOXA_PORT || '502'),  // Modbus TCP
    unitId  : parseInt(process.env.MOXA_UNIT || '1'),
  },
  ws: {
    port    : parseInt(process.env.WS_PORT || '5050'),
  },
  poll: {
    intervalMs: parseInt(process.env.POLL_MS || '300'),  // 300ms polling
  },
  tank_test: {
    vakum_sure      : 5000,   // Vakum tutma süresi (ms)
    basinc_esik_min : 0.3,    // Min basınç (bar) — analog yoksa DI ile
    test_timeout    : 30000,  // Max test süresi
  }
};

// ── Modbus TCP Yardımcıları ───────────────────────────────
let transactionId = 0;

function modbusRequest(funcCode, startAddr, count) {
  transactionId = (transactionId + 1) & 0xFFFF;
  const buf = Buffer.alloc(12);
  buf.writeUInt16BE(transactionId, 0); // Transaction ID
  buf.writeUInt16BE(0, 2);             // Protocol ID
  buf.writeUInt16BE(6, 4);             // Length
  buf.writeUInt8(CFG.moxa.unitId, 6); // Unit ID
  buf.writeUInt8(funcCode, 7);         // Function Code
  buf.writeUInt16BE(startAddr, 8);     // Start Address
  buf.writeUInt16BE(count, 10);        // Quantity
  return buf;
}

// FC01: Read Coils (DO durumu oku)
function readCoils(start, count)         { return modbusRequest(0x01, start, count); }
// FC02: Read Discrete Inputs (DI oku)
function readDiscreteInputs(start, count){ return modbusRequest(0x02, start, count); }
// FC05: Write Single Coil (DO yaz)
function writeCoil(addr, value) {
  transactionId = (transactionId + 1) & 0xFFFF;
  const buf = Buffer.alloc(12);
  buf.writeUInt16BE(transactionId, 0);
  buf.writeUInt16BE(0, 2);
  buf.writeUInt16BE(6, 4);
  buf.writeUInt8(CFG.moxa.unitId, 6);
  buf.writeUInt8(0x05, 7);
  buf.writeUInt16BE(addr, 8);
  buf.writeUInt16BE(value ? 0xFF00 : 0x0000, 10);
  return buf;
}

// Modbus yanıtını parse et
function parseCoils(buf, count) {
  const bits = [];
  const byteCount = buf[8];
  for (let i = 0; i < count; i++) {
    const byteIdx = Math.floor(i / 8) + 9;
    const bitIdx  = i % 8;
    bits.push((buf[byteIdx] >> bitIdx) & 1);
  }
  return bits;
}

// ── Cihaz Durumu ──────────────────────────────────────────
const state = {
  connected  : false,
  do_bits    : [0,0,0,0],  // D10-D13 (Coil 0-3)
  di_bits    : [0,0,0,0,0,0,0,0], // DI00-DI07
  basinc     : 0.0,        // bar (analog yoksa DI'dan hesap)
  hata       : null,
  son_guncelle: null,
  // Tank test durumu
  test: {
    aktif   : false,
    aşama   : 'BEKLEMEDE',  // BEKLEMEDE | BASLATIYOR | VAKUM | TEST | TAMAMLANDI | HATA
    sure_ms : 0,
    baslama : null,
    sonuc   : null,
  }
};

// ── MOXA TCP Bağlantısı ───────────────────────────────────
let moxaClient = null;
let pollTimer  = null;
let pendingCb  = null;

function moxaBaglan() {
  if (moxaClient) return;

  moxaClient = new net.Socket();
  moxaClient.setTimeout(3000);

  moxaClient.connect(CFG.moxa.port, CFG.moxa.host, () => {
    state.connected = true;
    state.hata = null;
    console.log(`MOXA bağlandı: ${CFG.moxa.host}:${CFG.moxa.port}`);
    broadcast({ tip: 'baglanti', durum: 'baglandı', mesaj: 'MOXA bağlantısı kuruldu' });
    pollBaslat();
  });

  moxaClient.on('data', (data) => {
    if (pendingCb) {
      pendingCb(null, data);
      pendingCb = null;
    }
  });

  moxaClient.on('error', (err) => {
    state.connected = false;
    state.hata = err.message;
    console.error('MOXA hata:', err.message);
    broadcast({ tip: 'baglanti', durum: 'hata', mesaj: err.message });
    temizle();
  });

  moxaClient.on('close', () => {
    state.connected = false;
    console.log('MOXA bağlantısı kesildi');
    broadcast({ tip: 'baglanti', durum: 'kesildi', mesaj: 'Bağlantı kesildi' });
    temizle();
    setTimeout(moxaBaglan, 3000); // Otomatik yeniden bağlan
  });

  moxaClient.on('timeout', () => {
    moxaClient.destroy();
  });
}

function temizle() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  if (moxaClient) { moxaClient.destroy(); moxaClient = null; }
  pendingCb = null;
}

// Modbus komut gönder + yanıt al
function gonder(buf) {
  return new Promise((res, rej) => {
    if (!moxaClient || !state.connected) return rej(new Error('Bağlı değil'));
    pendingCb = (err, data) => err ? rej(err) : res(data);
    moxaClient.write(buf);
    setTimeout(() => { if (pendingCb) { pendingCb = null; rej(new Error('Timeout')); } }, 2000);
  });
}

// ── Polling — DI + DO oku ─────────────────────────────────
async function pollMoxa() {
  if (!state.connected) return;
  try {
    // DI oku (DI00-DI07)
    const diData = await gonder(readDiscreteInputs(0, 8));
    state.di_bits = parseCoils(diData, 8);

    // DO oku (Coil 0-3)
    const doData = await gonder(readCoils(0, 4));
    state.do_bits = parseCoils(doData, 4);

    state.son_guncelle = Date.now();

    // Basınç tahmini — DI00=düşük, DI01=orta, DI02=yüksek sinyali varsa
    // (gerçek analog sensör yoksa DI'dan boolean basınç)
    state.basinc = state.di_bits[0] ? 0.8 : (state.di_bits[1] ? 0.5 : 0.0);

    // Otomatik Start butonu — DI03
    if (state.di_bits[3] && !state.test.aktif) {
      tankTestBaslat();
    }
    // Stop butonu — DI04
    if (state.di_bits[4] && state.test.aktif) {
      tankTestDurdur('STOP butonuna basıldı');
    }

    broadcast({
      tip      : 'durum',
      do_bits  : state.do_bits,
      di_bits  : state.di_bits,
      basinc   : state.basinc,
      test     : state.test,
      ts       : state.son_guncelle,
    });

  } catch (err) {
    state.hata = err.message;
  }
}

function pollBaslat() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(pollMoxa, CFG.poll.intervalMs);
}

// ── Coil Yaz (DO kontrol) ─────────────────────────────────
async function coilYaz(addr, deger) {
  if (!state.connected) throw new Error('MOXA bağlı değil');
  await gonder(writeCoil(addr, deger));
  state.do_bits[addr] = deger ? 1 : 0;
  console.log(`Coil ${addr} → ${deger ? 'ON' : 'OFF'}`);
}

// ── Tank Test Otomasyonu ───────────────────────────────────
// Pin haritası:
//   Coil 0 (D10) = Vakum Kompresör
//   Coil 1 (D11) = Hava Valfi
//   Coil 2 (D12) = Piston (kitleme)
//   DI00         = Basınç düşük
//   DI01         = Basınç yüksek
//   DI02         = Ürün sensörü (hortum var)
//   DI03         = Start butonu
//   DI04         = Stop butonu

async function tankTestBaslat() {
  if (state.test.aktif) return;
  if (!state.di_bits[2]) {
    broadcast({ tip: 'test_hata', mesaj: 'Hortum bağlı değil (DI02 = 0)' });
    return;
  }

  state.test = { aktif: true, aşama: 'BASLATIYOR', sure_ms: 0, baslama: Date.now(), sonuc: null };
  broadcast({ tip: 'test_basladi', test: state.test });

  try {
    // 1. Piston kapat (fikstür kilitle)
    testLog('Piston kilitleniyor...');
    await coilYaz(2, 1);
    await bekle(500);
    state.test.aşama = 'VAKUM';

    // 2. Vakum kompresörü başlat
    testLog('Vakum başlatılıyor...');
    await coilYaz(0, 1);
    await bekle(CFG.tank_test.vakum_sure);

    // 3. Valfi kapat (vakum tut)
    state.test.aşama = 'TEST';
    testLog('Vakum tutuluyor, basınç kontrol...');
    await coilYaz(0, 0);  // Kompresör kapat
    await coilYaz(1, 0);  // Valf kapat

    // 4. Basınç kontrolü — 5 sn boyunca DI00 (basınç düşük) izle
    let gecirmez = true;
    for (let i = 0; i < 10; i++) {
      await bekle(500);
      await pollMoxa();
      if (state.di_bits[0]) {  // Basınç düştü = sızıntı var
        gecirmez = false;
        break;
      }
    }

    // 5. Sonuç
    state.test.aşama     = 'TAMAMLANDI';
    state.test.aktif     = false;
    state.test.sure_ms   = Date.now() - state.test.baslama;
    state.test.sonuc     = gecirmez ? 'GECTI' : 'KALDI';

    testLog(`Test tamamlandı: ${state.test.sonuc}`);

    // 6. Sistemi sıfırla
    await coilYaz(2, 0);  // Pistonı aç
    await coilYaz(1, 1);  // Valfi aç (basıncı tahliye et)
    await bekle(1000);
    await coilYaz(1, 0);

    broadcast({ tip: 'test_bitti', test: state.test, sonuc: state.test.sonuc });

  } catch (err) {
    tankTestDurdur('Otomasyon hatası: ' + err.message);
  }
}

async function tankTestDurdur(neden) {
  state.test.aktif   = false;
  state.test.aşama   = 'HATA';
  state.test.sonuc   = 'IPTAL';
  // Güvenli durum — her şeyi kapat
  try { await coilYaz(0, 0); } catch(e){}
  try { await coilYaz(1, 0); } catch(e){}
  try { await coilYaz(2, 0); } catch(e){}
  broadcast({ tip: 'test_hata', mesaj: neden, test: state.test });
}

function testLog(mesaj) {
  console.log('[TEST]', mesaj);
  broadcast({ tip: 'test_log', mesaj, ts: Date.now() });
}

function bekle(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── WebSocket Server ──────────────────────────────────────
const server = http.createServer();
const wss    = new WebSocket.Server({ server });

function broadcast(data) {
  const json = JSON.stringify(data);
  wss.clients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(json); });
}

wss.on('connection', (ws) => {
  console.log('WS istemci bağlandı');
  // Mevcut durumu gönder
  ws.send(JSON.stringify({
    tip     : 'ilk_durum',
    connected: state.connected,
    do_bits : state.do_bits,
    di_bits : state.di_bits,
    basinc  : state.basinc,
    test    : state.test,
    config  : CFG.moxa,
  }));

  ws.on('message', async (raw) => {
    try {
      const msg = JSON.parse(raw);
      console.log('WS komut:', msg);

      switch (msg.komut) {
        case 'do_yaz':
          await coilYaz(msg.addr, msg.deger);
          ws.send(JSON.stringify({ tip: 'do_yanit', addr: msg.addr, deger: msg.deger, ok: true }));
          break;

        case 'test_basla':
          await tankTestBaslat();
          break;

        case 'test_durdur':
          await tankTestDurdur('Kullanıcı tarafından durduruldu');
          break;

        case 'tum_kapat':
          for (let i=0; i<4; i++) await coilYaz(i, 0);
          ws.send(JSON.stringify({ tip: 'tum_kapat_yanit', ok: true }));
          break;

        case 'config_guncelle':
          if (msg.moxa_host) CFG.moxa.host = msg.moxa_host;
          if (msg.moxa_port) CFG.moxa.port = parseInt(msg.moxa_port);
          if (msg.vakum_sure) CFG.tank_test.vakum_sure = parseInt(msg.vakum_sure);
          ws.send(JSON.stringify({ tip: 'config_yanit', config: CFG }));
          temizle();
          setTimeout(moxaBaglan, 500);
          break;
      }
    } catch (err) {
      ws.send(JSON.stringify({ tip: 'hata', mesaj: err.message }));
    }
  });

  ws.on('close', () => console.log('WS istemci ayrıldı'));
});

server.listen(CFG.ws.port, () => {
  console.log(`WebSocket server: ws://localhost:${CFG.ws.port}/ws`);
  console.log(`MOXA hedef: ${CFG.moxa.host}:${CFG.moxa.port}`);
  moxaBaglan();
});

process.on('SIGINT', () => {
  console.log('\nKapatılıyor...');
  temizle();
  process.exit();
});
