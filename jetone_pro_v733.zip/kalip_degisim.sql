CREATE TABLE IF NOT EXISTS `kalip_degisim` (
  `kalip_id`       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `urun_kodu`      VARCHAR(100) DEFAULT NULL,
  `urun_adi`       VARCHAR(255) DEFAULT NULL,
  `kalip_aciklama` TEXT,
  `is_istasyonu`   VARCHAR(50)  DEFAULT NULL,
  `aciliyet`       VARCHAR(30)  DEFAULT 'Normal',
  `vardiya`        TINYINT(1)   DEFAULT 1,
  `ekleyen`        VARCHAR(100) DEFAULT NULL,
  `tamamlayan`     VARCHAR(100) DEFAULT NULL,
  `durumu`         VARCHAR(30)  DEFAULT 'Devam Ediyor',
  `baslama_tarih`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bitis_tarih`    DATETIME     DEFAULT NULL,
  KEY `idx_durum`  (`durumu`),
  KEY `idx_tarih`  (`baslama_tarih`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
