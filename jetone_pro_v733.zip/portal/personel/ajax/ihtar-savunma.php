<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){ session_name('JETONE_PERSONEL'); session_start(); }
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz']);exit;}
$portal_kul_id = (int)$_SESSION['portal']['id'];

$d = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$islem = $d['islem'] ?? 'listele';

try {
    // Portal kullanıcısının personel_id'sini bul
    $qp = $db->prepare("SELECT ilgili_id FROM portal_kullanicilari WHERE id=? LIMIT 1");
    $qp->execute([$portal_kul_id]); $pk = $qp->fetch();
    $personel_id = (int)($pk['ilgili_id'] ?? 0);
    if (!$personel_id) { echo json_encode(['ok'=>false,'hata'=>'Personel bulunamadı']); exit; }

    if ($islem === 'listele') {
        $q = $db->prepare("SELECT id,tutanak_no,ihtar_tarihi,durum,savunma,savunma_tarihi,
            neden_mola,neden_telefon,neden_amire,neden_makine,neden_isg,neden_alkol,neden_gorev,neden_hatali,neden_diger,neden_diger_acik
            FROM ihtar_tutanaklar WHERE personel_id=? ORDER BY ihtar_tarihi DESC");
        $q->execute([$personel_id]);
        echo json_encode(['ok'=>true,'ihtarlar'=>$q->fetchAll()]);

    } elseif ($islem === 'savunma_gir') {
        $ihtar_id = (int)($d['ihtar_id'] ?? 0);
        $savunma  = trim($d['savunma'] ?? '');
        if (!$ihtar_id || !$savunma) { echo json_encode(['ok'=>false,'hata'=>'Savunma metni zorunlu']); exit; }
        // Sadece bu personelin ihtarına savunma girebilir, bir kez girebilir
        $chk = $db->prepare("SELECT id, savunma FROM ihtar_tutanaklar WHERE id=? AND personel_id=? LIMIT 1");
        $chk->execute([$ihtar_id, $personel_id]); $row = $chk->fetch();
        if (!$row) { echo json_encode(['ok'=>false,'hata'=>'Tutanak bulunamadı']); exit; }
        if (!empty($row['savunma'])) { echo json_encode(['ok'=>false,'hata'=>'Savunma daha önce girilmiş, değiştirilemez']); exit; }
        $db->prepare("UPDATE ihtar_tutanaklar SET savunma=?, savunma_tarihi=NOW(), durum='kapali' WHERE id=?")
           ->execute([$savunma, $ihtar_id]);
        echo json_encode(['ok'=>true]);
    }
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
