<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){ session_name('JETONE_PERSONEL'); session_start(); }
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz']);exit;}
$pid = (int)$_SESSION['portal']['id'];
$d = json_decode(file_get_contents('php://input'),true) ?: [];
if (empty($d)) { echo json_encode(['ok'=>false,'hata'=>'Veri yok']); exit; }

$str = function($k) use ($d) { return trim($d[$k]??'') ?: null; };
$int = function($k) use ($d) { $v = (int)($d[$k]??0); return $v ?: null; };

$vals = [
    'portal_kul_id' => $pid,
    'anonim'    => (int)($d['anonim']??1),
    'ad_soyad'  => $str('ad_soyad'),
    'departman' => $str('departman'),
    'a1'=>$int('a1'),'a2'=>$int('a2'),'a3'=>$int('a3'),'a4'=>$int('a4'),
    'a5'=>$int('a5'),'a6'=>$int('a6'),'a7'=>$int('a7'),
    'b8'=>$int('b8'),'b9'=>$int('b9'),'b10'=>$int('b10'),'b11'=>$int('b11'),
    'b12'=>$int('b12'),'b13'=>$int('b13'),'b14'=>$int('b14'),'b15'=>$int('b15'),
    'b16'=>$int('b16'),'b17'=>$int('b17'),'b18'=>$int('b18'),'b19'=>$int('b19'),
    'b20'=>$int('b20'),'b21'=>$int('b21'),'b22'=>$int('b22'),'b23'=>$int('b23'),
    'c24'=>$int('c24'),'c25'=>$int('c25'),'c26'=>$int('c26'),'c27'=>$int('c27'),
    'c28'=>$int('c28'),'c29'=>$int('c29'),'c30'=>$int('c30'),
    'mutlu1'=>$str('mutlu1'),'mutlu2'=>$str('mutlu2'),'mutlu3'=>$str('mutlu3'),
    'sikayet1'=>$str('sikayet1'),'sikayet2'=>$str('sikayet2'),'sikayet3'=>$str('sikayet3'),
    'genel_oneri'=>$str('genel_oneri'),
];

try {
    // Daha önce doldurulanı güncelle veya yeni ekle
    $mevcut = $db->prepare("SELECT id FROM anket_yanitlar WHERE portal_kul_id=? LIMIT 1");
    $mevcut->execute([$pid]); $row = $mevcut->fetch();

    if ($row) {
        $set = implode('=?,', array_keys($vals)).'=?';
        $v2 = array_values($vals); $v2[] = $row['id'];
        $db->prepare("UPDATE anket_yanitlar SET $set WHERE id=?")->execute($v2);
    } else {
        $cols = implode(',', array_keys($vals));
        $phs  = implode(',', array_fill(0,count($vals),'?'));
        $db->prepare("INSERT INTO anket_yanitlar ($cols) VALUES ($phs)")->execute(array_values($vals));
    }
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
