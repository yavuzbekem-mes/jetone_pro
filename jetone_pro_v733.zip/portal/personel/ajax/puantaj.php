<?php
ob_start();ini_set('display_errors',0);error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
ob_clean();header('Content-Type: application/json;charset=utf-8');
if(session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if(empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$pid=(int)$_SESSION['portal']['ilgili_id'];
$ay=(int)($_GET['ay']??date('n'));$yil=(int)($_GET['yil']??date('Y'));
try{
  // Personelin vardiya tipini al - mesai eşiği için
  $vt_stmt=$db->prepare("SELECT vardiya_tipi FROM personeller WHERE id=? LIMIT 1");
  $vt_stmt->execute([$pid]);
  $vardiya_tipi=$vt_stmt->fetchColumn()?:'tek';
  $mesai_esik=($vardiya_tipi==='beyaz')?10:8; // Beyaz yaka 10 saat, diğerleri 8 saat

  $st=$db->prepare("SELECT * FROM devam_kayitlari WHERE personel_id=? AND MONTH(tarih)=? AND YEAR(tarih)=? ORDER BY tarih DESC");
  $st->execute([$pid,$ay,$yil]);$rows=$st->fetchAll();
  $gn=['Mon'=>'Pzt','Tue'=>'Sal','Wed'=>'Çar','Thu'=>'Per','Fri'=>'Cum','Sat'=>'Cmt','Sun'=>'Paz'];
  $dt=['geldi'=>'Geldi','gelmedi'=>'Gelmedi','izinli'=>'İzinli','gecikti'=>'Geç Geldi','eksik'=>'Eksik'];
  $veriler=array_map(function($d) use($gn,$dt){
    $g=date('D',strtotime($d['tarih']));
    return['tarih'=>$d['tarih'],'tarih_fmt'=>date('d.m',strtotime($d['tarih'])),'gun'=>$gn[$g]??$g,'giris'=>$d['giris_saati']?date('H:i',strtotime($d['giris_saati'])):null,'cikis'=>$d['cikis_saati']?date('H:i',strtotime($d['cikis_saati'])):null,'sure'=>$d['calisma_suresi']?round($d['calisma_suresi'],1):null,'durum'=>$d['durum']??'geldi','durum_tr'=>$dt[$d['durum']??'geldi']??ucfirst($d['durum']??'geldi')];
  },$rows);
  $toplam=array_sum(array_column($veriler,'sure'));
  $is=count(array_filter($veriler,fn($v)=>$v['durum']==='geldi'));
  echo json_encode(['ok'=>true,'veriler'=>$veriler,'ozet'=>['toplam_sure'=>round($toplam,1),'is_gunu'=>$is,'ay'=>$ay,'yil'=>$yil,'vardiya_tipi'=>$vardiya_tipi,'mesai_esik'=>$mesai_esik]]);
}catch(Exception $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
