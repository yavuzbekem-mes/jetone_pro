<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$pid=(int)$_SESSION['portal']['ilgili_id'];
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `oneri_sikayet` (`id` INT AUTO_INCREMENT PRIMARY KEY,`personel_id` INT NOT NULL,`tip` VARCHAR(20) DEFAULT 'oneri',`konu` VARCHAR(200) NOT NULL,`aciklama` TEXT,`durum` VARCHAR(30) DEFAULT 'bekliyor',`anonim` TINYINT(1) DEFAULT 0,`odul_hakki` TINYINT(1) DEFAULT 0,`odul_tutari` DECIMAL(10,2) DEFAULT 0,`inceleme_notu` TEXT,`inceleme_tarihi` DATETIME DEFAULT NULL,`inceleyici_id` INT DEFAULT NULL,`olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $st=$db->prepare("SELECT * FROM oneri_sikayet WHERE personel_id=? ORDER BY olusturma DESC LIMIT 20");
    $st->execute([$pid]); $rows=$st->fetchAll();
    $tip_tr=['oneri'=>'Öneri','sikayet'=>'Şikayet','dilek'=>'Dilek/İstek'];
    $dur_tr=['bekliyor'=>'Bekliyor','incelemede'=>'İncelemede','onaylandi'=>'Onaylandı','reddedildi'=>'Reddedildi','uygulandi'=>'Uygulandı'];
    $veriler=array_map(function($r) use($tip_tr,$dur_tr){
        return ['id'=>$r['id'],'tip'=>$tip_tr[$r['tip']]??$r['tip'],'konu'=>$r['konu'],'durum'=>$r['durum'],'durum_tr'=>$dur_tr[$r['durum']]??ucfirst($r['durum']),'anonim'=>(bool)$r['anonim'],'odul'=>(bool)$r['odul_hakki'],'odul_tutari'=>$r['odul_tutari'],'tarih'=>date('d.m.Y',strtotime($r['olusturma'])),'not'=>$r['inceleme_notu']??''];
    },$rows);
    echo json_encode(['ok'=>true,'veriler'=>$veriler]);
} catch(Exception $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
