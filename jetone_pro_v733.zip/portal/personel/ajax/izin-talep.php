<?php
ob_start();ini_set('display_errors',0);error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
ob_clean();header('Content-Type: application/json;charset=utf-8');
if(session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if(empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$d=json_decode(file_get_contents('php://input'),true)?:$_POST;
$pid=(int)$_SESSION['portal']['ilgili_id'];
$tur=$d['izin_turu']??'yillik';$bas=$d['baslangic']??'';$bit=$d['bitis']??'';$ack=trim($d['aciklama']??'');
if(!$bas||!$bit){echo json_encode(['ok'=>false,'hata'=>'Tarih zorunlu.']);exit;}
$gun=max(1,(int)((strtotime($bit)-strtotime($bas))/86400)+1);
try{
  if($tur==='yillik'){
    $kull=$db->prepare("SELECT COALESCE(SUM(gun_sayisi),0) FROM izin_talepleri WHERE personel_id=? AND durum='onaylandi' AND izin_turu='yillik' AND YEAR(baslangic)=YEAR(NOW())");
    $kull->execute([$pid]);$kullanilan=(int)$kull->fetchColumn();
    if($kullanilan+$gun>14){echo json_encode(['ok'=>false,'hata'=>'Yetersiz bakiye. Kalan: '.(14-$kullanilan).' gün.']);exit;}
  }
  $db->prepare("INSERT INTO izin_talepleri (personel_id,izin_turu,baslangic,bitis,gun_sayisi,aciklama,durum) VALUES (?,?,?,?,?,?,?)")
     ->execute([$pid,$tur,$bas,$bit,$gun,$ack,'bekliyor']);
  $izin_id=$db->lastInsertId();
  // Yönetici bildirimi
  try{
    $yon=$db->prepare("SELECT p2.id yid FROM personeller p1 JOIN personeller p2 ON p1.yonetici_id=p2.id WHERE p1.id=? LIMIT 1");
    $yon->execute([$pid]);$yRow=$yon->fetch();
    $per=$db->prepare("SELECT CONCAT(ad,' ',soyad) FROM personeller WHERE id=? LIMIT 1");
    $per->execute([$pid]);$perAdi=$per->fetchColumn();
    if($yRow){
      $db->prepare("INSERT IGNORE INTO bildirimler (kullanici_id,tip,baslik,mesaj,ilgili_tip,ilgili_id,okundu) VALUES (?,?,?,?,?,?,0)")
         ->execute([null,'izin_talep','İzin Talebi — '.$perAdi,$perAdi.' '.$gun.' günlük izin talep etti.','izin',$izin_id]);
    }
  }catch(Exception $e){}
  echo json_encode(['ok'=>true,'mesaj'=>$gun.' günlük izin talebiniz gönderildi.','gun'=>$gun]);
}catch(Exception $e){echo json_encode(['ok'=>false,'hata'=>'Kayıt hatası: '.$e->getMessage()]);}
