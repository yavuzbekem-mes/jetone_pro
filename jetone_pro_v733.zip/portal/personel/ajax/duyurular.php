<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){ session_name('JETONE_PERSONEL'); session_start(); }
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false]);exit;}
$pid = (int)$_SESSION['portal']['id'];

$islem = $_POST['islem'] ?? 'listele';

try {
    // Personel bilgilerini al
    $pu = $db->prepare("SELECT pk.ilgili_id, p.departman_id, p.kadro FROM portal_kullanicilari pk LEFT JOIN personeller p ON pk.ilgili_id=p.id WHERE pk.id=? LIMIT 1");
    $pu->execute([$pid]); $pu = $pu->fetch();
    $dept_id  = $pu['departman_id'] ?? 0;
    $kadro    = $pu['kadro'] ?? '';

    if ($islem === 'listele') {
        $bugun = date('Y-m-d');
        $rows = $db->query("SELECT d.*, (SELECT COUNT(*) FROM duyuru_okunanlar WHERE duyuru_id=d.id AND portal_kul_id=$pid) okundu FROM duyurular d WHERE d.aktif=1 AND (d.baslangic IS NULL OR d.baslangic <= '$bugun') AND (d.bitis IS NULL OR d.bitis >= '$bugun') ORDER BY d.oncelik='acil' DESC, d.oncelik='onemli' DESC, d.olusturma DESC LIMIT 20")->fetchAll();

        $duyurular = [];
        foreach ($rows as $r) {
            // Hedef filtrele
            $goster = false;
            if ($r['hedef'] === 'herkese') {
                $goster = true;
            } elseif ($r['hedef'] === 'departman') {
                $ids = json_decode($r['hedef_ids'] ?? '[]', true) ?: [];
                $goster = in_array($dept_id, $ids);
            } elseif ($r['hedef'] === 'kadro') {
                $ids = json_decode($r['hedef_ids'] ?? '[]', true) ?: [];
                $goster = in_array($kadro, $ids);
            }
            if (!$goster) continue;
            $duyurular[] = [
                'id'       => $r['id'],
                'baslik'   => $r['baslik'],
                'icerik'   => $r['icerik'],
                'oncelik'  => $r['oncelik'],
                'tarih'    => date('d.m.Y', strtotime($r['olusturma'])),
                'okundu'   => (bool)$r['okundu'],
            ];
        }
        echo json_encode(['ok'=>true,'duyurular'=>$duyurular]);

    } elseif ($islem === 'detay') {
        $did = (int)($_POST['duyuru_id'] ?? 0);
        if (!$did) { echo json_encode(['ok'=>false]); exit; }
        $r = $db->prepare("SELECT icerik FROM duyurular WHERE id=? LIMIT 1");
        $r->execute([$did]); $row = $r->fetch();
        echo json_encode(['ok'=>true,'icerik'=>$row['icerik']??'']);

    } elseif ($islem === 'oku') {
        $did = (int)($_POST['duyuru_id'] ?? 0);
        if ($did) {
            $db->prepare("INSERT IGNORE INTO duyuru_okunanlar (duyuru_id, portal_kul_id) VALUES (?,?)")->execute([$did, $pid]);
        }
        echo json_encode(['ok'=>true]);
    }
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
