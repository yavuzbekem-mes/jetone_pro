<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$pid=(int)$_SESSION['portal']['ilgili_id'];
try {
    $stmt=$db->prepare("SELECT p.*,d.ad dept_adi FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.id=? LIMIT 1");
    $stmt->execute([$pid]); $p=$stmt->fetch();
    if (!$p){echo json_encode(['ok'=>false,'hata'=>'Bulunamadı.']);exit;}
    // Son giriş
    $sg=$db->prepare("SELECT giris_saati FROM devam_kayitlari WHERE personel_id=? ORDER BY tarih DESC LIMIT 1");
    $sg->execute([$pid]); $son_giris=$sg->fetchColumn();
    // Doğum günü kontrolü
    $dogum = $p['dogum_tarihi'] ?? '';
    $bugun_dogum = $dogum && date('m-d', strtotime($dogum)) === date('m-d');
    echo json_encode(['ok'=>true,'profil'=>['ad'=>$p['ad'],'soyad'=>$p['soyad'],'sicil'=>$p['sicil_no'],'dept'=>$p['dept_adi']??'','pozisyon'=>$p['pozisyon']??'','email'=>$p['email']??'','telefon'=>$p['telefon']??'','ise_baslama'=>$p['ise_baslama']??'','son_giris'=>$son_giris?date('d.m.Y H:i',strtotime($son_giris)):null,'dogum_gunu'=>$bugun_dogum,'dogum_tarihi'=>$dogum]]);
} catch(Exception $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
