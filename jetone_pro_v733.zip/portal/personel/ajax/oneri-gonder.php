<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/push-gonder.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}

$pid  = (int)$_SESSION['portal']['ilgili_id'];
$d    = json_decode(file_get_contents('php://input'),true) ?: $_POST;

$tip     = in_array($d['tip']??'', ['oneri','sikayet','dilek']) ? $d['tip'] : 'oneri';
$konu    = trim($d['konu']    ?? '');
$aciklama= trim($d['aciklama'] ?? '');
$anonim  = (int)(!empty($d['anonim']));

if (!$konu || !$aciklama) { echo json_encode(['ok'=>false,'hata'=>'Konu ve açıklama zorunludur.']); exit; }
if (mb_strlen($aciklama) < 20) { echo json_encode(['ok'=>false,'hata'=>'Açıklama en az 20 karakter olmalıdır.']); exit; }

try {
    // Tablo yoksa oluştur
    $db->exec("CREATE TABLE IF NOT EXISTS `oneri_sikayet` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `personel_id` INT NOT NULL,
        `tip` ENUM('oneri','sikayet','dilek') NOT NULL DEFAULT 'oneri',
        `konu` VARCHAR(200) NOT NULL,
        `aciklama` TEXT NOT NULL,
        `durum` ENUM('bekliyor','incelemede','onaylandi','reddedildi','uygulandi') DEFAULT 'bekliyor',
        `anonim` TINYINT(1) DEFAULT 0,
        `odul_hakki` TINYINT(1) DEFAULT 0,
        `odul_tutari` DECIMAL(10,2) DEFAULT 0,
        `inceleme_notu` TEXT,
        `inceleme_tarihi` DATETIME DEFAULT NULL,
        `inceleyici_id` INT DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pid (personel_id), INDEX idx_d (durum)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->prepare("INSERT INTO oneri_sikayet (personel_id,tip,konu,aciklama,anonim,durum) VALUES (?,?,?,?,?,'bekliyor')")
       ->execute([$pid, $tip, $konu, $aciklama, $anonim]);
    $id = $db->lastInsertId();

    // Oneri ise ödül bilgisi ver
    $odul_mesaj = '';
    if ($tip === 'oneri') {
        $odul_mesaj = ' Öneriniz değerlendirilip uygulanabilir bulunursa ₺2.500 öneri ödülüne hak kazanırsınız!';
    }

    // IK yöneticilerine bildirim
    try {
        $per = $db->prepare("SELECT CONCAT(ad,' ',soyad) ad FROM personeller WHERE id=? LIMIT 1");
        $per->execute([$pid]); $perAdi = $per->fetchColumn() ?: 'Personel';
        $gorAdi = $anonim ? 'Anonim' : $perAdi;

        $tip_tr = ['oneri'=>'Öneri','sikayet'=>'Şikayet','dilek'=>'Dilek'];
        $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu)
                      VALUES (?,?,?,?,?,?,0)")
           ->execute([null,'erp',
               "Yeni {$tip_tr[$tip]}: $konu",
               "$gorAdi tarafından yeni bir {$tip_tr[$tip]} iletildi.",
               'uyari','oneri']);
    } catch(Exception $e) {}

    // Personele onay bildirimi
    try {
        $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu)
                      VALUES (?,?,?,?,?,?,0)")
           ->execute([
               (int)$_SESSION['portal']['id'], 'personel',
               ($tip==='oneri'?'💡':'📢').' '.($tip_tr[$tip]??ucfirst($tip)).' Alındı',
               "\"$konu\" başlıklı ".($tip_tr[$tip]??$tip)."niz başarıyla iletildi. İncelenip size bildirim yapılacak.$odul_mesaj",
               'basari', 'oneri'
           ]);
    } catch(Exception $e) {}

    echo json_encode([
        'ok'    => true,
        'mesaj' => ($tip==='oneri'?'💡 Öneriniz':'📢 '.($tip_tr[$tip]??ucfirst($tip)).'iniz').' başarıyla iletildi!'.$odul_mesaj,
        'id'    => $id,
    ]);
} catch(Exception $e) {
    echo json_encode(['ok'=>false,'hata'=>'Kayıt hatası: '.$e->getMessage()]);
}
