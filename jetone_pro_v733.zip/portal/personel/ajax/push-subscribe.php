<?php
/**
 * Push Subscription Kaydet / Sil
 * portal/personel/ajax/push-subscribe.php
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){
    echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']); exit;
}

$portal_kul_id = (int)$_SESSION['portal']['id'];
$pid           = (int)$_SESSION['portal']['ilgili_id'];
$d = json_decode(file_get_contents('php://input'),true) ?: [];
$islem = $d['islem'] ?? 'kaydet'; // kaydet | sil

try {
    // Tablo yoksa oluştur
    $db->exec("CREATE TABLE IF NOT EXISTS push_subscriptions (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        portal_kul_id INT NOT NULL,
        personel_id   INT DEFAULT NULL,
        endpoint      TEXT NOT NULL,
        p256dh        VARCHAR(500) NOT NULL,
        auth          VARCHAR(200) NOT NULL,
        user_agent    VARCHAR(300) DEFAULT NULL,
        aktif         TINYINT(1) DEFAULT 1,
        olusturma     DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pki (portal_kul_id),
        INDEX idx_pid (personel_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    if ($islem === 'kaydet') {
        $endpoint = $d['endpoint']      ?? '';
        $p256dh   = $d['keys']['p256dh'] ?? '';
        $auth_key = $d['keys']['auth']   ?? '';

        if (!$endpoint || !$p256dh || !$auth_key) {
            echo json_encode(['ok'=>false,'hata'=>'Eksik subscription verisi']); exit;
        }

        // Varsa güncelle, yoksa ekle
        $mevcut = $db->prepare("SELECT id FROM push_subscriptions WHERE portal_kul_id=? AND endpoint=? LIMIT 1");
        $mevcut->execute([$portal_kul_id, $endpoint]);
        $row = $mevcut->fetch();

        if ($row) {
            $db->prepare("UPDATE push_subscriptions SET p256dh=?,auth=?,aktif=1,olusturma=NOW() WHERE id=?")
               ->execute([$p256dh, $auth_key, $row['id']]);
        } else {
            $db->prepare("INSERT INTO push_subscriptions (portal_kul_id,personel_id,endpoint,p256dh,auth,user_agent) VALUES (?,?,?,?,?,?)")
               ->execute([$portal_kul_id, $pid, $endpoint, $p256dh, $auth_key, substr($_SERVER['HTTP_USER_AGENT']??'',0,300)]);
        }

        echo json_encode(['ok'=>true,'mesaj'=>'Push bildirimleri aktif edildi.']);

    } elseif ($islem === 'sil') {
        $endpoint = $d['endpoint'] ?? '';
        if ($endpoint) {
            $db->prepare("UPDATE push_subscriptions SET aktif=0 WHERE portal_kul_id=? AND endpoint=?")
               ->execute([$portal_kul_id, $endpoint]);
        }
        echo json_encode(['ok'=>true]);

    } elseif ($islem === 'vapid_key') {
        // Public key'i client'a gönder
        echo json_encode(['ok'=>true,'publicKey'=>defined('VAPID_PUBLIC')?VAPID_PUBLIC:'']);
    }

} catch (Exception $e) {
    error_log('[PushSubscribe] ' . $e->getMessage());
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
