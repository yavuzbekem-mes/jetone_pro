<?php
ob_start();ini_set('display_errors',0);error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
ob_clean();header('Content-Type: application/json;charset=utf-8');
if(session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if(empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$pid=(int)$_SESSION['portal']['ilgili_id'];
try{
  $st=$db->prepare("SELECT * FROM izin_talepleri WHERE personel_id=? ORDER BY olusturma DESC LIMIT 20");
  $st->execute([$pid]);$rows=$st->fetchAll();
  $tt=['yillik'=>'Yıllık','hastalik'=>'Hastalık','mazeret'=>'Mazeret','ucretsiz'=>'Ücretsiz'];
  $kull=$db->prepare("SELECT COALESCE(SUM(gun_sayisi),0) FROM izin_talepleri WHERE personel_id=? AND durum='onaylandi' AND izin_turu='yillik' AND YEAR(baslangic)=YEAR(NOW())");
  $kull->execute([$pid]);$kullanilan=(int)$kull->fetchColumn();
  echo json_encode(['ok'=>true,'bakiye'=>['toplam'=>14,'kullanilan'=>$kullanilan,'kalan'=>max(0,14-$kullanilan)],'veriler'=>array_map(fn($r)=>['id'=>$r['id'],'tur'=>$tt[$r['izin_turu']]??$r['izin_turu'],'bas'=>date('d.m.Y',strtotime($r['baslangic'])),'bit'=>date('d.m.Y',strtotime($r['bitis'])),'gun'=>$r['gun_sayisi'],'durum'=>$r['durum']],$rows)]);
}catch(Exception $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
