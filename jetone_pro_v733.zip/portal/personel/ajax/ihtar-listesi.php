<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){ session_name('JETONE_PERSONEL'); session_start(); }
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false]);exit;}
$pid = (int)$_SESSION['portal']['id'];

// Portal kullanıcısının personel_id'sini bul
try {
    $pu = $db->prepare("SELECT ilgili_id FROM portal_kullanicilari WHERE id=? LIMIT 1");
    $pu->execute([$pid]); $pu = $pu->fetch();
    if (!$pu || !$pu['ilgili_id']) { echo json_encode(['ok'=>true,'ihtarlar',[]]); exit; }
    $per_id = (int)$pu['ilgili_id'];

    $q = $db->prepare("SELECT id, tutanak_no, ihtar_tarihi, nedenler, diger_neden, savunma, durum FROM ihtar_tutanaklar WHERE personel_id=? ORDER BY ihtar_tarihi DESC");
    $q->execute([$per_id]);
    $rows = $q->fetchAll();

    $nedenler_listesi = ['Mola saatleri dışında görev yerini terk etmek.','Mola saatleri dışında cep telefonu ile görüşme yapmak.','Amirlere ve arkadaşlarına karşı gelmek.','Makine ve techizatlara zarar vermek.','İş sağlığı ve güvenliği kurallarına uymamak.','İş yerinde alkollü ve sarhoş olmak.','4857 sayılı kanunun 25/A maddesi.','Hatalı üretim / işlem yapmak.'];

    $ihtarlar = [];
    foreach ($rows as $r) {
        $nedenler_idx = json_decode($r['nedenler']??'[]',true) ?: [];
        $nedenler_metin = [];
        foreach ($nedenler_idx as $ni) {
            if ($ni < count($nedenler_listesi)) $nedenler_metin[] = $nedenler_listesi[$ni];
            elseif ($r['diger_neden']) $nedenler_metin[] = 'Diğer: '.$r['diger_neden'];
        }
        $ihtarlar[] = [
            'id'         => $r['id'],
            'tutanak_no' => $r['tutanak_no'],
            'ihtar_tarihi'=> date('d.m.Y',strtotime($r['ihtar_tarihi'])),
            'nedenler'   => $nedenler_metin,
            'savunma'    => $r['savunma'],
            'durum'      => $r['durum'],
        ];
    }
    echo json_encode(['ok'=>true,'ihtarlar'=>$ihtarlar]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
