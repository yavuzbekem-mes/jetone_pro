<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){ session_name('JETONE_PERSONEL'); session_start(); }
if (empty($_SESSION['portal']['id'])) { echo json_encode(['dolduruldu'=>false]); exit; }
$pid = (int)$_SESSION['portal']['id'];
try {
    $q = $db->prepare("SELECT olusturma FROM anket_yanitlar WHERE portal_kul_id=? ORDER BY olusturma DESC LIMIT 1");
    $q->execute([$pid]); $r = $q->fetch();
    if ($r) { echo json_encode(['dolduruldu'=>true,'tarih'=>date('d.m.Y',strtotime($r['olusturma']))]); }
    else { echo json_encode(['dolduruldu'=>false]); }
} catch (Throwable $e) { echo json_encode(['dolduruldu'=>false]); }
