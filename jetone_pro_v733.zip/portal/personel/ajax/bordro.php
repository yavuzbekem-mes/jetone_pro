<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']);exit;}
$pid=(int)$_SESSION['portal']['ilgili_id'];
$ay  =(int)($_GET['ay']  ?? date('n'));
$yil =(int)($_GET['yil'] ?? date('Y'));

try {
    // Tablo yoksa oluştur
    $db->exec("CREATE TABLE IF NOT EXISTS `bordro_dosyalar` (`id` INT AUTO_INCREMENT PRIMARY KEY,`personel_id` INT NOT NULL,`ay` TINYINT NOT NULL,`yil` SMALLINT NOT NULL,`dosya_adi` VARCHAR(300) NOT NULL,`dosya_yol` VARCHAR(500) NOT NULL,`yukleyen_id` INT DEFAULT NULL,`olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uk_per_ay_yil (personel_id,ay,yil)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Bu ay bordro
    $st=$db->prepare("SELECT * FROM bordro_dosyalar WHERE personel_id=? AND ay=? AND yil=? LIMIT 1");
    $st->execute([$pid,$ay,$yil]); $buAy=$st->fetch();

    // Son 12 ay liste
    $liste=$db->prepare("SELECT ay,yil,dosya_adi,olusturma FROM bordro_dosyalar WHERE personel_id=? ORDER BY yil DESC,ay DESC LIMIT 12");
    $liste->execute([$pid]); $tumBordrolar=$liste->fetchAll();

    $aylar=['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
    $veriler=array_map(function($b) use($aylar){
        return [
            'ay'    =>$b['ay'],
            'yil'   =>$b['yil'],
            'ay_ad' =>$aylar[$b['ay']].' '.$b['yil'],
            'dosya' =>$b['dosya_adi'],
            'url'   =>BASE_URL.'/uploads/bordrolar/'.rawurlencode($b['dosya_adi']),
            'tarih' =>date('d.m.Y',strtotime($b['olusturma'])),
        ];
    },$tumBordrolar);

    echo json_encode([
        'ok'     =>true,
        'bu_ay'  =>$buAy?['url'=>BASE_URL.'/uploads/bordrolar/'.rawurlencode($buAy['dosya_adi']),'ay_ad'=>$aylar[$ay].' '.$yil]:null,
        'veriler'=>$veriler,
    ]);
} catch(Exception $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
