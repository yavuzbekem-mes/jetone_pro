<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE){session_name('JETONE_PERSONEL');session_start();}
if (empty($_SESSION['portal']['id'])||$_SESSION['portal']['tip']!=='personel'){
    echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']); exit;
}
$portal_kul_id = (int)$_SESSION['portal']['id'];

// Okunmamış sayısı
$d = json_decode(file_get_contents('php://input'),true) ?: $_GET;
$islem = $d['islem'] ?? 'liste';

try {
    if ($islem === 'okundu_isle') {
        $bil_id = (int)($d['id'] ?? 0);
        if ($bil_id) {
            $db->prepare("UPDATE bildirimler SET okundu=1, okunma_tarihi=NOW() WHERE id=? AND (kullanici_id=? OR kullanici_id IS NULL) AND portal_tipi='personel'")
               ->execute([$bil_id, $portal_kul_id]);
        } else {
            $db->prepare("UPDATE bildirimler SET okundu=1, okunma_tarihi=NOW() WHERE (kullanici_id=? OR kullanici_id IS NULL) AND portal_tipi='personel' AND okundu=0")
               ->execute([$portal_kul_id]);
        }
        echo json_encode(['ok'=>true]); exit;
    }

    // Bildirim listesi
    $stmt = $db->prepare("SELECT * FROM bildirimler 
        WHERE (kullanici_id=? OR kullanici_id IS NULL) 
          AND portal_tipi='personel'
        ORDER BY okundu ASC, olusturma DESC 
        LIMIT 30");
    $stmt->execute([$portal_kul_id]);
    $rows = $stmt->fetchAll();

    $okunmamis = count(array_filter($rows, function($r){ return !$r['okundu']; }));

    $bildirimler = array_map(function($r) {
        return [
            'id'        => $r['id'],
            'baslik'    => $r['baslik'],
            'mesaj'     => $r['mesaj'],
            'tip'       => $r['tip'],
            'okundu'    => (bool)$r['okundu'],
            'tarih'     => $r['olusturma'] ? date('d.m H:i', strtotime($r['olusturma'])) : '',
            'tarih_tam' => $r['olusturma'] ?? '',
            'modul'     => $r['modul'] ?? '',
            'link'      => $r['link'] ?? '',
        ];
    }, $rows);

    echo json_encode(['ok'=>true,'bildirimler'=>$bildirimler,'okunmamis'=>$okunmamis]);
} catch(Exception $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
