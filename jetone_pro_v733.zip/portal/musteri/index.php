<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
session_name("JETONE_MUSTERI"); session_start();
if (empty($_SESSION['portal']['id']) || $_SESSION['portal']['tip'] !== 'musteri') {
    header('Location: ' . BASE_URL . '/portal/musteri/giris.php'); exit;
}
$portal = $_SESSION['portal'];
$musteriId = $portal['ilgili_id'];
// İrsaliyeler
$irsaliyeler = [];
try {
    $stmt = $db->prepare("SELECT * FROM irsaliyeler WHERE musteri_id=? ORDER BY tarih DESC LIMIT 20");
    $stmt->execute([$musteriId]); $irsaliyeler = $stmt->fetchAll();
} catch(Throwable $e){}
// Stok tanımları
$stoklar = [];
try {
    $stmt2 = $db->prepare("SELECT mst.*, u.ad urun_adi, u.stok_miktari, u.birim FROM musteri_stok_tanimlari mst JOIN urunler u ON mst.urun_id=u.id WHERE mst.musteri_id=? AND mst.aktif=1");
    $stmt2->execute([$musteriId]); $stoklar = $stmt2->fetchAll();
} catch(Throwable $e){}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<link rel="icon" type="image/svg+xml" href="<?php echo BASE_URL; ?>/favicons/musteri.svg">
<link rel="shortcut icon" href="<?php echo BASE_URL; ?>/favicons/musteri.svg">
<meta name="theme-color" content="#10B981">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Müşteri Portalı</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/portal/musteri/css/portal.css">
</head>
<body>
<div class="mp-header">
  <div class="mph-sol">
    <div class="mph-logo">J</div>
    <div><div class="mph-marka">Müşteri Portalı</div><div class="mph-musteri"><?php echo htmlspecialchars($portal['musteri_adi']??$portal['ad_soyad']??''); ?></div></div>
  </div>
  <div class="mph-sag">
    <div class="mph-av"><?php echo mb_strtoupper(mb_substr($portal['ad_soyad']??'M',0,2)); ?></div>
    <a href="<?php echo BASE_URL; ?>/portal/musteri/cikis.php" style="color:rgba(255,255,255,.6);font-size:12px;text-decoration:none">Çıkış</a>
  </div>
</div>

<div class="mp-sekmeler">
  <button class="mp-sekme aktif" onclick="tabGoster('irsaliye',this)">🚚 İrsaliyeler</button>
  <button class="mp-sekme" onclick="tabGoster('stok',this)">📦 Stok Durumu</button>
  <button class="mp-sekme" onclick="tabGoster('siparisler',this)">📋 Siparişler</button>
</div>

<div class="mp-icerik">
  <!-- İrsaliyeler -->
  <div class="mp-tab aktif" id="t-irsaliye">
    <?php if(empty($irsaliyeler)): ?>
    <div style="text-align:center;padding:40px;color:var(--m2)">Aktif irsaliye bulunamadı.</div>
    <?php else: foreach($irsaliyeler as $irs):
      $durumRenk=['hazirlaniyor'=>['#E0F2FE','#0284C7'],'yuklendi'=>['#FEF0C7','#B45309'],'yolda'=>['#FEF3E8','#EA6800'],'teslimde'=>['#FEF0C7','#B45309'],'teslim'=>['#D1FADF','#0A8F4E'],'iade'=>['#FEE4E2','#F04438']];
      $dr=$durumRenk[$irs['durum']]??['#F4F5F7','#667085'];
      $adimPct=['hazirlaniyor'=>10,'yuklendi'=>30,'yolda'=>55,'teslimde'=>78,'teslim'=>100];
      $pct=$adimPct[$irs['durum']]??0;
    ?>
    <div class="irs-kart">
      <div class="irs-ust">
        <div><div class="irs-no"><?php echo htmlspecialchars($irs['irsaliye_no']); ?></div><div class="irs-tarih"><?php echo date('d.m.Y',strtotime($irs['tarih'])); ?></div></div>
        <span class="roz" style="background:<?php echo $dr[0]; ?>;color:<?php echo $dr[1]; ?>"><?php echo ucfirst($irs['durum']); ?></span>
      </div>
      <?php if($irs['arac_plaka']): ?><div style="font-size:12px;color:var(--m2);margin-bottom:8px"><?php echo htmlspecialchars($irs['arac_plaka']); ?> • <?php echo htmlspecialchars($irs['surucu_adi']??''); ?></div><?php endif; ?>
      <div class="ilerleme">
        <div class="ilerleme-dolgu" style="width:<?php echo $pct; ?>%"></div>
        <div class="adimlar">
          <?php foreach(['Hazırlandı','Yüklendi','Yolda','Teslimde','Teslim'] as $idx=>$adAd): $done=($pct>($idx*22)); ?>
          <div class="adim"><div class="adim-nokta <?php echo $done?'tamam':($pct>($idx*22-11)&&!$done?'simdiki':''); ?>">
            <?php echo $done?'✓':''; ?></div><div class="adim-et"><?php echo $adAd; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php if($irs['teslim_tarihi']): ?><div style="font-size:12px;color:var(--m2)">Tahmini: <?php echo date('d.m.Y',strtotime($irs['teslim_tarihi'])); ?></div><?php endif; ?>
    </div>
    <?php endforeach; endif; ?>
  </div>

  <!-- Stok -->
  <div class="mp-tab" id="t-stok">
    <div style="background:var(--t-a,#FEF3E8);border:1px solid #FED7AA;border-radius:var(--r);padding:11px;margin-bottom:14px;font-size:12.5px;color:#EA6800">
      ℹ️ Stok seviyeleri gerçek zamanlı güncellenmektedir.
    </div>
    <?php if(empty($stoklar)): ?>
    <div style="text-align:center;padding:40px;color:var(--m2)">Tanımlı stok bulunamadı.</div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px">
      <?php foreach($stoklar as $s):
        $miktar=(float)$s['stok_miktari'];
        $max=max($miktar*1.2,100);
        $pct=min(100,round($miktar/$max*100));
        if($miktar<=0){ $renk='#F04438'; $bg='#FEE4E2'; }
        elseif($miktar<=$s['min_stok_uyari']){ $renk='#F79009'; $bg='#FEF0C7'; }
        else { $renk='#12B76A'; $bg='#D1FADF'; }
      ?>
      <div style="background:var(--yuzey);border:1px solid var(--kenar);border-left:3px solid <?php echo $renk; ?>;border-radius:var(--r);padding:14px">
        <div style="font-size:10px;color:var(--m3);font-weight:700;text-transform:uppercase;margin-bottom:4px"><?php echo htmlspecialchars($s['musteri_urun_kodu']??$s['urun_id']??''); ?></div>
        <div style="font-size:13px;font-weight:700;margin-bottom:10px;line-height:1.3"><?php echo htmlspecialchars($s['musteri_urun_adi']??$s['urun_adi']??''); ?></div>
        <div style="font-size:26px;font-weight:800;color:<?php echo $renk; ?>;letter-spacing:-1px"><?php echo number_format($miktar,0,'.',','); ?></div>
        <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($s['birim']??'adet'); ?></div>
        <div style="height:4px;background:var(--kenar);border-radius:3px;overflow:hidden;margin-top:8px"><div style="width:<?php echo $pct; ?>%;height:100%;background:<?php echo $renk; ?>;border-radius:3px"></div></div>
        <?php if($miktar<=0): ?><div style="font-size:10px;color:<?php echo $renk; ?>;margin-top:4px;font-weight:600">❌ Stok yok</div>
        <?php elseif($miktar<=$s['min_stok_uyari']): ?><div style="font-size:10px;color:<?php echo $renk; ?>;margin-top:4px;font-weight:600">⚠ Düşük seviye</div>
        <?php else: ?><div style="font-size:10px;color:<?php echo $renk; ?>;margin-top:4px;font-weight:600">✓ Yeterli</div><?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Siparişler -->
  <div class="mp-tab" id="t-siparisler">
    <div style="text-align:center;padding:40px;color:var(--m2)">Sipariş geçmişi yakında.</div>
  </div>
</div>

<script>
function tabGoster(id,btn){
  document.querySelectorAll('.mp-tab').forEach(t=>t.classList.remove('aktif'));
  document.querySelectorAll('.mp-sekme').forEach(s=>s.classList.remove('aktif'));
  document.getElementById('t-'+id).classList.add('aktif');
  btn.classList.add('aktif');
}
</script>
</body>
</html>
