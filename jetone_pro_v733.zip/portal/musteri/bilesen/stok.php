<?php /* musteri portal: stok */ ?>
