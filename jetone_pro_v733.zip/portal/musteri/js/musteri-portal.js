/* musteri-portal.js */
