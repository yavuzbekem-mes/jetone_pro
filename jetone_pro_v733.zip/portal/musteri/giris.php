<?php
/**
 * Müşteri Portalı — Giriş
 * portal/musteri/giris.php
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';

if (session_status() === PHP_SESSION_NONE) { session_name("JETONE_MUSTERI"); session_start(); }

if (!empty($_SESSION['portal']['id']) && $_SESSION['portal']['tip'] === 'musteri') {
    header('Location: ' . BASE_URL . '/portal/musteri/index.php');
    exit;
}

$hata = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kulAdi = trim($_POST['kullanici_adi'] ?? '');
    $sifre  = trim($_POST['sifre']         ?? '');

    if ($kulAdi && $sifre) {
        try {
            $stmt = $db->prepare("
                SELECT pk.*, m.ad musteri_adi, m.kod musteri_kodu, m.id musteri_db_id
                FROM portal_kullanicilari pk
                LEFT JOIN musteriler m ON pk.ilgili_id = m.id
                WHERE pk.tip = 'musteri'
                  AND (pk.kullanici_adi = ? OR pk.email = ?)
                LIMIT 1
            ");
            $stmt->execute([$kulAdi, $kulAdi]);
            $kul = $stmt->fetch();

            if (!$kul) {
                $hata = 'Müşteri kodu veya şifre hatalı.';
            } elseif ((int)$kul['durum'] === 0) {
                $hata = '⛔ Hesabınız askıya alınmıştır. Lütfen yetkili satış temsilcinizle iletişime geçin.';
            } elseif (!password_verify($sifre, $kul['sifre_hash'])) {
                $hata = 'Müşteri kodu veya şifre hatalı.';
            } else {
                $kul['sifre_uyumlu'] = true;
            }

            if (isset($kul['sifre_uyumlu'])) {
                session_regenerate_id(true);
                $_SESSION['portal'] = [
                    'id'           => $kul['id'],
                    'tip'          => 'musteri',
                    'ilgili_id'    => $kul['ilgili_id'],
                    'kullanici_adi'=> $kul['kullanici_adi'],
                    'ad_soyad'     => $kul['ad_soyad'] ?? $kulAdi,
                    'musteri_adi'  => $kul['musteri_adi'] ?? $kulAdi,
                    'musteri_kodu' => $kul['musteri_kodu'] ?? $kulAdi,
                ];
                $db->prepare("UPDATE portal_kullanicilari SET son_giris=NOW() WHERE id=?")
                   ->execute([$kul['id']]);
                header('Location: ' . BASE_URL . '/portal/musteri/index.php');
                exit;
            }
        } catch (\Throwable $e) {
            error_log('[MusteriPortal] ' . $e->getMessage());
            $hata = 'Sistem hatası. Lütfen tekrar deneyin.';
        }
    } else {
        $hata = 'Tüm alanları doldurun.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<link rel="icon" type="image/svg+xml" href="<?php echo BASE_URL; ?>/favicons/musteri.svg">
<link rel="shortcut icon" href="<?php echo BASE_URL; ?>/favicons/musteri.svg">
<meta name="theme-color" content="#10B981">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Müşteri Portalı — Giriş</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--t:#F97316;--t-k:#EA6800;--lac:#1A2E4A;--lac-k:#111E30;--bg:#F0F4F8;--yuzey:#fff;--kenar:#E4E7EC;--m:#101828;--m2:#667085;--m3:#98A2B3;--hat:#F04438;--hat-a:#FEE4E2;--r:8px;--r-lg:12px;--bas:#12B76A}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{min-height:100%}
body{font-family:'Plus Jakarta Sans',system-ui,sans-serif;font-size:14px;color:var(--m);background:var(--bg);display:flex;min-height:100vh}

/* Sol panel */
.sol{
  width:420px;flex-shrink:0;background:var(--lac-k);
  position:relative;overflow:hidden;
  display:flex;align-items:center;justify-content:center;padding:40px;
}
.sol-bg{position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 10% 80%,rgba(249,115,22,.2) 0%,transparent 60%),linear-gradient(160deg,#1A2E4A 0%,#080F1A 100%)}
.sol-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:40px 40px}
.sol-ic{position:relative;z-index:1;color:#fff;text-align:center}
.sol-logo{width:72px;height:72px;border-radius:18px;background:var(--t);display:flex;align-items:center;justify-content:center;font-size:32px;margin:0 auto 20px;box-shadow:0 12px 32px rgba(249,115,22,.4)}
.sol-bas{font-size:26px;font-weight:800;letter-spacing:-1px;margin-bottom:10px}
.sol-alt{font-size:13px;color:rgba(255,255,255,.5);line-height:1.6;margin-bottom:24px}
.ozellik{display:flex;flex-direction:column;gap:10px;text-align:left}
.oz{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:var(--r);padding:10px 14px}
.oz-i{font-size:20px;flex-shrink:0}
.oz-a{font-size:13px;font-weight:700}
.oz-b{font-size:11px;color:rgba(255,255,255,.45)}

/* Sağ panel */
.sag{flex:1;display:flex;align-items:center;justify-content:center;padding:32px;overflow-y:auto}
.kart{width:100%;max-width:380px;background:var(--yuzey);border:1px solid var(--kenar);border-radius:16px;padding:36px;box-shadow:0 20px 40px rgba(0,0,0,.1)}
.kart-logo{display:flex;align-items:center;gap:10px;justify-content:center;margin-bottom:24px}
.kl-ikon{width:38px;height:38px;border-radius:10px;background:var(--t);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;font-size:16px}
.kl-marka{font-size:20px;font-weight:800}
.kl-marka span{color:var(--t)}
.kart h2{font-size:19px;font-weight:700;text-align:center;margin-bottom:4px}
.kart-alt{text-align:center;font-size:13px;color:var(--m2);margin-bottom:24px}
.hata{background:var(--hat-a);border:1px solid var(--hat);border-radius:var(--r);padding:11px 14px;font-size:13px;color:var(--hat);margin-bottom:16px;font-weight:600}
.bilgi-kutu{background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r);padding:12px 14px;margin-bottom:18px}
.bilgi-kutu-bas{font-size:11px;font-weight:700;color:#1D4ED8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}
.bilgi-satir{display:flex;justify-content:space-between;font-size:12.5px;padding:3px 0;border-bottom:1px solid rgba(29,78,216,.1)}
.bilgi-satir:last-child{border-bottom:none}
.bilgi-k{color:var(--m2)}
.bilgi-v{font-weight:700;color:var(--m);font-family:'Courier New',monospace}
.f-grup{margin-bottom:14px}
.f-et{display:block;font-size:12.5px;font-weight:700;margin-bottom:5px}
.f-alan{width:100%;padding:10px 12px;border:1.5px solid var(--kenar);border-radius:var(--r);font-size:13.5px;font-family:inherit;color:var(--m);background:var(--bg);outline:none;transition:border-color .15s}
.f-alan:focus{border-color:var(--t);box-shadow:0 0 0 4px rgba(249,115,22,.1);background:#fff}
.btn{width:100%;padding:12px;background:var(--t);color:#fff;border:none;border-radius:var(--r);font-size:15px;font-weight:700;font-family:inherit;cursor:pointer;transition:all .15s;margin-top:4px}
.btn:hover{background:var(--t-k);transform:translateY(-1px);box-shadow:0 6px 16px rgba(249,115,22,.4)}
.alt-link{text-align:center;margin-top:14px;font-size:12.5px;color:var(--m2)}
.alt-link a{color:var(--t);font-weight:600;text-decoration:none}
@media(max-width:640px){.sol{display:none}.sag{padding:20px}}
</style>
</head>
<body>
<div class="sol">
  <div class="sol-bg"></div><div class="sol-grid"></div>
  <div class="sol-ic">
    <div class="sol-logo">🚚</div>
    <div class="sol-bas">Müşteri Portalı</div>
    <div class="sol-alt">Siparişlerinizi ve stok durumunuzu gerçek zamanlı takip edin.</div>
    <div class="ozellik">
      <div class="oz"><div class="oz-i">🚚</div><div><div class="oz-a">İrsaliye Takibi</div><div class="oz-b">Adım adım teslimat durumu</div></div></div>
      <div class="oz"><div class="oz-i">📦</div><div><div class="oz-a">Stok Durumu</div><div class="oz-b">Size özel stok görünürlüğü</div></div></div>
      <div class="oz"><div class="oz-i">📋</div><div><div class="oz-a">Sipariş Geçmişi</div><div class="oz-b">Tüm siparişleriniz</div></div></div>
    </div>
  </div>
</div>

<div class="sag">
  <div class="kart">
    <div class="kart-logo">
      <div class="kl-ikon">J</div>
      <div class="kl-marka">jetone<span>.pro</span></div>
    </div>
    <h2>Müşteri Girişi</h2>
    <div class="kart-alt">musteri.jetone.pro</div>

    <div class="bilgi-kutu">
      <div class="bilgi-kutu-bas">📋 Örnek Giriş Bilgileri</div>
      <div class="bilgi-satir"><span class="bilgi-k">ABC Plastik</span><span class="bilgi-v">ABC-001</span></div>
      <div class="bilgi-satir"><span class="bilgi-k">Demir Endüstri</span><span class="bilgi-v">DEF-002</span></div>
      <div class="bilgi-satir"><span class="bilgi-k">XYZ Makine</span><span class="bilgi-v">XYZ-003</span></div>
      <div class="bilgi-satir"><span class="bilgi-k">Şifre (hepsi)</span><span class="bilgi-v">Musteri2024!</span></div>
    </div>

    <?php if ($hata): ?><div class="hata">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>

    <form method="POST">
      <div class="f-grup">
        <label class="f-et">Müşteri Kodu / Kullanıcı Adı</label>
        <input type="text" name="kullanici_adi" class="f-alan"
               placeholder="ABC-001"
               value="<?php echo htmlspecialchars($_POST['kullanici_adi'] ?? ''); ?>"
               required autofocus autocomplete="username">
      </div>
      <div class="f-grup">
        <label class="f-et">Şifre</label>
        <input type="password" name="sifre" class="f-alan"
               placeholder="••••••••" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn">🔐 Portala Giriş Yap</button>
    </form>
    <div class="alt-link">
      <a href="<?php echo BASE_URL; ?>/giris.php">← ERP Yönetim Paneli</a>
    </div>
  </div>
</div>
</body>
</html>
