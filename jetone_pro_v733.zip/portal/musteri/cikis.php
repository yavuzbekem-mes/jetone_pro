<?php
session_name("JETONE_MUSTERI"); session_start();
session_destroy();
header('Location: /jetone_pro/portal/musteri/giris.php');
exit;
