<?php
require_once __DIR__.'/core/config.php';
require_once __DIR__.'/core/db.php';
require_once __DIR__.'/core/auth.php';
Auth::zorunlu();

$tablolar = [
    'duyurular' => "CREATE TABLE IF NOT EXISTS `duyurular` (
        `id`            INT AUTO_INCREMENT PRIMARY KEY,
        `baslik`        VARCHAR(300) NOT NULL,
        `icerik`        TEXT NOT NULL,
        `hedef`         ENUM('herkese','departman','kadro') DEFAULT 'herkese',
        `hedef_ids`     VARCHAR(500) DEFAULT NULL,
        `oncelik`       ENUM('normal','onemli','acil') DEFAULT 'normal',
        `baslangic`     DATE DEFAULT NULL,
        `bitis`         DATE DEFAULT NULL,
        `aktif`         TINYINT(1) DEFAULT 1,
        `olusturan_id`  INT DEFAULT NULL,
        `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
        `guncelleme`    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_aktif (aktif)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'duyuru_okunanlar' => "CREATE TABLE IF NOT EXISTS `duyuru_okunanlar` (
        `id`            INT AUTO_INCREMENT PRIMARY KEY,
        `duyuru_id`     INT NOT NULL,
        `portal_kul_id` INT NOT NULL,
        `okunma`        DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_duyuru_kul (duyuru_id, portal_kul_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'performans_degerlendirme' => "CREATE TABLE IF NOT EXISTS `performans_degerlendirme` (
        `id`                INT AUTO_INCREMENT PRIMARY KEY,
        `personel_id`       INT NOT NULL,
        `degerlendiren`     VARCHAR(200) DEFAULT NULL,
        `deg_bolum`         VARCHAR(200) DEFAULT NULL,
        `deg_unvan`         VARCHAR(200) DEFAULT NULL,
        `degerlendirme_tarihi` DATE NOT NULL,
        `k11` TINYINT DEFAULT NULL, `k12` TINYINT DEFAULT NULL,
        `k13` TINYINT DEFAULT NULL, `k14` TINYINT DEFAULT NULL,
        `k15` TINYINT DEFAULT NULL, `k16` TINYINT DEFAULT NULL,
        `k17` TINYINT DEFAULT NULL, `k18` TINYINT DEFAULT NULL,
        `d21` TINYINT DEFAULT NULL, `d22` TINYINT DEFAULT NULL,
        `d23` TINYINT DEFAULT NULL, `d24` TINYINT DEFAULT NULL,
        `d25` TINYINT DEFAULT NULL, `d26` TINYINT DEFAULT NULL,
        `d27` TINYINT DEFAULT NULL, `d28` TINYINT DEFAULT NULL,
        `d29` TINYINT DEFAULT NULL, `d210` TINYINT DEFAULT NULL,
        `d211` TINYINT DEFAULT NULL,
        `t31` TINYINT DEFAULT NULL, `t32` TINYINT DEFAULT NULL,
        `t33` TINYINT DEFAULT NULL, `t34` TINYINT DEFAULT NULL,
        `t35` TINYINT DEFAULT NULL, `t36` TINYINT DEFAULT NULL,
        `toplam_k` TINYINT DEFAULT NULL, `toplam_d` TINYINT DEFAULT NULL,
        `toplam_t` TINYINT DEFAULT NULL, `genel_toplam` TINYINT DEFAULT NULL,
        `firma_adi` VARCHAR(200) DEFAULT NULL,
        `bolum` VARCHAR(200) DEFAULT NULL, `unvan` VARCHAR(200) DEFAULT NULL,
        `hazirlayan` VARCHAR(200) DEFAULT NULL, `onaylayan` VARCHAR(200) DEFAULT NULL,
        `kaydeden_id` INT DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `guncelleme` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_personel (personel_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'anket_yanitlar' => "CREATE TABLE IF NOT EXISTS `anket_yanitlar` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `portal_kul_id` INT DEFAULT NULL, `anonim` TINYINT(1) DEFAULT 1,
        `ad_soyad` VARCHAR(200) DEFAULT NULL, `departman` VARCHAR(200) DEFAULT NULL,
        `a1` TINYINT DEFAULT NULL, `a2` TINYINT DEFAULT NULL, `a3` TINYINT DEFAULT NULL,
        `a4` TINYINT DEFAULT NULL, `a5` TINYINT DEFAULT NULL, `a6` TINYINT DEFAULT NULL, `a7` TINYINT DEFAULT NULL,
        `b8` TINYINT DEFAULT NULL, `b9` TINYINT DEFAULT NULL, `b10` TINYINT DEFAULT NULL,
        `b11` TINYINT DEFAULT NULL, `b12` TINYINT DEFAULT NULL, `b13` TINYINT DEFAULT NULL,
        `b14` TINYINT DEFAULT NULL, `b15` TINYINT DEFAULT NULL, `b16` TINYINT DEFAULT NULL,
        `b17` TINYINT DEFAULT NULL, `b18` TINYINT DEFAULT NULL, `b19` TINYINT DEFAULT NULL,
        `b20` TINYINT DEFAULT NULL, `b21` TINYINT DEFAULT NULL, `b22` TINYINT DEFAULT NULL, `b23` TINYINT DEFAULT NULL,
        `c24` TINYINT DEFAULT NULL, `c25` TINYINT DEFAULT NULL, `c26` TINYINT DEFAULT NULL,
        `c27` TINYINT DEFAULT NULL, `c28` TINYINT DEFAULT NULL, `c29` TINYINT DEFAULT NULL, `c30` TINYINT DEFAULT NULL,
        `mutlu1` VARCHAR(500) DEFAULT NULL, `mutlu2` VARCHAR(500) DEFAULT NULL, `mutlu3` VARCHAR(500) DEFAULT NULL,
        `sikayet1` VARCHAR(500) DEFAULT NULL, `sikayet2` VARCHAR(500) DEFAULT NULL, `sikayet3` VARCHAR(500) DEFAULT NULL,
        `genel_oneri` TEXT DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_portal (portal_kul_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'ihtar_tutanaklar' => "CREATE TABLE IF NOT EXISTS `ihtar_tutanaklar` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `tutanak_no` VARCHAR(30) NOT NULL UNIQUE,
        `personel_id` INT NOT NULL, `ihtar_tarihi` DATE NOT NULL,
        `teblig_eden` VARCHAR(200) DEFAULT NULL, `sabit` VARCHAR(200) DEFAULT NULL,
        `nedenler` TEXT DEFAULT NULL, `diger_neden` VARCHAR(500) DEFAULT NULL,
        `savunma` TEXT DEFAULT NULL, `karar` TEXT DEFAULT NULL,
        `savunma_tarihi` DATETIME DEFAULT NULL,
        `ik_sorumlu` VARCHAR(200) DEFAULT NULL, `fabrika_mudur` VARCHAR(200) DEFAULT NULL,
        `kaydeden_id` INT DEFAULT NULL,
        `bolum` VARCHAR(200) DEFAULT NULL, `kadro` VARCHAR(200) DEFAULT NULL, `unvan` VARCHAR(200) DEFAULT NULL,
        `durum` ENUM('bekliyor','savunma_alindi','kapatildi') DEFAULT 'bekliyor',
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `guncelleme` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_personel (personel_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'yemek_menuler' => "CREATE TABLE IF NOT EXISTS `yemek_menuler` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `tarih` DATE NOT NULL, `ogun` ENUM('sabah','oglen','aksam') DEFAULT 'oglen',
        `yemek1` VARCHAR(300) DEFAULT NULL, `yemek2` VARCHAR(300) DEFAULT NULL,
        `yemek3` VARCHAR(300) DEFAULT NULL, `yemek4` VARCHAR(300) DEFAULT NULL,
        `corba` VARCHAR(300) DEFAULT NULL, `tatli` VARCHAR(300) DEFAULT NULL,
        `notlar` VARCHAR(500) DEFAULT NULL, `kalori` INT DEFAULT NULL,
        `olusturan_id` INT DEFAULT NULL, `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_tarih_ogun (tarih, ogun),
        INDEX idx_tarih (tarih)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'yemek_puanlar' => "CREATE TABLE IF NOT EXISTS `yemek_puanlar` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `menu_id` INT NOT NULL, `portal_kul_id` INT NOT NULL,
        `puan` TINYINT NOT NULL, `yorum` VARCHAR(300) DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_menu_kul (menu_id, portal_kul_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

echo '<style>body{font-family:monospace;padding:20px;background:#F8FAFC}
.ok{background:#D1FAE5;color:#065F46;padding:8px 14px;border-radius:8px;margin:4px 0;display:block}
.err{background:#FEE2E2;color:#991B1B;padding:8px 14px;border-radius:8px;margin:4px 0;display:block}
.skip{background:#F3F4F6;color:#6B7280;padding:8px 14px;border-radius:8px;margin:4px 0;display:block}
</style>';
echo '<h2 style="margin-bottom:16px">🔧 Eksik Tablolar Oluşturuluyor</h2>';

foreach ($tablolar as $tablo => $sql) {
    // Tablo var mı?
    $varmi = $db->query("SHOW TABLES LIKE '$tablo'")->fetchColumn();
    if ($varmi) {
        echo "<span class='skip'>⏭ $tablo — zaten var, atlandı</span>";
        continue;
    }
    try {
        $db->exec($sql);
        echo "<span class='ok'>✅ $tablo — oluşturuldu</span>";
    } catch (Throwable $e) {
        echo "<span class='err'>❌ $tablo — HATA: {$e->getMessage()}</span>";
    }
}

echo '<br><div style="background:#D1FAE5;color:#065F46;padding:16px;border-radius:10px;font-size:14px;font-weight:700">
  ✅ Tamamlandı! Sayfayı kapatabilirsiniz.
</div>';
// portal_kullanicilari eksik kolonlar
// sifre_degistirildi kolonu ekle - IF NOT EXISTS yerine manuel kontrol
$col_check = $db->query("SHOW COLUMNS FROM portal_kullanicilari LIKE 'sifre_degistirildi'")->fetch();
if (!$col_check) {
    try {
        $db->exec("ALTER TABLE portal_kullanicilari ADD COLUMN sifre_degistirildi TINYINT(1) DEFAULT 0");
        echo "<span class='ok'>✅ portal_kullanicilari.sifre_degistirildi eklendi</span>";
    } catch (Throwable $e) {
        echo "<span class='err'>❌ sifre_degistirildi: " . $e->getMessage() . "</span>";
    }
} else {
    echo "<span class='skip'>⏭ sifre_degistirildi zaten var</span>";
}

// satin_alma_talepler - takip_eden kolonları
$col1 = $db->query("SHOW COLUMNS FROM satin_alma_talepler LIKE 'takip_eden_id'")->fetch();
if (!$col1) {
    try {
        $db->exec("ALTER TABLE satin_alma_talepler ADD COLUMN takip_eden_id INT DEFAULT NULL");
        $db->exec("ALTER TABLE satin_alma_talepler ADD COLUMN takip_eden_adi VARCHAR(150) DEFAULT NULL");
        echo "<span class='ok'>✅ satin_alma_talepler.takip_eden eklendi</span>";
    } catch (Throwable $e) { echo "<span class='err'>❌ takip_eden: ".$e->getMessage()."</span>"; }
} else { echo "<span class='skip'>⏭ takip_eden zaten var</span>"; }

// evraklar tablosuna gecerlilik alanları
$evrak_tbl = $db->query("SHOW TABLES LIKE 'evraklar'")->fetch();
if ($evrak_tbl) {
    $cols_to_add = [
        'gecerlilik_tarihi'    => 'DATE DEFAULT NULL',
        'hatirlatma_gun'       => 'INT DEFAULT NULL',
        'hatirlatma_gonderildi'=> 'TINYINT(1) DEFAULT 0',
    ];
    foreach ($cols_to_add as $kolon => $tanim) {
        $chk = $db->query("SHOW COLUMNS FROM evraklar LIKE '$kolon'")->fetch();
        if (!$chk) {
            try { $db->exec("ALTER TABLE evraklar ADD COLUMN $kolon $tanim");
                  echo "<span class='ok'>✅ evraklar.$kolon eklendi</span>"; }
            catch (Throwable $e) { echo "<span class='err'>❌ evraklar.$kolon: ".$e->getMessage()."</span>"; }
        } else { echo "<span class='skip'>⏭ evraklar.$kolon zaten var</span>"; }
    }
}

// sozlesmeler.teklif_id NOT NULL → NULL yap
try {
    $db->exec("ALTER TABLE sozlesmeler MODIFY teklif_id INT DEFAULT NULL");
    echo "<span class='ok'>✅ sozlesmeler.teklif_id NULL yapıldı</span>";
} catch (Throwable $e) {
    echo "<span class='skip'>⏭ sozlesmeler.teklif_id: " . $e->getMessage() . "</span>";
}

echo '<br><a href="panel.php" style="display:inline-block;padding:12px 24px;background:#F97316;color:#fff;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px">→ ERP Paneline Dön</a>';
