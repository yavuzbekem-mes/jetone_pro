-- DB'deki yolları fiziksel klasörle eşleştir
UPDATE `dokuman_listesi` 
SET `dok_yol` = REPLACE(`dok_yol`, 'kys_dokumanlar/', 'kys_dökümanlar/')
WHERE `dok_yol` LIKE 'kys_dokumanlar/%';

-- Kontrol
SELECT id, dok_yol FROM dokuman_listesi WHERE dok_yol LIKE 'kys_dokumanlar/%' LIMIT 5;
SELECT id, dok_yol FROM dokuman_listesi WHERE dok_yol LIKE 'kys_dökümanlar/%' LIMIT 5;
