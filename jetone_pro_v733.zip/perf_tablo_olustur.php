<?php
require_once __DIR__.'/core/config.php';
require_once __DIR__.'/core/db.php';
require_once __DIR__.'/core/auth.php';
Auth::zorunlu();

$sql = "CREATE TABLE IF NOT EXISTS `performans_degerlendirme` (
    `id`                INT AUTO_INCREMENT PRIMARY KEY,
    `personel_id`       INT NOT NULL,
    `degerlendiren`     VARCHAR(200) DEFAULT NULL,
    `deg_bolum`         VARCHAR(200) DEFAULT NULL,
    `deg_unvan`         VARCHAR(200) DEFAULT NULL,
    `degerlendirme_tarihi` DATE NOT NULL,
    `k11` TINYINT DEFAULT NULL, `k12` TINYINT DEFAULT NULL,
    `k13` TINYINT DEFAULT NULL, `k14` TINYINT DEFAULT NULL,
    `k15` TINYINT DEFAULT NULL, `k16` TINYINT DEFAULT NULL,
    `k17` TINYINT DEFAULT NULL, `k18` TINYINT DEFAULT NULL,
    `d21` TINYINT DEFAULT NULL, `d22` TINYINT DEFAULT NULL,
    `d23` TINYINT DEFAULT NULL, `d24` TINYINT DEFAULT NULL,
    `d25` TINYINT DEFAULT NULL, `d26` TINYINT DEFAULT NULL,
    `d27` TINYINT DEFAULT NULL, `d28` TINYINT DEFAULT NULL,
    `d29` TINYINT DEFAULT NULL, `d210` TINYINT DEFAULT NULL,
    `d211` TINYINT DEFAULT NULL,
    `t31` TINYINT DEFAULT NULL, `t32` TINYINT DEFAULT NULL,
    `t33` TINYINT DEFAULT NULL, `t34` TINYINT DEFAULT NULL,
    `t35` TINYINT DEFAULT NULL, `t36` TINYINT DEFAULT NULL,
    `toplam_k`    TINYINT DEFAULT NULL,
    `toplam_d`    TINYINT DEFAULT NULL,
    `toplam_t`    TINYINT DEFAULT NULL,
    `genel_toplam` TINYINT DEFAULT NULL,
    `firma_adi`   VARCHAR(200) DEFAULT NULL,
    `bolum`       VARCHAR(200) DEFAULT NULL,
    `unvan`       VARCHAR(200) DEFAULT NULL,
    `hazirlayan`  VARCHAR(200) DEFAULT NULL,
    `onaylayan`   VARCHAR(200) DEFAULT NULL,
    `kaydeden_id` INT DEFAULT NULL,
    `olusturma`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    `guncelleme`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_personel (personel_id),
    INDEX idx_tarih (degerlendirme_tarihi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

try {
    $db->exec($sql);
    echo '<div style="font-family:monospace;padding:20px;background:#D1FAE5;color:#065F46;border-radius:8px">✅ performans_degerlendirme tablosu oluşturuldu!</div>';
    echo '<br><a href="?sayfa=ik-perf-form" style="display:inline-block;margin-top:10px;padding:10px 20px;background:#F97316;color:#fff;border-radius:8px;text-decoration:none;font-weight:700">→ Performans Formuna Git</a>';
} catch (Throwable $e) {
    echo '<div style="font-family:monospace;padding:20px;background:#FEE2E2;color:#991B1B;border-radius:8px">❌ Hata: '.$e->getMessage().'</div>';
}
