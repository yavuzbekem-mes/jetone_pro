# Jetone.pro ERP

## Kurulum

### 1. Veritabanı Oluştur
```bash
mysql -u root -p < veritabani_olustur.sql
```

### 2. Veritabanı Bağlantısı
`core/db.php` dosyasını düzenle:
```php
$host            = 'localhost';
$veritabani_ismi = 'jetone_pro';
$kullanici_adi   = 'root';
$sifre           = '';
```

### 3. Config
`core/config.php` dosyasında BASE_URL ayarla:
```php
define('BASE_URL', 'http://localhost/jetone_pro');
```

### 4. İlk Giriş
- URL: `http://localhost/jetone_pro/giris.php`
- E-posta: `admin@jetone.pro`
- Şifre: `password` (İlk girişten sonra değiştir)

## Klasör Yapısı
```
jetone_pro/
├── core/           Çekirdek — DB, Auth, Config
├── paylasilan/     Ortak CSS/JS/Bileşenler
├── bolumler/       ERP modülleri (ik, satis, uretim...)
├── ayarlar/        Sistem ayarları & entegrasyonlar
├── portal/         Personel & Müşteri portalları
├── raporlar/
├── entegrasyonlar/
├── guvenlik/
└── veritabani_olustur.sql
```

## Entegrasyonlar
Panel → Ayarlar → Entegrasyonlar üzerinden yapılandırın:
- **Logo Tiger (TIGERDB)**: SQL Server bağlantısı
- **MES**: Üretim takip sistemi
- **Logo REST API**: REST API entegrasyonu
- **SMTP**: E-posta servisi

## Portaller
- **Personel Portalı**: `/portal/personel/giris.php`
- **Müşteri Portalı**: `/portal/musteri/giris.php`

Portal kullanıcıları: Panel → Ayarlar → Portal Kullanıcıları
