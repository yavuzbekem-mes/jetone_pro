<?php
/**
 * Kullanıcı Profili
 * kullanici-profil.php (panel.php üzerinden çalışır)
 */
Auth::zorunlu();
$oturum_kul = Auth::kullanici();

// ID belirtilmişse o kullanıcıyı göster (sadece süper admin)
$hedef_id = (int)($_GET['id'] ?? 0);
$super_adm = ((int)($oturum_kul['rol_id'] ?? 0) === 1);

if ($hedef_id && $hedef_id !== (int)$oturum_kul['id'] && !$super_adm) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}
$profil_id = ($hedef_id && $super_adm) ? $hedef_id : (int)$oturum_kul['id'];
$kendi_profili = ($profil_id === (int)$oturum_kul['id']);

// Kullanıcı verisini çek
try {
    $stmt = $db->prepare("SELECT k.*, r.ad rol_adi, d.ad dept_adi
        FROM kullanicilar k
        LEFT JOIN roller r ON k.rol_id = r.id
        LEFT JOIN departmanlar d ON k.departman_id = d.id
        WHERE k.id = ? LIMIT 1");
    $stmt->execute([$profil_id]);
    $u = $stmt->fetch();
} catch (Exception $e) { $u = null; }

if (!$u) {
    // Kullanıcı DB'de yok ama session'da var - session bilgisinden oluştur
    $u = [
        'id'                => $profil_id,
        'ad'                => $oturum_kul['ad_soyad'] ?? 'Kullanıcı',
        'soyad'             => '',
        'email'             => $oturum_kul['email'] ?? '',
        'rol_adi'           => '—',
        'dept_adi'          => null,
        'pozisyon'          => null,
        'telefon'           => null,
        'durum'             => 1,
        'son_giris'         => null,
        'olusturma'         => null,
        'rol_id'            => $oturum_kul['rol_id'] ?? 0,
        'sifre_degistirildi'=> 1,
    ];
}

// Aktivite logları
try {
    $loglar = $db->prepare("SELECT * FROM sistem_loglar WHERE kullanici_id=? ORDER BY olusturma DESC LIMIT 20");
    $loglar->execute([$profil_id]);
    $loglar = $loglar->fetchAll();
} catch (Exception $e) { $loglar = []; }

// POST — Profil güncelle veya şifre değiştir
$basari = $hata = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $kendi_profili) {
    $islem = $_POST['_islem'] ?? '';
    try {
        if ($islem === 'profil_guncelle') {
            $db->prepare("UPDATE kullanicilar SET ad=?,soyad=?,telefon=?,pozisyon=? WHERE id=?")
               ->execute([
                   trim($_POST['ad']       ?? ''),
                   trim($_POST['soyad']    ?? ''),
                   trim($_POST['telefon']  ?? '') ?: null,
                   trim($_POST['pozisyon'] ?? '') ?: null,
                   $profil_id,
               ]);
            // Session güncelle
            $_SESSION['kullanici']['ad_soyad'] = trim($_POST['ad']).' '.trim($_POST['soyad']);
            $basari = 'Profil güncellendi.';
            $stmt2=$db->prepare("SELECT k.*, r.ad rol_adi, d.ad dept_adi FROM kullanicilar k LEFT JOIN roller r ON k.rol_id=r.id LEFT JOIN departmanlar d ON k.departman_id=d.id WHERE k.id=? LIMIT 1");
            $stmt2->execute([$profil_id]); $u2=$stmt2->fetch(); if($u2) $u=$u2;

        } elseif ($islem === 'sifre_degistir') {
            $mevcut  = $_POST['mevcut_sifre']  ?? '';
            $yeni    = $_POST['yeni_sifre']    ?? '';
            $tekrar  = $_POST['yeni_tekrar']   ?? '';

            if (!$mevcut || !$yeni || !$tekrar) {
                $hata = 'Tüm şifre alanları zorunludur.';
            } elseif ($yeni !== $tekrar) {
                $hata = 'Yeni şifreler eşleşmiyor.';
            } elseif (strlen($yeni) < 8) {
                $hata = 'Şifre en az 8 karakter olmalıdır.';
            } else {
                $row = $db->prepare("SELECT sifre_hash FROM kullanicilar WHERE id=? LIMIT 1");
                $row->execute([$profil_id]); $row = $row->fetch();
                if (!$row || !password_verify($mevcut, $row['sifre_hash'])) {
                    $hata = 'Mevcut şifre yanlış.';
                } else {
                    $db->prepare("UPDATE kullanicilar SET sifre_hash=?, sifre_degistirildi=1 WHERE id=?")
                       ->execute([password_hash($yeni, PASSWORD_DEFAULT), $profil_id]);
                    $_SESSION['kullanici']['sifre_degistirildi'] = 1;
                    $basari = 'Şifre başarıyla değiştirildi.';
                    Auth::logKaydet($profil_id, 'sifre_degistir', 'profil', null, 'Şifre değiştirildi');
                }
            }
        }
    } catch (Exception $e) { $hata = $e->getMessage(); }
}

$aktif_sekme = $_GET['sekme'] ?? 'genel';
?>

<div class="s-bar">
  <div style="display:flex;align-items:center;gap:14px">
    <!-- Avatar -->
    <div style="width:54px;height:54px;border-radius:14px;background:linear-gradient(135deg,var(--t),var(--t-k));display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;flex-shrink:0">
      <?php echo mb_strtoupper(mb_substr($u['ad'],0,1).mb_substr($u['soyad']??'',0,1)); ?>
    </div>
    <div>
      <div style="display:flex;align-items:center;gap:8px">
        <h1 class="s-bas"><?php echo htmlspecialchars($u['ad'].' '.($u['soyad']??'')); ?></h1>
        <span class="roz" style="background:<?php echo $u['durum']?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo $u['durum']?'#0A8F4E':'#F04438'; ?>">
          <?php echo $u['durum'] ? '✓ Aktif' : '✗ Pasif'; ?>
        </span>
        <?php if (($u['sifre_degistirildi']??1)==0): ?>
        <span class="roz" style="background:#FEF0C7;color:#B45309">⚠ İlk Şifre Kullanılıyor</span>
        <?php endif; ?>
      </div>
      <div style="font-size:13px;color:var(--m2)">
        <?php echo htmlspecialchars($u['rol_adi']??'—'); ?>
        <?php if ($u['dept_adi']): ?> · <?php echo htmlspecialchars($u['dept_adi']); ?><?php endif; ?>
        <?php if ($u['pozisyon']): ?> · <?php echo htmlspecialchars($u['pozisyon']); ?><?php endif; ?>
      </div>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-left:auto">
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ayarlar&sekme=kullanici" class="btn btn-b">← Kullanıcılar</a>
    <?php if ($kendi_profili): ?>
    <a href="<?php echo BASE_URL; ?>/cikis.php" class="btn btn-b">🚪 Çıkış</a>
    <?php endif; ?>
  </div>
</div>

<div class="s-body">

<?php if ($basari): ?><div style="background:#D1FADF;border:1px solid #86EFAC;color:#0A8F4E;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">✅ <?php echo htmlspecialchars($basari); ?></div><?php endif; ?>
<?php if ($hata): ?><div style="background:#FEE4E2;border:1px solid #F04438;color:#F04438;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:600">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>

<!-- Sekme nav -->
<div style="display:flex;gap:2px;background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:5px;margin-bottom:16px">
  <button onclick="profilSekme('genel',this)" id="ptab-genel"
    class="ptab <?php echo $aktif_sekme==='genel'?'aktif':''; ?>"
    style="padding:7px 14px;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;background:<?php echo $aktif_sekme==='genel'?'var(--t)':'none'; ?>;color:<?php echo $aktif_sekme==='genel'?'#fff':'var(--m2)'; ?>;transition:all .15s">
    👤 Genel Bilgiler
  </button>
  <?php if ($kendi_profili): ?>
  <button onclick="profilSekme('sifre',this)" id="ptab-sifre"
    style="padding:7px 14px;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;background:none;color:var(--m2);transition:all .15s">
    🔑 Şifre Değiştir
  </button>
  <?php endif; ?>
  <button onclick="profilSekme('aktivite',this)" id="ptab-aktivite"
    style="padding:7px 14px;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;background:none;color:var(--m2);transition:all .15s">
    📋 Aktivite Geçmişi
  </button>
</div>

<!-- ── Genel Bilgiler ── -->
<div id="pb-genel">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <!-- Bilgiler -->
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📋 Hesap Bilgileri</div></div>
      <div style="display:flex;flex-direction:column;gap:0">
        <?php
        $bilgiler = [
          'E-posta'        => $u['email'],
          'Rol'            => $u['rol_adi'] ?? '—',
          'Departman'      => $u['dept_adi'] ?? '—',
          'Pozisyon'       => $u['pozisyon'] ?? '—',
          'Son Giriş'      => $u['son_giris'] ? date('d.m.Y H:i',strtotime($u['son_giris'])) : 'Henüz giriş yapılmadı',
          'Kayıt Tarihi'   => ($u['olusturma'] ?? null) ? date('d.m.Y',strtotime($u['olusturma'])) : '—',
          'Şifre Durumu'   => ($u['sifre_degistirildi']??1) ? '✓ Kullanıcı değiştirdi' : '⚠ İlk şifre kullanılıyor',
        ];
        foreach ($bilgiler as $k=>$v): ?>
        <div style="display:flex;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--kenar);font-size:13px">
          <span style="width:130px;flex-shrink:0;color:var(--m2)"><?php echo $k; ?></span>
          <span style="font-weight:600;color:var(--m)"><?php echo htmlspecialchars($v); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Profil düzenle -->
    <?php if ($kendi_profili): ?>
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">✏️ Profili Düzenle</div></div>
      <form method="POST">
        <input type="hidden" name="_islem" value="profil_guncelle">
        <div class="form-grid-2">
          <div class="form-grup">
            <label class="form-et">Ad <span class="zorunlu">*</span></label>
            <input type="text" class="form-alan" name="ad" value="<?php echo htmlspecialchars($u['ad']); ?>" required>
          </div>
          <div class="form-grup">
            <label class="form-et">Soyad</label>
            <input type="text" class="form-alan" name="soyad" value="<?php echo htmlspecialchars($u['soyad']??''); ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">Telefon</label>
            <input type="text" class="form-alan" name="telefon" value="<?php echo htmlspecialchars($u['telefon']??''); ?>" placeholder="05xx xxx xx xx">
          </div>
          <div class="form-grup">
            <label class="form-et">Pozisyon</label>
            <input type="text" class="form-alan" name="pozisyon" value="<?php echo htmlspecialchars($u['pozisyon']??''); ?>" placeholder="Unvan">
          </div>
        </div>
        <button type="submit" class="btn btn-t" style="width:100%;margin-top:8px">💾 Güncelle</button>
      </form>
    </div>
    <?php else: ?>
    <!-- Süper admin başka kullanıcıyı görüntülüyor -->
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">⚙️ Yönetici İşlemleri</div></div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button onclick="erpSifreResetProfil(<?php echo $u['id']; ?>,'<?php echo htmlspecialchars($u['email']); ?>')"
          style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--r);border:1.5px solid var(--kenar);background:var(--bg);cursor:pointer;font-family:inherit;text-align:left;width:100%">
          <span style="font-size:18px">🔑</span>
          <div><div style="font-size:13px;font-weight:700">Şifre Sıfırla</div><div style="font-size:11px;color:var(--m2)">Yeni geçici şifre oluştur</div></div>
        </button>
        <button onclick="erpToggleProfil(<?php echo $u['id']; ?>,<?php echo $u['durum']; ?>)"
          style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--r);border:1.5px solid <?php echo $u['durum']?'#FCA5A5':'#86EFAC'; ?>;background:<?php echo $u['durum']?'#FFF0F0':'#F0FFF4'; ?>;cursor:pointer;font-family:inherit;text-align:left;width:100%">
          <span style="font-size:18px"><?php echo $u['durum']?'🔒':'🔓'; ?></span>
          <div><div style="font-size:13px;font-weight:700;color:<?php echo $u['durum']?'#F04438':'#12B76A'; ?>"><?php echo $u['durum']?'Hesabı Kapat':'Hesabı Aç'; ?></div></div>
        </button>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- ── Şifre Değiştir ── -->
<div id="pb-sifre" style="display:none">
  <div style="max-width:440px">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🔑 Şifre Değiştir</div></div>
      <form method="POST">
        <input type="hidden" name="_islem" value="sifre_degistir">
        <div class="form-grup">
          <label class="form-et">Mevcut Şifre</label>
          <input type="password" class="form-alan" name="mevcut_sifre" required autocomplete="current-password">
        </div>
        <div class="form-grup">
          <label class="form-et">Yeni Şifre <span style="font-size:11px;color:var(--m2);font-weight:400">(min 8 karakter)</span></label>
          <input type="password" class="form-alan" name="yeni_sifre" id="yeniSifre" required autocomplete="new-password" oninput="sifreGuc(this.value)">
          <div id="sifreGucBar" style="height:4px;background:var(--kenar);border-radius:2px;margin-top:5px;overflow:hidden"><div id="sifreGucIc" style="height:100%;width:0;transition:all .3s;border-radius:2px"></div></div>
          <div id="sifreGucEt" style="font-size:11px;margin-top:2px;color:var(--m3)"></div>
        </div>
        <div class="form-grup">
          <label class="form-et">Yeni Şifre Tekrar</label>
          <input type="password" class="form-alan" name="yeni_tekrar" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn btn-t" style="width:100%">🔒 Şifreyi Güncelle</button>
      </form>
    </div>
  </div>
</div>

<!-- ── Aktivite Geçmişi ── -->
<div id="pb-aktivite" style="display:none">
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">📋 Son Aktiviteler</div></div>
    <?php if (empty($loglar)): ?>
    <div style="padding:24px;text-align:center;color:var(--m2)">Aktivite kaydı bulunamadı</div>
    <?php else: ?>
    <table class="tablo">
      <thead><tr><th>Tarih</th><th>İşlem</th><th>Modül</th><th>IP</th><th>Durum</th></tr></thead>
      <tbody>
      <?php foreach ($loglar as $l): ?>
      <tr>
        <td style="font-size:12px;color:var(--m2)"><?php echo $l['olusturma'] ? date('d.m.Y H:i',strtotime($l['olusturma'])) : '—'; ?></td>
        <td style="font-size:13px">
          <?php echo htmlspecialchars($l['aciklama'] ?? ($l['islem'] ?? '—')); ?>
        </td>
        <td><span class="roz"><?php echo htmlspecialchars($l['modul'] ?? '—'); ?></span></td>
        <td style="font-size:11px;color:var(--m3);font-family:monospace"><?php echo htmlspecialchars($l['ip'] ?? '—'); ?></td>
        <td><span class="roz" style="background:<?php echo ($l['durum']??'basarili')==='basarili'?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo ($l['durum']??'basarili')==='basarili'?'#0A8F4E':'#F04438'; ?>"><?php echo ucfirst($l['durum']??'basarili'); ?></span></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

</div>

<script>
function profilSekme(id, el) {
    ['genel','sifre','aktivite'].forEach(function(s){
        var b = document.getElementById('pb-'+s);
        var t = document.getElementById('ptab-'+s);
        if (b) b.style.display = s===id ? 'block' : 'none';
        if (t) { t.style.background = s===id?'var(--t)':'none'; t.style.color = s===id?'#fff':'var(--m2)'; }
    });
}

function sifreGuc(v) {
    var p = 0;
    if (v.length>=8) p++;
    if (/[A-Z]/.test(v)) p++;
    if (/[0-9]/.test(v)) p++;
    if (/[^A-Za-z0-9]/.test(v)) p++;
    var renkler=['','#F04438','#F79009','#F79009','#12B76A'];
    var et=['','Zayıf','Orta','İyi','Güçlü'];
    var bar = document.getElementById('sifreGucIc');
    var etEl = document.getElementById('sifreGucEt');
    if (bar) { bar.style.width=(p*25)+'%'; bar.style.background=renkler[p]||'#eee'; }
    if (etEl) { etEl.textContent=et[p]||''; etEl.style.color=renkler[p]||'#999'; }
}

function erpSifreResetProfil(id, email) {
    if (!confirm(email+' şifresi sıfırlansın mı?')) return;
    JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',{islem:'sifre_sifirla',erp_kul_id:id})
        .then(function(r){ if(r.ok) alert('✅ Yeni şifre: '+r.yeni_sifre); else JT.bildirim(r.hata,'hata'); });
}
function erpToggleProfil(id, mevcut) {
    if (!confirm(mevcut?'Hesap kapatılsın mı?':'Hesap açılsın mı?')) return;
    JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',{islem:'toggle_erisim',erp_kul_id:id})
        .then(function(r){ if(r.ok){JT.bildirim(r.mesaj,'basari');setTimeout(function(){location.reload();},800);}else JT.bildirim(r.hata,'hata'); });
}
</script>
