<?php
// Output buffer en başta — hiçbir şey sızmaz
ob_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(0);

// Core yükle
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

// Tiger bağlantısı opsiyonel — hata verirse devam et
$tigerdb_pdo = null;
try {
    require_once __DIR__ . '/baglanlogo.php';
} catch(Throwable $e) { /* Tiger yoksa devam */ }

// Her türlü output'u temizle, JSON header yaz
ob_clean();
header('Content-Type: application/json; charset=utf-8');

// Session
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['kullanici'])) {
    echo json_encode(['ok'=>false,'msg'=>'Oturum sona erdi.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false,'msg'=>'POST gerekli.']);
    exit;
}

$soru   = trim($_POST['soru'] ?? '');
$gecmis = json_decode($_POST['gecmis'] ?? '[]', true) ?: [];

if (!$soru) {
    echo json_encode(['ok'=>false,'msg'=>'Soru boş.']);
    exit;
}

// API key — önce DB'den, yoksa config'den
$api_key = '';
try {
    $r = $db->query("SELECT deger FROM sistem_ayarlari WHERE anahtar='claude_api_key' LIMIT 1")->fetch();
    $api_key = trim($r['deger'] ?? '');
} catch(Throwable $e) {}
if (empty($api_key)) $api_key = defined('CLAUDE_API_KEY') ? CLAUDE_API_KEY : '';
if (empty($api_key)) {
    echo json_encode(['ok'=>false,'msg'=>'API anahtarı tanımlanmamış. panel.php?sayfa=ayarlar-ai adresinden ekleyin.']);
    exit;
}

// ── Context Toplama ──────────────────────────────────────────────
$ctx = [];
$kul = $_SESSION['kullanici'];
$ctx[] = "Kullanıcı: " . ($kul['ad_soyad'] ?? $kul['email'] ?? 'Bilinmiyor');
$ctx[] = "Tarih/Saat: " . date('d.m.Y H:i');

$q = mb_strtolower($soru, 'UTF-8');
$is_sip  = preg_match('/sipari|satış|müşteri|musteri|order/u', $q);
$is_urt  = preg_match('/üretim|uretim|plan|hat|mps|enjek|montaj/u', $q);
$is_per  = preg_match('/personel|çalışan|calisan|izin|devam|ik\b|kişi/u', $q);
$is_stok = preg_match('/stok|malzeme|hammadde|hm\b|depo/u', $q);
$genel   = !($is_sip || $is_urt || $is_per || $is_stok);

// Sipariş
if ($is_sip || $genel) {
    try {
        $r = $db->query("SELECT COUNT(*) t, SUM(CASE WHEN sip_statu='Aktif' THEN 1 ELSE 0 END) a,
            SUM(CASE WHEN sip_statu='Aktif' THEN sip_miktar-sip_sevk_miktari ELSE 0 END) k,
            COUNT(DISTINCT musteri_firma_adi) m FROM siparis")->fetch(PDO::FETCH_ASSOC);
        if ($r) $ctx[] = "SİPARİŞ: Toplam {$r['t']}, Aktif {$r['a']}, Kalan ".number_format($r['k'],0,',','.')." adet, {$r['m']} müşteri.";

        $son = $db->query("SELECT musteri_firma_adi, sip_kodu, sip_baslik,
            sip_miktar-sip_sevk_miktari kalan, sip_teslim_tarihi
            FROM siparis WHERE sip_statu='Aktif' ORDER BY id DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);
        if ($son) {
            $ctx[] = "AKTİF SİPARİŞLER:\n" . implode("\n", array_map(fn($s)=>
                "{$s['musteri_firma_adi']} | {$s['sip_kodu']} | {$s['sip_baslik']} | Kalan:{$s['kalan']} | Teslim:{$s['sip_teslim_tarihi']}", $son));
        }
    } catch(Throwable $e) {}
}

// Üretim
if ($is_urt || $genel) {
    try {
        $r = $db->query("SELECT COUNT(*) t,
            SUM(durum='Devam Ediyor') devam, SUM(durum='Planlandı') planli,
            SUM(durum='Tamamlandı') tamam, SUM(kalan_miktar) kalan
            FROM mps_plan WHERE durum NOT IN('İptal','Iptal')")->fetch(PDO::FETCH_ASSOC);
        if ($r) $ctx[] = "ÜRETİM: {$r['t']} iş — {$r['devam']} devam, {$r['planli']} planlandı, {$r['tamam']} tamamlandı. Kalan: ".number_format($r['kalan'],0,',','.') ." adet.";

        $hatlar = $db->query("SELECT hat_kodu, COUNT(*) c, SUM(kalan_miktar) k
            FROM mps_plan WHERE durum NOT IN('İptal','Iptal','Tamamlandı')
            GROUP BY hat_kodu ORDER BY hat_kodu LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
        if ($hatlar) $ctx[] = "HATLAR:\n" . implode("\n", array_map(fn($h)=>
            "{$h['hat_kodu']}: {$h['c']} iş, ".number_format($h['k'],0,',','.')." kalan", $hatlar));
    } catch(Throwable $e) {}
}

// Personel
if ($is_per || $genel) {
    try {
        $r = $db->query("SELECT COUNT(*) t, SUM(durum='aktif') a, SUM(durum='izinli') i FROM personeller")->fetch(PDO::FETCH_ASSOC);
        if ($r) $ctx[] = "PERSONEL: {$r['t']} toplam, {$r['a']} aktif, {$r['i']} izinli.";
        $bugun = $db->query("SELECT COUNT(DISTINCT personel_id) FROM devam_kayitlari WHERE DATE(giris_saati)=CURDATE()")->fetchColumn();
        if ($bugun !== false) $ctx[] = "BUGÜN DEVAM: $bugun kişi.";
    } catch(Throwable $e) {}
}

// Stok (Tiger)
if ($is_stok && $tigerdb_pdo) {
    try {
        $kritik = $tigerdb_pdo->query("SELECT TOP 10 IT.CODE, IT.NAME,
            ISNULL(SUM(LV.ONHAND),0) stok
            FROM dbo.LG_222_ITEMS IT
            LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
            WHERE IT.STGRPCODE IN('Plastik HM','Masterbatch') AND IT.ACTIVE=0
            GROUP BY IT.CODE, IT.NAME HAVING ISNULL(SUM(LV.ONHAND),0)<500
            ORDER BY stok ASC")->fetchAll(PDO::FETCH_ASSOC);
        if ($kritik) $ctx[] = "KRİTİK STOK:\n" . implode("\n", array_map(fn($s)=>
            "{$s['CODE']} | {$s['NAME']} | {$s['stok']} kg", $kritik));
    } catch(Throwable $e) {}
}

$context = implode("\n\n", $ctx);

// ── Mesajlar ────────────────────────────────────────────────────
$msgs = [];
foreach (array_slice($gecmis, -8) as $g)
    if (!empty($g['role']) && !empty($g['content']))
        $msgs[] = ['role'=>$g['role'], 'content'=>$g['content']];
$msgs[] = ['role'=>'user', 'content'=>$soru];

$system = "Sen Jetone ERP sisteminin Türkçe yapay zeka asistanısın. Üretim, sipariş, stok ve personel yönetimi konusunda uzmansın.\nYanıtları kısa, net ve markdown formatında ver (tablo, liste kullan).\nBilmediğin şeyleri uydurmuyorsun.\n\nGÜNCEL VERİTABANI VERİLERİ:\n{$context}";

// ── API ─────────────────────────────────────────────────────────
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_POSTFIELDS     => json_encode([
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 1024,
        'system'     => $system,
        'messages'   => $msgs,
    ]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'x-api-key: ' . $api_key,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_SSL_VERIFYPEER => false, // Laragon localhost için
]);

$raw  = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($err) {
    echo json_encode(['ok'=>false,'msg'=>'CURL: '.$err]);
    exit;
}

$resp = json_decode($raw, true);
if ($code !== 200) {
    echo json_encode(['ok'=>false,'msg'=>'API ('.$code.'): '.($resp['error']['message']??$raw)]);
    exit;
}

echo json_encode(['ok'=>true,'cevap'=>$resp['content'][0]['text']??'']);
