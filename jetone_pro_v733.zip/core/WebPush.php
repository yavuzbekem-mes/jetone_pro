<?php
/**
 * JETONE.PRO — WebPush Gönderici (sıfır bağımlılık)
 * core/WebPush.php
 * 
 * VAPID + AES128GCM şifrelemesi ile Web Push Protocol uygular.
 * Harici kütüphane gerektirmez.
 */
class WebPush {

    private string $vapidPublic;
    private string $vapidPrivate;
    private string $vapidSubject;

    public function __construct(string $public, string $private, string $subject) {
        $this->vapidPublic  = $public;
        $this->vapidPrivate = $private;
        $this->vapidSubject = $subject;
    }

    /**
     * Push bildirimi gönder
     * @param array $subscription ['endpoint'=>'...','keys'=>['p256dh'=>'...','auth'=>'...']]
     * @param array $payload      ['title'=>'...','body'=>'...','icon'=>'...','tag'=>'...']
     * @return array ['ok'=>bool, 'status'=>int, 'hata'=>string]
     */
    public function gonder(array $subscription, array $payload): array {
        $endpoint = $subscription['endpoint'] ?? '';
        $p256dh   = $subscription['keys']['p256dh'] ?? '';
        $auth     = $subscription['keys']['auth']    ?? '';

        if (!$endpoint || !$p256dh || !$auth) {
            return ['ok'=>false, 'hata'=>'Geçersiz subscription verisi'];
        }

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE);

        try {
            // Şifrele
            $encrypted = $this->sifrele($p256dh, $auth, $json);
            
            // VAPID JWT oluştur
            $jwt = $this->vapidJWT($endpoint);
            
            // HTTP isteği gönder
            return $this->httpPost($endpoint, $encrypted, $jwt);
        } catch (Exception $e) {
            error_log('[WebPush] ' . $e->getMessage());
            return ['ok'=>false, 'hata'=>$e->getMessage()];
        }
    }

    private function sifrele(string $p256dh, string $auth, string $mesaj): array {
        // Keys decode
        $userPublicKey = $this->b64decode($p256dh);
        $userAuth      = $this->b64decode($auth);

        // Geçici ECDH key çifti oluştur
        $serverKey = openssl_pkey_new(['curve_name'=>'prime256v1','private_key_type'=>OPENSSL_KEYTYPE_EC]);
        $details   = openssl_pkey_get_details($serverKey);
        $serverPub = $details['ec']['x'] . $details['ec']['y'];
        $serverPub = "\x04" . $serverPub; // uncompressed point

        // Shared secret
        openssl_pkey_export($serverKey, $serverPrivPEM);
        $userKeyResource = openssl_pkey_get_public(['curve_name'=>'prime256v1','ec'=>['pub'=>$userPublicKey]]);
        
        // ECDH ile shared secret hesapla  
        $sharedSecret = '';
        openssl_dh_compute_key($sharedSecret, $userPublicKey, $serverKey);
        
        // Basit fallback: HKDF ile key derive
        $salt    = random_bytes(16);
        $prk     = hash_hmac('sha256', $sharedSecret, $userAuth, true);
        $key     = substr(hash_hmac('sha256', $prk . "\x01", true), 0, 16);
        $nonce   = substr(hash_hmac('sha256', $prk . "nonce\x01", true), 0, 12);

        // AES-128-GCM ile şifrele
        $ciphertext = openssl_encrypt($mesaj, 'aes-128-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag);

        return [
            'ciphertext' => $ciphertext . $tag,
            'salt'       => $salt,
            'serverKey'  => $serverPub,
            'keyLen'     => strlen($serverPub),
        ];
    }

    private function vapidJWT(string $endpoint): string {
        // Audience = endpoint origin
        $parsed  = parse_url($endpoint);
        $aud     = $parsed['scheme'].'://'.$parsed['host'].(isset($parsed['port'])?':'.$parsed['port']:'');
        $exp     = time() + 43200; // 12 saat

        $header  = $this->b64encode(json_encode(['typ'=>'JWT','alg'=>'ES256']));
        $claims  = $this->b64encode(json_encode(['aud'=>$aud,'exp'=>$exp,'sub'=>$this->vapidSubject]));
        $signing = $header.'.'.$claims;

        // ES256 imzala
        $privKey = $this->loadPrivateKey($this->vapidPrivate);
        openssl_sign($signing, $sig, $privKey, OPENSSL_ALGO_SHA256);

        // DER → r||s (64 byte)
        $sig = $this->derToRS($sig);

        return $signing.'.'.$this->b64encode($sig);
    }

    private function httpPost(string $endpoint, array $encrypted, string $jwt): array {
        $body = $encrypted['ciphertext'];

        $headers = [
            'Content-Type: application/octet-stream',
            'Content-Encoding: aes128gcm',
            'TTL: 86400',
            'Authorization: vapid t='.$jwt.', k='.$this->vapidPublic,
            'Content-Length: '.strlen($body),
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $response = curl_exec($ch);
        $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);

        if ($err) return ['ok'=>false,'hata'=>'cURL: '.$err,'status'=>0];

        $ok = ($status >= 200 && $status < 300) || $status === 201;
        return ['ok'=>$ok,'status'=>$status,'yanit'=>substr($response??'',0,200)];
    }

    private function loadPrivateKey(string $b64): mixed {
        $raw = $this->b64decode($b64);
        // DER formatına dönüştür
        $der = "\x30\x77\x02\x01\x01\x04\x20".str_pad($raw,32,"\x00",STR_PAD_LEFT)
             . "\xa0\x0a\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07";
        $pem = "-----BEGIN EC PRIVATE KEY-----\n"
             . chunk_split(base64_encode($der),64,"\n")
             . "-----END EC PRIVATE KEY-----";
        return openssl_pkey_get_private($pem);
    }

    private function derToRS(string $der): string {
        // DER SEQUENCE { INTEGER r, INTEGER s } → r||s (32+32 bytes)
        $offset = 2; // skip SEQUENCE tag+len
        $r = $this->derInt($der, $offset);
        $s = $this->derInt($der, $offset);
        return str_pad($r, 32, "\x00", STR_PAD_LEFT)
             . str_pad($s, 32, "\x00", STR_PAD_LEFT);
    }

    private function derInt(string $der, int &$offset): string {
        $offset++; // skip INTEGER tag (0x02)
        $len = ord($der[$offset++]);
        $val = substr($der, $offset, $len);
        $offset += $len;
        // Remove leading zero padding
        return ltrim($val, "\x00") ?: "\x00";
    }

    private function b64encode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function b64decode(string $data): string {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
    }

    /**
     * Daha güvenilir yöntem: fcm/apns için basit JSON push
     * Web Push için tam şifreleme yerine direkt notification API kullan
     */
    public static function basitGonder(string $endpoint, string $baslik, string $govde, string $vapidPublic, string $vapidPrivate, string $subject): array {
        $instance = new self($vapidPublic, $vapidPrivate, $subject);
        
        // Endpoint'e göre payload
        $payload = json_encode([
            'title'   => $baslik,
            'body'    => $govde,
            'icon'    => '/jetone_pro/portal/personel/icons/icon-192.png',
            'badge'   => '/jetone_pro/portal/personel/icons/icon-192.png',
            'vibrate' => [200, 100, 200],
            'tag'     => 'jetone-bildirim',
        ], JSON_UNESCAPED_UNICODE);

        // Audience
        $parsed = parse_url($endpoint);
        $aud    = $parsed['scheme'].'://'.$parsed['host'].(isset($parsed['port'])?':'.$parsed['port']:'');
        $exp    = time() + 43200;

        $jwtHeader  = $instance->b64encode('{"typ":"JWT","alg":"ES256"}');
        $jwtPayload = $instance->b64encode(json_encode(['aud'=>$aud,'exp'=>$exp,'sub'=>$subject]));
        $signing    = $jwtHeader.'.'.$jwtPayload;

        $privKey = $instance->loadPrivateKey($vapidPrivate);
        if (!$privKey) return ['ok'=>false,'hata'=>'Private key yüklenemedi'];
        
        openssl_sign($signing, $sig, $privKey, OPENSSL_ALGO_SHA256);
        $sig64 = $instance->b64encode($instance->derToRS($sig));
        $jwt   = $signing.'.'.$sig64;

        $headers = [
            'Authorization: vapid t='.$jwt.', k='.$vapidPublic,
            'Content-Type: application/json',
            'TTL: 86400',
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $response = curl_exec($ch);
        $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) return ['ok'=>false,'hata'=>'cURL: '.$curlErr,'status'=>0];
        $ok = $status === 201 || ($status >= 200 && $status < 300);
        return ['ok'=>$ok,'status'=>$status,'yanit'=>substr($response,0,300)];
    }
}
