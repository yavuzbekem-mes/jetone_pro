<?php
/**
 * Satınalma — ERP + Portal Bildirim Gönderici
 * core/satin-bildirim.php
 *
 * ERP bildirimler tablosuna yazar (tüm yöneticilere + talep eden)
 * Portal push bildirimi gönderir (personele)
 */

if (!function_exists('satinBildirimGonder')) {

require_once __DIR__ . '/push-gonder.php';

/**
 * @param int    $talep_id
 * @param string $tetikleyen   talep_olusturuldu | onayda | reddedildi | teklifte | siparisde | kismi_tedarik | tamamlandi
 * @param array  $ekstra       ['not'=>'...']
 */
function satinBildirimGonder(int $talep_id, string $tetikleyen, array $ekstra = []): void
{
    global $db;

    // Talep bilgilerini al — personel_id direkt + fallback JOIN
    try {
        $t = $db->prepare(
            "SELECT t.* FROM satin_alma_talepler t WHERE t.id = ? LIMIT 1"
        );
        $t->execute([$talep_id]);
        $talep = $t->fetch();
        if (!$talep) return;

        // per_id artık email ile bulunuyor (aşağıda)
    } catch (Throwable $e) { return; }

    $talep_no = $talep['talep_no'];
    $talep_adi = $talep['talep_eden_adi'];

    // Durum mesajları
    $onaylayan_b = $ekstra['onaylayan'] ?? '';
    $mesajlar = [
        'kalem_onaylandi'   => ['baslik' => "✅ Kalem Onaylandı: $talep_no",
                                 'kisa'   => ($onaylayan_b?"$onaylayan_b onayladı":"Kalem onaylandı"),
                                 'tip'    => 'basari'],
        'kalem_reddedildi'  => ['baslik' => "❌ Kalem Reddedildi: $talep_no",
                                 'kisa'   => ($onaylayan_b?"$onaylayan_b reddetti":"Kalem reddedildi"),
                                 'tip'    => 'hata'],
        'kalem_guncellendi' => ['baslik' => "🔄 Kalem Güncellendi: $talep_no",
                                 'kisa'   => "Kalem durumu güncellendi",
                                 'tip'    => 'bilgi'],
        'talep_olusturuldu' => ['baslik' => "🛒 Yeni Satınalma Talebi: $talep_no",
                                 'kisa'   => "Yeni talep oluşturuldu ($talep_adi)",
                                 'tip'    => 'bilgi'],
        'onayda'            => ['baslik' => "👁 Talep Onay Aşamasında: $talep_no",
                                 'kisa'   => "Talebiniz onay sürecine alındı",
                                 'tip'    => 'bilgi'],
        'reddedildi'        => ['baslik' => "❌ Talep Reddedildi: $talep_no",
                                 'kisa'   => "Talebiniz reddedildi" . (!empty($ekstra['not']) ? ": {$ekstra['not']}" : ''),
                                 'tip'    => 'hata'],
        'teklifte'          => ['baslik' => "📋 Teklif Toplanıyor: $talep_no",
                                 'kisa'   => "Talebiniz için tedarikçi teklifleri toplanıyor",
                                 'tip'    => 'uyari'],
        'siparisde'         => ['baslik' => "📦 Sipariş Oluşturuldu: $talep_no",
                                 'kisa'   => "Talebiniz için sipariş oluşturuldu",
                                 'tip'    => 'bilgi'],
        'kismi_tedarik'     => ['baslik' => "🔄 Kısmi Tedarik: $talep_no",
                                 'kisa'   => "Talebinizin bir kısmı tedarik edildi",
                                 'tip'    => 'uyari'],
        'tamamlandi'        => ['baslik' => "✅ Talep Tamamlandı: $talep_no",
                                 'kisa'   => "Talebiniz tamamen tamamlandı",
                                 'tip'    => 'basari'],
    ];

    $msg = $mesajlar[$tetikleyen] ?? [
        'baslik' => "🛒 Satınalma: $talep_no",
        'kisa'   => "Talep durumu güncellendi",
        'tip'    => 'bilgi'
    ];

    $link = '?sayfa=idari-satin-detay&id=' . $talep_id;

    // ── 1. ERP BİLDİRİMLERİ ────────────────────────────────

    // a) Talep eden kullanıcıya
    _erpBildirimYaz($db, $talep['talep_eden_id'], 'erp', $msg['baslik'], $msg['kisa'], $msg['tip'], 'idari-satinalma', $link);

    // b) Satınalma müdürü ve İdari sorumlu — personeller tablosundan bul, kullanici_id ile ERP bildirimi
    try {
        $sorumlu_poz = $db->query(
            "SELECT p.kullanici_id FROM personeller p
             JOIN departmanlar d ON p.departman_id = d.id
             WHERE p.durum='aktif' AND p.kullanici_id IS NOT NULL
               AND (d.ad LIKE '%Satınalma%' OR d.ad LIKE '%Satin%'
                    OR d.ad LIKE '%İdari%'   OR d.ad LIKE '%Idari%'
                    OR p.pozisyon LIKE '%Satınalma%Müdür%' OR p.unvan LIKE '%Satınalma%Müdür%'
                    OR p.pozisyon LIKE '%İdari%Sorumlu%'   OR p.unvan LIKE '%İdari%İşler%')"
        )->fetchAll();
        foreach ($sorumlu_poz as $s) {
            if (!$s['kullanici_id'] || $s['kullanici_id'] == $talep['talep_eden_id']) continue;
            _erpBildirimYaz($db, $s['kullanici_id'], 'erp', $msg['baslik'], $msg['kisa'], $msg['tip'], 'idari-satinalma', $link);
        }
        // Ek olarak admin rolündeki kullanıcılar (rol_id <= 2)
        $adminler = $db->query("SELECT id FROM kullanicilar WHERE rol_id <= 2 AND aktif=1")->fetchAll();
        foreach ($adminler as $a) {
            if ($a['id'] == $talep['talep_eden_id']) continue;
            _erpBildirimYaz($db, $a['id'], 'erp', $msg['baslik'], $msg['kisa'], $msg['tip'], 'idari-satinalma', $link);
        }
    } catch (Throwable $e) {}

    // ── 2. PERSONEL PORTAL BİLDİRİMİ ───────────────────────
    // portal_kullanicilari kolonları: id, tip, ilgili_id, kullanici_adi, email, durum
    // personeller tablosunda kullanici_id yok — email veya ad_soyad ile eşleştir
    try {
        $pkul_id = null;

        // Talep edenin email adresini al
        $email_q = $db->prepare("SELECT email FROM kullanicilar WHERE id=? LIMIT 1");
        $email_q->execute([$talep['talep_eden_id']]);
        $talep_eden_email = $email_q->fetchColumn() ?: '';

        // Yöntem 1: kullanicilar.email = portal_kullanicilari.email (EN GÜVENILIR)
        if ($talep_eden_email) {
            $pq1 = $db->prepare(
                "SELECT id FROM portal_kullanicilari
                 WHERE email=? AND tip='personel' AND durum=1 LIMIT 1"
            );
            $pq1->execute([$talep_eden_email]);
            $pkul_id = $pq1->fetchColumn() ?: null;
        }

        // Yöntem 2: portal_kullanicilari.ad_soyad = talep_eden_adi
        if (!$pkul_id && !empty($talep['talep_eden_adi'])) {
            $pq2 = $db->prepare(
                "SELECT id FROM portal_kullanicilari
                 WHERE ad_soyad=? AND tip='personel' AND durum=1 LIMIT 1"
            );
            $pq2->execute([trim($talep['talep_eden_adi'])]);
            $pkul_id = $pq2->fetchColumn() ?: null;
        }

        // Yöntem 3: personeller.email -> portal_kullanicilari.ilgili_id
        if (!$pkul_id && $talep_eden_email) {
            $pq3 = $db->prepare(
                "SELECT pk.id FROM portal_kullanicilari pk
                 JOIN personeller p ON pk.ilgili_id = p.id
                 WHERE p.email=? AND pk.tip='personel' AND pk.durum=1 LIMIT 1"
            );
            $pq3->execute([$talep_eden_email]);
            $pkul_id = $pq3->fetchColumn() ?: null;
        }

        // Yöntem 4: personel_id direkt (talep tablosunda kayıtlıysa)
        if (!$pkul_id && !empty($talep['personel_id'])) {
            $pq4 = $db->prepare(
                "SELECT id FROM portal_kullanicilari
                 WHERE ilgili_id=? AND tip='personel' AND durum=1 LIMIT 1"
            );
            $pq4->execute([$talep['personel_id']]);
            $pkul_id = $pq4->fetchColumn() ?: null;
        }

        if ($pkul_id) {
            _erpBildirimYaz($db, $pkul_id, 'personel',
                $msg['baslik'], $msg['kisa'], $msg['tip'], 'satinalma', null);
        }

        // Web Push — personeller.id üzerinden
        if (!empty($talep['per_id'])) {
            pushGonder((int)$talep['per_id'], $msg['baslik'], $msg['kisa'], $msg['tip']);
        }
    } catch (Throwable $e) {}
}

/**
 * bildirimler tablosuna tek satır yaz
 */
function _erpBildirimYaz($db, $kul_id, $portal, $baslik, $mesaj, $tip, $modul, $link): void
{
    try {
        $db->prepare(
            "INSERT INTO bildirimler (kullanici_id, portal_tipi, baslik, mesaj, tip, modul, link, okundu)
             VALUES (?, ?, ?, ?, ?, ?, ?, 0)"
        )->execute([$kul_id ?: null, $portal, $baslik, $mesaj, $tip, $modul, $link]);
    } catch (Throwable $e) {}
}

} // end if !function_exists
