<?php
/**
 * JETONE.PRO — Veritabani Baglantisi
 * core/db.php
 * PHP 7.0+ uyumlu
 */

if (defined('DB_CONNECTED')) return;
define('DB_CONNECTED', true);

$db_host = defined('DB_HOST') ? DB_HOST : 'localhost';
$db_adi  = defined('DB_ADI')  ? DB_ADI  : 'jetone_pro';
$db_kul  = defined('DB_KUL')  ? DB_KUL  : 'root';
$db_sifre = defined('DB_SIFRE') ? DB_SIFRE : '';

try {
    $db = new PDO(
        "mysql:host=$db_host;dbname=$db_adi;charset=utf8mb4",
        $db_kul,
        $db_sifre
    );
    $db->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES,   false);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $db->exec("SET NAMES utf8mb4");
    $db->exec("SET CHARACTER SET utf8mb4");
    $db->exec("SET time_zone = '+03:00'");

} catch (PDOException $e) {
    error_log('[DB] Baglanti hatasi: ' . $e->getMessage());
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        die('<pre style="color:red;padding:20px">Veritabani baglanamadi: ' . $e->getMessage() . '</pre>');
    } else {
        die('Veritabani baglanamadi.');
    }
}

date_default_timezone_set('Europe/Istanbul');

// Ayarlari oku
try {
    $stmt = $db->query("SELECT * FROM ayarlar LIMIT 1");
    $AYARLAR = $stmt->fetch();
    if (!$AYARLAR) $AYARLAR = array();
} catch (Exception $e) {
    $AYARLAR = array();
}
