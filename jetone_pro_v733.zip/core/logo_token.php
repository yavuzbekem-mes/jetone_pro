<?php
/**
 * JETONE.PRO — Logo REST API Token Yönetimi
 * core/logo_token.php
 *
 * Token bilgileri veritabanındaki 'entegrasyonlar' tablosundan okunur.
 */

if (!defined('DB_CONNECTED')) {
    require_once __DIR__ . '/db.php';
}

class LogoToken {

    /** Geçerli token'ı döndür (yoksa yenisini al) */
    public static function getToken() {
        global $db;

        try {
            // Bugüne ait geçerli token var mı?
            $stmt = $db->prepare("
                SELECT token FROM api_token_kayitlar
                WHERE entegrasyon_id = (SELECT id FROM entegrasyonlar WHERE kod='logo_rest' LIMIT 1)
                  AND aktif = 1
                  AND DATE(alinma_tarihi) = CURDATE()
                ORDER BY id DESC LIMIT 1
            ");
            $stmt->execute();
            $satir = $stmt->fetch();

            if ($satir && !empty($satir['token'])) {
                $GLOBALS['API_TOKEN'] = $satir['token'];
                return $satir['token'];
            }

            // Yeni token al
            return self::yeniTokenAl();

        } catch (Throwable $e) {
            error_log('[LogoToken] Token alma hatası: ' . $e->getMessage());
            return null;
        }
    }

    /** Logo REST'ten yeni token al ve kaydet */
    private static function yeniTokenAl() {
        global $db;

        // REST API ayarlarını oku
        $stmt = $db->prepare("SELECT * FROM entegrasyonlar WHERE kod='logo_rest' AND aktif=1 LIMIT 1");
        $stmt->execute();
        $ayar = $stmt->fetch();

        if (!$ayar) {
            error_log('[LogoToken] Logo REST entegrasyonu aktif değil.');
            return null;
        }

        $ek = json_decode($ayar['ek_parametreler'] ?? '{}', true);

        $url        = rtrim($ayar['host'], '/') . '/api/v1/token';
        $kullanici  = $ayar['kullanici']  ?? '';
        $sifre      = $ayar['sifre']      ?? '';
        $firmNo     = $ek['firm_no']       ?? '1';
        $clientId   = $ek['client_id']     ?? '';
        $clientSec  = $ek['client_secret'] ?? '';

        // Şifreyi çöz
        if ($sifre) {
            $key   = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
            $sifre = openssl_decrypt($sifre, 'AES-256-CBC', $key, 0, '1234567890123456') ?: $sifre;
        }

        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => http_build_query([
                    'username'      => $kullanici,
                    'password'      => $sifre,
                    'grant_type'    => 'password',
                    'firmno'        => $firmNo,
                    'client_id'     => $clientId,
                    'client_secret' => $clientSec,
                ]),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT        => 15,
            ]);

            $yanit    = curl_exec($ch);
            $httpKod  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlHata = curl_error($ch);
            curl_close($ch);

            if ($curlHata) throw new \Exception('cURL hatası: ' . $curlHata);
            if ($httpKod >= 400) throw new \Exception("HTTP $httpKod: $yanit");

            $sonuc = json_decode($yanit, true);
            if (empty($sonuc['access_token'])) throw new \Exception("Token alınamadı: $yanit");

            $token = $sonuc['access_token'];

            // Token'ı kaydet
            $entId = $db->query("SELECT id FROM entegrasyonlar WHERE kod='logo_rest' LIMIT 1")->fetchColumn();
            $db->prepare("INSERT INTO api_token_kayitlar (entegrasyon_id, token, aktif) VALUES (?,?,1)")
               ->execute([$entId, $token]);

            $GLOBALS['API_TOKEN'] = $token;
            error_log('[LogoToken] Yeni token alındı.');
            return $token;

        } catch (\Exception $e) {
            error_log('[LogoToken] Yeni token alma hatası: ' . $e->getMessage());
            return null;
        }
    }

    /** Token ile Logo REST isteği yap */
    public static function istek($endpoint, $metot = 'GET', ?$veri = null) {
        global $db;

        $token = self::getToken();
        if (!$token) return ['ok' => false, 'hata' => 'Token alınamadı.'];

        $stmt = $db->prepare("SELECT host FROM entegrasyonlar WHERE kod='logo_rest' LIMIT 1");
        $stmt->execute();
        $baseUrl = rtrim($stmt->fetchColumn() ?: '', '/');

        $url = $baseUrl . '/api/v1/' . ltrim($endpoint, '/');

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
        ]);

        if ($metot === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($veri));
        } elseif ($metot === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($veri));
        } elseif ($metot === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        $yanit   = curl_exec($ch);
        $httpKod = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpKod >= 200 && $httpKod < 300) {
            return ['ok' => true, 'data' => json_decode($yanit, true), 'kod' => $httpKod];
        }

        return ['ok' => false, 'hata' => "HTTP $httpKod", 'yanit' => $yanit];
    }
}
