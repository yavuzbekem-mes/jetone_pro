<?php
/**
 * JETONE.PRO — Kimlik Dogrulama ve Log Sistemi
 * core/auth.php
 * PHP 7.0+ uyumlu
 */

if (!defined('DB_CONNECTED')) {
    require_once __DIR__ . '/db.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_name('JETONE_ERP');
    session_start();
}

class Auth {

    public static function kullanici() {
        return isset($_SESSION['kullanici']) ? $_SESSION['kullanici'] : null;
    }

    public static function girisYapilmisMi() {
        return !empty($_SESSION['kullanici']['id']);
    }

    public static function zorunlu() {
        if (!self::girisYapilmisMi()) {
            if (self::ajaxIstegi()) {
                self::json(array('ok'=>false,'hata'=>'Oturum suresi doldu.','giris_gerekli'=>true), 401);
            }
            header('Location: ' . BASE_URL . '/giris.php');
            exit;
        }
    }

    public static function yetkiKontrol($modul, $islem = 'goruntule') {
        $kul = self::kullanici();
        if (!$kul) return false;
        if (isset($kul['rol_id']) && (int)$kul['rol_id'] === 1) return true;

        global $db;
        try {
            $stmt = $db->prepare("SELECT `$islem` FROM yetkiler WHERE rol_id=? AND modul=? LIMIT 1");
            $stmt->execute(array($kul['rol_id'], $modul));
            $satir = $stmt->fetch();
            return !empty($satir[$islem]);
        } catch (Exception $e) {
            return false;
        }
    }

    public static function girisYap($email, $sifre) {
        global $db;
        try {
            $email_temiz = strtolower(trim($email));

            $stmt = $db->prepare("SELECT * FROM kullanicilar WHERE LOWER(TRIM(email))=? LIMIT 1");
            $stmt->execute(array($email_temiz));
            $kul = $stmt->fetch();

            if (!$kul) {
                error_log("[Auth] Giris basarisiz: '$email_temiz' bulunamadi.");
                self::log(null, 'giris_basarisiz', null, null, null, "Bulunamadi: $email_temiz", null, null, 'hata');
                return array('ok'=>false, 'hata'=>'E-posta veya sifre hatali.');
            }

            if ((int)$kul['durum'] !== 1) {
                return array('ok'=>false, 'hata'=>'Hesabiniz aktif degil.');
            }

            if (!password_verify($sifre, $kul['sifre_hash'])) {
                error_log("[Auth] Giris basarisiz: '$email_temiz' yanlis sifre. Hash uz: " . strlen($kul['sifre_hash']));
                self::log(isset($kul['id']) ? $kul['id'] : null, 'giris_basarisiz', null, null, null, "Yanlis sifre: $email_temiz", null, null, 'hata');
                return array('ok'=>false, 'hata'=>'E-posta veya sifre hatali.');
            }

            session_regenerate_id(true);
            $ad    = isset($kul['ad'])    ? $kul['ad']    : '';
            $soyad = isset($kul['soyad']) ? $kul['soyad'] : '';
            $sifre_degistirildi = isset($kul['sifre_degistirildi']) ? (int)$kul['sifre_degistirildi'] : 1;

            // Rol adını çek
            $rol_adi = 'Kullanıcı';
            try {
                $rs = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
                $rs->execute([$kul['rol_id']]);
                $rol_adi = $rs->fetchColumn() ?: 'Kullanıcı';
            } catch(Throwable $_re) {}

            $_SESSION['kullanici'] = array(
                'id'                  => $kul['id'],
                'ad_soyad'            => trim($ad . ' ' . $soyad),
                'email'               => $kul['email'],
                'rol_id'              => $kul['rol_id'],
                'rol_adi'             => $rol_adi,
                'avatar'              => isset($kul['avatar']) ? $kul['avatar'] : null,
                'sifre_degistirildi'  => $sifre_degistirildi,
            );

            $db->prepare("UPDATE kullanicilar SET son_giris=NOW() WHERE id=?")->execute(array($kul['id']));
            self::log($kul['id'], 'giris', 'sistem', null, null, 'Basarili giris');
            return array(
                'ok'                 => true,
                'kullanici'          => $_SESSION['kullanici'],
                'sifre_degistirildi' => $sifre_degistirildi,
            );

        } catch (Exception $e) {
            error_log('[Auth] Giris hatasi: ' . $e->getMessage());
            return array('ok'=>false, 'hata'=>'Sistem hatasi.');
        }
    }

    public static function cikisYap() {
        $id = null;
        $kul = self::kullanici();
        if ($kul) $id = $kul['id'];
        if ($id) self::log($id, 'cikis', 'sistem', null, null, 'Cikis yapildi');
        session_destroy();
    }

    // ─── LOG SİSTEMİ ─────────────────────────────────────────

    public static function log(
        $kullanici_id,
        $islem,
        $modul       = null,
        $tablo       = null,
        $kayit_id    = null,
        $aciklama    = null,
        $eski_veri   = null,
        $yeni_veri   = null,
        $durum       = 'basarili',
        $hata_mesaji = null
    ) {
        global $db;
        try {
            if ($kullanici_id === null && isset($_SESSION['kullanici']['id'])) {
                $kullanici_id = $_SESSION['kullanici']['id'];
            }

            $db->prepare("
                INSERT INTO sistem_loglar
                    (kullanici_id, ip, islem, modul, tablo_adi, kayit_id,
                     aciklama, eski_veri, yeni_veri, durum, hata_mesaji, user_agent)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ")->execute(array(
                $kullanici_id,
                self::ip(),
                $islem,
                $modul,
                $tablo,
                $kayit_id,
                $aciklama,
                $eski_veri  ? json_encode($eski_veri,  JSON_UNESCAPED_UNICODE) : null,
                $yeni_veri  ? json_encode($yeni_veri,  JSON_UNESCAPED_UNICODE) : null,
                $durum,
                $hata_mesaji,
                substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 300),
            ));
        } catch (Exception $e) {
            error_log('[Log] Kayit hatasi: ' . $e->getMessage());
        }
    }

    public static function logKaydet($kullanici_id, $islem, $modul = null, $kayit_id = null, $aciklama = null, $durum = 'basarili') {
        self::log($kullanici_id, $islem, $modul, null, $kayit_id, $aciklama, null, null, $durum);
    }

    public static function crudLog($islem, $modul, $tablo, $kayit_id, $eski = null, $yeni = null, $aciklama = null) {
        $maskele = array('sifre_hash','sifre','password','token','api_key','client_secret');
        if ($eski) { foreach ($maskele as $k) { if (isset($eski[$k])) $eski[$k] = '***'; } }
        if ($yeni) { foreach ($maskele as $k) { if (isset($yeni[$k])) $yeni[$k] = '***'; } }
        if (!$aciklama) $aciklama = ucfirst($islem) . " - $tablo #$kayit_id";
        self::log(null, $islem, $modul, $tablo, $kayit_id, $aciklama, $eski, $yeni);
    }

    public static function ip() {
        $kontrol = array('HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR');
        foreach ($kontrol as $k) {
            if (!empty($_SERVER[$k])) {
                $parts = explode(',', $_SERVER[$k]);
                return trim($parts[0]);
            }
        }
        return '0.0.0.0';
    }

    public static function ajaxIstegi() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    public static function json($veri, $kod = 200) {
        http_response_code($kod);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($veri, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
