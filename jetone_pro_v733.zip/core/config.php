<?php
/**
 * JETONE.PRO — Uygulama Konfigürasyonu
 * core/config.php
 * PHP 7.0+ uyumlu
 */

// Zaman dilimi — İstanbul
date_default_timezone_set('Europe/Istanbul');

define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

// BASE_URL otomatik algıla (PHP 7.0+ uyumlu)
if (!defined('BASE_URL')) {
    $protokol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host     = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';

    $root_gercek = str_replace('\\', '/', realpath(dirname(__DIR__)));
    $doc_root    = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])) : '';

    if ($doc_root !== '' && strpos($root_gercek, $doc_root) === 0) {
        $alt_yol = substr($root_gercek, strlen($doc_root));
    } else {
        $alt_yol = '/' . basename($root_gercek);
    }

    $alt_yol = rtrim($alt_yol, '/');
    define('BASE_URL', $protokol . '://' . $host . $alt_yol);
}

// VAPID Push Bildirim Anahtarları
define('VAPID_PUBLIC',  'BDqOMrtqO7HIQlYFyEp9_Fh3jCU3npiSlUabnotcMYS-yNnQhtsK0SA73kMcnsz3V74v29BfOKe6M9Gv3BBCTDs');
define('VAPID_PRIVATE', 'g0KLdEoLwXjgNTGuhDw3v69OQf4lygqv_J5bAvspoVg');
define('VAPID_SUBJECT', 'mailto:admin@jetone.pro');

// Dizin sabitleri
define('ROOT_DIR',       dirname(__DIR__));
define('UPLOAD_DIR',     ROOT_DIR . '/uploads');
define('PAYLASILAN_CSS', ROOT_DIR . '/paylasilan/css');
define('PAYLASILAN_JS',  ROOT_DIR . '/paylasilan/js');

// Dosya kisitlamalari
define('IZIN_UZANTILAR', array('jpg','jpeg','png','gif','pdf','xlsx','xls','docx','doc','zip'));
define('MAX_UPLOAD_SIZE', 20 * 1024 * 1024);

// Oturum
define('SESSION_SURE', 8 * 3600);

// Uygulama
define('APP_VERSIYON', '1.0.0');
define('APP_ADI',      'Jetone.pro ERP');

// Veritabani sabitleri
define('DB_HOST',  'localhost');
define('DB_ADI',   'jetone_pro');
define('DB_KUL',   'root');
define('DB_SIFRE', '');

// Sifreleme
define('SIFRELE_KEY', 'jetone_gizli_anahtar_2024_degistirin');

// CSS inline embed yardimcisi (PHP 7.0 uyumlu - tip tanımı yok)
function css_inline($dosya_adi) {
    $yol = PAYLASILAN_CSS . '/' . $dosya_adi;
    if (file_exists($yol)) {
        echo '<style>' . file_get_contents($yol) . '</style>' . PHP_EOL;
    }
}

function js_inline($dosya_adi) {
    $yol = PAYLASILAN_JS . '/' . $dosya_adi;
    if (file_exists($yol)) {
        $icerik = file_get_contents($yol);
        // BOM karakterini kaldır
        $icerik = ltrim($icerik, "\xef\xbb\xbf");
        echo '<script>' . $icerik . '</script>' . PHP_EOL;
    }
}

// ── Yapay Zeka (Claude API) ──────────────────────────────────────
define('CLAUDE_API_KEY', ''); // API key buraya eklenecek
define('CLAUDE_MODEL',   'claude-sonnet-4-20250514');
