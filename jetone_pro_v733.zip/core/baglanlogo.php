<?php
/**
 * JETONE.PRO — Logo Tiger (TIGERDB) & MES Veritabanı Bağlantısı
 * core/baglanlogo.php
 *
 * Bağlantı bilgileri 'entegrasyonlar' tablosundan okunur.
 * Kullanım: require_once __DIR__ . '/baglanlogo.php';
 *           // $tigerdb_pdo, $mes_pdo kullanılabilir
 */

if (!defined('DB_CONNECTED')) {
    require_once __DIR__ . '/db.php';
}

$tigerdb_pdo = null;
$mes_pdo     = null;
$KEY = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
$IV  = '1234567890123456';

function _logo_sifre_coz($sifreli, $key, $iv) {
    if (!$sifreli) return '';
    $cozuldu = openssl_decrypt($sifreli, 'AES-256-CBC', $key, 0, $iv);
    return ($cozuldu !== false) ? $cozuldu : $sifreli; // şifreli değilse direkt kullan
}

function _logo_mssql_baglan($host, $vt, $user, $pass, $port = 0) {
    $pdo_opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    $serverStr = ($port && $port != 1433) ? "$host,$port" : $host;
    $dsn = "sqlsrv:server=$serverStr;Database=$vt";

    // Önce host adıyla dene
    try {
        return new PDO($dsn, $user, $pass, $pdo_opts);
    } catch (Exception $e) {
        // Hostname çalışmazsa IP'ye çevirip tekrar dene (VPN senaryosu)
        if (!filter_var($host, FILTER_VALIDATE_IP)) {
            $ip = @gethostbyname($host);
            if ($ip && $ip !== $host) {
                $serverStr2 = ($port && $port != 1433) ? "$ip,$port" : $ip;
                $dsn2 = "sqlsrv:server=$serverStr2;Database=$vt";
                return new PDO($dsn2, $user, $pass, $pdo_opts);
            }
        }
        throw $e; // her ikisi de başarısız
    }
}

// ── TIGERDB (Logo Tiger Ana Veritabanı) ──────────────────
try {
    $stmt = $db->prepare("SELECT * FROM entegrasyonlar WHERE kod='logo_tiger' AND aktif=1 LIMIT 1");
    $stmt->execute();
    $ayar = $stmt->fetch();

    if ($ayar) {
        $host = $ayar['host']       ?: 'POLIZASERVER';
        $vt   = $ayar['veritabani'] ?: 'TIGERDB';
        $user = $ayar['kullanici']  ?: 'sa';
        $pass = _logo_sifre_coz($ayar['sifre'], $KEY, $IV);
        $port = $ayar['port']       ?: 1433;

        $tigerdb_pdo = _logo_mssql_baglan($host, $vt, $user, $pass, $port);

        $db->prepare("UPDATE entegrasyonlar SET son_test_tarihi=NOW(), son_test_sonucu=1, son_test_mesaji='Bağlantı başarılı' WHERE kod='logo_tiger'")->execute();
        error_log("[TIGERDB] Bağlantı başarılı.");
    }
} catch (Throwable $e) {
    $tigerdb_pdo = null;
    error_log('[TIGERDB] Bağlantı hatası: ' . $e->getMessage());
    try {
        $db->prepare("UPDATE entegrasyonlar SET son_test_tarihi=NOW(), son_test_sonucu=0, son_test_mesaji=? WHERE kod='logo_tiger'")
           ->execute([mb_substr($e->getMessage(), 0, 500)]);
    } catch (Throwable $ignore) {}
}

// ── MES (Üretim Takip Veritabanı) ────────────────────────
try {
    $stmt2 = $db->prepare("SELECT * FROM entegrasyonlar WHERE kod='mes' AND aktif=1 LIMIT 1");
    $stmt2->execute();
    $ayar2 = $stmt2->fetch();

    if ($ayar2) {
        $host = $ayar2['host']       ?: 'POLIZASERVER';
        $vt   = $ayar2['veritabani'] ?: 'MES';
        $user = $ayar2['kullanici']  ?: 'sa';
        $pass = _logo_sifre_coz($ayar2['sifre'], $KEY, $IV);
        $port = $ayar2['port']       ?: 1433;

        $mes_pdo = _logo_mssql_baglan($host, $vt, $user, $pass, $port);

        $db->prepare("UPDATE entegrasyonlar SET son_test_tarihi=NOW(), son_test_sonucu=1, son_test_mesaji='Bağlantı başarılı' WHERE kod='mes'")->execute();
        error_log("[MES] Bağlantı başarılı.");
    }
} catch (Throwable $e) {
    $mes_pdo = null;
    error_log('[MES] Bağlantı hatası: ' . $e->getMessage());
    try {
        $db->prepare("UPDATE entegrasyonlar SET son_test_tarihi=NOW(), son_test_sonucu=0, son_test_mesaji=? WHERE kod='mes'")
           ->execute([mb_substr($e->getMessage(), 0, 500)]);
    } catch (Throwable $ignore) {}
}
