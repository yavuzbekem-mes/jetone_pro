<?php
/**
 * Push Bildirim Gönder — Yardımcı
 * core/push-gonder.php
 * 
 * Kullanım: require ve pushGonder() çağır
 */

if (!function_exists('pushGonder')) {

require_once __DIR__ . '/WebPush.php';

/**
 * Personel'e push bildirimi gönder
 * @param int    $personel_id  personeller.id
 * @param string $baslik
 * @param string $govde
 * @param string $tip          basari|hata|uyari|bilgi
 */
function pushGonder(int $personel_id, string $baslik, string $govde, string $tip = 'bilgi'): void {
    global $db;
    if (!defined('VAPID_PUBLIC') || !defined('VAPID_PRIVATE')) return;

    try {
        // Personelin portal kullanıcısını bul
        $stmt = $db->prepare("
            SELECT ps.* FROM push_subscriptions ps
            JOIN portal_kullanicilari pk ON ps.portal_kul_id = pk.id
            WHERE pk.ilgili_id = ? AND pk.tip = 'personel' AND ps.aktif = 1
            ORDER BY ps.olusturma DESC
        ");
        $stmt->execute([$personel_id]);
        $subscriptions = $stmt->fetchAll();

        if (empty($subscriptions)) return;

        $ikonlar = ['basari'=>'✅','hata'=>'❌','uyari'=>'⚠️','bilgi'=>'ℹ️'];
        $tam_baslik = ($ikonlar[$tip]??'🔔').' '.$baslik;

        foreach ($subscriptions as $sub) {
            $result = WebPush::basitGonder(
                $sub['endpoint'],
                $tam_baslik,
                $govde,
                VAPID_PUBLIC,
                VAPID_PRIVATE,
                VAPID_SUBJECT
            );

            if (!$result['ok']) {
                error_log("[PushGonder] Gönderim hatası (sub #{$sub['id']}): HTTP {$result['status']} — {$result['hata']}");
                // 410 Gone = subscription geçersiz, deaktif et
                if (($result['status']??0) === 410) {
                    $db->prepare("UPDATE push_subscriptions SET aktif=0 WHERE id=?")->execute([$sub['id']]);
                }
            } else {
                error_log("[PushGonder] Gönderildi (sub #{$sub['id']}): HTTP {$result['status']}");
            }
        }
    } catch (Throwable $e) {
        error_log('[PushGonder] Hata: ' . $e->getMessage());
    }
}

/**
 * Portal kullanıcısına (kul_id ile) push gönder
 */
function pushGonderKulId(int $portal_kul_id, string $baslik, string $govde, string $tip = 'bilgi'): void {
    global $db;
    if (!defined('VAPID_PUBLIC') || !defined('VAPID_PRIVATE')) return;

    try {
        $stmt = $db->prepare("SELECT * FROM push_subscriptions WHERE portal_kul_id=? AND aktif=1 ORDER BY olusturma DESC");
        $stmt->execute([$portal_kul_id]);
        $subs = $stmt->fetchAll();

        foreach ($subs as $sub) {
            WebPush::basitGonder($sub['endpoint'],$baslik,$govde,VAPID_PUBLIC,VAPID_PRIVATE,VAPID_SUBJECT);
        }
    } catch (Throwable $e) {
        error_log('[PushGonderKul] ' . $e->getMessage());
    }
}

} // end function_exists check
