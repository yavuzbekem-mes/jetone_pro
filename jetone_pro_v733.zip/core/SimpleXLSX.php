<?php
/**
 * SimpleXLSX - Minimal XLSX okuyucu
 * xlsx = zip arşivi, xl/worksheets/sheet1.xml içinde veriler
 */
class SimpleXLSX {
    private $rows_data = [];
    private $error = '';

    public function __construct($file) {
        if (!file_exists($file)) { $this->error='Dosya bulunamadi'; return; }
        if (!class_exists('ZipArchive')) { $this->error='ZipArchive yok'; return; }
        $zip = new ZipArchive();
        if ($zip->open($file) !== true) { $this->error='ZIP acilamadi'; return; }

        // Shared strings
        $shared = [];
        $ss = $zip->getFromName('xl/sharedStrings.xml');
        if ($ss) {
            $xml = simplexml_load_string($ss,'SimpleXMLElement',LIBXML_NOCDATA|LIBXML_NOERROR);
            if ($xml) {
                foreach ($xml->si as $si) {
                    $t = '';
                    if (isset($si->t)) $t = (string)$si->t;
                    elseif (isset($si->r)) {
                        foreach ($si->r as $r) { if(isset($r->t)) $t.=(string)$r->t; }
                    }
                    $shared[] = $t;
                }
            }
        }

        // Sheet1
        $sheet = null;
        for ($i=1; $i<=10; $i++) {
            $s = $zip->getFromName("xl/worksheets/sheet$i.xml");
            if ($s) { $sheet=$s; break; }
        }
        $zip->close();
        if (!$sheet) { $this->error='Sheet bulunamadi'; return; }

        $xml = simplexml_load_string($sheet,'SimpleXMLElement',LIBXML_NOCDATA|LIBXML_NOERROR);
        if (!$xml) { $this->error='XML parse hatasi'; return; }

        $ns = $xml->getNamespaces(true);
        $default_ns = isset($ns['']) ? $ns[''] : '';

        foreach ($xml->sheetData->row as $row) {
            $rowData = [];
            $maxCol = 0;
            $cells = [];
            foreach ($row->c as $c) {
                $r = (string)$c['r'];
                // Kolon harfini sayıya çevir
                preg_match('/^([A-Z]+)(\d+)$/', $r, $m);
                $colLetter = $m[1]??'A';
                $colIdx = 0;
                for ($ci=0; $ci<strlen($colLetter); $ci++) {
                    $colIdx = $colIdx*26 + (ord($colLetter[$ci])-64);
                }
                $colIdx--;
                $type = (string)$c['t'];
                $val  = isset($c->v) ? (string)$c->v : '';
                if ($type==='s') $val = $shared[(int)$val] ?? '';
                elseif ($type==='inlineStr') $val = isset($c->is->t) ? (string)$c->is->t : '';
                $cells[$colIdx] = $val;
                if ($colIdx>$maxCol) $maxCol=$colIdx;
            }
            $rowArr = [];
            for ($ci=0; $ci<=$maxCol; $ci++) $rowArr[]=$cells[$ci]??'';
            $this->rows_data[] = $rowArr;
        }
    }

    public function rows() { return $this->rows_data; }
    public function error() { return $this->error; }
    public function success() { return empty($this->error); }
}
