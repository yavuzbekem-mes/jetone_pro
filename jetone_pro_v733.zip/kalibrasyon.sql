-- ================================================================
-- KALİBRASYON CİHAZLARI + KAYIT TABLOLARI
-- ================================================================

CREATE TABLE IF NOT EXISTS `kalibrasyon_cihazlar` (
  `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `kayit_no`            VARCHAR(20) NOT NULL UNIQUE,       -- POL-01 vb
  `cihaz_adi`           VARCHAR(255) NOT NULL,
  `marka_model`         VARCHAR(255),
  `olcum_araligi`       VARCHAR(100),
  `hassasiyet`          VARCHAR(50),
  `kullanim_bolumu`     VARCHAR(100),
  `periyot_gun`         INT NOT NULL DEFAULT 365,
  `son_kalibrasyon`     DATE,
  `sonraki_kalibrasyon` DATE,
  `yapan_firma`         VARCHAR(255),
  `degerlendirme`       VARCHAR(255),           -- KULLANIMA UYGUNDUR vb
  `durum`               VARCHAR(50) DEFAULT 'OKEY',  -- OKEY/ARIZALI/KULLANIM DIŞI/KAYIP
  `aktif`               TINYINT(1) DEFAULT 1,
  `aciklama`            TEXT,
  `kayit_tarihi`        DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_sonraki` (`sonraki_kalibrasyon`),
  KEY `idx_kayit_no` (`kayit_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `kalibrasyon_kayitlar` (
  `id`                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `cihaz_id`          INT UNSIGNED NOT NULL,
  `kalibrasyon_tarihi` DATE NOT NULL,
  `sonraki_tarih`     DATE,
  `yapan_firma`       VARCHAR(255),
  `degerlendirme`     VARCHAR(255),
  `durum`             VARCHAR(50) DEFAULT 'OKEY',
  `sertifika_dosya`   VARCHAR(255),        -- uploads içinde dosya adı
  `aciklama`          TEXT,
  `ekleyen`           VARCHAR(100),
  `kayit_tarihi`      DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_cihaz`     (`cihaz_id`),
  KEY `idx_tarih`     (`kalibrasyon_tarihi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
