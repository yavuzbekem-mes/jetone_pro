<?php
/**
 * JETONE.PRO — Giriş Sayfası
 * giris.php
 */
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';
require_once __DIR__ . '/core/auth.php';

if (session_status() === PHP_SESSION_NONE) { session_name('JETONE_ERP'); session_start(); }

if (Auth::girisYapilmisMi()) {
    header('Location: ' . BASE_URL . '/panel.php');
    exit;
}

$hata = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sonuc = Auth::girisYap(
        trim($_POST['email']  ?? ''),
        trim($_POST['sifre']  ?? '')
    );
    if ($sonuc['ok']) {
        // İlk şifre kontrolü — sifre_degistirildi = 0 ise şifre değiştir sayfasına yönlendir
        if (isset($sonuc['sifre_degistirildi']) && $sonuc['sifre_degistirildi'] == 0) {
            header('Location: ' . BASE_URL . '/erp-sifre-degistir.php?ilk=1');
        } else {
            header('Location: ' . BASE_URL . '/panel.php');
        }
        exit;
    }
    $hata = $sonuc['hata'];
}

$firma_adi = htmlspecialchars($AYARLAR['firma_adi'] ?? 'Jetone.pro');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<link rel="icon" type="image/svg+xml" href="<?php echo BASE_URL; ?>/favicons/erp.svg">
<link rel="shortcut icon" href="<?php echo BASE_URL; ?>/favicons/erp.svg">
<meta name="theme-color" content="#F97316">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Giriş — <?php echo $firma_adi; ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<?php css_inline('uygulama.css'); ?>
<style>
html,body{height:100%;overflow:hidden;margin:0;padding:0}
body{display:flex;font-family:'Plus Jakarta Sans',system-ui,sans-serif}
.g-sol{
  flex:1;
  position:relative;overflow:hidden;
  display:flex;align-items:center;justify-content:center;
  background:#111E30;
}
.g-sol-bg{
  position:absolute;inset:0;
  background:
    radial-gradient(ellipse 80% 60% at 10% 80%,rgba(249,115,22,.18) 0%,transparent 60%),
    radial-gradient(ellipse 60% 80% at 90% 20%,rgba(37,99,235,.14) 0%,transparent 60%),
    linear-gradient(160deg,#1A2E4A 0%,#0D1F35 55%,#080F1A 100%);
}
.g-sol-grid{
  position:absolute;inset:0;
  background-image:
    linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);
  background-size:44px 44px;
}
.g-ic{position:relative;z-index:1;text-align:center;color:#fff;padding:40px;}
.g-logo{
  width:80px;height:80px;border-radius:22px;background:#F97316;
  display:flex;align-items:center;justify-content:center;
  margin:0 auto 24px;font-size:36px;font-weight:900;color:#fff;letter-spacing:-2px;
  box-shadow:0 0 0 8px rgba(249,115,22,.14),0 20px 40px rgba(249,115,22,.35);
  animation:yuz 3.5s ease-in-out infinite;
}
@keyframes yuz{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
.g-baslik{
  font-size:32px;font-weight:800;letter-spacing:-1px;margin-bottom:10px;
  background:linear-gradient(135deg,#fff 40%,rgba(255,255,255,.55));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.g-alt{font-size:15px;color:rgba(255,255,255,.5);max-width:300px;margin:0 auto 32px;line-height:1.65;}
.g-taglar{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;}
.g-tag{
  display:flex;align-items:center;gap:6px;
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  border-radius:20px;padding:6px 14px;
  font-size:12px;font-weight:600;color:rgba(255,255,255,.65);
}

.g-sag{
  width:460px;flex-shrink:0;background:#F0F2F5;
  display:flex;align-items:center;justify-content:center;
  padding:32px;overflow-y:auto;
}
.g-kart{
  width:100%;max-width:380px;
  background:#fff;border:1px solid #E4E7EC;
  border-radius:16px;padding:40px 36px;
  box-shadow:0 20px 40px rgba(0,0,0,.1);
}
.g-kart-logo{display:flex;align-items:center;gap:10px;justify-content:center;margin-bottom:28px;}
.g-kart-ikon{
  width:38px;height:38px;border-radius:10px;background:#F97316;
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:18px;font-weight:900;
  box-shadow:0 4px 12px rgba(249,115,22,.3);
}
.g-kart-marka{font-size:22px;font-weight:800;color:#101828;letter-spacing:-.5px;}
.g-kart-marka span{color:#F97316;}
.g-kart h2{font-size:20px;font-weight:700;text-align:center;margin-bottom:4px;color:#101828;}
.g-kart-alt{text-align:center;font-size:13px;color:#667085;margin-bottom:28px;}

.hata-kutu{
  background:#FEE4E2;border:1px solid #F04438;border-radius:8px;
  padding:10px 14px;font-size:13px;color:#F04438;margin-bottom:16px;font-weight:600;
}
.f-grup{margin-bottom:16px;}
.f-et{display:block;font-size:12.5px;font-weight:700;color:#101828;margin-bottom:5px;}
.f-alan{
  width:100%;padding:10px 14px;
  border:1.5px solid #E4E7EC;border-radius:8px;
  font-size:14px;font-family:inherit;color:#101828;
  background:#fff;outline:none;
  transition:border-color .15s,box-shadow .15s;
  box-sizing:border-box;
}
.f-alan:focus{border-color:#F97316;box-shadow:0 0 0 4px rgba(249,115,22,.1);}
.f-satir{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.onay-l{display:flex;align-items:center;gap:8px;font-size:13px;color:#667085;cursor:pointer;}
.onay-l input{accent-color:#F97316;}
.sifre-l{font-size:13px;color:#F97316;font-weight:600;cursor:pointer;text-decoration:none;}
.g-btn{
  width:100%;padding:12px;background:#F97316;color:#fff;
  border:none;border-radius:8px;font-size:15px;font-weight:700;
  font-family:inherit;cursor:pointer;transition:all .15s;
}
.g-btn:hover{background:#EA6800;transform:translateY(-1px);box-shadow:0 6px 16px rgba(249,115,22,.4);}

.portal-bolum{margin-top:22px;padding-top:20px;border-top:1px solid #E4E7EC;}
.portal-et{font-size:11px;font-weight:700;color:#98A2B3;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;}
.portal-btn{
  display:flex;align-items:center;gap:10px;padding:9px 14px;
  border:1.5px solid #E4E7EC;border-radius:8px;
  background:#F4F5F7;color:#667085;
  font-size:13px;font-weight:600;font-family:inherit;
  cursor:pointer;text-decoration:none;transition:all .15s;
  margin-bottom:8px;width:100%;box-sizing:border-box;
}
.portal-btn:hover{border-color:#F97316;color:#F97316;background:#FEF3E8;}
.portal-btn-ok{margin-left:auto;font-size:11px;opacity:.4;}

@media(max-width:600px){
  .g-sol{display:none;}
  .g-sag{width:100%;padding:20px;}
}
</style>
</head>
<body>

<div class="g-sol">
  <div class="g-sol-bg"></div>
  <div class="g-sol-grid"></div>
  <div class="g-ic">
    <div class="g-logo">J</div>
    <div class="g-baslik"><?php echo $firma_adi; ?></div>
    <div class="g-alt">Üretim, İK, Satış ve Lojistiği tek platformda yönetin</div>
    <div class="g-taglar">
      <div class="g-tag">🏭 Üretim & MRP</div>
      <div class="g-tag">👥 İK & Personel</div>
      <div class="g-tag">📦 Depo</div>
      <div class="g-tag">💼 Satış CRM</div>
    </div>
  </div>
</div>

<div class="g-sag">
  <div class="g-kart">
    <div class="g-kart-logo">
      <div class="g-kart-ikon">J</div>
      <div class="g-kart-marka">jetone<span>.pro</span></div>
    </div>
    <h2>Yönetim Paneli</h2>
    <div class="g-kart-alt">ERP hesabınızla giriş yapın</div>

    <?php if ($hata): ?>
    <div class="hata-kutu">❌ <?php echo htmlspecialchars($hata); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="f-grup">
        <label class="f-et">E-posta Adresi</label>
        <input type="email" name="email" class="f-alan"
               placeholder="admin@firma.com"
               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
               required autofocus>
      </div>
      <div class="f-grup">
        <label class="f-et">Şifre</label>
        <input type="password" name="sifre" class="f-alan"
               placeholder="••••••••" required>
      </div>
      <div class="f-satir">
        <label class="onay-l">
          <input type="checkbox" name="beni_hatirla" checked> Beni Hatırla
        </label>
        <a href="#" class="sifre-l">Şifremi Unuttum?</a>
      </div>
      <button type="submit" class="g-btn">Giriş Yap →</button>
    </form>

    <div class="portal-bolum">
      <div class="portal-et">Bağlantılı Portaller</div>
      <a href="<?php echo BASE_URL; ?>/portal/personel/giris.php" class="portal-btn">
        <span>🧑‍💼</span>
        <span>Personel Self-Service</span>
        <span style="font-size:10px;color:#98A2B3;margin-left:4px">portal.jetone.pro</span>
        <span class="portal-btn-ok">↗</span>
      </a>
      <a href="<?php echo BASE_URL; ?>/portal/musteri/giris.php" class="portal-btn">
        <span>🚚</span>
        <span>Müşteri Portalı</span>
        <span style="font-size:10px;color:#98A2B3;margin-left:4px">musteri.jetone.pro</span>
        <span class="portal-btn-ok">↗</span>
      </a>
    </div>
  </div>
</div>

</body>
</html>
