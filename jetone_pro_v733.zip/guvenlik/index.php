<?php
/**
 * GUVENLIK — index.php
 */
if (!Auth::yetkiKontrol('guvenlik','goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}
?>
<div class="s-bar">
  <div><h1 class="s-bas"><?php echo ucfirst('guvenlik'); ?></h1><div class="s-yol">Anasayfa / <b><?php echo ucfirst('guvenlik'); ?></b></div></div>
</div>
<div class="s-body">
  <div class="kart" style="padding:40px;text-align:center;color:var(--m2)">
    <div style="font-size:44px;margin-bottom:14px">📊</div>
    <div style="font-size:16px;font-weight:700;color:var(--m)"><?php echo ucfirst('guvenlik'); ?> modülü geliştiriliyor</div>
  </div>
</div>
