<?php
// JETONE.PRO - Giris Test ve Otomatik Duzeltme
// Kullandiktan sonra silin!
// PHP 7.0+ uyumlu, hicbir framework yok

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabani bilgileri
$db_host  = 'localhost';
$db_adi   = 'jetone_pro';
$db_kul   = 'root';
$db_sifre = '';

// Baglanti
try {
    $db = new PDO("mysql:host=$db_host;dbname=$db_adi;charset=utf8", $db_kul, $db_sifre);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec("SET NAMES utf8");
    $baglanti_ok = true;
    $baglanti_hata = '';
} catch (Exception $e) {
    $baglanti_ok = false;
    $baglanti_hata = $e->getMessage();
}

$mesajlar = array();
$islem_tamam = false;

// Form gonderildi mi?
if ($baglanti_ok && isset($_POST['guncelle'])) {

    // Hash uret
    $admin_hash = password_hash('Admin123!',     PASSWORD_DEFAULT);
    $erp_hash   = password_hash('Jetone2024!',   PASSWORD_DEFAULT);
    $per_hash   = password_hash('Personel2024!', PASSWORD_DEFAULT);
    $mus_hash   = password_hash('Musteri2024!',  PASSWORD_DEFAULT);

    // --- sistem_loglar tablosuna tablo_adi kolonu ekle ---
    try {
        // Kolon var mi kontrol et
        $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'sistem_loglar' AND COLUMN_NAME = 'tablo_adi'");
        $stmt->execute(array($db_adi));
        $var = (int)$stmt->fetchColumn();
        if ($var == 0) {
            $db->exec("ALTER TABLE sistem_loglar ADD COLUMN tablo_adi VARCHAR(80) DEFAULT NULL AFTER modul");
            $mesajlar[] = array(1, 'sistem_loglar.tablo_adi kolonu eklendi');
        } else {
            $mesajlar[] = array(1, 'sistem_loglar.tablo_adi zaten mevcut, atlandi');
        }
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'ALTER TABLE: ' . $e->getMessage());
    }

    // --- ERP Admin ---
    try {
        $db->exec("DELETE FROM kullanicilar WHERE email='admin@jetone.pro'");
        $st = $db->prepare("INSERT INTO kullanicilar (ad, soyad, email, sifre_hash, rol_id, durum)
            VALUES ('Super', 'Admin', 'admin@jetone.pro', ?, 1, 1)");
        $st->execute(array($admin_hash));
        $mesajlar[] = array(1, 'admin@jetone.pro eklendi (Admin123!)');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'Admin ekle: ' . $e->getMessage());
    }

    // --- Diger ERP kullanicilari ---
    try {
        $erp_liste = array(
            array('Ayse',   'Yilmaz', 'ayse.yilmaz@jetone.pro',   1, 1, 'Sistem Yoneticisi'),
            array('Mehmet', 'Kaya',   'mehmet.kaya@jetone.pro',    2, 2, 'IK Muduru'),
            array('Fatma',  'Sahin',  'fatma.sahin@jetone.pro',    3, 5, 'Uretim Sefi'),
            array('Ali',    'Demir',  'ali.demir@jetone.pro',       4, 8, 'Satinalma'),
            array('Zeynep', 'Arslan', 'zeynep.arslan@jetone.pro',  5, 4, 'Satis'),
        );
        foreach ($erp_liste as $u) {
            $db->exec("DELETE FROM kullanicilar WHERE email='" . $u[2] . "'");
            $st = $db->prepare("INSERT INTO kullanicilar (ad, soyad, email, sifre_hash, rol_id, departman_id, pozisyon, durum)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
            $st->execute(array($u[0], $u[1], $u[2], $erp_hash, $u[3], $u[4], $u[5]));
        }
        $mesajlar[] = array(1, '5 ERP kullanicisi eklendi (Jetone2024!)');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'ERP kullanicilari: ' . $e->getMessage());
    }

    // --- Personeller ---
    try {
        $personeller = array(
            array('P-00001','Ahmet',   'Kaya',   '12345678901','1988-05-12',1,5,'Uretim Operatoru',   '0532 111 0001','ahmet.kaya@firma.com',     '2019-03-01',18500.00),
            array('P-00002','Mustafa', 'Celik',  '12345678902','1990-07-22',1,5,'CNC Operatoru',      '0532 111 0002','mustafa.celik@firma.com',   '2020-06-15',20000.00),
            array('P-00003','Hasan',   'Yildiz', '12345678903','1985-11-03',1,5,'Vardiya Sefi',       '0532 111 0003','hasan.yildiz@firma.com',    '2017-01-10',28000.00),
            array('P-00004','Ibrahim', 'Ozturk', '12345678904','1992-03-18',1,5,'Bakim Teknisyeni',   '0532 111 0004','ibrahim.ozturk@firma.com',  '2021-09-01',22000.00),
            array('P-00005','Emre',    'Yilmaz', '12345678905','1995-08-25',1,5,'Uretim Operatoru',   '0532 111 0005','emre.yilmaz@firma.com',     '2022-02-14',17500.00),
            array('P-00006','Fatma',   'Sahin',  '12345678906','1987-02-14',2,2,'IK Uzmani',          '0532 111 0006','fatma.sahin.ik@firma.com',  '2018-07-01',32000.00),
            array('P-00007','Elif',    'Koca',   '12345678907','1993-12-30',2,2,'IK Asistani',        '0532 111 0007','elif.koca@firma.com',       '2022-04-01',22000.00),
            array('P-00008','Selin',   'Aydin',  '12345678908','1989-09-07',2,7,'Kalite Uzmani',      '0532 111 0008','selin.aydin@firma.com',     '2019-11-15',27000.00),
            array('P-00009','Burak',   'Gunes',  '12345678909','1991-04-21',1,7,'Kalite Kontrol',     '0532 111 0009','burak.gunes@firma.com',     '2020-08-01',24000.00),
            array('P-00010','Murat',   'Dogan',  '12345678910','1986-06-15',1,6,'Depo Sorumlusu',     '0532 111 0010','murat.dogan@firma.com',     '2018-01-15',25000.00),
            array('P-00011','Kadir',   'Arslan', '12345678911','1994-01-28',1,6,'Depo Gorevlisi',     '0532 111 0011','kadir.arslan@firma.com',    '2021-05-01',19000.00),
            array('P-00012','Serkan',  'Kilic',  '12345678912','1997-10-11',1,6,'Forklift Operatoru', '0532 111 0012','serkan.kilic@firma.com',    '2023-01-09',18000.00),
            array('P-00013','Zeynep',  'Arslan', '12345678913','1990-03-05',2,4,'Satis Uzmani',       '0532 111 0013','zeynep.arslan.s@firma.com', '2019-05-01',30000.00),
            array('P-00014','Berk',    'Ozkan',  '12345678914','1988-07-19',1,4,'Satis Muduru',       '0532 111 0014','berk.ozkan@firma.com',      '2016-09-01',45000.00),
            array('P-00015','Busra',   'Yilmaz', '12345678915','1992-11-22',2,3,'Muhasebe Uzmani',    '0532 111 0015','busra.yilmaz@firma.com',    '2020-10-01',34000.00),
        );

        // calısma_tipi kolonunun gercek adini bul
        $col_stmt = $db->query("SHOW COLUMNS FROM personeller LIKE '%tisma_tipi%'");
        $col_row = $col_stmt->fetch(PDO::FETCH_ASSOC);
        $calisma_kol = $col_row ? $col_row['Field'] : 'calisma_tipi';

        $st = $db->prepare("INSERT INTO personeller
            (sicil_no, ad, soyad, tc_kimlik, dogum_tarihi, cinsiyet,
             departman_id, pozisyon, telefon, email, ise_baslama, $calisma_kol, durum, maas)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,'tam_zamanli','aktif',?)
            ON DUPLICATE KEY UPDATE durum='aktif'");
        foreach ($personeller as $p) {
            $st->execute(array($p[0],$p[1],$p[2],$p[3],$p[4],$p[5],$p[6],$p[7],$p[8],$p[9],$p[10],$p[11]));
        }
        $mesajlar[] = array(1, count($personeller) . ' personel eklendi/guncellendi');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'Personeller: ' . $e->getMessage());
    }

    // --- Musteriler ---
    try {
        $musteriler = array(
            array('ABC-001','ABC Plastik San.', '1234567890','0216 555 0001','info@abcplastik.com','Istanbul','Umraniye',   'Ahmet Polat','0532 222 0001','ahmet.polat@abcplastik.com',30),
            array('DEF-002','Demir Endustri',   '2345678901','0312 555 0002','info@demirend.com',  'Ankara',  'Yenimahalle','Cemal Demir','0533 222 0002','cemal@demirend.com',        45),
            array('XYZ-003','XYZ Makine',       '3456789012','0224 555 0003','info@xyzmakine.com', 'Bursa',   'Nilufer',    'Selim Yildiz','0534 222 0003','selim@xyzmakine.com',      30),
            array('TRK-004','Turk Metal',       '4567890123','0212 555 0004','info@turkmetal.com', 'Istanbul','Basaksehir', 'Ferhat Turk','0535 222 0004','ferhat@turkmetal.com',      60),
            array('PLS-005','Polimer Plastik',  '5678901234','0236 555 0005','info@polimer.com',   'Manisa',  'Yunusemre',  'Kahraman Can','0536 222 0005','kahraman@polimer.com',     30),
        );
        $st = $db->prepare("INSERT INTO musteriler
            (kod,ad,tip,vergi_no,telefon,email,il,ilce,yetkili_adi,yetkili_tel,yetkili_email,odeme_vadesi,durum)
            VALUES (?,'kurumsal',?,?,?,?,?,?,?,?,?,?,'aktif')
            ON DUPLICATE KEY UPDATE durum='aktif'");
        // NOT: INSERT sutun sirasi hatali, duzeltiyorum
        $st = $db->prepare("INSERT INTO musteriler
            (kod,ad,tip,vergi_no,telefon,email,il,ilce,yetkili_adi,yetkili_tel,yetkili_email,odeme_vadesi,durum)
            VALUES (?,?,'kurumsal',?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE durum='aktif'");
        foreach ($musteriler as $m) {
            $st->execute(array($m[0],$m[1],$m[2],$m[3],$m[4],$m[5],$m[6],$m[7],$m[8],$m[9],$m[10],$m[11],'aktif'));
        }
        $mesajlar[] = array(1, count($musteriler) . ' musteri eklendi/guncellendi');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'Musteriler: ' . $e->getMessage());
    }

    // --- Portal kullanicilari ---
    try {
        $db->exec("DELETE FROM portal_kullanicilari");

        // Personel portal (sicil_no = kullanici_adi)
        $per_portal = array('P-00001','P-00002','P-00003','P-00006','P-00015');
        $st = $db->prepare("INSERT INTO portal_kullanicilari
            (tip, ilgili_id, kullanici_adi, email, sifre_hash, ad_soyad, telefon, durum)
            SELECT 'personel', id, sicil_no, email, ?, CONCAT(ad,' ',soyad), telefon, 1
            FROM personeller WHERE sicil_no = ?");
        foreach ($per_portal as $sicil) {
            $st->execute(array($per_hash, $sicil));
        }
        $mesajlar[] = array(1, count($per_portal) . ' personel portal kullanicisi eklendi (Personel2024!)');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'Personel portal: ' . $e->getMessage());
    }

    try {
        // Musteri portal (kod = kullanici_adi)
        $mus_portal = array('ABC-001','DEF-002','XYZ-003','TRK-004');
        $st = $db->prepare("INSERT INTO portal_kullanicilari
            (tip, ilgili_id, kullanici_adi, email, sifre_hash, ad_soyad, telefon, durum)
            SELECT 'musteri', id, kod, yetkili_email, ?, yetkili_adi, yetkili_tel, 1
            FROM musteriler WHERE kod = ?");
        foreach ($mus_portal as $kod) {
            $st->execute(array($mus_hash, $kod));
        }
        $mesajlar[] = array(1, count($mus_portal) . ' musteri portal kullanicisi eklendi (Musteri2024!)');
    } catch (Exception $e) {
        $mesajlar[] = array(0, 'Musteri portal: ' . $e->getMessage());
    }

    // --- Kontrol ---
    $hatali = 0;
    foreach ($mesajlar as $m) { if ($m[0] == 0) $hatali++; }
    $islem_tamam = ($hatali == 0);
}

// --- Mevcut durum ---
$erp_kul = array();
$portal_kul = array();
$tablo_sayilari = array();
if ($baglanti_ok) {
    try {
        $erp_kul = $db->query("SELECT id, email, LENGTH(sifre_hash) uz, durum FROM kullanicilar ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
        $portal_kul = $db->query("SELECT tip, kullanici_adi, LENGTH(sifre_hash) uz, durum FROM portal_kullanicilari ORDER BY tip, kullanici_adi")->fetchAll(PDO::FETCH_ASSOC);
        $tbls = array('kullanicilar','personeller','musteriler','portal_kullanicilari','urunler');
        foreach ($tbls as $t) {
            try { $tablo_sayilari[$t] = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn(); }
            catch(Exception $e) { $tablo_sayilari[$t] = 'HATA'; }
        }
    } catch(Exception $e) {}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Giris Test</title>
<style>
body{font-family:Arial,sans-serif;background:#111;color:#ccc;padding:20px;font-size:13px}
h1{color:#f97316;font-size:16px}h2{color:#58a6ff;font-size:13px;margin:16px 0 6px;border-bottom:1px solid #333;padding-bottom:3px}
.ok{color:#3fb950;font-weight:bold}.hata{color:#f85149;font-weight:bold}
.uyari{background:#3d1a00;border:1px solid #f97316;border-radius:6px;padding:10px;margin:8px 0;color:#f97316}
.basari{background:#0d2818;border:1px solid #3fb950;border-radius:6px;padding:10px;margin:8px 0;color:#3fb950}
table{width:100%;border-collapse:collapse;margin-bottom:10px}
th{background:#1a1a1a;color:#888;padding:5px 8px;border:1px solid #333;text-align:left;font-size:11px}
td{padding:5px 8px;border:1px solid #333;font-size:12px}
.btn{background:#f97316;color:#fff;border:none;padding:10px 20px;border-radius:6px;cursor:pointer;font-size:14px;font-weight:bold}
.btn-yesil{background:#3fb950}.btn:hover{opacity:.85}
.kutu{background:#1a1a1a;border:1px solid #333;border-radius:6px;padding:12px;margin:8px 0}
</style>
</head>
<body>
<h1>Jetone.pro Giris Test</h1>
<div class="uyari">Bu dosyayi kullandiktan sonra silin: <strong>giris_test.php</strong></div>

<!-- Baglanti durumu -->
<?php if (!$baglanti_ok): ?>
<div class="uyari"><strong>Veritabani baglanti hatasi:</strong><br><?php echo htmlspecialchars($baglanti_hata); ?></div>
<?php else: ?>
<div class="basari">Veritabani baglantisi basarili (<?php echo $db_adi; ?>)</div>
<?php endif; ?>

<!-- Islem sonuclari -->
<?php if (!empty($mesajlar)): ?>
<h2>Islem Sonuclari</h2>
<?php
$hatali = 0;
foreach ($mesajlar as $m) { if ($m[0] == 0) $hatali++; }
?>
<div class="<?php echo $hatali == 0 ? 'basari' : 'uyari'; ?>">
    <?php echo $hatali == 0 ? 'Tum islemler basarili!' : $hatali . ' hata olustu'; ?>
</div>
<table>
<tr><th>Durum</th><th>Mesaj</th></tr>
<?php foreach ($mesajlar as $m): ?>
<tr>
    <td class="<?php echo $m[0] ? 'ok' : 'hata'; ?>"><?php echo $m[0] ? 'OK' : 'HATA'; ?></td>
    <td><?php echo htmlspecialchars($m[1]); ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

<!-- Giris bilgileri (islem tamam ise goster) -->
<?php if ($islem_tamam): ?>
<div class="basari">
<strong>Giris Bilgileri:</strong><br><br>
ERP Yonetim (giris.php):<br>
&nbsp;&nbsp;admin@jetone.pro / Admin123!<br>
&nbsp;&nbsp;ayse.yilmaz@jetone.pro / Jetone2024!<br><br>
Personel Portal (portal/personel/giris.php):<br>
&nbsp;&nbsp;P-00001 / Personel2024!<br>
&nbsp;&nbsp;P-00002 / Personel2024!<br>
&nbsp;&nbsp;P-00003 / Personel2024!<br><br>
Musteri Portal (portal/musteri/giris.php):<br>
&nbsp;&nbsp;ABC-001 / Musteri2024!<br>
&nbsp;&nbsp;DEF-002 / Musteri2024!<br>
&nbsp;&nbsp;XYZ-003 / Musteri2024!
</div>
<?php endif; ?>

<!-- Mevcut durum -->
<?php if ($baglanti_ok): ?>
<h2>Tablo Kayit Sayilari</h2>
<table>
<tr><th>Tablo</th><th>Kayit</th></tr>
<?php foreach ($tablo_sayilari as $t => $n): ?>
<tr><td><?php echo $t; ?></td><td><strong><?php echo $n; ?></strong></td></tr>
<?php endforeach; ?>
</table>

<h2>ERP Kullanicilari (kullanicilar tablosu)</h2>
<table>
<tr><th>ID</th><th>Email</th><th>Hash Uzunlugu</th><th>Durum</th></tr>
<?php foreach ($erp_kul as $u): ?>
<tr>
    <td><?php echo $u['id']; ?></td>
    <td><?php echo htmlspecialchars($u['email']); ?></td>
    <td class="<?php echo $u['uz'] == 60 ? 'ok' : 'hata'; ?>"><?php echo $u['uz']; ?> <?php echo $u['uz'] == 60 ? '(BCRYPT OK)' : '(YANLIS)'; ?></td>
    <td class="<?php echo $u['durum'] ? 'ok' : 'hata'; ?>"><?php echo $u['durum'] ? 'Aktif' : 'Pasif'; ?></td>
</tr>
<?php endforeach; ?>
</table>

<h2>Portal Kullanicilari</h2>
<table>
<tr><th>Tip</th><th>Kullanici Adi</th><th>Hash Uz.</th><th>Durum</th></tr>
<?php foreach ($portal_kul as $u): ?>
<tr>
    <td><?php echo $u['tip']; ?></td>
    <td><?php echo htmlspecialchars($u['kullanici_adi']); ?></td>
    <td class="<?php echo $u['uz'] == 60 ? 'ok' : 'hata'; ?>"><?php echo $u['uz']; ?> <?php echo $u['uz'] == 60 ? '(OK)' : '(YANLIS)'; ?></td>
    <td class="<?php echo $u['durum'] ? 'ok' : 'hata'; ?>"><?php echo $u['durum'] ? 'Aktif' : 'Pasif'; ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

<!-- Ana buton -->
<?php if ($baglanti_ok && !$islem_tamam): ?>
<h2>Guncelleme</h2>
<div class="kutu">
<form method="POST">
<input type="hidden" name="guncelle" value="1">
<button type="submit" class="btn btn-yesil" onclick="return confirm('Veritabani guncellenecek. Emin misiniz?')">
Tum Sifreler Guncelle + Veri Ekle
</button>
</form>
</div>
<?php endif; ?>

</body>
</html>
