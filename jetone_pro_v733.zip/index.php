<?php
/**
 * JETONE.PRO — Ana Giriş Noktası
 * index.php
 */
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';
require_once __DIR__ . '/core/auth.php';

if (Auth::girisYapilmisMi()) {
    header('Location: ' . BASE_URL . '/panel.php');
} else {
    header('Location: ' . BASE_URL . '/giris.php');
}
exit;
