<?php
/**
 * JETONE.PRO — Kalibrasyon Cihaz Detayı + Sertifika Geçmişi
 * panel.php: 'kalite-kalibrasyon-detay' => 'bolumler/kalite/kalibrasyon_detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<p>Geçersiz ID</p>'; exit; }

$c = $db->prepare("SELECT * FROM kalibrasyon_cihazlar WHERE id=?");
$c->execute([$id]);
$cihaz = $c->fetch(PDO::FETCH_ASSOC);
if (!$cihaz) { echo '<p>Cihaz bulunamadı</p>'; exit; }

// Kalibrasyon geçmişi
try {
    $st = $db->prepare("SELECT * FROM kalibrasyon_kayitlar WHERE cihaz_id=? ORDER BY kalibrasyon_tarihi DESC");
    $st->execute([$id]);
    $gecmis = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $gecmis = []; }

$bugun = date('Y-m-d');
$kalan = $cihaz['sonraki_kalibrasyon'] ? (int)round((strtotime($cihaz['sonraki_kalibrasyon'])-time())/86400) : null;
$durum_stil = ['OKEY'=>['#D1FAE5','#065F46'],'ARIZALI'=>['#FEE2E2','#991B1B'],'KULLANIM DIŞI'=>['#F1F5F9','#64748B'],'KAYIP'=>['#FEF9C3','#92400E']];
[$d_bg,$d_fg] = $durum_stil[$cihaz['durum']] ?? ['#F1F5F9','#334155'];

function ns($v,$d='—'){ $v=trim($v??''); return htmlspecialchars($v!==''?$v:$d); }
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚙️ <?= ns($cihaz['kayit_no']) ?> — Cihaz Detayı</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" style="color:var(--t)">Kalibrasyon</a> / <b><?= ns($cihaz['kayit_no']) ?></b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-guncelle&id=<?= $id ?>" class="btn btn-t btn-sm">✏️ Güncelle</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-kayit-ekle&cihaz_id=<?= $id ?>" class="btn btn-b btn-sm">+ Kalibrasyon Kaydı Ekle</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" class="btn btn-b btn-sm">← Liste</a>
  </div>
</div>

<div class="s-body">

<!-- Cihaz bilgi kartı -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
  <div class="kart" style="border-top:4px solid var(--t)">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:10px">Cihaz Bilgileri</div>
    <div style="font-size:18px;font-weight:900;color:var(--t)"><?= ns($cihaz['kayit_no']) ?></div>
    <div style="font-size:14px;font-weight:700;margin:4px 0 12px"><?= ns($cihaz['cihaz_adi']) ?></div>
    <div style="display:flex;flex-direction:column;gap:7px;font-size:12.5px">
      <?php foreach ([
        ['Marka/Model', $cihaz['marka_model']],
        ['Ölçüm Aralığı', $cihaz['olcum_araligi']],
        ['Hassasiyet', $cihaz['hassasiyet']],
        ['Kullanım Bölümü', $cihaz['kullanim_bolumu']],
        ['Kalibrasyon Periyodu', $cihaz['periyot_gun'].' gün'],
        ['Yapan Firma', $cihaz['yapan_firma']],
        ['Değerlendirme', $cihaz['degerlendirme']],
      ] as [$lbl,$val]): ?>
      <div style="display:flex;justify-content:space-between;gap:8px;border-bottom:1px solid var(--kenar);padding-bottom:5px">
        <span style="color:var(--m2)"><?= $lbl ?></span>
        <span style="font-weight:700;text-align:right"><?= ns($val) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="kart" style="border-top:4px solid <?= $kalan!==null&&$kalan<0?'#EF4444':($kalan!==null&&$kalan<=30?'#F59E0B':'#22C55E') ?>">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:10px">Kalibrasyon Durumu</div>

    <!-- Durum rozeti -->
    <div style="margin-bottom:14px">
      <span style="background:<?= $d_bg ?>;color:<?= $d_fg ?>;padding:4px 14px;border-radius:20px;font-size:14px;font-weight:800"><?= ns($cihaz['durum']) ?></span>
    </div>

    <!-- Kalan gün göstergesi -->
    <div style="background:var(--kenar-a);border-radius:var(--r);padding:14px;text-align:center;margin-bottom:12px">
      <?php if ($kalan === null): ?>
      <div style="font-size:28px;font-weight:900;color:var(--m2)">—</div>
      <div style="font-size:12px;color:var(--m2)">Tarih girilmemiş</div>
      <?php elseif ($kalan < 0): ?>
      <div style="font-size:28px;font-weight:900;color:#EF4444"><?= abs($kalan) ?></div>
      <div style="font-size:12px;color:#EF4444;font-weight:700">GÜN GEÇTİ — KALİBRASYON GEREKLİ!</div>
      <?php elseif ($kalan <= 30): ?>
      <div style="font-size:28px;font-weight:900;color:#F59E0B"><?= $kalan ?></div>
      <div style="font-size:12px;color:#F59E0B;font-weight:700">GÜN KALDI — YAKLAŞIYOR</div>
      <?php else: ?>
      <div style="font-size:28px;font-weight:900;color:#22C55E"><?= $kalan ?></div>
      <div style="font-size:12px;color:var(--m2)">Gün Kaldı</div>
      <?php endif; ?>
    </div>

    <div style="display:flex;flex-direction:column;gap:7px;font-size:12.5px">
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--m2)">Son Kalibrasyon</span>
        <b><?= $cihaz['son_kalibrasyon'] ? date('d.m.Y',strtotime($cihaz['son_kalibrasyon'])) : '—' ?></b>
      </div>
      <div style="display:flex;justify-content:space-between">
        <span style="color:var(--m2)">Sonraki Kalibrasyon</span>
        <b><?= $cihaz['sonraki_kalibrasyon'] ? date('d.m.Y',strtotime($cihaz['sonraki_kalibrasyon'])) : '—' ?></b>
      </div>
      <?php if ($cihaz['aciklama']): ?>
      <div style="margin-top:6px;font-size:11px;color:var(--m2);border-top:1px solid var(--kenar);padding-top:6px"><?= nl2br(htmlspecialchars($cihaz['aciklama'])) ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Kalibrasyon geçmişi + sertifikalar -->
<div class="kart" style="padding:0">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;font-size:14px">📜 Kalibrasyon Geçmişi & Sertifikalar</div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-kayit-ekle&cihaz_id=<?= $id ?>" class="btn btn-t btn-sm">+ Kayıt Ekle</a>
  </div>

  <?php if (empty($gecmis)): ?>
  <div style="padding:32px;text-align:center;color:var(--m2)">
    <div style="font-size:28px;margin-bottom:8px">📋</div>
    Henüz kalibrasyon kaydı yok.
  </div>
  <?php else: ?>
  <div style="overflow-x:auto">
    <table class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach (['Kalibrasyon Tarihi','Sonraki Tarih','Yapan Firma','Değerlendirme','Durum','Sertifika','Açıklama','Ekleyen','Tarih'] as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($gecmis as $g):
            $g_durum_stil = ['OKEY'=>['#D1FAE5','#065F46'],'ARIZALI'=>['#FEE2E2','#991B1B'],'KULLANIM DIŞI'=>['#F1F5F9','#64748B']];
            [$gd_bg,$gd_fg] = $g_durum_stil[$g['durum']] ?? ['#F1F5F9','#334155'];
        ?>
        <tr>
          <td style="white-space:nowrap;font-weight:700"><?= date('d.m.Y',strtotime($g['kalibrasyon_tarihi'])) ?></td>
          <td style="white-space:nowrap"><?= $g['sonraki_tarih'] ? date('d.m.Y',strtotime($g['sonraki_tarih'])) : '—' ?></td>
          <td><?= ns($g['yapan_firma']) ?></td>
          <td style="font-size:11px"><?= ns($g['degerlendirme']) ?></td>
          <td><span style="background:<?= $gd_bg ?>;color:<?= $gd_fg ?>;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:800"><?= ns($g['durum']) ?></span></td>
          <td>
            <?php if ($g['sertifika_dosya']): ?>
            <a href="<?= BASE_URL ?>/kys_dokumanlar/kalibrasyon/<?= htmlspecialchars($g['sertifika_dosya']) ?>"
               target="_blank" class="btn btn-sm"
               style="background:var(--bas-a);color:var(--bas);padding:3px 8px;font-size:11px;text-decoration:none">
              📎 <?= htmlspecialchars(pathinfo($g['sertifika_dosya'],PATHINFO_EXTENSION)) ?>
            </a>
            <?php else: ?>
            <span style="color:var(--m3);font-size:11px">—</span>
            <?php endif; ?>
          </td>
          <td style="font-size:11px;max-width:180px"><?= ns($g['aciklama']) ?></td>
          <td style="font-size:11px"><?= ns($g['ekleyen']) ?></td>
          <td style="font-size:11px;white-space:nowrap"><?= date('d.m.Y',strtotime($g['kayit_tarihi'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

</div>
