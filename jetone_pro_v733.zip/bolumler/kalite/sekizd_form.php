<?php
/**
 * 8D Aç / Düzenle — tüm adımlar tek formda
 * panel.php: 'kalite-8d-form' => 'bolumler/kalite/sekizd_form.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
$r  = null;
if ($id) { $s=$db->prepare("SELECT * FROM kal_sekizd WHERE id=?");$s->execute([$id]);$r=$s->fetch(PDO::FETCH_ASSOC); }
$r = $r ?: ['sekizd_no'=>'','kaynak'=>'urun_hatasi','kaynak_ref'=>'','problem_ozeti'=>'','acilis_tarihi'=>date('Y-m-d'),'hedef_tarih'=>'','durum'=>'d1','kritiklik'=>'yuksek','d1_ekip'=>'','d1_lider'=>$kul_adi,'d2_problem'=>'','d2_etkilenen_urun'=>'','d2_etkilenen_adet'=>'','d3_gecici_onlem'=>'','d3_stok_blokaj'=>'','d3_musteri_bildirim'=>'','d3_uygulama_tarihi'=>null,'d4_kok_neden'=>'','d4_kacis_nokta'=>'','d4_balik_insan'=>'','d4_balik_yontem'=>'','d4_balik_makine'=>'','d4_balik_malzeme'=>'','d4_balik_olcum'=>'','d4_balik_cevre'=>'','d5_secenekler'=>'','d5_secilen'=>'','d6_uygulama'=>'','d6_olcum_sonuc'=>'','d6_sorumlu'=>'','d6_tamamlanma'=>null,'d7_sistem_degisim'=>'','d7_egitim'=>'','d7_yayilim'=>'','d8_tebrik'=>'','d8_kapanma_onay'=>'','d8_kapanma_notu'=>''];

$mesaj=''; $mesaj_tip='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $no=trim($_POST['sekizd_no']??'');
    if(!$no){$yil=date('Y');$son=$db->query("SELECT sekizd_no FROM kal_sekizd WHERE sekizd_no LIKE '8D-{$yil}-%' ORDER BY id DESC LIMIT 1")->fetchColumn();$no=sprintf('8D-%d-%03d',$yil,$son?(int)substr($son,-3)+1:1);}

    $tum_alanlari=['sekizd_no','kaynak','kaynak_ref','problem_ozeti','acilis_tarihi','hedef_tarih','durum','kritiklik','d1_ekip','d1_lider','d2_problem','d2_etkilenen_urun','d2_etkilenen_adet','d3_gecici_onlem','d3_stok_blokaj','d3_musteri_bildirim','d3_uygulama_tarihi','d4_kok_neden','d4_kacis_nokta','d4_balik_insan','d4_balik_yontem','d4_balik_makine','d4_balik_malzeme','d4_balik_olcum','d4_balik_cevre','d5_secenekler','d5_secilen','d6_uygulama','d6_olcum_sonuc','d6_sorumlu','d6_tamamlanma','d7_sistem_degisim','d7_egitim','d7_yayilim','d8_tebrik','d8_kapanma_onay','d8_kapanma_notu'];
    $fields=['sekizd_no'=>$no];
    foreach($tum_alanlari as $f){if($f!='sekizd_no')$fields[$f]=($_POST[$f]??'')?:null;}
    $fields['acilis_tarihi']=$_POST['acilis_tarihi']??date('Y-m-d');
    $fields['problem_ozeti']=$_POST['problem_ozeti']??'';

    try {
        if($id){$set=implode(',',array_map(fn($k)=>"$k=?",array_keys($fields)));$db->prepare("UPDATE kal_sekizd SET $set WHERE id=?")->execute([...array_values($fields),$id]);$mesaj='Güncellendi.';$mesaj_tip='ok';$s2=$db->prepare("SELECT * FROM kal_sekizd WHERE id=?");$s2->execute([$id]);$r=$s2->fetch(PDO::FETCH_ASSOC);}
        else{$fields['olusturan']=$kul_adi;$cols=implode(',',array_keys($fields));$vals=implode(',',array_fill(0,count($fields),'?'));$db->prepare("INSERT INTO kal_sekizd ($cols) VALUES ($vals)")->execute(array_values($fields));$id=(int)$db->lastInsertId();echo "<script>window.location.href=".json_encode(BASE_URL.'/panel.php?sayfa=kalite-8d-detay&id='.$id).";</script>";exit;}
    } catch(Throwable $e){$mesaj='Hata: '.$e->getMessage();$mesaj_tip='hata';}
}

function ta($n,$v,$p='',$rows=3){return "<textarea name=\"$n\" class=\"form-alan\" rows=\"$rows\" style=\"width:100%;resize:vertical\" placeholder=\"$p\">".htmlspecialchars($v??"")."</textarea>";}
function inp($n,$v,$p=''){return "<input name=\"$n\" class=\"form-alan\" value=\"".htmlspecialchars($v??"")."\" placeholder=\"$p\">";}

$adimlar_aktif=array_keys(array_filter(['d1'=>1,'d2'=>1,'d3'=>1,'d4'=>1,'d5'=>1,'d6'=>1,'d7'=>1,'d8'=>1],fn($v)=>$v));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?=$id?'✏️ 8D Düzenle':'+ Yeni 8D Aç'?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d" style="color:var(--t)">8D</a> / <b><?=$id?'Düzenle':'Yeni'?></b></div>
  </div>
  <?php if($id): ?><a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-detay&id=<?=$id?>" class="btn btn-b btn-sm">← Detay</a><?php endif; ?>
</div>
<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>
<div style="max-width:900px">
<form method="POST">

<!-- Kimlik -->
<div class="kart" style="padding:16px;margin-bottom:10px">
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
    <div><label class="form-et">8D No <span style="font-size:10px;color:var(--m3)">(boş=otomatik)</span></label><?=inp('sekizd_no',$r['sekizd_no'],'8D-2026-001')?></div>
    <div><label class="form-et">Açılış Tarihi</label><input type="date" name="acilis_tarihi" class="form-alan" value="<?=htmlspecialchars($r['acilis_tarihi'])?>"></div>
    <div><label class="form-et">Hedef Kapanış</label><input type="date" name="hedef_tarih" class="form-alan" value="<?=htmlspecialchars($r['hedef_tarih']??'')?>"></div>
    <div><label class="form-et">Kaynak</label><select name="kaynak" class="form-alan">
      <?php foreach(['musteri_sikayet'=>'Müşteri Şikayeti','ic_denetim'=>'İç Denetim','urun_hatasi'=>'Ürün Hatası','proses_hatasi'=>'Proses Hatası','tedarikci'=>'Tedarikçi','diger'=>'Diğer'] as $v=>$l): ?>
      <option value="<?=$v?>" <?=$r['kaynak']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?></select></div>
    <div><label class="form-et">Kritiklik</label><select name="kritiklik" class="form-alan">
      <?php foreach(['dusuk'=>'Düşük','orta'=>'Orta','yuksek'=>'Yüksek','kritik'=>'KRİTİK'] as $v=>$l): ?>
      <option value="<?=$v?>" <?=$r['kritiklik']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?></select></div>
    <div><label class="form-et">Mevcut Adım</label><select name="durum" class="form-alan">
      <?php foreach(['d1'=>'D1 - Ekip','d2'=>'D2 - Problem','d3'=>'D3 - Koruma','d4'=>'D4 - Kök Neden','d5'=>'D5 - Seçim','d6'=>'D6 - Uygulama','d7'=>'D7 - Önleme','d8'=>'D8 - Kapanış','kapandi'=>'Kapandı','iptal'=>'İptal'] as $v=>$l): ?>
      <option value="<?=$v?>" <?=$r['durum']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?></select></div>
    <div class="c3"><label class="form-et">Problem Özeti <span style="color:#EF4444">*</span></label><input name="problem_ozeti" class="form-alan" required value="<?=htmlspecialchars($r['problem_ozeti'])?>" style="width:100%"></div>
    <div><label class="form-et">Kaynak Ref No</label><?=inp('kaynak_ref',$r['kaynak_ref']??'')?></div>
  </div>
</div>

<?php
$adim_bloklar = [
  'D1'=> ['renk'=>'#1E3A5F','ikon'=>'👥','baslik'=>'D1 — Ekibin Oluşturulması','alanlar'=>[
    ['D1 Lider','d1_lider','inp','Sorumlu kişi'],
    ['Ekip Üyeleri ve Rolleri','d1_ekip','ta','Ad - Rol - Bölüm (her satıra bir kişi)...'],
  ]],
  'D2'=> ['renk'=>'#DC2626','ikon'=>'🔬','baslik'=>'D2 — Problemin Tanımlanması (5N1K + Etki)','alanlar'=>[
    ['Problem Teknik Detayı (5N1K)','d2_problem','ta','Kim, Ne, Nerede, Ne Zaman, Nasıl, Ne Kadar...'],
    ['Etkilenen Ürün/Parça No','d2_etkilenen_urun','inp',''],
    ['Etkilenen Adet/Lot','d2_etkilenen_adet','inp',''],
  ]],
  'D3'=> ['renk'=>'#F59E0B','ikon'=>'🚧','baslik'=>'D3 — Geçici Koruma Aksiyonları','alanlar'=>[
    ['Acil Koruma Önlemleri','d3_gecici_onlem','ta','%100 kontrol, karantina, hattı durdurma...'],
    ['Stok Blokaj Detayı','d3_stok_blokaj','ta','Hangi stoklar bloke edildi?'],
    ['Müşteri Bildirim','d3_musteri_bildirim','ta','Müşteriye ne bildirildi?'],
  ]],
  'D4'=> ['renk'=>'#0EA5E9','ikon'=>'🐟','baslik'=>'D4 — Kök Neden Analizi ve Kaçış Noktası','alanlar'=>[
    ['5 Neden Analizi','d4_kok_neden','ta','1. Neden? → ...\n2. Neden? → ...\n3. Neden? → ...\n4. Neden? → ...\n5. Kök Neden → ...'],
    ['Kaçış Noktası (Neden Fark Edilmedi?)','d4_kacis_nokta','ta','Kontrol sistemi neden bu hatayı yakalamadı?'],
    ['Balık - İnsan','d4_balik_insan','ta',''],
    ['Balık - Yöntem','d4_balik_yontem','ta',''],
    ['Balık - Makine','d4_balik_makine','ta',''],
    ['Balık - Malzeme','d4_balik_malzeme','ta',''],
    ['Balık - Ölçüm','d4_balik_olcum','ta',''],
    ['Balık - Çevre','d4_balik_cevre','ta',''],
  ]],
  'D5'=> ['renk'=>'#7C3AED','ikon'=>'🎯','baslik'=>'D5 — Kalıcı Düzeltici Faaliyetlerin Seçilmesi','alanlar'=>[
    ['Değerlendirilen Seçenekler','d5_secenekler','ta','Seçenek 1: ...\nSeçenek 2: ...\nSeçenek 3: ...'],
    ['Seçilen Çözüm ve Gerekçe','d5_secilen','ta','Neden bu seçenek seçildi?'],
  ]],
  'D6'=> ['renk'=>'#16A34A','ikon'=>'⚙️','baslik'=>'D6 — Kalıcı Düzeltici Faaliyetin Uygulanması','alanlar'=>[
    ['Uygulama Detayı','d6_uygulama','ta','Yapılan değişiklikler, prosedür güncellemeleri...'],
    ['Ölçüm ve Doğrulama Sonuçları','d6_olcum_sonuc','ta','Uygulama sonrası ölçüm sonuçları...'],
    ['Sorumlu','d6_sorumlu','inp',''],
  ]],
  'D7'=> ['renk'=>'#0F766E','ikon'=>'🛡️','baslik'=>'D7 — Tekrarın Önlenmesi (Sistemik Değişim)','alanlar'=>[
    ['Sistem/Prosedür Değişiklikleri','d7_sistem_degisim','ta','Güncellenen dokümanlar, standartlar...'],
    ['Eğitim Planı','d7_egitim','ta','Kime, ne zaman, hangi eğitim?'],
    ['Benzer Süreçlere Yayılım','d7_yayilim','ta','Bu ders hangi diğer süreçlere uygulanacak?'],
  ]],
  'D8'=> ['renk'=>'#6366F1','ikon'=>'🎉','baslik'=>'D8 — Ekibin Tebriği ve Dosya Kapanışı','alanlar'=>[
    ['Öğrenilen Dersler ve Ekip Tebriği','d8_tebrik','ta','Bu 8D sürecinden neler öğrendik?'],
    ['Kapanış Onaylayan','d8_kapanma_onay','inp',''],
    ['Kapanış Notu','d8_kapanma_notu','ta',''],
  ]],
];
?>

<?php foreach ($adim_bloklar as $adim=>$blok): ?>
<div class="kart" style="padding:16px;margin-bottom:10px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid <?=$blok['renk']?>;color:<?=$blok['renk']?>">
    <?=$blok['ikon']?> <?=$blok['baslik']?>
  </div>
  <?php
  $cols = count($blok['alanlar']) <= 1 ? 1 : (count($blok['alanlar']) <= 3 ? count($blok['alanlar']) : 2);
  $grid_cols = $cols == 1 ? '1fr' : ($cols == 3 ? '1fr 1fr 1fr' : '1fr 1fr');
  ?>
  <div style="display:grid;grid-template-columns:<?=$grid_cols?>;gap:12px">
  <?php foreach($blok['alanlar'] as $alan): ?>
  <div>
    <label class="form-et" style="font-size:11px"><?=$alan[0]?></label>
    <?php if($alan[2]==='inp'): ?><?=inp($alan[1],$r[$alan[1]]??'',$alan[3]??'')?>
    <?php else: ?><?=ta($alan[1],$r[$alan[1]]??'',$alan[3]??'',$blok['renk']===$adim_bloklar['D4']['renk']?3:2)?><?php endif; ?>
  </div>
  <?php endforeach; ?>
  </div>
</div>
<?php endforeach; ?>

<div style="display:flex;gap:8px;justify-content:flex-end">
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d" class="btn btn-b">İptal</a>
  <button type="submit" class="btn btn-t">💾 <?=$id?'Güncelle':'8D Aç'?></button>
</div>
</form>
</div>
</div>
<style>.c3{grid-column:span 3}</style>
