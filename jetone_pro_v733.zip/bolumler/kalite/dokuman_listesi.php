<?php
/**
 * JETONE.PRO — KYS Doküman Listesi (Aktif)
 * bolumler/kalite/dokuman_listesi.php
 * panel.php: 'kalite-dokuman-listesi' => 'bolumler/kalite/dokuman_listesi.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_isim = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// Kategori türleri
$turler = [
    'formlar'       => 'FORMLAR',
    'listeler'      => 'LİSTELER',
    'sunumlar'      => 'SUNUMLAR',
    'planlar'       => 'PLANLAR',
    'talimatlar'    => 'GENEL TALİMATLAR',
    'mak_talimatlar'=> 'MAKİNA TALİMATLARI',
    'semalar'       => 'ŞEMALAR',
    'el kitapları'  => 'EL KİTAPLARI',
    'sürecler'      => 'SÜREÇLER',
    'dkd'           => 'DKD',
    'prosedürler'   => 'PROSEDÜRLER',
    'tablolar'      => 'TABLOLAR',
    'standart'      => 'STANDART',
    'raporlar'      => 'RAPORLAR',
    'kalibrasyon'   => 'KALİBRASYON',
    'atamalar'      => 'ATAMA',
    'politikalar'   => 'POLİTİKALARIMIZ',
    'taahütname'    => 'TAAHÜTNAME',
];

$secili_tur = $_GET['kategori'] ?? 'formlar';
if (!array_key_exists($secili_tur, $turler)) $secili_tur = 'formlar';

// Yeni döküman POST
if (isset($_POST['dokuman_ekle'])) {
    $tur      = trim($_POST['tur']       ?? '');
    $dok_adi  = trim($_POST['dok_adi']   ?? '');
    $dok_no   = trim($_POST['dok_no']    ?? '');
    $ref      = trim($_POST['ref_madde'] ?? '');
    $ekleyen  = $kul_isim;

    $dok_yol  = null;
    if (!empty($_FILES['dok_yol']['name']) && $_FILES['dok_yol']['error'] === 0) {
        $dir = dirname(dirname(__DIR__)) . '/kys_dökümanlar/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $orijinal = $_FILES['dok_yol']['name'];
        $fname = rand(10000,99999) . rand(10000,99999) . preg_replace('/[^a-zA-Z0-9._\-]/', '', $orijinal);
        if (move_uploaded_file($_FILES['dok_yol']['tmp_name'], $dir . $fname)) {
            $dok_yol = 'kys_dökümanlar/' . $fname;
        }
    }

    try {
        $db->prepare("INSERT INTO dokuman_listesi (tür,dok_yol,dok_adi,ref_madde,dok_no,durum,ekleyen)
            VALUES (?,?,?,?,?,'Aktif',?)")
        ->execute([$tur, $dok_yol, $dok_adi, $ref, $dok_no, $ekleyen]);
    } catch (Throwable $e) {}

    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-dokuman-listesi&kategori=' . urlencode($tur) . '";</script>'; exit;
}

// Veri çek
try {
    $st = $db->prepare("SELECT * FROM dokuman_listesi WHERE tür=? AND durum='Aktif' ORDER BY dok_no ASC");
    $st->execute([$secili_tur]);
    $dokuman_rows = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $dokuman_rows = []; }

$durum_msg = $_GET['durum'] ?? '';
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📄 KYS Doküman Listesi</h1>
    <div class="s-yol">Kalite / <b>Doküman Listesi</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-listesi-pasif" class="btn btn-b btn-sm">📦 Pasifler</a>
    <button onclick="document.getElementById('dokEkleModal').style.display='flex'" class="btn btn-t btn-sm">+ Doküman Ekle</button>
  </div>
</div>

<div class="s-body">

<?php if ($durum_msg === 'ok'): ?>
<div style="background:var(--bas-a);color:var(--bas);border-radius:var(--r);padding:10px 14px;margin-bottom:12px;font-weight:700">✅ İşlem başarıyla tamamlandı.</div>
<?php endif; ?>

<!-- Kategori seç -->
<div class="kart" style="margin-bottom:14px;padding:12px">
  <div style="display:flex;gap:6px;flex-wrap:wrap">
    <?php foreach ($turler as $k => $v): ?>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-listesi&kategori=<?= urlencode($k) ?>"
       style="padding:5px 12px;border-radius:20px;font-size:12px;font-weight:700;text-decoration:none;
              background:<?= $secili_tur===$k?'#1E3A5F':'var(--kenar-a)' ?>;
              color:<?= $secili_tur===$k?'#fff':'var(--m)' ?>;
              border:1.5px solid <?= $secili_tur===$k?'#1E3A5F':'var(--kenar)' ?>">
      <?= $v ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:14px">
    📂 <?= $turler[$secili_tur] ?> <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($dokuman_rows) ?></span>
  </div>
  <div style="overflow-x:auto">
    <?php $sth = ['#','İşlemler','Durum','Doküman No','Doküman Adı','Ref. Madde','Rev. No','Rev. Tarihi','Rev. Eden']; ?>
    <table id="dokumanTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php foreach ($dokuman_rows as $i => $r): ?>
        <tr>
          <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
          <td style="white-space:nowrap">
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-duzenle&id=<?= $r['id'] ?>"
               class="btn btn-sm" style="background:var(--bas-a);color:var(--bas);padding:3px 8px;font-size:11px;text-decoration:none">✏️</a>
            <?php if ($r['dok_yol']): ?>
            <a href="<?= BASE_URL ?>/<?= htmlspecialchars(dirname($r['dok_yol']) . '/' . rawurlencode(basename($r['dok_yol']))) ?>" target="_blank" download
               class="btn btn-sm" style="background:var(--bil-a);color:var(--bil);padding:3px 8px;font-size:11px;text-decoration:none">⬇</a>
            <?php endif; ?>
            <form method="POST" action="<?= BASE_URL ?>/islemler/kalite/dokuman_sil.php" style="display:inline"
                  onsubmit="return confirm('Kaydı silmek istiyor musunuz?')">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <input type="hidden" name="tur" value="<?= htmlspecialchars($r['tür']) ?>">
              <button type="submit" class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
            </form>
          </td>
          <td><span style="background:var(--bas-a);color:var(--bas);padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700"><?= htmlspecialchars($r['durum']) ?></span></td>
          <td style="font-family:monospace;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['dok_no']??'') ?></td>
          <td style="max-width:280px"><?= htmlspecialchars($r['dok_adi']??'') ?></td>
          <td style="font-size:12px"><?= htmlspecialchars($r['ref_madde']??'') ?></td>
          <td style="text-align:center"><?= htmlspecialchars($r['revize_no']??'00') ?></td>
          <td style="white-space:nowrap;font-size:12px"><?= $r['revize_tarih'] ? date('d.m.Y',strtotime($r['revize_tarih'])) : '—' ?></td>
          <td style="font-size:12px"><?= htmlspecialchars($r['revize_eden']??'') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</div>

<!-- Döküman Ekle Modal -->
<div id="dokEkleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:12px;width:95%;max-width:480px;padding:20px;max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
      <div style="font-size:15px;font-weight:800">📄 Doküman Ekle</div>
      <button onclick="document.getElementById('dokEkleModal').style.display='none'"
              style="background:var(--kenar-a);border:none;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:16px">✕</button>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="dokuman_ekle" value="1">

      <div class="form-grup">
        <label class="form-et">Kategori / Tür <span class="zorunlu">*</span></label>
        <select class="form-alan" name="tur" required>
          <?php foreach ($turler as $k => $v): ?>
          <option value="<?= $k ?>" <?= $secili_tur===$k?'selected':'' ?>><?= $v ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-grup">
        <label class="form-et">Doküman No</label>
        <input class="form-alan" type="text" name="dok_no" placeholder="FR.01, LST.01...">
      </div>

      <div class="form-grup">
        <label class="form-et">Ref. Madde</label>
        <input class="form-alan" type="text" name="ref_madde" placeholder="7.5, 8.7...">
      </div>

      <div class="form-grup">
        <label class="form-et">Doküman Adı <span class="zorunlu">*</span></label>
        <textarea class="form-alan" name="dok_adi" rows="2" required placeholder="Doküman adını giriniz..."></textarea>
      </div>

      <div class="form-grup">
        <label class="form-et">Dosya Yükle (PDF/Word/Excel/Görsel)</label>
        <input class="form-alan" type="file" name="dok_yol"
               accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
               style="padding:6px">
      </div>

      <div class="form-footer">
        <button type="button" onclick="document.getElementById('dokEkleModal').style.display='none'" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script>
$(document).ready(function(){
  var tbl = $('#dokumanTablo').DataTable({
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollX:true, scrollY:480, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',filename:'Dokuman_<?= date('Ymd') ?>'},
      {extend:'print',text:'🖨 Yazdır'}
    ],
    drawCallback:function(){
      $('#dokumanTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); });
    },
    initComplete:function(){
      this.api().columns([2,3,6]).every(function(){
        var col=this, sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
        col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); });
      });
      $('#dokumanTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); });
    }
  });
});
</script>
