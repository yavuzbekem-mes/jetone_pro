<?php
/**
 * JETONE.PRO — KYS Doküman Düzenle
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul      = Auth::kullanici();
$kul_isim = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<p>Geçersiz ID</p>'; exit; }

$st = $db->prepare("SELECT * FROM dokuman_listesi WHERE id=?");
$st->execute([$id]);
$d = $st->fetch(PDO::FETCH_ASSOC);
if (!$d) { echo '<p>Kayıt bulunamadı</p>'; exit; }

$turler = [
    'formlar'=>'FORMLAR','listeler'=>'LİSTELER','sunumlar'=>'SUNUMLAR','planlar'=>'PLANLAR',
    'talimatlar'=>'GENEL TALİMATLAR','mak_talimatlar'=>'MAKİNA TALİMATLARI','semalar'=>'ŞEMALAR',
    'el kitapları'=>'EL KİTAPLARI','sürecler'=>'SÜREÇLER','dkd'=>'DKD','prosedürler'=>'PROSEDÜRLER',
    'tablolar'=>'TABLOLAR','standart'=>'STANDART','raporlar'=>'RAPORLAR','kalibrasyon'=>'KALİBRASYON',
    'atamalar'=>'ATAMA','politikalar'=>'POLİTİKALARIMIZ','taahütname'=>'TAAHÜTNAME',
];

function ns($v){ return htmlspecialchars(trim($v??'')); }
function vt($t){ return (!empty($t) && $t!=='0000-00-00') ? date('Y-m-d', strtotime($t)) : ''; }

$dok_yol      = trim($d['dok_yol'] ?? '');
$ext          = strtolower(pathinfo($dok_yol, PATHINFO_EXTENSION));
$download_url = '';

if ($dok_yol) {
    $klasor       = dirname($dok_yol);
    $dosya_adi    = basename($dok_yol);
    $download_url = BASE_URL . '/' . $klasor . '/' . rawurlencode($dosya_adi);
}

$geri_url = BASE_URL . '/panel.php?sayfa=kalite-dokuman-listesi&kategori=' . urlencode($d['tür'] ?? 'formlar');

// Görüntüleyici tipi
$viewer_type = '';
if ($ext === 'pdf')                                        $viewer_type = 'pdf';
elseif (in_array($ext, ['xls','xlsx']))                    $viewer_type = 'excel';
elseif (in_array($ext, ['doc','docx']))                    $viewer_type = 'word';
elseif (in_array($ext, ['jpg','jpeg','png','gif','webp'])) $viewer_type = 'img';
elseif (in_array($ext, ['ppt','pptx']))                    $viewer_type = 'ppt';
?>
<style>
.dok-grid{display:grid;grid-template-columns:360px 1fr;gap:16px;align-items:start}
@media(max-width:900px){.dok-grid{grid-template-columns:1fr}}
#viewer-area{min-height:640px;background:var(--kenar-a);display:flex;align-items:center;justify-content:center}
#viewer-area iframe,#viewer-area canvas{width:100%;display:block}
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">✏️ Doküman Düzenle</h1>
    <div class="s-yol">Kalite /
      <a href="<?= $geri_url ?>" style="color:var(--t)">Doküman Listesi</a> /
      <b><?= ns($d['dok_no']) ?></b>
    </div>
  </div>
  <a href="<?= $geri_url ?>" class="btn btn-b btn-sm">← Listeye Dön</a>
</div>

<div class="s-body">
<div class="dok-grid">

  <!-- ── SOL: Form ─────────────────────────────────────── -->
  <div class="kart">
    <div style="font-size:13px;font-weight:800;margin-bottom:14px">📋 Doküman Bilgileri</div>
    <form action="<?= BASE_URL ?>/islemler/kalite/dokuman_guncelle.php"
          method="POST" enctype="multipart/form-data">
      <input type="hidden" name="id"             value="<?= $id ?>">
      <input type="hidden" name="mevcut_dok_yol" value="<?= ns($dok_yol) ?>">

      <div class="form-grup">
        <label class="form-et">Doküman No</label>
        <input class="form-alan" type="text" name="dok_no" value="<?= ns($d['dok_no']) ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Doküman Adı</label>
        <textarea class="form-alan" name="dok_adi" rows="2"><?= ns($d['dok_adi']) ?></textarea>
      </div>
      <div class="form-grup">
        <label class="form-et">Ref. Madde</label>
        <input class="form-alan" type="text" name="ref_madde" value="<?= ns($d['ref_madde']) ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Tür</label>
        <select class="form-alan" name="tur">
          <?php foreach ($turler as $k=>$v): ?>
          <option value="<?= $k ?>" <?= ($d['tür']??'')===$k?'selected':'' ?>><?= $v ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-grup">
        <label class="form-et">Durum</label>
        <select class="form-alan" name="durum">
          <option value="Aktif" <?= ($d['durum']??'')==='Aktif'?'selected':'' ?>>AKTİF</option>
          <option value="Pasif" <?= ($d['durum']??'')==='Pasif'?'selected':'' ?>>PASİF</option>
        </select>
      </div>

      <div style="border-top:1px solid var(--kenar);margin:12px 0;padding-top:12px">
        <div style="font-size:11px;font-weight:800;margin-bottom:8px;color:var(--m2);text-transform:uppercase">Revizyon Bilgileri</div>
        <div class="form-grup">
          <label class="form-et">Rev. No</label>
          <input class="form-alan" type="text" name="revize_no" value="<?= ns($d['revize_no']) ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Rev. Tarihi</label>
          <input class="form-alan" type="date" name="revize_tarih" value="<?= vt($d['revize_tarih']) ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Rev. Eden</label>
          <input class="form-alan" type="text" name="revize_eden"
                 value="<?= ns($d['revize_eden']) ?>" placeholder="<?= ns($kul_isim) ?>">
        </div>
      </div>

      <div style="border-top:1px solid var(--kenar);margin:12px 0;padding-top:12px">
        <div style="font-size:11px;font-weight:800;margin-bottom:8px;color:var(--m2);text-transform:uppercase">Dosya (opsiyonel)</div>
        <?php if ($dok_yol): ?>
        <div style="margin-bottom:8px;font-size:12px;color:var(--m2)">
          Mevcut: <a href="<?= htmlspecialchars($download_url) ?>" target="_blank"
                    style="color:var(--t);word-break:break-all"><?= htmlspecialchars(basename($dok_yol)) ?></a>
        </div>
        <?php endif; ?>
        <label class="form-et">Yeni Dosya (boş bırakılırsa mevcut korunur)</label>
        <input class="form-alan" type="file" name="dok_yol"
               accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.png,.jpg,.jpeg,.webp"
               style="padding:6px">
      </div>

      <div class="form-footer">
        <a href="<?= $geri_url ?>" class="btn btn-b btn-sm">İptal</a>
        <button type="submit" class="btn btn-t btn-sm">💾 Güncelle</button>
      </div>
    </form>
  </div><!-- /sol -->

  <!-- ── SAĞ: Önizleme ─────────────────────────────────── -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);
                display:flex;align-items:center;justify-content:space-between;gap:8px">
      <div style="font-weight:700;font-size:13px">🔍 Doküman Önizleme</div>
      <?php if ($download_url): ?>
      <a href="<?= htmlspecialchars($download_url) ?>" target="_blank"
         class="btn btn-t btn-sm">⬇ İndir / Aç</a>
      <?php endif; ?>
    </div>

    <div id="viewer-area" style="min-height:640px">
      <?php if (!$dok_yol): ?>
        <div style="text-align:center;color:var(--m2)">
          <div style="font-size:40px;margin-bottom:10px">📄</div>Dosya yüklenmemiş.
        </div>
      <?php elseif ($viewer_type === 'img'): ?>
        <img src="<?= htmlspecialchars($download_url) ?>"
             style="max-width:100%;max-height:640px;object-fit:contain;padding:16px">
      <?php elseif ($viewer_type === 'pdf'): ?>
        <!-- PDF.js ile göster -->
        <div id="pdf-viewer" style="width:100%;height:640px;overflow-y:auto;padding:8px;box-sizing:border-box"></div>
      <?php elseif (in_array($viewer_type, ['excel'])): ?>
        <!-- SheetJS ile göster -->
        <div id="excel-viewer" style="width:100%;height:640px;overflow:auto;padding:8px;box-sizing:border-box;font-size:12px"></div>
      <?php elseif ($viewer_type === 'word'): ?>
        <!-- Mammoth.js ile göster -->
        <div id="word-viewer" style="width:100%;height:640px;overflow-y:auto;padding:16px;box-sizing:border-box;font-size:13px;line-height:1.6"></div>
      <?php elseif ($viewer_type === 'ppt'): ?>
        <div style="text-align:center;padding:48px;color:var(--m2)">
          <div style="font-size:48px;margin-bottom:12px">📊</div>
          <div style="font-weight:700;margin-bottom:8px">PowerPoint Dosyası</div>
          <div style="font-size:12px;margin-bottom:16px"><?= htmlspecialchars(basename($dok_yol)) ?></div>
          <a href="<?= htmlspecialchars($download_url) ?>" target="_blank"
             class="btn btn-t">⬇ İndir ve Aç</a>
        </div>
      <?php else: ?>
        <div style="text-align:center;padding:48px;color:var(--m2)">
          <div style="font-size:40px;margin-bottom:10px">📎</div>
          <div style="margin-bottom:14px"><?= htmlspecialchars(basename($dok_yol)) ?></div>
          <a href="<?= htmlspecialchars($download_url) ?>" target="_blank"
             class="btn btn-t btn-sm">⬇ İndir</a>
        </div>
      <?php endif; ?>
    </div>
  </div><!-- /sağ -->

</div>
</div>

<?php if ($download_url && in_array($viewer_type, ['pdf','excel','word'])): ?>
<!-- Kütüphaneler -->
<?php if ($viewer_type === 'pdf'): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script>
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
(async function(){
  const container = document.getElementById('pdf-viewer');
  container.innerHTML = '<div style="padding:16px;color:var(--m2)">Yükleniyor...</div>';
  try {
    const pdf = await pdfjsLib.getDocument('<?= addslashes($download_url) ?>').promise;
    container.innerHTML = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page  = await pdf.getPage(i);
      const scale = (container.clientWidth - 16) / page.getViewport({scale:1}).width;
      const vp    = page.getViewport({scale});
      const canvas = document.createElement('canvas');
      canvas.style.cssText = 'display:block;margin:0 auto 8px;max-width:100%';
      canvas.width  = vp.width;
      canvas.height = vp.height;
      await page.render({canvasContext: canvas.getContext('2d'), viewport: vp}).promise;
      container.appendChild(canvas);
    }
  } catch(e) {
    container.innerHTML = '<div style="padding:24px;text-align:center;color:#EF4444">PDF yüklenemedi: ' + e.message + '</div>';
  }
})();
</script>

<?php elseif ($viewer_type === 'excel'): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
(async function(){
  const container = document.getElementById('excel-viewer');
  container.innerHTML = '<div style="padding:16px;color:var(--m2)">Yükleniyor...</div>';
  try {
    const res  = await fetch('<?= addslashes($download_url) ?>');
    const buf  = await res.arrayBuffer();
    const wb   = XLSX.read(buf, {type:'array'});
    let html   = '';
    wb.SheetNames.forEach(function(name) {
      html += '<div style="font-weight:800;padding:6px 8px;background:#1E3A5F;color:#fff;font-size:12px">📋 ' + name + '</div>';
      html += '<div style="overflow-x:auto">';
      html += XLSX.utils.sheet_to_html(wb.Sheets[name], {id:'sheet_'+name, editable:false});
      html += '</div><br>';
    });
    container.innerHTML = html;
    // Tablo stilini düzelt
    container.querySelectorAll('table').forEach(function(t){
      t.style.cssText = 'border-collapse:collapse;font-size:11px;min-width:100%';
    });
    container.querySelectorAll('td,th').forEach(function(c){
      c.style.cssText = 'border:1px solid #CBD5E1;padding:3px 6px;white-space:nowrap';
    });
  } catch(e) {
    container.innerHTML = '<div style="padding:24px;text-align:center;color:#EF4444">Excel yüklenemedi: ' + e.message + '</div>';
  }
})();
</script>

<?php elseif ($viewer_type === 'word'): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js"></script>
<script>
(async function(){
  const container = document.getElementById('word-viewer');
  container.innerHTML = '<div style="padding:16px;color:var(--m2)">Yükleniyor...</div>';
  try {
    const res    = await fetch('<?= addslashes($download_url) ?>');
    const buf    = await res.arrayBuffer();
    const result = await mammoth.convertToHtml({arrayBuffer: buf});
    container.innerHTML = '<div style="max-width:700px;margin:0 auto">' + result.value + '</div>';
  } catch(e) {
    container.innerHTML = '<div style="padding:24px;text-align:center;color:#EF4444">Word dosyası yüklenemedi: ' + e.message + '<br><br>.doc formatı desteklenmeyebilir, .docx deneyin.</div>';
  }
})();
</script>
<?php endif; ?>
<?php endif; ?>
