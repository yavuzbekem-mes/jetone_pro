<?php
/**
 * JETONE.PRO — Uygunsuzluk Düzenle (Karar + DÖF)
 * panel.php: 'kalite-uygunsuzluk-duzenle' => 'bolumler/kalite/uygunsuzluk_duzenle.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<p style="color:red">Geçersiz ID</p>'; exit; }

$st = $db->prepare("SELECT * FROM uygunsuzluk WHERE id=?");
$st->execute([$id]);
$k = $st->fetch(PDO::FETCH_ASSOC);
if (!$k) { echo '<p style="color:red">Kayıt bulunamadı</p>'; exit; }

function ft($t){ return (!empty($t) && $t!=='0000-00-00') ? date('Y-m-d', strtotime($t)) : ''; }
function ns($v){ return htmlspecialchars($v ?? ''); }
$yer_map = ['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">✏️ Uygunsuzluk Düzenle</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" style="color:var(--t)">Uygunsuzluk</a> / <b><?= ns($k['takip_no']) ?></b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-yazdir&id=<?= $id ?>" target="_blank" class="btn btn-b btn-sm">🖨 Yazdır</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" class="btn btn-b btn-sm">← Liste</a>
  </div>
</div>

<div class="s-body">
<div class="kart">
  <div style="text-align:center;margin-bottom:18px">
    <div style="font-size:16px;font-weight:800">UYGUNSUZLUK DÜZENLEME</div>
    <div style="font-family:monospace;font-size:14px;color:var(--t);font-weight:800;margin-top:4px"><?= ns($k['takip_no']) ?></div>
  </div>

  <form action="<?= BASE_URL ?>/islemler/kalite/uygunsuzluk_guncelle.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $id ?>">

    <!-- Readonly bilgiler -->
    <div style="background:var(--kenar-a);border-radius:var(--r);padding:14px;margin-bottom:16px;border-left:4px solid var(--t)">
      <div style="font-size:11px;color:var(--m2);font-weight:700;margin-bottom:10px">KAYIT BİLGİLERİ (Değiştirilemez)</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;font-size:13px">
        <div><span style="color:var(--m2)">Tespit Eden:</span><br><b><?= ns($k['tespit_eden_kisi']) ?></b></div>
        <div><span style="color:var(--m2)">Tespit Tarihi:</span><br><b><?= $k['tespit_tarihi'] ? date('d.m.Y', strtotime($k['tespit_tarihi'])) : '—' ?></b></div>
        <div><span style="color:var(--m2)">Vardiya:</span><br><b><?= ns($k['vardiya']) ?></b></div>
        <div><span style="color:var(--m2)">Malzeme:</span><br><b><?= ns($k['malzeme_adi']) ?></b></div>
        <div><span style="color:var(--m2)">Uyg. Yeri:</span><br><b><?= $yer_map[$k['uygunsuzluk_yeri']??'']??ns($k['uygunsuzluk_yeri']) ?></b></div>
        <div><span style="color:var(--m2)">Hatalı Miktar:</span><br><b><?= ns($k['hatali_miktar']) ?></b></div>
      </div>
      <?php if ($k['uygunsuzluk_sebebi']): ?>
      <div style="margin-top:10px;font-size:12px;color:var(--m);border-top:1px solid var(--kenar);padding-top:8px">
        <span style="color:var(--m2);font-weight:700">Uygunsuzluk Sebebi:</span><br>
        <?= nl2br(ns($k['uygunsuzluk_sebebi'])) ?>
      </div>
      <?php endif; ?>
      <?php if ($k['uygunsuzluk_gorsel']): ?>
      <div style="margin-top:8px">
        <img src="<?= BASE_URL ?>/kys_dokumanlar/uygunsuzluk/<?= ns($k['uygunsuzluk_gorsel']) ?>"
             style="width:80px;height:80px;object-fit:cover;border-radius:6px;cursor:pointer;border:1px solid var(--kenar)"
             onclick="document.getElementById('imgModal').style.display='flex';document.getElementById('imgModal').querySelector('img').src=this.src">
      </div>
      <?php endif; ?>
    </div>

    <!-- Karar bölümü -->
    <div style="border:1.5px solid var(--kenar);border-radius:var(--r);padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:800;margin-bottom:12px">⚖️ Karar Bölümü</div>

      <div class="form-grup">
        <label class="form-et">Değerlendirme Sonucu <span class="zorunlu">*</span></label>
        <textarea class="form-alan" name="degerlendirme_sonucu" rows="3" required><?= ns($k['degerlendirme_sonucu']) ?></textarea>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Değerlendirme Tarihi <span class="zorunlu">*</span></label>
          <input class="form-alan" type="date" name="degerlendirme_tarihi" required value="<?= ft($k['degerlendirme_tarihi']) ?: date('Y-m-d') ?>">
        </div>
        <div></div>
      </div>

      <div class="form-grup">
        <label class="form-et">Karar <span class="zorunlu">*</span></label>
        <textarea class="form-alan" name="karar" rows="3" required><?= ns($k['karar']) ?></textarea>
      </div>
    </div>

    <!-- Düzeltici faaliyet -->
    <div class="form-grup">
      <label class="form-et">Düzeltici Faaliyet</label>
      <div style="display:flex;gap:24px;padding:12px;background:var(--kenar-a);border-radius:var(--r);border:1.5px solid var(--kenar)">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700">
          <input type="radio" name="duzeltici" value="gerekiyor" id="dofGer"
                 <?= ($k['duzeltici_faaliyet']==='gerekiyor')?'checked':'' ?>
                 style="width:18px;height:18px;accent-color:var(--hat)" onchange="toggleDOF()">
          Düzeltici Faaliyet Gerekiyor
        </label>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700">
          <input type="radio" name="duzeltici" value="gerekmiyor"
                 <?= ($k['duzeltici_faaliyet']==='gerekmiyor')?'checked':'' ?>
                 style="width:18px;height:18px;accent-color:var(--bas)" onchange="toggleDOF()">
          Gerekmiyor
        </label>
      </div>
    </div>

    <div id="dofBolum" style="display:<?= ($k['duzeltici_faaliyet']==='gerekiyor')?'block':'none' ?>">
      <div style="border:1.5px solid var(--hat);border-radius:var(--r);padding:14px;margin-bottom:14px">
        <div style="font-size:13px;font-weight:800;margin-bottom:12px;color:var(--hat)">📋 DÖF / 8D Bilgileri</div>
        <div class="form-grid-2">
          <div class="form-grup">
            <label class="form-et">DÖF No</label>
            <input class="form-alan" type="text" name="df_no" value="<?= ns($k['df_no']) ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">DÖF Hedef Tarihi</label>
            <input class="form-alan" type="date" name="df_hedef_tarih" value="<?= ft($k['df_hedef_tarih']) ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">8D No</label>
            <input class="form-alan" type="text" name="sekizd_no" value="<?= ns($k['sekizd_no']) ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">8D Hedef Tarihi</label>
            <input class="form-alan" type="date" name="sekizd_hedef_tarih" value="<?= ft($k['sekizd_hedef_tarih']) ?>">
          </div>
        </div>
      </div>
    </div>

    <!-- İmzalar -->
    <div class="form-grid-3">
      <div class="form-grup">
        <label class="form-et">Kalite Kontrol Sorumlusu</label>
        <input class="form-alan" type="text" name="kalite_sorumlu" value="<?= ns($k['kalite_sorumlu']?:'Emine Memduha Barut') ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Kalite Güvence Müdürü</label>
        <input class="form-alan" type="text" name="kalite_mudur" value="<?= ns($k['kalite_mudur']?:'Aslı Budak') ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Üretim Müdürü</label>
        <input class="form-alan" type="text" name="uretim_mudur" value="<?= ns($k['uretim_mudur']?:'Tarkan Aslan') ?>">
      </div>
    </div>

    <div class="form-footer">
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" class="btn btn-b">İptal</a>
      <button type="submit" name="uygunsuzluk_guncelle" class="btn btn-t">💾 Güncelle</button>
    </div>
  </form>
</div>
</div>

<!-- Görsel modal -->
<div id="imgModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;align-items:center;justify-content:center"
     onclick="this.style.display='none'">
  <img src="" style="max-width:90vw;max-height:90vh;border-radius:8px">
</div>

<script>
function toggleDOF(){ document.getElementById('dofBolum').style.display = document.getElementById('dofGer').checked ? 'block':'none'; }
</script>
