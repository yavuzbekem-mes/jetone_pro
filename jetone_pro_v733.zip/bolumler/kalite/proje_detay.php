<?php
/**
 * Proje Detay — Görevler, Riskler, Kaynaklar, Dokümanlar
 * panel.php: 'kalite-proje-detay' => 'bolumler/proje/detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-proje';</script>"; exit; }
$stmt = $db->prepare("SELECT * FROM prj_proje WHERE id=?"); $stmt->execute([$id]);
$p = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$p) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-proje';</script>"; exit; }

$mesaj=''; $mesaj_tip='';

// ── POST handler ──────────────────────────────────────────
if (isset($_POST['action'])) switch ($_POST['action']) {

    case 'gorev_ekle': case 'gorev_guncelle':
        $gid = (int)($_POST['gorev_id']??0);
        $data = [$_POST['gorev_adi'],$_POST['aciklama']??'',$_POST['asama'],$_POST['sorumlu']??'',$_POST['destek_kisi']??'',$_POST['baslangic_tarihi']?:null,$_POST['bitis_tarihi']?:null,$_POST['durum'],$_POST['oncelik'],(int)$_POST['tamamlanma'],$_POST['kilometre_tasi']??0,$_POST['notlar']??''];
        if ($gid) {
            $db->prepare("UPDATE prj_gorev SET gorev_adi=?,aciklama=?,aşama=?,sorumlu=?,destek_kisi=?,baslangic_tarihi=?,bitis_tarihi=?,durum=?,oncelik=?,tamamlanma=?,kilometre_tasi=?,notlar=? WHERE id=? AND proje_id=?")->execute([...$data,$gid,$id]);
            if ($_POST['durum']==='tamamlandi') $db->prepare("UPDATE prj_gorev SET gercek_bitis=CURDATE() WHERE id=? AND gercek_bitis IS NULL")->execute([$gid]);
        } else {
            $db->prepare("INSERT INTO prj_gorev (proje_id,gorev_adi,aciklama,aşama,sorumlu,destek_kisi,baslangic_tarihi,bitis_tarihi,durum,oncelik,tamamlanma,kilometre_tasi,notlar) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")->execute([$id,...$data]);
        }
        // Proje tamamlanma % güncelle
        $pct_r = $db->prepare("SELECT AVG(tamamlanma) FROM prj_gorev WHERE proje_id=? AND durum!='iptal'");
        $pct_r->execute([$id]); $pct_v = (int)$pct_r->fetchColumn();
        $db->prepare("UPDATE prj_proje SET tamamlanma_yuzdesi=? WHERE id=?")->execute([$pct_v,$id]);
        $mesaj='Görev kaydedildi.'; $mesaj_tip='ok'; break;

    case 'gorev_sil':
        $db->prepare("DELETE FROM prj_gorev WHERE id=? AND proje_id=?")->execute([(int)$_POST['gorev_id'],$id]);
        $mesaj='Görev silindi.'; $mesaj_tip='ok'; break;

    case 'risk_ekle': case 'risk_guncelle':
        $rid = (int)($_POST['risk_id']??0);
        $rd  = [$_POST['risk_tanimi'],$_POST['kategori'],(int)$_POST['olasilik'],(int)$_POST['etki'],$_POST['onleyici_eylem']??'',$_POST['acil_plan']??'',$_POST['sorumlu']??'',$_POST['durum']];
        $rid ? $db->prepare("UPDATE prj_risk SET risk_tanimi=?,kategori=?,olasilik=?,etki=?,onleyici_eylem=?,acil_plan=?,sorumlu=?,durum=? WHERE id=? AND proje_id=?")->execute([...$rd,$rid,$id])
             : $db->prepare("INSERT INTO prj_risk (proje_id,risk_tanimi,kategori,olasilik,etki,onleyici_eylem,acil_plan,sorumlu,durum) VALUES (?,?,?,?,?,?,?,?,?)")->execute([$id,...$rd]);
        $mesaj='Risk kaydedildi.'; $mesaj_tip='ok'; break;

    case 'risk_sil':
        $db->prepare("DELETE FROM prj_risk WHERE id=? AND proje_id=?")->execute([(int)$_POST['risk_id'],$id]);
        $mesaj='Risk silindi.'; $mesaj_tip='ok'; break;

    case 'kaynak_ekle': case 'kaynak_guncelle':
        $kid = (int)($_POST['kaynak_id']??0);
        $kd  = [$_POST['kaynak_turu'],$_POST['ad'],$_POST['birim']??'',(float)$_POST['miktar_tahmini'],(float)$_POST['miktar_gercek'],(float)$_POST['birim_maliyet'],$_POST['siparis_durumu'],$_POST['notlar']??''];
        $kid ? $db->prepare("UPDATE prj_kaynak SET kaynak_turu=?,ad=?,birim=?,miktar_tahmini=?,miktar_gercek=?,birim_maliyet=?,siparis_durumu=?,notlar=? WHERE id=? AND proje_id=?")->execute([...$kd,$kid,$id])
             : $db->prepare("INSERT INTO prj_kaynak (proje_id,kaynak_turu,ad,birim,miktar_tahmini,miktar_gercek,birim_maliyet,siparis_durumu,notlar) VALUES (?,?,?,?,?,?,?,?,?)")->execute([$id,...$kd]);
        $mesaj='Kaynak kaydedildi.'; $mesaj_tip='ok'; break;

    case 'kaynak_sil':
        $db->prepare("DELETE FROM prj_kaynak WHERE id=? AND proje_id=?")->execute([(int)$_POST['kaynak_id'],$id]);
        $mesaj='Silindi.'; $mesaj_tip='ok'; break;

    case 'ilerleme_guncelle':
        $db->prepare("UPDATE prj_proje SET tamamlanma_yuzdesi=?,durum=?,butce_gerceklesen=?,notlar=? WHERE id=?")->execute([(int)$_POST['tamamlanma_yuzdesi'],$_POST['durum'],(float)($_POST['butce_gerceklesen']??0),$_POST['notlar']??'',$id]);
        $stmt2=$db->prepare("SELECT * FROM prj_proje WHERE id=?");$stmt2->execute([$id]);$p=$stmt2->fetch(PDO::FETCH_ASSOC);
        $mesaj='Güncellendi.'; $mesaj_tip='ok'; break;

    case 'proje_sil':
        $dok_list=$db->prepare("SELECT dosya_yolu FROM prj_dokuman WHERE proje_id=?");$dok_list->execute([$id]);
        foreach($dok_list->fetchAll(PDO::FETCH_COLUMN) as $yol){$f=dirname(dirname(__DIR__)).'/'.$yol;if(file_exists($f))@unlink($f);}
        $db->prepare("DELETE FROM prj_proje WHERE id=?")->execute([$id]);
        echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-proje';</script>"; exit;
}

// ── Doküman yükle ─────────────────────────────────────────
if (isset($_FILES['dosya']) && $_FILES['dosya']['error']===0) {
    $dir = dirname(dirname(__DIR__)).'/uploads/proje/'.$id.'/';
    if (!is_dir($dir)) mkdir($dir,0777,true);
    $ext = strtolower(pathinfo($_FILES['dosya']['name'],PATHINFO_EXTENSION));
    if (in_array($ext,['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','zip','txt','mpp'])) {
        $fn = time().'_'.preg_replace('/[^a-z0-9._-]/i','_',$_FILES['dosya']['name']);
        if (move_uploaded_file($_FILES['dosya']['tmp_name'],$dir.$fn)) {
            $db->prepare("INSERT INTO prj_dokuman (proje_id,gorev_id,dosya_adi,dosya_yolu,tur,aciklama,yukleyen) VALUES (?,?,?,?,?,?,?)")
               ->execute([$id,$_POST['gorev_id_dok']??null,$_FILES['dosya']['name'],'uploads/proje/'.$id.'/'.$fn,$_POST['dosya_turu']??'diger',$_POST['dok_aciklama']??'',$kul_adi]);
            $mesaj='Doküman yüklendi.'; $mesaj_tip='ok';
        }
    } else { $mesaj='Desteklenmeyen dosya türü.'; $mesaj_tip='hata'; }
}

if (isset($_POST['action']) && $_POST['action']==='dok_sil') {
    $dk=$db->prepare("SELECT * FROM prj_dokuman WHERE id=? AND proje_id=?");$dk->execute([(int)$_POST['dok_id'],$id]);$dk=$dk->fetch(PDO::FETCH_ASSOC);
    if($dk){$f=dirname(dirname(__DIR__)).'/'.$dk['dosya_yolu'];if(file_exists($f))@unlink($f);$db->prepare("DELETE FROM prj_dokuman WHERE id=?")->execute([$dk['id']]);$mesaj='Silindi.';$mesaj_tip='ok';}
}

// ── Veri yükle ────────────────────────────────────────────
$stmt_g=$db->prepare("SELECT * FROM prj_gorev WHERE proje_id=? ORDER BY FIELD(aşama,'hazilik','uygulama','test','kapanis','diger'),sira,baslangic_tarihi");$stmt_g->execute([$id]);$gorevler=$stmt_g->fetchAll(PDO::FETCH_ASSOC);
$stmt_r=$db->prepare("SELECT * FROM prj_risk WHERE proje_id=? ORDER BY (olasilik*etki) DESC");$stmt_r->execute([$id]);$riskler=$stmt_r->fetchAll(PDO::FETCH_ASSOC);
$stmt_k=$db->prepare("SELECT * FROM prj_kaynak WHERE proje_id=? ORDER BY kaynak_turu,id");$stmt_k->execute([$id]);$kaynaklar=$stmt_k->fetchAll(PDO::FETCH_ASSOC);
$stmt_d=$db->prepare("SELECT * FROM prj_dokuman WHERE proje_id=? ORDER BY yuklenme_tarihi DESC");$stmt_d->execute([$id]);$dokumanlar=$stmt_d->fetchAll(PDO::FETCH_ASSOC);

$ds_stil=['taslak'=>['#94A3B8','Taslak'],'planlama'=>['#6366F1','Planlama'],'devam'=>['#0EA5E9','Devam'],'beklemede'=>['#F59E0B','Beklemede'],'tamamlandi'=>['#16A34A','Tamamlandı'],'iptal'=>['#DC2626','İptal']];
$gs_stil=['bekliyor'=>['#94A3B8','Bekliyor'],'devam'=>['#0EA5E9','Devam'],'tamamlandi'=>['#16A34A','Tamam'],'iptal'=>['#DC2626','İptal'],'engellendi'=>['#F59E0B','Engellendi']];
$asama_etiket=['hazilik'=>'🔧 Hazırlık','uygulama'=>'⚙️ Uygulama','test'=>'🧪 Test','kapanis'=>'🏁 Kapanış','diger'=>'📌 Diğer'];
$risk_kat=['teknik'=>'🔧','mali'=>'💰','zaman'=>'⏰','kaynak'=>'👥','dis_etken'=>'🌐','diger'=>'⚠️'];
$pct = (int)$p['tamamlanma_yuzdesi'];
$gecikti = $p['durum']==='devam' && $p['hedef_bitis_tarihi'] && $p['hedef_bitis_tarihi'] < date('Y-m-d');
$butce_asim = $p['butce_tahmini']>0 && $p['butce_gerceklesen']>$p['butce_tahmini'];
// Görevleri aşamaya göre grupla
$gorev_asama = [];
foreach($gorevler as $g){
    $ak = $g['aşama'] ?? ($g['asama'] ?? 'diger');
    $gorev_asama[$ak][] = $g;
}
// Bütçe hesapla (kaynaklar üzerinden)
$toplam_kaynak_maliyet = array_sum(array_map(fn($k)=>$k['miktar_gercek']*$k['birim_maliyet'],$kaynaklar));
$km_taslari = array_filter($gorevler,fn($g)=>$g['kilometre_tasi']);
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📂 <?=htmlspecialchars($p['proje_kodu'])?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje" style="color:var(--t)">Projeler</a> / <b><?=htmlspecialchars($p['proje_kodu'])?></b></div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
    <?php
      $ds_val  = $ds_stil[$p['durum']] ?? ['#6B7280','?'];
      $ds_renk = $ds_val[0];
      $ds_lbl  = $ds_val[1];
    ?>
    <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:<?=$ds_renk?>22;color:<?=$ds_renk?>;border:1px solid <?=$ds_renk?>"><?=$ds_lbl?></span>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-form&id=<?=$id?>" class="btn btn-b btn-sm">✏️ Düzenle</a>
    <?php
      $sil_kod  = htmlspecialchars($p['proje_kodu']);
      $sil_gcnt = count($gorevler);
      $sil_dcnt = count($dokumanlar);
    ?>
    <button id="projeSilBtn"
      data-kod="<?=$sil_kod?>"
      data-gcnt="<?=$sil_gcnt?>"
      data-dcnt="<?=$sil_dcnt?>"
      class="btn btn-sm" style="background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;font-size:12px;padding:5px 12px">
      🗑️ Sil
    </button>
  </div>
</div>

<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<!-- Kimlik Kartı -->
<div class="kart" style="padding:18px;margin-bottom:14px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;margin-bottom:14px">
    <div>
      <div style="font-size:18px;font-weight:900;color:var(--t);margin-bottom:6px"><?=htmlspecialchars($p['proje_adi'])?></div>
      <div style="font-size:13px;color:var(--m2);margin-bottom:8px"><?=htmlspecialchars($p['proje_amaci']??'')?></div>
      <div style="display:flex;gap:14px;font-size:12px;color:var(--m2);flex-wrap:wrap">
        <?php if($p['sponsor']): ?><span>🏢 Sponsor: <b><?=htmlspecialchars($p['sponsor'])?></b></span><?php endif; ?>
        <?php if($p['proje_yoneticisi']): ?><span>👤 PM: <b><?=htmlspecialchars($p['proje_yoneticisi'])?></b></span><?php endif; ?>
        <?php if($p['baslangic_tarihi']): ?><span>📅 <b><?=date('d.m.Y',strtotime($p['baslangic_tarihi']))?></b></span><?php endif; ?>
        <?php if($p['hedef_bitis_tarihi']): ?>
        <span style="color:<?=$gecikti?'#DC2626':'var(--m2)'?>">🏁 <b><?=date('d.m.Y',strtotime($p['hedef_bitis_tarihi']))?></b><?=$gecikti?' ⚠️ GECİKTİ':''?></span>
        <?php endif; ?>
        <?php if($p['butce_tahmini']>0): ?><span style="color:<?=$butce_asim?'#DC2626':'var(--m2)'?>">💰 <b><?=number_format($p['butce_tahmini'],0,',','.')?> ₺</b><?=$butce_asim?' (AŞILDI)':''?></span><?php endif; ?>
      </div>
    </div>
    <form method="POST" style="display:flex;flex-direction:column;gap:6px;min-width:180px">
      <input type="hidden" name="action" value="ilerleme_guncelle">
      <input type="hidden" name="durum" value="<?=htmlspecialchars($p['durum'])?>">
      <input type="hidden" name="butce_gerceklesen" value="<?=$p['butce_gerceklesen']??0?>">
      <input type="hidden" name="notlar" value="<?=htmlspecialchars($p['notlar']??'')?>">
      <label class="form-et" style="font-size:10px">İlerleme %</label>
      <input type="range" name="tamamlanma_yuzdesi" min="0" max="100" value="<?=$pct?>" id="ilerlemeRange"
             oninput="document.getElementById('ilerlemeVal').textContent=this.value+'%'" style="width:100%">
      <div style="text-align:center;font-size:16px;font-weight:800" id="ilerlemeVal"><?=$pct?>%</div>
      <button type="submit" class="btn btn-t btn-sm" style="font-size:11px">Güncelle</button>
    </form>
  </div>
  <div style="height:8px;background:var(--kenar);border-radius:4px">
    <div style="height:100%;width:<?=$pct?>%;background:<?php echo $pct>=100?'#22C55E':($pct>50?'#0EA5E9':'#6366F1'); ?>;border-radius:4px"></div>
  </div>
  <?php if(!empty($km_taslari)): ?>
  <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--kenar)">
    <div style="font-size:11px;font-weight:700;color:var(--m2);margin-bottom:6px">🚩 KİLOMETRE TAŞLARI</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
    <?php foreach($km_taslari as $km):
      $kgs=$gs_stil[$km['durum']]??['#6B7280','?'];
    ?>
    <div style="padding:5px 10px;border-radius:8px;background:<?=$km['durum']==='tamamlandi'?'#D1FAE5':'#EFF6FF'?>;font-size:11px">
      <?=$km['durum']==='tamamlandi'?'✅':'⏳'?> <?=htmlspecialchars($km['gorev_adi'])?>
      <?php if($km['bitis_tarihi']): ?><span style="color:var(--m3)"> · <?=date('d.m.Y',strtotime($km['bitis_tarihi']))?></span><?php endif; ?>
    </div>
    <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:16px;flex-wrap:wrap">
  <?php
    $ptabs_data = [
      ['gorevler',   '📋 Görevler ('.count($gorevler).')'],
      ['riskler',    '⚡ Riskler ('.count($riskler).')'],
      ['kaynaklar',  '💰 Kaynaklar ('.count($kaynaklar).')'],
      ['dokumanlar', '📎 Dokümanlar ('.count($dokumanlar).')'],
      ['kapsam',     '🎯 Kapsam'],
    ];
    foreach($ptabs_data as $ti=>[$tid,$tlbl]):
  ?>
  <button onclick="tabGoster('<?=$tid?>')" id="ptab_<?=$tid?>"
    style="padding:7px 14px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;
           background:<?=$ti===0?'var(--t)':'var(--kenar-a)'?>;color:<?=$ti===0?'#fff':'var(--m)'?>">
    <?=$tlbl?>
  </button>
  <?php endforeach; ?>
</div>

<!-- GÖREVLER -->
<div id="tab_gorevler">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
  <div style="font-weight:800;font-size:14px">İş Kırılım Yapısı</div>
  <button onclick="modalAc('gorevModal')" class="btn btn-t btn-sm">+ Görev Ekle</button>
</div>
<?php if(empty($gorevler)): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Görev eklenmemiş.</div>
<?php else: ?>
<?php foreach(['hazilik','uygulama','test','kapanis','diger'] as $asama):
  if(empty($gorev_asama[$asama])) continue;
  $asama_g = $gorev_asama[$asama];
  $a_tam = count(array_filter($asama_g,fn($g)=>$g['durum']==='tamamlandi'));
?>
<div style="margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
    <div style="font-weight:800;font-size:13px"><?=$asama_etiket[$asama]??$asama?></div>
    <span style="font-size:11px;color:var(--m2)"><?=$a_tam?>/<?=count($asama_g)?></span>
  </div>
  <div style="display:flex;flex-direction:column;gap:6px">
  <?php foreach($asama_g as $g):
    $gs   = $gs_stil[$g['durum']] ?? ['#6B7280','?'];
    $g_gec = $g['durum']!='tamamlandi' && $g['bitis_tarihi'] && $g['bitis_tarihi']<date('Y-m-d');
    $gid_safe = (int)$g['id'];
  ?>
  <div class="kart" style="padding:10px 14px;border-left:3px solid <?=$gs[0]?>">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span style="font-size:14px"><?=$g['durum']==='tamamlandi'?'✅':($g['durum']==='devam'?'⏳':($g['durum']==='engellendi'?'🚫':($g['kilometre_tasi']?'🚩':'⬜')))?></span>
      <div style="flex:1;min-width:150px">
        <div style="font-weight:700;font-size:13px"><?=htmlspecialchars($g['gorev_adi'])?>
          <?php if($g['kilometre_tasi']): ?><span style="font-size:10px;background:#EFF6FF;color:#2563EB;padding:1px 5px;border-radius:4px;margin-left:4px">KM</span><?php endif; ?>
        </div>
        <?php if($g['sorumlu']): ?><div style="font-size:11px;color:var(--m2)">👤 <?=htmlspecialchars($g['sorumlu'])?></div><?php endif; ?>
      </div>
      <div style="font-size:11px;color:var(--m2);min-width:120px">
        <?php if($g['baslangic_tarihi']): ?><?=date('d.m',strtotime($g['baslangic_tarihi']))?> → <?=$g['bitis_tarihi']?date('d.m.Y',strtotime($g['bitis_tarihi'])):'?'?><?php endif; ?>
        <?php if($g_gec): ?><span style="color:#DC2626;font-weight:700;display:block">⚠️ GECİKTİ</span><?php endif; ?>
      </div>
      <div style="min-width:70px;text-align:center">
        <div style="font-size:12px;font-weight:700;color:<?=$gs[0]?>"><?=$g['tamamlanma']?>%</div>
        <div style="height:4px;background:var(--kenar);border-radius:2px">
          <div style="height:100%;width:<?=$g['tamamlanma']?>%;background:<?=$gs[0]?>;border-radius:2px"></div>
        </div>
      </div>
      <div style="display:flex;gap:4px">
        <button onclick="gorevDuzenleById(<?=$gid_safe?>)" class="btn btn-b btn-sm" style="font-size:10px;padding:3px 8px">✏️</button>
        <button onclick="gorevSil(<?=$gid_safe?>)" class="btn btn-sm" style="font-size:10px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>

<!-- RİSKLER -->
<div id="tab_riskler" style="display:none">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
  <div style="font-weight:800;font-size:14px">Risk Kaydı</div>
  <button onclick="modalAc('riskModal')" class="btn btn-t btn-sm">+ Risk Ekle</button>
</div>
<?php if(empty($riskler)): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Risk kaydı yok.</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($riskler as $r):
  $skor = $r['olasilik']*$r['etki'];
  $r_renk = $skor>=15?'#DC2626':($skor>=9?'#D97706':($skor>=4?'#F59E0B':'#22C55E'));
  $rid_safe = (int)$r['id'];
?>
<div class="kart" style="padding:12px 16px;border-left:4px solid <?=$r_renk?>">
  <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
    <div style="text-align:center;min-width:50px">
      <div style="font-size:22px;font-weight:900;color:<?=$r_renk?>"><?=$skor?></div>
      <div style="font-size:9px;color:var(--m2)">SKOR</div>
    </div>
    <div style="flex:1">
      <div style="font-size:13px;font-weight:700"><?=$risk_kat[$r['kategori']]??'⚠️'?> <?=htmlspecialchars($r['risk_tanimi'])?></div>
      <?php if($r['onleyici_eylem']): ?><div style="font-size:11px;color:var(--m2);margin-top:3px">🛡️ <?=htmlspecialchars(mb_strimwidth($r['onleyici_eylem'],0,100,'…'))?></div><?php endif; ?>
      <div style="font-size:11px;color:var(--m3);margin-top:3px">Olasılık:<?=$r['olasilik']?>/5 · Etki:<?=$r['etki']?>/5 · <?=strtoupper($r['durum']??'')?></div>
    </div>
    <div style="display:flex;gap:4px">
      <button onclick="riskDuzenleById(<?=$rid_safe?>)" class="btn btn-b btn-sm" style="font-size:10px;padding:3px 8px">✏️</button>
      <button onclick="riskSil(<?=$rid_safe?>)" class="btn btn-sm" style="font-size:10px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<!-- KAYNAKLAR -->
<div id="tab_kaynaklar" style="display:none">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
  <div style="font-weight:800;font-size:14px">Kaynak ve Bütçe</div>
  <button onclick="modalAc('kaynakModal')" class="btn btn-t btn-sm">+ Kaynak Ekle</button>
</div>
<?php if(!empty($kaynaklar)):
  $t_tah = array_sum(array_map(fn($k)=>$k['miktar_tahmini']*$k['birim_maliyet'],$kaynaklar));
  $t_ger = array_sum(array_map(fn($k)=>$k['miktar_gercek']*$k['birim_maliyet'],$kaynaklar));
?>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px">
  <?php foreach([['Tahmini',number_format($t_tah,0,',','.').' ₺','#1E3A5F'],['Gerçekleşen',number_format($t_ger,0,',','.').' ₺',$t_ger>$t_tah?'#DC2626':'#16A34A'],['Fark',number_format($t_tah-$t_ger,0,',','.').' ₺',$t_ger>$t_tah?'#DC2626':'#16A34A']] as $bk): ?>
  <div class="kart" style="padding:12px;text-align:center;border-left:4px solid <?=$bk[2]?>">
    <div style="font-size:18px;font-weight:900;color:<?=$bk[2]?>"><?=$bk[1]?></div>
    <div style="font-size:11px;color:var(--m2)"><?=$bk[0]?></div>
  </div>
  <?php endforeach; ?>
</div>
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto">
<table style="width:100%;border-collapse:collapse;font-size:12px">
  <thead><tr style="background:#1E3A5F;color:#fff">
    <?php foreach(['Tür','Ad','Birim','Tah.Miktar','Ger.Miktar','Birim Mal.','Toplam','Sipariş',''] as $th): ?>
    <th style="padding:8px 10px;text-align:left;white-space:nowrap"><?=$th?></th>
    <?php endforeach; ?>
  </tr></thead>
  <tbody>
  <?php foreach($kaynaklar as $k):
    $sip_renk=['bekliyor'=>'#F59E0B','siparis_verildi'=>'#0EA5E9','teslim_alindi'=>'#16A34A','iptal'=>'#DC2626'];
    $sip_lbl=['bekliyor'=>'Bekliyor','siparis_verildi'=>'Sipariş Verildi','teslim_alindi'=>'Teslim Alındı','iptal'=>'İptal'];
    $kid_safe=(int)$k['id'];
    $toplam=$k['miktar_gercek']*$k['birim_maliyet'];
  ?>
  <tr style="border-bottom:1px solid var(--kenar)">
    <td style="padding:7px 10px"><?=['insan'=>'👤','malzeme'=>'📦','ekipman'=>'🔧','diger'=>'📌'][$k['kaynak_turu']]??'📌'?></td>
    <td style="padding:7px 10px;font-weight:700"><?=htmlspecialchars($k['ad'])?></td>
    <td style="padding:7px 10px"><?=htmlspecialchars($k['birim']??'')?></td>
    <td style="padding:7px 10px;text-align:right"><?=number_format($k['miktar_tahmini'],2,',','.')?></td>
    <td style="padding:7px 10px;text-align:right;font-weight:700"><?=number_format($k['miktar_gercek'],2,',','.')?></td>
    <td style="padding:7px 10px;text-align:right"><?=number_format($k['birim_maliyet'],2,',','.')?></td>
    <td style="padding:7px 10px;text-align:right;font-weight:700"><?=number_format($toplam,0,',','.')?> ₺</td>
    <td style="padding:7px 10px"><span style="font-size:10px;font-weight:700;color:<?=$sip_renk[$k['siparis_durumu']]??'#6B7280'?>"><?=$sip_lbl[$k['siparis_durumu']]??'?'?></span></td>
    <td style="padding:7px 10px;white-space:nowrap">
      <button onclick="kaynakDuzenleById(<?=$kid_safe?>)" class="btn btn-b btn-sm" style="font-size:10px;padding:2px 7px">✏️</button>
      <button onclick="kaynakSil(<?=$kid_safe?>)" class="btn btn-sm" style="font-size:10px;padding:2px 7px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
<?php else: ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Kaynak eklenmemiş.</div>
<?php endif; ?>
</div>

<!-- DOKÜMANLAR -->
<div id="tab_dokumanlar" style="display:none">
<div style="display:flex;justify-content:flex-end;margin-bottom:12px">
  <button onclick="modalAc('dokModal')" class="btn btn-t btn-sm">📎 Yükle</button>
</div>
<?php if(empty($dokumanlar)): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Doküman yüklenmemiş.</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px">
<?php foreach($dokumanlar as $dok):
  $ext=strtolower(pathinfo($dok['dosya_adi'],PATHINFO_EXTENSION));
  $dikon=in_array($ext,['jpg','jpeg','png','gif'])?'🖼️':($ext==='pdf'?'📄':($ext==='zip'?'🗜️':'📎'));
  $dok_id_safe=(int)$dok['id'];
?>
<div class="kart" style="padding:12px">
  <div style="display:flex;gap:8px;margin-bottom:8px">
    <div style="font-size:22px"><?=$dikon?></div>
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:12px;word-break:break-word"><?=htmlspecialchars($dok['dosya_adi'])?></div>
      <?php if($dok['aciklama']): ?><div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars($dok['aciklama'])?></div><?php endif; ?>
    </div>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:10px;color:var(--m3)"><?=date('d.m.Y',strtotime($dok['yuklenme_tarihi']))?></span>
    <div style="display:flex;gap:5px">
      <a href="<?=BASE_URL?>/<?=$dok['dosya_yolu']?>" target="_blank" class="btn btn-b btn-sm" style="font-size:11px;padding:3px 8px">⬇️</a>
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="dok_sil">
        <input type="hidden" name="dok_id" value="<?=$dok_id_safe?>">
        <button type="submit" onclick="return confirm('Silinsin mi?')" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
      </form>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<!-- KAPSAM -->
<div id="tab_kapsam" style="display:none">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px" class="kap-grid">
  <?php foreach([['Kapsam Icinde','kapsam_icinde','#16A34A','#F0FDF4'],['Kapsam Disinda','kapsam_disinda','#DC2626','#FEF2F2']] as $kap): ?>
  <div class="kart" style="padding:16px;border-left:4px solid <?=$kap[2]?>;background:<?=$kap[3]?>">
    <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:<?=$kap[2]?>"><?=$kap[0]?></div>
    <?php $kisiler=array_filter(explode("\n",trim($p[$kap[1]]??'')),fn($s)=>trim($s)); ?>
    <?php if($kisiler): ?>
    <ul style="margin:0;padding-left:18px">
      <?php foreach($kisiler as $sat): ?><li style="font-size:13px;margin-bottom:3px"><?=htmlspecialchars(trim($sat))?></li><?php endforeach; ?>
    </ul>
    <?php else: ?><span style="color:var(--m3);font-size:12px">Girilmemiş</span><?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php if($p['basari_kriterleri']): ?>
<div class="kart" style="padding:16px;border-left:4px solid #6366F1">
  <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:#6366F1">Basari Kriterleri</div>
  <?php foreach(array_filter(explode("\n",trim($p['basari_kriterleri'])),fn($s)=>trim($s)) as $sat): ?>
  <div style="font-size:13px;padding:4px 0;border-bottom:1px solid var(--kenar)">⭐ <?=htmlspecialchars(trim($sat))?></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<!-- MODALLER -->
<!-- Görev Modal -->
<div id="gorevModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center;padding:16px;overflow-y:auto">
<div class="kart" style="width:620px;max-width:100%;padding:22px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px" id="gorevModalBaslik">Gorev Ekle</div>
    <button onclick="modalKapat('gorevModal')" style="border:none;background:none;font-size:20px;cursor:pointer">x</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" id="g_action" value="gorev_ekle">
    <input type="hidden" name="gorev_id" id="g_id" value="">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div style="grid-column:span 2"><label class="form-et">Gorev Adi *</label><input name="gorev_adi" id="g_adi" class="form-alan" required style="width:100%"></div>
      <div><label class="form-et">Asama</label><select name="asama" id="g_asama" class="form-alan"><option value="hazilik">Hazirlik</option><option value="uygulama" selected>Uygulama</option><option value="test">Test</option><option value="kapanis">Kapanis</option><option value="diger">Diger</option></select></div>
      <div><label class="form-et">Oncelik</label><select name="oncelik" id="g_oncelik" class="form-alan"><option value="dusuk">Dusuk</option><option value="normal" selected>Normal</option><option value="yuksek">Yuksek</option><option value="kritik">Kritik</option></select></div>
      <div><label class="form-et">Sorumlu</label><input name="sorumlu" id="g_sorumlu" class="form-alan"></div>
      <div><label class="form-et">Destek</label><input name="destek_kisi" id="g_destek" class="form-alan"></div>
      <div><label class="form-et">Baslangic</label><input type="date" name="baslangic_tarihi" id="g_bas" class="form-alan"></div>
      <div><label class="form-et">Bitis</label><input type="date" name="bitis_tarihi" id="g_bit" class="form-alan"></div>
      <div><label class="form-et">Durum</label><select name="durum" id="g_durum" class="form-alan"><option value="bekliyor">Bekliyor</option><option value="devam">Devam</option><option value="tamamlandi">Tamamlandi</option><option value="engellendi">Engellendi</option><option value="iptal">Iptal</option></select></div>
      <div><label class="form-et">Tamamlanma %</label><input type="number" name="tamamlanma" id="g_pct" class="form-alan" min="0" max="100" value="0"></div>
      <div style="grid-column:span 2"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px"><input type="checkbox" name="kilometre_tasi" id="g_km" value="1"> Kilometre Tasi</label></div>
      <div style="grid-column:span 2"><label class="form-et">Notlar</label><textarea name="notlar" id="g_notlar" class="form-alan" rows="2" style="width:100%;resize:vertical"></textarea></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('gorevModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Risk Modal -->
<div id="riskModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center;padding:16px">
<div class="kart" style="width:560px;max-width:100%;padding:20px;max-height:90vh;overflow-y:auto">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px" id="riskModalBaslik">Risk Ekle</div>
    <button onclick="modalKapat('riskModal')" style="border:none;background:none;font-size:20px;cursor:pointer">x</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" id="r_action" value="risk_ekle">
    <input type="hidden" name="risk_id" id="r_id" value="">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div style="grid-column:span 2"><label class="form-et">Risk Tanimi *</label><textarea name="risk_tanimi" id="r_tanim" class="form-alan" required rows="2" style="width:100%;resize:vertical"></textarea></div>
      <div><label class="form-et">Kategori</label><select name="kategori" id="r_kat" class="form-alan"><option value="teknik">Teknik</option><option value="mali">Mali</option><option value="zaman">Zaman</option><option value="kaynak">Kaynak</option><option value="dis_etken">Dis Etken</option><option value="diger">Diger</option></select></div>
      <div><label class="form-et">Durum</label><select name="durum" id="r_durum" class="form-alan"><option value="acik">Acik</option><option value="izleniyor">Izleniyor</option><option value="kapandi">Kapandi</option><option value="gerceklesti">Gerceklesti</option></select></div>
      <div><label class="form-et">Olasilik (1-5)</label><input type="range" name="olasilik" id="r_olas" min="1" max="5" value="3" oninput="this.nextElementSibling.textContent=this.value" style="width:100%"><span style="font-weight:700">3</span></div>
      <div><label class="form-et">Etki (1-5)</label><input type="range" name="etki" id="r_etki" min="1" max="5" value="3" oninput="this.nextElementSibling.textContent=this.value" style="width:100%"><span style="font-weight:700">3</span></div>
      <div><label class="form-et">Sorumlu</label><input name="sorumlu" id="r_sorumlu" class="form-alan"></div>
      <div style="grid-column:span 2"><label class="form-et">Onleyici Eylem</label><textarea name="onleyici_eylem" id="r_onleyici" class="form-alan" rows="2" style="width:100%;resize:vertical"></textarea></div>
      <div style="grid-column:span 2"><label class="form-et">Acil Plan</label><textarea name="acil_plan" id="r_acil" class="form-alan" rows="2" style="width:100%;resize:vertical"></textarea></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('riskModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Kaynak Modal -->
<div id="kaynakModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center;padding:16px">
<div class="kart" style="width:480px;max-width:100%;padding:20px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px" id="kaynakModalBaslik">Kaynak Ekle</div>
    <button onclick="modalKapat('kaynakModal')" style="border:none;background:none;font-size:20px;cursor:pointer">x</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" id="k_action" value="kaynak_ekle">
    <input type="hidden" name="kaynak_id" id="k_id" value="">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div><label class="form-et">Tur</label><select name="kaynak_turu" id="k_tur" class="form-alan"><option value="insan">Insan</option><option value="malzeme">Malzeme</option><option value="ekipman">Ekipman</option><option value="diger">Diger</option></select></div>
      <div><label class="form-et">Ad *</label><input name="ad" id="k_ad" class="form-alan" required></div>
      <div><label class="form-et">Birim</label><input name="birim" id="k_birim" class="form-alan" placeholder="adet, kg, saat..."></div>
      <div><label class="form-et">Tah. Miktar</label><input type="number" name="miktar_tahmini" id="k_tah" class="form-alan" step="0.01" value="0"></div>
      <div><label class="form-et">Ger. Miktar</label><input type="number" name="miktar_gercek" id="k_ger" class="form-alan" step="0.01" value="0"></div>
      <div><label class="form-et">Birim Maliyet</label><input type="number" name="birim_maliyet" id="k_mal" class="form-alan" step="0.01" value="0"></div>
      <div style="grid-column:span 2"><label class="form-et">Siparis Durumu</label><select name="siparis_durumu" id="k_sip" class="form-alan"><option value="bekliyor">Bekliyor</option><option value="siparis_verildi">Siparis Verildi</option><option value="teslim_alindi">Teslim Alindi</option><option value="iptal">Iptal</option></select></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('kaynakModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Dokuman Modal -->
<div id="dokModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:420px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800">Dokuman Yukle</div>
    <button onclick="modalKapat('dokModal')" style="border:none;background:none;font-size:18px;cursor:pointer">x</button>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Dosya</label><input type="file" name="dosya" class="form-alan" required></div>
      <div><label class="form-et">Tur</label><select name="dosya_turu" class="form-alan"><option value="plan">Plan</option><option value="rapor">Rapor</option><option value="sozlesme">Sozlesme</option><option value="cizim">Cizim</option><option value="foto">Fotograf</option><option value="diger" selected>Diger</option></select></div>
      <div><label class="form-et">Ilgili Gorev (opsiyonel)</label>
        <select name="gorev_id_dok" class="form-alan">
          <option value="">Genel proje</option>
          <?php foreach($gorevler as $gg): ?>
          <option value="<?=(int)$gg['id']?>"><?=htmlspecialchars($gg['gorev_adi'])?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-et">Aciklama</label><input name="dok_aciklama" class="form-alan"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('dokModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Yukle</button>
    </div>
  </form>
</div>
</div>

<!-- Gizli Formlar -->
<form method="POST" id="gorevSilForm" style="display:none"><input type="hidden" name="action" value="gorev_sil"><input type="hidden" name="gorev_id" id="gorevSilId"></form>
<form method="POST" id="riskSilForm" style="display:none"><input type="hidden" name="action" value="risk_sil"><input type="hidden" name="risk_id" id="riskSilId"></form>
<form method="POST" id="kaynakSilForm" style="display:none"><input type="hidden" name="action" value="kaynak_sil"><input type="hidden" name="kaynak_id" id="kaynakSilId"></form>
<form method="POST" id="projeSilForm" style="display:none"><input type="hidden" name="action" value="proje_sil"></form>

</div><!-- /s-body -->
<style>
@media(max-width:600px){.kap-grid{grid-template-columns:1fr!important}}
</style>

<script>
// Veri - base64 ile guvenli aktarim
var _gorevler  = JSON.parse(atob('<?=base64_encode(json_encode($gorevler))?>'));
var _riskler   = JSON.parse(atob('<?=base64_encode(json_encode($riskler,  JSON_UNESCAPED_UNICODE))?>'));
var _kaynaklar = JSON.parse(atob('<?=base64_encode(json_encode($kaynaklar))?>'));

// Proje sil
document.getElementById('projeSilBtn').addEventListener('click', function(){
    var kod  = this.dataset.kod;
    var gcnt = parseInt(this.dataset.gcnt);
    var dcnt = parseInt(this.dataset.dcnt);
    var msg  = '"' + kod + '" projesini silmek istiyorsunuz.\n';
    if(gcnt > 0) msg += gcnt + ' gorev silinecek.\n';
    if(dcnt > 0) msg += dcnt + ' dokuman silinecek.\n';
    msg += '\nGERI ALINAMAZ. Devam?';
    if(!confirm(msg)) return;
    var girilen = prompt('Onaylamak icin proje kodunu girin:\n\n' + kod);
    if(girilen === null) return;
    if(girilen.trim().toUpperCase() !== kod.toUpperCase()){
        alert('Kod eslesmed. Iptal.');
        return;
    }
    document.getElementById('projeSilForm').submit();
});

// Sekme
var ptabs = ['gorevler','riskler','kaynaklar','dokumanlar','kapsam'];
function tabGoster(id){
    ptabs.forEach(function(t){
        document.getElementById('tab_'+t).style.display = t===id ? 'block' : 'none';
        var b = document.getElementById('ptab_'+t);
        if(b){ b.style.background = t===id ? 'var(--t)' : 'var(--kenar-a)'; b.style.color = t===id ? '#fff' : 'var(--m)'; }
    });
}

function modalAc(id)  { document.getElementById(id).style.display = 'flex'; }
function modalKapat(id){ document.getElementById(id).style.display = 'none'; }

// Gorev
function gorevDuzenleById(id){
    var g = _gorevler.find(function(x){ return x.id == id; });
    if(!g) return;
    document.getElementById('gorevModalBaslik').textContent = 'Gorev Duzenle';
    document.getElementById('g_action').value   = 'gorev_guncelle';
    document.getElementById('g_id').value       = g.id;
    document.getElementById('g_adi').value      = g.gorev_adi    || '';
    document.getElementById('g_asama').value    = g['asama'] || g['aşama'] || 'uygulama';
    document.getElementById('g_sorumlu').value  = g.sorumlu      || '';
    document.getElementById('g_destek').value   = g.destek_kisi  || '';
    document.getElementById('g_bas').value      = g.baslangic_tarihi || '';
    document.getElementById('g_bit').value      = g.bitis_tarihi || '';
    document.getElementById('g_durum').value    = g.durum        || 'bekliyor';
    document.getElementById('g_oncelik').value  = g.oncelik      || 'normal';
    document.getElementById('g_pct').value      = g.tamamlanma   || 0;
    document.getElementById('g_km').checked     = g.kilometre_tasi == 1;
    document.getElementById('g_notlar').value   = g.notlar       || '';
    modalAc('gorevModal');
}
function gorevSil(id){
    if(!confirm('Bu gorevi silmek istediginizden emin misiniz?')) return;
    document.getElementById('gorevSilId').value = id;
    document.getElementById('gorevSilForm').submit();
}

// Risk
function riskDuzenleById(id){
    var r = _riskler.find(function(x){ return x.id == id; });
    if(!r) return;
    document.getElementById('riskModalBaslik').textContent = 'Risk Duzenle';
    document.getElementById('r_action').value   = 'risk_guncelle';
    document.getElementById('r_id').value       = r.id;
    document.getElementById('r_tanim').value    = r.risk_tanimi     || '';
    document.getElementById('r_kat').value      = r.kategori        || 'diger';
    document.getElementById('r_olas').value     = r.olasilik        || 3;
    document.getElementById('r_olas').nextElementSibling.textContent = r.olasilik || 3;
    document.getElementById('r_etki').value     = r.etki            || 3;
    document.getElementById('r_etki').nextElementSibling.textContent = r.etki || 3;
    document.getElementById('r_onleyici').value = r.onleyici_eylem  || '';
    document.getElementById('r_acil').value     = r.acil_plan       || '';
    document.getElementById('r_sorumlu').value  = r.sorumlu         || '';
    document.getElementById('r_durum').value    = r.durum           || 'acik';
    modalAc('riskModal');
}
function riskSil(id){
    if(!confirm('Bu riski silmek istediginizden emin misiniz?')) return;
    document.getElementById('riskSilId').value = id;
    document.getElementById('riskSilForm').submit();
}

// Kaynak
function kaynakDuzenleById(id){
    var k = _kaynaklar.find(function(x){ return x.id == id; });
    if(!k) return;
    document.getElementById('kaynakModalBaslik').textContent = 'Kaynak Duzenle';
    document.getElementById('k_action').value  = 'kaynak_guncelle';
    document.getElementById('k_id').value      = k.id;
    document.getElementById('k_tur').value     = k.kaynak_turu    || 'insan';
    document.getElementById('k_ad').value      = k.ad             || '';
    document.getElementById('k_birim').value   = k.birim          || '';
    document.getElementById('k_tah').value     = k.miktar_tahmini || 0;
    document.getElementById('k_ger').value     = k.miktar_gercek  || 0;
    document.getElementById('k_mal').value     = k.birim_maliyet  || 0;
    document.getElementById('k_sip').value     = k.siparis_durumu || 'bekliyor';
    modalAc('kaynakModal');
}
function kaynakSil(id){
    if(!confirm('Silinsin mi?')) return;
    document.getElementById('kaynakSilId').value = id;
    document.getElementById('kaynakSilForm').submit();
}
</script>
