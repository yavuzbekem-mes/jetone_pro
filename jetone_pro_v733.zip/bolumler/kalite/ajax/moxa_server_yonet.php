<?php
/**
 * MOXA Node.js Server Yönetim Endpoint
 * POST action=baslat|durdur|durum
 * Windows Laragon ortamı için optimize edildi
 */
ob_start();
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'hata'=>'auth']); exit; }

$action     = $_POST['action'] ?? $_GET['action'] ?? 'durum';
$server_dir = $root . DIRECTORY_SEPARATOR . 'entegrasyonlar';
$pid_dosya  = $root . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'moxa_server.pid';
$log_dosya  = $root . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'moxa_server.log';
$ws_port    = 5050;

// ── Yardımcı: PID çalışıyor mu ────────────────────────────
function pidCalisiyorMu($pid) {
    if (!$pid || $pid <= 0) return false;
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $out = []; exec("tasklist /FI \"PID eq $pid\" /NH 2>NUL", $out);
        foreach ($out as $line) {
            if (strpos($line, (string)$pid) !== false) return true;
        }
        return false;
    } else {
        return file_exists("/proc/$pid");
    }
}

// ── Yardımcı: Porta bağlanabilir mi (server ayakta mı) ────
function portAcikMi($port) {
    $s = @fsockopen('127.0.0.1', $port, $e, $es, 0.5);
    if ($s) { fclose($s); return true; }
    return false;
}

// ── Mevcut PID oku ────────────────────────────────────────
$pid = 0;
if (file_exists($pid_dosya)) {
    $pid = (int)trim(file_get_contents($pid_dosya));
}
$calisiyor = pidCalisiyorMu($pid) || portAcikMi($ws_port);

// ── DURUM ─────────────────────────────────────────────────
if ($action === 'durum') {
    echo json_encode([
        'ok'        => true,
        'calisiyor' => $calisiyor,
        'pid'       => $pid,
        'port'      => $ws_port,
        'ws_url'    => "ws://localhost:$ws_port",
    ]);
    exit;
}

// ── BAŞLAT ────────────────────────────────────────────────
if ($action === 'baslat') {
    if ($calisiyor) {
        echo json_encode(['ok'=>true,'mesaj'=>'Zaten çalışıyor','pid'=>$pid,'ws_url'=>"ws://localhost:$ws_port"]);
        exit;
    }

    // node_modules var mı?
    $nm_dir = $server_dir . DIRECTORY_SEPARATOR . 'node_modules';
    if (!is_dir($nm_dir)) {
        // npm install çalıştır
        $npm_cmd = strtoupper(substr(PHP_OS,0,3))==='WIN' ? 'npm.cmd' : 'npm';
        $npm_out = []; $npm_ret = -1;
        @exec("cd /d \"$server_dir\" && $npm_cmd install --silent 2>&1", $npm_out, $npm_ret);
        if ($npm_ret !== 0 && !is_dir($nm_dir)) {
            echo json_encode(['ok'=>false,'hata'=>'npm install başarısız: '.implode(' ',$npm_out)]);
            exit;
        }
    }

    // Node.js serveri arka planda baslatiliyor
    $node_cmd  = strtoupper(substr(PHP_OS,0,3))==='WIN' ? 'node.exe' : 'node';
    $server_js = $server_dir . DIRECTORY_SEPARATOR . 'moxa_server.js';

    if (strtoupper(substr(PHP_OS,0,3))==='WIN') {
        // Windows: START /B ile arka planda
        $cmd = "START /B \"\" $node_cmd \"$server_js\" > \"$log_dosya\" 2>&1";
        pclose(popen("cd /d \"$server_dir\" && $cmd", 'r'));
    } else {
        // Linux/Mac
        $cmd = "$node_cmd \"$server_js\" > \"$log_dosya\" 2>&1 &";
        @exec("cd \"$server_dir\" && $cmd");
    }

    // PID'i bul — porta bağlanana kadar bekle (max 5sn)
    $yeni_pid = 0;
    for ($i = 0; $i < 10; $i++) {
        usleep(500000); // 0.5sn
        if (portAcikMi($ws_port)) {
            // PID bul
            if (strtoupper(substr(PHP_OS,0,3))==='WIN') {
                $out=[]; exec("netstat -ano | findstr :$ws_port", $out);
                foreach ($out as $line) {
                    if (preg_match('/\s(\d+)\s*$/', trim($line), $m)) {
                        $yeni_pid = (int)$m[1]; break;
                    }
                }
            } else {
                $out=[]; exec("lsof -ti:$ws_port", $out);
                if (!empty($out)) $yeni_pid = (int)$out[0];
            }
            break;
        }
    }

    if ($yeni_pid > 0) {
        file_put_contents($pid_dosya, $yeni_pid);
    }

    $basarili = portAcikMi($ws_port);
    echo json_encode([
        'ok'     => $basarili,
        'mesaj'  => $basarili ? 'Server başlatıldı' : 'Server başlatılamadı',
        'pid'    => $yeni_pid,
        'ws_url' => "ws://localhost:$ws_port",
    ]);
    exit;
}

// ── DURDUR ────────────────────────────────────────────────
if ($action === 'durdur') {
    $durduruldu = false;

    if ($pid > 0 && pidCalisiyorMu($pid)) {
        if (strtoupper(substr(PHP_OS,0,3))==='WIN') {
            exec("taskkill /F /PID $pid 2>NUL", $o, $r);
            $durduruldu = ($r === 0);
        } else {
            exec("kill $pid", $o, $r);
            $durduruldu = ($r === 0);
        }
    }

    // Porta bakarak da durdur
    if (portAcikMi($ws_port)) {
        if (strtoupper(substr(PHP_OS,0,3))==='WIN') {
            $out=[]; exec("netstat -ano | findstr :$ws_port", $out);
            foreach ($out as $line) {
                if (preg_match('/\s(\d+)\s*$/', trim($line), $m)) {
                    exec("taskkill /F /PID {$m[1]} 2>NUL");
                }
            }
        } else {
            exec("fuser -k {$ws_port}/tcp 2>/dev/null");
        }
        $durduruldu = true;
    }

    if (file_exists($pid_dosya)) @unlink($pid_dosya);

    echo json_encode(['ok'=>true,'mesaj'=>$durduruldu?'Server durduruldu':'Zaten duruyordu']);
    exit;
}

echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen action']);
