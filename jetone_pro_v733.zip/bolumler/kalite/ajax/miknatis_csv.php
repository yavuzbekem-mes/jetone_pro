<?php
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$cihazlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$tb = preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['tarih_b']??'') ? $_GET['tarih_b'] : date('Y-m-d',strtotime('-6 days'));
$te = preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['tarih_e']??'') ? $_GET['tarih_e'] : date('Y-m-d');
$mak = in_array($_GET['makina']??'',$cihazlar) ? $_GET['makina'] : '';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="miknatis_'.$tb.'_'.$te.'.csv"');
ob_end_clean();

$where = "WHERE DATE(kontrol_zamani) BETWEEN ? AND ?";
$p = [$tb,$te];
if($mak){ $where .= " AND makina_kodu=?"; $p[]=$mak; }

$s = $db->prepare("SELECT id,makina_kodu,urun_kodu,durum,m1,m2,m3,eksik_adet,
    kontrol_zamani,duzeltme_zamani,aciklama FROM miknatis_kontroller $where ORDER BY kontrol_zamani DESC");
$s->execute($p);

$out = fopen('php://output','w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
fputcsv($out,['ID','Cihaz','Ürün Kodu','Durum','M1','M2','M3','Eksik','Zaman','Düzeltme','Açıklama']);
while($r=$s->fetch(PDO::FETCH_ASSOC)) fputcsv($out,$r);
fclose($out); exit;
