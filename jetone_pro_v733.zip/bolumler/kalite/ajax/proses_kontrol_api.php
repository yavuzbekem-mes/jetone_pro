<?php
/**
 * Proses Kontrol — DataTables server-side API
 * POST: DataTables params + 1_tarih, 2_tarih
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
if (!Auth::girisYapilmisMi()) { echo json_encode(['error'=>'Yetkisiz']); exit; }

$tarih_b = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['1_tarih'] ?? '') ? $_POST['1_tarih'] : date('Y-m-d', strtotime('-29 days'));
$tarih_e = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['2_tarih'] ?? '') ? $_POST['2_tarih'] : date('Y-m-d');

$draw   = (int)($_POST['draw']   ?? 1);
$start  = (int)($_POST['start']  ?? 0);
$length = (int)($_POST['length'] ?? 25);
$search = $_POST['search']['value'] ?? '';

$where = "WHERE tarih BETWEEN ? AND ?";
$params = [$tarih_b, $tarih_e];

if ($search !== '') {
    $where .= " AND (urun_kodu LIKE ? OR urun_adi LIKE ? OR istasyon_kodu LIKE ? OR ekleyen LIKE ?)";
    $s = "%$search%";
    $params = array_merge($params, [$s,$s,$s,$s]);
}

// Toplam kayıt
$total = $db->prepare("SELECT COUNT(*) FROM proses_kontrol $where");
$total->execute($params);
$totalRecords = (int)$total->fetchColumn();

// Sıralama
$orderCol  = (int)($_POST['order'][0]['column'] ?? 6);
$orderDir  = ($_POST['order'][0]['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
$cols = ['id','id','sonuc','urun_kodu','urun_adi','vardiya','tarih',
         'gramaj','map_gramaj','gramaj_fark',
         'cevrim','map_cevrim','cevrim_fark',
         'makina_tonaj','map_tonaj','tonaj_fark',
         'aciklama','ekleyen'];
$sortCol = $cols[$orderCol] ?? 'tarih';

$stmt = $db->prepare("SELECT * FROM proses_kontrol $where ORDER BY $sortCol $orderDir LIMIT ? OFFSET ?");
$params[] = $length;
$params[] = $start;
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

function sonuc_roz(string $s): string {
    $map = [
        'ok'  => ['#D1FAE5','#065F46','OK'],
        'nok' => ['#FEE2E2','#991B1B','NOK'],
        'na'  => ['#F1F5F9','#475569','N/A'],
        'n/a' => ['#F1F5F9','#475569','N/A'],
    ];
    $c = $map[strtolower($s)] ?? ['#F1F5F9','#334155', strtoupper($s)];
    return "<span style=\"background:{$c[0]};color:{$c[1]};padding:2px 9px;border-radius:12px;font-size:11px;font-weight:800\">{$c[2]}</span>";
}

function fark_html(?float $f): string {
    if ($f === null) return '<span style="color:#94A3B8">—</span>';
    $renk = $f == 0 ? '#059669' : ($f > 0 ? '#D97706' : '#DC2626');
    $isk  = $f > 0 ? '+' : '';
    return "<span style=\"color:$renk;font-weight:700\">{$isk}" . number_format($f, 2, ',', '.') . "</span>";
}

$data = [];
foreach ($rows as $i => $r) {
    $sira = $start + $i + 1;

    // İşlemler butonu
    $isle = "<a href=\"" . ($GLOBALS['base_url'] ?? '') . "\" onclick=\"prosesDetay({$r['id']});return false\"
               style=\"background:var(--t-a);color:var(--t);border-radius:4px;padding:2px 8px;font-size:11px;
               font-weight:700;text-decoration:none\">🔍</a>";

    // Fark renkleri
    $gr_fark  = fark_html(isset($r['gramaj_fark'])   ? (float)$r['gramaj_fark']  : null);
    $cv_fark  = fark_html(isset($r['cevrim_fark'])   ? (float)$r['cevrim_fark']  : null);
    $ton_fark = fark_html(isset($r['tonaj_fark'])    ? (float)$r['tonaj_fark']   : null);

    $vrd = ['1'=>'1.Vrd','2'=>'2.Vrd','3'=>'3.Vrd'][$r['vardiya']] ?? $r['vardiya'];

    $data[] = [
        $sira,
        $isle,
        sonuc_roz($r['sonuc']),
        htmlspecialchars($r['urun_kodu']),
        htmlspecialchars($r['urun_adi']),
        $vrd,
        date('d.m.Y', strtotime($r['tarih'])),
        $r['gramaj']      !== null ? number_format((float)$r['gramaj'],3,',','.')      : '—',
        $r['map_gramaj']  !== null ? number_format((float)$r['map_gramaj'],3,',','.')  : '—',
        $gr_fark,
        $r['cevrim']      !== null ? number_format((float)$r['cevrim'],2,',','.')      : '—',
        $r['map_cevrim']  !== null ? number_format((float)$r['map_cevrim'],2,',','.')  : '—',
        $cv_fark,
        $r['makina_tonaj'] !== null ? number_format((float)$r['makina_tonaj'],2,',','.') : '—',
        $r['map_tonaj']    !== null ? number_format((float)$r['map_tonaj'],2,',','.')    : '—',
        $ton_fark,
        htmlspecialchars($r['aciklama'] ?? ''),
        htmlspecialchars($r['ekleyen']),
    ];
}

echo json_encode([
    'draw'            => $draw,
    'recordsTotal'    => $totalRecords,
    'recordsFiltered' => $totalRecords,
    'data'            => $data,
]);
exit;
