<?php
/**
 * Proses Kontrol — AJAX kaydet
 * POST: form verileri
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
if (ob_get_level()) ob_end_clean();
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'msg'=>'Oturum gerekli']); exit; }

$kul = Auth::kullanici();

$n = function(string $k, $def = null) { $v = trim($_POST[$k] ?? ''); return $v !== '' ? $v : $def; };
$f = function(string $k) use ($n) {
    $v = str_replace(',', '.', $n($k, ''));
    return is_numeric($v) ? (float)$v : null;
};

$urun_kodu     = strtoupper($n('urun_kodu', ''));
$urun_adi      = $n('urun_adi', $n('urun_adi_goster', ''));
$istasyon_kodu = $n('istasyon_kodu', '');
$vardiya       = (int)($n('vardiya', 1));
$tarih         = $n('tarih', date('Y-m-d'));
$ekleyen       = $n('ekleyen', $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem');

if (!$urun_kodu || !$istasyon_kodu) {
    echo json_encode(['ok'=>false,'msg'=>'Ürün kodu ve makina zorunlu']); exit;
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tarih)) {
    echo json_encode(['ok'=>false,'msg'=>'Geçersiz tarih']); exit;
}

$gramaj        = $f('gramaj');
$map_gramaj    = $f('map_gramaj');
$gramaj_fark   = ($gramaj !== null && $map_gramaj !== null) ? round($gramaj - $map_gramaj, 3) : null;

$cevrim        = $f('cevrim');
$map_cevrim    = $f('map_cevrim');
$cevrim_fark   = ($cevrim !== null && $map_cevrim !== null) ? round($cevrim - $map_cevrim, 2) : null;

$makina_tonaj  = $f('makina_tonaj');
$map_tonaj     = $f('map_tonaj');
$tonaj_fark    = ($makina_tonaj !== null && $map_tonaj !== null) ? round($makina_tonaj - $map_tonaj, 2) : null;

$kriterler = ['cizik_capak','kirik_catlak','cokuntu','hm_lekesi','yag_lekesi',
              'eksik_enj','serpme','gazlanma','yanma','tirnak_pim','harelenme','sonuc'];
$kriter_vals = [];
$izin = ['ok','nok','na','n/a'];
foreach ($kriterler as $k) {
    $v = strtolower(trim($_POST[$k] ?? 'ok'));
    $kriter_vals[$k] = in_array($v, $izin) ? $v : 'ok';
}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS `proses_kontrol` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `urun_kodu` VARCHAR(50) NOT NULL, `urun_adi` VARCHAR(200) NOT NULL DEFAULT '',
        `istasyon_kodu` VARCHAR(30) NOT NULL DEFAULT '', `vardiya` TINYINT(1) NOT NULL DEFAULT 1,
        `tarih` DATE NOT NULL,
        `gramaj` DECIMAL(10,3) DEFAULT NULL, `map_gramaj` DECIMAL(10,3) DEFAULT NULL, `gramaj_fark` DECIMAL(10,3) DEFAULT NULL,
        `cevrim` DECIMAL(10,2) DEFAULT NULL, `map_cevrim` DECIMAL(10,2) DEFAULT NULL, `cevrim_fark` DECIMAL(10,2) DEFAULT NULL,
        `makina_tonaj` DECIMAL(10,2) DEFAULT NULL, `map_tonaj` DECIMAL(10,2) DEFAULT NULL, `tonaj_fark` DECIMAL(10,2) DEFAULT NULL,
        `cizik_capak` VARCHAR(5) NOT NULL DEFAULT 'ok', `kirik_catlak` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `cokuntu` VARCHAR(5) NOT NULL DEFAULT 'ok', `hm_lekesi` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `yag_lekesi` VARCHAR(5) NOT NULL DEFAULT 'ok', `eksik_enj` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `serpme` VARCHAR(5) NOT NULL DEFAULT 'ok', `gazlanma` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `yanma` VARCHAR(5) NOT NULL DEFAULT 'ok', `tirnak_pim` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `harelenme` VARCHAR(5) NOT NULL DEFAULT 'ok', `sonuc` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `aciklama` TEXT, `ekleyen` VARCHAR(100) NOT NULL DEFAULT '',
        `kayit_zaman` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_tarih` (`tarih`), KEY `idx_urun` (`urun_kodu`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $stmt = $db->prepare("INSERT INTO proses_kontrol
        (urun_kodu, urun_adi, istasyon_kodu, vardiya, tarih,
         gramaj, map_gramaj, gramaj_fark,
         cevrim, map_cevrim, cevrim_fark,
         makina_tonaj, map_tonaj, tonaj_fark,
         cizik_capak, kirik_catlak, cokuntu, hm_lekesi, yag_lekesi,
         eksik_enj, serpme, gazlanma, yanma, tirnak_pim, harelenme,
         sonuc, aciklama, ekleyen)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

    $stmt->execute([
        $urun_kodu, $urun_adi, $istasyon_kodu, $vardiya, $tarih,
        $gramaj, $map_gramaj, $gramaj_fark,
        $cevrim, $map_cevrim, $cevrim_fark,
        $makina_tonaj, $map_tonaj, $tonaj_fark,
        $kriter_vals['cizik_capak'], $kriter_vals['kirik_catlak'],
        $kriter_vals['cokuntu'],     $kriter_vals['hm_lekesi'],
        $kriter_vals['yag_lekesi'],  $kriter_vals['eksik_enj'],
        $kriter_vals['serpme'],      $kriter_vals['gazlanma'],
        $kriter_vals['yanma'],       $kriter_vals['tirnak_pim'],
        $kriter_vals['harelenme'],   $kriter_vals['sonuc'],
        $n('aciklama', ''),          $ekleyen,
    ]);

    $id = (int)$db->lastInsertId();
    echo json_encode(['ok'=>true,'id'=>$id,'msg'=>"Proses kontrol kaydedildi. (#$id)"]);

} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'msg'=>'DB Hatası: '.$e->getMessage()]);
}
exit;
