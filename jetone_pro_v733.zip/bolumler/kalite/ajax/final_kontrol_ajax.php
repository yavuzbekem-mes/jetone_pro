<?php
/**
 * Final Kontrol AJAX endpoint
 * GET  ?action=kontrol_et&paket=XXX  → paket bilgisi + duplicate kontrolü
 * POST action=kaydet                  → DB'ye yaz
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
require_once $root . '/core/baglanlogo.php';

header('Content-Type: application/json; charset=utf-8');
if (ob_get_level()) ob_end_clean();
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'hata'=>'Oturum gerekli']); exit; }
$kul = Auth::kullanici();

// ── GET: Paket sorgula ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action']??'') === 'kontrol_et') {
    $paket = trim($_GET['paket'] ?? '');
    if (!$paket) { echo json_encode(['ok'=>false,'hata'=>'Paket no boş']); exit; }

    // Daha önce kontrol edilmiş mi?
    try {
        $st = $db->prepare("SELECT kontrol_eden, kontrol_tarih_saat, kontrol_sonuc
            FROM final_kontrol_listesi WHERE paket_no=? ORDER BY kontrol_tarih_saat DESC LIMIT 1");
        $st->execute([$paket]);
        $prev = $st->fetch(PDO::FETCH_ASSOC);
        if ($prev) {
            echo json_encode([
                'ok' => true,
                'zaten_var' => true,
                'mesaj' => date('d.m.Y H:i', strtotime($prev['kontrol_tarih_saat']))
                         . ' — ' . ($prev['kontrol_eden'] ?? '?')
                         . ' — ' . ($prev['kontrol_sonuc'] ?? '?'),
            ]); exit;
        }
    } catch (Throwable $e) {}

    // MES'ten paket bilgisi çek
    $stok_kodu = ''; $stok_adi = ''; $miktar = '';
    if ($mes_pdo) {
        // Gerçek tablo adı: MES..PAKETLER (MSSQL çift nokta = MES.dbo.PAKETLER)
        $tables = ['MES..PAKETLER', 'MES.dbo.PAKETLER', 'PAKETLER'];
        foreach ($tables as $tbl) {
            try {
                $st = $mes_pdo->prepare("SELECT STOK_KODU, STOK_ADI, MIKTAR FROM $tbl WHERE PAKET_NO=?");
                $st->execute([$paket]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r) {
                    $stok_kodu = trim($r['STOK_KODU'] ?? '');
                    $stok_adi  = trim($r['STOK_ADI']  ?? '');
                    $miktar    = trim((string)($r['MIKTAR'] ?? ''));
                    // Tam sayı ise noktasız göster
                    if (is_numeric($miktar)) {
                        $f = (float)$miktar;
                        $miktar = floor($f)==$f ? (string)(int)$f : rtrim(rtrim(number_format($f,3,'.',','),'0'),',');
                    }
                    break;
                }
            } catch (Throwable $e) { /* sonraki tabloyu dene */ }
        }
    }

    echo json_encode([
        'ok'        => true,
        'zaten_var' => false,
        'stok_kodu' => $stok_kodu,
        'stok_adi'  => $stok_adi,
        'miktar'    => $miktar,
        'mes_ok'    => ($mes_pdo !== null),
        'uyari'     => ($mes_pdo && !$stok_kodu) ? 'Paket MES\'te bulunamadı — bilgileri manuel girin' : '',
    ]); exit;
}

// ── POST: Kaydet ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz istek']); exit;
}

$paket   = trim($_POST['paket_no'] ?? '');
$karar   = strtoupper(trim($_POST['karar'] ?? 'OK'));
$aciklama= trim($_POST['aciklama'] ?? '');
$sk      = trim($_POST['stok_kodu'] ?? '');
$sa      = trim($_POST['stok_adi']  ?? '');
$mik_raw = trim($_POST['miktar']    ?? '');
$ekleyen = $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem';

if (!$paket) { echo json_encode(['ok'=>false,'hata'=>'Paket no boş']); exit; }
if (!in_array($karar, ['OK','NOK'])) $karar = 'OK';

$miktar = null;
if ($mik_raw !== '') {
    $mik_raw = str_replace(',', '.', $mik_raw);
    if (is_numeric($mik_raw)) $miktar = (float)$mik_raw;
}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS `final_kontrol_listesi` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `paket_no` VARCHAR(100) NOT NULL, `stok_kodu` VARCHAR(100) DEFAULT NULL,
        `stok_adi` VARCHAR(255) DEFAULT NULL, `miktar` DECIMAL(12,3) DEFAULT NULL,
        `kontrol_sonuc` VARCHAR(20) DEFAULT NULL, `kontrol_aciklama` TEXT,
        `kontrol_eden` VARCHAR(100) DEFAULT NULL,
        `kontrol_tarih_saat` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`), INDEX (`paket_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->prepare("INSERT INTO final_kontrol_listesi
        (paket_no, stok_kodu, stok_adi, miktar, kontrol_sonuc, kontrol_aciklama, kontrol_eden)
        VALUES (?,?,?,?,?,?,?)")
    ->execute([$paket, $sk ?: null, $sa ?: null, $miktar, $karar, $aciklama ?: null, $ekleyen]);

    echo json_encode([
        'ok'       => true,
        'stok_kodu'=> $sk,
        'stok_adi' => $sa,
        'saat'     => date('H:i'),
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
exit;
