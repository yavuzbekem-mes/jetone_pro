<?php
ob_start();
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false]); exit; }
$kul  = Auth::kullanici();
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$gecerli = ['GECTI','KALDI','IPTAL'];
$sonuc = $data['sonuc'] ?? '';
if (!in_array($sonuc, $gecerli)) { echo json_encode(['ok'=>false,'hata'=>'Geçersiz sonuç']); exit; }
try {
    $db->exec("CREATE TABLE IF NOT EXISTS tank_kapak_test (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, urun_kodu VARCHAR(50),
        operatör VARCHAR(100), sonuc ENUM('GECTI','KALDI','IPTAL') NOT NULL,
        sure_ms INT UNSIGNED, basinc_max DECIMAL(5,3), aciklama VARCHAR(255),
        test_zamani DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $db->prepare("INSERT INTO tank_kapak_test (urun_kodu,operatör,sonuc,sure_ms) VALUES(?,?,?,?)")
       ->execute([
           substr(trim($data['urun_kodu'] ?? ''), 0, 50),
           $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem',
           $sonuc,
           (int)($data['sure_ms'] ?? 0),
       ]);
    echo json_encode(['ok'=>true, 'id'=>(int)$db->lastInsertId()]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
