<?php
ob_start();
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'hata'=>'auth']); exit; }

$data = json_decode(file_get_contents('php://input'), true) ?: [];

// Sil
if (!empty($data['sil'])) {
    $id = (int)($data['id'] ?? 0);
    if (!$id) { echo json_encode(['ok'=>false,'hata'=>'ID eksik']); exit; }
    try {
        $db->prepare("DELETE FROM hortum_test_recete WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
    exit;
}

// Kaydet / Güncelle
$id             = (int)($data['id'] ?? 0);
$recete_adi     = trim($data['recete_adi'] ?? '');
$hedef_basinc   = (float)($data['hedef_basinc'] ?? 2.5);
$kacak_esigi    = (float)($data['kacak_esigi'] ?? 0.05);
$bekle_sure     = (int)($data['bekle_sure'] ?? 10);
$min_akis       = (float)($data['min_akis'] ?? 8.0);
$stabilize_sure = (int)($data['stabilize_sure'] ?? 3);
$aciklama       = substr(trim($data['aciklama'] ?? ''), 0, 255);
$aktif          = (int)($data['aktif'] ?? 1);

if (!$recete_adi) { echo json_encode(['ok'=>false,'hata'=>'Reçete adı boş olamaz']); exit; }

try {
    if ($id > 0) {
        $db->prepare("UPDATE hortum_test_recete SET
            recete_adi=?, hedef_basinc=?, kacak_esigi=?, bekle_sure=?,
            min_akis=?, stabilize_sure=?, aciklama=?, aktif=?
            WHERE id=?")
           ->execute([$recete_adi,$hedef_basinc,$kacak_esigi,$bekle_sure,$min_akis,$stabilize_sure,$aciklama,$aktif,$id]);
        echo json_encode(['ok'=>true,'id'=>$id,'mesaj'=>'Güncellendi']);
    } else {
        $db->prepare("INSERT INTO hortum_test_recete
            (recete_adi,hedef_basinc,kacak_esigi,bekle_sure,min_akis,stabilize_sure,aciklama,aktif)
            VALUES (?,?,?,?,?,?,?,?)")
           ->execute([$recete_adi,$hedef_basinc,$kacak_esigi,$bekle_sure,$min_akis,$stabilize_sure,$aciklama,$aktif]);
        echo json_encode(['ok'=>true,'id'=>(int)$db->lastInsertId(),'mesaj'=>'Eklendi']);
    }
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
