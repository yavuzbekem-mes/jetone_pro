<?php
/**
 * JETONE.PRO — Mıknatıs AJAX handler
 * bolumler/kalite/ajax/miknatis_ajax.php
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

ini_set('display_errors',0); error_reporting(0);
ob_start();
header('Content-Type: application/json; charset=utf-8');

if (!Auth::girisYapilmisMi()) { ob_end_clean(); echo json_encode(['ok'=>false,'hata'=>'Oturum sona erdi']); exit; }

$cihazlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$action = $_GET['action'] ?? '';


// Tüm cihazların son durumu — cihazlar sayfası için
if ($action === 'tum_cihazlar') {
    try {
        $tmp_dir = dirname(dirname(dirname(__DIR__))) . '/uploads/miknatis';

        // DB'den son kayıtları al (opsiyonel, olmasa da cihaz listesi dönecek)
        $db_map = [];
        try {
            $dbRows = $db->query("
                SELECT mk.makina_kodu, mk.durum, mk.m1, mk.m2, mk.m3,
                       DATE_FORMAT(mk.kontrol_zamani,'%H:%i:%s') AS saat,
                       mk.aciklama, mk.urun_kodu
                FROM miknatis_kontroller mk
                INNER JOIN (
                    SELECT makina_kodu, MAX(id) AS max_id
                    FROM miknatis_kontroller GROUP BY makina_kodu
                ) t ON mk.makina_kodu=t.makina_kodu AND mk.id=t.max_id
            ")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbRows as $r) $db_map[$r['makina_kodu']] = $r;
        } catch(Throwable $e) {}

        // 8 cihazın tamamını döndür — online/offline için tmp dosyası yeterli
        $result = [];
        foreach ($cihazlar as $kod) {
            $row = $db_map[$kod] ?? [
                'makina_kodu' => $kod, 'durum' => '', 'm1' => 0, 'm2' => 0, 'm3' => 0,
                'saat' => '', 'aciklama' => '', 'urun_kodu' => '',
            ];
            $row['makina_kodu'] = $kod;
            $row['gecen_sn']    = 9999;
            $row['ip']          = '';

            // Tmp dosyasından online durumu — ping veya kayıt yazdıysa
            $tmp = $tmp_dir . '/miknatis_' . $kod . '.json';
            if (file_exists($tmp)) {
                $v = json_decode(file_get_contents($tmp), true);
                if ($v) {
                    $row['gecen_sn'] = time() - (int)($v['ts'] ?? 0);
                    $row['ip']       = $v['ip'] ?? '';
                    // Tmp'deki son durum DB'dekinden daha güncel olabilir
                    if (!empty($v['durum'])) $row['durum'] = $v['durum'];
                }
            }
            $result[] = $row;
        }

        ob_end_clean();
        echo json_encode(['ok'=>true,'cihazlar'=>$result]);
    } catch(Throwable $e){ ob_end_clean(); echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
    exit;
}

// Son durum + özet + son 20 kayıt
if ($action === 'son_durum') {
    $mak = in_array($_GET['makina']??'',$cihazlar) ? $_GET['makina'] : 'KRT-01';
    try {
        $row = $db->prepare("SELECT id,urun_kodu,durum,m1,m2,m3,eksik_adet,aciklama,
            DATE_FORMAT(kontrol_zamani,'%H:%i:%s') AS saat, kontrol_zamani
            FROM miknatis_kontroller WHERE makina_kodu=?
            ORDER BY kontrol_zamani DESC LIMIT 1");
        $row->execute([$mak]); $son = $row->fetch(PDO::FETCH_ASSOC);

        $oz = $db->prepare("SELECT COUNT(*) AS toplam,
            SUM(durum='basarili') AS basarili,
            SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
            SUM(durum='duzeltildi') AS duzeltildi,
            ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran
            FROM miknatis_kontroller WHERE makina_kodu=? AND DATE(kontrol_zamani)=CURDATE()");
        $oz->execute([$mak]); $ozet = $oz->fetch(PDO::FETCH_ASSOC);

        $ls = $db->prepare("SELECT id,urun_kodu,durum,m1,m2,m3,eksik_adet,
            DATE_FORMAT(kontrol_zamani,'%H:%i:%s') AS saat, aciklama
            FROM miknatis_kontroller WHERE makina_kodu=?
            ORDER BY kontrol_zamani DESC LIMIT 20");
        $ls->execute([$mak]);

        ob_end_clean();
        echo json_encode(['ok'=>true,'son'=>$son,'ozet'=>$ozet,'liste'=>$ls->fetchAll(PDO::FETCH_ASSOC)]);
    } catch(Throwable $e){ ob_end_clean(); echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
    exit;
}

// Simülasyon kaydı
if ($action === 'sim_kayit' && $_SERVER['REQUEST_METHOD']==='POST'
    && ($_SERVER['HTTP_X_REQUESTED_WITH']??'')==='XMLHttpRequest') {
    $mak  = in_array($_POST['makina']??'',$cihazlar) ? $_POST['makina'] : 'KRT-01';
    $m1   = (int)(bool)($_POST['m1']??0);
    $m2   = (int)(bool)($_POST['m2']??0);
    $m3   = (int)(bool)($_POST['m3']??0);
    $urun = strtoupper(substr(trim($_POST['urun_kodu']??'TEST'),0,30));
    $eksik = 3-($m1+$m2+$m3);
    $durum = $eksik===0 ? 'basarili' : "hata_{$eksik}";
    try {
        $db->prepare("INSERT INTO miknatis_kontroller
            (urun_kodu,makina_kodu,durum,m1,m2,m3,eksik_adet,aciklama)
            VALUES(?,?,?,?,?,?,?,?)")
          ->execute([$urun,$mak,$durum,$m1,$m2,$m3,$eksik,'Simülasyon']);
        ob_end_clean();
        echo json_encode(['ok'=>true,'durum'=>$durum,'eksik'=>$eksik]);
    } catch(Throwable $e){ ob_end_clean(); echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
    exit;
}

ob_end_clean();
echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen action']);
exit;
