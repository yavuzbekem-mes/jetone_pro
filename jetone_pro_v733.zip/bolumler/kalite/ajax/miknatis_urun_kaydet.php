<?php
/**
 * Mıknatıs cihaz ürün kodu kaydet — AJAX endpoint
 * POST: makina_kodu, urun_kodu, aktif
 */
ob_start();

$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if (!Auth::girisYapilmisMi()) {
    echo json_encode(['ok'=>false,'hata'=>'Oturum gerekli']); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false,'hata'=>'POST gerekli']); exit;
}

$kul = Auth::kullanici();

$gecerli_kodlar = [
    '2985310100','2985310200','2985310300','2985310400','2985310500','2985310600','2985310700',
    '2987910100','2987910200','2987910300','2987910400','2987910500','2987910600','2987910700',
    '2988080100','2988080200','2988080300','2988080400','2988080500','2988080600','2988080700',
    '2995190100','2995190200','2995190400','2995190500','2995190600',
];

$makina = preg_replace('/[^A-Z0-9\-]/', '', strtoupper(trim($_POST['makina_kodu'] ?? '')));
$urun   = strtoupper(trim($_POST['urun_kodu'] ?? ''));
$aktif  = (int)($_POST['aktif'] ?? 1);

if (!$makina) { echo json_encode(['ok'=>false,'hata'=>'Makina kodu gerekli']); exit; }
if (!$urun)   { echo json_encode(['ok'=>false,'hata'=>'Ürün kodu gerekli']); exit; }
if (!in_array($urun, $gecerli_kodlar)) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz ürün kodu: '.$urun]); exit;
}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS miknatis_cihaz_tanim (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        makina_kodu VARCHAR(20) NOT NULL,
        urun_kodu   VARCHAR(30) NOT NULL,
        aktif       TINYINT(1) NOT NULL DEFAULT 1,
        guncelleme  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        guncelleyen VARCHAR(100),
        UNIQUE KEY uk_makina (makina_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->prepare("INSERT INTO miknatis_cihaz_tanim (makina_kodu, urun_kodu, aktif, guncelleyen)
        VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE
            urun_kodu   = VALUES(urun_kodu),
            aktif       = VALUES(aktif),
            guncelleyen = VALUES(guncelleyen),
            guncelleme  = NOW()")
       ->execute([$makina, $urun, $aktif, $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem']);

    echo json_encode(['ok'=>true, 'makina'=>$makina, 'urun'=>$urun]);

} catch (Throwable $e) {
    echo json_encode(['ok'=>false, 'hata'=>$e->getMessage()]);
}
exit;
