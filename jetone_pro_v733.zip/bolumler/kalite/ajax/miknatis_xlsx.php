<?php
/**
 * Mıknatıs test sonuçları XLSX export (PhpSpreadsheet)
 * Türkçe karakter sorunu yok — UTF-8 native
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
Auth::zorunlu();

$cihazlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$tb  = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['tarih_b'] ?? '') ? $_GET['tarih_b'] : date('Y-m-d', strtotime('-6 days'));
$te  = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['tarih_e'] ?? '') ? $_GET['tarih_e'] : date('Y-m-d');
$mak = in_array($_GET['makina'] ?? '', $cihazlar) ? $_GET['makina'] : '';

$where = "WHERE DATE(kontrol_zamani) BETWEEN ? AND ?";
$p = [$tb, $te];
if ($mak) { $where .= " AND makina_kodu=?"; $p[] = $mak; }

$stmt = $db->prepare("SELECT id, makina_kodu, urun_kodu, durum, m1, m2, m3, eksik_adet,
    DATE_FORMAT(kontrol_zamani,'%d.%m.%Y %H:%i:%s') AS zaman,
    DATE_FORMAT(duzeltme_zamani,'%d.%m.%Y %H:%i:%s') AS duzeltme,
    aciklama FROM miknatis_kontroller $where ORDER BY kontrol_zamani DESC");
$stmt->execute($p);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// PhpSpreadsheet yoksa basit CSV-in-xlsx fallback
$dosya_adi = 'Miknatis_' . $tb . '_' . $te . ($mak ? '_' . $mak : '');

// PhpSpreadsheet kurulu mu?
$spreadsheet_mevcut = false;
$possible = [
    $root . '/vendor/autoload.php',
    dirname($root) . '/vendor/autoload.php',
];
foreach ($possible as $p2) {
    if (file_exists($p2)) {
        require_once $p2;
        if (class_exists('\PhpOffice\PhpSpreadsheet\Spreadsheet')) {
            $spreadsheet_mevcut = true;
            break;
        }
    }
}

if ($spreadsheet_mevcut) {
    // ── PhpSpreadsheet ile gerçek XLSX ──────────────────────────
    $ss   = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $ss->getActiveSheet();
    $sheet->setTitle('Test Sonuçları');

    $basliklar = ['#','Cihaz','Ürün Kodu','Durum','M1','M2','M3','Eksik','Zaman','Düzeltme','Açıklama'];
    $sheet->fromArray($basliklar, null, 'A1');

    // Başlık stili
    $baslik_stil = [
        'font'      => ['bold'=>true,'color'=>['rgb'=>'FFFFFF']],
        'fill'      => ['fillType'=>'solid','startColor'=>['rgb'=>'1E3A5F']],
        'alignment' => ['horizontal'=>'center'],
    ];
    $sheet->getStyle('A1:K1')->applyFromArray($baslik_stil);

    $row = 2;
    $durum_tr = [
        'basarili'=>'Başarılı','hata_1'=>'1 Eksik','hata_2'=>'2 Eksik',
        'hata_3'=>'3 Eksik','duzeltildi'=>'Düzeltildi'
    ];
    foreach ($rows as $r) {
        $sheet->fromArray([
            $r['id'], $r['makina_kodu'], $r['urun_kodu'],
            $durum_tr[$r['durum']] ?? $r['durum'],
            $r['m1'] ? 'Var' : 'Yok',
            $r['m2'] ? 'Var' : 'Yok',
            $r['m3'] ? 'Var' : 'Yok',
            $r['eksik_adet'],
            $r['zaman'], $r['duzeltme'] ?? '', $r['aciklama'] ?? ''
        ], null, 'A'.$row);
        // Hata satırlarını kırmızı yap
        if (str_starts_with($r['durum'], 'hata')) {
            $sheet->getStyle('A'.$row.':K'.$row)->getFill()
                  ->setFillType('solid')->getStartColor()->setRGB('FEE2E2');
        } elseif ($r['durum'] === 'basarili') {
            $sheet->getStyle('A'.$row.':K'.$row)->getFill()
                  ->setFillType('solid')->getStartColor()->setRGB('F0FDF4');
        }
        $row++;
    }

    // Sütun genişlikleri
    foreach (range('A','K') as $col) $sheet->getColumnDimension($col)->setAutoSize(true);

    ob_end_clean();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $dosya_adi . '.xlsx"');
    header('Cache-Control: no-cache');
    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss);
    $writer->save('php://output');

} else {
    // ── Fallback: CSV with UTF-8 BOM (Excel uyumlu) ─────────────
    ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $dosya_adi . '.csv"');
    header('Cache-Control: no-cache');

    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
    fputcsv($out, ['#','Cihaz','Ürün Kodu','Durum','M1','M2','M3','Eksik','Zaman','Düzeltme','Açıklama'], ';');
    $durum_tr = ['basarili'=>'Başarılı','hata_1'=>'1 Eksik','hata_2'=>'2 Eksik','hata_3'=>'3 Eksik','duzeltildi'=>'Düzeltildi'];
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['id'], $r['makina_kodu'], $r['urun_kodu'],
            $durum_tr[$r['durum']] ?? $r['durum'],
            $r['m1']?'Var':'Yok', $r['m2']?'Var':'Yok', $r['m3']?'Var':'Yok',
            $r['eksik_adet'], $r['zaman'], $r['duzeltme']??'', $r['aciklama']??''
        ], ';');
    }
    fclose($out);
}
exit;
