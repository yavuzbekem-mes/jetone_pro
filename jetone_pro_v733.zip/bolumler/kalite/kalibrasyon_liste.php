<?php
/**
 * JETONE.PRO — Kalibrasyon Cihaz Listesi & Dashboard
 * panel.php: 'kalite-kalibrasyon-liste' => 'bolumler/kalite/kalibrasyon_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Tabloları oluştur (yoksa)
try {
    $db->exec(file_get_contents(dirname(dirname(__DIR__)) . '/kalibrasyon.sql'));
} catch (Throwable $e) {}

// Durum mesajı
$durum = $_GET['durum'] ?? '';

// Özet istatistikler
$bugun = date('Y-m-d');
$s30 = date('Y-m-d', strtotime('+30 days'));
$s60 = date('Y-m-d', strtotime('+60 days'));
$yil = date('Y');
$ay  = (int)date('m');

try {
    $ozet = $db->query("SELECT
        COUNT(*) toplam,
        SUM(durum='OKEY') okey,
        SUM(durum IN('ARIZALI','KULLANIM DIŞI')) sorunlu,
        SUM(durum='KAYIP') kayip,
        SUM(sonraki_kalibrasyon < '$bugun') gecmis,
        SUM(sonraki_kalibrasyon BETWEEN '$bugun' AND '$s30') yaklasan30,
        SUM(sonraki_kalibrasyon BETWEEN '$bugun' AND '$s60') yaklasan60
        FROM kalibrasyon_cihazlar WHERE aktif=1")->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $ozet = array_fill_keys(['toplam','okey','sorunlu','kayip','gecmis','yaklasan30','yaklasan60'],0); }

// Bu yıl ay ay plan
try {
    $aylik = [];
    for ($m=1;$m<=12;$m++) {
        $st = $db->prepare("SELECT COUNT(*) FROM kalibrasyon_cihazlar WHERE MONTH(sonraki_kalibrasyon)=? AND YEAR(sonraki_kalibrasyon)=? AND aktif=1");
        $st->execute([$m, $yil]);
        $aylik[$m] = (int)$st->fetchColumn();
    }
} catch (Throwable $e) { $aylik = array_fill(1,12,0); }

// Bu yıl yapılan
try {
    $yapilan = [];
    for ($m=1;$m<=12;$m++) {
        $st = $db->prepare("SELECT COUNT(DISTINCT cihaz_id) FROM kalibrasyon_kayitlar WHERE MONTH(kalibrasyon_tarihi)=? AND YEAR(kalibrasyon_tarihi)=?");
        $st->execute([$m, $yil]);
        $yapilan[$m] = (int)$st->fetchColumn();
    }
} catch (Throwable $e) { $yapilan = array_fill(1,12,0); }

// Filtre
$filtre_bolum = $_GET['bolum'] ?? '';
$filtre_durum = $_GET['durum_f'] ?? '';
$filtre_kalan = $_GET['kalan'] ?? '';

$where = "WHERE aktif=1";
$params = [];
if ($filtre_bolum) { $where .= " AND kullanim_bolumu=?"; $params[] = $filtre_bolum; }
if ($filtre_durum) { $where .= " AND durum=?"; $params[] = $filtre_durum; }
if ($filtre_kalan === '30') { $where .= " AND sonraki_kalibrasyon BETWEEN '$bugun' AND '$s30'"; }
elseif ($filtre_kalan === '60') { $where .= " AND sonraki_kalibrasyon BETWEEN '$bugun' AND '$s60'"; }
elseif ($filtre_kalan === 'gecmis') { $where .= " AND sonraki_kalibrasyon < '$bugun'"; }

try {
    $st = $db->prepare("SELECT * FROM kalibrasyon_cihazlar $where ORDER BY kayit_no");
    $st->execute($params);
    $cihazlar = $st->fetchAll(PDO::FETCH_ASSOC);
    $bolumler = $db->query("SELECT DISTINCT kullanim_bolumu FROM kalibrasyon_cihazlar WHERE aktif=1 ORDER BY kullanim_bolumu")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) { $cihazlar = []; $bolumler = []; }

$ay_adlari = ['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚙️ Kalibrasyon Yönetimi</h1>
    <div class="s-yol">Kalite / <b>Kalibrasyon</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-ekle" class="btn btn-t btn-sm">+ Yeni Cihaz</a>
  </div>
</div>

<div class="s-body">

<?php if ($durum === 'ok'): ?>
<div style="background:var(--bas-a);color:var(--bas);border-radius:var(--r);padding:10px 14px;margin-bottom:12px;font-weight:700">✅ İşlem başarıyla tamamlandı.</div>
<?php endif; ?>

<!-- ── Özet Kartlar ──────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:16px">
  <?php
  $kutular = [
    ['Toplam Cihaz',  $ozet['toplam'],     '#1E3A5F','#E0F2FE'],
    ['Uygun',         $ozet['okey'],        '#22C55E','#D1FAE5'],
    ['Sorunlu',       $ozet['sorunlu'],     '#EF4444','#FEE2E2'],
    ['Geçmiş Kalibr.',$ozet['gecmis'],      '#F59E0B','#FEF9C3'],
    ['30 Günde',      $ozet['yaklasan30'],  '#6366F1','#EDE9FE'],
    ['60 Günde',      $ozet['yaklasan60'],  '#0EA5E9','#E0F7FA'],
  ];
  foreach ($kutular as [$lbl,$val,$fg,$bg]):
  ?>
  <div style="background:<?= $bg ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $fg ?>"><?= (int)$val ?></div>
    <div style="font-size:10px;font-weight:700;color:<?= $fg ?>;text-transform:uppercase;opacity:.8;margin-top:2px"><?= $lbl ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- ── Aylık Plan Grafiği ────────────────────────────────────── -->
<div class="kart" style="margin-bottom:16px;padding:14px">
  <div style="font-size:13px;font-weight:800;margin-bottom:10px">📅 <?= $yil ?> Yılı Aylık Kalibrasyon Planı</div>
  <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:4px;align-items:end;height:80px">
    <?php for($m=1;$m<=12;$m++): $p=$aylik[$m]; $y=$yapilan[$m]; $max=max(1,max(array_values($aylik))); ?>
    <div style="display:flex;flex-direction:column;align-items:center;gap:2px">
      <div style="font-size:9px;font-weight:700;color:<?= $m===$ay?'var(--t)':'var(--m2)' ?>"><?= $p ?></div>
      <div style="width:100%;display:flex;flex-direction:column-reverse;gap:1px">
        <div style="height:<?= max(4,round($p/$max*50)) ?>px;background:<?= $m===$ay?'var(--t)':'#94A3B8' ?>;border-radius:3px 3px 0 0;opacity:.5"></div>
        <?php if($y>0): ?>
        <div style="height:<?= max(4,round($y/$max*50)) ?>px;background:<?= $m<=$ay?'#22C55E':'#94A3B8' ?>;border-radius:3px 3px 0 0"></div>
        <?php endif; ?>
      </div>
      <div style="font-size:9px;color:<?= $m===$ay?'var(--t)':'var(--m2)' ?>;font-weight:<?= $m===$ay?'800':'400' ?>"><?= $ay_adlari[$m] ?></div>
    </div>
    <?php endfor; ?>
  </div>
  <div style="display:flex;gap:16px;margin-top:8px;font-size:11px">
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#94A3B8;border-radius:2px;opacity:.5;display:inline-block"></span>Plan</span>
    <span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;background:#22C55E;border-radius:2px;display:inline-block"></span>Yapılan</span>
  </div>
</div>

<!-- ── Filtreler ─────────────────────────────────────────────── -->
<div class="kart" style="margin-bottom:14px;padding:12px">
  <form method="GET" action="<?= BASE_URL ?>/panel.php" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="kalite-kalibrasyon-liste">
    <div class="form-grup" style="margin:0;min-width:160px">
      <label class="form-et">Bölüm</label>
      <select class="form-alan" name="bolum">
        <option value="">Tümü</option>
        <?php foreach ($bolumler as $b): ?>
        <option value="<?= htmlspecialchars($b) ?>" <?= $filtre_bolum===$b?'selected':'' ?>><?= htmlspecialchars($b) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-grup" style="margin:0;min-width:140px">
      <label class="form-et">Durum</label>
      <select class="form-alan" name="durum_f">
        <option value="">Tümü</option>
        <?php foreach (['OKEY','ARIZALI','KULLANIM DIŞI','KAYIP'] as $d): ?>
        <option value="<?= $d ?>" <?= $filtre_durum===$d?'selected':'' ?>><?= $d ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-grup" style="margin:0;min-width:140px">
      <label class="form-et">Kalibrasyon Durumu</label>
      <select class="form-alan" name="kalan">
        <option value="">Tümü</option>
        <option value="30" <?= $filtre_kalan==='30'?'selected':'' ?>>30 Gün İçinde</option>
        <option value="60" <?= $filtre_kalan==='60'?'selected':'' ?>>60 Gün İçinde</option>
        <option value="gecmis" <?= $filtre_kalan==='gecmis'?'selected':'' ?>>Süresi Geçmiş</option>
      </select>
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" class="btn btn-b btn-sm">Sıfırla</a>
  </form>
</div>

<!-- ── Cihaz Tablosu ─────────────────────────────────────────── -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <?php $sth = ['Kayıt No','Cihaz Adı','Marka/Model','Ölç. Aralığı','Bölüm','Son Kalibr.','Sonraki Kalibr.','Kalan Gün','Yapan Firma','Değerlendirme','Durum','İşlemler']; ?>
    <table id="kalibTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php foreach ($cihazlar as $c):
            $kalan = $c['sonraki_kalibrasyon'] ? (int)round((strtotime($c['sonraki_kalibrasyon'])-time())/86400) : null;
            if ($kalan === null) { $kalan_r='—'; $kalan_s='#94A3B8'; }
            elseif ($kalan < 0) { $kalan_r='<b style="color:#EF4444">'.abs($kalan).' gün geçti</b>'; $kalan_s='#EF4444'; }
            elseif ($kalan <= 30) { $kalan_r='<b style="color:#F59E0B">'.$kalan.' gün</b>'; $kalan_s='#F59E0B'; }
            elseif ($kalan <= 60) { $kalan_r='<span style="color:#6366F1">'.$kalan.' gün</span>'; $kalan_s='#6366F1'; }
            else { $kalan_r='<span style="color:var(--m2)">'.$kalan.' gün</span>'; $kalan_s='#64748B'; }
            // Satır arkaplan
            $row_bg = '';
            if ($kalan !== null && is_int($kalan)) {
                if ($kalan < 0) $row_bg = 'background:#FEF2F2';
                elseif ($kalan <= 30) $row_bg = 'background:#FFFBEB';
            }
            $durum_stil = ['OKEY'=>['#D1FAE5','#065F46'],'ARIZALI'=>['#FEE2E2','#991B1B'],'KULLANIM DIŞI'=>['#F1F5F9','#64748B'],'KAYIP'=>['#FEF9C3','#92400E']];
            [$d_bg,$d_fg] = $durum_stil[$c['durum']] ?? ['#F1F5F9','#334155'];
        ?>
        <tr style="<?= $row_bg ?>">
          <td style="font-weight:800;font-family:monospace;color:var(--t)"><?= htmlspecialchars($c['kayit_no']) ?></td>
          <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?= htmlspecialchars($c['cihaz_adi']) ?>"><?= htmlspecialchars($c['cihaz_adi']) ?></td>
          <td><?= htmlspecialchars($c['marka_model']??'') ?></td>
          <td style="font-size:11px"><?= htmlspecialchars($c['olcum_araligi']??'') ?></td>
          <td><?= htmlspecialchars($c['kullanim_bolumu']??'') ?></td>
          <td style="white-space:nowrap"><?= $c['son_kalibrasyon'] ? date('d.m.Y',strtotime($c['son_kalibrasyon'])) : '—' ?></td>
          <td style="white-space:nowrap"><?= $c['sonraki_kalibrasyon'] ? date('d.m.Y',strtotime($c['sonraki_kalibrasyon'])) : '—' ?></td>
          <td><?= $kalan_r ?></td>
          <td style="font-size:11px"><?= htmlspecialchars($c['yapan_firma']??'') ?></td>
          <td style="font-size:11px;max-width:160px"><?= htmlspecialchars($c['degerlendirme']??'') ?></td>
          <td><span style="background:<?= $d_bg ?>;color:<?= $d_fg ?>;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:800;white-space:nowrap"><?= htmlspecialchars($c['durum']) ?></span></td>
          <td style="white-space:nowrap">
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-detay&id=<?= $c['id'] ?>"
               class="btn btn-sm" style="background:var(--t-a);color:var(--t);padding:3px 8px;font-size:11px;text-decoration:none">📋</a>
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-guncelle&id=<?= $c['id'] ?>"
               class="btn btn-sm" style="background:var(--bil-a);color:var(--bil);padding:3px 8px;font-size:11px;text-decoration:none">✏️</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</div>

<script>
$(document).ready(function(){
  var tbl = $('#kalibTablo').DataTable({
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollX:true, scrollY:520, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',filename:'Kalibrasyon_<?= date('Ymd') ?>'},
      {extend:'print',text:'🖨 Yazdır'}
    ],
    drawCallback:function(){ $('#kalibTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){
      this.api().columns([4,10]).every(function(){
        var col=this, sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
        col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); });
      });
      $('#kalibTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); });
    }
  });
});
</script>
