<?php
/**
 * GKK Detay — İrsaliye satırları, Onay/Şartlı/Red
 * Route: kalite-gkk-detay
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

require_once ROOT_DIR.'/islemler/kalite/gkk_ortak.php';
global $db;

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}

$fis_id    = (int)($_GET['fis_id']    ?? 0);
$irsno     = trim($_GET['irsaliye_no'] ?? '');
$cari      = trim($_GET['cari']        ?? '');
$cari_kodu = trim($_GET['cari_kodu']   ?? '');
$tarih     = trim($_GET['tarih']       ?? '');

if(!$fis_id || !$irsno) {
    echo '<div class="s-body"><div style="padding:20px;color:#DC2626">⚠️ Geçersiz parametreler.</div></div>'; return;
}

// MES_SATINALMA satırları — aynı stok kodunu grupla
$satirlar = [];
if($tigerdb_pdo) {
    try {
        $st = $tigerdb_pdo->prepare(
            "SELECT MIN(SATIR_ID) AS SATIR_ID, STOK_KODU,
                    MAX(STOK_ADI) AS STOK_ADI,
                    SUM(MIKTAR) AS MIKTAR,
                    MAX(BIRIM) AS BIRIM,
                    MAX(ISNULL(LOT_NO,'')) AS LOT_NO,
                    MAX(ISNULL(STOK_YERI,'')) AS STOK_YERI,
                    MAX(ISNULL(AMBAR,1)) AS AMBAR
             FROM MES_SATINALMA
             WHERE FIS_ID=?
             GROUP BY STOK_KODU
             ORDER BY MIN(SATIR_ID)"
        );
        $st->execute([$fis_id]);
        $satirlar = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Her satır için paket ve GKK durumu
$paket_durum = []; $gkk_sonuc = [];
foreach($satirlar as $s) {
    $sid  = $s['SATIR_ID'];
    $sk   = trim($s['STOK_KODU']??'');
    // Paketler
    try {
        $st2 = $mes_pdo->prepare("SELECT * FROM dbo.PAKETLER WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF IN (0,2) ORDER BY ID");
        $st2->execute([$irsno, $sk]);
        $paket_durum[$sid] = $st2->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $paket_durum[$sid] = []; }
    // GKK sonucu
    $gkk_sonuc[$sid] = gkkSonucuVar($fis_id, $sid, $db) ?: null;
}

// Tedarikçi e-postaları
$ted_mails = tedarikciEmail($cari, $db);
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔬 GKK Detay</h1>
    <div class="s-yol">Kalite / <a href="?sayfa=kalite-gkk-liste" style="color:var(--t)">GKK</a> / <b><?=htmlspecialchars($irsno)?></b></div>
  </div>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:300px 1fr;gap:14px;align-items:flex-start">

<!-- Sol: Bilgi -->
<div style="display:flex;flex-direction:column;gap:12px">
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #4F46E5">
    <div style="padding:14px;background:#EEF2FF;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#4F46E5">📋 İrsaliye</div>
    </div>
    <div style="padding:16px">
      <?php foreach([
        ['İrsaliye No', $irsno, '#4F46E5'],
        ['Tarih', $tarih, null],
        ['Tedarikçi', $cari, null],
        ['Cari Kodu', $cari_kodu, null],
      ] as [$lbl,$val,$renk]):?>
      <div style="margin-bottom:10px;padding:8px 10px;background:var(--kenar-a);border-radius:var(--r);<?=$renk?"border-left:3px solid $renk":''?>">
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--m3);margin-bottom:2px"><?=$lbl?></div>
        <div style="font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($val)?>"><?=htmlspecialchars($val)?></div>
      </div>
      <?php endforeach;?>

      <?php if(!empty($ted_mails)):?>
      <div style="margin-top:12px;padding:10px;background:#FEF3C7;border-radius:var(--r);border-left:3px solid #F59E0B">
        <div style="font-size:10px;font-weight:700;color:#92400E;margin-bottom:4px">📧 Tedarikçi E-posta</div>
        <?php foreach($ted_mails as $m):?>
        <div style="font-size:11px;font-family:monospace"><?=htmlspecialchars($m)?></div>
        <?php endforeach;?>
      </div>
      <?php endif;?>
    </div>
  </div>

  <!-- Özet -->
  <?php
  $toplam = count($satirlar);
  $onay = $sart = $red = $bekl = 0;
  foreach($satirlar as $s) {
      $g = $gkk_sonuc[$s['SATIR_ID']];
      if(!$g) $bekl++;
      elseif($g['sonuc']==='ONAY') $onay++;
      elseif($g['sonuc']==='SART_ONAY') $sart++;
      elseif($g['sonuc']==='RED') $red++;
  }
  ?>
  <div class="kart" style="padding:14px">
    <div style="font-weight:800;font-size:12px;margin-bottom:10px;color:var(--m2)">📊 Özet</div>
    <?php foreach([
      ['Toplam Kalem', $toplam, '#6B7280'],
      ['✅ Onay',      $onay,   '#16A34A'],
      ['⚠️ Şartlı',    $sart,   '#F59E0B'],
      ['❌ Red',        $red,    '#DC2626'],
      ['⏳ Bekliyor',   $bekl,   '#6B7280'],
    ] as [$l,$v,$renk]):?>
    <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:12px">
      <span style="color:var(--m2)"><?=$l?></span>
      <span style="font-weight:800;color:<?=$renk?>"><?=$v?></span>
    </div>
    <?php endforeach;?>
  </div>
</div>

<!-- Sağ: Satırlar -->
<div>
  <?php foreach($satirlar as $s):
    $sid  = $s['SATIR_ID'];
    $sk   = trim($s['STOK_KODU']??'');
    $pktler = $paket_durum[$sid] ?? [];
    $gkk    = $gkk_sonuc[$sid];
    $etiket_alindi = !empty($pktler);
  ?>
  <div class="kart gkk-kalem" data-fis="<?=$fis_id?>" data-sid="<?=$sid?>" data-sk="<?=htmlspecialchars($sk,ENT_QUOTES|ENT_HTML5)?>"
       style="padding:0;overflow:hidden;margin-bottom:12px;border-top:3px solid <?=$gkk?($gkk['sonuc']==='ONAY'?'#16A34A':($gkk['sonuc']==='SART_ONAY'?'#F59E0B':'#DC2626')):'#6B7280'?>">
    <!-- Başlık -->
    <div style="padding:12px 16px;background:var(--kenar-a);border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div>
        <span style="font-weight:800;font-size:13px"><?=htmlspecialchars($sk)?></span>
        <span style="font-size:11px;color:var(--m3);margin-left:8px"><?=htmlspecialchars($s['STOK_ADI']??'')?></span>
      </div>
      <div>
        <?php if(!$etiket_alindi):?>
        <span style="background:#FEF3C7;color:#92400E;padding:3px 10px;border-radius:10px;font-size:10px;font-weight:700">📦 Etiket Bekleniyor</span>
        <?php elseif($gkk):?>
          <?php if($gkk['sonuc']==='ONAY'):?>
          <span style="background:#D1FAE5;color:#065F46;padding:3px 10px;border-radius:10px;font-size:10px;font-weight:700">✅ Onaylandı</span>
          <?php elseif($gkk['sonuc']==='SART_ONAY'):?>
          <span style="background:#FEF3C7;color:#92400E;padding:3px 10px;border-radius:10px;font-size:10px;font-weight:700">⚠️ Şartlı Onay</span>
          <?php else:?>
          <span style="background:#FEE2E2;color:#7F1D1D;padding:3px 10px;border-radius:10px;font-size:10px;font-weight:700">❌ Red</span>
          <?php endif;?>
        <?php else:?>
        <span style="background:#DBEAFE;color:#1E40AF;padding:3px 10px;border-radius:10px;font-size:10px;font-weight:700">⏳ GKK Bekliyor</span>
        <?php endif;?>
      </div>
    </div>
    <div style="padding:14px 16px">
      <!-- Satır bilgisi -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;font-size:11px">
        <div><span style="color:var(--m3)">Miktar:</span> <b><?=number_format((float)($s['MIKTAR']??0),2)?> <?=htmlspecialchars($s['BIRIM']??'')?></b></div>
        <div><span style="color:var(--m3)">LOT:</span> <b><?=htmlspecialchars($s['LOT_NO']??'—')?></b></div>
        <div><span style="color:var(--m3)">Stok Yeri:</span> <b><?=htmlspecialchars($s['STOK_YERI']??'—')?></b></div>
        <div><span style="color:var(--m3)">Ambar:</span> <b><?=htmlspecialchars((string)($s['AMBAR']??''))?></b></div>
      </div>

      <!-- Paketler -->
      <?php if($etiket_alindi):?>
      <div style="margin-bottom:12px;max-height:140px;overflow-y:auto;border:1px solid var(--kenar);border-radius:var(--r)">
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead style="position:sticky;top:0;background:#1E293B;color:#fff">
            <tr>
              <th style="padding:5px 8px;text-align:left">Paket No</th>
              <th style="padding:5px 8px;text-align:right">Miktar</th>
              <th style="padding:5px 8px">Raf</th>
              <th style="padding:5px 8px">Ambar</th>
              <th style="padding:5px 8px">Durum</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach($pktler as $j=>$pkg):
            $raf = $pkg['STOK_YERI']??'';
            $aktif = (int)($pkg['AKTIF']??0);
            $pbg = $aktif===2?'#FFF0F0':($j%2===0?'#fff':'var(--kenar-a)');
          ?>
          <tr style="border-bottom:1px solid var(--kenar);background:<?=$pbg?>">
            <td style="padding:4px 8px;font-family:monospace;font-weight:700"><?=htmlspecialchars($pkg['PAKET_NO']??'')?></td>
            <td style="padding:4px 8px;text-align:right;font-weight:700;color:#16A34A"><?=number_format((float)($pkg['MIKTAR']??0),2)?></td>
            <td style="padding:4px 8px;font-weight:700;color:<?=str_contains($raf,'RED')?'#DC2626':(str_contains($raf,'OK')?'#16A34A':'var(--m2)')?>"><?=htmlspecialchars($raf)?></td>
            <td style="padding:4px 8px"><?=$pkg['AMBAR']??''?></td>
            <td style="padding:4px 8px"><?=$aktif===2?'<span style="color:#DC2626;font-size:10px">Karantina</span>':'<span style="color:#16A34A;font-size:10px">Aktif</span>'?></td>
          </tr>
          <?php endforeach;?>
          </tbody>
        </table>
      </div>

      <!-- GKK Sonuç kaydı varsa detay göster -->
      <?php if($gkk):?>
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:10px 12px;margin-bottom:12px;font-size:11px">
        <div style="margin-bottom:4px"><b>Kontrol:</b> <?=htmlspecialchars($gkk['kontrol_eden']??'')?> — <?=htmlspecialchars(substr($gkk['kontrol_tarihi']??'',0,16))?></div>
        <?php
        $ka = (int)($gkk['kontrol_adet']??0);
        $ha = (int)($gkk['hata_adet']??0);
        if($ka > 0):
            $oran = $ka > 0 ? round(($ha/$ka)*100,1) : 0;
        ?>
        <div style="display:flex;gap:8px;margin-bottom:4px;flex-wrap:wrap">
          <span style="background:#F0FDF4;border:1px solid #BBF7D0;color:#15803D;padding:2px 8px;border-radius:6px;font-size:10px;font-weight:700">✅ Kontrol: <?=$ka?> adet</span>
          <span style="background:#FEF2F2;border:1px solid #FCA5A5;color:#DC2626;padding:2px 8px;border-radius:6px;font-size:10px;font-weight:700">❌ Hata: <?=$ha?> adet</span>
          <span style="background:#FEF3C7;border:1px solid #FDE68A;color:#92400E;padding:2px 8px;border-radius:6px;font-size:10px;font-weight:700">📊 Oran: %<?=$oran?></span>
        </div>
        <?php endif;?>
        <?php if(!empty($gkk['aciklama'])):?>
        <div style="margin-bottom:4px"><b>Açıklama:</b> <?=htmlspecialchars($gkk['aciklama']??'')?></div>
        <?php endif;?>
        <?php if(!empty($gkk['logo_fis_no'])):?>
        <?php
            $fno = $gkk['logo_fis_no']??'';
            $fno_goster = ($fno && $fno !== '~' && substr($fno,0,4)!=='REF-') ? $fno : '';
            $sonuc_gkk  = $gkk['sonuc']??'';
            if($sonuc_gkk==='RED')           $transfer_yonu = '🔴 Merkez → Karantina transferi yapıldı';
            elseif($sonuc_gkk==='ONAY')      $transfer_yonu = '🟢 Karantina → Merkez transferi yapıldı';
            elseif($sonuc_gkk==='SART_ONAY') $transfer_yonu = '🟡 Karantina → Merkez transferi yapıldı';
            else $transfer_yonu = '🔄 Ambar transferi yapıldı';
        ?>
        <div style="background:#DBEAFE;border:1px solid #BFDBFE;border-radius:6px;padding:5px 10px;display:inline-flex;align-items:center;gap:6px;margin-top:2px">
          <span style="font-size:10px;color:#1E40AF"><?=htmlspecialchars($transfer_yonu)?></span>
          <?php if($fno_goster):?>
          <span style="font-weight:800;font-family:monospace;color:#1E40AF;margin-left:6px"><?=htmlspecialchars($fno_goster)?></span>
          <?php endif;?>
        </div>
        <?php endif;?>
      </div>
      <?php endif;?>

      <!-- Onay/Şartlı/Red butonları — sadece GKK yapılmamışsa VEYA Red ise tekrar onay mümkün -->
      <?php
        $gkk_yapilmis = $gkk && $gkk['sonuc'] !== 'RED';
        $red_ise_onaylanabilir = $gkk && $gkk['sonuc'] === 'RED';
      ?>
      <?php if(!$gkk_yapilmis):?>
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:12px;margin-bottom:0">
        <label class="form-et" style="font-size:11px">GKK Açıklama (opsiyonel)</label>
        <textarea id="aciklama-<?=$sid?>" class="form-alan" rows="2" style="resize:none;margin-bottom:8px" placeholder="Kontrol notu..."></textarea>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
          <div>
            <label style="font-size:10px;font-weight:700;color:var(--m3);display:block;margin-bottom:3px">Kontrol Edilen Adet</label>
            <input type="number" id="kontrol-adet-<?=$sid?>" class="form-alan" min="0" step="1" placeholder="Örn: 30" style="font-size:12px">
          </div>
          <div>
            <label style="font-size:10px;font-weight:700;color:#DC2626;display:block;margin-bottom:3px">Hata Tespit Edilen Adet</label>
            <input type="number" id="hata-adet-<?=$sid?>" class="form-alan" min="0" step="1" placeholder="Örn: 5" style="font-size:12px;border-color:#FCA5A5">
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button type="button" class="btn-gkk" data-sonuc="ONAY"
                  class="btn" style="padding:8px 16px;background:#16A34A;color:#fff;font-weight:700;font-size:12px">
            ✅ Onayla
          </button>
          <button type="button" class="btn-gkk" data-sonuc="SART_ONAY"
                  class="btn" style="padding:8px 16px;background:#F59E0B;color:#fff;font-weight:700;font-size:12px">
            ⚠️ Şartlı Onayla
          </button>
          <button type="button" class="btn-gkk" data-sonuc="RED"
                  class="btn" style="padding:8px 16px;background:#DC2626;color:#fff;font-weight:700;font-size:12px">
            ❌ Red Et
          </button>
        </div>
      </div>
      <?php elseif($red_ise_onaylanabilir):?>
      <div style="background:#FEF3C7;border-radius:var(--r);padding:12px">
        <div style="font-size:11px;color:#92400E;font-weight:700;margin-bottom:8px">⚠️ Bu kalem reddedilmiş — Onaylamak için aşağıdaki butonu kullanın</div>
        <textarea id="aciklama-<?=$sid?>" class="form-alan" rows="2" style="resize:none;margin-bottom:8px" placeholder="Yeniden onay açıklaması..."></textarea>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
          <div>
            <label style="font-size:10px;font-weight:700;color:var(--m3);display:block;margin-bottom:3px">Kontrol Edilen Adet</label>
            <input type="number" id="kontrol-adet-<?=$sid?>" class="form-alan" min="0" step="1" placeholder="Örn: 30" style="font-size:12px">
          </div>
          <div>
            <label style="font-size:10px;font-weight:700;color:#DC2626;display:block;margin-bottom:3px">Hata Adet</label>
            <input type="number" id="hata-adet-<?=$sid?>" class="form-alan" min="0" step="1" placeholder="Örn: 5" style="font-size:12px">
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button type="button" class="btn-gkk" data-sonuc="ONAY"
                  class="btn" style="padding:8px 16px;background:#16A34A;color:#fff;font-weight:700;font-size:12px">
            ✅ Yeniden Onayla (Karantina → Merkez)
          </button>
          <button type="button" class="btn-gkk" data-sonuc="SART_ONAY"
                  class="btn" style="padding:8px 16px;background:#F59E0B;color:#fff;font-weight:700;font-size:12px">
            ⚠️ Şartlı Onayla
          </button>
        </div>
      </div>
      <?php endif;?>

      <?php else:?>
      <div style="background:#FEF3C7;border-radius:var(--r);padding:10px 12px;font-size:12px;color:#92400E">
        📦 Bu kalem için henüz etiket alınmamış. GKK kontrol yapılamaz.
      </div>
      <?php endif;?>
    </div>
  </div>
  <?php endforeach;?>
</div><!-- /sağ -->
</div><!-- /grid -->
</div><!-- /s-body -->

<script>
var BASE_GKK = <?=json_encode(BASE_URL)?>;
var GKK_FIS  = <?=(int)$fis_id?>;
var GKK_IRSNO= <?=json_encode($irsno)?>;
var GKK_CARI = <?=json_encode($cari)?>;
var GKK_MAILS= <?=json_encode(array_values($ted_mails))?>;

document.addEventListener('click', function(e){
    var btn = e.target.closest('.btn-gkk');
    if(!btn) return;
    var kalem = btn.closest('.gkk-kalem');
    if(!kalem) return;
    var fis_id    = parseInt(kalem.dataset.fis);
    var satir_id  = parseInt(kalem.dataset.sid);
    var stok_kodu = kalem.dataset.sk;
    var sonuc     = btn.dataset.sonuc;
    var aciklama  = (document.getElementById('aciklama-'+satir_id)||{value:''}).value||'';
    var kadet = parseInt((document.getElementById('kontrol-adet-'+satir_id)||{value:0}).value)||0;
    var hadet = parseInt((document.getElementById('hata-adet-'+satir_id)||{value:0}).value)||0;

    btn.disabled=true;
    btn.textContent='⏳...';
    var sonucLabel = sonuc==='ONAY'?'Onaylanıyor':(sonuc==='SART_ONAY'?'Şartlı Onay':'Red Ediliyor');
    if(typeof Swal !== 'undefined') {
        Swal.fire({title:sonucLabel+'...', text:'Lütfen bekleyiniz.', allowOutsideClick:false, allowEscapeKey:false, showConfirmButton:false, didOpen:function(){ Swal.showLoading(); }});
    }

    fetch(BASE_GKK+'/islemler/kalite/gkk_kaydet.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            fis_id:fis_id, satir_id:satir_id,
            sonuc:sonuc, stok_kodu:stok_kodu,
            aciklama:aciklama,
            kontrol_adet:kadet, hata_adet:hadet
        })
    })
    .then(function(r){
        return r.text().then(function(t){
            console.log('GKK yanıt:', t.substring(0,400));
            // PHP warning/notice olabilir — JSON kısmını çıkar
            var jsonStart = t.indexOf('{');
            var jsonStr = jsonStart >= 0 ? t.substring(jsonStart) : t;
            try{ return JSON.parse(jsonStr); }
            catch(je){ throw new Error('JSON değil: '+t.substring(0,200)); }
        });
    })
    .then(function(d){
        btn.disabled=false;
        btn.textContent = sonuc==='ONAY'?'✅ Onayla':(sonuc==='SART_ONAY'?'⚠️ Şartlı Onayla':'❌ Red Et');
        if(d.detail) console.error('GKK detay:', d.detail);
        if(d.success){
            if(sonuc==='RED'){
                var oran = kadet>0 ? ((hadet/kadet)*100).toFixed(1) : null;
                var kb   = kadet>0
                    ? ('Kontrol Edilen Adet: '+kadet+'\n'
                      +'Hata Tespit Edilen Adet: '+hadet+'\n'
                      +(oran ? 'Hata Oranı: %'+oran+'\n' : ''))
                    : '';
                var body =
                    'Sayın '+GKK_CARI+',\n'
                    +GKK_IRSNO+' nolu irsaliyenizde bulunan '+stok_kodu+' stok kodlu ürün, giriş kalite kontrol sürecinde RED sonucu almıştır.\n'
                    +(aciklama?'Red Gerekçesi: '+aciklama+'\n':'')
                    +kb
                    +'Konu ile ilgili üretim ve sevkiyat süreçlerinizin acil olarak kontrol edilerek;\n\n'
                    +'* Hatanın oluşma nedenine ilişkin detaylı kök neden analizinin,\n'
                    +'* Alınan ve alınacak düzeltici / önleyici faaliyetlerin detaylı aksiyon planı ile birlikte paylaşılmasının,\n'
                    +'* Aynı hatayı içerebilecek stok, yarı mamul ve sevkiyatların kontrol altına alınarak riskli ürünlerin sevkiyatının durdurulmasının,\n'
                    +'* Tarafımıza acil şekilde OK ürün hazırlanarak sevk edilmesi için gerekli aksiyonun alınmasının,\n'
                    +'ivedilikle tarafımıza yazılı olarak iletilmesini rica ederiz.\n\n'
                    +'Üretim sürekliliğimizin etkilenmemesi adına sürecin öncelikli olarak değerlendirilmesi önem arz etmektedir.\n\n'
                    +'Saygılarımızla,\nPoliza Endüstri A.Ş. — Kalite Kontrol';
                var mailTo = GKK_MAILS.length > 0 ? GKK_MAILS.join(';') : '';
                window.open('mailto:'+mailTo
                    +'?subject='+encodeURIComponent('GKK Red Bildirimi — '+GKK_IRSNO+' / '+stok_kodu)
                    +'&body='+encodeURIComponent(body), '_blank');
            }
            if(typeof Swal !== 'undefined') {
        Swal.fire({icon:'success', title:'İşlem Tamamlandı',
            text: sonuc==='ONAY'?'Ürün onaylandı.': (sonuc==='SART_ONAY'?'Şartlı onay verildi.':'Red işlemi tamamlandı. Ambar transferi yapıldı.'),
            confirmButtonColor:'#16A34A', confirmButtonText:'Tamam', timer:2000, timerProgressBar:true
        }).then(function(){ location.reload(); });
    } else { setTimeout(function(){location.reload();},800); }
        } else {
            if(typeof Swal !== 'undefined') {
        Swal.fire({icon:'error', title:'İşlem Başarısız', html:'<b>'+d.message+'</b>', confirmButtonColor:'#DC2626', confirmButtonText:'Tamam'});
    } else { alert('Hata: '+d.message); }
        }
    })
    .catch(function(e){
        if(typeof Swal !== 'undefined') Swal.close();
        btn.disabled=false;
        btn.textContent = sonuc==='ONAY'?'✅ Onayla':(sonuc==='SART_ONAY'?'⚠️ Şartlı Onayla':'❌ Red Et');
        if(typeof Swal !== 'undefined') {
            Swal.fire({icon:'error', title:'Bağlantı Hatası', text:e.message, confirmButtonColor:'#DC2626'});
        } else { alert('Hata: '+e.message); }
    });
});
</script>