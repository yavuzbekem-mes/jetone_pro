<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Birkaç örnek döküman al
$rows = $db->query("SELECT id, dok_no, dok_adi, dok_yol FROM dokuman_listesi WHERE dok_yol IS NOT NULL AND dok_yol != '' LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="s-bar"><div><h1 class="s-bas">🔧 Doküman Erişim Testi</h1></div></div>
<div class="s-body">
<div class="kart">
<p style="margin-bottom:16px;font-size:13px;color:var(--m2)">
Her satır için <b>URL</b>'e tıklayın — tarayıcı açıyorsa yol doğru demektir.
</p>
<table class="tablo" style="width:100%">
<thead><tr style="background:#1E3A5F!important">
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">ID</th>
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">Dok No</th>
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">DB yolu (ham)</th>
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">Oluşturulan URL</th>
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">Fiziksel Var mı?</th>
  <th style="background:#1E3A5F!important;color:#fff!important;padding:8px">Test</th>
</tr></thead>
<tbody>
<?php foreach ($rows as $r):
    $yol = trim($r['dok_yol']);
    $klasor = dirname($yol);
    $dosya  = basename($yol);
    $url    = BASE_URL . '/' . $klasor . '/' . rawurlencode($dosya);
    $fiziksel = dirname(dirname(__DIR__)) . '/' . $yol;
    $var = file_exists($fiziksel);
?>
<tr>
  <td><?= $r['id'] ?></td>
  <td><?= htmlspecialchars($r['dok_no']??'') ?></td>
  <td style="font-size:10px;font-family:monospace;word-break:break-all"><?= htmlspecialchars($yol) ?></td>
  <td style="font-size:10px;font-family:monospace;word-break:break-all"><?= htmlspecialchars($url) ?></td>
  <td style="text-align:center"><?= $var ? '✅' : '❌' ?></td>
  <td><a href="<?= htmlspecialchars($url) ?>" target="_blank" class="btn btn-t btn-sm">Aç</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div style="margin-top:24px;padding:16px;background:var(--kenar-a);border-radius:var(--r);font-size:12px">
<b>BASE_URL:</b> <?= BASE_URL ?><br>
<b>Kök dizin:</b> <?= dirname(dirname(__DIR__)) ?><br>
<b>kys_dökümanlar klasörü var mı:</b>
<?= is_dir(dirname(dirname(__DIR__)) . '/kys_dökümanlar') ? '✅ kys_dökümanlar' : '❌' ?>
<?= is_dir(dirname(dirname(__DIR__)) . '/kys_dokumanlar') ? ' ✅ kys_dokumanlar' : '' ?>
</div>
</div>
</div>
