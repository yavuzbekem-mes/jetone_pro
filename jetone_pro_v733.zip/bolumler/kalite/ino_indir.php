<?php
/**
 * JETONE.PRO — .ino Dosya İndirme Endpoint
 * bolumler/kalite/ino_indir.php
 * Panel.php'yi bypass eder — direkt URL ile çağrılır
 * Örnek: http://localhost:4459/jetone_pro/bolumler/kalite/ino_indir.php?kod=KRT-01
 */

// Output buffering başlat — config'in herhangi bir çıktısını yakala
ob_start();

require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$kod   = preg_replace('/[^A-Z0-9\-]/', '', strtoupper(trim($_GET['kod'] ?? '')));
$dosya = __DIR__ . '/ino/tekmelik_' . $kod . '.ino';

if (empty($kod) || !file_exists($dosya)) {
    ob_end_clean();
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h3>Dosya bulunamadı: ' . htmlspecialchars($kod) . '</h3>';
    echo '<p>Beklenen yol: bolumler/kalite/ino/tekmelik_' . htmlspecialchars($kod) . '.ino</p>';
    exit;
}

// Tüm birikmiş çıktıyı temizle, header gönder
ob_end_clean();

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="tekmelik_' . $kod . '.ino"');
header('Content-Length: ' . filesize($dosya));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');

readfile($dosya);
exit;
