<?php
/**
 * 8D Detay — 8 adım sekme görünümü
 * panel.php: 'kalite-8d-detay' => 'bolumler/kalite/sekizd_detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id=(int)($_GET['id']??0);
if(!$id){echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-8d';</script>";exit;}
$s=$db->prepare("SELECT * FROM kal_sekizd WHERE id=?");$s->execute([$id]);$r=$s->fetch(PDO::FETCH_ASSOC);
if(!$r){echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-8d';</script>";exit;}

$mesaj='';$mesaj_tip='';

if(isset($_POST['action'])){
    switch($_POST['action']){
        case 'adim_ilerlet':
            $siradaki=['d1'=>'d2','d2'=>'d3','d3'=>'d4','d4'=>'d5','d5'=>'d6','d6'=>'d7','d7'=>'d8','d8'=>'kapandi'];
            $yeni=$siradaki[$r['durum']]??'kapandi';
            $db->prepare("UPDATE kal_sekizd SET durum=? WHERE id=?")->execute([$yeni,$id]);
            $r['durum']=$yeni; $mesaj=$yeni==='kapandi'?'8D kapandı! 🎉':'Sonraki adıma geçildi.'; $mesaj_tip='ok'; break;
        case 'durum_guncelle':
            $db->prepare("UPDATE kal_sekizd SET durum=? WHERE id=?")->execute([$_POST['durum'],$id]);
            $r['durum']=$_POST['durum']; $mesaj='Güncellendi.'; $mesaj_tip='ok'; break;
        case 'sekizd_sil':
            $dk=$db->prepare("SELECT dosya_yolu FROM kal_sekizd_dokuman WHERE sekizd_id=?");$dk->execute([$id]);
            foreach($dk->fetchAll(PDO::FETCH_COLUMN) as $y){$f=dirname(dirname(__DIR__)).'/'.$y;if(file_exists($f))@unlink($f);}
            $db->prepare("DELETE FROM kal_sekizd WHERE id=?")->execute([$id]);
            echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-8d';</script>";exit;
        case 'dok_sil':
            $dk=$db->prepare("SELECT * FROM kal_sekizd_dokuman WHERE id=? AND sekizd_id=?");$dk->execute([(int)$_POST['dok_id'],$id]);$dk=$dk->fetch(PDO::FETCH_ASSOC);
            if($dk){$f=dirname(dirname(__DIR__)).'/'.$dk['dosya_yolu'];if(file_exists($f))@unlink($f);$db->prepare("DELETE FROM kal_sekizd_dokuman WHERE id=?")->execute([$dk['id']]);}
            $mesaj='Silindi.';$mesaj_tip='ok'; break;
    }
}

// Doküman yükle
if(isset($_FILES['dosya'])&&$_FILES['dosya']['error']===0){
    $dir=dirname(dirname(__DIR__)).'/uploads/sekizd/'.$id.'/';
    if(!is_dir($dir))mkdir($dir,0777,true);
    $ext=strtolower(pathinfo($_FILES['dosya']['name'],PATHINFO_EXTENSION));
    if(in_array($ext,['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','zip'])){
        $fn=time().'_'.preg_replace('/[^a-z0-9._-]/i','_',$_FILES['dosya']['name']);
        if(move_uploaded_file($_FILES['dosya']['tmp_name'],$dir.$fn)){
            $db->prepare("INSERT INTO kal_sekizd_dokuman(sekizd_id,adim,dosya_adi,dosya_yolu,tur,aciklama,yukleyen) VALUES(?,?,?,?,?,?,?)")
               ->execute([$id,$_POST['dok_adim']??'','$_FILES[dosya][name]','uploads/sekizd/'.$id.'/'.$fn,$_POST['dok_tur']??'diger',$_POST['dok_aciklama']??'',$kul_adi]);
            // Dosya adını düzelt
            $db->prepare("UPDATE kal_sekizd_dokuman SET dosya_adi=? WHERE id=?")->execute([$_FILES['dosya']['name'],(int)$db->lastInsertId()]);
            $mesaj='Yüklendi.';$mesaj_tip='ok';
        }
    } else{$mesaj='Desteklenmeyen tür.';$mesaj_tip='hata';}
}

$s2=$db->prepare("SELECT * FROM kal_sekizd_dokuman WHERE sekizd_id=? ORDER BY yuklenme_tarihi DESC");$s2->execute([$id]);$dokumanlar=$s2->fetchAll(PDO::FETCH_ASSOC);

$adim_no = preg_match('/^d(\d)$/',$r['durum'],$m)?(int)$m[1]:($r['durum']==='kapandi'?9:0);
$siradaki=['d1'=>'d2','d2'=>'d3','d3'=>'d4','d4'=>'d5','d5'=>'d6','d6'=>'d7','d7'=>'d8','d8'=>'kapandi'];
$sonraki_var = isset($siradaki[$r['durum']]);

function blk($b,$icerik,$renk='#1E3A5F'){
    if(!trim($icerik??''))return "<div style='color:var(--m3);font-size:12px;padding:8px 0'>Girilmemiş</div>";
    return "<div style='background:var(--kenar-a);border-radius:8px;padding:12px;border-left:3px solid $renk'><div style='font-size:10px;font-weight:700;color:$renk;margin-bottom:5px'>$b</div><div style='font-size:13px;color:var(--t);white-space:pre-wrap'>".htmlspecialchars($icerik)."</div></div>";
}
?>
<?php
// Önceden hesapla - HTML attribute içinde PHP kullanma
$sd_no    = htmlspecialchars($r['sekizd_no']);
$sd_dcnt  = count($dokumanlar);
$sd_durum = $r['durum'];
$sd_adim_lbls = ['d1'=>'D1 Ekip','d2'=>'D2 Problem','d3'=>'D3 Koruma','d4'=>'D4 Kok Neden',
                 'd5'=>'D5 Secim','d6'=>'D6 Uygulama','d7'=>'D7 Onleme','d8'=>'D8 Kapanis'];
$sd_adim_renkler = ['d1'=>'#1E3A5F','d2'=>'#DC2626','d3'=>'#F59E0B','d4'=>'#0EA5E9',
                    'd5'=>'#7C3AED','d6'=>'#16A34A','d7'=>'#0F766E','d8'=>'#6366F1'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">8D — <?=htmlspecialchars($r['sekizd_no'])?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d" style="color:var(--t)">8D</a> / <b><?=htmlspecialchars($r['sekizd_no'])?></b></div>
  </div>
  <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <?php if($sonraki_var): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="adim_ilerlet">
      <button type="submit" class="btn btn-t btn-sm">Sonraki Adim</button>
    </form>
    <?php endif; ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="durum_guncelle">
      <select name="durum" class="form-alan" style="font-size:12px;padding:4px 8px" onchange="this.form.submit()">
        <?php foreach(['d1'=>'D1','d2'=>'D2','d3'=>'D3','d4'=>'D4','d5'=>'D5','d6'=>'D6','d7'=>'D7','d8'=>'D8','kapandi'=>'Kapandi','iptal'=>'Iptal'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$r['durum']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-form&id=<?=$id?>" class="btn btn-b btn-sm">✏️ Duzenle</a>
    <button id="sekizdSilBtn"
      data-no="<?=$sd_no?>"
      data-dcnt="<?=$sd_dcnt?>"
      class="btn btn-sm" style="background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;font-size:12px;padding:5px 12px">
      🗑️ Sil
    </button>
  </div>
</div>

<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<!-- Başlık Kartı -->
<div class="kart" style="padding:14px;margin-bottom:14px">
  <div style="font-size:15px;font-weight:800;margin-bottom:10px"><?=htmlspecialchars($r['problem_ozeti'])?></div>
  <!-- 8 Adım ilerleme şeridi -->
  <div style="display:flex;gap:0;border-radius:8px;overflow:hidden;margin-bottom:8px">
    <?php foreach($sd_adim_renkler as $ak=>$arenk):
      $ano = (int)substr($ak,1);
      $aktif = $adim_no >= $ano;
    ?>
    <div onclick="tabGoster('<?=$ak?>')" style="flex:1;padding:8px 4px;text-align:center;background:<?=$aktif?$arenk:'var(--kenar)'?>;color:<?=$aktif?'#fff':'var(--m3)'?>;cursor:pointer">
      <div style="font-weight:900;font-size:11px"><?=strtoupper($ak)?></div>
      <div style="font-size:9px;opacity:.8"><?=explode(' ',$sd_adim_lbls[$ak])[1]?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <div style="display:flex;gap:10px;font-size:12px;color:var(--m2);flex-wrap:wrap">
    <span>📅 <?=date('d.m.Y',strtotime($r['acilis_tarihi']))?></span>
    <?php if($r['hedef_tarih']): ?><span>🏁 <?=date('d.m.Y',strtotime($r['hedef_tarih']))?></span><?php endif; ?>
    <?php if($r['d1_lider']): ?><span>👤 <?=htmlspecialchars($r['d1_lider'])?></span><?php endif; ?>
    <?php if($r['d2_etkilenen_adet']): ?><span>📊 <?=htmlspecialchars($r['d2_etkilenen_adet'])?></span><?php endif; ?>
    <?php if(count($dokumanlar)): ?><span>📎 <?=count($dokumanlar)?></span><?php endif; ?>
  </div>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:3px;border-bottom:2px solid var(--kenar);margin-bottom:14px;flex-wrap:wrap">
  <?php
    $sd_sekme_lbls = ['d1'=>'D1 Ekip','d2'=>'D2 Problem','d3'=>'D3 Koruma','d4'=>'D4 Kok Neden',
                      'd5'=>'D5 Secim','d6'=>'D6 Uygulama','d7'=>'D7 Onleme','d8'=>'D8 Kapanis'];
    foreach($sd_sekme_lbls as $ak=>$al):
      $ano = (int)substr($ak,1);
      $aktif_sekme = $adim_no >= $ano;
      $ilk = ($ak === 'd1');
  ?>
  <button onclick="tabGoster('<?=$ak?>')" id="sdtab_<?=$ak?>"
    style="padding:6px 12px;border:none;border-radius:6px 6px 0 0;font-size:11px;font-weight:700;cursor:pointer;margin-bottom:-2px;
           background:<?=$ilk?$sd_adim_renkler[$ak]:'var(--kenar-a)'?>;color:<?=$ilk?'#fff':'var(--m)'?>;
           opacity:<?=$aktif_sekme?1:0.5?>">
    <?=$al?>
  </button>
  <?php endforeach; ?>
  <button onclick="tabGoster('dokumanlar')" id="sdtab_dokumanlar"
    style="padding:6px 12px;border:none;border-radius:6px 6px 0 0;font-size:11px;font-weight:700;cursor:pointer;margin-bottom:-2px;background:var(--kenar-a);color:var(--m)">
    Dokumanlar (<?=count($dokumanlar)?>)
  </button>
</div>

<!-- D1 -->
<div id="tab_d1">
  <?=blk('Ekip Lideri',    $r['d1_lider']??'','#1E3A5F')?>
  <div style="margin-top:10px"><?=blk('Ekip Uyeleri',$r['d1_ekip']??'','#1E3A5F')?></div>
</div>

<!-- D2 -->
<div id="tab_d2" style="display:none">
  <?=blk('Problem Tanimi (5N1K)',$r['d2_problem']??'','#DC2626')?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
    <?=blk('Etkilenen Urun',$r['d2_etkilenen_urun']??'','#DC2626')?>
    <?=blk('Etkilenen Adet',$r['d2_etkilenen_adet']??'','#DC2626')?>
  </div>
</div>

<!-- D3 -->
<div id="tab_d3" style="display:none">
  <?=blk('Acil Koruma Onlemleri',$r['d3_gecici_onlem']??'','#F59E0B')?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
    <?=blk('Stok Blokaj',$r['d3_stok_blokaj']??'','#F59E0B')?>
    <?=blk('Musteri Bildirim',$r['d3_musteri_bildirim']??'','#F59E0B')?>
  </div>
</div>

<!-- D4 -->
<div id="tab_d4" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
    <?=blk('5 Neden Analizi',$r['d4_kok_neden']??'','#0EA5E9')?>
    <?=blk('Kacis Noktasi',$r['d4_kacis_nokta']??'','#DC2626')?>
  </div>
  <div class="kart" style="padding:12px">
    <div style="font-weight:700;font-size:12px;margin-bottom:8px">Balik Kilcigi</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
      <?php foreach([
        ['Insan',   'd4_balik_insan',   '#2563EB'],
        ['Yontem',  'd4_balik_yontem',  '#7C3AED'],
        ['Makine',  'd4_balik_makine',  '#D97706'],
        ['Malzeme', 'd4_balik_malzeme', '#16A34A'],
        ['Olcum',   'd4_balik_olcum',   '#EF4444'],
        ['Cevre',   'd4_balik_cevre',   '#0EA5E9'],
      ] as $b): ?>
      <div style="background:var(--kenar-a);border-radius:6px;padding:8px;border-top:3px solid <?=$b[2]?>">
        <div style="font-size:10px;font-weight:700;color:<?=$b[2]?>;margin-bottom:3px"><?=$b[0]?></div>
        <div style="font-size:12px"><?=trim($r[$b[1]]??'')?htmlspecialchars($r[$b[1]]):'—'?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- D5 -->
<div id="tab_d5" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <?=blk('Degerlendirilern Secenekler',$r['d5_secenekler']??'','#7C3AED')?>
    <?=blk('Secilen Cozum ve Gerekcesi',$r['d5_secilen']??'','#7C3AED')?>
  </div>
</div>

<!-- D6 -->
<div id="tab_d6" style="display:none">
  <?=blk('Uygulama Detayi',$r['d6_uygulama']??'','#16A34A')?>
  <div style="margin-top:10px"><?=blk('Olcum ve Dogrulama Sonuclari',$r['d6_olcum_sonuc']??'','#16A34A')?></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
    <?=blk('Sorumlu',$r['d6_sorumlu']??'','#16A34A')?>
    <?=blk('Tamamlanma',$r['d6_tamamlanma']??'','#16A34A')?>
  </div>
</div>

<!-- D7 -->
<div id="tab_d7" style="display:none">
  <?=blk('Sistem / Prosedur Degisiklikleri',$r['d7_sistem_degisim']??'','#0F766E')?>
  <div style="margin-top:10px"><?=blk('Egitim Plani',$r['d7_egitim']??'','#0F766E')?></div>
  <div style="margin-top:10px"><?=blk('Benzer Sureclere Yayilim',$r['d7_yayilim']??'','#0F766E')?></div>
</div>

<!-- D8 -->
<div id="tab_d8" style="display:none">
  <?=blk('Ogrenilen Dersler ve Ekip Tebrigi',$r['d8_tebrik']??'','#6366F1')?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
    <?=blk('Kapanis Onaylayan',$r['d8_kapanma_onay']??'','#6366F1')?>
    <?=blk('Kapanis Notu',$r['d8_kapanma_notu']??'','#6366F1')?>
  </div>
</div>

<!-- DOKÜMANLAR -->
<div id="tab_dokumanlar" style="display:none">
  <div style="display:flex;justify-content:flex-end;margin-bottom:10px">
    <button onclick="dokModalAc()" class="btn btn-t btn-sm">📎 Yukle</button>
  </div>
  <?php if(empty($dokumanlar)): ?>
  <div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Dokuman yuklenmemis.</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
  <?php foreach($dokumanlar as $dok):
    $ext=strtolower(pathinfo($dok['dosya_adi'],PATHINFO_EXTENSION));
    $dikon=in_array($ext,['jpg','jpeg','png','gif'])?'🖼️':($ext==='pdf'?'📄':'📎');
    $dok_id_safe=(int)$dok['id'];
  ?>
  <div class="kart" style="padding:10px">
    <div style="display:flex;gap:8px;margin-bottom:6px">
      <div style="font-size:20px"><?=$dikon?></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:11px;word-break:break-word"><?=htmlspecialchars($dok['dosya_adi'])?></div>
        <?php if($dok['adim']): ?><div style="font-size:10px;color:#2563EB"><?=strtoupper($dok['adim'])?></div><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:10px;color:var(--m3)"><?=date('d.m',strtotime($dok['yuklenme_tarihi']))?></span>
      <div style="display:flex;gap:4px">
        <a href="<?=BASE_URL?>/<?=$dok['dosya_yolu']?>" target="_blank" class="btn btn-b btn-sm" style="font-size:10px;padding:2px 7px">⬇️</a>
        <form method="POST" style="display:inline">
          <input type="hidden" name="action" value="dok_sil">
          <input type="hidden" name="dok_id" value="<?=$dok_id_safe?>">
          <button type="submit" onclick="return confirm('Silinsin mi?')" class="btn btn-sm" style="font-size:10px;padding:2px 7px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DOKUMAN MODAL -->
<div id="dokModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:400px;max-width:95vw;padding:18px">
  <div style="display:flex;justify-content:space-between;margin-bottom:12px">
    <div style="font-weight:800">Dokuman Yukle</div>
    <button onclick="modalKapat('dokModal')" style="border:none;background:none;font-size:18px;cursor:pointer">x</button>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Dosya</label><input type="file" name="dosya" class="form-alan" required></div>
      <div><label class="form-et">Adim</label>
        <select name="dok_adim" class="form-alan">
          <?php foreach(['d1'=>'D1','d2'=>'D2','d3'=>'D3','d4'=>'D4','d5'=>'D5','d6'=>'D6','d7'=>'D7','d8'=>'D8'] as $v=>$l): ?>
          <option value="<?=$v?>"><?=$l?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-et">Tur</label>
        <select name="dok_tur" class="form-alan">
          <option value="foto">Fotograf</option>
          <option value="rapor">Rapor</option>
          <option value="olcum">Olcum</option>
          <option value="prosedur">Prosedur</option>
          <option value="diger">Diger</option>
        </select>
      </div>
      <div><label class="form-et">Aciklama</label><input name="dok_aciklama" class="form-alan"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
      <button type="button" onclick="modalKapat('dokModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Yukle</button>
    </div>
  </form>
</div>
</div>

<!-- GİZLİ FORM -->
<form method="POST" id="sekizdSilForm" style="display:none">
  <input type="hidden" name="action" value="sekizd_sil">
</form>

</div><!-- /s-body -->

<script>
// 8D renkleri - sadece sabit değerler
var sdRenkler = {
    d1:'#1E3A5F',d2:'#DC2626',d3:'#F59E0B',d4:'#0EA5E9',
    d5:'#7C3AED',d6:'#16A34A',d7:'#0F766E',d8:'#6366F1',
    dokumanlar:'var(--t)'
};
var sdTabs = ['d1','d2','d3','d4','d5','d6','d7','d8','dokumanlar'];

// Silme butonu
document.getElementById('sekizdSilBtn').addEventListener('click', function(){
    var no   = this.dataset.no;
    var dcnt = parseInt(this.dataset.dcnt);
    var msg  = '"' + no + '" 8D kaydini silmek istiyorsunuz.\n';
    if(dcnt > 0) msg += dcnt + ' dokuman da silinecek.\n';
    msg += '\nGERI ALINAMAZ. Devam?';
    if(!confirm(msg)) return;
    var girilen = prompt('Onaylamak icin 8D numarasini girin:\n\n' + no);
    if(girilen === null) return;
    if(girilen.trim().toUpperCase() !== no.toUpperCase()){
        alert('Eslesmed. Iptal.');
        return;
    }
    document.getElementById('sekizdSilForm').submit();
});

// Sekme
function tabGoster(id){
    sdTabs.forEach(function(t){
        var panel = document.getElementById('tab_'+t);
        var btn   = document.getElementById('sdtab_'+t);
        if(panel) panel.style.display = t===id ? 'block' : 'none';
        if(btn){
            var renk = sdRenkler[id] || 'var(--t)';
            btn.style.background = t===id ? renk : 'var(--kenar-a)';
            btn.style.color      = t===id ? '#fff' : 'var(--m)';
        }
    });
}

function modalKapat(id){ document.getElementById(id).style.display = 'none'; }
function dokModalAc()  { document.getElementById('dokModal').style.display = 'flex'; }
</script>
