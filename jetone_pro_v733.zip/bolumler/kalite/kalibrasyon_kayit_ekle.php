<?php
/**
 * Kalibrasyon Kaydı Ekle (Sertifika yükleme dahil)
 * panel.php: 'kalite-kalibrasyon-kayit-ekle' => ...
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

$cihaz_id = (int)($_GET['cihaz_id'] ?? 0);
if (!$cihaz_id) { echo '<p>Cihaz ID gerekli</p>'; exit; }

$c = $db->prepare("SELECT * FROM kalibrasyon_cihazlar WHERE id=?");
$c->execute([$cihaz_id]);
$cihaz = $c->fetch(PDO::FETCH_ASSOC);
if (!$cihaz) { echo '<p>Cihaz bulunamadı</p>'; exit; }
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Kalibrasyon Kaydı Ekle</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" style="color:var(--t)">Kalibrasyon</a> /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-detay&id=<?= $cihaz_id ?>" style="color:var(--t)"><?= htmlspecialchars($cihaz['kayit_no']) ?></a> / <b>Yeni Kayıt</b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-detay&id=<?= $cihaz_id ?>" class="btn btn-b btn-sm">← Cihaza Dön</a>
</div>

<div class="s-body">

<!-- Cihaz özeti -->
<div class="kart" style="margin-bottom:14px;border-left:4px solid var(--t);padding:12px 16px">
  <div style="font-size:11px;color:var(--m2);font-weight:700">CİHAZ</div>
  <div style="font-size:15px;font-weight:800;color:var(--t)"><?= htmlspecialchars($cihaz['kayit_no']) ?> — <?= htmlspecialchars($cihaz['cihaz_adi']) ?></div>
  <div style="font-size:12px;color:var(--m2);margin-top:2px"><?= htmlspecialchars($cihaz['marka_model']??'') ?> | <?= htmlspecialchars($cihaz['kullanim_bolumu']??'') ?> | Periyot: <?= $cihaz['periyot_gun'] ?> gün</div>
</div>

<div class="kart" style="max-width:640px">
  <form action="<?= BASE_URL ?>/islemler/kalite/kalibrasyon_kayit_kaydet.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="cihaz_id" value="<?= $cihaz_id ?>">

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Kalibrasyon Tarihi <span class="zorunlu">*</span></label>
        <input class="form-alan" type="date" name="kalibrasyon_tarihi" required id="kalTarih"
               value="<?= date('Y-m-d') ?>" onchange="sonrakiHesapla()">
      </div>
      <div class="form-grup">
        <label class="form-et">Sonraki Kalibrasyon</label>
        <input class="form-alan" type="date" name="sonraki_tarih" id="sonrakiTarih"
               style="background:var(--kenar-a)" readonly>
        <div style="font-size:11px;color:var(--m2);margin-top:3px">Otomatik: +<?= $cihaz['periyot_gun'] ?> gün</div>
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Yapan Firma</label>
        <input class="form-alan" type="text" name="yapan_firma" value="<?= htmlspecialchars($cihaz['yapan_firma']??'') ?>" placeholder="Kalibrasyon firması...">
      </div>
      <div class="form-grup">
        <label class="form-et">Durum</label>
        <select class="form-alan" name="durum">
          <option value="OKEY" selected>OKEY</option>
          <option value="ARIZALI">ARIZALI</option>
          <option value="KULLANIM DIŞI">KULLANIM DIŞI</option>
        </select>
      </div>
    </div>

    <div class="form-grup">
      <label class="form-et">Değerlendirme Sonucu</label>
      <input class="form-alan" type="text" name="degerlendirme"
             value="<?= htmlspecialchars($cihaz['degerlendirme']??'') ?>"
             placeholder="KULLANIMA UYGUNDUR...">
    </div>

    <div class="form-grup">
      <label class="form-et">Kalibrasyon Sertifikası (PDF/JPG/PNG)</label>
      <input class="form-alan" type="file" name="sertifika" accept=".pdf,.jpg,.jpeg,.png,.webp"
             style="padding:6px">
      <div style="font-size:11px;color:var(--m2);margin-top:3px">Maks 10 MB — PDF veya görsel</div>
    </div>

    <div class="form-grup">
      <label class="form-et">Açıklama</label>
      <textarea class="form-alan" name="aciklama" rows="2" placeholder="Ek notlar..."></textarea>
    </div>

    <div class="form-footer">
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-detay&id=<?= $cihaz_id ?>" class="btn btn-b">İptal</a>
      <button type="submit" class="btn btn-t">💾 Kaydet</button>
    </div>
  </form>
</div>
</div>

<script>
var periyot = <?= (int)$cihaz['periyot_gun'] ?>;
function sonrakiHesapla(){
    var tarih = document.getElementById('kalTarih').value;
    if(!tarih) return;
    var d = new Date(tarih);
    d.setDate(d.getDate() + periyot);
    document.getElementById('sonrakiTarih').value = d.toISOString().split('T')[0];
}
sonrakiHesapla();
</script>
