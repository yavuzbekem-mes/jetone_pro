<?php
/**
 * JETONE.PRO — Kalite Denetimleri
 * panel.php: 'kalite-denetim' => 'bolumler/kalite/denetim.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// ── Tabloları garantile ──────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS kal_denetim (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    denetim_kodu    VARCHAR(30) UNIQUE NOT NULL,
    denetim_turu    ENUM('ic_denetim','tedarikci','iso_9001','musteri','proses','diger') DEFAULT 'ic_denetim',
    denetim_konusu  VARCHAR(200),
    denetim_tarihi  DATE NOT NULL,
    denetci_adi     VARCHAR(100),
    denetlenen_bolum VARCHAR(100),
    denetlenen_kisi  VARCHAR(100),
    genel_durum     ENUM('planlandi','devam_ediyor','tamamlandi','iptal') DEFAULT 'planlandi',
    aciklama        TEXT,
    olusturan       VARCHAR(100),
    kayit_tarihi    DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tarih(denetim_tarihi),
    INDEX idx_durum(genel_durum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS kal_denetim_bulgu (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    denetim_id      INT UNSIGNED NOT NULL,
    bulgu_no        VARCHAR(20),
    bulgu_tanimi    TEXT NOT NULL,
    bulgu_turu      ENUM('buyuk_uygunsuzluk','kucuk_uygunsuzluk','gozlem','iyilestirme') DEFAULT 'kucuk_uygunsuzluk',
    standart_madde  VARCHAR(100),
    kok_neden       TEXT,
    dof_aksiyon     TEXT,
    sorumlu         VARCHAR(100),
    hedef_tarih     DATE,
    tamamlanma_tarihi DATE,
    dogrulayan      VARCHAR(100),
    dogrulama_yontemi VARCHAR(200),
    durum           ENUM('acik','devam_ediyor','tamamlandi','gecikti','kapandi') DEFAULT 'acik',
    olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(denetim_id) REFERENCES kal_denetim(id) ON DELETE CASCADE,
    INDEX idx_denetim(denetim_id),
    INDEX idx_durum(durum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS kal_denetim_dokuman (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    denetim_id      INT UNSIGNED,
    bulgu_id        INT UNSIGNED,
    dosya_adi       VARCHAR(255),
    dosya_yolu      VARCHAR(500),
    dosya_turu      ENUM('denetim_raporu','kanit','dof','foto','diger') DEFAULT 'diger',
    aciklama        VARCHAR(255),
    yukleyen        VARCHAR(100),
    yuklenme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(denetim_id) REFERENCES kal_denetim(id) ON DELETE CASCADE,
    INDEX idx_denetim(denetim_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── Filtreler ─────────────────────────────────────────────
$f_durum = $_GET['durum'] ?? '';
$f_tur   = $_GET['tur']   ?? '';
$f_yil   = $_GET['yil']   ?? date('Y');

$where = "WHERE YEAR(d.denetim_tarihi) = ?";
$params = [$f_yil];
if ($f_durum) { $where .= " AND d.genel_durum=?"; $params[] = $f_durum; }
if ($f_tur)   { $where .= " AND d.denetim_turu=?"; $params[] = $f_tur; }

$denetimler = $db->prepare("
    SELECT d.*,
        COUNT(b.id)                                        AS bulgu_toplam,
        SUM(b.durum IN ('tamamlandi','kapandi'))           AS bulgu_kapanan,
        SUM(b.durum='acik')                                AS bulgu_acik,
        SUM(b.durum='gecikti')                             AS bulgu_gecikti,
        SUM(b.bulgu_turu='buyuk_uygunsuzluk')              AS buyuk_uygunsuzluk
    FROM kal_denetim d
    LEFT JOIN kal_denetim_bulgu b ON b.denetim_id=d.id
    $where
    GROUP BY d.id ORDER BY d.denetim_tarihi DESC
");
$denetimler->execute($params);
$denetimler = $denetimler->fetchAll(PDO::FETCH_ASSOC);

// ── Özet istatistikler ────────────────────────────────────
$ozet = $db->prepare("SELECT
    COUNT(DISTINCT d.id)                                                    AS toplam,
    SUM(d.genel_durum='devam_ediyor')                                       AS devam,
    SUM(d.genel_durum='tamamlandi')                                         AS tamamlandi,
    SUM(b.durum='acik' OR b.durum='devam_ediyor')                           AS acik_bulgu,
    SUM(b.durum='gecikti')                                                  AS gecikti
    FROM kal_denetim d
    LEFT JOIN kal_denetim_bulgu b ON b.denetim_id=d.id
    WHERE YEAR(d.denetim_tarihi)=?
")->execute([$f_yil]);
$ozet = $db->prepare("SELECT
    COUNT(DISTINCT d.id) as toplam,
    SUM(d.genel_durum='devam_ediyor') as devam,
    SUM(d.genel_durum='tamamlandi') as tamamlandi,
    SUM(b.durum IN ('acik','devam_ediyor')) as acik_bulgu,
    SUM(b.durum='gecikti') as gecikti
    FROM kal_denetim d
    LEFT JOIN kal_denetim_bulgu b ON b.denetim_id=d.id
    WHERE YEAR(d.denetim_tarihi)=?");
$ozet->execute([$f_yil]);
$oz = $ozet->fetch(PDO::FETCH_ASSOC) ?: [];

// Etiket sabitleri
$tur_etiket  = ['ic_denetim'=>'İç Denetim','tedarikci'=>'Tedarikçi','iso_9001'=>'ISO 9001','musteri'=>'Müşteri','proses'=>'Proses','diger'=>'Diğer'];
$durum_stil  = ['planlandi'=>['#6B7280','#F1F5F9','Planlandı'],'devam_ediyor'=>['#D97706','#FFFBEB','Devam Ediyor'],'tamamlandi'=>['#16A34A','#F0FDF4','Tamamlandı'],'iptal'=>['#94A3B8','#F8FAFC','İptal']];
$bulgu_stil  = ['buyuk_uygunsuzluk'=>['#DC2626','#FEF2F2','Büyük Uyg.'],'kucuk_uygunsuzluk'=>['#D97706','#FFFBEB','Küçük Uyg.'],'gozlem'=>['#2563EB','#EFF6FF','Gözlem'],'iyilestirme'=>['#7C3AED','#F5F3FF','İyileştirme']];
$bdur_stil   = ['acik'=>['#EF4444','#FEF2F2','Açık'],'devam_ediyor'=>['#F59E0B','#FFFBEB','Devam'],'tamamlandi'=>['#22C55E','#F0FDF4','Tamamlandı'],'gecikti'=>['#DC2626','#FFF','Gecikti'],'kapandi'=>['#6B7280','#F1F5F9','Kapandı']];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔍 Kalite Denetimleri</h1>
    <div class="s-yol">Kalite / <b>Denetimler</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <!-- Yıl filtresi -->
    <select class="form-alan" style="font-size:12px;padding:5px 10px;width:90px" onchange="filtreDegistir('yil',this.value)">
      <?php for($y=date('Y');$y>=2023;$y--): ?>
      <option value="<?=$y?>" <?=$f_yil==$y?'selected':''?>><?=$y?></option>
      <?php endfor; ?>
    </select>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-denetim-form" class="btn btn-t btn-sm">+ Yeni Denetim</a>
  </div>
</div>

<div class="s-body">

<!-- ── Özet Kartlar ──────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px" class="den-ozet">
  <?php foreach ([
    ['🔍','Toplam Denetim', $oz['toplam']??0,   '#1E3A5F','#EFF6FF'],
    ['⏳','Devam Eden',      $oz['devam']??0,    '#D97706','#FFFBEB'],
    ['✅','Tamamlanan',      $oz['tamamlandi']??0,'#16A34A','#F0FDF4'],
    ['⚠️','Açık Bulgu',      $oz['acik_bulgu']??0,'#EF4444','#FEF2F2'],
    ['🚨','Geciken',         $oz['gecikti']??0,  '#DC2626','#FFF5F5'],
  ] as $k): ?>
  <div class="kart" style="padding:14px;border-left:4px solid <?=$k[3]?>;background:<?=$k[4]?>">
    <div style="font-size:22px;margin-bottom:4px"><?=$k[0]?></div>
    <div style="font-size:26px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700;color:var(--t)"><?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- ── Filtreler ─────────────────────────────────────────── -->
<div class="kart" style="padding:12px 16px;margin-bottom:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
  <span style="font-size:12px;font-weight:700;color:var(--m2)">Filtrele:</span>
  <?php
  $durumlar = [''=> 'Tüm Durumlar','planlandi'=>'Planlandı','devam_ediyor'=>'Devam Eden','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'];
  $turler   = [''=> 'Tüm Türler','ic_denetim'=>'İç Denetim','tedarikci'=>'Tedarikçi','iso_9001'=>'ISO 9001','musteri'=>'Müşteri','proses'=>'Proses','diger'=>'Diğer'];
  ?>
  <select class="form-alan" style="font-size:12px;padding:5px 10px" onchange="filtreDegistir('durum',this.value)">
    <?php foreach ($durumlar as $v=>$l): ?><option value="<?=$v?>" <?=$f_durum===$v?'selected':''?>><?=$l?></option><?php endforeach; ?>
  </select>
  <select class="form-alan" style="font-size:12px;padding:5px 10px" onchange="filtreDegistir('tur',this.value)">
    <?php foreach ($turler as $v=>$l): ?><option value="<?=$v?>" <?=$f_tur===$v?'selected':''?>><?=$l?></option><?php endforeach; ?>
  </select>
  <?php if($f_durum||$f_tur): ?>
  <a href="?sayfa=kalite-denetim&yil=<?=$f_yil?>" class="btn btn-b btn-sm" style="font-size:11px">✕ Temizle</a>
  <?php endif; ?>
  <span style="margin-left:auto;font-size:12px;color:var(--m2)"><?=count($denetimler)?> denetim</span>
</div>

<!-- ── Denetim Listesi ───────────────────────────────────── -->
<?php if (empty($denetimler)): ?>
<div class="kart" style="padding:50px;text-align:center;color:var(--m3)">
  <div style="font-size:40px;margin-bottom:12px">🔍</div>
  <div style="font-size:15px;font-weight:700">Denetim kaydı bulunamadı</div>
  <div style="margin-top:12px"><a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-denetim-form" class="btn btn-t">+ İlk Denetimi Oluştur</a></div>
</div>
<?php else: ?>

<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach ($denetimler as $d):
  $ds = $durum_stil[$d['genel_durum']] ?? ['#6B7280','#F1F5F9','?'];
  $tl = $tur_etiket[$d['denetim_turu']] ?? 'Diğer';
  $toplam  = (int)$d['bulgu_toplam'];
  $kapanan = (int)$d['bulgu_kapanan'];
  $pct     = $toplam > 0 ? round($kapanan/$toplam*100) : 0;
  $gecikti = (int)$d['bulgu_gecikti'];
  $buyuk   = (int)$d['buyuk_uygunsuzluk'];
?>
<div class="kart" style="padding:0;overflow:hidden;border-left:4px solid <?=$ds[0]?>">
  <div style="padding:14px 18px;display:flex;align-items:center;gap:16px;flex-wrap:wrap">

    <!-- Sol: Kod + Tür -->
    <div style="min-width:130px">
      <div style="font-size:16px;font-weight:900;color:var(--t);font-family:monospace"><?= htmlspecialchars($d['denetim_kodu']) ?></div>
      <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:6px;background:<?=$ds[1]?>;color:<?=$ds[0]?>"><?=$ds[2]?></span>
    </div>

    <!-- Orta: Detaylar -->
    <div style="flex:1;min-width:200px">
      <div style="font-size:14px;font-weight:700;color:var(--t);margin-bottom:4px"><?= htmlspecialchars($d['denetim_konusu']??'—') ?></div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--m2)">
        <span>📅 <?= date('d.m.Y',strtotime($d['denetim_tarihi'])) ?></span>
        <span>🏢 <?= htmlspecialchars($d['denetlenen_bolum']??'—') ?></span>
        <span>👤 <?= htmlspecialchars($d['denetci_adi']??'—') ?></span>
        <span style="background:#EFF6FF;color:#2563EB;padding:1px 6px;border-radius:4px;font-weight:600"><?= $tl ?></span>
      </div>
    </div>

    <!-- Sağ: Bulgu özeti -->
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <?php if($toplam > 0): ?>
      <div style="text-align:center;min-width:70px">
        <div style="font-size:11px;color:var(--m2)">Tamamlanma</div>
        <div style="font-size:15px;font-weight:800;color:<?php echo ($pct>=100?'#16A34A':($pct>50?'#D97706':'#EF4444')); ?>"><?=$pct?>%</div>
        <div style="height:4px;background:var(--kenar);border-radius:2px;margin-top:3px;width:70px">
          <div style="height:100%;width:<?=$pct?>%;background:<?php echo ($pct>=100?'#22C55E':($pct>50?'#F59E0B':'#EF4444')); ?>;border-radius:2px"></div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:3px">
        <span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:8px;background:#F1F5F9;color:#374151"><?=$toplam?> bulgu</span>
        <?php if($d['bulgu_acik']>0): ?><span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:8px;background:#FEF2F2;color:#DC2626"><?=$d['bulgu_acik']?> açık</span><?php endif; ?>
        <?php if($gecikti>0): ?><span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:8px;background:#DC2626;color:#fff"><?=$gecikti?> gecikti</span><?php endif; ?>
        <?php if($buyuk>0): ?><span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:8px;background:#FEE2E2;color:#7F1D1D">⚡ <?=$buyuk?> büyük</span><?php endif; ?>
      </div>
      <?php else: ?>
      <span style="font-size:11px;color:var(--m3)">Bulgu girilmemiş</span>
      <?php endif; ?>

      <!-- İşlem Butonları -->
      <div style="display:flex;gap:6px;margin-left:8px">
        <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-denetim-detay&id=<?=$d['id']?>" class="btn btn-t btn-sm" style="font-size:11px;padding:5px 12px">
          📋 Detay
        </a>
        <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-denetim-form&id=<?=$d['id']?>" class="btn btn-b btn-sm" style="font-size:11px;padding:5px 10px">✏️</a>
      </div>
    </div>

  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

</div><!-- /s-body -->

<style>
@media(max-width:700px){ .den-ozet{grid-template-columns:repeat(3,1fr)!important} }
</style>
<script>
function filtreDegistir(alan, deger) {
    var url = new URL(window.location.href);
    url.searchParams.set('sayfa', 'kalite-denetim');
    url.searchParams.set(alan, deger);
    window.location.href = url.href;
}
</script>
