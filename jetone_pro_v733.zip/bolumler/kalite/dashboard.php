<?php
/**
 * JETONE.PRO — Kalite Dashboard
 * panel.php: 'kalite-dashboard' => 'bolumler/kalite/dashboard.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$bugun = date('Y-m-d');
$yil   = (int)date('Y');
$ay    = (int)date('m');
$hedef_ppm = 7500;

// 1. KALİBRASYON
try {
    $kalib = $db->query("SELECT COUNT(*) toplam,
        SUM(durum='OKEY') okey,
        SUM(durum IN('ARIZALI','KULLANIM DIŞI')) sorunlu,
        SUM(sonraki_kalibrasyon < '$bugun') suresi_gecmis,
        SUM(sonraki_kalibrasyon BETWEEN '$bugun' AND DATE_ADD('$bugun', INTERVAL 30 DAY)) yaklasan30
        FROM kalibrasyon_cihazlar WHERE aktif=1")->fetch(PDO::FETCH_ASSOC);
    $kalib_yaklasan = $db->query("SELECT kayit_no, cihaz_adi, sonraki_kalibrasyon,
        DATEDIFF(sonraki_kalibrasyon,'$bugun') kalan_gun
        FROM kalibrasyon_cihazlar WHERE aktif=1 AND durum='OKEY'
        AND sonraki_kalibrasyon BETWEEN '$bugun' AND DATE_ADD('$bugun', INTERVAL 30 DAY)
        ORDER BY sonraki_kalibrasyon LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $kalib=['toplam'=>0,'okey'=>0,'sorunlu'=>0,'suresi_gecmis'=>0,'yaklasan30'=>0]; $kalib_yaklasan=[]; }

// 2. UYGUNSUZLUK
try {
    $uyg = $db->query("SELECT COUNT(*) toplam,
        SUM(YEAR(tespit_tarihi)=$yil AND MONTH(tespit_tarihi)=$ay) bu_ay,
        SUM(karar IS NULL OR karar='') acik,
        SUM(YEAR(tespit_tarihi)=$yil) bu_yil
        FROM uygunsuzluk")->fetch(PDO::FETCH_ASSOC);
    $uyg_son = $db->query("SELECT takip_no, malzeme_adi, tespit_tarihi
        FROM uygunsuzluk ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $uyg=['toplam'=>0,'bu_ay'=>0,'acik'=>0,'bu_yil'=>0]; $uyg_son=[]; }

// 3. FINAL KONTROL
try {
    $final = $db->query("SELECT COUNT(*) toplam,
        SUM(kontrol_sonuc='OK') ok,
        SUM(kontrol_sonuc='NOK') nok,
        SUM(YEAR(kontrol_tarih_saat)=$yil AND MONTH(kontrol_tarih_saat)=$ay) bu_ay
        FROM final_kontrol_listesi")->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $final=['toplam'=>0,'ok'=>0,'nok'=>0,'bu_ay'=>0]; }

// 4. PROSES KONTROL
try {
    $proses = $db->query("SELECT COUNT(*) toplam,
        SUM(YEAR(kayit_tarihi)=$yil AND MONTH(kayit_tarihi)=$ay) bu_ay,
        ROUND(AVG(verimlilik),1) ort_verim,
        SUM(YEAR(kayit_tarihi)=$yil AND MONTH(kayit_tarihi)=$ay AND verimlilik>=85) hedef_ustu
        FROM proses_kontrol")->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $proses=['toplam'=>0,'bu_ay'=>0,'ort_verim'=>0,'hedef_ustu'=>0]; }

// 5. DIŞ İADE + PPM
try {
    $iade = $db->query("SELECT COUNT(DISTINCT irsaliye_no) toplam_irs, SUM(hata_miktar) toplam_hata
        FROM dis_iade_kontrol_listesi")->fetch(PDO::FETCH_ASSOC);
    $bu_ay_hata = (float)$db->query("SELECT COALESCE(SUM(hata_miktar),0) FROM dis_iade_kontrol_listesi
        WHERE YEAR(kayit_tarih)=$yil AND MONTH(kayit_tarih)=$ay")->fetchColumn();
} catch (Throwable $e) { $iade=['toplam_irs'=>0,'toplam_hata'=>0]; $bu_ay_hata=0; }

$satis_ay = 0;
if (!empty($tigerdb_pdo)) {
    try {
        $st = $tigerdb_pdo->prepare("SELECT SUM(tt) FROM (
            SELECT SUM(STL.AMOUNT) tt FROM LG_222_01_STLINE STL WITH(NOLOCK)
            LEFT JOIN LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
            WHERE STF.TRCODE=8 AND STL.YEAR_=? AND STL.MONTH_=?
            UNION ALL
            SELECT SUM(STL.AMOUNT) FROM LG_222_02_STLINE STL WITH(NOLOCK)
            LEFT JOIN LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
            WHERE STF.TRCODE=8 AND STL.YEAR_=? AND STL.MONTH_=?) q");
        $st->execute([$yil,$ay,$yil,$ay]);
        $satis_ay = (float)($st->fetchColumn()??0);
    } catch (Throwable $e) {}
}
$bu_ay_ppm = $satis_ay > 0 ? round($bu_ay_hata/$satis_ay*1000000) : null;
$ppm_renk  = $bu_ay_ppm===null?'#94A3B8':($bu_ay_ppm<=$hedef_ppm?'#22C55E':'#EF4444');
$ppm_bg    = $bu_ay_ppm===null?'#F1F5F9':($bu_ay_ppm<=$hedef_ppm?'#D1FAE5':'#FEE2E2');

// 6. DOKÜMAN
try {
    $dok = $db->query("SELECT COUNT(*) toplam, SUM(durum='Aktif') aktif, SUM(durum='Pasif') pasif,
        SUM(revize_tarih >= DATE_SUB('$bugun', INTERVAL 30 DAY)) son_revize
        FROM dokuman_listesi")->fetch(PDO::FETCH_ASSOC);
    $dok_tur = $db->query("SELECT tür, COUNT(*) adet FROM dokuman_listesi
        WHERE durum='Aktif' GROUP BY tür ORDER BY adet DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $dok=['toplam'=>0,'aktif'=>0,'pasif'=>0,'son_revize'=>0]; $dok_tur=[]; }

// 7. İADE TREND (son 6 ay)
$trend=[];
for ($i=5;$i>=0;$i--) {
    $dt=new DateTime("first day of -$i month");
    $ty=(int)$dt->format('Y'); $tm=(int)$dt->format('n');
    try { $h=(float)$db->query("SELECT COALESCE(SUM(hata_miktar),0) FROM dis_iade_kontrol_listesi WHERE YEAR(kayit_tarih)=$ty AND MONTH(kayit_tarih)=$tm")->fetchColumn();
    } catch (Throwable $e) { $h=0; }
    $trend[]=['et'=>$dt->format('M'),'h'=>$h,'y'=>$ty,'m'=>$tm];
}
$max_tr=max(1,max(array_column($trend,'h')));
$ay_adlari=['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 Kalite Dashboard</h1>
    <div class="s-yol">Kalite / <b>Dashboard</b> <span style="font-size:11px;color:var(--m2);margin-left:6px"><?= date('d.m.Y H:i') ?></span></div>
  </div>
</div>
<div class="s-body">

<!-- ÜST KARTLAR -->
<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:18px">
<?php
$ppm_d = $bu_ay_ppm===null?'— PPM':number_format($bu_ay_ppm).' PPM';
$ppm_s = $bu_ay_ppm===null?'—':($bu_ay_ppm<=$hedef_ppm?'✅ HEDEF ALTI':'🔴 HEDEF ÜSTÜ');
$üst = [
  ['kalite-kalibrasyon-liste','⚙️','Kalibrasyon',$kalib['toplam'].' Cihaz',
   $kalib['suresi_gecmis']>0?'⚠️ '.$kalib['suresi_gecmis'].' GEÇMİŞ':'✅ '.$kalib['okey'].' UYGUN',
   $kalib['suresi_gecmis']>0?'#EF4444':'#22C55E',$kalib['suresi_gecmis']>0?'#FEE2E2':'#D1FAE5'],
  ['kalite-uygunsuzluk-liste','⚠️','Uygunsuzluk',$uyg['bu_yil'].' Bu Yıl',
   $uyg['acik']>0?'🔴 '.$uyg['acik'].' AÇIK':'✅ KAPALI',
   $uyg['acik']>0?'#F59E0B':'#22C55E',$uyg['acik']>0?'#FEF9C3':'#D1FAE5'],
  ['kalite-final-liste','✅','Final Kontrol',($final['toplam']??0).' Toplam',
   ($final['nok']??0)>0?'🔴 '.($final['nok']??0).' NOK':'✅ '.($final['ok']??0).' OK',
   ($final['nok']??0)>0?'#EF4444':'#22C55E',($final['nok']??0)>0?'#FEE2E2':'#D1FAE5'],
  ['kalite-kontrol','🔧','Proses Kontrol',($proses['bu_ay']??0).' Bu Ay',
   '%'.($proses['ort_verim']??0).' ORT. VERİM','#1E3A5F','#E0F2FE'],
  ['kalite-dis-iade-ozet','📦','Dış İade PPM',$ppm_d,$ppm_s,$ppm_renk,$ppm_bg],
  ['kalite-dokuman-listesi','📄','KYS Doküman',($dok['aktif']??0).' Aktif',
   ($dok['son_revize']??0).' SON REVİZE','#6366F1','#EDE9FE'],
];
foreach ($üst as [$lnk,$ik,$bas,$deg,$dur,$fg,$bg]):
?>
<a href="<?= BASE_URL ?>/panel.php?sayfa=<?= $lnk ?>"
   style="background:<?= $bg ?>;border-radius:var(--r);padding:14px 12px;text-decoration:none;display:block;border:2px solid <?= $fg ?>22"
   onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 18px <?= $fg ?>33'"
   onmouseout="this.style.transform='';this.style.boxShadow=''">
  <div style="font-size:20px;margin-bottom:4px"><?= $ik ?></div>
  <div style="font-size:10px;font-weight:700;color:<?= $fg ?>;text-transform:uppercase;opacity:.75"><?= $bas ?></div>
  <div style="font-size:15px;font-weight:900;color:<?= $fg ?>;margin:3px 0"><?= $deg ?></div>
  <div style="font-size:10px;background:<?= $fg ?>;color:#fff;padding:1px 7px;border-radius:10px;display:inline-block;font-weight:700"><?= $dur ?></div>
</a>
<?php endforeach; ?>
</div>

<!-- ORTA 3 KOLON -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:14px">

<!-- KALİBRASYON -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">⚙️ Kalibrasyon Durumu</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div style="padding:12px">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:12px">
      <?php foreach ([['Toplam',$kalib['toplam'],'#1E3A5F','#E0F2FE'],['Uygun',$kalib['okey'],'#22C55E','#D1FAE5'],['Sorunlu',$kalib['sorunlu'],'#EF4444','#FEE2E2'],['Süresi Geçmiş',$kalib['suresi_gecmis'],'#F59E0B','#FEF9C3']] as [$l,$v,$f,$b]): ?>
      <div style="background:<?= $b ?>;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:20px;font-weight:900;color:<?= $f ?>"><?= (int)$v ?></div>
        <div style="font-size:9px;color:<?= $f ?>;font-weight:700;text-transform:uppercase"><?= $l ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php if ($kalib_yaklasan): ?>
    <div style="font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:6px">📅 30 Günde Bitenler</div>
    <?php foreach ($kalib_yaklasan as $k): ?>
    <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:11px">
      <span style="font-family:monospace;color:var(--t);font-weight:700"><?= htmlspecialchars($k['kayit_no']) ?></span>
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--m2);padding:0 6px"><?= htmlspecialchars($k['cihaz_adi']) ?></span>
      <span style="background:<?= $k['kalan_gun']<=7?'#FEE2E2':'#FEF9C3' ?>;color:<?= $k['kalan_gun']<=7?'#EF4444':'#F59E0B' ?>;padding:2px 6px;border-radius:8px;font-weight:800"><?= $k['kalan_gun'] ?>g</span>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div style="text-align:center;color:var(--m2);font-size:12px;padding:10px 0">✅ 30 günde biten kalibrasyon yok</div>
    <?php endif; ?>
  </div>
</div>

<!-- UYGUNSUZLUK -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">⚠️ Uygunsuzluklar</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div style="padding:12px">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:12px">
      <?php foreach ([['Bu Ay',$uyg['bu_ay'],'#1E3A5F','#E0F2FE'],['Bu Yıl',$uyg['bu_yil'],'#6366F1','#EDE9FE'],['Açık',$uyg['acik'],$uyg['acik']>0?'#EF4444':'#22C55E',$uyg['acik']>0?'#FEE2E2':'#D1FAE5'],['Toplam',$uyg['toplam'],'#94A3B8','#F1F5F9']] as [$l,$v,$f,$b]): ?>
      <div style="background:<?= $b ?>;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:20px;font-weight:900;color:<?= $f ?>"><?= (int)$v ?></div>
        <div style="font-size:9px;color:<?= $f ?>;font-weight:700;text-transform:uppercase"><?= $l ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:6px">Son Kayıtlar</div>
    <?php foreach ($uyg_son as $u): ?>
    <div style="padding:5px 0;border-bottom:1px solid var(--kenar);font-size:11px">
      <div style="display:flex;justify-content:space-between;margin-bottom:1px">
        <span style="font-family:monospace;color:var(--t);font-weight:700"><?= htmlspecialchars($u['takip_no']) ?></span>
        <span style="color:var(--m2)"><?= $u['tespit_tarihi']?date('d.m.Y',strtotime($u['tespit_tarihi'])):'—' ?></span>
      </div>
      <div style="color:var(--m2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($u['malzeme_adi']??'—') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- DIŞ İADE PPM -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">📦 Dış İade PPM</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-ozet" style="font-size:11px;color:var(--t)">Özet →</a>
  </div>
  <div style="padding:12px">
    <div style="text-align:center;padding:14px;background:<?= $ppm_bg ?>;border-radius:10px;margin-bottom:12px">
      <div style="font-size:11px;color:<?= $ppm_renk ?>;font-weight:700"><?= $ay_adlari[$ay] ?> <?= $yil ?></div>
      <div style="font-size:34px;font-weight:900;color:<?= $ppm_renk ?>;line-height:1.1"><?= $bu_ay_ppm===null?'—':number_format($bu_ay_ppm) ?></div>
      <div style="font-size:11px;color:<?= $ppm_renk ?>;margin-top:2px">PPM | Hedef <?= number_format($hedef_ppm) ?></div>
      <?php if ($bu_ay_ppm!==null): ?>
      <div style="margin-top:6px;height:6px;background:rgba(0,0,0,.1);border-radius:3px;overflow:hidden">
        <div style="height:100%;width:<?= min(100,round($bu_ay_ppm/$hedef_ppm*100)) ?>%;background:<?= $ppm_renk ?>;border-radius:3px"></div>
      </div>
      <div style="font-size:10px;color:<?= $ppm_renk ?>;margin-top:3px;font-weight:700">%<?= round($bu_ay_ppm/$hedef_ppm*100,1) ?> / Hedef</div>
      <?php endif; ?>
    </div>
    <div style="font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:6px">Son 6 Ay Trendi</div>
    <div style="display:flex;gap:4px;align-items:flex-end;height:48px">
      <?php foreach ($trend as $t): $bh=$t['h']>0?max(4,round($t['h']/$max_tr*42)):3; $cur=($t['y']===$yil&&$t['m']===$ay); ?>
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:1px">
        <div style="height:<?= $bh ?>px;width:100%;background:<?= $cur?'#1E3A5F':'#94A3B8' ?>;border-radius:2px 2px 0 0;opacity:<?= $t['h']>0?'1':'0.25' ?>"></div>
        <div style="font-size:8px;color:<?= $cur?'var(--t)':'var(--m2)' ?>;font-weight:<?= $cur?'800':'400' ?>"><?= $t['et'] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px">
      <div style="background:#FEE2E2;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:17px;font-weight:900;color:#EF4444"><?= number_format((float)($iade['toplam_hata']??0)) ?></div>
        <div style="font-size:9px;color:#EF4444;font-weight:700">TOPLAM İADE</div>
      </div>
      <div style="background:#E0F2FE;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:17px;font-weight:900;color:#1E3A5F"><?= (int)($iade['toplam_irs']??0) ?></div>
        <div style="font-size:9px;color:#1E3A5F;font-weight:700">İRSALİYE</div>
      </div>
    </div>
  </div>
</div>
</div>

<!-- ALT 3 KOLON -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px">

<!-- FINAL KONTROL -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">✅ Final Kontrol</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-final-liste" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div style="padding:12px">
    <?php $ok_pct=($final['toplam']??0)>0?round(($final['ok']??0)/($final['toplam']??1)*100,1):0;
          $ok_r=$ok_pct>=95?'#22C55E':($ok_pct>=85?'#F59E0B':'#EF4444'); ?>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-bottom:12px">
      <?php foreach ([['Toplam',$final['toplam']??0,'#1E3A5F','#E0F2FE'],['OK',$final['ok']??0,'#22C55E','#D1FAE5'],['NOK',$final['nok']??0,($final['nok']??0)>0?'#EF4444':'#94A3B8',($final['nok']??0)>0?'#FEE2E2':'#F1F5F9']] as [$l,$v,$f,$b]): ?>
      <div style="background:<?= $b ?>;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:18px;font-weight:900;color:<?= $f ?>"><?= number_format((int)$v) ?></div>
        <div style="font-size:9px;color:<?= $f ?>;font-weight:700"><?= $l ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:4px">
      <span>OK Oranı</span><span style="color:<?= $ok_r ?>"><?= $ok_pct ?>%</span>
    </div>
    <div style="height:10px;background:var(--kenar);border-radius:5px;overflow:hidden;margin-bottom:10px">
      <div style="height:100%;width:<?= $ok_pct ?>%;background:<?= $ok_r ?>;border-radius:5px"></div>
    </div>
    <div style="font-size:11px;color:var(--m2)">Bu ay: <b style="color:var(--t)"><?= $final['bu_ay']??0 ?></b> kontrol</div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-final-kontrol" class="btn btn-t btn-sm" style="width:100%;text-align:center;margin-top:10px;display:block">+ Yeni Kontrol</a>
  </div>
</div>

<!-- PROSES KONTROL -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">🔧 Proses Kontrol</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kontrol" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div style="padding:12px">
    <?php $verim=(float)($proses['ort_verim']??0); $vr=$verim>=85?'#22C55E':($verim>=70?'#F59E0B':'#EF4444'); $vb=$verim>=85?'#D1FAE5':($verim>=70?'#FEF9C3':'#FEE2E2'); ?>
    <div style="text-align:center;padding:14px;background:<?= $vb ?>;border-radius:10px;margin-bottom:12px">
      <div style="font-size:11px;color:<?= $vr ?>;font-weight:700">Ortalama Verimlilik</div>
      <div style="font-size:34px;font-weight:900;color:<?= $vr ?>;line-height:1.1">%<?= $verim ?></div>
      <div style="height:6px;background:rgba(0,0,0,.1);border-radius:3px;margin-top:8px;overflow:hidden">
        <div style="height:100%;width:<?= min(100,$verim) ?>%;background:<?= $vr ?>;border-radius:3px"></div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:10px">
      <?php foreach ([['Toplam',$proses['toplam']??0,'#1E3A5F','#E0F2FE'],['Bu Ay',$proses['bu_ay']??0,'#6366F1','#EDE9FE']] as [$l,$v,$f,$b]): ?>
      <div style="background:<?= $b ?>;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:20px;font-weight:900;color:<?= $f ?>"><?= (int)$v ?></div>
        <div style="font-size:9px;color:<?= $f ?>;font-weight:700;text-transform:uppercase"><?= $l ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="font-size:11px;color:var(--m2)">Bu ay ≥%85: <b style="color:#22C55E"><?= $proses['hedef_ustu']??0 ?></b> kayıt</div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-proses-ekle" class="btn btn-t btn-sm" style="width:100%;text-align:center;margin-top:10px;display:block">+ Yeni Proses Kaydı</a>
  </div>
</div>

<!-- DOKÜMAN -->
<div class="kart" style="padding:0">
  <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <b style="font-size:13px">📄 KYS Dokümanlar</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-listesi" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div style="padding:12px">
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-bottom:12px">
      <?php foreach ([['Toplam',$dok['toplam']??0,'#1E3A5F','#E0F2FE'],['Aktif',$dok['aktif']??0,'#22C55E','#D1FAE5'],['Pasif',$dok['pasif']??0,'#94A3B8','#F1F5F9']] as [$l,$v,$f,$b]): ?>
      <div style="background:<?= $b ?>;border-radius:8px;padding:8px;text-align:center">
        <div style="font-size:20px;font-weight:900;color:<?= $f ?>"><?= (int)$v ?></div>
        <div style="font-size:9px;color:<?= $f ?>;font-weight:700"><?= $l ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:7px">Kategori Dağılımı</div>
    <?php $ta=['formlar'=>'Formlar','listeler'=>'Listeler','talimatlar'=>'Talimatlar','prosedürler'=>'Prosedürler','planlar'=>'Planlar','raporlar'=>'Raporlar','kalibrasyon'=>'Kalibrasyon','semalar'=>'Şemalar'];
    $dm=$dok_tur?max(array_column($dok_tur,'adet')):1;
    foreach ($dok_tur as $dt): $pct=round($dt['adet']/$dm*100); $lbl=$ta[$dt['tür']]??ucfirst($dt['tür']); ?>
    <div style="margin-bottom:5px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px"><span><?= htmlspecialchars($lbl) ?></span><b><?= $dt['adet'] ?></b></div>
      <div style="height:5px;background:var(--kenar);border-radius:3px"><div style="height:100%;width:<?= $pct ?>%;background:#6366F1;border-radius:3px"></div></div>
    </div>
    <?php endforeach; ?>
    <div style="margin-top:10px;font-size:11px;color:var(--m2)">Son 30g revize: <b style="color:#6366F1"><?= $dok['son_revize']??0 ?></b></div>
  </div>
</div>

</div>
</div>
