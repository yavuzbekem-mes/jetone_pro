<?php
/**
 * Dış İade Detay — tek irsaliye tüm kayıtları
 * panel.php: 'kalite-dis-iade-detay'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$irs = trim($_GET['irsaliye'] ?? '');
if (!$irs) { echo '<p>İrsaliye no gerekli</p>'; exit; }

try {
    $st = $db->prepare("SELECT * FROM dis_iade_kontrol_listesi WHERE irsaliye_no=? ORDER BY kayit_tarih DESC, id DESC");
    $st->execute([$irs]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $rows = []; }

// Tiger özet
$tiger_rows = [];
if (!empty($tigerdb_pdo)) {
    try {
        $tst = $tigerdb_pdo->prepare("
            SELECT CONVERT(VARCHAR,STF.DATE_,104) AS tarih, CL.DEFINITION_ AS musteri,
                   IT.CODE AS kod, IT.NAME AS adi, SUM(STL.AMOUNT) AS miktar
            FROM LG_222_02_STLINE STL
            LEFT JOIN LG_222_ITEMS IT  ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
            LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
            LEFT JOIN LG_222_CLCARD CL ON CL.LOGICALREF=STF.CLIENTREF
            WHERE STF.TRCODE=3 AND STF.FICHENO=?
            GROUP BY STF.DATE_,CL.DEFINITION_,IT.CODE,IT.NAME
            UNION ALL
            SELECT CONVERT(VARCHAR,STF.DATE_,104), CL.DEFINITION_, IT.CODE, IT.NAME, SUM(STL.AMOUNT)
            FROM LG_222_01_STLINE STL
            LEFT JOIN LG_222_ITEMS IT  ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
            LEFT JOIN LG_222_01_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
            LEFT JOIN LG_222_CLCARD CL ON CL.LOGICALREF=STF.CLIENTREF
            WHERE STF.TRCODE=3 AND STF.FICHENO=?
            GROUP BY STF.DATE_,CL.DEFINITION_,IT.CODE,IT.NAME");
        $tst->execute([$irs, $irs]);
        $tiger_rows = $tst->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
}

// Grupla: malzeme → toplam hata
$malzeme_hata = [];
foreach ($rows as $r) {
    $k = $r['malzeme_kodu'];
    $malzeme_hata[$k] = ($malzeme_hata[$k] ?? 0) + (float)$r['hata_miktar'];
}
// Tiger miktarı
$tiger_mkt_map = [];
foreach ($tiger_rows as $t) { $tiger_mkt_map[$t['kod']] = (float)$t['miktar']; }

$musteri = $tiger_rows[0]['musteri'] ?? '';
$tarih   = $tiger_rows[0]['tarih']   ?? '';
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔍 İrsaliye Detayı: <?= htmlspecialchars($irs) ?></h1>
    <div class="s-yol">Kalite /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-liste" style="color:var(--t)">Dış İade</a> /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-kontrol" style="color:var(--t)">Kontrol Sonuçları</a> /
      <b><?= htmlspecialchars($irs) ?></b>
    </div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-kontrol" class="btn btn-b btn-sm">← Listeye Dön</a>
</div>

<div class="s-body">

<!-- Üst bilgi -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
  <?php
  $toplam_irs_mkt = array_sum($tiger_mkt_map);
  $toplam_hata    = array_sum($malzeme_hata);
  $genel_oran     = $toplam_irs_mkt > 0 ? round($toplam_hata/$toplam_irs_mkt*100,1) : 0;
  $kutular = [
    ['İrsaliye No', htmlspecialchars($irs), '#1E3A5F','#E0F2FE'],
    ['Müşteri', htmlspecialchars($musteri), '#6366F1','#EDE9FE'],
    ['Tarih', $tarih ? date('d.m.Y',strtotime(str_replace('.','-',$tarih))) : '—', '#0EA5E9','#E0F7FA'],
    ['Toplam Miktar', number_format($toplam_irs_mkt,0), '#22C55E','#D1FAE5'],
    ['Toplam Hata', number_format($toplam_hata,0), '#EF4444','#FEE2E2'],
    ['Kontrol Oranı', $genel_oran.'%', $genel_oran>=100?'#22C55E':($genel_oran>0?'#F59E0B':'#EF4444'), $genel_oran>=100?'#D1FAE5':($genel_oran>0?'#FEF9C3':'#FEE2E2')],
  ];
  foreach ($kutular as [$lbl,$val,$fg,$bg]):
  ?>
  <div style="background:<?= $bg ?>;border-radius:var(--r);padding:12px 14px">
    <div style="font-size:10px;font-weight:700;color:<?= $fg ?>;text-transform:uppercase;opacity:.8"><?= $lbl ?></div>
    <div style="font-size:16px;font-weight:900;color:<?= $fg ?>;margin-top:2px"><?= $val ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Malzeme özet tablosu -->
<?php if ($tiger_rows): ?>
<div class="kart" style="margin-bottom:16px">
  <div style="font-size:13px;font-weight:800;margin-bottom:10px">📦 Malzeme Özeti</div>
  <table class="tablo" style="width:100%">
    <thead><tr style="background:#1E3A5F!important">
      <?php foreach(['Malzeme Kodu','Malzeme Adı','İrs. Miktarı','Toplam Hata','Kontrol Oranı'] as $h): ?>
      <th style="background:#1E3A5F!important;color:#fff!important;padding:7px 10px;font-size:12px;font-weight:700"><?= $h ?></th>
      <?php endforeach; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($tiger_rows as $t):
        $hata = $malzeme_hata[$t['kod']] ?? 0;
        $oran = (float)$t['miktar'] > 0 ? round($hata/(float)$t['miktar']*100,1) : 0;
    ?>
    <tr>
      <td style="font-family:monospace"><?= htmlspecialchars($t['kod']??'') ?></td>
      <td><?= htmlspecialchars($t['adi']??'') ?></td>
      <td style="text-align:right"><?= number_format((float)$t['miktar'],0) ?></td>
      <td style="text-align:right;color:<?= $hata>0?'#EF4444':'var(--m2)' ?>;font-weight:700"><?= number_format($hata,0) ?></td>
      <td style="text-align:center;font-weight:800;color:<?= $oran>=100?'#22C55E':($oran>0?'#F59E0B':'var(--m2)') ?>"><?= $oran ?>%</td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- Hata kayıtları detay -->
<div class="kart" style="padding:0">
  <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);font-weight:700;font-size:13px">
    📋 Hata Kayıtları <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($rows) ?></span>
  </div>
  <div style="overflow-x:auto">
    <table class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach(['#','Malzeme Kodu','Malzeme Adı','Miktar','Hata Tipi','Hata Miktarı','Alınan Aksiyon','Kaydeden','Tarih','Sil'] as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:7px 10px;font-size:12px;font-weight:700;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $i => $r): ?>
      <tr>
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['malzeme_kodu']??'') ?></td>
        <td style="font-size:12px;max-width:200px"><?= htmlspecialchars($r['malzeme_adi']??'') ?></td>
        <td style="text-align:right"><?= htmlspecialchars($r['miktar']??'') ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['hata_tipi']??'') ?></td>
        <td style="text-align:right;font-weight:700;color:#EF4444"><?= htmlspecialchars($r['hata_miktar']??'') ?></td>
        <td style="font-size:11px;max-width:160px"><?= htmlspecialchars($r['alinan_aksiyon']??'') ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['kul_adi']??'') ?></td>
        <td style="white-space:nowrap;font-size:11px"><?= $r['kayit_tarih'] ? date('d.m.Y',strtotime($r['kayit_tarih'])) : '—' ?></td>
        <td>
          <button class="btn btn-sm sil-btn" data-id="<?= $r['id'] ?>"
                  style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
document.addEventListener('click', async function(e){
  var btn = e.target.closest('.sil-btn');
  if (!btn) return;
  if (!confirm('Bu kaydı silmek istiyor musunuz?')) return;
  try {
    var r = await fetch('<?= BASE_URL ?>/islemler/kalite/dis_iade_sil.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id: parseInt(btn.dataset.id)})
    });
    var j = await r.json(); if (j.status==='success') location.reload(); else alert(j.message);
  } catch(e){ alert(e.message); }
});
</script>
