<?php
/**
 * JETONE.PRO — DÖF (Düzeltici ve Önleyici Faaliyet) Listesi
 * panel.php: 'kalite-dof' => 'bolumler/kalite/dof.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// ── Tablo oluştur ─────────────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS kal_dof (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dof_no              VARCHAR(30) UNIQUE NOT NULL,
    kaynak              ENUM('musteri_sikayet','ic_denetim','urun_hatasi','proses_hatasi','tedarikci','calisma_kazasi','diger') DEFAULT 'diger',
    kaynak_ref          VARCHAR(100)  COMMENT 'Denetim/Şikayet/Proje No',
    problem_tanimi      TEXT NOT NULL,
    bes_n_kim           TEXT  COMMENT 'Kim - kişi/bölüm',
    bes_n_ne            TEXT  COMMENT 'Ne - sorun ne',
    bes_n_nerede        TEXT  COMMENT 'Nerede - yer/süreç',
    bes_n_nezaman       TEXT  COMMENT 'Ne zaman - tarih/sıklık',
    bes_n_nasil         TEXT  COMMENT 'Nasıl - nasıl fark edildi',
    etkilenen_miktar    VARCHAR(100),
    gecici_onlem        TEXT  COMMENT 'Karantina, acil müdahale',
    kok_neden_5n        TEXT  COMMENT '5 Neden analizi özeti',
    kok_neden_kacan     TEXT  COMMENT 'Kaçış noktası - neden fark edilmedi',
    balik_insan         TEXT,
    balik_yontem        TEXT,
    balik_makine        TEXT,
    balik_malzeme       TEXT,
    balik_olcum         TEXT,
    balik_cevre         TEXT,
    duzeltici_faaliyet  TEXT,
    onleyici_faaliyet   TEXT,
    sorumlu             VARCHAR(100),
    hedef_tarih         DATE,
    tamamlanma_tarihi   DATE,
    dogrulama_yontemi   TEXT,
    dogrulayan          VARCHAR(100),
    dogrulama_tarihi    DATE,
    etkinlik_kontrolu   TEXT  COMMENT 'Aksiyon işe yaradı mı?',
    durum               ENUM('acildi','analiz','aksiyon','dogrulama','kapandi','iptal') DEFAULT 'acildi',
    kritiklik           ENUM('dusuk','orta','yuksek','kritik') DEFAULT 'orta',
    ilgili_8d_id        INT UNSIGNED DEFAULT NULL,
    olusturan           VARCHAR(100),
    acilis_tarihi       DATE NOT NULL,
    kayit_tarihi        DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme_tarihi   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_durum(durum), INDEX idx_tarih(acilis_tarihi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS kal_dof_dokuman (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dof_id          INT UNSIGNED NOT NULL,
    dosya_adi       VARCHAR(255),
    dosya_yolu      VARCHAR(500),
    tur             ENUM('kanit','foto','rapor','aksiyon','diger') DEFAULT 'diger',
    aciklama        VARCHAR(255),
    yukleyen        VARCHAR(100),
    yuklenme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(dof_id) REFERENCES kal_dof(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── Filtreler ─────────────────────────────────────────────
$f_durum    = $_GET['durum']    ?? '';
$f_kritik   = $_GET['kritik']   ?? '';
$f_yil      = $_GET['yil']      ?? date('Y');
$where = "WHERE YEAR(d.acilis_tarihi)=?"; $params = [$f_yil];
if ($f_durum)  { $where .= " AND d.durum=?";     $params[] = $f_durum; }
if ($f_kritik) { $where .= " AND d.kritiklik=?"; $params[] = $f_kritik; }

$stmt = $db->prepare("SELECT d.*, COUNT(dk.id) AS dok_sayisi
    FROM kal_dof d LEFT JOIN kal_dof_dokuman dk ON dk.dof_id=d.id
    $where GROUP BY d.id ORDER BY
    FIELD(d.durum,'acildi','analiz','aksiyon','dogrulama','kapandi','iptal'),
    FIELD(d.kritiklik,'kritik','yuksek','orta','dusuk'),
    d.acilis_tarihi DESC");
$stmt->execute($params); $dofler = $stmt->fetchAll(PDO::FETCH_ASSOC);

$oz = $db->prepare("SELECT COUNT(*) toplam,
    SUM(durum='acildi') acildi, SUM(durum='analiz') analiz,
    SUM(durum='aksiyon') aksiyon, SUM(durum='dogrulama') dogrulama,
    SUM(durum='kapandi') kapandi,
    SUM(durum NOT IN ('kapandi','iptal') AND hedef_tarih < CURDATE()) gecikti
    FROM kal_dof WHERE YEAR(acilis_tarihi)=?");
$oz->execute([$f_yil]); $oz = $oz->fetch(PDO::FETCH_ASSOC);

$durum_stil = [
    'acildi'     => ['#DC2626','#FEF2F2','🔴 Açıldı'],
    'analiz'     => ['#D97706','#FFFBEB','🔎 Analiz'],
    'aksiyon'    => ['#0EA5E9','#F0F9FF','⚙️ Aksiyon'],
    'dogrulama'  => ['#7C3AED','#F5F3FF','✅ Doğrulama'],
    'kapandi'    => ['#16A34A','#F0FDF4','🏁 Kapandı'],
    'iptal'      => ['#94A3B8','#F8FAFC','❌ İptal'],
];
$kritik_stil = [
    'dusuk'  => ['#94A3B8','Düşük'],
    'orta'   => ['#D97706','Orta'],
    'yuksek' => ['#EF4444','Yüksek'],
    'kritik' => ['#7F1D1D','KRİTİK'],
];
$kaynak_etiket = ['musteri_sikayet'=>'👤 Müşteri Şikayeti','ic_denetim'=>'🔍 İç Denetim','urun_hatasi'=>'🔧 Ürün Hatası','proses_hatasi'=>'⚙️ Proses Hatası','tedarikci'=>'🚛 Tedarikçi','calisma_kazasi'=>'⚠️ Çalışma Kazası','diger'=>'📌 Diğer'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 DÖF Takip Listesi</h1>
    <div class="s-yol">Kalite / <b>Düzeltici ve Önleyici Faaliyetler</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <select class="form-alan" style="font-size:12px;padding:4px 8px;width:80px" onchange="filtre('yil',this.value)">
      <?php for($y=date('Y');$y>=2023;$y--): ?><option value="<?=$y?>" <?=$f_yil==$y?'selected':''?>><?=$y?></option><?php endfor; ?>
    </select>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-form" class="btn btn-t btn-sm">+ Yeni DÖF Aç</a>
  </div>
</div>
<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px;margin-bottom:16px" class="dof-ozet">
<?php foreach ([
  ['📋','Toplam', $oz['toplam']??0,  '#1E3A5F','#EFF6FF'],
  ['🔴','Açıldı', $oz['acildi']??0,  '#DC2626','#FEF2F2'],
  ['🔎','Analiz',  $oz['analiz']??0,  '#D97706','#FFFBEB'],
  ['⚙️','Aksiyon', $oz['aksiyon']??0, '#0EA5E9','#F0F9FF'],
  ['✅','Doğrulama',$oz['dogrulama']??0,'#7C3AED','#F5F3FF'],
  ['🏁','Kapandı', $oz['kapandi']??0, '#16A34A','#F0FDF4'],
  ['⚠️','Gecikti', $oz['gecikti']??0, '#7F1D1D','#FFF5F5'],
] as $k): ?>
<div class="kart" style="padding:12px;border-left:3px solid <?=$k[3]?>;background:<?=$k[4]?>;text-align:center">
  <div style="font-size:18px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
  <div style="font-size:10px;font-weight:700"><?=$k[1]?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:10px 16px;margin-bottom:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  <span style="font-size:12px;font-weight:700;color:var(--m2)">Filtrele:</span>
  <select class="form-alan" style="font-size:12px;padding:4px 8px" onchange="filtre('durum',this.value)">
    <option value="">Tüm Durumlar</option>
    <?php foreach ($durum_stil as $v=>$s): ?><option value="<?=$v?>" <?=$f_durum===$v?'selected':''?>><?=$s[2]?></option><?php endforeach; ?>
  </select>
  <select class="form-alan" style="font-size:12px;padding:4px 8px" onchange="filtre('kritik',this.value)">
    <option value="">Tüm Öncelikler</option>
    <?php foreach ($kritik_stil as $v=>$s): ?><option value="<?=$v?>" <?=$f_kritik===$v?'selected':''?>><?=$s[1]?></option><?php endforeach; ?>
  </select>
  <span style="margin-left:auto;font-size:12px;color:var(--m2)"><?=count($dofler)?> kayıt</span>
</div>

<!-- Liste -->
<?php if(empty($dofler)): ?>
<div class="kart" style="padding:50px;text-align:center;color:var(--m3)">
  <div style="font-size:40px;margin-bottom:12px">🔧</div>
  <div style="font-size:14px;font-weight:700;margin-bottom:10px">DÖF kaydı yok</div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-form" class="btn btn-t">+ İlk DÖF'ü Aç</a>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach ($dofler as $d):
  $ds = $durum_stil[$d['durum']] ?? ['#6B7280','#F1F5F9','?'];
  $ks = $kritik_stil[$d['kritiklik']] ?? ['#6B7280','?'];
  $gecikti = !in_array($d['durum'],['kapandi','iptal']) && $d['hedef_tarih'] && $d['hedef_tarih'] < date('Y-m-d');
?>
<div class="kart" style="padding:0;overflow:hidden;border-left:4px solid <?=$ds[0]?>">
  <div style="padding:12px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
    <!-- No + Durum -->
    <div style="min-width:130px">
      <div style="font-weight:900;font-size:14px;font-family:monospace;color:var(--t)"><?=htmlspecialchars($d['dof_no'])?></div>
      <div style="display:flex;gap:5px;margin-top:3px;flex-wrap:wrap">
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:<?=$ds[1]?>;color:<?=$ds[0]?>"><?=$ds[2]?></span>
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;color:<?=$ks[0]?>;background:<?=$ks[0]?>18;border:1px solid <?=$ks[0]?>"><?=$ks[1]?></span>
        <?php if($gecikti): ?><span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:#DC2626;color:#fff">⏰ GECİKTİ</span><?php endif; ?>
      </div>
    </div>
    <!-- Detay -->
    <div style="flex:1;min-width:200px">
      <div style="font-size:14px;font-weight:700;color:var(--t);margin-bottom:3px"><?=htmlspecialchars(mb_strimwidth($d['problem_tanimi'],0,80,'…'))?></div>
      <div style="display:flex;gap:12px;font-size:11px;color:var(--m2);flex-wrap:wrap">
        <span><?=$kaynak_etiket[$d['kaynak']]??'📌'?></span>
        <?php if($d['kaynak_ref']): ?><span>Ref: <?=htmlspecialchars($d['kaynak_ref'])?></span><?php endif; ?>
        <span>📅 <?=date('d.m.Y',strtotime($d['acilis_tarihi']))?></span>
        <?php if($d['sorumlu']): ?><span>👤 <?=htmlspecialchars($d['sorumlu'])?></span><?php endif; ?>
        <?php if($d['hedef_tarih']): ?><span style="color:<?=$gecikti?'#DC2626':'var(--m2)'?>">🏁 <?=date('d.m.Y',strtotime($d['hedef_tarih']))?></span><?php endif; ?>
        <?php if($d['dok_sayisi']>0): ?><span>📎 <?=$d['dok_sayisi']?></span><?php endif; ?>
        <?php if($d['ilgili_8d_id']): ?><span style="color:#6366F1;font-weight:700">🔗 8D bağlı</span><?php endif; ?>
      </div>
    </div>
    <!-- Butonlar -->
    <div style="display:flex;gap:6px">
      <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-detay&id=<?=$d['id']?>" class="btn btn-t btn-sm" style="font-size:11px;padding:5px 12px">📋 Detay</a>
      <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-form&id=<?=$d['id']?>" class="btn btn-b btn-sm" style="font-size:11px;padding:5px 10px">✏️</a>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<style>@media(max-width:800px){.dof-ozet{grid-template-columns:repeat(4,1fr)!important}}</style>
<script>
function filtre(k,v){var u=new URL(window.location.href);u.searchParams.set('sayfa','kalite-dof');u.searchParams.set(k,v);window.location.href=u.href;}
</script>
