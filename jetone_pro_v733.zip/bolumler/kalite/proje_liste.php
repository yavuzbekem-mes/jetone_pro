<?php
/**
 * JETONE.PRO — Proje Yönetimi Ana Sayfa
 * panel.php: 'kalite-proje' => 'bolumler/proje/index.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// ── Tabloları oluştur ─────────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS prj_proje (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proje_kodu        VARCHAR(30) UNIQUE NOT NULL,
    proje_adi         VARCHAR(200) NOT NULL,
    proje_amaci       TEXT,
    kapsam_icinde     TEXT,
    kapsam_disinda    TEXT,
    basari_kriterleri TEXT,
    sponsor           VARCHAR(100),
    proje_yoneticisi  VARCHAR(100),
    onay_makami       VARCHAR(100),
    baslangic_tarihi  DATE,
    hedef_bitis_tarihi DATE,
    gercek_bitis_tarihi DATE,
    durum             ENUM('taslak','planlama','devam','beklemede','tamamlandi','iptal') DEFAULT 'taslak',
    oncelik           ENUM('dusuk','normal','yuksek','kritik') DEFAULT 'normal',
    butce_tahmini     DECIMAL(15,2) DEFAULT 0,
    butce_gerceklesen DECIMAL(15,2) DEFAULT 0,
    tamamlanma_yuzdesi TINYINT UNSIGNED DEFAULT 0,
    notlar            TEXT,
    olusturan         VARCHAR(100),
    kayit_tarihi      DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_durum(durum), INDEX idx_tarih(baslangic_tarihi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS prj_gorev (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proje_id        INT UNSIGNED NOT NULL,
    ust_gorev_id    INT UNSIGNED DEFAULT NULL,
    gorev_adi       VARCHAR(200) NOT NULL,
    aciklama        TEXT,
    asama           ENUM('hazilik','uygulama','test','kapanis','diger') DEFAULT 'uygulama',
    sorumlu         VARCHAR(100),
    destek_kisi     VARCHAR(200),
    baslangic_tarihi DATE,
    bitis_tarihi    DATE,
    gercek_bitis    DATE,
    durum           ENUM('bekliyor','devam','tamamlandi','iptal','engellendi') DEFAULT 'bekliyor',
    oncelik         ENUM('dusuk','normal','yuksek','kritik') DEFAULT 'normal',
    tamamlanma      TINYINT UNSIGNED DEFAULT 0,
    kilometre_tasi  TINYINT(1) DEFAULT 0,
    notlar          TEXT,
    sira            INT DEFAULT 0,
    FOREIGN KEY(proje_id) REFERENCES prj_proje(id) ON DELETE CASCADE,
    INDEX idx_proje(proje_id), INDEX idx_durum(durum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS prj_risk (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proje_id        INT UNSIGNED NOT NULL,
    risk_tanimi     TEXT NOT NULL,
    kategori        ENUM('teknik','mali','zaman','kaynak','dis_etken','diger') DEFAULT 'diger',
    olasilik        TINYINT UNSIGNED DEFAULT 3 COMMENT '1-5',
    etki            TINYINT UNSIGNED DEFAULT 3 COMMENT '1-5',
    onleyici_eylem  TEXT,
    acil_plan       TEXT,
    sorumlu         VARCHAR(100),
    durum           ENUM('acik','izleniyor','kapandi','gerceklesti') DEFAULT 'acik',
    FOREIGN KEY(proje_id) REFERENCES prj_proje(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS prj_kaynak (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proje_id        INT UNSIGNED NOT NULL,
    kaynak_turu     ENUM('insan','malzeme','ekipman','diger') DEFAULT 'insan',
    ad              VARCHAR(150) NOT NULL,
    birim           VARCHAR(30),
    miktar_tahmini  DECIMAL(12,2) DEFAULT 0,
    miktar_gercek   DECIMAL(12,2) DEFAULT 0,
    birim_maliyet   DECIMAL(12,2) DEFAULT 0,
    siparis_durumu  ENUM('bekliyor','siparis_verildi','teslim_alindi','iptal') DEFAULT 'bekliyor',
    notlar          VARCHAR(255),
    FOREIGN KEY(proje_id) REFERENCES prj_proje(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS prj_dokuman (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proje_id        INT UNSIGNED NOT NULL,
    gorev_id        INT UNSIGNED DEFAULT NULL,
    dosya_adi       VARCHAR(255),
    dosya_yolu      VARCHAR(500),
    tur             ENUM('plan','rapor','sozlesme','cizim','foto','diger') DEFAULT 'diger',
    aciklama        VARCHAR(255),
    yukleyen        VARCHAR(100),
    yuklenme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(proje_id) REFERENCES prj_proje(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── Filtreler & veri ──────────────────────────────────────
$f_durum = $_GET['durum'] ?? '';
$f_oncelik = $_GET['oncelik'] ?? '';
$where = "WHERE 1=1";
$params = [];
if ($f_durum)   { $where .= " AND p.durum=?"; $params[] = $f_durum; }
if ($f_oncelik) { $where .= " AND p.oncelik=?"; $params[] = $f_oncelik; }

$projeler = $db->prepare("
    SELECT p.*,
        COUNT(DISTINCT g.id)                          AS gorev_toplam,
        SUM(g.durum='tamamlandi')                     AS gorev_tamam,
        SUM(g.durum IN ('devam','bekliyor'))           AS gorev_aktif,
        SUM(g.kilometre_tasi=1)                        AS km_toplam,
        SUM(g.kilometre_tasi=1 AND g.durum='tamamlandi') AS km_tamam,
        COUNT(DISTINCT r.id)                           AS risk_toplam,
        SUM(r.durum='acik')                            AS risk_acik
    FROM prj_proje p
    LEFT JOIN prj_gorev g ON g.proje_id=p.id
    LEFT JOIN prj_risk r ON r.proje_id=p.id
    $where
    GROUP BY p.id ORDER BY
        FIELD(p.durum,'devam','planlama','taslak','beklemede','tamamlandi','iptal'),
        FIELD(p.oncelik,'kritik','yuksek','normal','dusuk'),
        p.kayit_tarihi DESC
");
$projeler->execute($params);
$projeler = $projeler->fetchAll(PDO::FETCH_ASSOC);

// Özet
$oz = $db->query("SELECT
    COUNT(*) toplam,
    SUM(durum='devam') devam,
    SUM(durum='tamamlandi') tamamlandi,
    SUM(durum IN ('taslak','planlama')) planlama,
    SUM(durum='iptal') iptal
    FROM prj_proje")->fetch(PDO::FETCH_ASSOC);

$durum_stil = [
    'taslak'     => ['#94A3B8','#F8FAFC','Taslak'],
    'planlama'   => ['#6366F1','#EEF2FF','Planlama'],
    'devam'      => ['#0EA5E9','#F0F9FF','Devam Ediyor'],
    'beklemede'  => ['#F59E0B','#FFFBEB','Beklemede'],
    'tamamlandi' => ['#16A34A','#F0FDF4','Tamamlandı'],
    'iptal'      => ['#DC2626','#FEF2F2','İptal'],
];
$oncelik_stil = [
    'dusuk'  => ['#94A3B8','Düşük'],
    'normal' => ['#6B7280','Normal'],
    'yuksek' => ['#D97706','Yüksek'],
    'kritik' => ['#DC2626','Kritik'],
];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🚀 Proje Yönetimi</h1>
    <div class="s-yol">Anasayfa / <b>Projeler</b></div>
  </div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-form" class="btn btn-t btn-sm">+ Yeni Proje</a>
</div>

<div class="s-body">

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px" class="prj-ozet">
  <?php foreach ([
    ['🚀','Toplam Proje',  $oz['toplam']??0,    '#1E3A5F','#EFF6FF'],
    ['⏳','Devam Eden',    $oz['devam']??0,     '#0EA5E9','#F0F9FF'],
    ['📐','Planlama',      $oz['planlama']??0,  '#6366F1','#EEF2FF'],
    ['✅','Tamamlanan',   $oz['tamamlandi']??0,'#16A34A','#F0FDF4'],
    ['❌','İptal',         $oz['iptal']??0,     '#DC2626','#FEF2F2'],
  ] as $k): ?>
  <div class="kart" style="padding:14px;border-left:4px solid <?=$k[3]?>;background:<?=$k[4]?>">
    <div style="font-size:22px;margin-bottom:4px"><?=$k[0]?></div>
    <div style="font-size:26px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700;color:var(--t)"><?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:10px 16px;margin-bottom:14px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  <span style="font-size:12px;font-weight:700;color:var(--m2)">Filtrele:</span>
  <select class="form-alan" style="font-size:12px;padding:4px 8px" onchange="filtre('durum',this.value)">
    <option value="">Tüm Durumlar</option>
    <?php foreach (['taslak'=>'Taslak','planlama'=>'Planlama','devam'=>'Devam','beklemede'=>'Beklemede','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'] as $v=>$l): ?>
    <option value="<?=$v?>" <?=$f_durum===$v?'selected':''?>><?=$l?></option>
    <?php endforeach; ?>
  </select>
  <select class="form-alan" style="font-size:12px;padding:4px 8px" onchange="filtre('oncelik',this.value)">
    <option value="">Tüm Öncelikler</option>
    <?php foreach (['kritik'=>'Kritik','yuksek'=>'Yüksek','normal'=>'Normal','dusuk'=>'Düşük'] as $v=>$l): ?>
    <option value="<?=$v?>" <?=$f_oncelik===$v?'selected':''?>><?=$l?></option>
    <?php endforeach; ?>
  </select>
  <span style="margin-left:auto;font-size:12px;color:var(--m2)"><?=count($projeler)?> proje</span>
</div>

<!-- Proje Listesi -->
<?php if (empty($projeler)): ?>
<div class="kart" style="padding:50px;text-align:center;color:var(--m3)">
  <div style="font-size:44px;margin-bottom:12px">🚀</div>
  <div style="font-size:15px;font-weight:700;margin-bottom:12px">Henüz proje yok</div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-form" class="btn btn-t">+ İlk Projeyi Oluştur</a>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach ($projeler as $p):
  $ds  = $durum_stil[$p['durum']] ?? ['#6B7280','#F1F5F9','?'];
  $os  = $oncelik_stil[$p['oncelik']] ?? ['#6B7280','Normal'];
  $pct = (int)$p['tamamlanma_yuzdesi'];
  $gt  = (int)$p['gorev_toplam'];
  $gtam= (int)$p['gorev_tamam'];
  $gpct= $gt>0 ? round($gtam/$gt*100) : 0;
  // Gecikme kontrolü
  $gecikti = $p['durum']==='devam' && $p['hedef_bitis_tarihi'] && $p['hedef_bitis_tarihi'] < date('Y-m-d');
?>
<div class="kart" style="padding:0;overflow:hidden;border-left:4px solid <?=$ds[0]?>">
  <div style="padding:14px 18px;display:flex;align-items:center;gap:16px;flex-wrap:wrap">

    <!-- Kod + Durum + Öncelik -->
    <div style="min-width:140px">
      <div style="font-weight:900;font-size:15px;font-family:monospace;color:var(--t)"><?=htmlspecialchars($p['proje_kodu'])?></div>
      <div style="display:flex;gap:5px;margin-top:4px;flex-wrap:wrap">
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:<?=$ds[1]?>;color:<?=$ds[0]?>"><?=$ds[2]?></span>
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:<?=$os[0]?>22;color:<?=$os[0]?>;border:1px solid <?=$os[0]?>"><?=$os[1]?></span>
        <?php if($gecikti): ?><span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:#DC2626;color:#fff">⚠️ Gecikti</span><?php endif; ?>
      </div>
    </div>

    <!-- İsim + Yönetici + Tarih -->
    <div style="flex:1;min-width:200px">
      <div style="font-size:15px;font-weight:800;color:var(--t);margin-bottom:4px"><?=htmlspecialchars($p['proje_adi'])?></div>
      <div style="display:flex;gap:14px;font-size:12px;color:var(--m2);flex-wrap:wrap">
        <?php if($p['proje_yoneticisi']): ?><span>👤 <?=htmlspecialchars($p['proje_yoneticisi'])?></span><?php endif; ?>
        <?php if($p['baslangic_tarihi']): ?><span>📅 <?=date('d.m.Y',strtotime($p['baslangic_tarihi']))?></span><?php endif; ?>
        <?php if($p['hedef_bitis_tarihi']): ?>
        <span style="color:<?=$gecikti?'#DC2626':'var(--m2)'?>">🏁 <?=date('d.m.Y',strtotime($p['hedef_bitis_tarihi']))?></span>
        <?php endif; ?>
      </div>
    </div>

    <!-- İlerleme + Görev + Risk -->
    <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
      <!-- Tamamlanma -->
      <div style="text-align:center;min-width:65px">
        <div style="font-size:10px;color:var(--m2);margin-bottom:2px">İlerleme</div>
        <div style="font-size:18px;font-weight:900;color:<?php echo ($pct>=100?'#16A34A':($pct>50?'#0EA5E9':'#6B7280')); ?>"><?=$pct?>%</div>
        <div style="height:5px;background:var(--kenar);border-radius:3px;width:65px">
          <div style="height:100%;width:<?=$pct?>%;background:<?php echo ($pct>=100?'#22C55E':($pct>50?'#0EA5E9':'#6366F1')); ?>;border-radius:3px;transition:width .3s"></div>
        </div>
      </div>
      <!-- Görevler -->
      <?php if($gt>0): ?>
      <div style="text-align:center">
        <div style="font-size:10px;color:var(--m2)">Görevler</div>
        <div style="font-size:13px;font-weight:700;color:var(--t)"><?=$gtam?>/<?=$gt?></div>
      </div>
      <?php endif; ?>
      <!-- Bütçe -->
      <?php if($p['butce_tahmini']>0): ?>
      <div style="text-align:center">
        <div style="font-size:10px;color:var(--m2)">Bütçe</div>
        <div style="font-size:12px;font-weight:700;color:<?=$p['butce_gerceklesen']>$p['butce_tahmini']?'#DC2626':'var(--t)'?>">
          <?=number_format($p['butce_gerceklesen'],0,',','.')?> ₺
        </div>
        <div style="font-size:10px;color:var(--m3)">/ <?=number_format($p['butce_tahmini'],0,',','.')?> ₺</div>
      </div>
      <?php endif; ?>
      <!-- Risk -->
      <?php if((int)$p['risk_acik']>0): ?>
      <span style="font-size:10px;font-weight:700;padding:3px 8px;border-radius:8px;background:#FEF2F2;color:#DC2626">⚡ <?=$p['risk_acik']?> risk</span>
      <?php endif; ?>
      <!-- Butonlar -->
      <div style="display:flex;gap:6px">
        <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-detay&id=<?=$p['id']?>" class="btn btn-t btn-sm" style="font-size:11px;padding:5px 12px">📂 Aç</a>
        <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-form&id=<?=$p['id']?>" class="btn btn-b btn-sm" style="font-size:11px;padding:5px 10px">✏️</a>
      </div>
    </div>
  </div>
  <!-- Progress bar alt çizgi -->
  <?php if($pct>0&&$pct<100): ?>
  <div style="height:3px;background:var(--kenar)"><div style="height:100%;width:<?=$pct?>%;background:<?=$ds[0]?>;opacity:.5"></div></div>
  <?php endif; ?>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

</div><!-- /s-body -->
<style>@media(max-width:700px){.prj-ozet{grid-template-columns:repeat(3,1fr)!important}}</style>
<script>
function filtre(k,v){
    var u=new URL(window.location.href);
    u.searchParams.set('sayfa','kalite-proje');
    u.searchParams.set(k,v);
    window.location.href=u.href;
}
</script>
