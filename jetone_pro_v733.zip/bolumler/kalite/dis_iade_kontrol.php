<?php
/**
 * Dış İade Kontrol Sonuçları Listesi
 * panel.php: 'kalite-dis-iade-kontrol'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

// Tarih filtresi
$start = $_POST['start_date'] ?? date('Y-m-d', strtotime('-1 month'));
$end   = $_POST['end_date']   ?? date('Y-m-d');

// Kayıtları çek
try {
    $st = $db->prepare("SELECT d.*,
        (SELECT SUM(hata_miktar) FROM dis_iade_kontrol_listesi d2
         WHERE d2.irsaliye_no=d.irsaliye_no AND d2.malzeme_kodu=d.malzeme_kodu) AS toplam_hata
        FROM dis_iade_kontrol_listesi d
        WHERE d.kayit_tarih BETWEEN ? AND ?
        ORDER BY d.kayit_tarih DESC, d.irsaliye_no, d.malzeme_kodu");
    $st->execute([$start, $end]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $rows = []; }

// Tiger'dan irsaliye miktarlarını toplu çek
$irsaliye_miktar_map = [];
if ($rows && !empty($tigerdb_pdo)) {
    $irs_list = array_unique(array_column($rows, 'irsaliye_no'));
    foreach (array_chunk($irs_list, 10) as $chunk) {
        $in = implode(',', array_fill(0, count($chunk), '?'));
        try {
            $tst = $tigerdb_pdo->prepare("
                SELECT FICHENO AS irs, SUM(STL.AMOUNT) AS mkt
                FROM LG_222_02_STLINE STL
                LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STF.TRCODE=3 AND STF.FICHENO IN ($in)
                GROUP BY STF.FICHENO
                UNION ALL
                SELECT FICHENO, SUM(STL.AMOUNT)
                FROM LG_222_01_STLINE STL
                LEFT JOIN LG_222_01_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STF.TRCODE=3 AND STF.FICHENO IN ($in)
                GROUP BY STF.FICHENO");
            $tst->execute(array_merge($chunk,$chunk));
            foreach ($tst->fetchAll(PDO::FETCH_ASSOC) as $tm) {
                $irsaliye_miktar_map[$tm['irs']] = (float)$tm['mkt'];
            }
        } catch (Throwable $e) {}
    }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Dış İade Kontrol Sonuçları</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-liste" style="color:var(--t)">Dış İade</a> / <b>Kontrol Sonuçları</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-liste" class="btn btn-b btn-sm">← İrsaliye Sorgula</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-ozet" class="btn btn-b btn-sm">📊 Özet</a>
  </div>
</div>

<div class="s-body">

<!-- Tarih filtresi -->
<div class="kart" style="margin-bottom:14px;padding:12px">
  <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="start_date" value="<?= $start ?>">
    </div>
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="end_date" value="<?= $end ?>">
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0">
  <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);font-size:13px;font-weight:700">
    <?= htmlspecialchars($start) ?> — <?= htmlspecialchars($end) ?>
    <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:8px"><?= count($rows) ?> kayıt</span>
  </div>
  <div style="overflow-x:auto">
    <?php $sth = ['#','İrsaliye No','Malzeme Kodu','Malzeme Adı','İrs.Miktarı','Hata Tipi','Hata Miktarı','Alınan Aksiyon','Kontrol Oranı','Kayıt Tarihi','Kaydeden','Sil']; ?>
    <table id="kontrolTablo" class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach ($sth as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tfoot><tr style="background:#1E3A5F!important">
        <?php foreach ($sth as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></tfoot>
      <tbody>
      <?php foreach ($rows as $i => $r):
          $irs_mkt    = $irsaliye_miktar_map[$r['irsaliye_no']] ?? 0;
          $toplam_hata= (float)($r['toplam_hata'] ?? 0);
          $oran       = $irs_mkt > 0 ? round($toplam_hata / $irs_mkt * 100, 1) : 0;
          if ($oran >= 100)    $rbg = 'background:#D1FAE5';
          elseif ($oran > 0)   $rbg = 'background:#FEF9C3';
          else                 $rbg = '';
      ?>
      <tr style="<?= $rbg ?>">
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td style="font-family:monospace;font-weight:700;white-space:nowrap">
          <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-detay&irsaliye=<?= urlencode($r['irsaliye_no']) ?>"
             style="color:var(--t)"><?= htmlspecialchars($r['irsaliye_no']) ?></a>
        </td>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['malzeme_kodu']??'') ?></td>
        <td style="max-width:200px;font-size:12px"><?= htmlspecialchars($r['malzeme_adi']??'') ?></td>
        <td style="text-align:right"><?= $irs_mkt > 0 ? number_format($irs_mkt,0) : '—' ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['hata_tipi']??'') ?></td>
        <td style="text-align:right;font-weight:700;color:#EF4444"><?= htmlspecialchars($r['hata_miktar']??'') ?></td>
        <td style="font-size:11px;max-width:160px"><?= htmlspecialchars($r['alinan_aksiyon']??'') ?></td>
        <td style="text-align:center;font-weight:800;color:<?= $oran>=100?'#22C55E':($oran>0?'#F59E0B':'var(--m2)') ?>">
          <?= $oran ?>%
        </td>
        <td style="white-space:nowrap;font-size:11px"><?= $r['kayit_tarih'] ? date('d.m.Y',strtotime($r['kayit_tarih'])) : '—' ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['kul_adi']??'') ?></td>
        <td>
          <button type="button" class="btn btn-sm sil-btn" data-id="<?= $r['id'] ?>"
                  style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
$(document).ready(function(){
  var tbl = $('#kontrolTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true, scrollY:500, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'DisIade_<?= date('Ymd') ?>'},{extend:'print',text:'🖨'}],
    drawCallback:function(){ $('#kontrolTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){ $('#kontrolTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); }
  });
});

document.addEventListener('click', async function(e){
  var btn = e.target.closest('.sil-btn');
  if (!btn) return;
  if (!confirm('Bu kaydı silmek istiyor musunuz?')) return;
  try {
    var r = await fetch('<?= BASE_URL ?>/islemler/kalite/dis_iade_sil.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id: parseInt(btn.dataset.id)})
    });
    var j = await r.json();
    if (j.status==='success') { location.reload(); }
    else { alert('Hata: '+j.message); }
  } catch(e){ alert('Hata: '+e.message); }
});
</script>
