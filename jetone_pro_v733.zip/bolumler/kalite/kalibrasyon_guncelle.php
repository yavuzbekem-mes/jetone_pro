<?php
/**
 * Kalibrasyon Cihaz Güncelle / Yeni Ekle
 * panel.php: 'kalite-kalibrasyon-guncelle' => ...
 *            'kalite-kalibrasyon-ekle'     => ...
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

$id = (int)($_GET['id'] ?? 0);
$yeni = ($id === 0);
$kayit = [];

if (!$yeni) {
    $st = $db->prepare("SELECT * FROM kalibrasyon_cihazlar WHERE id=?");
    $st->execute([$id]);
    $kayit = $st->fetch(PDO::FETCH_ASSOC) ?: [];
    if (!$kayit) { echo '<p>Cihaz bulunamadı</p>'; exit; }
}

function ns($v,$d=''){ return htmlspecialchars(trim($v??$d)); }
function vt($t){ return (!empty($t)&&$t!=='0000-00-00')?date('Y-m-d',strtotime($t)):''; }
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas"><?= $yeni ? '➕ Yeni Cihaz Ekle' : '✏️ Cihaz Güncelle: '.ns($kayit['kayit_no']) ?></h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" style="color:var(--t)">Kalibrasyon</a> / <b><?= $yeni ? 'Yeni' : ns($kayit['kayit_no']) ?></b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" class="btn btn-b btn-sm">← Liste</a>
</div>

<div class="s-body">
<div class="kart" style="max-width:800px">
  <form action="<?= BASE_URL ?>/islemler/kalite/kalibrasyon_cihaz_kaydet.php" method="POST">
    <input type="hidden" name="id" value="<?= $id ?>">

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Kayıt No (POL-XX) <span class="zorunlu">*</span></label>
        <input class="form-alan" type="text" name="kayit_no" required value="<?= ns($kayit['kayit_no']??'') ?>"
               placeholder="POL-01" <?= !$yeni?'readonly style="background:var(--kenar-a)"':'' ?>>
      </div>
      <div class="form-grup">
        <label class="form-et">Kullanım Bölümü</label>
        <input class="form-alan" type="text" name="kullanim_bolumu" value="<?= ns($kayit['kullanim_bolumu']??'') ?>" placeholder="KALİTE, ÜRETİM...">
      </div>
    </div>

    <div class="form-grup">
      <label class="form-et">Cihaz Adı <span class="zorunlu">*</span></label>
      <input class="form-alan" type="text" name="cihaz_adi" required value="<?= ns($kayit['cihaz_adi']??'') ?>">
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Marka & Model</label>
        <input class="form-alan" type="text" name="marka_model" value="<?= ns($kayit['marka_model']??'') ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Ölçüm Aralığı</label>
        <input class="form-alan" type="text" name="olcum_araligi" value="<?= ns($kayit['olcum_araligi']??'') ?>">
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Hassasiyet</label>
        <input class="form-alan" type="text" name="hassasiyet" value="<?= ns($kayit['hassasiyet']??'') ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Kalibrasyon Periyodu (Gün) <span class="zorunlu">*</span></label>
        <input class="form-alan" type="number" name="periyot_gun" required min="1"
               value="<?= (int)($kayit['periyot_gun']??365) ?>" id="periyotGun">
      </div>
    </div>

    <div style="border-top:1px solid var(--kenar);margin:14px 0;padding-top:14px">
      <div style="font-size:13px;font-weight:800;margin-bottom:12px">Kalibrasyon Bilgileri</div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Son Kalibrasyon Tarihi</label>
          <input class="form-alan" type="date" name="son_kalibrasyon" id="sonKalibrasyonTarih"
                 value="<?= vt($kayit['son_kalibrasyon']??'') ?>" onchange="sonrakiHesapla()">
        </div>
        <div class="form-grup">
          <label class="form-et">Sonraki Kalibrasyon Tarihi</label>
          <input class="form-alan" type="date" name="sonraki_kalibrasyon" id="sonrakiKalibrasyonTarih"
                 value="<?= vt($kayit['sonraki_kalibrasyon']??'') ?>"
                 style="background:var(--kenar-a)" readonly>
          <div style="font-size:11px;color:var(--m2);margin-top:3px">Son tarih + periyot gün otomatik hesaplanır</div>
        </div>
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Yapan Firma</label>
        <input class="form-alan" type="text" name="yapan_firma" value="<?= ns($kayit['yapan_firma']??'') ?>">
      </div>
      <div class="form-grup">
        <label class="form-et">Durum</label>
        <select class="form-alan" name="durum">
          <?php foreach (['OKEY','ARIZALI','KULLANIM DIŞI','KAYIP'] as $d): ?>
          <option value="<?= $d ?>" <?= ($kayit['durum']??'OKEY')===$d?'selected':'' ?>><?= $d ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-grup">
      <label class="form-et">Değerlendirme Sonucu</label>
      <input class="form-alan" type="text" name="degerlendirme" value="<?= ns($kayit['degerlendirme']??'') ?>"
             placeholder="KULLANIMA UYGUNDUR / KULLANIMA UYGUN DEĞİL">
    </div>

    <div class="form-grup">
      <label class="form-et">Açıklama</label>
      <textarea class="form-alan" name="aciklama" rows="2"><?= ns($kayit['aciklama']??'') ?></textarea>
    </div>

    <div class="form-footer">
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kalibrasyon-liste" class="btn btn-b">İptal</a>
      <button type="submit" class="btn btn-t">💾 <?= $yeni?'Kaydet':'Güncelle' ?></button>
    </div>
  </form>
</div>
</div>

<script>
function sonrakiHesapla(){
    var son = document.getElementById('sonKalibrasyonTarih').value;
    var periyot = parseInt(document.getElementById('periyotGun').value) || 365;
    if (!son) return;
    var d = new Date(son);
    d.setDate(d.getDate() + periyot);
    document.getElementById('sonrakiKalibrasyonTarih').value = d.toISOString().split('T')[0];
}
document.getElementById('periyotGun').addEventListener('input', sonrakiHesapla);
sonrakiHesapla();
</script>
