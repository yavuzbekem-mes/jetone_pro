<?php
/**
 * DÖF Aç / Düzenle
 * panel.php: 'kalite-dof-form' => 'bolumler/kalite/dof_form.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
$d  = null;
if ($id) { $s=$db->prepare("SELECT * FROM kal_dof WHERE id=?");$s->execute([$id]);$d=$s->fetch(PDO::FETCH_ASSOC); }
$d = $d ?: ['dof_no'=>'','kaynak'=>'ic_denetim','kaynak_ref'=>'','problem_tanimi'=>'','bes_n_kim'=>'','bes_n_ne'=>'','bes_n_nerede'=>'','bes_n_nezaman'=>'','bes_n_nasil'=>'','etkilenen_miktar'=>'','gecici_onlem'=>'','kok_neden_5n'=>'','kok_neden_kacan'=>'','balik_insan'=>'','balik_yontem'=>'','balik_makine'=>'','balik_malzeme'=>'','balik_olcum'=>'','balik_cevre'=>'','duzeltici_faaliyet'=>'','onleyici_faaliyet'=>'','sorumlu'=>$kul_adi,'hedef_tarih'=>'','dogrulama_yontemi'=>'','dogrulayan'=>'','dogrulama_tarihi'=>'','etkinlik_kontrolu'=>'','durum'=>'acildi','kritiklik'=>'orta','acilis_tarihi'=>date('Y-m-d')];

$mesaj=''; $mesaj_tip='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $no = trim($_POST['dof_no']??'');
    if (!$no) {
        $yil=date('Y');
        $son=$db->query("SELECT dof_no FROM kal_dof WHERE dof_no LIKE 'DOF-{$yil}-%' ORDER BY id DESC LIMIT 1")->fetchColumn();
        $no=sprintf('DOF-%d-%03d',$yil,$son?(int)substr($son,-3)+1:1);
    }
    $fields=['dof_no'=>$no,'kaynak'=>$_POST['kaynak'],'kaynak_ref'=>$_POST['kaynak_ref']??'','problem_tanimi'=>$_POST['problem_tanimi'],'bes_n_kim'=>$_POST['bes_n_kim']??'','bes_n_ne'=>$_POST['bes_n_ne']??'','bes_n_nerede'=>$_POST['bes_n_nerede']??'','bes_n_nezaman'=>$_POST['bes_n_nezaman']??'','bes_n_nasil'=>$_POST['bes_n_nasil']??'','etkilenen_miktar'=>$_POST['etkilenen_miktar']??'','gecici_onlem'=>$_POST['gecici_onlem']??'','kok_neden_5n'=>$_POST['kok_neden_5n']??'','kok_neden_kacan'=>$_POST['kok_neden_kacan']??'','balik_insan'=>$_POST['balik_insan']??'','balik_yontem'=>$_POST['balik_yontem']??'','balik_makine'=>$_POST['balik_makine']??'','balik_malzeme'=>$_POST['balik_malzeme']??'','balik_olcum'=>$_POST['balik_olcum']??'','balik_cevre'=>$_POST['balik_cevre']??'','duzeltici_faaliyet'=>$_POST['duzeltici_faaliyet']??'','onleyici_faaliyet'=>$_POST['onleyici_faaliyet']??'','sorumlu'=>$_POST['sorumlu']??'','hedef_tarih'=>$_POST['hedef_tarih']?:null,'dogrulama_yontemi'=>$_POST['dogrulama_yontemi']??'','dogrulayan'=>$_POST['dogrulayan']??'','dogrulama_tarihi'=>$_POST['dogrulama_tarihi']?:null,'etkinlik_kontrolu'=>$_POST['etkinlik_kontrolu']??'','durum'=>$_POST['durum'],'kritiklik'=>$_POST['kritiklik'],'acilis_tarihi'=>$_POST['acilis_tarihi']];
    try {
        if ($id) {
            $set=implode(',',array_map(fn($k)=>"$k=?",array_keys($fields)));
            $db->prepare("UPDATE kal_dof SET $set WHERE id=?")->execute([...array_values($fields),$id]);
            $mesaj='Güncellendi.'; $mesaj_tip='ok';
            $s2=$db->prepare("SELECT * FROM kal_dof WHERE id=?");$s2->execute([$id]);$d=$s2->fetch(PDO::FETCH_ASSOC);
        } else {
            $fields['olusturan']=$kul_adi;
            $cols=implode(',',array_keys($fields));$vals=implode(',',array_fill(0,count($fields),'?'));
            $db->prepare("INSERT INTO kal_dof ($cols) VALUES ($vals)")->execute(array_values($fields));
            $id=(int)$db->lastInsertId();
            echo "<script>window.location.href=".json_encode(BASE_URL.'/panel.php?sayfa=kalite-dof-detay&id='.$id).";</script>"; exit;
        }
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}

// 8D listesi (bağlantı için)
$sekizd_list = [];
try { $sekizd_list=$db->query("SELECT id,sekizd_no,problem_ozeti FROM kal_sekizd ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e){}

function ta($name,$val,$placeholder='') { return "<textarea name=\"$name\" class=\"form-alan\" rows=\"3\" style=\"width:100%;resize:vertical\" placeholder=\"$placeholder\">".htmlspecialchars($val)."</textarea>"; }
function inp($name,$val,$placeholder='') { return "<input name=\"$name\" class=\"form-alan\" value=\"".htmlspecialchars($val)."\" placeholder=\"$placeholder\">"; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?=$id?'✏️ DÖF Düzenle':'+ Yeni DÖF Aç'?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof" style="color:var(--t)">DÖF</a> / <b><?=$id?'Düzenle':'Yeni'?></b></div>
  </div>
  <?php if($id): ?><a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-detay&id=<?=$id?>" class="btn btn-b btn-sm">← Detay</a><?php endif; ?>
</div>
<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<div style="max-width:860px">
<form method="POST">

<!-- 1. Kimlik -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid #DC2626;color:var(--t)">🔴 1. DÖF Kimliği ve Kaynak</div>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
    <div><label class="form-et">DÖF No <span style="font-size:10px;color:var(--m3)">(boş=otomatik)</span></label><?=inp('dof_no',$d['dof_no'],'DOF-2026-001')?></div>
    <div><label class="form-et">Açılış Tarihi</label><input type="date" name="acilis_tarihi" class="form-alan" value="<?=htmlspecialchars($d['acilis_tarihi'])?>"></div>
    <div><label class="form-et">Hedef Kapanış</label><input type="date" name="hedef_tarih" class="form-alan" value="<?=htmlspecialchars($d['hedef_tarih']??'')?>"></div>
    <div><label class="form-et">Kaynak</label>
      <select name="kaynak" class="form-alan">
        <?php foreach (['musteri_sikayet'=>'Müşteri Şikayeti','ic_denetim'=>'İç Denetim','urun_hatasi'=>'Ürün Hatası','proses_hatasi'=>'Proses Hatası','tedarikci'=>'Tedarikçi','calisma_kazasi'=>'Çalışma Kazası','diger'=>'Diğer'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['kaynak']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div><label class="form-et">Kaynak Ref No</label><?=inp('kaynak_ref',$d['kaynak_ref']??'','Denetim/Şikayet/Proje No')?></div>
    <div><label class="form-et">Kritiklik</label>
      <select name="kritiklik" class="form-alan">
        <?php foreach (['dusuk'=>'Düşük','orta'=>'Orta','yuksek'=>'Yüksek','kritik'=>'KRİTİK'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['kritiklik']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?>
      </select>
    </div>
    <div><label class="form-et">Durum</label>
      <select name="durum" class="form-alan">
        <?php foreach (['acildi'=>'🔴 Açıldı','analiz'=>'🔎 Analiz','aksiyon'=>'⚙️ Aksiyon','dogrulama'=>'✅ Doğrulama','kapandi'=>'🏁 Kapandı','iptal'=>'❌ İptal'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['durum']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?>
      </select>
    </div>
    <div><label class="form-et">Sorumlu</label><?=inp('sorumlu',$d['sorumlu']??'')?></div>
    <?php if(!empty($sekizd_list)): ?>
    <div><label class="form-et">Bağlı 8D <span style="font-size:10px;color:var(--m3)">(opsiyonel)</span></label>
      <select name="ilgili_8d_id" class="form-alan">
        <option value="">—</option>
        <?php foreach($sekizd_list as $sd): ?><option value="<?=$sd['id']?>" <?=($d['ilgili_8d_id']??'')==$sd['id']?'selected':''?>><?=$sd['sekizd_no']?> — <?=htmlspecialchars(mb_strimwidth($sd['problem_ozeti'],0,30,'…'))?></option><?php endforeach; ?>
      </select>
    </div>
    <?php endif; ?>
  </div>
  <div style="margin-top:10px">
    <label class="form-et">Problem Tanımı <span style="color:#EF4444">*</span></label>
    <?=ta('problem_tanimi',$d['problem_tanimi'],'Sorunun açık ve net tanımı...')?>
  </div>
</div>

<!-- 2. 5N1K -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid #D97706">🔎 2. Problem Analizi — 5N1K</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <?php foreach ([
      ['bes_n_kim',    '👤 KİM — Sorunu kim bildirdi/buldu?'],
      ['bes_n_ne',     '🔧 NE — Sorun tam olarak nedir?'],
      ['bes_n_nerede', '📍 NEREDE — Hangi süreç/makine/bölümde?'],
      ['bes_n_nezaman','📅 NE ZAMAN — Ne zaman/ne sıklıkla?'],
      ['bes_n_nasil',  '🔍 NASIL — Nasıl fark edildi?'],
    ] as $f): ?>
    <div><label class="form-et"><?=$f[1]?></label><?=ta($f[0],$d[$f[0]]??'')?></div>
    <?php endforeach; ?>
    <div><label class="form-et">📊 Etkilenen Miktar/Kapsam</label><?=inp('etkilenen_miktar',$d['etkilenen_miktar']??'','100 adet, Lot 2024-001...')?></div>
  </div>
</div>

<!-- 3. Geçici Önlem -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:10px;padding-bottom:7px;border-bottom:2px solid #F59E0B">🚧 3. Geçici Önlem (Karantina/Acil Müdahale)</div>
  <?=ta('gecici_onlem',$d['gecici_onlem']??'','Stok blokajı, %100 kontrol, müşteriye bildirim... Sorunun yayılmasını durdurmak için alınan acil önlemler')?>
</div>

<!-- 4. Kök Neden -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid #0EA5E9">🐟 4. Kök Neden Analizi</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
    <div>
      <label class="form-et">5 Neden Analizi Özeti</label>
      <?=ta('kok_neden_5n',$d['kok_neden_5n']??'','1. Neden? → Cevap
2. Neden? → Cevap
3. Neden? → Cevap
4. Neden? → Cevap
5. Neden (Kök)? → KÖK NEDEN')?>
    </div>
    <div>
      <label class="form-et">Kaçış Noktası <span style="font-size:10px;color:var(--m2)">(neden fark edilmedi?)</span></label>
      <?=ta('kok_neden_kacan',$d['kok_neden_kacan']??'','Sorun neden kontrol sisteminden kaçtı?')?>
    </div>
  </div>
  <!-- Balık Kılçığı -->
  <div style="background:#F8FAFC;border:1px solid var(--kenar);border-radius:8px;padding:14px">
    <div style="font-weight:700;font-size:12px;color:var(--m2);margin-bottom:10px">🐟 Balık Kılçığı (İshikawa) — Kategoriler</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
      <?php foreach ([
        ['balik_insan',    '👤 İnsan','Eğitim eksikliği, dikkatsizlik, tecrübesizlik'],
        ['balik_yontem',   '📋 Yöntem','SOP eksik, talimat belirsiz, prosedür hatası'],
        ['balik_makine',   '🔧 Makine/Ekipman','Kalibrasyon hatası, arıza, uygunsuz ekipman'],
        ['balik_malzeme',  '📦 Malzeme','Kalitesiz hammadde, spec dışı, hatalı tedarik'],
        ['balik_olcum',    '📏 Ölçüm','Yanlış ölçüm, ölçüm eksikliği, cihaz hatası'],
        ['balik_cevre',    '🌡️ Çevre','Titreşim, sıcaklık, nem, gürültü'],
      ] as $bc): ?>
      <div>
        <label class="form-et" style="font-size:11px"><?=$bc[1]?></label>
        <?=ta($bc[0],$d[$bc[0]]??'',$bc[2])?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- 5. Faaliyetler -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid #16A34A">⚙️ 5. Düzeltici ve Önleyici Faaliyetler</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <div><label class="form-et">Düzeltici Faaliyet <span style="font-size:10px;color:var(--m2)">(sorunun tekrarlanmaması için)</span></label>
    <?=ta('duzeltici_faaliyet',$d['duzeltici_faaliyet']??'','Alınan kalıcı aksiyon, sistem/prosedür değişikliği...')?>
    </div>
    <div><label class="form-et">Önleyici Faaliyet <span style="font-size:10px;color:var(--m2)">(benzer hataların önlenmesi)</span></label>
    <?=ta('onleyici_faaliyet',$d['onleyici_faaliyet']??'','Diğer süreçlere yayılım, eğitim, prosedür güncelleme...')?>
    </div>
  </div>
</div>

<!-- 6. Doğrulama -->
<div class="kart" style="padding:18px;margin-bottom:12px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;padding-bottom:7px;border-bottom:2px solid #7C3AED">✅ 6. Doğrulama ve Kapatma</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
    <div><label class="form-et">Doğrulayan</label><?=inp('dogrulayan',$d['dogrulayan']??'')?></div>
    <div><label class="form-et">Doğrulama Tarihi</label><input type="date" name="dogrulama_tarihi" class="form-alan" value="<?=htmlspecialchars($d['dogrulama_tarihi']??'')?>"></div>
    <div><label class="form-et">Tamamlanma Tarihi</label><input type="date" name="tamamlanma_tarihi" class="form-alan" value="<?=htmlspecialchars($d['tamamlanma_tarihi']??'')?>"></div>
    <div class="c3"><label class="form-et">Doğrulama Yöntemi (Kanıtlar)</label><?=ta('dogrulama_yontemi',$d['dogrulama_yontemi']??'','Fotoğraf, revize prosedür, eğitim kaydı, ölçüm sonuçları...')?></div>
    <div class="c3"><label class="form-et">Etkinlik Kontrolü <span style="font-size:10px;color:var(--m2)">(Aksiyon işe yaradı mı?)</span></label><?=ta('etkinlik_kontrolu',$d['etkinlik_kontrolu']??'','Takip ölçümleri, tekrar eden hata var mı?...')?></div>
  </div>
</div>

<div style="display:flex;gap:8px;justify-content:flex-end">
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof" class="btn btn-b">İptal</a>
  <button type="submit" class="btn btn-t">💾 <?=$id?'Güncelle':'DÖF Aç'?></button>
</div>
</form>
</div>
</div>
<style>.c3{grid-column:span 3}</style>
