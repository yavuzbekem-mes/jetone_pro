<?php
/**
 * JETONE.PRO — Tekmelik Mıknatıs Test Cihazları
 * bolumler/kalite/miknatis_cihazlar.php
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();


// ── Sabit ürün listesi ──────────────────────────────────────
$urun_listesi = [
    '2985310100' => 'TEKMELIK_PROLOGUE_GR_ARC1_BEYAZ',
    '2985310200' => 'TEKMELIK_GR_PROLOGUE_ARC722_SYH',
    '2985310300' => 'TEKMELIK_GR_PROLOGUE_P1_BYZ_V0',
    '2985310400' => 'TEKMELIK_GR_PROLOGUE_ARC1050_GRI',
    '2985310500' => 'TEKMELIK_GR_PROLOGUE_ARC764MGRI',
    '2985310600' => 'TEKMELIK_GR_PROLOGUE_ARC700_ANTRSIT',
    '2985310700' => 'TEKMELIK_GR_PROLOGUE_ARC1165_ANTRASIT',
    '2987910100' => 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ',
    '2987910200' => 'TEKMELIK_GRUBU_OEM_ARC_722 SIYAH_PARLAK',
    '2987910300' => 'TEKMELIK_GRUBU_OEM_ARC_P1BEYAZ_V0',
    '2987910400' => 'TEKMELIK_GRUBU_OEM_ARC_1050_GRI',
    '2987910500' => 'TEKMELIK_GRUBU_OEM_ARC_764S MGRAY',
    '2987910600' => 'TEKMELIK_GRUBU_OEM_ARC_700_ANTRASIT',
    '2987910700' => 'TEKMELIK_GRUBU_OEM_ARC_1165_ANTRASIT',
    '2988080100' => 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ',
    '2988080200' => 'TEKMELIK_GRUBU_BEYOND_ARC722 SYH_PARLAK',
    '2988080300' => 'TEKMELIK_GRUBU_BEYOND_ARC_P1BEYAZ_V0',
    '2988080400' => 'TEKMELIK_GRUBU_BEYOND_ARC_1050_GRI',
    '2988080500' => 'TEKMELIK_GRUBU_BEYOND_ARC_764S MAN_GRAY',
    '2988080600' => 'TEKMELIK_GRUBU_BEYOND_ARC_1165_ANTRASIT',
    '2988080700' => 'TEKMELIK_GRUBU_BEYOND_KAPALI_ARC1',
    '2995190100' => 'TEKMELIK_GR_PLM4_ARC_P1BEYAZ Indesit',
    '2995190200' => 'TEKMELIK_GR_PLM4_ARC722 SYH_PARLAK Indesit',
    '2995190400' => 'TEKMELIK_GR_PLM4_ARC_1050_GRI',
    '2995190500' => 'TEKMELIK_GR_PLM4_ARC_764S MAN_GRAY',
    '2995190600' => 'TEKMELIK_GR_PLM4_ARC_1165_ANTRASIT',
];
// ── 8 sabit cihaz ────────────────────────────────────────────
$cihazlar = [
    'KRT-01' => ['ad' => 'Tekmelik Test Cihazı 1', 'konum' => 'Kalite Lab — İstasyon 1'],
    'KRT-02' => ['ad' => 'Tekmelik Test Cihazı 2', 'konum' => 'Kalite Lab — İstasyon 2'],
    'KRT-03' => ['ad' => 'Tekmelik Test Cihazı 3', 'konum' => 'Kalite Lab — İstasyon 3'],
    'KRT-04' => ['ad' => 'Tekmelik Test Cihazı 4', 'konum' => 'Kalite Lab — İstasyon 4'],
    'KRT-05' => ['ad' => 'Tekmelik Test Cihazı 5', 'konum' => 'Üretim Hattı — A Bölgesi'],
    'KRT-06' => ['ad' => 'Tekmelik Test Cihazı 6', 'konum' => 'Üretim Hattı — B Bölgesi'],
    'KRT-07' => ['ad' => 'Tekmelik Test Cihazı 7', 'konum' => 'Sevkiyat Kontrol 1'],
    'KRT-08' => ['ad' => 'Tekmelik Test Cihazı 8', 'konum' => 'Sevkiyat Kontrol 2'],
];



// ── Tanım map ─────────────────────────────────────────────────
$tanim_map = [];
try {
    $db->exec("CREATE TABLE IF NOT EXISTS miknatis_cihaz_tanim (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        makina_kodu VARCHAR(20) NOT NULL,
        urun_kodu   VARCHAR(30) NOT NULL,
        aktif       TINYINT(1) NOT NULL DEFAULT 1,
        guncelleme  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        guncelleyen VARCHAR(100),
        UNIQUE KEY uk_makina (makina_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    foreach ($db->query("SELECT * FROM miknatis_cihaz_tanim")->fetchAll(PDO::FETCH_ASSOC) as $r)
        $tanim_map[$r['makina_kodu']] = $r;
} catch (Throwable $e) {}

// ── Bugünkü istatistik ────────────────────────────────────────
$istat_map = [];
try {
    foreach ($db->query("
        SELECT makina_kodu,
               COUNT(*) AS toplam,
               SUM(durum='basarili') AS basarili,
               SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
               SUM(durum='duzeltildi') AS duzeltildi,
               ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran,
               MAX(kontrol_zamani) AS son_test
        FROM miknatis_kontroller
        WHERE DATE(kontrol_zamani) = CURDATE()
        GROUP BY makina_kodu
    ")->fetchAll(PDO::FETCH_ASSOC) as $r)
        $istat_map[$r['makina_kodu']] = $r;
} catch (Throwable $e) {}

// ── Son kayıt ────────────────────────────────────────────────
$son_map = [];
try {
    foreach ($db->query("
        SELECT mk.makina_kodu, mk.durum, mk.m1, mk.m2, mk.m3, mk.urun_kodu,
               DATE_FORMAT(mk.kontrol_zamani,'%H:%i:%s') AS saat,
               mk.aciklama, mk.kontrol_zamani,
               TIMESTAMPDIFF(SECOND, mk.kontrol_zamani, NOW()) AS gecen_sn
        FROM miknatis_kontroller mk
        INNER JOIN (
            SELECT makina_kodu, MAX(id) AS max_id
            FROM miknatis_kontroller GROUP BY makina_kodu
        ) t ON mk.makina_kodu=t.makina_kodu AND mk.id=t.max_id
    ")->fetchAll(PDO::FETCH_ASSOC) as $r)
        $son_map[$r['makina_kodu']] = $r;
} catch (Throwable $e) {}

// ── Yardımcılar ───────────────────────────────────────────────
function oled_mesaj(string $durum, ?string $aciklama): array {
    switch ($durum) {
        case 'basarili':   return ['TAMAM!', 'Parça alınabilir', 'Solenoid: AÇIK', '#22C55E'];
        case 'duzeltildi': return ['DÜZELTİLDİ!', 'Parça alınabilir', 'Solenoid: AÇIK', '#A855F7'];
        case 'hata_1':
        case 'hata_2':
        case 'hata_3':
            $eks = $aciklama ? str_replace('Eksik: ', '', $aciklama) : '?';
            return ['MIKNATIS EKSIK!', 'Eksik: ' . $eks, '3sn tekrar kontrol', '#EF4444'];
        default:           return ['Hazır', 'Ürün bekleniyor', '', '#22C55E'];
    }
}
?>
<style>
/* Makina kartı özel stilleri */
@keyframes blink-g {
  0%,100%{opacity:1;box-shadow:0 0 5px #22C55E}
  50%{opacity:.35;box-shadow:none}
}
.mkart {
    background: var(--yuzey);
    border: 1px solid var(--kenar);
    border-radius: 12px;
    overflow: hidden;
    transition: box-shadow .2s;
}
.mkart:hover { box-shadow: 0 4px 20px rgba(0,0,0,.08); }

/* OLED ekran */
.oled-ekran {
    background: #0a0f1a;
    border-radius: 6px;
    border: 2px solid #1E3A5F;
    padding: 8px 10px;
    font-family: monospace;
    font-size: 11px;
    color: #22C55E;
    line-height: 1.7;
    min-height: 72px;
}
.oled-baslik { color: #F97316; font-weight: 700; font-size: 10px; border-bottom: 1px solid #1E293B; padding-bottom: 4px; margin-bottom: 4px; }

/* Fikstür gövde */
.fikstur-govde {
    background: #F8FAFC;
    border: 2px solid #CBD5E1;
    border-radius: 8px;
    padding: 10px;
    position: relative;
}
.fikstur-govde.durum-tamam  { border-color: #22C55E; background: #F0FDF4; }
.fikstur-govde.durum-hata   { border-color: #EF4444; background: #FEF2F2; }
.fikstur-govde.durum-bekle  { border-color: #CBD5E1; }

/* Solenoid kilit */
.solenoid-kilit {
    width: 28px;
    height: 44px;
    border-radius: 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    font-size: 14px;
    font-weight: 800;
    border: 2px solid;
    transition: all .3s;
}
.solenoid-acik   { background: #D1FAE5; border-color: #22C55E; color: #065F46; }
.solenoid-kapali { background: #FEE2E2; border-color: #EF4444; color: #7F1D1D; }

/* LED göstergeler */
.led-nokta {
    width: 14px; height: 14px;
    border-radius: 50%;
    display: inline-block;
    border: 2px solid rgba(0,0,0,.1);
}
.led-yesil  { background: #22C55E; box-shadow: 0 0 6px #22C55E66; }
.led-sari   { background: #F59E0B; box-shadow: 0 0 6px #F59E0B66; }
.led-kirmizi{ background: #EF4444; box-shadow: 0 0 6px #EF444466; }
.led-pasif  { background: #E2E8F0; box-shadow: none; }

/* Mıknatıs daire */
.mik-daire {
    width: 36px; height: 36px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px;
    border: 2px solid;
    transition: all .3s;
    font-weight: 800;
}
.mik-var  { background: #D1FAE5; border-color: #22C55E; color: #065F46; }
.mik-yok  { background: #FEE2E2; border-color: #EF4444; color: #7F1D1D; }
.mik-bekle{ background: #F1F5F9; border-color: #94A3B8; color: #94A3B8; }

@media(max-width:480px){
  .mkart-grid { grid-template-columns: 1fr !important; }
}
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🧲 Mıknatıs Test Cihazları</h1>
    <div class="s-yol">Kalite / <b>Tekmelik Test Cihazları</b></div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-monitor" class="btn btn-t btn-sm">📡 Canlı İzleme</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-sonuclar" class="btn btn-b btn-sm">📋 Sonuçlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-sema" class="btn btn-b btn-sm">📐 Şema</a>
  </div>
</div>

<div class="s-body">

<?php if (!empty($_GET['ok'])): ?>
<div style="background:#D1FAE5;color:#065F46;border-radius:var(--r);padding:10px 16px;margin-bottom:14px;font-weight:700">
  ✅ Ürün kodu güncellendi.
</div>
<?php endif; ?>

<!-- Kurulum Rehberi -->
<details style="margin-bottom:16px">
  <summary style="background:#1E3A5F;color:#fff;padding:10px 18px;border-radius:var(--r);cursor:pointer;font-weight:700;font-size:13px;list-style:none">
    📋 ESP32 Kurulum Rehberi
  </summary>
  <div class="kart" style="margin-top:0;border-radius:0 0 var(--r) var(--r)">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;font-size:12px">
      <div style="background:#F0FDF4;border-radius:8px;padding:12px;border-left:4px solid #22C55E">
        <b style="color:#065F46">① Arduino IDE + ESP32 Kart</b>
        <ol style="padding-left:14px;margin-top:6px;line-height:2">
          <li>Arduino IDE 2.x indir</li>
          <li>Tercihler → Ek Kart URL ekle (espressif)</li>
          <li>Kart Yöneticisi → esp32 kur</li>
        </ol>
      </div>
      <div style="background:#EFF6FF;border-radius:8px;padding:12px;border-left:4px solid #2563EB">
        <b style="color:#1D4ED8">② Kütüphaneler</b>
        <ul style="padding-left:14px;margin-top:6px;line-height:2">
          <li>Adafruit SSD1306 + GFX Library</li>
          <li>RTClib (Adafruit)</li>
          <li>ArduinoJson v6.x</li>
        </ul>
      </div>
      <div style="background:#FEF9C3;border-radius:8px;padding:12px;border-left:4px solid #D97706">
        <b style="color:#78350F">③ Kart Ayarları</b>
        <ul style="padding-left:14px;margin-top:6px;line-height:2">
          <li>Araçlar → ESP32 Dev Module</li>
          <li>Upload Speed: 115200</li>
          <li>Partition: Default 4MB</li>
        </ul>
      </div>
      <div style="background:#FDF4FF;border-radius:8px;padding:12px;border-left:4px solid #A855F7">
        <b style="color:#6B21A8">④ .ino Yükle</b>
        <ol style="padding-left:14px;margin-top:6px;line-height:2">
          <li>Karttan ⬇ .ino indir</li>
          <li><code>API_BASE</code> → sunucu IP gir</li>
          <li>ESP32 USB bağla → ▶ Yükle</li>
          <li>Seri monitör 115200 baud</li>
        </ol>
      </div>
      <div style="background:#FFF1F2;border-radius:8px;padding:12px;border-left:4px solid #F43F5E">
        <b style="color:#9F1239">⑤ Pin Bağlantısı</b>
        <table style="width:100%;font-size:11px;margin-top:6px">
          <tr><td><code>34</code></td><td>SN04-N Yakınlık</td></tr>
          <tr><td><code>35/32/33</code></td><td>US1881 Hall M1/M2/M3</td></tr>
          <tr><td><code>27/13</code></td><td>Röle → Solenoid 1/2</td></tr>
          <tr><td><code>25/26/14</code></td><td>LED Yeşil/Sarı/Kırmızı</td></tr>
          <tr><td><code>4</code></td><td>Buzzer</td></tr>
          <tr><td><code>21/22</code></td><td>SDA/SCL (OLED + RTC)</td></tr>
          <tr><td><code>17/16</code></td><td>TX/RX Zebra Yazıcı</td></tr>
        </table>
      </div>
      <div style="background:#F0FDF4;border-radius:8px;padding:12px;border-left:4px solid #14B8A6">
        <b style="color:#0F766E">⑥ Ürün Kodu</b>
        <p style="margin-top:6px;line-height:1.7">Sayfadaki <b>Tanımla</b> formundan gir → DB'ye kaydedilir → ESP32 otomatik çeker (30 sn).<br>Manuel: Seri monitörde <code>KOD:TKM-001</code></p>
      </div>
    </div>
  </div>
</details>

<!-- ── Cihaz Kartları ─────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:18px" class="mkart-grid">

<?php foreach ($cihazlar as $kod => $cihaz):
    $tanim  = $tanim_map[$kod] ?? null;
    $istat  = $istat_map[$kod] ?? null;
    $son    = $son_map[$kod]   ?? null;
    $aktif  = $tanim ? (int)$tanim['aktif'] : 0;
    $urun   = $tanim['urun_kodu'] ?? '—';
    $oran   = $istat ? (float)$istat['oran'] : null;

    $son_durum = $son['durum'] ?? 'bekle';
    // Online/Offline: canli_durum tmp dosyasından oku (DB'den değil)
    $canli_dosya = dirname(dirname(__DIR__)) . '/uploads/miknatis/miknatis_' . $kod . '.json';
    $canli_veri  = null;
    if (file_exists($canli_dosya)) {
        $canli_veri = json_decode(file_get_contents($canli_dosya), true);
    }
    $canli_gecen = $canli_veri ? (time() - ($canli_veri['ts'] ?? 0)) : PHP_INT_MAX;
    $online      = ($canli_gecen <= 600); // 10 dk içinde ping/kayıt geldiyse online
    $canli_ip    = $canli_veri['ip'] ?? '';
    if ($canli_gecen < 60)         $son_gorulme = $canli_gecen . ' sn';
    elseif ($canli_gecen < 3600)   $son_gorulme = floor($canli_gecen/60) . ' dk';
    elseif ($canli_gecen < 86400)  $son_gorulme = floor($canli_gecen/3600) . ' sa';
    elseif ($canli_veri)           $son_gorulme = date('H:i', $canli_veri['ts']);
    else $son_gorulme = '';
    $sol_acik  = in_array($son_durum, ['basarili','duzeltildi']) || !$son;
    $fikstur_cls = $son
        ? (in_array($son_durum,['basarili','duzeltildi']) ? 'durum-tamam'
          : (str_starts_with($son_durum,'hata') ? 'durum-hata' : 'durum-bekle'))
        : 'durum-bekle';

    // LED durumları
    $led_yesil  = in_array($son_durum, ['basarili','duzeltildi']) ? 'led-yesil' : 'led-pasif';
    $led_sari   = $son_durum === 'bekle' || !$son ? 'led-sari' : 'led-pasif';
    $led_kirmizi= $son && str_starts_with($son_durum,'hata') ? 'led-kirmizi' : 'led-pasif';

    // OLED
    [$oled1,$oled2,$oled3,$oled_renk] = oled_mesaj($son_durum, $son['aciklama'] ?? null);

    // Üst bordür rengi
    $bordur = $aktif
        ? ($oran !== null ? ($oran >= 95 ? '#22C55E' : ($oran >= 80 ? '#D97706' : '#DC2626')) : '#94A3B8')
        : '#E2E8F0';
?>
<div class="mkart" style="border-top:4px solid <?= $bordur ?>" id="kart_<?= $kod ?>">

  <!-- ── KART BAŞLIĞI ── -->
  <div style="padding:12px 14px 0;display:flex;justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-size:16px;font-weight:800;color:var(--t);display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <?= $kod ?>
        <span id="ag_<?= $kod ?>" style="font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;
                     background:<?= $online?'#D1FAE5':'#FEE2E2' ?>;
                     color:<?= $online?'#065F46':'#991B1B' ?>;
                     display:inline-flex;align-items:center;gap:4px">
          <span id="ag_led_<?= $kod ?>" style="width:7px;height:7px;border-radius:50%;display:inline-block;flex-shrink:0;
                       background:<?= $online?'#22C55E':'#EF4444' ?>;
                       <?= $online?'animation:blink-g 1.5s ease-in-out infinite':'' ?>"></span>
          <span id="ag_txt_<?= $kod ?>"><?= $online ? 'Online'.($canli_ip?' '.$canli_ip:'') : 'Offline' ?></span>
        </span>
      </div>
      <div style="font-size:12px;color:var(--m);margin-top:2px"><?= htmlspecialchars($cihaz['ad']) ?></div>
      <div style="font-size:11px;color:var(--m2)">📍 <?= htmlspecialchars($cihaz['konum']) ?></div>
      <?php if (!empty($son_gorulme)): ?>
      <div style="font-size:10px;color:var(--m3);margin-top:1px" id="ag_sure_<?= $kod ?>">
        Son: <?= $son_gorulme ?> önce
      </div>
      <?php endif; ?>
    </div>
    <a href="<?= BASE_URL ?>/bolumler/kalite/ino_indir.php?kod=<?= $kod ?>"
       title="<?= $kod ?> .ino indir"
       style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:6px;padding:4px 8px;
              font-size:11px;color:#475569;text-decoration:none;display:flex;align-items:center;gap:4px;white-space:nowrap">
      ⬇ .ino
    </a>
  </div>

  <!-- ── MAKİNA GÖRSEL ALANI ── -->
  <div style="padding:12px 14px">

    <div style="display:flex;gap:10px;align-items:stretch">

      <!-- Sol solenoid kilidi -->
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px" id="sol_sol_<?= $kod ?>">
        <div class="solenoid-kilit <?= $sol_acik ? 'solenoid-acik' : 'solenoid-kapali' ?>" id="sol1_<?= $kod ?>">
          <span style="font-size:16px"><?= $sol_acik ? '🔓' : '🔒' ?></span>
          <span style="font-size:8px;font-weight:700"><?= $sol_acik ? 'AÇK' : 'KLT' ?></span>
        </div>
        <div style="font-size:9px;color:var(--m2);font-weight:700">SOL1</div>
      </div>

      <!-- Fikstür gövde — orta -->
      <div class="fikstur-govde <?= $fikstur_cls ?>" style="flex:1;min-height:100px" id="fikstur_<?= $kod ?>">

        <!-- Ürün kodu + durum etiketi -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <code style="background:rgba(0,0,0,.06);padding:2px 7px;border-radius:4px;font-size:11px;font-weight:800">
            <?= htmlspecialchars($urun) ?>
          </code>
          <?php if ($son):
            $de_map = [
              'basarili'   => ['#065F46','#D1FAE5','✓ Tamam'],
              'duzeltildi' => ['#5B21B6','#EDE9FE','✔ Düzeltildi'],
              'hata_1'     => ['#92400E','#FEF9C3','⚠ 1 Eksik'],
              'hata_2'     => ['#991B1B','#FEE2E2','✗ 2 Eksik'],
              'hata_3'     => ['#7F1D1D','#FCA5A5','✗✗ 3 Eksik'],
            ];
            $de = $de_map[$son_durum] ?? ['#475569','#F1F5F9','—'];
          ?>
          <span style="background:<?= $de[1] ?>;color:<?= $de[0] ?>;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:800">
            <?= $de[2] ?> <span style="opacity:.7;font-weight:400"><?= $son['saat'] ?></span>
          </span>
          <?php endif; ?>
        </div>

        <!-- TEKMELİK + M1 M2 M3 -->
        <div style="display:flex;align-items:center;gap:8px;justify-content:center;margin-bottom:6px">
          <div style="font-size:10px;font-weight:800;color:var(--m2);letter-spacing:.05em;writing-mode:horizontal-tb">
            TEKMELİK
          </div>
          <?php for ($m=1;$m<=3;$m++):
            if ($son) {
              $mv = (int)$son['m'.$m];
              $mcls = $mv ? 'mik-var' : 'mik-yok';
              $mico = $mv ? 'M' : '✗';
            } else {
              $mcls = 'mik-bekle'; $mico = 'M';
            }
          ?>
          <div style="text-align:center" id="mik_<?= $kod ?>_<?= $m ?>_wrap">
            <div class="mik-daire <?= $mcls ?>" id="mik_<?= $kod ?>_<?= $m ?>"><?= $mico ?><?= $m ?></div>
          </div>
          <?php endfor; ?>
        </div>

        <!-- Ürün varlık sensörü -->
        <div style="display:flex;justify-content:center">
          <span style="font-size:10px;color:var(--m2)">
            Ürün sensörü:
            <span style="font-weight:700;color:<?= $son ? '#22C55E' : '#94A3B8' ?>">
              <?= $son ? '● Aktif' : '○ Yok' ?>
            </span>
          </span>
        </div>
      </div>

      <!-- Sağ: Solenoid 2 + LED + ESP32 mini -->
      <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
        <!-- Solenoid 2 -->
        <div class="solenoid-kilit <?= $sol_acik ? 'solenoid-acik' : 'solenoid-kapali' ?>" id="sol2_<?= $kod ?>">
          <span style="font-size:16px"><?= $sol_acik ? '🔓' : '🔒' ?></span>
          <span style="font-size:8px;font-weight:700"><?= $sol_acik ? 'AÇK' : 'KLT' ?></span>
        </div>
        <div style="font-size:9px;color:var(--m2);font-weight:700">SOL2</div>

        <!-- LED trafik ışığı -->
        <div style="display:flex;flex-direction:column;gap:3px;align-items:center;margin-top:4px">
          <div class="led-nokta <?= $led_kirmizi ?>" id="led_k_<?= $kod ?>"></div>
          <div class="led-nokta <?= $led_sari  ?>" id="led_s_<?= $kod ?>"></div>
          <div class="led-nokta <?= $led_yesil ?>" id="led_y_<?= $kod ?>"></div>
        </div>
      </div>

    </div><!-- /flex fikstür satırı -->

    <!-- ── OLED Ekran ── -->
    <!-- OLED Ekran — 0.96" 128x64 simülasyonu -->
    <div class="oled-ekran" style="margin-top:10px;padding:8px 10px" id="oled_<?= $kod ?>">
      <!-- Satır 1: Cihaz | WiFi -->
      <div style="display:flex;justify-content:space-between;align-items:center;
                  border-bottom:1px solid #1E293B;padding-bottom:3px;margin-bottom:4px">
        <span style="color:#F97316;font-weight:700;font-size:10px"><?= $kod ?></span>
        <span id="oled_wifi_<?= $kod ?>" style="font-size:10px;font-weight:700;color:<?= $online?'#22C55E':'#EF4444' ?>">
          <?= $online ? '▲ WiFi' : '✗ WiFi' ?>
        </span>
      </div>
      <!-- Satır 2: Ürün kodu — kalın, büyük -->
      <div style="font-size:13px;font-weight:900;color:#fff;letter-spacing:.05em;margin-bottom:3px;
                  white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
           id="oled_urun_<?= $kod ?>"><?= htmlspecialchars($urun !== '—' ? $urun : '—') ?></div>
      <!-- Satır 3: Günlük sayaç -->
      <div style="display:flex;gap:10px;font-size:10px;color:#64748B;margin-bottom:3px">
        <span>OK: <b style="color:#22C55E"><?= (int)($istat['basarili'] ?? 0) ?></b></span>
        <span>Hata: <b style="color:#EF4444"><?= (int)($istat['hatali'] ?? 0) ?></b></span>
        <span>Toplam: <b style="color:#94A3B8" id="oled_top_<?= $kod ?>"><?= (int)($istat['toplam'] ?? 0) ?></b></span>
      </div>
      <!-- Satır 4: Durum -->
      <div style="font-size:11px;font-weight:700;color:<?= $oled_renk ?>" id="oled_s1_<?= $kod ?>"><?= $oled1 ?></div>
      <!-- Satır 5: Açıklama -->
      <div style="font-size:10px;color:#64748B" id="oled_s2_<?= $kod ?>"><?= $oled2 ?></div>
      <div style="font-size:9px;color:#475569" id="oled_s3_<?= $kod ?>"><?= $oled3 ?></div>
    </div>

    <!-- ── Alt: Yazıcı + ESP32 + Buzzer satırı ── -->
    <div style="display:flex;gap:8px;margin-top:10px;align-items:center">
      <!-- Yazıcı -->
      <div style="flex:1;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:5px 8px;text-align:center" id="yazici_<?= $kod ?>">
        <div style="font-size:9px;color:#94A3B8;font-weight:700">YAZICI</div>
        <div style="font-size:11px;font-weight:700;color:<?= (in_array($son_durum,['basarili','duzeltildi'])&&$son) ? '#A855F7' : '#CBD5E1' ?>">
          <?= (in_array($son_durum,['basarili','duzeltildi'])&&$son) ? '● ZPL' : '○ Bekle' ?>
        </div>
      </div>
      <!-- Buzzer -->
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:5px 8px;text-align:center">
        <div style="font-size:9px;color:#94A3B8;font-weight:700">BZR</div>
        <div style="font-size:11px" id="bzr_<?= $kod ?>">
          <?= ($son && str_starts_with($son_durum,'hata')) ? '🔊' : '🔇' ?>
        </div>
      </div>
      <!-- ESP32 WiFi -->
      <div id="esp_wifi_<?= $kod ?>" style="flex:1;border-radius:6px;padding:5px 8px;text-align:center;
           background:<?= $online?'#D1FAE5':'#F8FAFC' ?>;border:1px solid <?= $online?'#22C55E':'#E2E8F0' ?>">
        <div style="font-size:9px;font-weight:700;color:<?= $online?'#065F46':'#94A3B8' ?>">ESP32</div>
        <div id="esp_wifi_txt_<?= $kod ?>" style="font-size:9px;font-weight:800;color:<?= $online?'#22C55E':'#94A3B8' ?>">
          <?= $online ? '▲ Wi-Fi' : '○ Wi-Fi' ?>
        </div>
      </div>
      <!-- İstatistik -->
      <?php if ($istat): ?>
      <div style="flex:1;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;padding:5px 8px;text-align:center">
        <div style="font-size:9px;color:#94A3B8;font-weight:700">BUGÜN</div>
        <div style="font-size:11px;font-weight:800;color:<?= $oran >= 95 ? '#22C55E' : ($oran >= 80 ? '#D97706' : '#EF4444') ?>">
          <?= $oran ?>%
        </div>
      </div>
      <?php endif; ?>
    </div>

  </div><!-- /padding alan -->

  <!-- ── KART ALT: Tanımla + Linkler ── -->
  <div style="border-top:1px solid var(--kenar);padding:10px 14px;display:flex;flex-direction:column;gap:8px">

    <details id="details_<?= $kod ?>">
      <summary style="font-size:12px;font-weight:700;color:var(--t);cursor:pointer">
        ✏️ Ürün Kodu Tanımla / Güncelle
      </summary>

      <!-- Mevcut ürün göster -->
      <?php if ($urun !== '—'): ?>
      <div style="margin-top:8px;background:#FEF9C3;border-radius:6px;padding:8px 10px;font-size:12px;border-left:3px solid #D97706">
        <span style="color:#92400E;font-weight:700">Mevcut:</span>
        <code style="margin-left:6px;background:#FEF3C7;padding:2px 7px;border-radius:4px;font-weight:800;color:#78350F"><?= htmlspecialchars($urun) ?></code>
        <?php if (isset($urun_listesi[$urun])): ?>
        <div style="font-size:11px;color:#92400E;margin-top:3px"><?= htmlspecialchars($urun_listesi[$urun]) ?></div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <!-- AŞAMA 1: Seçim -->
      <div id="asama1_<?= $kod ?>" style="margin-top:10px">
        <div style="font-size:11px;color:var(--m2);margin-bottom:6px;font-weight:700">Yeni ürün seçin:</div>
        <div style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap">
          <div style="flex:1;min-width:180px">
            <select id="secim_<?= $kod ?>" class="form-alan" style="font-size:12px;padding:6px 10px;width:100%">
              <option value="">— Seçiniz —</option>
              <?php foreach ($urun_listesi as $uk => $ua): ?>
              <option value="<?= $uk ?>" <?= ($urun === $uk) ? 'selected' : '' ?>
                      data-ad="<?= htmlspecialchars($ua) ?>">
                <?= $uk ?> — <?= htmlspecialchars(mb_strimwidth($ua, 0, 35, '...')) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="form-et" style="font-size:10px">Durum</label>
            <select id="aktif_<?= $kod ?>" class="form-alan" style="font-size:12px;padding:6px 10px">
              <option value="1" <?= $aktif?'selected':'' ?>>Aktif</option>
              <option value="0" <?= !$aktif?'selected':'' ?>>Pasif</option>
            </select>
          </div>
          <button type="button" class="btn btn-t btn-sm"
                  onclick="asama2Goster('<?= $kod ?>', '<?= htmlspecialchars($urun, ENT_QUOTES) ?>')">
            Devam →
          </button>
        </div>
      </div>

    </details>

    <!-- AŞAMA 2: Onay — details DIŞINDA -->
    <div id="asama2_<?= $kod ?>" style="display:none;background:#FEE2E2;border-radius:8px;padding:12px;border:2px solid #EF4444;margin-top:4px">
      <div style="font-weight:800;font-size:13px;color:#7F1D1D;margin-bottom:8px">⚠️ Ürün kodu değiştiriliyor!</div>
      <div style="font-size:12px;color:#991B1B;margin-bottom:10px">
        <div>Eskisi: <code id="onay_eski_<?= $kod ?>" style="background:#FCA5A5;padding:1px 6px;border-radius:3px;font-weight:800"></code></div>
        <div style="margin-top:4px">Yenisi: <code id="onay_yeni_<?= $kod ?>" style="background:#FEE2E2;padding:1px 6px;border-radius:3px;font-weight:800"></code></div>
        <div id="onay_yeni_ad_<?= $kod ?>" style="margin-top:3px;font-size:11px;color:#7F1D1D"></div>
      </div>
      <input type="hidden" id="form_urun_<?= $kod ?>">
      <input type="hidden" id="form_aktif_<?= $kod ?>">
      <div style="display:flex;gap:8px">
        <button type="button" class="btn btn-sm"
                style="background:#DC2626;color:#fff;border:none;font-weight:800"
                onclick="urunKaydet('<?= $kod ?>')">
          ✓ Evet, Değiştir
        </button>
        <button type="button" class="btn btn-b btn-sm"
                onclick="asama2Iptal('<?= $kod ?>')">
          ✕ İptal
        </button>
      </div>
    </div>

    <div style="display:flex;gap:6px">
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-monitor&cihaz=<?= $kod ?>"
         class="btn btn-sm" style="flex:1;text-align:center;background:var(--t-a);color:var(--t);text-decoration:none;font-size:11px">
        📡 Canlı İzle
      </a>
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-sonuclar&makina=<?= $kod ?>"
         class="btn btn-sm btn-b" style="flex:1;text-align:center;text-decoration:none;font-size:11px">
        📋 Sonuçlar
      </a>
    </div>
  </div>

</div><!-- /mkart -->
<?php endforeach; ?>
</div><!-- /grid -->
</div><!-- /s-body -->

<script>
(function(){
    // OLED mesaj hesapla
    function oledMesaj(durum, aciklama) {
        if (durum==='basarili')   return {s1:'TAMAM!', s2:'Parça alınabilir', s3:'Solenoid: AÇIK', renk:'#22C55E'};
        if (durum==='duzeltildi') return {s1:'DÜZELTİLDİ!', s2:'Parça alınabilir', s3:'Solenoid: AÇIK', renk:'#A855F7'};
        if (durum && durum.startsWith('hata')) {
            var eks = aciklama ? aciklama.replace('Eksik: ','') : '?';
            return {s1:'MIKNATIS EKSİK!', s2:'Eksik: '+eks, s3:'3sn tekrar kontrol', renk:'#EF4444'};
        }
        return {s1:'Hazır', s2:'Ürün bekleniyor', s3:'', renk:'#22C55E'};
    }

    async function yenile() {
        try {
            var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/miknatis_ajax.php?action=tum_cihazlar');
            var d = await r.json();
            if (!d.ok || !d.cihazlar) return;

            d.cihazlar.forEach(function(c) {
                var kod = c.makina_kodu;
                var durum = c.durum || '';
                var solAcik = (durum==='basarili'||durum==='duzeltildi'||!durum);
                var hata = durum.startsWith('hata');

                // Solenoid ikonlar
                [1,2].forEach(function(n){
                    var el = document.getElementById('sol'+n+'_'+kod);
                    if (!el) return;
                    el.className = 'solenoid-kilit ' + (solAcik ? 'solenoid-acik' : 'solenoid-kapali');
                    el.querySelector('span:first-child').textContent = solAcik ? '🔓' : '🔒';
                    el.querySelector('span:last-child').textContent  = solAcik ? 'AÇK' : 'KLT';
                });

                // Fikstür border
                var fk = document.getElementById('fikstur_'+kod);
                if (fk) {
                    fk.className = 'fikstur-govde ' +
                        (solAcik&&durum?'durum-tamam':(hata?'durum-hata':'durum-bekle'));
                }

                // Mıknatıs daireler
                [1,2,3].forEach(function(m){
                    var el = document.getElementById('mik_'+kod+'_'+m);
                    if (!el) return;
                    var v = c['m'+m]==1;
                    el.className = 'mik-daire ' + (v?'mik-var':'mik-yok');
                    el.textContent = (v?'M':'✗') + m;
                });

                // LED'ler
                var ky = document.getElementById('led_y_'+kod);
                var ks = document.getElementById('led_s_'+kod);
                var kk = document.getElementById('led_k_'+kod);
                if(ky) ky.className='led-nokta '+(solAcik&&durum?'led-yesil':'led-pasif');
                if(ks) ks.className='led-nokta '+(!durum?'led-sari':'led-pasif');
                if(kk) kk.className='led-nokta '+(hata?'led-kirmizi':'led-pasif');

                // OLED
                var om = oledMesaj(durum, c.aciklama);
                var s1 = document.getElementById('oled_s1_'+kod);
                var s2 = document.getElementById('oled_s2_'+kod);
                var s3 = document.getElementById('oled_s3_'+kod);
                if(s1){s1.textContent=om.s1; s1.style.color=om.renk;}
                if(s2) s2.textContent=om.s2;
                if(s3) s3.textContent=om.s3;

                // Yazıcı
                var yz = document.getElementById('yazici_'+kod);
                if(yz){
                    yz.querySelector('div:last-child').style.color = solAcik&&durum?'#A855F7':'#CBD5E1';
                    yz.querySelector('div:last-child').textContent = solAcik&&durum?'● ZPL':'○ Bekle';
                }

                // Buzzer
                var bz = document.getElementById('bzr_'+kod);
                if(bz) bz.textContent = hata?'🔊':'🔇';

                // Online/Offline — canli_durum tmp dosyasından (1sn polling)
                var gsn = parseInt(c.gecen_sn) || 9999;
                var online = (gsn <= 30);  // 30 sn içindeyse online

                // OLED WiFi satırı
                var owEl = document.getElementById('oled_wifi_' + kod);
                if (owEl) {
                    owEl.style.color = online ? '#22C55E' : '#EF4444';
                    owEl.textContent = online ? '▲ WiFi' : '✗ WiFi';
                }

                // ESP32 Wi-Fi kutusu
                var ewEl  = document.getElementById('esp_wifi_' + kod);
                var ewtEl = document.getElementById('esp_wifi_txt_' + kod);
                if (ewEl) {
                    ewEl.style.background  = online ? '#D1FAE5' : '#F8FAFC';
                    ewEl.style.borderColor = online ? '#22C55E' : '#E2E8F0';
                    var ewLbl = ewEl.querySelector('div:first-child');
                    if (ewLbl) ewLbl.style.color = online ? '#065F46' : '#94A3B8';
                }
                if (ewtEl) {
                    ewtEl.style.color = online ? '#22C55E' : '#94A3B8';
                    ewtEl.textContent = online ? '▲ Wi-Fi' : '○ Wi-Fi';
                }

                var agEl = document.getElementById('ag_' + kod);
                if (agEl) {
                    agEl.style.background = online ? '#D1FAE5' : '#FEE2E2';
                    agEl.style.color      = online ? '#065F46' : '#991B1B';
                }
                var ledEl2 = document.getElementById('ag_led_' + kod);
                if (ledEl2) {
                    ledEl2.style.background = online ? '#22C55E' : '#EF4444';
                    ledEl2.style.animation  = online ? 'blink-g 1.5s ease-in-out infinite' : '';
                }
                var txtEl2 = document.getElementById('ag_txt_' + kod);
                if (txtEl2) {
                    var ipStr = (online && c.ip) ? ' ' + c.ip : '';
                    txtEl2.textContent = (online ? 'Online' : 'Offline') + ipStr;
                }
                var sureEl = document.getElementById('ag_sure_' + kod);
                if (sureEl) {
                    var gs = gsn < 9999 ? (gsn<60?gsn+'sn':gsn<3600?Math.floor(gsn/60)+'dk':Math.floor(gsn/3600)+'sa') : '?';
                    sureEl.textContent = 'Son: ' + gs + ' önce';
                    sureEl.style.display = gsn<9999 ? '' : 'none';
                }
            });
        } catch(e){}
    }

    // Polling kaldırıldı — sayfa yenileme yeterli
})();

// ── Online/Offline — 10 dk'da bir, sayfa açılışında hemen çalışır ──
(function(){
    var URL = '<?= BASE_URL ?>/bolumler/kalite/api/miknatis_online.php';

    function guncelle() {
        fetch(URL + '?_t=' + Date.now())
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.ok) return;
            Object.keys(d.cihazlar).forEach(function(kod){
                var c      = d.cihazlar[kod];
                var online = c.online === true;
                var ip     = c.ip || '';

                // Rozet
                var ag = document.getElementById('ag_' + kod);
                if (ag) {
                    ag.style.background = online ? '#D1FAE5' : '#FEE2E2';
                    ag.style.color      = online ? '#065F46' : '#991B1B';
                }
                var led = document.getElementById('ag_led_' + kod);
                if (led) {
                    led.style.background = online ? '#22C55E' : '#EF4444';
                    led.style.animation  = online ? 'blink-g 1.5s ease-in-out infinite' : 'none';
                }
                var txt = document.getElementById('ag_txt_' + kod);
                if (txt) {
                    txt.textContent = (online ? 'Online' : 'Offline') + (online && ip ? ' ' + ip : '');
                }

                // OLED WiFi
                var ow = document.getElementById('oled_wifi_' + kod);
                if (ow) { ow.textContent = online ? '▲ WiFi' : '✗ WiFi'; ow.style.color = online ? '#22C55E' : '#EF4444'; }

                // ESP32 kutu
                var ew  = document.getElementById('esp_wifi_' + kod);
                var ewt = document.getElementById('esp_wifi_txt_' + kod);
                if (ew) {
                    ew.style.background  = online ? '#D1FAE5' : '#F8FAFC';
                    ew.style.borderColor = online ? '#22C55E' : '#E2E8F0';
                    var lbl = ew.querySelector('div');
                    if (lbl) lbl.style.color = online ? '#065F46' : '#94A3B8';
                }
                if (ewt) { ewt.style.color = online ? '#22C55E' : '#94A3B8'; ewt.textContent = online ? '▲ Wi-Fi' : '○ Wi-Fi'; }
            });
        })
        .catch(function(){});
    }

    guncelle();                          // sayfa açılışında hemen
    setInterval(guncelle, 600000);       // 10 dk'da bir
})();


// ── 2 Aşamalı Onay ───────────────────────────────────────────
function asama2Goster(kod, eskiUrun) {
    var sel   = document.getElementById('secim_' + kod);
    var aktif = document.getElementById('aktif_' + kod);

    console.log('[asama2Goster] kod=' + kod + ' secim=' + (sel ? sel.value : 'YOK'));

    if (!sel || !sel.value) {
        alert('Lütfen bir ürün seçin.');
        return;
    }

    var yeniKod = sel.value;
    var yeniAd  = sel.options[sel.selectedIndex].getAttribute('data-ad') || '';

    // Onay elementlerini doldur
    var eskiEl = document.getElementById('onay_eski_' + kod);
    var yeniEl = document.getElementById('onay_yeni_' + kod);
    var adEl   = document.getElementById('onay_yeni_ad_' + kod);
    var urunEl = document.getElementById('form_urun_' + kod);
    var aktifEl= document.getElementById('form_aktif_' + kod);

    console.log('[asama2Goster] elementler:', eskiEl, yeniEl, urunEl);

    if (!eskiEl || !yeniEl || !urunEl) {
        alert('Sayfa hatası — lütfen sayfayı yenileyin.');
        return;
    }

    eskiEl.textContent  = eskiUrun || '— (tanımsız)';
    yeniEl.textContent  = yeniKod;
    if (adEl) adEl.textContent = yeniAd;
    urunEl.value  = yeniKod;
    if (aktifEl) aktifEl.value = aktif ? aktif.value : '1';

    // details'i zorla aç (asama1 içinde)
    var det = document.getElementById('details_' + kod);
    if (det) det.open = true;

    // asama1 gizle (details içinde)
    var a1 = document.getElementById('asama1_' + kod);
    if (a1) a1.style.display = 'none';

    // asama2 göster (details dışında)
    var a2 = document.getElementById('asama2_' + kod);
    if (a2) {
        a2.style.display = 'block';
        a2.scrollIntoView({behavior: 'smooth', block: 'nearest'});
    }
}

function asama2Iptal(kod) {
    document.getElementById('asama1_' + kod).style.display = 'block';
    document.getElementById('asama2_' + kod).style.display = 'none';
}

async function urunKaydet(kod) {
    var urunEl  = document.getElementById('form_urun_' + kod);
    var aktifEl = document.getElementById('form_aktif_' + kod);
    console.log('[urunKaydet] kod='+kod+' urun='+(urunEl?urunEl.value:'YOK'));
    if (!urunEl || !urunEl.value) { alert('Ürün kodu seçilmedi!'); return; }

    var btn = event.target;
    btn.disabled = true;
    btn.textContent = '⏳ Kaydediliyor...';

    var fd = new FormData();
    fd.append('makina_kodu', kod);
    fd.append('urun_kodu',   urunEl.value);
    fd.append('aktif',       aktifEl ? aktifEl.value : '1');

    try {
        var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/miknatis_urun_kaydet.php', {
            method: 'POST',
            headers: {'X-Requested-With': 'XMLHttpRequest'},
            body: fd
        });
        var d = await r.json();
        console.log('[urunKaydet] yanit=', d);
        if (d.ok) {
            btn.style.background = '#059669';
            btn.textContent = '✓ Kaydedildi!';
            setTimeout(function(){ location.reload(); }, 800);
        } else {
            btn.disabled = false;
            btn.textContent = '✓ Evet, Değiştir';
            btn.style.background = '#DC2626';
            alert('Hata: ' + (d.hata || 'Bilinmeyen hata'));
        }
    } catch(e) {
        console.error('[urunKaydet] hata:', e);
        btn.disabled = false;
        btn.textContent = '✓ Evet, Değiştir';
        alert('Bağlantı hatası: ' + e.message);
    }
}
</script>
