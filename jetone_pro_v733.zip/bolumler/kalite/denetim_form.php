<?php
/**
 * Denetim Oluştur / Düzenle
 * panel.php: 'kalite-denetim-form' => 'bolumler/kalite/denetim_form.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id   = (int)($_GET['id'] ?? 0);
$den  = $id ? $db->prepare("SELECT * FROM kal_denetim WHERE id=?")->execute([$id]) && null : null;
if ($id) {
    $stmt = $db->prepare("SELECT * FROM kal_denetim WHERE id=?");
    $stmt->execute([$id]);
    $den = $stmt->fetch(PDO::FETCH_ASSOC);
}

$mesaj = ''; $mesaj_tip = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Otomatik kod oluştur
    $kod = trim($_POST['denetim_kodu'] ?? '');
    if (!$kod) {
        $yil = date('Y');
        $son = $db->query("SELECT denetim_kodu FROM kal_denetim WHERE denetim_kodu LIKE 'DEN-{$yil}-%' ORDER BY id DESC LIMIT 1")->fetchColumn();
        $no  = $son ? (int)substr($son,-3)+1 : 1;
        $kod = sprintf('DEN-%d-%03d', $yil, $no);
    }
    try {
        if ($id) {
            $db->prepare("UPDATE kal_denetim SET denetim_kodu=?,denetim_turu=?,denetim_konusu=?,denetim_tarihi=?,denetci_adi=?,denetlenen_bolum=?,denetlenen_kisi=?,genel_durum=?,aciklama=? WHERE id=?")
               ->execute([$kod,$_POST['denetim_turu'],$_POST['denetim_konusu'],$_POST['denetim_tarihi'],$_POST['denetci_adi'],$_POST['denetlenen_bolum'],$_POST['denetlenen_kisi'],$_POST['genel_durum'],$_POST['aciklama']??'',$id]);
            $mesaj='Denetim güncellendi.'; $mesaj_tip='ok';
        } else {
            $db->prepare("INSERT INTO kal_denetim (denetim_kodu,denetim_turu,denetim_konusu,denetim_tarihi,denetci_adi,denetlenen_bolum,denetlenen_kisi,genel_durum,aciklama,olusturan) VALUES (?,?,?,?,?,?,?,?,?,?)")
               ->execute([$kod,$_POST['denetim_turu'],$_POST['denetim_konusu'],$_POST['denetim_tarihi'],$_POST['denetci_adi'],$_POST['denetlenen_bolum'],$_POST['denetlenen_kisi'],$_POST['genel_durum'],$_POST['aciklama']??'',$kul_adi]);
            $id = (int)$db->lastInsertId();
            $redirect_url = BASE_URL.'/panel.php?sayfa=kalite-denetim-detay&id='.$id;
            echo "<script>window.location.href=".json_encode($redirect_url).";</script>";
            exit;
        }
        $den = $db->prepare("SELECT * FROM kal_denetim WHERE id=?")->execute([$id]) ? $den : $den;
        $stmt2 = $db->prepare("SELECT * FROM kal_denetim WHERE id=?"); $stmt2->execute([$id]); $den=$stmt2->fetch(PDO::FETCH_ASSOC);
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}

$d = $den ?: ['denetim_kodu'=>'','denetim_turu'=>'ic_denetim','denetim_konusu'=>'','denetim_tarihi'=>date('Y-m-d'),'denetci_adi'=>$kul_adi,'denetlenen_bolum'=>'','denetlenen_kisi'=>'','genel_durum'=>'planlandi','aciklama'=>''];

$bolumler = ['Üretim','Kalite','Depo','Satın Alma','Satış','Planlama','İnsan Kaynakları','Bakım','Bilgi İşlem','Yönetim','Diğer'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?=$id?'✏️ Denetim Düzenle':'+ Yeni Denetim'?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim" style="color:var(--t)">Denetimler</a> / <b><?=$id?'Düzenle':'Yeni'?></b></div>
  </div>
  <?php if($id): ?>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim-detay&id=<?=$id?>" class="btn btn-b btn-sm">← Detay</a>
  <?php endif; ?>
</div>
<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<div style="max-width:760px">
<form method="POST">
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div style="font-weight:800;font-size:14px;margin-bottom:16px;color:var(--t)">📋 Genel Bilgiler</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

    <div>
      <label class="form-et">Denetim Kodu <span style="color:var(--m3);font-weight:400">(boş bırakılırsa otomatik)</span></label>
      <input name="denetim_kodu" class="form-alan" value="<?=htmlspecialchars($d['denetim_kodu'])?>" placeholder="DEN-2026-001" style="font-family:monospace">
    </div>
    <div>
      <label class="form-et">Denetim Türü</label>
      <select name="denetim_turu" class="form-alan">
        <?php foreach (['ic_denetim'=>'İç Denetim','tedarikci'=>'Tedarikçi Denetimi','iso_9001'=>'ISO 9001','musteri'=>'Müşteri Denetimi','proses'=>'Proses Denetimi','diger'=>'Diğer'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['denetim_turu']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-span-2">
      <label class="form-et">Denetim Konusu / Başlığı <span style="color:#EF4444">*</span></label>
      <input name="denetim_konusu" class="form-alan" required value="<?=htmlspecialchars($d['denetim_konusu'])?>" placeholder="Ör: Üretim Hattı ISO 9001:2015 Madde 8 Denetimi" style="width:100%">
    </div>

    <div>
      <label class="form-et">Denetim Tarihi <span style="color:#EF4444">*</span></label>
      <input type="date" name="denetim_tarihi" class="form-alan" required value="<?=htmlspecialchars($d['denetim_tarihi'])?>">
    </div>
    <div>
      <label class="form-et">Genel Durum</label>
      <select name="genel_durum" class="form-alan">
        <?php foreach (['planlandi'=>'Planlandı','devam_ediyor'=>'Devam Ediyor','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['genel_durum']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-et">Denetçi Adı</label>
      <input name="denetci_adi" class="form-alan" value="<?=htmlspecialchars($d['denetci_adi']??'')?>" placeholder="Denetimi yapan kişi">
    </div>
    <div>
      <label class="form-et">Denetlenen Kişi</label>
      <input name="denetlenen_kisi" class="form-alan" value="<?=htmlspecialchars($d['denetlenen_kisi']??'')?>" placeholder="Denetlenen sorumlu kişi">
    </div>

    <div>
      <label class="form-et">Denetlenen Bölüm</label>
      <select name="denetlenen_bolum" class="form-alan">
        <option value="">— Seçin —</option>
        <?php foreach ($bolumler as $b): ?><option <?=$d['denetlenen_bolum']===$b?'selected':''?>><?=$b?></option><?php endforeach; ?>
      </select>
    </div>

    <div class="col-span-2">
      <label class="form-et">Genel Açıklama / Kapsam</label>
      <textarea name="aciklama" class="form-alan" rows="3" style="width:100%;resize:vertical"><?=htmlspecialchars($d['aciklama']??'')?></textarea>
    </div>
  </div>
</div>

<div style="display:flex;gap:8px;justify-content:flex-end">
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim" class="btn btn-b">İptal</a>
  <button type="submit" class="btn btn-t">💾 <?=$id?'Güncelle':'Denetim Oluştur'?></button>
</div>
</form>
</div>
</div>
<style>.col-span-2{grid-column:span 2}</style>
