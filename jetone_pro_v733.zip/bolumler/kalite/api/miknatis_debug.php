<?php
/**
 * DEBUG endpoint - tarayıcıdan aç:
 * http://localhost:4459/jetone_pro/bolumler/kalite/api/miknatis_debug.php
 */
header('Content-Type: text/plain; charset=utf-8');

$root    = dirname(__FILE__, 4);
$tmp_dir = $root . '/uploads/miknatis';

echo "=== MIKNATIS DEBUG ===\n\n";
echo "ROOT: $root\n";
echo "TMP_DIR: $tmp_dir\n";
echo "TMP_DIR EXIST: " . (is_dir($tmp_dir) ? 'EVET' : 'HAYIR') . "\n";
echo "TMP_DIR YAZILABILIR: " . (is_writable($tmp_dir) ? 'EVET' : 'HAYIR') . "\n\n";

// Tüm miknatis_*.json dosyaları
echo "=== TMP DOSYALAR ===\n";
if (is_dir($tmp_dir)) {
    $files = glob($tmp_dir . '/miknatis_*.json');
    if (empty($files)) {
        echo "HİÇ DOSYA YOK!\n";
    } else {
        foreach ($files as $f) {
            $v = json_decode(file_get_contents($f), true);
            $gecen = time() - ($v['ts'] ?? 0);
            echo basename($f) . ": ts=" . ($v['ts']??'?') . " gecen={$gecen}sn ip=" . ($v['ip']??'?') . "\n";
        }
    }
} else {
    echo "KLASÖR YOK!\n";
}

echo "\n=== PING ENDPOINT TEST ===\n";
// Ping endpoint'ini simüle et
$ping_root = dirname(__FILE__, 4) . '/uploads/miknatis';
if (!is_dir($ping_root)) {
    $ok = @mkdir($ping_root, 0777, true);
    echo "mkdir: " . ($ok ? 'OK' : 'HATA') . "\n";
} else {
    echo "Klasör var\n";
}
$test_file = $ping_root . '/miknatis_KRT-TEST.json';
$ok = @file_put_contents($test_file, json_encode(['ts'=>time(),'ip'=>'test']), LOCK_EX);
echo "Test yazma: " . ($ok !== false ? "OK ($ok bytes)" : 'HATA - izin yok!') . "\n";
if ($ok) @unlink($test_file);

echo "\n=== DB BAĞLANTISI ===\n";
try {
    require_once $root . '/core/config.php';
    require_once $root . '/core/db.php';
    $row = $db->query("SELECT COUNT(*) as n FROM miknatis_kontroller")->fetch();
    echo "miknatis_kontroller kayıt sayısı: " . $row['n'] . "\n";
    
    $row2 = $db->query("SELECT makina_kodu, MAX(kontrol_zamani) as son, 
        TIMESTAMPDIFF(SECOND,MAX(kontrol_zamani),NOW()) as gecen
        FROM miknatis_kontroller GROUP BY makina_kodu")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($row2 as $r) {
        echo "  " . $r['makina_kodu'] . ": son=" . $r['son'] . " (" . $r['gecen'] . "sn önce)\n";
    }
} catch (Throwable $e) {
    echo "DB HATA: " . $e->getMessage() . "\n";
}

echo "\n=== AUTH ===\n";
require_once $root . '/core/auth.php';
echo "Giriş yapılmış: " . (Auth::girisYapilmisMi() ? 'EVET' : 'HAYIR') . "\n";

echo "\n=== sys_get_temp_dir ===\n";
echo sys_get_temp_dir() . "\n";
$sys_file = sys_get_temp_dir() . '/miknatis_KRT-01.json';
echo "sys_temp dosyası var mı: " . (file_exists($sys_file) ? 'EVET - YANLIŞ YER!' : 'hayır') . "\n";
