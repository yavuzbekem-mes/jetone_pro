<?php
header('Content-Type: application/json; charset=utf-8');
if (ob_get_level()) ob_end_clean();

$makina = preg_replace('/[^A-Z0-9\-]/', '', strtoupper(trim($_REQUEST['makina'] ?? '')));
$ip     = substr(trim($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);

if (!$makina) { echo json_encode(['ok'=>false]); exit; }

$dir = dirname(__FILE__, 4) . '/uploads/miknatis';
if (!is_dir($dir)) @mkdir($dir, 0777, true);

// Mevcut veriyi koru, sadece ts ve ip güncelle
$dosya  = $dir . '/miknatis_' . $makina . '.json';
$mevcut = file_exists($dosya) ? (json_decode(file_get_contents($dosya), true) ?: []) : [];
$mevcut['ts'] = time();
$mevcut['ip'] = $ip;

$ok = @file_put_contents($dosya, json_encode($mevcut), LOCK_EX);
echo json_encode(['ok'=> $ok !== false, 'ts'=> $mevcut['ts'], 'ip'=> $ip]);
