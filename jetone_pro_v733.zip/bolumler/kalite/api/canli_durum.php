<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-store');

$root    = dirname(__FILE__, 4);
$tmp_dir = $root . '/uploads/miknatis';

require_once $root . '/core/config.php';
require_once $root . '/core/db.php';

$gecerli = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$makina  = preg_replace('/[^A-Z0-9\-]/', '', strtoupper($_GET['makina'] ?? 'KRT-01'));
if (!in_array($makina, $gecerli)) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz makina']); exit;
}

// ── Online: tmp dosyası VEYA son DB kaydı 10 dk içindeyse ────
$tmp_dosya = $tmp_dir . '/miknatis_' . $makina . '.json';
$tmp_ts    = 0;
$ip        = '';

if (file_exists($tmp_dosya)) {
    $t     = json_decode(file_get_contents($tmp_dosya), true) ?: [];
    $tmp_ts = (int)($t['ts'] ?? 0);
    $ip    = $t['ip'] ?? '';
}

// DB'den son kayıt zamanı
$db_ts = 0;
try {
    $s = $db->prepare("SELECT UNIX_TIMESTAMP(MAX(kontrol_zamani)) as ts FROM miknatis_kontroller WHERE makina_kodu=?");
    $s->execute([$makina]);
    $db_ts = (int)($s->fetchColumn() ?: 0);
} catch(Throwable $e) {}

// En güncel zaman damgasını kullan
$son_ts = max($tmp_ts, $db_ts);
$gecen  = $son_ts > 0 ? (time() - $son_ts) : PHP_INT_MAX;
$online = $gecen <= 600; // 10 dk

// tmp dosyasını DB zamanıyla güncelle (eğer daha güncel ise)
if ($db_ts > $tmp_ts && $db_ts > 0) {
    if (!is_dir($tmp_dir)) @mkdir($tmp_dir, 0777, true);
    $mevcut = file_exists($tmp_dosya) ? (json_decode(file_get_contents($tmp_dosya), true) ?: []) : [];
    $mevcut['ts'] = $db_ts;
    if (empty($mevcut['ip'])) $mevcut['ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
    @file_put_contents($tmp_dosya, json_encode($mevcut), LOCK_EX);
    $ip = $mevcut['ip'];
}

// ── Son DB kaydı ─────────────────────────────────────────────
$veri = null;
try {
    $stmt = $db->prepare("
        SELECT durum, m1, m2, m3, urun_kodu, aciklama,
               DATE_FORMAT(kontrol_zamani,'%H:%i:%s') AS saat,
               TIMESTAMPDIFF(SECOND, kontrol_zamani, NOW()) AS db_gecen
        FROM miknatis_kontroller WHERE makina_kodu=?
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([$makina]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $db_gecen = (int)$row['db_gecen'];
        if ($db_gecen > 30) $gorunum = 'BEKLEME';
        elseif (in_array($row['durum'],['basarili','duzeltildi'])) $gorunum = 'BASARILI';
        elseif (strpos($row['durum'],'hata')===0) $gorunum = 'HATA_BEKLE';
        else $gorunum = 'BEKLEME';

        $veri = [
            'durum'    => $gorunum,
            'db_durum' => $row['durum'],
            'm1'       => (int)$row['m1'],
            'm2'       => (int)$row['m2'],
            'm3'       => (int)$row['m3'],
            's0'       => $db_gecen < 60 ? 1 : 0,
            'sol'      => in_array($gorunum,['BASARILI','BEKLEME']) ? 1 : 0,
            'urun'     => $row['urun_kodu'],
            'aciklama' => $row['aciklama'],
            'saat'     => $row['saat'],
            'db_gecen' => $db_gecen,
            'online'   => $online,
            'ip'       => $ip,
        ];
    }
} catch (Throwable $e) {}

echo json_encode(['ok'=>true,'veri'=>$veri,'online'=>$online,'ip'=>$ip,'gecen'=>$gecen,'offline'=>!$online]);
