<?php
/**
 * Tekmelik Mıknatıs Kontrol — Veri Alım API
 * bolumler/kalite/api/miknatis_kayit.php
 * ESP32 bu endpoint'e JSON POST gönderir.
 */

header('Content-Type: application/json; charset=utf-8');

// ── GET: Ürün kodu sorgulama (ESP32 her 30 sn'de bir çeker) ───
if ($_SERVER['REQUEST_METHOD'] === 'GET'
    && isset($_GET['action'])
    && $_GET['action'] === 'urun_kodu') {

    require_once dirname(__FILE__, 4) . '/core/db.php';
    $makina = preg_replace('/[^A-Z0-9\-]/', '', strtoupper($_GET['makina'] ?? ''));
    if (!$makina) { echo json_encode(['ok'=>false,'hata'=>'makina gerekli']); exit; }
    try {
        $stmt = $db->prepare("SELECT urun_kodu FROM miknatis_cihaz_tanim WHERE makina_kodu=? AND aktif=1 LIMIT 1");
        $stmt->execute([$makina]);
        $uk = $stmt->fetchColumn();
        echo json_encode(['ok'=>true,'urun_kodu'=>$uk ?: '']);
    } catch(Throwable $e) {
        echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
    }
    exit;
}

// ── Sadece POST kabul et ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['ok'=>false,'hata'=>'Sadece POST']));
}

// ── DB bağlantısı ─────────────────────────────────────────────
require_once dirname(__FILE__, 4) . '/core/db.php';

// ── Gelen JSON ────────────────────────────────────────────────
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    exit(json_encode(['ok'=>false,'hata'=>'Geçersiz JSON']));
}

foreach (['urun_kodu','durum','m1','m2','m3'] as $alan) {
    if (!isset($data[$alan])) {
        http_response_code(400);
        exit(json_encode(['ok'=>false,'hata'=>"Eksik: $alan"]));
    }
}

$urun_kodu   = substr(trim($data['urun_kodu']),         0, 30);
$makina_kodu = substr(trim($data['makina_kodu'] ?? 'KRT-01'), 0, 20);
$m1          = (int)(bool)$data['m1'];
$m2          = (int)(bool)$data['m2'];
$m3          = (int)(bool)$data['m3'];
$eksik_adet  = 3 - ($m1 + $m2 + $m3);
$aciklama    = substr(trim($data['aciklama'] ?? ''), 0, 100);
$orijinal_id = isset($data['orijinal_id']) ? (int)$data['orijinal_id'] : null;

// ESP32 IP adresini al — JSON'dan veya HTTP_CLIENT_IP / REMOTE_ADDR
$ip_adresi = trim($data['ip'] ?? '')
           ?: ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
$ip_adresi = substr($ip_adresi, 0, 45);

$gecerli = ['basarili','hata_1','hata_2','hata_3','duzeltildi'];
$durum   = $data['durum'];
if (!in_array($durum, $gecerli)) {
    http_response_code(400);
    exit(json_encode(['ok'=>false,'hata'=>"Geçersiz durum: $durum"]));
}

// ── Düzeltme durumu ───────────────────────────────────────────
$duzeltme_zamani = null;
if ($durum === 'duzeltildi') {
    $duzeltme_zamani = date('Y-m-d H:i:s');
    if (!$orijinal_id) {
        $stmt = $db->prepare("
            SELECT id FROM miknatis_kontroller
            WHERE makina_kodu=? AND urun_kodu=?
              AND durum IN('hata_1','hata_2','hata_3')
              AND id NOT IN (
                  SELECT COALESCE(orijinal_id,0)
                  FROM miknatis_kontroller WHERE orijinal_id IS NOT NULL
              )
            ORDER BY kontrol_zamani DESC LIMIT 1
        ");
        $stmt->execute([$makina_kodu, $urun_kodu]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) $orijinal_id = $row['id'];
    }
}

// ── DB kaydet ─────────────────────────────────────────────────
try {
    // ip_adresi kolonu yoksa ekle (ilk kurulum için)
    try {
        $db->exec("ALTER TABLE miknatis_kontroller ADD COLUMN ip_adresi VARCHAR(45) NULL DEFAULT NULL AFTER makina_kodu");
    } catch(Throwable $e) { /* zaten varsa hata yok sayılır */ }

    $stmt = $db->prepare("
        INSERT INTO miknatis_kontroller
            (urun_kodu, makina_kodu, ip_adresi, durum, m1, m2, m3,
             eksik_adet, orijinal_id, duzeltme_zamani, aciklama)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    ");
    $stmt->execute([
        $urun_kodu, $makina_kodu, $ip_adresi ?: null, $durum,
        $m1, $m2, $m3, $eksik_adet,
        $orijinal_id, $duzeltme_zamani,
        $aciklama ?: null,
    ]);

    $yeni_id = (int)$db->lastInsertId();

    // ── Online durum: tmp dosyasına yaz ──────────────────────
    $canli_veri = json_encode([
        'ts'       => time(),
        'durum'    => $durum,
        'm1'       => $m1,
        'm2'       => $m2,
        'm3'       => $m3,
        'urun'     => $urun_kodu,
        'ip'       => $ip_adresi,
        'aciklama' => $aciklama,
    ]);
    // Proje içinde sabit yol kullan (Laragon/Windows'ta sys_get_temp_dir yazma sorunu)
    $canli_dir = dirname(__FILE__, 4) . '/uploads/miknatis';
    if (!is_dir($canli_dir)) @mkdir($canli_dir, 0777, true);
    $tmp_dosya = $canli_dir . '/miknatis_' . $makina_kodu . '.json';
    @file_put_contents($tmp_dosya, $canli_veri, LOCK_EX);

    // ── Günlük özet (ESP32'ye döner) ─────────────────────────
    $stmt2 = $db->prepare("
        SELECT COUNT(*) AS toplam,
               SUM(durum='basarili')                    AS basarili,
               SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
               SUM(durum='duzeltildi')                  AS duzeltildi
        FROM miknatis_kontroller
        WHERE makina_kodu=? AND DATE(kontrol_zamani)=CURDATE()
    ");
    $stmt2->execute([$makina_kodu]);
    $ozet = $stmt2->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'ok'   => true,
        'id'   => $yeni_id,
        'ozet' => [
            'toplam'     => (int)$ozet['toplam'],
            'basarili'   => (int)$ozet['basarili'],
            'hatali'     => (int)$ozet['hatali'],
            'duzeltildi' => (int)$ozet['duzeltildi'],
        ],
    ]);

} catch (PDOException $e) {
    error_log('tekmelik_api: ' . $e->getMessage());
    http_response_code(500);
    exit(json_encode(['ok'=>false,'hata'=>'DB hatası: '.$e->getMessage()]));
}
