<?php
/**
 * Tüm cihazların online durumu — DB + tmp birleşik
 * Cihazlar sayfası 30 sn'de bir çağırır
 */
$root = dirname(__FILE__, 4);
require_once $root . '/core/config.php';
require_once $root . '/core/auth.php';

header('Content-Type: application/json; charset=utf-8');
if (ob_get_level()) ob_end_clean();

if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'hata'=>'auth']); exit; }

require_once $root . '/core/db.php';

$tmp_dir  = $root . '/uploads/miknatis';
$cihazlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$simdi    = time();

// DB'den son kayıt zamanları — sadece kontrol_zamani (ip_adresi kolonu gerekmez)
$db_map = [];
try {
    $rows = $db->query("
        SELECT makina_kodu,
               UNIX_TIMESTAMP(MAX(kontrol_zamani)) AS ts
        FROM miknatis_kontroller
        GROUP BY makina_kodu
    ")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) $db_map[$r['makina_kodu']] = (int)$r['ts'];
} catch(Throwable $e) {}

$sonuc = [];
foreach ($cihazlar as $kod) {
    $tmp_ts = 0;
    $ip     = '';

    // tmp dosyasından oku (ping veya kayıt yazdıysa)
    $dosya = $tmp_dir . '/miknatis_' . $kod . '.json';
    if (file_exists($dosya)) {
        $v = json_decode(@file_get_contents($dosya), true) ?: [];
        $tmp_ts = (int)($v['ts'] ?? 0);
        $ip     = $v['ip'] ?? '';
    }

    // DB zamanı
    $db_ts = $db_map[$kod] ?? 0;

    // Daha yeni olanı kullan
    $son_ts = max($tmp_ts, $db_ts);
    $gecen  = $son_ts > 0 ? ($simdi - $son_ts) : PHP_INT_MAX;
    $online = ($gecen <= 10800); // 3 saat — ESP32 ping sorunu çözülene kadar içinde herhangi bir aktivite = online

    $sonuc[$kod] = [
        'online'  => $online,
        'ip'      => $ip,
        'gecen'   => $gecen,
        'tmp_ts'  => $tmp_ts,  // debug
        'db_ts'   => $db_ts,   // debug
        'son_ts'  => $son_ts,  // debug
    ];
}

echo json_encode(['ok'=>true,'d'=>$sonuc,'simdi'=>$simdi]);
