<?php
/**
 * Online kontrol
 * 1. TCP port tara — ESP32 açık portu varsa online
 * 2. TCP çalışmazsa — son kayıt/ping zamanına bak (3 saat)
 */
$root = dirname(__FILE__, 4);
require_once $root . '/core/config.php';
require_once $root . '/core/auth.php';

header('Content-Type: application/json; charset=utf-8');
if (ob_get_level()) ob_end_clean();
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false]); exit; }

$dir    = $root . '/uploads/miknatis';
$kodlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];
$simdi  = time();
$sonuc  = [];

// DB'den son kayıt zamanları
require_once $root . '/core/db.php';
$db_map = [];
try {
    $rows = $db->query("
        SELECT makina_kodu, UNIX_TIMESTAMP(MAX(kontrol_zamani)) as ts
        FROM miknatis_kontroller GROUP BY makina_kodu
    ")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) $db_map[$r['makina_kodu']] = (int)$r['ts'];
} catch(Throwable $e){}

foreach ($kodlar as $kod) {
    $dosya  = $dir . '/miknatis_' . $kod . '.json';
    $ip     = '';
    $tmp_ts = 0;

    if (file_exists($dosya)) {
        $v      = json_decode(file_get_contents($dosya), true) ?: [];
        $ip     = trim($v['ip'] ?? '');
        $tmp_ts = (int)($v['ts'] ?? 0);
    }

    // En güncel zaman damgası — tmp veya DB
    $db_ts  = $db_map[$kod] ?? 0;
    $son_ts = max($tmp_ts, $db_ts);
    $gecen  = $son_ts > 0 ? ($simdi - $son_ts) : PHP_INT_MAX;

    // TCP ile canlı kontrol dene (ESP32 port 80 varsayılan HTTP)
    $tcp_online = false;
    if ($ip && $gecen < 86400) { // sadece son 24 saatte görüldüyse dene
        foreach ([80, 8080, 23] as $port) {
            $s = @fsockopen($ip, $port, $e, $es, 0.3);
            if ($s) { fclose($s); $tcp_online = true; break; }
        }
    }

    if ($tcp_online) {
        // TCP bağlandı — kesinlikle online, ts güncelle
        $v = file_exists($dosya) ? (json_decode(file_get_contents($dosya), true) ?: []) : [];
        $v['ts'] = $simdi; $v['ip'] = $ip;
        @file_put_contents($dosya, json_encode($v), LOCK_EX);
        $online = true;
    } else {
        // TCP çalışmadı — son aktiviteye bak
        // ESP32 her test kaydında zaten DB'ye yazıyor
        // Son kayıt 3 saat içindeyse online say
        $online = ($gecen <= 10800);
    }

    $sonuc[$kod] = ['online'=>$online, 'ip'=>$ip, 'gecen'=>$gecen];
}

echo json_encode(['ok'=>true, 'cihazlar'=>$sonuc]);
