<?php
/**
 * GKK — Gelen Kalite Kontrol Listesi
 * Route: kalite-gkk-liste
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

require_once ROOT_DIR.'/islemler/kalite/gkk_ortak.php';
global $db;
try { gkk_tablo_olustur($db); } catch(Throwable $e) {}

$f_basl    = trim($_GET['basl']    ?? date('Y-m-01'));
$f_bitis   = trim($_GET['bitis']   ?? date('Y-m-d'));
$f_irsno   = trim($_GET['irsno']   ?? '');
$f_cari    = trim($_GET['cari']    ?? '');
$f_durum   = trim($_GET['durum']   ?? '');

$irsaliyeler = [];
if($tigerdb_pdo) {
    try {
        $w = ["YEAR(K.IRSALIYE_TARIHI)>=2025"];
        $p = [];
        if($f_basl && $f_bitis) { $w[]="CONVERT(date,K.IRSALIYE_TARIHI) BETWEEN ? AND ?"; $p[]=$f_basl; $p[]=$f_bitis; }
        if($f_irsno) { $w[]="K.IRSALIYE_NO LIKE ?"; $p[]="%$f_irsno%"; }
        if($f_cari)  { $w[]="K.CARI_UNVANI LIKE ?"; $p[]="%$f_cari%"; }
        $ws = implode(' AND ', $w);
        $sql = "SELECT TOP 500
            K.FIS_ID, K.IRSALIYE_NO, K.IRSALIYE_TARIHI,
            K.CARI_KODU, K.CARI_UNVANI, K.IRSALIYE_TURU
        FROM MES_SATINALMA_IRSALIYESI_KALITE K
        WHERE $ws ORDER BY K.FIS_ID DESC";
        $st = $tigerdb_pdo->prepare($sql);
        $st->execute($p);
        $irsaliyeler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Her irsaliye için GKK durumunu hesapla
$gkk_durum_map = [];
if(!empty($irsaliyeler) && $db) {
    try {
        $fis_ids = array_column($irsaliyeler,'FIS_ID');
        $in = implode(',',array_fill(0,count($fis_ids),'?'));
        $st2 = $db->prepare("SELECT fis_id, sonuc, COUNT(*) AS sayi FROM gkk_kontrol_sonuclari WHERE fis_id IN ($in) GROUP BY fis_id, sonuc");
        $st2->execute($fis_ids);
        foreach($st2->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $gkk_durum_map[$r['fis_id']][$r['sonuc']] = (int)$r['sayi'];
        }
    } catch(Throwable $e) {}
}

// Paket sayısı map
$paket_map = [];
if(!empty($irsaliyeler) && $mes_pdo) {
    try {
        $irsno_list = array_unique(array_column($irsaliyeler,'IRSALIYE_NO'));
        $in2 = implode(',',array_fill(0,count($irsno_list),'?'));
        $st3 = $mes_pdo->prepare("SELECT URETIM_EMRI_NO, COUNT(*) AS sayi FROM dbo.PAKETLER WHERE URETIM_EMRI_NO IN ($in2) AND AKTIF=0 GROUP BY URETIM_EMRI_NO");
        $st3->execute($irsno_list);
        foreach($st3->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $paket_map[$r['URETIM_EMRI_NO']] = (int)$r['sayi'];
        }
    } catch(Throwable $e) {}
}

// Durum filtresi
if($f_durum) {
    $irsaliyeler = array_values(array_filter($irsaliyeler, function($r) use($f_durum, $paket_map, $gkk_durum_map) {
        $pkt = $paket_map[$r['IRSALIYE_NO']] ?? 0;
        $gkk = $gkk_durum_map[$r['FIS_ID']] ?? [];
        $toplam_gkk = array_sum($gkk);
        if($f_durum === 'bekliyor') return $pkt > 0 && $toplam_gkk == 0;
        if($f_durum === 'kismi')   return $pkt > 0 && $toplam_gkk > 0 && $toplam_gkk < $pkt;
        if($f_durum === 'tamam')   return $toplam_gkk > 0 && ($gkk['RED']??0) == 0;
        if($f_durum === 'red')     return ($gkk['RED']??0) > 0;
        if($f_durum === 'paket_yok') return $pkt == 0;
        return true;
    }));
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔬 Gelen Kalite Kontrol</h1>
    <div class="s-yol">Kalite / <b>GKK</b></div>
  </div>
</div>
<div class="s-body">

<!-- Filtreler -->
<div class="kart" style="padding:16px;margin-bottom:14px">
  <form method="GET">
    <input type="hidden" name="sayfa" value="kalite-gkk-liste">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;align-items:flex-end">
      <div><label class="form-et" style="font-size:11px">Başlangıç</label><input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
      <div><label class="form-et" style="font-size:11px">Bitiş</label><input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
      <div><label class="form-et" style="font-size:11px">İrsaliye No</label><input type="text" name="irsno" class="form-alan" value="<?=htmlspecialchars($f_irsno)?>" placeholder="ARS..."></div>
      <div><label class="form-et" style="font-size:11px">Tedarikçi</label><input type="text" name="cari" class="form-alan" value="<?=htmlspecialchars($f_cari)?>" placeholder="Firma..."></div>
      <div>
        <label class="form-et" style="font-size:11px">Durum</label>
        <select name="durum" class="form-alan">
          <option value="">Tümü</option>
          <option value="paket_yok"  <?=$f_durum==='paket_yok'?'selected':''?>>📦 Paket Bekleniyor</option>
          <option value="bekliyor"   <?=$f_durum==='bekliyor'?'selected':''?>>⏳ GKK Bekleniyor</option>
          <option value="kismi"      <?=$f_durum==='kismi'?'selected':''?>>🔄 Kısmi Kontrol</option>
          <option value="tamam"      <?=$f_durum==='tamam'?'selected':''?>>✅ Tamamlandı</option>
          <option value="red"        <?=$f_durum==='red'?'selected':''?>>❌ Red Var</option>
        </select>
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-t" style="flex:1;padding:10px">🔍 Ara</button>
        <a href="?sayfa=kalite-gkk-liste" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">↺</a>
      </div>
    </div>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <span style="font-weight:800;font-size:14px">🔬 İrsaliye Listesi</span>
    <span style="font-size:12px;color:var(--m3)"><?=count($irsaliyeler)?> irsaliye</span>
  </div>
  <?php if(empty($irsaliyeler)):?>
  <div style="padding:40px;text-align:center;color:var(--m3)"><div style="font-size:36px">📭</div><div>Kayıt bulunamadı.</div></div>
  <?php else:?>
  <div style="overflow:auto;max-height:640px">
  <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
    <colgroup>
      <col style="width:140px"><col style="width:90px"><col style="width:220px">
      <col style="width:100px"><col style="width:110px"><col style="width:80px">
      <col style="width:110px"><col style="width:120px">
    </colgroup>
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E293B;color:#fff;border-bottom:2px solid #0F172A">
        <th style="padding:9px 10px;border-right:1px solid #334155">İrsaliye No</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Tarih</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Tedarikçi</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Cari Kodu</th>
        <th style="padding:9px 10px;text-align:center;border-right:1px solid #334155">Paket</th>
        <th style="padding:9px 10px;text-align:center;border-right:1px solid #334155">GKK</th>
        <th style="padding:9px 10px;text-align:center;border-right:1px solid #334155">Durum</th>
        <th style="padding:9px 10px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($irsaliyeler as $i=>$r):
      $fid  = $r['FIS_ID'];
      $irsno = $r['IRSALIYE_NO'];
      $pkt  = $paket_map[$irsno] ?? 0;
      $gkk  = $gkk_durum_map[$fid] ?? [];
      $toplam_gkk = array_sum($gkk);
      $bg = $i%2===0?'#fff':'var(--kenar-a)';

      // Durum badge
      if($pkt == 0) {
          $dbg='#F3F4F6'; $dfg='#6B7280'; $dtxt='📦 Paket Yok';
      } elseif($toplam_gkk == 0) {
          $dbg='#FEF3C7'; $dfg='#92400E'; $dtxt='⏳ GKK Bekliyor';
      } elseif(($gkk['RED']??0) > 0) {
          $dbg='#FEE2E2'; $dfg='#7F1D1D'; $dtxt='❌ Red Var';
      } elseif($toplam_gkk < $pkt) {
          $dbg='#DBEAFE'; $dfg='#1E40AF'; $dtxt='🔄 Kısmi';
      } else {
          $dbg='#D1FAE5'; $dfg='#065F46'; $dtxt='✅ Tamam';
      }
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:7px 10px;font-weight:700;font-family:monospace;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;white-space:nowrap"><?=htmlspecialchars($irsno)?></td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m2);border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars(substr($r['IRSALIYE_TARIHI']??'',0,10))?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['CARI_UNVANI']??'')?>"><?=htmlspecialchars($r['CARI_UNVANI']??'')?></td>
      <td style="padding:7px 10px;font-size:11px;font-family:monospace;border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars($r['CARI_KODU']??'')?></td>
      <td style="padding:7px 10px;text-align:center;font-weight:700;border-right:1px solid var(--kenar)">
        <?=$pkt>0?"<span style='color:#16A34A'>$pkt pkg</span>":"<span style='color:var(--m3)'>—</span>"?>
      </td>
      <td style="padding:7px 10px;text-align:center;border-right:1px solid var(--kenar);font-size:11px">
        <?php if($toplam_gkk>0): ?>
          <?php if($gkk['ONAY']??0):?><span style="color:#16A34A;font-weight:700"><?=$gkk['ONAY']?>✅</span> <?php endif;?>
          <?php if($gkk['SART_ONAY']??0):?><span style="color:#F59E0B;font-weight:700"><?=$gkk['SART_ONAY']?>⚠️</span> <?php endif;?>
          <?php if($gkk['RED']??0):?><span style="color:#DC2626;font-weight:700"><?=$gkk['RED']?>❌</span><?php endif;?>
        <?php else:?>—<?php endif;?>
      </td>
      <td style="padding:7px 10px;text-align:center;border-right:1px solid var(--kenar)">
        <span style="background:<?=$dbg?>;color:<?=$dfg?>;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:700;white-space:nowrap"><?=$dtxt?></span>
      </td>
      <td style="padding:7px 10px;text-align:center">
        <?php if($pkt > 0):?>
        <a href="?sayfa=kalite-gkk-detay&fis_id=<?=$fid?>&irsaliye_no=<?=urlencode($irsno)?>&cari=<?=urlencode($r['CARI_UNVANI']??'')?>&cari_kodu=<?=urlencode($r['CARI_KODU']??'')?>&tarih=<?=urlencode(substr($r['IRSALIYE_TARIHI']??'',0,10))?>"
           style="padding:4px 12px;background:#4F46E5;color:#fff;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none;white-space:nowrap">
          🔬 Kontrol
        </a>
        <?php else:?>
        <span style="font-size:11px;color:var(--m3)">—</span>
        <?php endif;?>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

</div><!-- /s-body -->
