<?php
/**
 * DÖF Detay — Tam görünüm + dokümanlar
 * panel.php: 'kalite-dof-detay' => 'bolumler/kalite/dof_detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-dof';</script>"; exit; }
$s=$db->prepare("SELECT * FROM kal_dof WHERE id=?");$s->execute([$id]);$d=$s->fetch(PDO::FETCH_ASSOC);
if (!$d) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-dof';</script>"; exit; }

$mesaj=''; $mesaj_tip='';

// POST
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'durum_guncelle':
            $db->prepare("UPDATE kal_dof SET durum=? WHERE id=?")->execute([$_POST['durum'],$id]);
            $d['durum']=$_POST['durum'];
            $mesaj='Durum güncellendi.'; $mesaj_tip='ok'; break;
        case 'dof_sil':
            $dok_l=$db->prepare("SELECT dosya_yolu FROM kal_dof_dokuman WHERE dof_id=?");$dok_l->execute([$id]);
            foreach($dok_l->fetchAll(PDO::FETCH_COLUMN) as $y){$f=dirname(dirname(__DIR__)).'/'.$y;if(file_exists($f))@unlink($f);}
            $db->prepare("DELETE FROM kal_dof WHERE id=?")->execute([$id]);
            echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-dof';</script>"; exit;
        case 'dok_sil':
            $dk=$db->prepare("SELECT * FROM kal_dof_dokuman WHERE id=? AND dof_id=?");$dk->execute([(int)$_POST['dok_id'],$id]);$dk=$dk->fetch(PDO::FETCH_ASSOC);
            if($dk){$f=dirname(dirname(__DIR__)).'/'.$dk['dosya_yolu'];if(file_exists($f))@unlink($f);$db->prepare("DELETE FROM kal_dof_dokuman WHERE id=?")->execute([$dk['id']]);}
            $mesaj='Silindi.'; $mesaj_tip='ok'; break;
    }
}

// Doküman yükle
if (isset($_FILES['dosya']) && $_FILES['dosya']['error']===0) {
    $dir=dirname(dirname(__DIR__)).'/uploads/dof/'.$id.'/';
    if(!is_dir($dir))mkdir($dir,0777,true);
    $ext=strtolower(pathinfo($_FILES['dosya']['name'],PATHINFO_EXTENSION));
    if(in_array($ext,['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','zip'])){
        $fn=time().'_'.preg_replace('/[^a-z0-9._-]/i','_',$_FILES['dosya']['name']);
        if(move_uploaded_file($_FILES['dosya']['tmp_name'],$dir.$fn)){
            $db->prepare("INSERT INTO kal_dof_dokuman(dof_id,dosya_adi,dosya_yolu,tur,aciklama,yukleyen) VALUES(?,?,?,?,?,?)")
               ->execute([$id,$_FILES['dosya']['name'],'uploads/dof/'.$id.'/'.$fn,$_POST['dok_tur']??'diger',$_POST['dok_aciklama']??'',$kul_adi]);
            $mesaj='Doküman yüklendi.'; $mesaj_tip='ok';
        }
    } else { $mesaj='Desteklenmeyen tür.'; $mesaj_tip='hata'; }
}

// Dokümanlar
$s2=$db->prepare("SELECT * FROM kal_dof_dokuman WHERE dof_id=? ORDER BY yuklenme_tarihi DESC");$s2->execute([$id]);$dokumanlar=$s2->fetchAll(PDO::FETCH_ASSOC);

$ds=['acildi'=>['#DC2626','🔴 Açıldı'],'analiz'=>['#D97706','🔎 Analiz'],'aksiyon'=>['#0EA5E9','⚙️ Aksiyon'],'dogrulama'=>['#7C3AED','✅ Doğrulama'],'kapandi'=>['#16A34A','🏁 Kapandı'],'iptal'=>['#94A3B8','❌ İptal']];
$ks=['dusuk'=>['#94A3B8','Düşük'],'orta'=>['#D97706','Orta'],'yuksek'=>['#EF4444','Yüksek'],'kritik'=>['#7F1D1D','KRİTİK']];

function blok($baslik,$icerik,$renk='#1E3A5F') {
    if (!trim($icerik??'')) return '';
    return "<div style='background:var(--kenar-a);border-radius:8px;padding:12px;border-left:3px solid $renk'>
        <div style='font-size:10px;font-weight:700;color:$renk;margin-bottom:6px'>$baslik</div>
        <div style='font-size:13px;color:var(--t);white-space:pre-wrap'>".htmlspecialchars($icerik)."</div></div>";
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 <?=htmlspecialchars($d['dof_no'])?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof" style="color:var(--t)">DÖF</a> / <b><?=htmlspecialchars($d['dof_no'])?></b></div>
  </div>
  <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="durum_guncelle">
      <select name="durum" class="form-alan" style="font-size:12px;padding:4px 8px" onchange="this.form.submit()">
        <?php foreach(['acildi'=>'Acildi','analiz'=>'Analiz','aksiyon'=>'Aksiyon','dogrulama'=>'Dogrulama','kapandi'=>'Kapandi','iptal'=>'Iptal'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['durum']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof-form&id=<?=$id?>" class="btn btn-b btn-sm">✏️ Düzenle</a>
    <?php
      $sil_no   = htmlspecialchars($d['dof_no']);
      $sil_dcnt = count($dokumanlar);
    ?>
    <button id="dofSilBtn"
      data-no="<?=$sil_no?>"
      data-dcnt="<?=$sil_dcnt?>"
      class="btn btn-sm" style="background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;font-size:12px;padding:5px 12px">
      🗑️ Sil
    </button>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-dof" class="btn btn-b btn-sm">← Geri</a>
  </div>
</div>

<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<!-- Başlık Kartı -->
<?php
  $ds0 = $ds[$d['durum']][0] ?? '#6B7280';
  $ds1 = $ds[$d['durum']][1] ?? '?';
  $ks0 = $ks[$d['kritiklik']][0] ?? '#6B7280';
  $ks1 = $ks[$d['kritiklik']][1] ?? '?';
?>
<div class="kart" style="padding:16px;margin-bottom:14px;border-left:4px solid <?=$ds0?>">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:12px">
    <div>
      <div style="font-size:16px;font-weight:800;color:var(--t);margin-bottom:6px"><?=htmlspecialchars($d['problem_tanimi'])?></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:12px;color:var(--m2)">
        <span>📅 <?=date('d.m.Y',strtotime($d['acilis_tarihi']))?></span>
        <?php if($d['kaynak_ref']): ?><span>📋 <?=htmlspecialchars($d['kaynak_ref'])?></span><?php endif; ?>
        <?php if($d['sorumlu']): ?><span>👤 <?=htmlspecialchars($d['sorumlu'])?></span><?php endif; ?>
        <?php if($d['hedef_tarih']): ?><span>🏁 <?=date('d.m.Y',strtotime($d['hedef_tarih']))?></span><?php endif; ?>
        <?php if($d['etkilenen_miktar']): ?><span>📊 <?=htmlspecialchars($d['etkilenen_miktar'])?></span><?php endif; ?>
        <?php if(count($dokumanlar)): ?><span>📎 <?=count($dokumanlar)?></span><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <span style="font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;background:<?=$ds0?>22;color:<?=$ds0?>;border:1px solid <?=$ds0?>"><?=$ds1?></span>
      <span style="font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;background:<?=$ks0?>22;color:<?=$ks0?>"><?=$ks1?></span>
    </div>
  </div>
</div>

<!-- İlerleme -->
<?php
  $adim_no_map = ['acildi'=>1,'analiz'=>2,'aksiyon'=>3,'dogrulama'=>4,'kapandi'=>5,'iptal'=>0];
  $aktif_adim  = $adim_no_map[$d['durum']] ?? 0;
  $adim_lbls   = ['Acildi','Analiz','Aksiyon','Dogrulama','Kapandi'];
?>
<div class="kart" style="padding:14px;margin-bottom:14px">
  <div style="display:flex;justify-content:space-between;position:relative">
    <div style="position:absolute;top:14px;left:10%;right:10%;height:3px;background:var(--kenar);z-index:0"></div>
    <?php
      $bar_width = $aktif_adim > 0 ? min(80, ($aktif_adim-1)/4*80) : 0;
    ?>
    <div style="position:absolute;top:14px;left:10%;width:<?=$bar_width?>%;height:3px;background:#16A34A;z-index:1"></div>
    <?php foreach($adim_lbls as $ai=>$albl): $an=$ai+1; ?>
    <div style="text-align:center;width:20%;position:relative;z-index:2">
      <div style="width:28px;height:28px;border-radius:50%;margin:0 auto;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center;background:<?=$an<=$aktif_adim?'#16A34A':'var(--kenar)'?>;color:<?=$an<=$aktif_adim?'#fff':'var(--m2)'?>">
        <?=$an<=$aktif_adim?'✓':$an?>
      </div>
      <div style="font-size:10px;margin-top:4px;font-weight:<?=$an===$aktif_adim?700:400?>;color:<?=$an===$aktif_adim?'var(--t)':'var(--m2)'?>"><?=$albl?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:16px;flex-wrap:wrap">
  <?php
    $dtabs_data = [
      ['analiz',     'Problem & 5N1K'],
      ['onlem',      'Gecici Onlem'],
      ['kok_neden',  'Kok Neden'],
      ['aksiyon',    'Faaliyetler'],
      ['dogrulama',  'Dogrulama'],
      ['dokumanlar', 'Dokumanlar ('.count($dokumanlar).')'],
    ];
    foreach($dtabs_data as $di=>[$dtid,$dtlbl]):
  ?>
  <button onclick="tabGoster('<?=$dtid?>')" id="dtab_<?=$dtid?>"
    style="padding:7px 13px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;
           background:<?=$di===0?'var(--t)':'var(--kenar-a)'?>;color:<?=$di===0?'#fff':'var(--m)'?>">
    <?=$dtlbl?>
  </button>
  <?php endforeach; ?>
</div>

<!-- ANALIZ -->
<div id="tab_analiz">
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px">
    <?php foreach([
      ['KIM',    'bes_n_kim',    '#2563EB'],
      ['NE',     'bes_n_ne',     '#DC2626'],
      ['NEREDE', 'bes_n_nerede', '#D97706'],
      ['NEZAMAN','bes_n_nezaman','#0EA5E9'],
      ['NASIL',  'bes_n_nasil',  '#7C3AED'],
      ['ETKILENEN MIKTAR','etkilenen_miktar','#16A34A'],
    ] as $b): ?>
    <?=blok($b[0],$d[$b[1]]??'',$b[2])?>
    <?php endforeach; ?>
  </div>
</div>

<!-- GECİCİ ÖNLEM -->
<div id="tab_onlem" style="display:none">
  <?=blok('Gecici Onlem',$d['gecici_onlem']??'','#F59E0B')?>
  <?php if(!trim($d['gecici_onlem']??'')): ?><div class="kart" style="padding:24px;text-align:center;color:var(--m3)">Girilmemis.</div><?php endif; ?>
</div>

<!-- KÖK NEDEN -->
<div id="tab_kok_neden" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px" class="kk-grid">
    <?=blok('5 Neden Analizi',$d['kok_neden_5n']??'','#0EA5E9')?>
    <?=blok('Kacis Noktasi',$d['kok_neden_kacan']??'','#DC2626')?>
  </div>
  <div class="kart" style="padding:14px">
    <div style="font-weight:700;font-size:12px;margin-bottom:10px">Balik Kilcigi</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px" class="balik-grid">
      <?php foreach([
        ['Insan',   'balik_insan',   '#2563EB'],
        ['Yontem',  'balik_yontem',  '#7C3AED'],
        ['Makine',  'balik_makine',  '#D97706'],
        ['Malzeme', 'balik_malzeme', '#16A34A'],
        ['Olcum',   'balik_olcum',   '#EF4444'],
        ['Cevre',   'balik_cevre',   '#0EA5E9'],
      ] as $b): ?>
      <div style="background:var(--kenar-a);border-radius:8px;padding:10px;border-top:3px solid <?=$b[2]?>">
        <div style="font-size:11px;font-weight:700;color:<?=$b[2]?>;margin-bottom:5px"><?=$b[0]?></div>
        <div style="font-size:12px;color:var(--t)"><?=trim($d[$b[1]]??'')?nl2br(htmlspecialchars($d[$b[1]])):'<span style="color:var(--m3)">-</span>'?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- AKSİYON -->
<div id="tab_aksiyon" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px" class="ak-grid">
    <?=blok('Duzeltici Faaliyet',$d['duzeltici_faaliyet']??'','#16A34A')?>
    <?=blok('Onleyici Faaliyet',$d['onleyici_faaliyet']??'','#6366F1')?>
  </div>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:12px">
    <?php foreach([['Sorumlu','sorumlu'],['Hedef Tarih','hedef_tarih'],['Tamamlanma','tamamlanma_tarihi']] as $b): ?>
    <div class="kart" style="padding:12px;text-align:center">
      <div style="font-size:10px;color:var(--m2)"><?=$b[0]?></div>
      <div style="font-size:14px;font-weight:700"><?=htmlspecialchars($d[$b[1]]??'-')?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- DOGRULAMA -->
<div id="tab_dogrulama" style="display:none">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px" class="dg-grid">
    <?=blok('Dogrulama Yontemi',$d['dogrulama_yontemi']??'','#7C3AED')?>
    <?=blok('Etkinlik Kontrolu',$d['etkinlik_kontrolu']??'','#16A34A')?>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    <?php foreach([['Dogrulayan','dogrulayan'],['Dogrulama Tarihi','dogrulama_tarihi']] as $b): ?>
    <div class="kart" style="padding:12px;text-align:center">
      <div style="font-size:10px;color:var(--m2)"><?=$b[0]?></div>
      <div style="font-size:14px;font-weight:700"><?=htmlspecialchars($d[$b[1]]??'-')?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- DOKÜMANLAR -->
<div id="tab_dokumanlar" style="display:none">
  <div style="display:flex;justify-content:flex-end;margin-bottom:12px">
    <button onclick="dokModalAc()" class="btn btn-t btn-sm">📎 Yukle</button>
  </div>
  <?php if(empty($dokumanlar)): ?>
  <div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Dokuman yuklenmemis.</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px">
  <?php foreach($dokumanlar as $dok):
    $ext=strtolower(pathinfo($dok['dosya_adi'],PATHINFO_EXTENSION));
    $dikon=in_array($ext,['jpg','jpeg','png','gif'])?'🖼️':($ext==='pdf'?'📄':'📎');
    $dok_id_safe=(int)$dok['id'];
  ?>
  <div class="kart" style="padding:12px">
    <div style="display:flex;gap:8px;margin-bottom:8px">
      <div style="font-size:22px"><?=$dikon?></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:12px;word-break:break-word"><?=htmlspecialchars($dok['dosya_adi'])?></div>
        <?php if($dok['aciklama']): ?><div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars($dok['aciklama'])?></div><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:10px;color:var(--m3)"><?=date('d.m.Y',strtotime($dok['yuklenme_tarihi']))?></span>
      <div style="display:flex;gap:5px">
        <a href="<?=BASE_URL?>/<?=$dok['dosya_yolu']?>" target="_blank" class="btn btn-b btn-sm" style="font-size:11px;padding:3px 8px">⬇️</a>
        <form method="POST" style="display:inline">
          <input type="hidden" name="action" value="dok_sil">
          <input type="hidden" name="dok_id" value="<?=$dok_id_safe?>">
          <button type="submit" onclick="return confirm('Silinsin mi?')" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DOKUMAN MODAL -->
<div id="dokModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:420px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800">Dokuman Yukle</div>
    <button onclick="modalKapat('dokModal')" style="border:none;background:none;font-size:18px;cursor:pointer">x</button>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Dosya</label><input type="file" name="dosya" class="form-alan" required></div>
      <div><label class="form-et">Tur</label>
        <select name="dok_tur" class="form-alan">
          <option value="kanit">Kanit</option>
          <option value="foto">Fotograf</option>
          <option value="rapor">Rapor</option>
          <option value="aksiyon">Aksiyon</option>
          <option value="diger">Diger</option>
        </select>
      </div>
      <div><label class="form-et">Aciklama</label><input name="dok_aciklama" class="form-alan"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('dokModal')" class="btn btn-b">Iptal</button>
      <button type="submit" class="btn btn-t">Yukle</button>
    </div>
  </form>
</div>
</div>

<!-- GİZLİ FORMLAR -->
<form method="POST" id="dofSilForm" style="display:none">
  <input type="hidden" name="action" value="dof_sil">
</form>

</div><!-- /s-body -->
<style>
@media(max-width:700px){.kk-grid,.ak-grid,.dg-grid{grid-template-columns:1fr!important}.balik-grid{grid-template-columns:1fr 1fr!important}}
</style>

<script>
var dtabs = ['analiz','onlem','kok_neden','aksiyon','dogrulama','dokumanlar'];

document.getElementById('dofSilBtn').addEventListener('click', function(){
    var no   = this.dataset.no;
    var dcnt = parseInt(this.dataset.dcnt);
    var msg  = '"' + no + '" DOF kaydini silmek istiyorsunuz.\n';
    if(dcnt > 0) msg += dcnt + ' dokuman da silinecek.\n';
    msg += '\nGERI ALINAMAZ. Devam?';
    if(!confirm(msg)) return;
    var girilen = prompt('Onaylamak icin DOF numarasini girin:\n\n' + no);
    if(girilen === null) return;
    if(girilen.trim().toUpperCase() !== no.toUpperCase()){
        alert('Eslesmed. Iptal.');
        return;
    }
    document.getElementById('dofSilForm').submit();
});

function tabGoster(id){
    dtabs.forEach(function(t){
        document.getElementById('tab_'+t).style.display = t===id ? 'block' : 'none';
        var b = document.getElementById('dtab_'+t);
        if(b){ b.style.background = t===id ? 'var(--t)' : 'var(--kenar-a)'; b.style.color = t===id ? '#fff' : 'var(--m)'; }
    });
}

function modalKapat(id){ document.getElementById(id).style.display = 'none'; }
function dokModalAc()  { document.getElementById('dokModal').style.display = 'flex'; }
</script>
