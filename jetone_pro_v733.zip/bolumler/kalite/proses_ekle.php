<?php
/**
 * JETONE.PRO — Kalite Proses Kontrol Başlat / Ekle
 * bolumler/kalite/proses_ekle.php
 * panel.php: 'kalite-proses-ekle' => 'bolumler/kalite/proses_ekle.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$kul      = Auth::kullanici();
$tiger_ok = ($tigerdb_pdo !== null);

// ── URL parametreleri ──────────────────────────────────────────
$urun_kodu = trim($_GET['urun_kodu'] ?? '');
$istasyon  = trim($_GET['istasyon']  ?? '');
$form_acik = ($urun_kodu !== '' && $istasyon !== '');

// ── Hat sırası ────────────────────────────────────────────────
$hat_sirasi = [
    'EN-110-01','EN-132-01','EN-80-01','EN-130-01','EN-160-01',
    'EN-201-01','EN-202-01','EN-301-01','EN-302-01','EN-350-01',
    'EN-420-01','EN-500-01','EN-650-01','EN-162-01','EN-131-01',
    'EN-161-01','EN-530-01','EN-650-02','EN-450-01','EN-500-02',
    'EN-260-01','EN-410-01','EN-500-03','EN-700-01','EN-180-01',
    'EN-280-01','EN-650-03','EN-650-04','EN-650-05','EN-650-06',
    'EN-850-01','EN-850-02',
];

$hat_renk = [
    'EN-110-01'=>'#FEE2E2','EN-132-01'=>'#DBEAFE','EN-80-01' =>'#D1FAE5',
    'EN-130-01'=>'#FEF3C7','EN-160-01'=>'#EDE9FE','EN-201-01'=>'#CFFAFE',
    'EN-202-01'=>'#FCE7F3','EN-301-01'=>'#E0F2FE','EN-302-01'=>'#ECFDF5',
    'EN-350-01'=>'#FEF9C3','EN-420-01'=>'#FFEDD5','EN-500-01'=>'#F1F5F9',
    'EN-650-01'=>'#F3E8FF','EN-162-01'=>'#E0F7FA','EN-131-01'=>'#FFF3CD',
    'EN-161-01'=>'#FEF08A','EN-530-01'=>'#FED7AA','EN-650-02'=>'#C7D2FE',
    'EN-450-01'=>'#CCFBF1','EN-500-02'=>'#FFE4E6','EN-260-01'=>'#BFDBFE',
    'EN-410-01'=>'#FDE68A','EN-500-03'=>'#BBF7D0','EN-700-01'=>'#FECACA',
    'EN-180-01'=>'#A7F3D0','EN-280-01'=>'#BAE6FD','EN-650-03'=>'#FDE68A',
    'EN-650-04'=>'#FBCFE8','EN-650-05'=>'#FED7AA','EN-650-06'=>'#DDD6FE',
    'EN-850-01'=>'#FECDD3','EN-850-02'=>'#FEF08A',
];

// ── VERİ HAZIRLAMA (form açıkken) ─────────────────────────────
$urun_adi_goster   = '';
$map_gramaj_goster = '';
$map_cevrim_goster = '';
$map_tonaj_goster  = '';
$gramaj_kaynak     = '-';
$cevrim_kaynak     = '-';
$tonaj_kaynak      = '-';
$db_cevrim_sabit   = false;
$db_tonaj_sabit    = false;
$op_map            = [];
$istasyon_list     = [];
$plan_rows         = [];

// İstasyon listesi (her zaman)
try {
    $st = $db->prepare("SELECT * FROM is_istasyonlari WHERE istasyon_group='ENJEKSİYON' ORDER BY istasyon_kodu");
    $st->execute();
    $istasyon_list = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

if ($form_acik) {
    // 1. malzemeler tablosundan çek
    $drawcek = [];
    try {
        $s = $db->prepare("SELECT * FROM malzemeler WHERE malzeme_kod = ? LIMIT 1");
        $s->execute([$urun_kodu]);
        $drawcek = $s->fetch(PDO::FETCH_ASSOC) ?: [];
        $urun_adi_goster = $drawcek['malzeme_adi'] ?? ($drawcek['malzeme_ad'] ?? '');
    } catch (Throwable $e) {}

    // mps_plan'dan ürün adı (yoksa)
    if ($urun_adi_goster === '') {
        try {
            $s = $db->prepare("SELECT urun_adi FROM mps_plan WHERE urun_kodu=? LIMIT 1");
            $s->execute([$urun_kodu]);
            $urun_adi_goster = $s->fetchColumn() ?: '';
        } catch (Throwable $e) {}
    }

    // günlük_plan'dan ürün adı (yoksa)
    if ($urun_adi_goster === '') {
        try {
            $s = $db->prepare("SELECT stok_adı FROM günlük_plan WHERE stok_kodu=? LIMIT 1");
            $s->execute([$urun_kodu]);
            $urun_adi_goster = $s->fetchColumn() ?: '';
        } catch (Throwable $e) {}
        // stok_adı alan adı farklıysa
        if ($urun_adi_goster === '') {
            try {
                $s = $db->prepare("SELECT stok_adi FROM günlük_plan WHERE stok_kodu=? LIMIT 1");
                $s->execute([$urun_kodu]);
                $urun_adi_goster = $s->fetchColumn() ?: '';
            } catch (Throwable $e) {}
        }
    }

    $db_gramaj    = (($drawcek['map_gramaj']       ?? '') !== '') ? $drawcek['map_gramaj']       : null;
    $db_cevrim    = (($drawcek['map_cevrim']        ?? '') !== '') ? $drawcek['map_cevrim']        : null;
    $db_map_tonaj = (($drawcek['map_makina_tonaj']  ?? '') !== '') ? $drawcek['map_makina_tonaj']  : null;

    // 2. Tiger'dan — sadece DB'de boş olanlar için
    if ($tiger_ok && ($db_gramaj === null || $db_cevrim === null || $db_map_tonaj === null)) {

        // ── GRAMAJ — aktif revizyon (BMR.ACTIVE=1, BOM.ACTIVE=0) ──────────
        if ($db_gramaj === null) {
            try {
                $s = $tigerdb_pdo->prepare("
                    SELECT IT2.STGRPCODE gg, BML.AMOUNT amt
                    FROM  dbo.LG_222_BOMLINE  BML WITH(NOLOCK)
                    JOIN  dbo.LG_222_BOMREVSN BMR WITH(NOLOCK) ON BML.BOMREVREF=BMR.LOGICALREF    AND BMR.ACTIVE=1
                    JOIN  dbo.LG_222_BOMASTER BOM WITH(NOLOCK) ON BMR.BOMMASTERREF=BOM.LOGICALREF AND BOM.ACTIVE=0
                    JOIN  dbo.LG_222_ITEMS    IT  WITH(NOLOCK) ON BOM.MAINPRODREF=IT.LOGICALREF
                    JOIN  dbo.LG_222_ITEMS    IT2 WITH(NOLOCK) ON BML.ITEMREF=IT2.LOGICALREF
                    WHERE IT.CODE=? AND BML.LINETYPE=0 AND IT.ACTIVE=0 AND IT2.ACTIVE=0
                      AND IT2.STGRPCODE IN ('Plastik HM','Masterbatch')
                ");
                $s->execute([$urun_kodu]);
                $raw = 0;
                foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if ($r['gg'] === 'Plastik HM') $raw += floatval($r['amt']) * 1000;
                }
                if ($raw > 0) $db_gramaj = $raw;
            } catch (Throwable $e) {}
        }

        // ── ÇEVRİM — verim_ekle.php ile BİREBİR AYNI sorgu ───────────────
        // IT.ACTIVE filtresi YOK — verim_ekle'de bu çalışıyor
        if ($db_cevrim === null || $db_map_tonaj === null) {
            try {
                $s = $tigerdb_pdo->prepare("
                    SELECT TOP 1
                        dbo.LG_INTTOTIME2(OPR.RUNTIME) AS CEVRIM_SN,
                        OPR.BATCHQUANTITY              AS PARTI
                    FROM dbo.LG_222_OPRTREQ  AS OPR
                    LEFT JOIN dbo.LG_222_OPERTION  AS OP  ON OP.LOGICALREF   = OPR.OPERATIONREF
                    LEFT JOIN dbo.LG_222_RTNGLINE  AS RTL ON RTL.OPERATIONREF = OP.LOGICALREF
                    LEFT JOIN dbo.LG_222_ROUTING   AS RT  ON RT.LOGICALREF   = RTL.ROUTINGREF
                    LEFT JOIN dbo.LG_222_BOMREVSN  AS BMR ON BMR.ROUTINGREF  = RT.LOGICALREF
                    LEFT JOIN dbo.LG_222_BOMASTER  AS BOM ON BOM.LOGICALREF  = BMR.BOMMASTERREF
                    LEFT JOIN dbo.LG_222_ITEMS     AS IT  ON IT.LOGICALREF   = BOM.MAINPRODREF
                    WHERE IT.CODE = ?
                      AND OP.CODE <> 'SKOP.001'
                      AND OPR.RUNTIME > 0
                    ORDER BY OPR.RUNTIME DESC
                ");
                $s->execute([$urun_kodu]);
                $row = $s->fetch(PDO::FETCH_ASSOC);
                if ($row && intval($row['CEVRIM_SN']) > 0) {
                    $db_cevrim = intval($row['CEVRIM_SN']);
                    $op_map[$istasyon] = ['cevrim' => $db_cevrim, 'tonaj' => 0];
                }
            } catch (Throwable $e) {}
        }
    }

    // Tonaj → is_istasyonlari'ndan seçili istasyon kodu üzerinden
    if (($db_map_tonaj === null || $db_map_tonaj == 0) && $istasyon !== '') {
        try {
            $s = $db->prepare("SELECT istasyon_mak_group FROM is_istasyonlari WHERE istasyon_kodu=? LIMIT 1");
            $s->execute([$istasyon]);
            $t = $s->fetchColumn();
            if ($t !== false && $t !== '' && (int)$t > 0) {
                $db_map_tonaj = (int)$t;
                if (isset($op_map[$istasyon])) $op_map[$istasyon]['tonaj'] = (int)$t;
            }
        } catch (Throwable $e) {}
    }

    // Tonaj hâlâ 0 → hat kodundan regex ile çıkar: EN-350-01 → 350
    if (($db_map_tonaj === null || $db_map_tonaj == 0) && $istasyon !== '') {
        if (preg_match('/^EN-(\d+)-/', $istasyon, $m)) {
            $db_map_tonaj = (int)$m[1];
            if (isset($op_map[$istasyon])) $op_map[$istasyon]['tonaj'] = (int)$m[1];
        }
    }

    // Tonaj 10'un katına aşağı yuvarla: 202→200, 131→130, 653→650
    if ($db_map_tonaj !== null && $db_map_tonaj > 0) {
        $db_map_tonaj = (int)(floor($db_map_tonaj / 10) * 10);
        if (isset($op_map[$istasyon])) $op_map[$istasyon]['tonaj'] = $db_map_tonaj;
    }

    // Gösterim + kaynak
    $map_gramaj_goster = $db_gramaj    !== null ? str_replace(',', '.', (string)$db_gramaj)    : '';
    $map_cevrim_goster = $db_cevrim    !== null ? str_replace(',', '.', (string)$db_cevrim)    : '';
    $map_tonaj_goster  = $db_map_tonaj !== null ? str_replace(',', '.', (string)$db_map_tonaj) : '';

    $gramaj_kaynak  = (($drawcek['map_gramaj']      ?? '') !== '') ? 'DB' : ($map_gramaj_goster ? 'Tiger' : '-');
    $cevrim_kaynak  = (($drawcek['map_cevrim']       ?? '') !== '') ? 'DB' : ($map_cevrim_goster ? 'Tiger' : '-');
    $tonaj_kaynak   = (($drawcek['map_makina_tonaj'] ?? '') !== '') ? 'DB' : ($map_tonaj_goster  ? 'Tiger' : '-');
    $db_cevrim_sabit = ($cevrim_kaynak === 'DB');
    $db_tonaj_sabit  = ($tonaj_kaynak  === 'DB');

} else {
    // LİSTE: önce mps_plan, yoksa günlük_plan tablosundan çek
    $plan_kaynagi = 'mps_plan'; // debug için
    try {
        $raw = $db->query("
            SELECT id, hat_kodu, urun_kodu, urun_adi, durum, hat_sira_no
            FROM mps_plan
            WHERE durum NOT IN ('Tamamlandı','İptal','Tamamlandi','Iptal')
              AND hat_kodu LIKE 'EN-%' AND urun_kodu != '__DURUS__'
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { $raw = []; }

    // mps_plan boş ya da yok → günlük_plan'a bak
    if (empty($raw)) {
        $plan_kaynagi = 'günlük_plan';
        try {
            $raw2 = $db->query("SELECT * FROM günlük_plan ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
            // günlük_plan → mps_plan field mapping
            foreach ($raw2 as $r) {
                $raw[] = [
                    'id'          => $r['id']          ?? 0,
                    'hat_kodu'    => $r['hat']          ?? ($r['hat_kodu']  ?? ''),
                    'urun_kodu'   => $r['stok_kodu']    ?? ($r['urun_kodu'] ?? ''),
                    'urun_adi'    => $r['stok_adı']     ?? ($r['stok_adi']  ?? ($r['urun_adi'] ?? '')),
                    'durum'       => $r['durum']        ?? '',
                    'hat_sira_no' => $r['hat_sira_no']  ?? 0,
                ];
            }
        } catch (Throwable $e) { $raw = []; }
    }

    $hat_sira_idx = array_flip($hat_sirasi);
    usort($raw, function($a, $b) use ($hat_sira_idx) {
        $ia = $hat_sira_idx[$a['hat_kodu']] ?? 999;
        $ib = $hat_sira_idx[$b['hat_kodu']] ?? 999;
        return $ia !== $ib ? $ia - $ib : (int)($a['hat_sira_no']??0) - (int)($b['hat_sira_no']??0);
    });
    $plan_rows = $raw;
}

function durum_roz(string $d): string {
    $map = [
        'Devam Ediyor'=>['#DBEAFE','#1D4ED8'],'Devam Edecek'=>['#DBEAFE','#1D4ED8'],
        'Planlandı'  =>['#FEF9C3','#92400E'],'Sıradaki İş' =>['#FEF9C3','#92400E'],
        'Beklemede'  =>['#FEF9C3','#92400E'],'Tamamlandı'  =>['#D1FAE5','#065F46'],
    ];
    $c = $map[$d] ?? ['#F1F5F9','#334155'];
    return "<span style=\"background:{$c[0]};color:{$c[1]};padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700\">"
         . htmlspecialchars($d) . "</span>";
}

$kaynak_roz = function(string $k): string {
    $bg = $k==='DB' ? '#D1FAE5' : ($k==='Tiger' ? '#FEF9C3' : '#F1F5F9');
    $fg = $k==='DB' ? '#065F46' : ($k==='Tiger' ? '#92400E' : '#64748B');
    return "<span style=\"background:$bg;color:$fg;padding:1px 6px;border-radius:10px;font-size:10px;font-weight:700\">$k</span>";
};
?>

<style>
@media(max-width:768px){.proses-grid{grid-template-columns:1fr!important}.proses-grid-3{grid-template-columns:1fr!important}}
.kriter-sel{transition:border-color .15s}
.kriter-ok  {border-color:#22C55E!important;background:#F0FDF4}
.kriter-nok {border-color:#EF4444!important;background:#FEF2F2}
.kriter-na  {border-color:#94A3B8!important;background:#F8FAFC}
</style>

<!-- ── Başlık ──────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">✅ Proses Kontrol Başlat</h1>
    <div class="s-yol">Kalite /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kontrol" style="color:var(--t)">Proses Kontrol</a>
      <?php if ($form_acik): ?>
        / <b><?= htmlspecialchars($urun_kodu) ?> — <?= htmlspecialchars($istasyon) ?></b>
      <?php else: ?>
        / <b>Plan Listesi</b>
      <?php endif; ?>
    </div>
  </div>
  <?php if ($form_acik): ?>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kontrol" class="btn btn-b btn-sm">📋 Liste</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-proses-ekle" class="btn btn-b btn-sm">← Plana Dön</a>
  </div>
  <?php endif; ?>
</div>

<div class="s-body">

<?php if (!$tiger_ok): ?>
<div style="background:var(--hat-a);color:var(--hat);border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-size:12.5px;font-weight:700">
  ⚠️ Tiger ERP bağlantısı yok — gramaj/çevrim/tonaj bilgileri yüklenemedi.
</div>
<?php endif; ?>

<?php if ($form_acik): ?>
<!-- ══════════════════════════════════════════════════════════════
     KONTROL FORMU — verim_ekle.php stilinde
══════════════════════════════════════════════════════════════ -->

<div style="display:grid;grid-template-columns:320px 1fr;gap:18px;align-items:start" class="proses-grid">

  <!-- Sol bilgi kartı -->
  <div class="kart" style="border-top:4px solid var(--t);min-width:0">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">Seçili Ürün</div>
    <div style="font-size:17px;font-weight:800;color:var(--t);margin-bottom:2px;word-break:break-all"><?= htmlspecialchars($urun_kodu) ?></div>
    <div style="font-size:13px;font-weight:600;margin-bottom:14px;color:var(--m);line-height:1.4;word-break:break-word" id="lblUrunAdi">
      <?= htmlspecialchars($urun_adi_goster) ?>
    </div>
    <div style="display:flex;flex-direction:column;gap:8px;font-size:12.5px;border-top:1px solid var(--kenar);padding-top:12px">
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2)">Hat / Makina</span>
        <span style="font-weight:700"><?= htmlspecialchars($istasyon) ?></span>
      </div>
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2)">Map Gramaj</span>
        <span style="font-weight:700">
          <?= $map_gramaj_goster ? number_format((float)$map_gramaj_goster, 2, ',', '.') . ' gr' : '—' ?>
          <?= $kaynak_roz($gramaj_kaynak) ?>
        </span>
      </div>
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2)">Map Çevrim</span>
        <span style="font-weight:700">
          <span id="lblMapCevrim"><?= $map_cevrim_goster ? htmlspecialchars($map_cevrim_goster) . ' sn' : '—' ?></span>
          <?= $kaynak_roz($cevrim_kaynak) ?>
        </span>
      </div>
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2)">Map Tonaj</span>
        <span style="font-weight:700" id="lblMapTonaj">
          <?= $map_tonaj_goster ? htmlspecialchars($map_tonaj_goster) . ' ton' : '—' ?>
          <?= $kaynak_roz($tonaj_kaynak) ?>
        </span>
      </div>
    </div>

    <!-- Tiger op_map debug (geliştirme) -->
    <?php if (!empty($op_map)): ?>
    <div style="margin-top:12px;border-top:1px solid var(--kenar);padding-top:10px">
      <div style="font-size:10px;color:var(--m2);font-weight:700;margin-bottom:6px">Tiger op_map (<?= count($op_map) ?> hat)</div>
      <?php foreach ($op_map as $hat => $op): ?>
      <div style="font-size:10px;font-family:monospace;color:<?= $hat===$istasyon?'var(--t)':'var(--m2)' ?>;font-weight:<?= $hat===$istasyon?'700':'400' ?>">
        <?= htmlspecialchars($hat) ?>: <?= $op['cevrim'] ?>sn / <?= $op['tonaj'] ?>t
        <?= $hat===$istasyon ? ' ← seçili' : '' ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if ($tiger_ok && empty($op_map) && $form_acik): ?>
    <div style="margin-top:8px;font-size:10px;color:var(--hat);font-weight:700">
      ⚠ Tiger bağlı ama bu ürün için çevrim bulunamadı.
    </div>
    <?php endif; ?>

    <!-- Fark özeti kutusu -->
    <div id="farkKutu" style="display:none;margin-top:14px;background:var(--bil-a);border:1px solid var(--bil);border-radius:var(--r);padding:10px 12px">
      <div style="font-size:11px;font-weight:700;color:#0369A1;margin-bottom:6px">📊 Fark Özeti</div>
      <div id="farkGramaj" style="font-size:12px;color:var(--m)"></div>
      <div id="farkCevrim" style="font-size:12px;color:var(--m);margin-top:3px"></div>
    </div>
  </div>

  <!-- Sağ form kartı -->
  <div class="kart">
    <div style="font-size:15px;font-weight:800;margin-bottom:16px">Proses Kontrol Bilgilerini Girin</div>
    <form id="prosesForm">
      <input type="hidden" name="urun_kodu"  value="<?= htmlspecialchars($urun_kodu) ?>">
      <input type="hidden" name="urun_adi"   id="h_urun_adi" value="<?= htmlspecialchars($urun_adi_goster) ?>">
      <input type="hidden" name="ekleyen"    value="<?= htmlspecialchars($kul['ad_soyad'] ?? $kul['email'] ?? '') ?>">
      <input type="hidden" name="map_gramaj" value="<?= htmlspecialchars($map_gramaj_goster) ?>">
      <input type="hidden" name="map_cevrim" id="h_map_cevrim" value="<?= htmlspecialchars($map_cevrim_goster) ?>">
      <input type="hidden" name="map_tonaj"  id="h_map_tonaj"  value="<?= htmlspecialchars($map_tonaj_goster) ?>">

      <!-- Satır 1: Ürün adı + Vardiya -->
      <div class="form-grid-2 proses-grid">
        <div class="form-grup">
          <label class="form-et">Ürün Adı</label>
          <input class="form-alan" type="text" name="urun_adi_goster" readonly
                 value="<?= htmlspecialchars($urun_adi_goster) ?>"
                 style="background:var(--kenar-a)">
        </div>
        <div class="form-grup">
          <label class="form-et">Vardiya <span class="zorunlu">*</span></label>
          <select class="form-alan" name="vardiya" id="vardiyaSelect" required>
            <option value="1">1. Vardiya (08:00–16:00)</option>
            <option value="2">2. Vardiya (16:00–24:00)</option>
            <option value="3">3. Vardiya (24:00–08:00)</option>
          </select>
        </div>
      </div>

      <!-- Satır 2: Makina + Tarih -->
      <div class="form-grid-2 proses-grid">
        <div class="form-grup">
          <label class="form-et">Makina / Hat</label>
          <input class="form-alan" type="text" name="istasyon_kodu" readonly
                 value="<?= htmlspecialchars($istasyon) ?>"
                 style="background:var(--kenar-a)">
        </div>
        <div class="form-grup">
          <label class="form-et">Tarih <span class="zorunlu">*</span></label>
          <input class="form-alan" type="date" name="tarih" value="<?= date('Y-m-d') ?>" required>
        </div>
      </div>

      <!-- Satır 3: Gramaj + Çevrim -->
      <div class="form-grid-2 proses-grid">
        <div class="form-grup">
          <label class="form-et">
            Ölçülen Gramaj (gr) <span class="zorunlu">*</span>
            <?php if ($map_gramaj_goster): ?>
            <span style="color:var(--m2);font-weight:400;font-size:11px">
              — Map: <?= number_format((float)$map_gramaj_goster, 2, ',', '.') ?> gr <?= $kaynak_roz($gramaj_kaynak) ?>
            </span>
            <?php endif; ?>
          </label>
          <input class="form-alan" id="inp_gramaj" name="gramaj" type="text"
                 placeholder="Gramaj giriniz..." required>
        </div>
        <div class="form-grup">
          <label class="form-et">
            Ölçülen Çevrim (sn) <span class="zorunlu">*</span>
            <?php if ($map_cevrim_goster): ?>
            <span style="color:var(--m2);font-weight:400;font-size:11px">
              — Map: <?= htmlspecialchars($map_cevrim_goster) ?> sn <?= $kaynak_roz($cevrim_kaynak) ?>
            </span>
            <?php endif; ?>
          </label>
          <input class="form-alan" id="inp_cevrim" name="cevrim" type="text"
                 value="<?= $map_cevrim_goster ? str_replace('.', ',', $map_cevrim_goster) : '' ?>"
                 placeholder="Çevrim sn giriniz..." required>
        </div>
      </div>

      <!-- Makina tonajı -->
      <div class="form-grid-2 proses-grid">
        <div class="form-grup">
          <label class="form-et">
            Makina Tonajı
            <?php if ($map_tonaj_goster): ?>
            <span style="color:var(--m2);font-weight:400;font-size:11px">
              — Map: <?= htmlspecialchars($map_tonaj_goster) ?> ton <?= $kaynak_roz($tonaj_kaynak) ?>
            </span>
            <?php endif; ?>
          </label>
          <input class="form-alan" id="inp_tonaj" name="makina_tonaj" type="text"
                 value="<?= htmlspecialchars($map_tonaj_goster) ?>"
                 placeholder="Makina tonajı..." readonly style="background:var(--kenar-a)">
        </div>
        <div></div>
      </div>

      <!-- ── GÖRSEL KONTROL KRİTERLERİ ────────────────────────── -->
      <div style="border-top:1px solid var(--kenar);margin:16px 0 14px;padding-top:14px">
        <div style="font-size:14px;font-weight:800;margin-bottom:12px">🔍 Görsel Kontrol Kriterleri</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px" class="proses-grid-3">
          <?php
          $kriterler = [
              ['cizik_capak', 'Çizik — Çapak'],
              ['kirik_catlak','Kırık — Çatlak'],
              ['cokuntu',     'Çöküntü'],
              ['hm_lekesi',   'Hammadde Lekesi'],
              ['yag_lekesi',  'Yağ Lekesi'],
              ['eksik_enj',   'Eksik Enjeksiyon'],
              ['serpme',      'Serpme'],
              ['gazlanma',    'Gazlanma'],
              ['yanma',       'Yanma'],
              ['tirnak_pim',  'Tırnak — Pim'],
              ['harelenme',   'Harelenme'],
          ];
          foreach ($kriterler as $k): ?>
          <div class="form-grup" style="margin:0">
            <label class="form-et" style="font-size:12px"><?= $k[1] ?></label>
            <select class="form-alan kriter-sel kriter-ok" name="<?= $k[0] ?>"
                    onchange="kriterRenk(this)"
                    style="font-size:12px;padding:5px 10px;font-weight:700">
              <option value="ok"  selected>✓ OK</option>
              <option value="nok">✗ NOK</option>
              <option value="na" >— N/A</option>
            </select>
          </div>
          <?php endforeach; ?>

          <!-- KARAR -->
          <div class="form-grup" style="margin:0">
            <label class="form-et" style="font-size:12px;font-weight:800;color:var(--t)">⚖️ KARAR</label>
            <select class="form-alan kriter-sel kriter-ok" name="sonuc" id="inp_sonuc"
                    onchange="kriterRenk(this)"
                    style="font-size:13px;padding:5px 10px;font-weight:800;border-width:2px">
              <option value="ok"  selected>✓ OK</option>
              <option value="nok">✗ NOK</option>
              <option value="na" >— N/A</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Açıklama -->
      <div class="form-grup">
        <label class="form-et">Açıklama</label>
        <textarea class="form-alan" name="aciklama" rows="3"
                  placeholder="Kontrolle ilgili notlarınızı giriniz..."></textarea>
      </div>

      <!-- Butonlar -->
      <div class="form-footer">
        <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-proses-ekle" class="btn btn-b">İptal</a>
        <button type="submit" id="submitBtn" class="btn btn-t">💾 Kaydet</button>
      </div>

    </form>
  </div><!-- /sağ kart -->
</div><!-- /grid -->

<?php else: ?>
<!-- ══════════════════════════════════════════════════════════════
     PLAN LİSTESİ
══════════════════════════════════════════════════════════════ -->

<!-- Manuel giriş -->
<div class="kart" style="margin-bottom:16px;border-left:4px solid var(--bas)">
  <div style="font-weight:800;margin-bottom:12px">
    🔧 Manuel Kontrol Başlat
    <span style="font-size:12px;color:var(--m2);font-weight:400"> — Günlük planda olmayan ürünler için</span>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end" class="proses-grid">
    <div class="form-grup" style="margin:0">
      <label class="form-et">Ürün Kodu <span class="zorunlu">*</span></label>
      <input class="form-alan" id="manuelKod" type="text" placeholder="Ürün kodunu giriniz...">
    </div>
    <div class="form-grup" style="margin:0">
      <label class="form-et">Makine / Hat <span class="zorunlu">*</span></label>
      <select class="form-alan" id="manuelHat">
        <option value="">— Seçiniz —</option>
        <?php foreach ($hat_sirasi as $hat): ?>
        <option value="<?= htmlspecialchars($hat) ?>"><?= htmlspecialchars($hat) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <button onclick="manuelBaslat()" class="btn btn-t">▶ Başlat</button>
    </div>
  </div>
</div>

<!-- Plan tablosu -->
<?php if (empty($plan_rows)): ?>
<div class="kart" style="text-align:center;padding:48px;color:var(--m2)">
  <div style="font-size:36px;margin-bottom:8px">📋</div>
  <div style="font-weight:700">Aktif enjeksiyon planı bulunamadı.</div>
</div>
<?php else: ?>
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;font-size:14px">
      🏭 Enjeksiyon Plan Listesi
      <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($plan_rows) ?> iş</span>
    </div>
    <div style="font-size:12px;color:var(--m2)">Kontrol başlatmak için ➕ Başlat'a tıklayın</div>
  </div>
  <div style="overflow-x:auto">
    <table id="prozesTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px">Başlat</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px">Hat</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px">Ürün Kodu</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px">Ürün Adı</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px">Durum</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($plan_rows as $r):
          $bg  = $hat_renk[$r['hat_kodu']] ?? '#fff';
          $url = BASE_URL . '/panel.php?sayfa=kalite-proses-ekle'
               . '&urun_kodu=' . urlencode($r['urun_kodu'])
               . '&istasyon='  . urlencode($r['hat_kodu']);
        ?>
        <tr style="background:<?= $bg ?>">
          <td>
            <a href="<?= $url ?>" class="btn btn-sm btn-t" style="text-decoration:none">➕ Başlat</a>
          </td>
          <td style="font-weight:700;white-space:nowrap"><?= htmlspecialchars($r['hat_kodu']) ?></td>
          <td>
            <code style="background:rgba(0,0,0,.06);padding:1px 6px;border-radius:3px;font-size:12px;font-weight:700">
              <?= htmlspecialchars($r['urun_kodu']) ?>
            </code>
          </td>
          <td style="min-width:180px"><?= htmlspecialchars($r['urun_adi'] ?? '') ?></td>
          <td><?= durum_roz($r['durum'] ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><th></th><th>Hat</th><th>Ürün Kodu</th><th>Ürün Adı</th><th>Durum</th></tr>
      </tfoot>
    </table>
  </div>
</div>
<?php endif; ?>
<?php endif; ?>

</div><!-- /s-body -->

<!-- ── Scripts ─────────────────────────────────────────────────────────── -->
<script>
/* Vardiya otomatik seç */
(function(){
    var s = document.getElementById('vardiyaSelect');
    if (!s) return;
    var h = new Date().getHours();
    s.value = (h>=8&&h<16)?'1':(h>=16)?'2':'3';
})();

/* Tiger op haritası */
var tigerOpMap  = <?= json_encode($op_map, JSON_UNESCAPED_UNICODE) ?>;
var seciliHat   = "<?= addslashes($istasyon) ?>";
var cevrimSabit = <?= $db_cevrim_sabit ? 'true' : 'false' ?>;
var tonajSabit  = <?= $db_tonaj_sabit  ? 'true' : 'false' ?>;

/* Sayfa yüklenince — seçili hat için sol karttaki değerleri doldur */
(function(){
    if (!seciliHat) return;
    var op = tigerOpMap[seciliHat];
    if (!op) return;

    // Sol kart — map çevrim
    if (!cevrimSabit && op.cevrim) {
        var lbl = document.getElementById('lblMapCevrim');
        if (lbl) lbl.textContent = op.cevrim + ' sn';
        var hid = document.getElementById('h_map_cevrim');
        if (hid) hid.value = op.cevrim;
        var inp = document.getElementById('inp_cevrim');
        if (inp && !inp.value) inp.value = op.cevrim.toString().replace('.', ',');
    }
    // Sol kart — map tonaj
    if (!tonajSabit && op.tonaj) {
        var lblT = document.getElementById('lblMapTonaj');
        if (lblT) lblT.textContent = op.tonaj + ' ton';
        var hidT = document.getElementById('h_map_tonaj');
        if (hidT) hidT.value = op.tonaj;
        var inpT = document.getElementById('inp_tonaj');
        if (inpT) { inpT.value = op.tonaj; inpT.removeAttribute('readonly'); inpT.style.background = ''; }
    }
})();

/* Virgül düzeltme */
['inp_gramaj','inp_cevrim'].forEach(function(id){
    var el = document.getElementById(id);
    if(el) el.addEventListener('input', function(){ this.value = this.value.replace('.',','); });
});

/* Fark hesapla */
function hesaplaFark(){
    var mapGr  = parseFloat("<?= str_replace(',','.',$map_gramaj_goster) ?>") || 0;
    var mapCv  = parseFloat("<?= str_replace(',','.',$map_cevrim_goster) ?>") || 0;

    var gr = parseFloat((document.getElementById('inp_gramaj')?.value||'').replace(',','.')) || 0;
    var cv = parseFloat((document.getElementById('inp_cevrim')?.value||'').replace(',','.')) || 0;

    if(!mapGr || !gr) return;
    var fgr = gr - mapGr;
    var fcv = mapCv ? cv - mapCv : null;

    var kutu = document.getElementById('farkKutu');
    if(kutu){ kutu.style.display='block'; }

    var renkFark = function(f){ return f===0?'#059669':f>0?'#D97706':'#DC2626'; };
    var fmt = function(v){ return (v>0?'+':'')+v.toFixed(2).replace('.',','); };

    var eg = document.getElementById('farkGramaj');
    if(eg) eg.innerHTML = 'Gramaj fark: <b style="color:'+renkFark(fgr)+'">'+fmt(fgr)+' gr</b>';

    if(fcv !== null){
        var ec = document.getElementById('farkCevrim');
        if(ec) ec.innerHTML = 'Çevrim fark: <b style="color:'+renkFark(fcv)+'">'+fmt(fcv)+' sn</b>';
    }
}

document.getElementById('inp_gramaj')?.addEventListener('input', hesaplaFark);
document.getElementById('inp_cevrim')?.addEventListener('input', hesaplaFark);
hesaplaFark();

/* Kriter renk */
function kriterRenk(sel){
    sel.className = sel.className.replace(/kriter-(ok|nok|na)/g,'');
    var v = sel.value;
    sel.classList.add(v==='ok'?'kriter-ok':v==='nok'?'kriter-nok':'kriter-na');
}

/* Form gönderimi */
(function(){
    var form = document.getElementById('prosesForm');
    if(!form) return;
    form.addEventListener('submit', function(e){
        e.preventDefault();
        var btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.textContent = '⏳ Kaydediliyor...';

        fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/proses_kaydet.php',{
            method: 'POST',
            headers: {'X-Requested-With':'XMLHttpRequest'},
            body: new FormData(form)
        })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if(d.ok){
                alert('✅ '+d.msg);
                window.location.href='<?= BASE_URL ?>/panel.php?sayfa=kalite-kontrol';
            } else {
                alert('❌ '+(d.msg||'Hata oluştu'));
                btn.disabled=false; btn.textContent='💾 Kaydet';
            }
        })
        .catch(function(){ alert('Bağlantı hatası!'); btn.disabled=false; btn.textContent='💾 Kaydet'; });
    });
})();

/* Manuel başlat */
function manuelBaslat(){
    var kod = (document.getElementById('manuelKod')?.value||'').trim();
    var hat = document.getElementById('manuelHat')?.value||'';
    if(!kod){ alert('Ürün kodu giriniz!'); return; }
    if(!hat){ alert('Makine seçiniz!'); return; }
    window.location.href='<?= BASE_URL ?>/panel.php?sayfa=kalite-proses-ekle'
        +'&urun_kodu='+encodeURIComponent(kod)
        +'&istasyon=' +encodeURIComponent(hat);
}
</script>

<?php if (!$form_acik): ?>
<script>
$(document).ready(function(){
    var tbl = $('#prozesTablo').DataTable({
        language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
        scrollY:550, scrollX:true, scrollCollapse:true, paging:false,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'ProsesPlan_<?= date('Ymd') ?>'}],
        drawCallback: function(){
          $('#prozesTablo thead th').each(function(){
            this.style.setProperty('background-color','#1E3A5F','important');
            this.style.setProperty('color','#ffffff','important');
          });
        },
        initComplete:function(){
            this.api().columns([1,2,3,4]).every(function(){
                var col=this;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
                    .appendTo($(col.footer()).empty())
                    .on('change',function(){
                        var v=$.fn.dataTable.util.escapeRegex($(this).val());
                        col.search(v?'^'+v+'$':'',true,false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var t=$('<div/>').html(d).text();
                    sel.append('<option value="'+t+'">'+(t.length>30?t.substr(0,30)+'...':t)+'</option>');
                });
            });
        }
    });
    $('#prozesTablo thead th').css({'background-color':'#1E3A5F','color':'#fff'});
});
</script>
<?php endif; ?>
