<?php
/**
 * GKK Red Takip — Kalite Görünümü (detay odaklı)
 * Route: kalite-gkk-red
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();
global $db;

require_once ROOT_DIR.'/islemler/kalite/gkk_red_surec.php'; // tabloları oluşturur — ama endpoint, direkt erişimde exit eder
// Tabloları garantilemek için
if($db) {
    try { gkk_tablolari_olustur($db); } catch(Throwable $e){}
}

$f_basl  = trim($_GET['basl']  ?? date('Y-m-d', strtotime('-3 months')));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));
$f_asama = trim($_GET['asama'] ?? '');

// Red kayıtları + süreç durumu
$redler = [];
if($db) {
    try {
        $w = ["DATE(g.kontrol_tarihi) BETWEEN ? AND ?", "g.sonuc='RED'"];
        $p = [$f_basl, $f_bitis];
        if($f_asama) { $w[] = "COALESCE(s.asama,'RED')=?"; $p[]=$f_asama; }
        $ws = implode(' AND ', $w);

        $st = $db->prepare("
            SELECT g.*, COALESCE(s.asama,'RED') AS surec_asama,
                   s.id AS surec_id, s.tedarikci, s.cari_kodu,
                   s.aksiyon_turu, s.sorumlu, s.planlanan_tarih, s.kapanma_tarihi,
                   (SELECT COUNT(*) FROM gkk_red_log l WHERE l.surec_id=s.id) AS log_sayisi,
                   (SELECT COUNT(*) FROM gkk_tedarikci_yanit y WHERE y.surec_id=s.id) AS yanit_sayisi
            FROM gkk_kontrol_sonuclari g
            LEFT JOIN gkk_red_surec s ON s.gkk_id=g.id
            WHERE $ws
            ORDER BY g.kontrol_tarihi DESC
        ");
        $st->execute($p);
        $redler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){}
}

// Tedarikçi eşlemi Tiger'dan (surec'te yoksa)
$ted_map = [];
if(!empty($redler) && $tigerdb_pdo) {
    try {
        $irsno_list = array_unique(array_filter(array_column($redler,'irsaliye_no')));
        if(!empty($irsno_list)) {
            $in = implode(',',array_fill(0,count($irsno_list),'?'));
            $ts = $tigerdb_pdo->prepare("SELECT F.FICHENO, C.DEFINITION_ AS CARI, C.CODE AS KOD
                FROM (SELECT FICHENO,CLIENTREF FROM LG_222_01_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1
                      UNION ALL SELECT FICHENO,CLIENTREF FROM LG_222_02_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1) F
                LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF");
            $ts->execute(array_merge($irsno_list,$irsno_list));
            foreach($ts->fetchAll(PDO::FETCH_ASSOC) as $r) $ted_map[$r['FICHENO']]=$r;
        }
    } catch(Throwable $e){}
}

$asamalar = [
    'RED'                        => ['emoji'=>'🔴','label'=>'Red Edildi',           'bg'=>'#FEE2E2','fg'=>'#7F1D1D'],
    'TEDARIKCI_BILDIRILDI'       => ['emoji'=>'📧','label'=>'Tedarikçi Bildirildi', 'bg'=>'#EDE9FE','fg'=>'#5B21B6'],
    'TEDARIKCI_YANIT_BEKLENIYOR' => ['emoji'=>'⏳','label'=>'Yanıt Bekleniyor',     'bg'=>'#FEF3C7','fg'=>'#92400E'],
    'TEDARIKCI_YANITI_ALINDI'    => ['emoji'=>'📩','label'=>'Yanıt Alındı',         'bg'=>'#DBEAFE','fg'=>'#1E40AF'],
    'AKSIYON_BELIRLENDI'         => ['emoji'=>'⚙️','label'=>'Aksiyon Belirlendi',   'bg'=>'#FFF7ED','fg'=>'#C2410C'],
    'GERCEKLESIYOR'              => ['emoji'=>'🔧','label'=>'Gerçekleşiyor',        'bg'=>'#ECFDF5','fg'=>'#065F46'],
    'KAPANDI'                    => ['emoji'=>'✅','label'=>'Kapandı',              'bg'=>'#F0FDF4','fg'=>'#166534'],
];

$aksiyon_turleri = [
    ''              => '— Seçin —',
    'IADE'          => '↩️ İade',
    'AYIKLAMA'      => '🔍 Ayıklama',
    'SARTLI_ONAY'   => '⚠️ Şartlı Onay',
    'YENİ_SEVKIYAT' => '🚚 Yeni Sevkiyat',
    'DIGER'         => '📋 Diğer',
];

// Özet
$ozet = array_fill_keys(array_keys($asamalar), 0);
foreach($redler as $r) $ozet[$r['surec_asama']] = ($ozet[$r['surec_asama']]??0)+1;
$toplam_acik = count(array_filter($redler, fn($r)=>$r['surec_asama']!=='KAPANDI'));
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔴 GKK Red Süreç Takibi</h1>
    <div class="s-yol">Kalite / <a href="?sayfa=kalite-gkk-liste" style="color:var(--t)">GKK</a> / <b>Red Takip</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="?sayfa=satinalma-gkk-red" class="btn" style="padding:8px 14px;font-size:12px;background:#4F46E5;color:#fff">📋 Satınalma Görünümü</a>
  </div>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:8px;margin-bottom:14px">
  <div class="kart" style="padding:12px 14px;border-left:4px solid #DC2626;text-align:center">
    <div style="font-size:22px;font-weight:900;color:#DC2626"><?=$toplam_acik?></div>
    <div style="font-size:10px;color:var(--m3);font-weight:700">Açık Süreç</div>
  </div>
  <?php foreach($asamalar as $k=>$a): if(!($ozet[$k]??0)) continue;?>
  <div class="kart" style="padding:10px 12px;border-left:3px solid <?=$a['fg']?>;background:<?=$a['bg']?>">
    <div style="font-size:18px;font-weight:900;color:<?=$a['fg']?>"><?=$ozet[$k]?></div>
    <div style="font-size:9px;font-weight:700;color:<?=$a['fg']?>"><?=$a['emoji']?> <?=$a['label']?></div>
  </div>
  <?php endforeach;?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:12px 16px;margin-bottom:12px">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <input type="hidden" name="sayfa" value="kalite-gkk-red">
    <div><label class="form-et" style="font-size:11px">Başlangıç</label><input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
    <div><label class="form-et" style="font-size:11px">Bitiş</label><input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
    <div>
      <label class="form-et" style="font-size:11px">Aşama</label>
      <select name="asama" class="form-alan" style="min-width:160px">
        <option value="">Tümü</option>
        <?php foreach($asamalar as $k=>$a):?>
        <option value="<?=$k?>" <?=$f_asama===$k?'selected':''?>><?=$a['emoji']?> <?=$a['label']?></option>
        <?php endforeach;?>
      </select>
    </div>
    <button type="submit" class="btn btn-t" style="padding:10px 16px">🔍 Ara</button>
    <a href="?sayfa=kalite-gkk-red" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">↺</a>
  </form>
</div>

<!-- Kartlar -->
<?php if(empty($redler)):?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">
  <div style="font-size:40px">✅</div><div style="font-weight:700;margin-top:8px">Red kaydı bulunamadı.</div>
</div>
<?php else:?>
<div style="display:grid;gap:10px">
<?php foreach($redler as $r):
  $asama_key = $r['surec_asama']??'RED';
  $a = $asamalar[$asama_key]??$asamalar['RED'];
  $ted = $ted_map[$r['irsaliye_no']]??null;
  $ted_adi = $r['tedarikci'] ?: ($ted['CARI']??'—');
  $ka = (int)($r['kontrol_adet']??0); $ha = (int)($r['hata_adet']??0);
  $oran = $ka>0 ? round(($ha/$ka)*100,1) : null;
  $oran_renk = $oran===null?'#6B7280':($oran>=50?'#DC2626':($oran>=20?'#F59E0B':'#16A34A'));
  $surec_id = $r['surec_id']??0;
?>
<div class="kart" style="padding:0;overflow:hidden;border-left:4px solid <?=$a['fg']?>">
  <!-- Başlık -->
  <div style="padding:12px 16px;background:<?=$a['bg']?>;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="display:flex;align-items:center;gap:10px">
      <span style="font-size:12px;font-weight:800;color:<?=$a['fg']?>"><?=$a['emoji']?> <?=$a['label']?></span>
      <span style="font-size:11px;font-family:monospace;color:var(--m2)"><?=htmlspecialchars($r['irsaliye_no'])?></span>
      <span style="font-size:11px;color:var(--m3)"><?=htmlspecialchars(substr($r['kontrol_tarihi'],0,10))?></span>
    </div>
    <div style="display:flex;gap:6px;align-items:center">
      <?php if($r['log_sayisi']??0):?><span style="font-size:10px;background:#fff;padding:2px 8px;border-radius:10px;color:var(--m3)"><?=$r['log_sayisi']?> log</span><?php endif;?>
      <?php if($r['yanit_sayisi']??0):?><span style="font-size:10px;background:#DBEAFE;padding:2px 8px;border-radius:10px;color:#1E40AF"><?=$r['yanit_sayisi']?> yanıt</span><?php endif;?>
      <button type="button" class="btn-gkk-detay" data-gkk-id="<?=$r['id']?>" data-surec-id="<?=$surec_id?>"
              style="padding:4px 12px;background:<?=$a['fg']?>;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
        ⚙️ Yönet
      </button>
    </div>
  </div>
  <!-- Bilgiler -->
  <div style="padding:12px 16px;display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:12px;font-size:11px">
    <div>
      <div style="color:var(--m3);font-size:10px;font-weight:700;margin-bottom:2px">TEDARİKÇİ</div>
      <div style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($ted_adi)?>"><?=htmlspecialchars($ted_adi)?></div>
    </div>
    <div>
      <div style="color:var(--m3);font-size:10px;font-weight:700;margin-bottom:2px">STOK KODU</div>
      <div style="font-family:monospace;font-weight:700"><?=htmlspecialchars($r['stok_kodu']??'')?></div>
      <div style="font-size:10px;color:var(--m3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars(substr($r['stok_adi']??'',0,20))?></div>
    </div>
    <div>
      <div style="color:var(--m3);font-size:10px;font-weight:700;margin-bottom:2px">MİKTAR</div>
      <div style="font-weight:700"><?=number_format((float)($r['miktar']??0),2)?> <?=htmlspecialchars($r['birim']??'')?></div>
    </div>
    <div>
      <div style="color:var(--m3);font-size:10px;font-weight:700;margin-bottom:2px">HATA ORANI</div>
      <?php if($oran!==null):?>
      <div style="font-size:16px;font-weight:900;color:<?=$oran_renk?>">%<?=$oran?></div>
      <div style="font-size:10px;color:var(--m3)"><?=$ha?>/<?=$ka?> adet</div>
      <?php else:?><div style="color:var(--m3)">—</div><?php endif;?>
    </div>
    <div>
      <div style="color:var(--m3);font-size:10px;font-weight:700;margin-bottom:2px">AKSİYON</div>
      <?php if($r['aksiyon_turu']):?>
      <div style="font-size:11px;font-weight:700;color:var(--m2)"><?=$aksiyon_turleri[$r['aksiyon_turu']]??$r['aksiyon_turu']?></div>
      <?php endif;?>
      <?php if($r['planlanan_tarih']):?>
      <div style="font-size:10px;color:var(--m3)">Plan: <?=htmlspecialchars($r['planlanan_tarih'])?></div>
      <?php endif;?>
    </div>
  </div>
  <?php if(!empty($r['aciklama'])):?>
  <div style="padding:6px 16px 10px;font-size:11px;color:var(--m3);border-top:1px solid var(--kenar)"><?=htmlspecialchars($r['aciklama'])?></div>
  <?php endif;?>
</div>
<?php endforeach;?>
</div>
<?php endif;?>
</div>

<!-- Süreç Yönetim Modal -->
<div id="surec-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.5);z-index:99000;align-items:flex-start;justify-content:center;overflow-y:auto;padding:40px 20px">
  <div style="background:#fff;border-radius:12px;width:680px;max-width:100%;box-shadow:0 20px 60px rgba(0,0,0,.3)">
    <!-- Modal Başlık -->
    <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:800;font-size:15px" id="surec-baslik">⚙️ Süreç Yönetimi</div>
      <button onclick="document.getElementById('surec-modal').style.display='none'" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--m3)">✕</button>
    </div>
    <div id="surec-icerik" style="padding:20px">Yükleniyor...</div>
  </div>
</div>

<script>
var BASE_GKK_RED = <?=json_encode(BASE_URL)?>;

var ASAMALAR = <?=json_encode(array_map(fn($k,$v)=>['key'=>$k,'label'=>$v['emoji'].' '.$v['label']], array_keys($asamalar), $asamalar))?>;
var AKSIYON_TURLERI = <?=json_encode(array_map(fn($k,$v)=>['key'=>$k,'label'=>$v], array_keys($aksiyon_turleri), $aksiyon_turleri))?>;

document.addEventListener('click', function(e){
    var btn = e.target.closest('.btn-gkk-detay');
    if(!btn) return;
    var gkkId   = btn.dataset.gkkId;
    var surecId = btn.dataset.surecId;
    surecModalAc(gkkId, surecId);
});

function surecModalAc(gkkId, surecId) {
    var modal = document.getElementById('surec-modal');
    modal.style.display = 'flex';
    document.getElementById('surec-icerik').innerHTML = '<div style="text-align:center;padding:30px;color:var(--m3)">⏳ Yükleniyor...</div>';

    // Önce süreç başlat (yoksa oluştur)
    fetch(BASE_GKK_RED+'/islemler/kalite/gkk_red_surec.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({action:'surec_baslat', gkk_id: parseInt(gkkId)})
    })
    .then(r=>r.json())
    .then(d=>{
        if(!d.success){ alert('Hata: '+d.message); return; }
        var sid = d.surec_id;
        // Detay yükle
        return fetch(BASE_GKK_RED+'/islemler/kalite/gkk_red_surec.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({action:'detay', surec_id: sid})
        }).then(r=>r.json()).then(det=>{
            if(!det.success){ alert('Detay hatası: '+det.message); return; }
            renderSurecModal(det.surec, det.loglar, det.yanitlar);
        });
    }).catch(e=>alert('Hata: '+e.message));
}

function renderSurecModal(surec, loglar, yanitlar) {
    document.getElementById('surec-baslik').textContent = '⚙️ '+surec.irsaliye_no+' / '+surec.stok_kodu;

    var asamaOptions = ASAMALAR.map(a=>`<option value="${a.key}" ${surec.asama===a.key?'selected':''}>${a.label}</option>`).join('');
    var aksiyonOptions = AKSIYON_TURLERI.map(a=>`<option value="${a.key}" ${surec.aksiyon_turu===a.key?'selected':''}>${a.label}</option>`).join('');

    var logHtml = loglar.length ? loglar.map(l=>`
        <div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--kenar)">
          <div style="font-size:10px;color:var(--m3);min-width:110px;white-space:nowrap">${(l.kayit_tarihi||'').substring(0,16)}</div>
          <div style="flex:1">
            <span style="font-size:10px;font-weight:700;color:#4F46E5">${l.asama_sonrasi||''}</span>
            ${l.not_?`<div style="font-size:11px;color:var(--m2)">${l.not_}</div>`:''}
            ${l.dosya_adi?`<div style="font-size:10px"><a href="${BASE_GKK_RED}/${l.dosya_yolu}" target="_blank" style="color:#4F46E5">📎 ${l.dosya_adi}</a></div>`:''}
          </div>
          <div style="font-size:10px;color:var(--m3);white-space:nowrap">${l.kaydeden||''}</div>
        </div>`).join('') : '<div style="color:var(--m3);font-size:11px;padding:8px 0">Henüz log yok.</div>';

    var yanitHtml = yanitlar.length ? yanitlar.map(y=>`
        <div style="background:#F0F9FF;border-radius:8px;padding:10px 12px;margin-bottom:8px;border-left:3px solid #0EA5E9">
          <div style="font-size:10px;font-weight:700;color:#0EA5E9;margin-bottom:4px">${y.yanit_turu} — ${y.yanit_tarihi||''} — ${y.kaydeden||''}</div>
          <div style="font-size:12px">${y.yanit_icerigi||''}</div>
          ${y.yeni_sevkiyat_tarih?`<div style="font-size:11px;color:#0EA5E9;margin-top:4px">🚚 Yeni Sevkiyat: ${y.yeni_sevkiyat_miktar} — ${y.yeni_sevkiyat_tarih}</div>`:''}
          ${y.dosya_adi?`<a href="${BASE_GKK_RED}/${y.dosya_yolu}" target="_blank" style="font-size:10px;color:#4F46E5">📎 ${y.dosya_adi}</a>`:''}
        </div>`).join('') : '<div style="color:var(--m3);font-size:11px">Henüz yanıt yok.</div>';

    document.getElementById('surec-icerik').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
      <div>
        <div style="font-size:10px;font-weight:700;color:var(--m3);margin-bottom:2px">TEDARİKÇİ</div>
        <div style="font-size:12px;font-weight:700">${surec.tedarikci||'—'}</div>
      </div>
      <div>
        <div style="font-size:10px;font-weight:700;color:var(--m3);margin-bottom:2px">MİKTAR</div>
        <div style="font-size:12px">${parseFloat(surec.miktar||0).toFixed(2)} ${surec.birim||''}</div>
      </div>
    </div>

    <!-- Aşama Güncelle -->
    <div style="background:var(--kenar-a);border-radius:8px;padding:14px;margin-bottom:14px">
      <div style="font-weight:700;font-size:12px;margin-bottom:10px">⚙️ Aşama Güncelle</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
        <div>
          <label class="form-et" style="font-size:11px">Aşama</label>
          <select id="sm-asama" class="form-alan"><option value="">— Seçin —</option>${asamaOptions}</select>
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Aksiyon Türü</label>
          <select id="sm-aksiyon" class="form-alan">${aksiyonOptions}</select>
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Sorumlu</label>
          <input type="text" id="sm-sorumlu" class="form-alan" value="${surec.sorumlu||''}" placeholder="Sorumlu kişi...">
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Planlanan Tarih</label>
          <input type="date" id="sm-tarih" class="form-alan" value="${surec.planlanan_tarih||''}">
        </div>
      </div>
      <textarea id="sm-not" class="form-alan" rows="2" style="resize:none;margin-bottom:8px" placeholder="Not...">${surec.aciklama||''}</textarea>
      <button type="button" onclick="asamaKaydet(${surec.id})"
              class="btn btn-t" style="width:100%;padding:10px;font-weight:800">💾 Aşama Kaydet</button>
    </div>

    <!-- Tedarikçi Yanıtı -->
    <div style="background:#F0F9FF;border-radius:8px;padding:14px;margin-bottom:14px;border:1px solid #BAE6FD">
      <div style="font-weight:700;font-size:12px;margin-bottom:10px;color:#0369A1">📩 Tedarikçi Yanıtı Ekle</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
        <div>
          <label class="form-et" style="font-size:11px">Yanıt Türü</label>
          <select id="sm-yanit-tur" class="form-alan">
            <option value="KOK_NEDEN">📋 Kök Neden Analizi</option>
            <option value="AKSIYON_PLANI">⚙️ Aksiyon Planı</option>
            <option value="YENI_SEVKIYAT">🚚 Yeni Sevkiyat</option>
            <option value="DIGER">📄 Diğer</option>
          </select>
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Yanıt Tarihi</label>
          <input type="date" id="sm-yanit-tarih" class="form-alan" value="${new Date().toISOString().split('T')[0]}">
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Yeni Sevkiyat Tarihi</label>
          <input type="date" id="sm-sev-tarih" class="form-alan">
        </div>
        <div>
          <label class="form-et" style="font-size:11px">Yeni Sevkiyat Miktarı</label>
          <input type="number" id="sm-sev-mik" class="form-alan" min="0" step="0.01" placeholder="0">
        </div>
      </div>
      <textarea id="sm-yanit-icerik" class="form-alan" rows="2" style="resize:none;margin-bottom:8px" placeholder="Yanıt içeriği..."></textarea>
      <!-- Dosya Yükle -->
      <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
        <input type="file" id="sm-dosya" accept=".pdf,.jpg,.jpeg,.png,.xlsx,.docx,.txt" style="flex:1;font-size:11px">
        <button type="button" onclick="dosyaYukle(${surec.id},'yanit')"
                class="btn" style="padding:6px 12px;background:#0369A1;color:#fff;font-size:11px;white-space:nowrap">📎 Yükle</button>
      </div>
      <button type="button" onclick="yanitKaydet(${surec.id})"
              class="btn" style="width:100%;padding:10px;background:#0369A1;color:#fff;font-weight:800">📩 Yanıt Kaydet</button>
    </div>

    <!-- Log Geçmişi -->
    <div style="margin-bottom:14px">
      <div style="font-weight:700;font-size:12px;margin-bottom:8px">📋 Geçmiş (${loglar.length} kayıt)</div>
      <div style="max-height:200px;overflow-y:auto;border:1px solid var(--kenar);border-radius:6px;padding:8px 10px">
        ${logHtml}
      </div>
    </div>

    <!-- Tedarikçi Yanıtları -->
    ${yanitlar.length ? `<div>
      <div style="font-weight:700;font-size:12px;margin-bottom:8px">📩 Tedarikçi Yanıtları (${yanitlar.length})</div>
      ${yanitHtml}
    </div>` : ''}
    `;
}

function asamaKaydet(surecId) {
    var asama   = document.getElementById('sm-asama').value;
    var aksiyon = document.getElementById('sm-aksiyon').value;
    var sorumlu = document.getElementById('sm-sorumlu').value;
    var tarih   = document.getElementById('sm-tarih').value;
    var not_    = document.getElementById('sm-not').value;
    if(!asama){ alert('Aşama seçin'); return; }
    fetch(BASE_GKK_RED+'/islemler/kalite/gkk_red_surec.php',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({action:'asama_guncelle',surec_id:surecId,asama,aksiyon_turu:aksiyon,sorumlu,planlanan_tarih:tarih,not:not_})
    }).then(r=>r.json()).then(d=>{
        if(d.success){ document.getElementById('surec-modal').style.display='none'; location.reload(); }
        else alert('Hata: '+d.message);
    });
}

function yanitKaydet(surecId) {
    var tur   = document.getElementById('sm-yanit-tur').value;
    var tarih = document.getElementById('sm-yanit-tarih').value;
    var icerik= document.getElementById('sm-yanit-icerik').value;
    var stih  = document.getElementById('sm-sev-tarih').value;
    var smik  = document.getElementById('sm-sev-mik').value;
    if(!icerik){ alert('Yanıt içeriği girin'); return; }
    fetch(BASE_GKK_RED+'/islemler/kalite/gkk_red_surec.php',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({action:'tedarikci_yanit',surec_id:surecId,yanit_turu:tur,yanit_tarihi:tarih,yanit_icerigi:icerik,yeni_sevkiyat_tarih:stih,yeni_sevkiyat_miktar:smik})
    }).then(r=>r.json()).then(d=>{
        if(d.success){ document.getElementById('surec-modal').style.display='none'; location.reload(); }
        else alert('Hata: '+d.message);
    });
}

function dosyaYukle(surecId, tur) {
    var inp = document.getElementById('sm-dosya');
    if(!inp.files.length){ alert('Dosya seçin'); return; }
    var fd = new FormData();
    fd.append('action','dosya_yukle');
    fd.append('surec_id', surecId);
    fd.append('tur', tur);
    fd.append('dosya', inp.files[0]);
    fetch(BASE_GKK_RED+'/islemler/kalite/gkk_red_surec.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(d=>{
        if(d.success) alert('✅ Dosya yüklendi: '+d.dosya_adi);
        else alert('Hata: '+d.message);
    });
}
</script>
