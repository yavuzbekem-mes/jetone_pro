<?php
/**
 * JETONE.PRO — Hortum Test Reçete Yönetimi
 * panel.php: 'kalite-hortum-recete' => 'bolumler/kalite/hortum_recete.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Tabloyu garantile
try {
    $db->exec("CREATE TABLE IF NOT EXISTS hortum_test_recete (
        id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        recete_adi       VARCHAR(100) NOT NULL,
        hedef_basinc     DECIMAL(5,3) DEFAULT 2.500,
        kacak_esigi      DECIMAL(5,3) DEFAULT 0.050,
        bekle_sure       INT DEFAULT 10,
        min_akis         DECIMAL(5,2) DEFAULT 8.00,
        stabilize_sure   INT DEFAULT 3,
        aciklama         VARCHAR(255) DEFAULT NULL,
        aktif            TINYINT(1) DEFAULT 1,
        olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
        guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // aciklama kolonu yoksa ekle
    try { $db->exec("ALTER TABLE hortum_test_recete ADD COLUMN aciklama VARCHAR(255) DEFAULT NULL AFTER min_akis"); } catch(Throwable $e) {}
    try { $db->exec("ALTER TABLE hortum_test_recete ADD COLUMN guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER olusturma_tarihi"); } catch(Throwable $e) {}
    // Örnek veriler yoksa ekle
    $db->exec("INSERT IGNORE INTO hortum_test_recete (id,recete_adi,hedef_basinc,kacak_esigi,bekle_sure,min_akis,stabilize_sure)
        VALUES (1,'Standart Hortum',2.500,0.050,10,8.00,3),
               (2,'Uzun Hortum',3.000,0.080,15,6.00,5),
               (3,'İnce Hortum',1.500,0.030,8,4.00,2)");
} catch (Throwable $e) {}

// Tüm reçeteler
try {
    $receteler = $db->query("SELECT * FROM hortum_test_recete ORDER BY aktif DESC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $receteler = []; }
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Hortum Test — Reçete Yönetimi</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" style="color:var(--t)">Hortum Test</a> / <b>Reçeteler</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="yeniReceteAc()" class="btn btn-t btn-sm">+ Yeni Reçete</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" class="btn btn-b btn-sm">← Test Sayfası</a>
  </div>
</div>

<div class="s-body">

<!-- ── Modal: Reçete Ekle/Düzenle ──────────────────────── -->
<div id="receteModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
  <div class="kart" style="width:480px;max-width:95vw;padding:22px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-weight:800;font-size:15px" id="modalBaslik">Yeni Reçete</div>
      <button onclick="modalKapat()" style="border:none;background:none;font-size:18px;cursor:pointer;color:var(--m2)">✕</button>
    </div>

    <form id="receteForm" onsubmit="receteKaydet(event)">
      <input type="hidden" id="receteId" value="">

      <div style="display:grid;gap:12px">

        <div>
          <label class="form-et">Reçete Adı <span style="color:#EF4444">*</span></label>
          <input id="f_adi" class="form-alan" type="text" required maxlength="100"
                 placeholder="Ör: Standart Hortum, BSH-A Tipi...">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div>
            <label class="form-et">Hedef Basınç (bar)</label>
            <input id="f_hedef" class="form-alan" type="number" step="0.001" min="0.1" max="10" value="2.500" required>
            <div style="font-size:10px;color:var(--m3);margin-top:2px">Test sırasında ulaşılması gereken basınç</div>
          </div>
          <div>
            <label class="form-et">Kaçak Eşiği (bar)</label>
            <input id="f_kacak" class="form-alan" type="number" step="0.001" min="0" max="1" value="0.050" required>
            <div style="font-size:10px;color:var(--m3);margin-top:2px">İzin verilen max basınç düşüşü</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
          <div>
            <label class="form-et">Bekleme (sn)</label>
            <input id="f_bekle" class="form-alan" type="number" min="1" max="300" value="10" required>
            <div style="font-size:10px;color:var(--m3);margin-top:2px">Basınç tutma süresi</div>
          </div>
          <div>
            <label class="form-et">Min. Akış (L/dk)</label>
            <input id="f_akis" class="form-alan" type="number" step="0.01" min="0" max="100" value="8.00" required>
            <div style="font-size:10px;color:var(--m3);margin-top:2px">Min. geçerli akış değeri</div>
          </div>
          <div>
            <label class="form-et">Stabilizasyon (sn)</label>
            <input id="f_stab" class="form-alan" type="number" min="1" max="60" value="3" required>
            <div style="font-size:10px;color:var(--m3);margin-top:2px">Dolum stabilizasyon süresi</div>
          </div>
        </div>

        <div>
          <label class="form-et">Açıklama <span style="color:var(--m3);font-weight:400">(opsiyonel)</span></label>
          <input id="f_aciklama" class="form-alan" type="text" maxlength="255"
                 placeholder="Hortum tipi, kullanım alanı...">
        </div>

        <div style="display:flex;align-items:center;gap:8px">
          <input id="f_aktif" type="checkbox" checked style="width:16px;height:16px">
          <label for="f_aktif" style="font-size:13px;font-weight:600">Aktif (test sayfasında görünsün)</label>
        </div>

      </div><!-- /grid -->

      <!-- Canlı önizleme -->
      <div style="margin-top:14px;background:var(--kenar-a);border-radius:8px;padding:10px" id="onizleme">
        <div style="font-size:11px;font-weight:700;color:var(--m2);margin-bottom:6px;text-transform:uppercase">Özet</div>
        <div id="onizlemeMetin" style="font-size:12px;color:var(--t)"></div>
      </div>

      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
        <button type="button" onclick="modalKapat()" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t" id="kaydetBtn">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>

<!-- ── Reçete Listesi ────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:1fr 340px;gap:16px" class="recete-grid">

<!-- Sol: Liste -->
<div>
  <div class="kart" style="padding:16px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div style="font-weight:800;font-size:14px;color:var(--t)">Tanımlı Reçeteler</div>
      <span style="font-size:12px;color:var(--m2)"><?= count($receteler) ?> reçete</span>
    </div>

    <?php if (empty($receteler)): ?>
    <div style="text-align:center;padding:30px;color:var(--m3)">
      Henüz reçete yok. <button onclick="yeniReceteAc()" class="btn btn-t btn-sm" style="margin-left:8px">+ Ekle</button>
    </div>
    <?php else: ?>

    <div style="display:grid;gap:10px">
    <?php foreach ($receteler as $r): ?>
    <div class="recete-kart" id="rkart_<?= $r['id'] ?>"
         style="border:2px solid <?= $r['aktif'] ? 'var(--kenar)' : '#E2E8F0' ?>;
                border-radius:10px;padding:14px;
                background:<?= $r['aktif'] ? 'var(--kart-bg,#fff)' : '#F8FAFC' ?>;
                opacity:<?= $r['aktif'] ? '1' : '.6' ?>">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div>
          <div style="font-weight:800;font-size:14px;color:var(--t)">
            <?= htmlspecialchars($r['recete_adi']) ?>
          </div>
          <?php if ($r['aciklama'] ?? ''): ?>
          <div style="font-size:11px;color:var(--m2);margin-top:2px"><?= htmlspecialchars($r['aciklama']) ?></div>
          <?php endif; ?>
        </div>
        <div style="display:flex;gap:6px;align-items:center">
          <?php if ($r['aktif']): ?>
          <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:#D1FAE5;color:#065F46">✓ Aktif</span>
          <?php else: ?>
          <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:#F1F5F9;color:#94A3B8">Pasif</span>
          <?php endif; ?>
          <button onclick="duzenle(<?= $r['id'] ?>)" class="btn btn-b btn-sm" style="padding:4px 10px;font-size:11px">✏️</button>
          <button onclick="silOnay(<?= $r['id'] ?>, '<?= addslashes(htmlspecialchars($r['recete_adi'])) ?>')"
                  class="btn btn-sm" style="padding:4px 10px;font-size:11px;background:#FEF2F2;color:#DC2626;border:1px solid #FCA5A5">🗑</button>
        </div>
      </div>

      <!-- Parametreler -->
      <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">
        <?php foreach ([
          ['Hedef Basınç', number_format($r['hedef_basinc'],3).' bar', '#7C3AED'],
          ['Kaçak Eşiği',  number_format($r['kacak_esigi'],3).' bar',  '#EF4444'],
          ['Bekleme',      $r['bekle_sure'].' sn',                      '#D97706'],
          ['Min. Akış',    number_format($r['min_akis'],2).' L/dk',     '#0F766E'],
          ['Stabilizasyon',$r['stabilize_sure'].' sn',                  '#2563EB'],
        ] as $p): ?>
        <div style="background:var(--kenar-a);border-radius:6px;padding:6px 8px;text-align:center">
          <div style="font-size:12px;font-weight:800;color:<?= $p[2] ?>"><?= $p[1] ?></div>
          <div style="font-size:9px;color:var(--m3);margin-top:1px"><?= $p[0] ?></div>
        </div>
        <?php endforeach; ?>
      </div>

    </div>
    <?php endforeach; ?>
    </div>

    <?php endif; ?>
  </div>
</div>

<!-- Sağ: Yardım + İstatistik -->
<div>

  <!-- Parametre Açıklamaları -->
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t)">📖 Parametre Rehberi</div>
    <?php foreach ([
      ['🎯','Hedef Basınç','#7C3AED','Test sırasında sisteme verilecek basınç. Hortum tipine ve uzunluğuna göre ayarlayın. Kısa hortumlar için düşük (1.5-2 bar), uzun hortumlar için yüksek (2.5-4 bar) değer kullanın.'],
      ['🔴','Kaçak Eşiği','#EF4444','Test süresince kabul edilebilir maksimum basınç düşüşü. Küçük değer = Daha hassas test. Örn: 0.050 bar → 5 dakikada en fazla 0.050 bar düşebilir.'],
      ['⏱️','Bekleme Süresi','#D97706','Basınç oluştuktan sonra kaçak testi için bekleme süresi. Uzun süre = Daha güvenilir sonuç. Minimum 5 sn, üretim hızı için 10-15 sn önerilir.'],
      ['💧','Min. Akış','#0F766E','2. aşama tıkanıklık testinde geçerli sayılacak minimum akış değeri. Hortumun iç çapına ve uzunluğuna göre belirleyin.'],
      ['📐','Stabilizasyon','#2563EB','Basınç uygulandıktan sonra ölçüm başlamadan önce beklenen süre. Sistemin dengelenmesi için 3-5 sn yeterlidir.'],
    ] as $p): ?>
    <div style="display:flex;gap:10px;margin-bottom:10px;padding:8px;border-radius:6px;background:var(--kenar-a)">
      <div style="font-size:16px;flex-shrink:0"><?= $p[0] ?></div>
      <div>
        <div style="font-weight:700;font-size:12px;color:<?= $p[2] ?>"><?= $p[1] ?></div>
        <div style="font-size:11px;color:var(--m2);margin-top:2px;line-height:1.5"><?= $p[3] ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Kullanım İstatistikleri -->
  <div class="kart" style="padding:16px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t)">📊 Reçete Kullanım</div>
    <?php
    try {
        $stats = $db->query("
            SELECT recete_adi,
                   COUNT(*) as toplam,
                   SUM(genel_sonuc) as gecti,
                   ROUND(SUM(genel_sonuc)/COUNT(*)*100,0) as oran
            FROM hortum_test_kayit
            GROUP BY recete_adi ORDER BY toplam DESC LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $stats = []; }
    ?>
    <?php if (empty($stats)): ?>
    <div style="font-size:12px;color:var(--m3);text-align:center;padding:16px">Henüz test kaydı yok</div>
    <?php else: ?>
    <?php foreach ($stats as $s): ?>
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
        <span style="font-weight:600"><?= htmlspecialchars($s['recete_adi'] ?? '—') ?></span>
        <span style="color:var(--m2)"><?= $s['toplam'] ?> test · <?= $s['oran'] ?>% geçti</span>
      </div>
      <div style="height:6px;background:var(--kenar);border-radius:3px;overflow:hidden">
        <div style="height:100%;width:<?= $s['oran'] ?>%;background:<?= $s['oran']>=80?'#22C55E':($s['oran']>=50?'#F59E0B':'#EF4444') ?>;border-radius:3px"></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div>
</div><!-- /grid -->
</div><!-- /s-body -->

<style>
@media(max-width:800px){ .recete-grid{grid-template-columns:1fr!important} }
</style>

<!-- Reçete verisi JS için -->
<script>
var receteler = <?= json_encode(array_column($receteler, null, 'id'), JSON_UNESCAPED_UNICODE) ?>;

// ── Modal ─────────────────────────────────────────────────
function yeniReceteAc() {
    document.getElementById('receteId').value = '';
    document.getElementById('modalBaslik').textContent = 'Yeni Reçete';
    document.getElementById('receteForm').reset();
    document.getElementById('f_aktif').checked = true;
    onizlemeGuncelle();
    document.getElementById('receteModal').style.display = 'flex';
    setTimeout(function(){ document.getElementById('f_adi').focus(); }, 100);
}

function duzenle(id) {
    var r = receteler[id];
    if (!r) return;
    document.getElementById('receteId').value    = id;
    document.getElementById('modalBaslik').textContent = 'Reçete Düzenle';
    document.getElementById('f_adi').value       = r.recete_adi;
    document.getElementById('f_hedef').value     = r.hedef_basinc;
    document.getElementById('f_kacak').value     = r.kacak_esigi;
    document.getElementById('f_bekle').value     = r.bekle_sure;
    document.getElementById('f_akis').value      = r.min_akis;
    document.getElementById('f_stab').value      = r.stabilize_sure;
    document.getElementById('f_aciklama').value  = r.aciklama || '';
    document.getElementById('f_aktif').checked   = r.aktif == 1;
    onizlemeGuncelle();
    document.getElementById('receteModal').style.display = 'flex';
}

function modalKapat() {
    document.getElementById('receteModal').style.display = 'none';
}

// ── Kaydet (AJAX) ─────────────────────────────────────────
async function receteKaydet(e) {
    e.preventDefault();
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.textContent = '⏳ Kaydediliyor...';

    var data = {
        id          : document.getElementById('receteId').value,
        recete_adi  : document.getElementById('f_adi').value.trim(),
        hedef_basinc: document.getElementById('f_hedef').value,
        kacak_esigi : document.getElementById('f_kacak').value,
        bekle_sure  : document.getElementById('f_bekle').value,
        min_akis    : document.getElementById('f_akis').value,
        stabilize_sure: document.getElementById('f_stab').value,
        aciklama    : document.getElementById('f_aciklama').value.trim(),
        aktif       : document.getElementById('f_aktif').checked ? 1 : 0,
    };

    try {
        var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/hortum_recete_kaydet.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},
            body: JSON.stringify(data)
        });
        var d = await r.json();
        if (d.ok) {
            modalKapat();
            location.reload();
        } else {
            alert('Hata: ' + (d.hata || 'Bilinmeyen hata'));
        }
    } catch(err) {
        alert('Bağlantı hatası: ' + err.message);
    } finally {
        btn.disabled = false; btn.textContent = '💾 Kaydet';
    }
}

// ── Sil ───────────────────────────────────────────────────
async function silOnay(id, ad) {
    if (!confirm('"' + ad + '" reçetesini silmek istediğinizden emin misiniz?\nBu işlem geri alınamaz.')) return;
    try {
        var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/hortum_recete_kaydet.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},
            body: JSON.stringify({sil: true, id: id})
        });
        var d = await r.json();
        if (d.ok) {
            var el = document.getElementById('rkart_' + id);
            if (el) { el.style.opacity='0'; el.style.transition='.3s'; setTimeout(function(){location.reload();},300); }
        } else { alert('Silinemedi: ' + (d.hata||'')); }
    } catch(err) { alert(err.message); }
}

// ── Önizleme ─────────────────────────────────────────────
function onizlemeGuncelle() {
    var hedef = parseFloat(document.getElementById('f_hedef').value)||0;
    var kacak = parseFloat(document.getElementById('f_kacak').value)||0;
    var bekle = parseInt(document.getElementById('f_bekle').value)||0;
    var akis  = parseFloat(document.getElementById('f_akis').value)||0;
    var stab  = parseInt(document.getElementById('f_stab').value)||0;
    var toplam = stab + bekle;
    document.getElementById('onizlemeMetin').innerHTML =
        '<b>' + hedef.toFixed(3) + ' bar</b> basınç hedefi, ' +
        '<b>' + bekle + ' sn</b> bekleme süresi ile test yapılır. ' +
        bekle + ' sn boyunca basınç düşüşü <b>' + kacak.toFixed(3) + ' bar</b>\'dan az olmalı. ' +
        'Akış testi için minimum <b>' + akis.toFixed(2) + ' L/dk</b> gerekli. ' +
        'Toplam test süresi yaklaşık <b>~' + (toplam + 10) + ' sn</b>.';
}

// Input değişince önizlemeyi güncelle
['f_hedef','f_kacak','f_bekle','f_akis','f_stab'].forEach(function(id){
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', onizlemeGuncelle);
});

// Modal dışına tıklayınca kapat
document.getElementById('receteModal').addEventListener('click', function(e){
    if (e.target === this) modalKapat();
});
</script>
