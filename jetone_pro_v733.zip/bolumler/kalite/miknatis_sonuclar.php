<?php
/**
 * JETONE.PRO — Tekmelik Test Sonuçları
 * bolumler/kalite/miknatis_sonuclar.php
 * panel.php: 'kalite-miknatis-sonuclar' => 'bolumler/kalite/miknatis_sonuclar.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$cihazlar = ['KRT-01','KRT-02','KRT-03','KRT-04','KRT-05','KRT-06','KRT-07','KRT-08'];

$makina   = in_array($_GET['makina'] ?? '', $cihazlar) ? $_GET['makina'] : '';
$tarih_b  = $_GET['tarih_b'] ?? date('Y-m-d', strtotime('-6 days'));
$tarih_e  = $_GET['tarih_e'] ?? date('Y-m-d');
$durum_f  = in_array($_GET['durum'] ?? '', ['basarili','hata_1','hata_2','hata_3','duzeltildi']) ? $_GET['durum'] : '';
$urun_f   = trim($_GET['urun'] ?? '');

// ── WHERE builder ─────────────────────────────────────────────────────────────
$where = "WHERE DATE(kontrol_zamani) BETWEEN ? AND ?";
$params = [$tarih_b, $tarih_e];
if ($makina) { $where .= " AND makina_kodu=?"; $params[] = $makina; }
if ($durum_f){ $where .= " AND durum=?";       $params[] = $durum_f; }
if ($urun_f) { $where .= " AND urun_kodu LIKE ?"; $params[] = "%$urun_f%"; }

// ── Özet ─────────────────────────────────────────────────────────────────────
try {
    $oz = $db->prepare("SELECT
        COUNT(*) AS toplam,
        SUM(durum='basarili') AS basarili,
        SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
        SUM(durum='duzeltildi') AS duzeltildi,
        SUM(durum='hata_1') AS h1, SUM(durum='hata_2') AS h2, SUM(durum='hata_3') AS h3,
        ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran
        FROM miknatis_kontroller $where");
    $oz->execute($params);
    $ozet = $oz->fetch(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $ozet = null; }

// ── Makina bazlı özet ─────────────────────────────────────────────────────────
try {
    $mz = $db->prepare("SELECT makina_kodu,
        COUNT(*) AS toplam,
        SUM(durum='basarili') AS basarili,
        SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
        ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran
        FROM miknatis_kontroller $where GROUP BY makina_kodu ORDER BY makina_kodu");
    $mz->execute($params);
    $mak_ozet = $mz->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $mak_ozet = []; }

// ── Günlük trend ─────────────────────────────────────────────────────────────
try {
    $tr = $db->prepare("SELECT DATE(kontrol_zamani) AS gun,
        COUNT(*) AS toplam,
        SUM(durum='basarili') AS basarili,
        SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
        SUM(durum='duzeltildi') AS duzeltildi,
        ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran
        FROM miknatis_kontroller $where GROUP BY DATE(kontrol_zamani) ORDER BY gun");
    $tr->execute($params);
    $trend = $tr->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $trend = []; }

// ── Kayıt listesi ─────────────────────────────────────────────────────────────
try {
    $ls = $db->prepare("SELECT id, makina_kodu, urun_kodu, durum, m1, m2, m3,
        eksik_adet, aciklama, orijinal_id,
        DATE_FORMAT(kontrol_zamani,'%d.%m.%Y %H:%i:%s') AS zaman,
        DATE_FORMAT(duzeltme_zamani,'%H:%i:%s') AS duz_saat
        FROM miknatis_kontroller $where
        ORDER BY kontrol_zamani DESC LIMIT 1000");
    $ls->execute($params);
    $kayitlar = $ls->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $kayitlar = []; }

function durum_roz(string $d): string {
    $map = [
        'basarili'  => ['#D1FAE5','#065F46','✓ Başarılı'],
        'hata_1'    => ['#FEF9C3','#92400E','⚠ 1 Eksik'],
        'hata_2'    => ['#FEE2E2','#991B1B','✗ 2 Eksik'],
        'hata_3'    => ['#7F1D1D','#FCA5A5','✗✗ 3 Eksik'],
        'duzeltildi'=> ['#EDE9FE','#5B21B6','✔ Düzeltildi'],
    ];
    $r = $map[$d] ?? ['#F1F5F9','#64748B', $d];
    return "<span style=\"background:{$r[0]};color:{$r[1]};padding:2px 9px;border-radius:12px;font-size:11px;font-weight:800\">{$r[2]}</span>";
}
$DOT = fn($v) => $v==1
  ? '<span style="color:#22C55E;font-weight:800">●</span>'
  : '<span style="color:#EF4444;font-weight:800">○</span>';
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Test Sonuçları</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" style="color:var(--t)">Test Cihazları</a> / <b>Sonuçlar</b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" class="btn btn-b btn-sm">← Cihazlar</a>
</div>

<div class="s-body">

<!-- Filtre -->
<div class="kart" style="margin-bottom:16px">
  <form method="GET" action="" style="display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="kalite-miknatis-sonuclar">
    <div class="form-grup" style="margin:0"><label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="tarih_b" value="<?= $tarih_b ?>" style="max-width:140px"></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="tarih_e" value="<?= $tarih_e ?>" style="max-width:140px"></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Cihaz</label>
      <select class="form-alan" name="makina" style="min-width:110px">
        <option value="">Tümü</option>
        <?php foreach ($cihazlar as $c): ?>
        <option value="<?= $c ?>" <?= $makina===$c?'selected':'' ?>><?= $c ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Durum</label>
      <select class="form-alan" name="durum" style="min-width:120px">
        <option value="">Tümü</option>
        <option value="basarili"   <?= $durum_f==='basarili'  ?'selected':''?>>Başarılı</option>
        <option value="hata_1"     <?= $durum_f==='hata_1'   ?'selected':''?>>1 Eksik</option>
        <option value="hata_2"     <?= $durum_f==='hata_2'   ?'selected':''?>>2 Eksik</option>
        <option value="hata_3"     <?= $durum_f==='hata_3'   ?'selected':''?>>3 Eksik</option>
        <option value="duzeltildi" <?= $durum_f==='duzeltildi'?'selected':''?>>Düzeltildi</option>
      </select></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Ürün Kodu</label>
      <input class="form-alan" type="text" name="urun" value="<?= htmlspecialchars($urun_f) ?>"
             placeholder="Ör: TKM-001" style="max-width:120px"></div>
    <button type="submit" class="btn btn-t">🔍 Filtrele</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-sonuclar" class="btn btn-b">✕</a>
  </form>
</div>

<!-- Özet kartlar -->
<?php if ($ozet): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px;margin-bottom:16px">
  <?php
  $kutular = [
    ['Toplam', $ozet['toplam']    ?? 0, 'var(--t)',    '#FFF7ED'],
    ['Başarılı',$ozet['basarili'] ?? 0, '#059669',     '#D1FAE5'],
    ['Hatalı',  $ozet['hatali']   ?? 0, '#DC2626',     '#FEE2E2'],
    ['Düzeltildi',$ozet['duzeltildi']??0,'#7C3AED',    '#EDE9FE'],
    ['Başarı %', ($ozet['oran']??0).'%','#1D4ED8',     '#EFF6FF'],
    ['1 Eksik',  $ozet['h1']??0,        '#D97706',     '#FEF9C3'],
    ['2 Eksik',  $ozet['h2']??0,        '#DC2626',     '#FEE2E2'],
    ['3 Eksik',  $ozet['h3']??0,        '#7F1D1D',     '#FEF2F2'],
  ];
  foreach ($kutular as $k): ?>
  <div style="background:<?= $k[3] ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:800;color:<?= $k[2] ?>"><?= $k[1] ?></div>
    <div style="font-size:11px;color:var(--m2);margin-top:3px"><?= $k[0] ?></div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Makina bazlı özet + Trend grafik -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px" class="son-grid">

  <!-- Makina bazlı -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:10px 16px;background:#1E3A5F">
      <span style="font-weight:800;color:#fff;font-size:13px">🏭 Cihaz Bazlı Özet</span>
    </div>
    <table class="tablo" style="width:100%">
      <thead>
        <tr style="background:#F1F5F9">
          <th style="color:#000;font-weight:700">Cihaz</th>
          <th style="color:#000;font-weight:700;text-align:right">Toplam</th>
          <th style="color:#000;font-weight:700;text-align:right">Başarılı</th>
          <th style="color:#000;font-weight:700;text-align:right">Hatalı</th>
          <th style="color:#000;font-weight:700;text-align:center">Başarı %</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($mak_ozet as $m):
          $or = (float)$m['oran'];
          $bg = $or >= 95 ? '#D1FAE5' : ($or >= 80 ? '#FEF9C3' : '#FEE2E2');
          $fg = $or >= 95 ? '#065F46' : ($or >= 80 ? '#92400E' : '#991B1B');
        ?>
        <tr>
          <td><a href="?sayfa=kalite-miknatis-sonuclar&makina=<?= $m['makina_kodu'] ?>&tarih_b=<?= $tarih_b ?>&tarih_e=<?= $tarih_e ?>"
                 style="font-weight:700;color:var(--t)"><?= $m['makina_kodu'] ?></a></td>
          <td style="text-align:right"><?= (int)$m['toplam'] ?></td>
          <td style="text-align:right;color:#059669;font-weight:700"><?= (int)$m['basarili'] ?></td>
          <td style="text-align:right;color:#DC2626;font-weight:700"><?= (int)$m['hatali'] ?></td>
          <td style="text-align:center">
            <span style="background:<?= $bg ?>;color:<?= $fg ?>;padding:2px 10px;border-radius:12px;font-weight:800;font-size:12px">
              <?= $or ?>%
            </span>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($mak_ozet)): ?>
        <tr><td colspan="5" style="text-align:center;padding:20px;color:var(--m3)">Kayıt yok</td></tr>
        <?php endif; ?>
      </tbody>
      <tfoot>
        <tr style="background:#F1F5F9">
          <th style="color:#000;font-weight:700">Cihaz</th>
          <th style="color:#000;font-weight:700;text-align:right">Toplam</th>
          <th style="color:#000;font-weight:700;text-align:right">Başarılı</th>
          <th style="color:#000;font-weight:700;text-align:right">Hatalı</th>
          <th style="color:#000;font-weight:700;text-align:center">Başarı %</th>
        </tr>
      </tfoot>
    </table>
  </div>

  <!-- Trend grafik -->
  <div class="kart">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px">📈 Günlük Trend</div>
    <canvas id="trendChart" style="max-height:220px"></canvas>
  </div>

</div>

<!-- Kayıt tablosu -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 16px;background:#1E3A5F;display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;color:#fff;font-size:13px">
      🗂 Test Kayıtları
      <span style="background:rgba(255,255,255,.15);color:#fff;padding:1px 8px;border-radius:10px;font-size:11px;margin-left:6px">
        <?= count($kayitlar) ?> kayıt
      </span>
    </div>
    <a href="<?= BASE_URL ?>/bolumler/kalite/ajax/miknatis_xlsx.php?tarih_b=<?= $tarih_b ?>&tarih_e=<?= $tarih_e ?>&makina=<?= urlencode($makina) ?>"
       class="btn btn-sm" style="background:rgba(255,255,255,.15);color:#fff;font-size:11px;text-decoration:none">
      📥 Excel
    </a>
  </div>
  <div style="overflow-x:auto">
    <table id="sonucTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">#</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">Zaman</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">Cihaz</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">Ürün Kodu</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;text-align:center">M1</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;text-align:center">M2</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;text-align:center">M3</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">Durum</th>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700">Açıklama</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($kayitlar as $k): ?>
        <tr>
          <td style="color:var(--m3);font-size:11px"><?= $k['id'] ?></td>
          <td style="white-space:nowrap;font-size:12px"><?= htmlspecialchars($k['zaman']) ?></td>
          <td style="font-weight:700"><?= htmlspecialchars($k['makina_kodu']) ?></td>
          <td><code style="background:var(--kenar-a);padding:1px 7px;border-radius:4px;font-size:11px;font-weight:700"><?= htmlspecialchars($k['urun_kodu']) ?></code></td>
          <td style="text-align:center"><?= $DOT($k['m1']) ?></td>
          <td style="text-align:center"><?= $DOT($k['m2']) ?></td>
          <td style="text-align:center"><?= $DOT($k['m3']) ?></td>
          <td><?= durum_roz($k['durum']) ?></td>
          <td style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($k['aciklama'] ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($kayitlar)): ?>
        <tr><td colspan="9" style="text-align:center;padding:32px;color:var(--m3)">Kayıt bulunamadı.</td></tr>
        <?php endif; ?>
      </tbody>
      <tfoot>
        <tr style="background:#F1F5F9">
          <th style="color:#000;font-weight:700">#</th><th style="color:#000;font-weight:700">Zaman</th>
          <th style="color:#000;font-weight:700">Cihaz</th><th style="color:#000;font-weight:700">Ürün Kodu</th>
          <th style="color:#000;font-weight:700">M1</th><th style="color:#000;font-weight:700">M2</th>
          <th style="color:#000;font-weight:700">M3</th><th style="color:#000;font-weight:700">Durum</th>
          <th style="color:#000;font-weight:700">Açıklama</th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

</div><!-- /s-body -->

<style>
@media(max-width:768px){.son-grid{grid-template-columns:1fr!important}}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
$(document).ready(function(){
    document.title = 'Mıknatıs Test Sonuçları';
    $('#sonucTablo').DataTable({
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollY:500, scrollX:true, scrollCollapse:true, paging:false,
        dom:'Bfrtip', order:[[0,'desc']],
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Miknatis_<?= date('Ymd') ?>'},'print'],
        createdRow: function(row){ $(row).find('td').css('border-bottom','1px solid #F1F5F9'); }
    });
});

// Trend chart
(function(){
    var trend = <?= json_encode($trend) ?>;
    if(!trend.length) return;
    new Chart(document.getElementById('trendChart'),{
        type:'bar',
        data:{
            labels: trend.map(d=>d.gun.substr(5).replace('-','.')),
            datasets:[
                {label:'Başarılı', data:trend.map(d=>+d.basarili||0),  backgroundColor:'#22C55E', borderRadius:3},
                {label:'Düzeltildi',data:trend.map(d=>+d.duzeltildi||0),backgroundColor:'#A855F7',borderRadius:3},
                {label:'Hatalı',   data:trend.map(d=>+d.hatali||0),    backgroundColor:'#EF4444', borderRadius:3},
            ]
        },
        options:{responsive:true,plugins:{legend:{labels:{font:{size:10}}}},
          scales:{x:{stacked:true},y:{stacked:true,beginAtZero:true}}}
    });
})();

$(document).ready(function(){ setTimeout(function(){ $('#prozesTablo thead th, #sonucTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },300); });
</script>
