<?php
/**
 * JETONE.PRO — Tank Kapak Vakum Test Sistemi
 * MOXA E1212 → WebSocket → PHP arayüz
 * panel.php: 'kalite-tank-kapak-test' => 'bolumler/kalite/tank_kapak_test.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

// Server durumu sayfa açılışında kontrol
$server_calisiyor = false;
try {
    $s = @fsockopen('127.0.0.1', 5050, $e, $es, 0.3);
    if ($s) { fclose($s); $server_calisiyor = true; }
} catch(Throwable $e) {}

// DB — test kayıtları tablosu
try {
    $db->exec("CREATE TABLE IF NOT EXISTS tank_kapak_test (
        id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        urun_kodu     VARCHAR(50),
        operatör      VARCHAR(100),
        sonuc         ENUM('GECTI','KALDI','IPTAL') NOT NULL,
        sure_ms       INT UNSIGNED,
        basinc_max    DECIMAL(5,3),
        aciklama      VARCHAR(255),
        test_zamani   DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_zaman (test_zamani),
        INDEX idx_sonuc (sonuc)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

// Bugünkü istatistikler
$bugun = [];
try {
    $row = $db->query("
        SELECT COUNT(*) as toplam,
               SUM(sonuc='GECTI') as gecti,
               SUM(sonuc='KALDI') as kaldi,
               ROUND(SUM(sonuc='GECTI')/NULLIF(COUNT(*),0)*100,1) as oran,
               AVG(sure_ms)/1000 as ort_sure
        FROM tank_kapak_test WHERE DATE(test_zamani)=CURDATE()
    ")->fetch(PDO::FETCH_ASSOC);
    $bugun = $row ?: [];
} catch (Throwable $e) {}

// Son kayıtlar
$son_kayitlar = [];
try {
    $son_kayitlar = $db->query("
        SELECT * FROM tank_kapak_test ORDER BY id DESC LIMIT 20
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔬 Tank Kapak Vakum Test</h1>
    <div class="s-yol">Kalite / <b>Tank Kapak Test</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px">
      <span id="serverBadge" style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#FEE2E2;color:#991B1B;white-space:nowrap">
        ● Node.js Kontrol ediliyor...
      </span>
      <span id="serverDurum" style="font-size:10px;color:var(--m3)"></span>
    </div>
    <button id="btnServerToggle" onclick="serverToggle()"
            style="padding:6px 14px;border:none;border-radius:var(--r);background:#22C55E;color:#fff;font-weight:700;font-size:12px;cursor:pointer;white-space:nowrap">
      ▶ Başlat
    </button>
    <span id="connBadge" style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#FEE2E2;color:#991B1B">● WS Bağlı Değil</span>
  </div>
</div>

<div class="s-body">

<!-- ── Bağlantı Ayarları Modal ──────────────────────────── -->
<div id="wsModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
  <div class="kart" style="width:420px;padding:20px">
    <div style="font-weight:800;font-size:15px;margin-bottom:14px">⚙️ MOXA Bağlantı Ayarları</div>
    <div style="display:grid;gap:10px;margin-bottom:14px">
      <div>
        <label class="form-et">WebSocket URL</label>
        <input class="form-alan" id="wsUrl" value="ws://localhost:5050" placeholder="ws://localhost:5050">
      </div>
      <div>
        <label class="form-et">MOXA IP</label>
        <input class="form-alan" id="moxaIp" value="192.168.127.254" placeholder="192.168.127.254">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div>
          <label class="form-et">MOXA Port</label>
          <input class="form-alan" id="moxaPort" value="502" type="number">
        </div>
        <div>
          <label class="form-et">Vakum Süresi (ms)</label>
          <input class="form-alan" id="vakumSure" value="5000" type="number">
        </div>
      </div>
    </div>
    <div style="background:#FEF9C3;border-radius:var(--r);padding:10px;font-size:11px;color:#78350F;margin-bottom:14px">
      ℹ️ Önce <code>entegrasyonlar/start.bat</code> ile Node.js server&#39;ı başlatın.
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="document.getElementById('wsModal').style.display='none'" class="btn btn-b btn-sm">İptal</button>
      <button onclick="wsBaglan()" class="btn btn-t btn-sm">Bağlan</button>
    </div>
  </div>
</div>

<!-- ── Ana Grid ─────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:1fr 380px;gap:16px" class="tank-grid">

<!-- SOL: Cihaz Paneli ──────────────────────────────────── -->
<div>

  <!-- Bağlantı durumu -->
  <div id="connAlert" style="background:#FEF9C3;border-radius:var(--r);padding:12px 16px;margin-bottom:14px;font-size:12px;color:#78350F;border-left:4px solid #D97706">
    ⚠️ MOXA bağlantısı yok. <strong>entegrasyonlar/start.bat</strong> dosyasını çalıştırın, sonra ⚙️ Bağlantı butonuna tıklayın.
  </div>

  <!-- Şema Görsel — MOXA + Cihazlar -->
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t)">🔌 Cihaz Bağlantı Şeması — Canlı Durum</div>

    <div style="display:grid;grid-template-columns:200px 1fr 200px;gap:0;align-items:start">

      <!-- Sol: MOXA + Power Supply -->
      <div style="display:flex;flex-direction:column;gap:8px">

        <!-- Power Supply -->
        <div style="background:#FEF9C3;border-radius:8px;padding:8px 10px;border:1px solid #D97706;font-size:11px">
          <div style="font-weight:800;color:#78350F;margin-bottom:4px">⚡ POWER SUPPLY</div>
          <div style="color:#92400E">24V DC</div>
          <div style="display:flex;gap:4px;margin-top:4px">
            <span style="background:#DC2626;color:#fff;border-radius:3px;padding:1px 6px;font-size:10px">+</span>
            <span style="background:#374151;color:#fff;border-radius:3px;padding:1px 6px;font-size:10px">−</span>
          </div>
        </div>

        <!-- MOXA -->
        <div style="background:#EFF6FF;border-radius:8px;padding:8px 10px;border:2px solid #2563EB">
          <div style="font-weight:800;color:#1D4ED8;margin-bottom:6px;font-size:12px">📡 MOXA E1212</div>
          <div style="font-size:10px;color:#3B82F6;margin-bottom:6px">Modbus TCP — 192.168.127.254</div>

          <!-- DO Çıkışlar -->
          <div style="font-size:10px;font-weight:700;color:#6B7280;margin-bottom:4px;text-transform:uppercase">ÇIKIŞLAR (DO)</div>
          <?php foreach ([
            ['D10','Coil 0','Vakum Komp.','#7C3AED','do0'],
            ['D11','Coil 1','Valf','#0EA5E9','do1'],
            ['D12','Coil 2','Piston','#D97706','do2'],
            ['D13','Coil 3','Yedek','#6B7280','do3'],
          ] as $p): ?>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
            <div id="led_<?= $p[4] ?>" style="width:10px;height:10px;border-radius:50%;background:#E2E8F0;border:1px solid #94A3B8;flex-shrink:0"></div>
            <span style="font-size:10px;font-weight:700;color:<?= $p[3] ?>;min-width:28px"><?= $p[0] ?></span>
            <span style="font-size:10px;color:var(--m2)"><?= $p[2] ?></span>
          </div>
          <?php endforeach; ?>

          <!-- DI Girişler -->
          <div style="font-size:10px;font-weight:700;color:#6B7280;margin:8px 0 4px;text-transform:uppercase">GİRİŞLER (DI)</div>
          <?php foreach ([
            ['DI00','Basınç Düşük','di0'],
            ['DI01','Basınç Yüksek','di1'],
            ['DI02','Ürün Sensörü','di2'],
            ['DI03','Start Buton','di3'],
            ['DI04','Stop Buton','di4'],
          ] as $p): ?>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
            <div id="led_<?= $p[2] ?>" style="width:10px;height:10px;border-radius:50%;background:#E2E8F0;border:1px solid #94A3B8;flex-shrink:0"></div>
            <span style="font-size:10px;font-weight:700;color:#374151;min-width:32px"><?= $p[0] ?></span>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?></span>
          </div>
          <?php endforeach; ?>
        </div>

      </div><!-- /sol -->

      <!-- Orta: Hat çizgileri + cihazlar -->
      <div style="padding:0 16px;display:flex;flex-direction:column;gap:8px;justify-content:center;min-height:320px">

        <!-- Röleler -->
        <div style="background:#FEF2F2;border-radius:8px;padding:8px 10px;border:1px solid #FCA5A5">
          <div style="font-weight:800;color:#991B1B;font-size:11px;margin-bottom:6px">🔧 RÖLELER (×4)</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">
            <?php foreach (['Vakum','Valf','Piston','Yedek'] as $i => $ad): ?>
            <div id="role_<?= $i ?>" style="background:#fff;border-radius:4px;padding:4px 6px;border:1px solid #FCA5A5;font-size:10px;font-weight:700;color:#7F1D1D;text-align:center">
              R<?= $i+1 ?>: <?= $ad ?>
            </div>
            <?php endforeach; ?>
          </div>
          <div style="font-size:10px;color:#9CA3AF;margin-top:4px">COM:11 NO:14 A2:− A1:+</div>
        </div>

        <!-- Basınç Ölçer -->
        <div style="background:#F0FDF4;border-radius:8px;padding:8px 10px;border:1px solid #86EFAC">
          <div style="font-weight:800;color:#065F46;font-size:11px;margin-bottom:4px">📊 BASINÇ ÖLÇER</div>
          <div style="font-size:22px;font-weight:900;color:#059669" id="basincGoster">0.00 <span style="font-size:12px">bar</span></div>
          <div id="basincBar" style="height:6px;background:#E2E8F0;border-radius:3px;margin-top:6px;overflow:hidden">
            <div id="basincBarFill" style="height:100%;background:#22C55E;width:0%;transition:width .5s;border-radius:3px"></div>
          </div>
        </div>

      </div><!-- /orta -->

      <!-- Sağ: Mekanik Cihazlar -->
      <div style="display:flex;flex-direction:column;gap:8px">

        <!-- Vakum Kompresör -->
        <div id="cihaz_vakum" style="background:#F5F3FF;border-radius:8px;padding:8px 10px;border:1px solid #DDD6FE">
          <div style="font-weight:800;color:#5B21B6;font-size:11px">🔄 VAKUM KOMPRESÖR</div>
          <div id="vakum_durum" style="font-size:10px;color:#8B5CF6;margin-top:2px">● Kapalı</div>
          <div style="font-size:10px;color:#9CA3AF">Hava Giriş</div>
        </div>

        <!-- Valf -->
        <div id="cihaz_valf" style="background:#EFF6FF;border-radius:8px;padding:8px 10px;border:1px solid #BFDBFE">
          <div style="font-weight:800;color:#1D4ED8;font-size:11px">🔩 VALF</div>
          <div id="valf_durum" style="font-size:10px;color:#3B82F6;margin-top:2px">● Kapalı</div>
          <div style="font-size:10px;color:#9CA3AF">Hava Giriş</div>
        </div>

        <!-- Piston -->
        <div id="cihaz_piston" style="background:#FFF7ED;border-radius:8px;padding:8px 10px;border:1px solid #FED7AA">
          <div style="font-weight:800;color:#92400E;font-size:11px">⬆️ PİSTON</div>
          <div id="piston_durum" style="font-size:10px;color:#D97706;margin-top:2px">● Açık</div>
        </div>

        <!-- Hortum Bağlama Aparatı -->
        <div style="background:#F0FDF4;border-radius:8px;padding:8px 10px;border:1px solid #86EFAC">
          <div style="font-weight:800;color:#065F46;font-size:11px">🔗 HORTUM BAĞLAMA</div>
          <div id="hortu_durum" style="font-size:10px;margin-top:2px">
            <span id="sensor_durum" style="color:#94A3B8">○ Ürün yok</span>
          </div>
        </div>

      </div><!-- /sağ -->

    </div><!-- /grid -->
  </div><!-- /kart şema -->

  <!-- Test Logları -->
  <div class="kart" style="padding:14px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
      <div style="font-weight:800;font-size:13px;color:var(--t)">📋 Test Logları</div>
      <button onclick="logTemizle()" class="btn btn-b btn-sm" style="font-size:10px">Temizle</button>
    </div>
    <div id="logKutu" style="background:#0F172A;border-radius:8px;padding:10px;height:180px;overflow-y:auto;font-family:monospace;font-size:11px;color:#E2E8F0">
      <div style="color:#64748B">// Bağlantı bekleniyor...</div>
    </div>
  </div>

</div><!-- /sol -->

<!-- SAĞ: Test Kontrol Paneli ───────────────────────────── -->
<div>

  <!-- Test Durumu -->
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t)">🧪 Test Kontrolü</div>

    <!-- Ürün Kodu -->
    <div style="margin-bottom:10px">
      <label class="form-et">Ürün Kodu</label>
      <input class="form-alan" id="urunKodu" placeholder="Ürün kodu girin..." style="font-size:12px">
    </div>

    <!-- Test Durumu Göstergesi -->
    <div id="testDurum" style="background:#F8FAFC;border-radius:10px;padding:14px;text-align:center;margin-bottom:12px;border:2px solid var(--kenar)">
      <div id="testAşama" style="font-size:24px;font-weight:900;color:#64748B">BEKLEMEde</div>
      <div id="testAlt" style="font-size:12px;color:var(--m2);margin-top:4px">Hortum bağlayın ve Start basın</div>
      <div id="testSure" style="font-size:11px;color:#94A3B8;margin-top:4px"></div>
    </div>

    <!-- Kontrol Butonları -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <button id="btnBasla" onclick="testBasla()"
              style="padding:14px;border:none;border-radius:var(--r);background:#22C55E;color:#fff;font-weight:800;font-size:13px;cursor:pointer">
        ▶ START
      </button>
      <button id="btnDurdur" onclick="testDurdur()"
              style="padding:14px;border:none;border-radius:var(--r);background:#EF4444;color:#fff;font-weight:800;font-size:13px;cursor:pointer">
        ■ STOP
      </button>
    </div>

    <!-- Manuel DO Kontrol -->
    <div style="border-top:1px solid var(--kenar);padding-top:12px">
      <div style="font-size:11px;font-weight:700;color:var(--m2);margin-bottom:8px;text-transform:uppercase">Manuel Kontrol</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
        <?php foreach ([
          ['0','Vakum Komp.','#7C3AED'],
          ['1','Valf','#0EA5E9'],
          ['2','Piston','#D97706'],
          ['3','Yedek','#6B7280'],
        ] as $do): ?>
        <div style="background:var(--kenar-a);border-radius:6px;padding:6px 8px">
          <div style="font-size:10px;font-weight:700;color:<?= $do[2] ?>;margin-bottom:4px">D1<?= $do[0] ?> — <?= $do[1] ?></div>
          <div style="display:flex;gap:4px">
            <button onclick="doYaz(<?= $do[0] ?>,1)"
                    style="flex:1;padding:4px;border:none;border-radius:4px;background:<?= $do[2] ?>;color:#fff;font-size:10px;font-weight:700;cursor:pointer">ON</button>
            <button onclick="doYaz(<?= $do[0] ?>,0)"
                    style="flex:1;padding:4px;border:none;border-radius:4px;background:#E2E8F0;color:#374151;font-size:10px;font-weight:700;cursor:pointer">OFF</button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <button onclick="tumKapat()" style="width:100%;margin-top:8px;padding:8px;border:none;border-radius:var(--r);background:#DC2626;color:#fff;font-weight:700;font-size:12px;cursor:pointer">
        🚨 Tüm Çıkışları Kapat
      </button>
    </div>

  </div><!-- /test kart -->

  <!-- Bugünkü İstatistikler -->
  <div class="kart" style="padding:14px;margin-bottom:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:var(--t)">📊 Bugün</div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px">
      <?php
      $istat = [
        ['Toplam Test', $bugun['toplam'] ?? 0, '#2563EB'],
        ['Geçti',       $bugun['gecti']  ?? 0, '#22C55E'],
        ['Kaldı',       $bugun['kaldi']  ?? 0, '#EF4444'],
        ['Başarı %',    ($bugun['oran']  ?? 0) . '%', '#D97706'],
      ];
      foreach ($istat as $s): ?>
      <div style="background:var(--kenar-a);border-radius:8px;padding:10px;text-align:center">
        <div style="font-size:20px;font-weight:900;color:<?= $s[2] ?>"><?= $s[1] ?></div>
        <div style="font-size:10px;color:var(--m2);margin-top:2px"><?= $s[0] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Son Kayıtlar -->
  <div class="kart" style="padding:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:var(--t)">🕐 Son Testler</div>
    <div style="overflow-y:auto;max-height:300px">
      <?php if (empty($son_kayitlar)): ?>
      <div style="text-align:center;color:var(--m3);font-size:12px;padding:20px">Kayıt yok</div>
      <?php else: ?>
      <?php foreach ($son_kayitlar as $k): ?>
      <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--kenar)">
        <span style="width:14px;height:14px;border-radius:50%;background:<?= $k['sonuc']==='GECTI'?'#22C55E':($k['sonuc']==='KALDI'?'#EF4444':'#94A3B8') ?>;flex-shrink:0"></span>
        <div style="flex:1;min-width:0">
          <div style="font-size:11px;font-weight:700;color:var(--t);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            <?= htmlspecialchars($k['urun_kodu'] ?: '—') ?>
          </div>
          <div style="font-size:10px;color:var(--m2)"><?= date('H:i', strtotime($k['test_zamani'])) ?></div>
        </div>
        <span style="font-size:10px;font-weight:800;color:<?= $k['sonuc']==='GECTI'?'#065F46':($k['sonuc']==='KALDI'?'#991B1B':'#64748B') ?>">
          <?= $k['sonuc'] ?>
        </span>
        <?php if ($k['sure_ms']): ?>
        <span style="font-size:10px;color:var(--m3)"><?= round($k['sure_ms']/1000,1) ?>s</span>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

</div><!-- /sağ -->
</div><!-- /ana grid -->

</div><!-- /s-body -->

<style>
@media(max-width:900px){ .tank-grid{grid-template-columns:1fr!important} }
</style>

<script>
// ── MOXA Server Otomatik Yönetim ─────────────────────────
var YONET_URL = '<?= BASE_URL ?>/bolumler/kalite/ajax/moxa_server_yonet.php';
var serverCalisiyor = <?= $server_calisiyor ? 'true' : 'false' ?>;

function serverBadgeGuncelle(calisiyor, bilgi) {
    var badge = document.getElementById('serverBadge');
    var btn   = document.getElementById('btnServerToggle');
    var durum = document.getElementById('serverDurum');
    if (!badge) return;
    if (calisiyor) {
        badge.style.background = '#D1FAE5'; badge.style.color = '#065F46';
        badge.textContent = '● Node.js Çalışıyor';
        if (btn) { btn.textContent = '■ Durdur'; btn.style.background = '#EF4444'; }
        if (durum) durum.textContent = bilgi || 'ws://localhost:5050';
    } else {
        badge.style.background = '#FEE2E2'; badge.style.color = '#991B1B';
        badge.textContent = '● Node.js Durdu';
        if (btn) { btn.textContent = '▶ Başlat'; btn.style.background = '#22C55E'; }
        if (durum) durum.textContent = bilgi || '';
    }
}

async function serverBaslat() {
    var btn = document.getElementById('btnServerToggle');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Başlatılıyor...'; }
    try {
        var fd = new FormData(); fd.append('action','baslat');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        var d  = await r.json();
        serverCalisiyor = d.ok && d.calisiyor !== false;
        serverBadgeGuncelle(serverCalisiyor, d.ws_url || d.mesaj);
        if (serverCalisiyor) {
            setTimeout(function(){
                document.getElementById('wsUrl') && (document.getElementById('wsUrl').value = d.ws_url || 'ws://localhost:5050');
                wsBaglan();
            }, 600);
        }
    } catch(e) { serverBadgeGuncelle(false, 'Hata: '+e.message); }
    finally { if(btn) btn.disabled = false; }
}

async function serverDurdur() {
    var btn = document.getElementById('btnServerToggle');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Durduruluyor...'; }
    try {
        if (ws) ws.close();
        var fd = new FormData(); fd.append('action','durdur');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        serverCalisiyor = false;
        serverBadgeGuncelle(false, 'Durduruldu');
    } catch(e) {} finally { if(btn) btn.disabled = false; }
}

function serverToggle() { if(serverCalisiyor) serverDurdur(); else serverBaslat(); }

window.addEventListener('DOMContentLoaded', function(){
    serverBadgeGuncelle(serverCalisiyor);
    if (!serverCalisiyor) { serverBaslat(); }
    else {
        document.getElementById('wsUrl') && (document.getElementById('wsUrl').value = 'ws://localhost:5050');
        setTimeout(wsBaglan, 600);
    }
});

var ws      = null;
var testAktif = false;
var testBaslama = null;
var testTimer = null;

// ── WebSocket ─────────────────────────────────────────────
function wsAyarlarAc() {
    document.getElementById('wsModal').style.display = 'flex';
}

function wsBaglan() {
    document.getElementById('wsModal').style.display = 'none';
    var url = document.getElementById('wsUrl').value.trim();
    if (ws) { ws.close(); ws = null; }

    logEkle('🔗 Bağlanıyor: ' + url);
    ws = new WebSocket(url);

    ws.onopen = function() {
        connDurum(true);
        logEkle('✅ WebSocket bağlandı');
        // Config güncelle
        var moxaIp   = document.getElementById('moxaIp').value.trim();
        var moxaPort = document.getElementById('moxaPort').value.trim();
        var vakumSure= document.getElementById('vakumSure').value.trim();
        ws.send(JSON.stringify({
            komut: 'config_guncelle',
            moxa_host: moxaIp,
            moxa_port: moxaPort,
            vakum_sure: vakumSure,
        }));
    };

    ws.onmessage = function(e) {
        try { mesajIsle(JSON.parse(e.data)); } catch(ex) {}
    };

    ws.onerror = function(e) {
        logEkle('❌ WebSocket hata: ' + (e.message || 'Bilinmiyor'));
    };

    ws.onclose = function() {
        connDurum(false);
        logEkle('🔌 Bağlantı kesildi — 5sn sonra tekrar denenecek');
        setTimeout(function(){ if (!ws || ws.readyState > 1) wsBaglan(); }, 5000);
    };
}

function connDurum(baglandı) {
    var badge = document.getElementById('connBadge');
    var alert = document.getElementById('connAlert');
    if (baglandı) {
        badge.style.background = '#D1FAE5'; badge.style.color = '#065F46';
        badge.textContent = '● Bağlı';
        alert.style.display = 'none';
    } else {
        badge.style.background = '#FEE2E2'; badge.style.color = '#991B1B';
        badge.textContent = '● Bağlı Değil';
        alert.style.display = '';
    }
}

// ── Mesaj İşle ────────────────────────────────────────────
function mesajIsle(d) {
    if (d.tip === 'durum' || d.tip === 'ilk_durum') {
        // LED'leri güncelle
        if (d.do_bits) {
            var doAdlar = ['vakum','valf','piston','yedek'];
            d.do_bits.forEach(function(v, i) {
                var led = document.getElementById('led_do'+i);
                if (led) {
                    led.style.background = v ? '#22C55E' : '#E2E8F0';
                    led.style.boxShadow  = v ? '0 0 6px #22C55E' : 'none';
                }
                var role = document.getElementById('role_'+i);
                if (role) {
                    role.style.background = v ? '#D1FAE5' : '#fff';
                    role.style.borderColor= v ? '#22C55E' : '#FCA5A5';
                }
            });
            // Cihaz durumları
            var vakumAcik = d.do_bits[0];
            var valfAcik  = d.do_bits[1];
            var pistonAcik= d.do_bits[2];
            el('vakum_durum').textContent  = vakumAcik ? '● Çalışıyor' : '● Kapalı';
            el('vakum_durum').style.color  = vakumAcik ? '#22C55E' : '#8B5CF6';
            el('valf_durum').textContent   = valfAcik  ? '● Açık'    : '● Kapalı';
            el('valf_durum').style.color   = valfAcik  ? '#22C55E' : '#3B82F6';
            el('piston_durum').textContent = pistonAcik ? '● Kilitli'  : '● Açık';
            el('piston_durum').style.color = pistonAcik ? '#EF4444' : '#D97706';
        }

        if (d.di_bits) {
            d.di_bits.forEach(function(v, i) {
                var led = document.getElementById('led_di'+i);
                if (led) {
                    led.style.background = v ? '#22C55E' : '#E2E8F0';
                    led.style.boxShadow  = v ? '0 0 6px #22C55E' : 'none';
                }
            });
            // Sensör
            var urunVar = d.di_bits[2];
            el('sensor_durum').textContent = urunVar ? '● Ürün/Hortum Bağlı' : '○ Ürün yok';
            el('sensor_durum').style.color  = urunVar ? '#22C55E' : '#94A3B8';
        }

        // Basınç
        if (d.basinc !== undefined) {
            var b = parseFloat(d.basinc).toFixed(2);
            el('basincGoster').innerHTML = b + ' <span style="font-size:12px">bar</span>';
            var pct = Math.min(parseFloat(d.basinc) / 1.0 * 100, 100);
            el('basincBarFill').style.width = pct + '%';
            el('basincBarFill').style.background = pct > 80 ? '#22C55E' : pct > 40 ? '#F59E0B' : '#EF4444';
        }

        // Test durumu
        if (d.test) guncellTestAşama(d.test);
    }

    if (d.tip === 'baglanti') {
        connDurum(d.durum === 'baglandı');
        logEkle('📡 MOXA: ' + d.mesaj);
    }

    if (d.tip === 'test_basladi') {
        testAktif = true;
        testBaslama = Date.now();
        testTimer = setInterval(sureGuncelle, 500);
        logEkle('▶ Test başladı');
    }

    if (d.tip === 'test_bitti') {
        testAktif = false;
        clearInterval(testTimer);
        var sonuc = d.sonuc;
        logEkle((sonuc==='GECTI'?'✅':'❌') + ' Test tamamlandı: ' + sonuc + ' — ' + (d.test.sure_ms/1000).toFixed(1) + 'sn');
        // DB'ye kaydet
        kaydetDB(sonuc, d.test.sure_ms);
        // Sonuç göster
        el('testAşama').textContent = sonuc === 'GECTI' ? '✅ GEÇTİ' : '❌ KALDI';
        el('testAşama').style.color = sonuc === 'GECTI' ? '#22C55E' : '#EF4444';
        el('testDurum').style.borderColor = sonuc === 'GECTI' ? '#22C55E' : '#EF4444';
        el('testDurum').style.background  = sonuc === 'GECTI' ? '#D1FAE5' : '#FEE2E2';
    }

    if (d.tip === 'test_hata') {
        testAktif = false;
        clearInterval(testTimer);
        logEkle('⚠️ ' + d.mesaj);
        guncellTestAşama({aşama:'HATA'});
    }

    if (d.tip === 'test_log') {
        logEkle('  ↳ ' + d.mesaj);
    }
}

function guncellTestAşama(test) {
    var renk = {'BEKLEMEDE':'#64748B','BASLATIYOR':'#D97706','VAKUM':'#2563EB','TEST':'#7C3AED','TAMAMLANDI':'#22C55E','HATA':'#EF4444','IPTAL':'#94A3B8'};
    var metin = {'BEKLEMEDE':'BEKLEMEde','BASLATIYOR':'Başlatılıyor...','VAKUM':'Vakum Oluşturuluyor','TEST':'Basınç Test Ediliyor','TAMAMLANDI':'Tamamlandı','HATA':'HATA','IPTAL':'İptal'};
    var c = renk[test.aşama] || '#64748B';
    el('testAşama').textContent = metin[test.aşama] || test.aşama;
    el('testAşama').style.color = c;
    el('testDurum').style.borderColor = c;
}

function sureGuncelle() {
    if (!testBaslama) return;
    var sn = ((Date.now() - testBaslama) / 1000).toFixed(1);
    el('testSure').textContent = '⏱ ' + sn + ' sn';
}

// ── Komutlar ──────────────────────────────────────────────
function wsSend(obj) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        logEkle('⚠️ Bağlı değil'); return;
    }
    ws.send(JSON.stringify(obj));
}

function doYaz(addr, deger) { wsSend({komut:'do_yaz', addr:addr, deger:deger}); }
function testBasla()        { wsSend({komut:'test_basla'}); }
function testDurdur()       { wsSend({komut:'test_durdur'}); }
function tumKapat()         { wsSend({komut:'tum_kapat'}); logEkle('🚨 Tüm çıkışlar kapatıldı'); }

// ── DB Kaydet ─────────────────────────────────────────────
async function kaydetDB(sonuc, sure_ms) {
    try {
        var urun = el('urunKodu').value.trim();
        var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/tank_test_kaydet.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},
            body: JSON.stringify({sonuc, sure_ms, urun_kodu: urun})
        });
        var d = await r.json();
        if (d.ok) logEkle('💾 Kayıt OK (id:' + d.id + ')');
    } catch(e) { logEkle('⚠️ Kayıt hatası: ' + e.message); }
}

// ── Log ───────────────────────────────────────────────────
function logEkle(mesaj) {
    var kutu = el('logKutu');
    var saat = new Date().toLocaleTimeString('tr-TR');
    var div  = document.createElement('div');
    div.style.color = mesaj.startsWith('✅') ? '#4ADE80' : mesaj.startsWith('❌') ? '#F87171' : mesaj.startsWith('⚠️') ? '#FBBf24' : '#94A3B8';
    div.textContent = '[' + saat + '] ' + mesaj;
    kutu.appendChild(div);
    kutu.scrollTop = kutu.scrollHeight;
}

function logTemizle() { el('logKutu').innerHTML = ''; }

function el(id) { return document.getElementById(id); }

// Sayfa kapanırken bağlantıyı kapat
window.addEventListener('beforeunload', function(){ if(ws) ws.close(); });
</script>
