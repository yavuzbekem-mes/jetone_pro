<?php
/**
 * JETONE.PRO — Uygunsuzluk Formu (Yeni Ekle)
 * panel.php: 'kalite-uygunsuzluk-formu' => 'bolumler/kalite/uygunsuzluk_formu.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_isim = $kul['ad_soyad'] ?? $kul['email'] ?? '';
$tiger_ok = ($tigerdb_pdo !== null);

// Tiger: malzeme listesi
$malzemeler = [];
if ($tiger_ok) {
    try {
        $st = $tigerdb_pdo->query("SELECT TOP 3000 CODE AS KOD, NAME AS AD FROM dbo.LG_222_ITEMS WITH(NOLOCK) WHERE ACTIVE=0 AND CODE!='' AND NAME!='' ORDER BY CODE");
        $malzemeler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
}

// Tiger: tedarikçi listesi
$tedarikciler = [];
if ($tiger_ok) {
    try {
        $st = $tigerdb_pdo->query("SELECT DISTINCT CLCARD.CODE KOD, CLCARD.DEFINITION_ AD FROM dbo.LG_222_02_CLFLINE WITH(NOLOCK) LEFT JOIN dbo.LG_222_CLCARD WITH(NOLOCK) ON CLFLINE.CLIENTREF=CLCARD.LOGICALREF ORDER BY CLCARD.DEFINITION_");
        $tedarikciler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📝 Uygunsuzluk Formu</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" style="color:var(--t)">Uygunsuzluk</a> / <b>Yeni Form</b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" class="btn btn-b btn-sm">← Liste</a>
</div>

<div class="s-body">
<div class="kart">
  <div style="text-align:center;margin-bottom:18px">
    <div style="font-size:16px;font-weight:800">UYGUNSUZLUK FORMU</div>
    <div style="font-size:11px;color:var(--m2);margin-top:2px">Doküman No: FR.06 | Rev: 02 | Tarih: 04.07.2024</div>
  </div>

  <form id="uygunsuzlukForm" action="<?= BASE_URL ?>/islemler/kalite/uygunsuzluk_ekle.php" method="POST" enctype="multipart/form-data">

    <!-- Üst bilgiler -->
    <div class="form-grid-3">
      <div class="form-grup">
        <label class="form-et">Takip No <span class="zorunlu">*</span></label>
        <input class="form-alan" type="text" name="takip_no" id="takip_no" readonly required
               style="background:var(--kenar-a);font-family:monospace;font-weight:800">
      </div>
      <div class="form-grup">
        <label class="form-et">Tespit Tarihi <span class="zorunlu">*</span></label>
        <input class="form-alan" type="date" name="tespit_tarihi" id="tespit_tarihi" required
               value="<?= date('Y-m-d') ?>" onchange="takipNoUret()">
      </div>
      <div class="form-grup">
        <label class="form-et">Vardiya <span class="zorunlu">*</span></label>
        <select class="form-alan" name="vardiya" required id="vardiyaSelect">
          <option value="1">1. Vardiya (08:00-16:00)</option>
          <option value="2">2. Vardiya (16:00-24:00)</option>
          <option value="3">3. Vardiya (24:00-08:00)</option>
        </select>
      </div>
    </div>

    <div class="form-grup">
      <label class="form-et">Tespit Eden Kişi <span class="zorunlu">*</span></label>
      <input class="form-alan" type="text" name="tespit_eden_kisi" required value="<?= htmlspecialchars($kul_isim) ?>">
    </div>

    <!-- Uygunsuzluk yeri -->
    <div class="form-grup">
      <label class="form-et">Uygunsuzluk Yeri <span class="zorunlu">*</span></label>
      <div style="display:flex;gap:24px;padding:12px;background:var(--kenar-a);border-radius:var(--r);border:1.5px solid var(--kenar)">
        <?php foreach (['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'] as $v=>$l): ?>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700">
          <input type="radio" name="uygunsuzluk_yeri" value="<?= $v ?>" required
                 style="width:18px;height:18px;accent-color:var(--t)">
          <?= $l ?>
        </label>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Malzeme -->
    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Malzeme/Parça Kodu <span class="zorunlu">*</span></label>
        <select class="form-alan" name="malzeme_kodu" id="malzemeKodu" required>
          <option value="">— Seçiniz —</option>
          <?php foreach ($malzemeler as $m): ?>
          <option value="<?= htmlspecialchars($m['KOD']) ?>" data-ad="<?= htmlspecialchars($m['AD']) ?>">
            <?= htmlspecialchars($m['KOD']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-grup">
        <label class="form-et">Malzeme/Parça Adı <span class="zorunlu">*</span></label>
        <select class="form-alan" name="malzeme_adi" id="malzemeAdi" required>
          <option value="">— Seçiniz —</option>
          <?php foreach ($malzemeler as $m): ?>
          <option value="<?= htmlspecialchars($m['AD']) ?>" data-kod="<?= htmlspecialchars($m['KOD']) ?>">
            <?= htmlspecialchars($m['AD']) ?> — <?= htmlspecialchars($m['KOD']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Tedarikçi Firma</label>
        <select class="form-alan" name="tedarikci_firma">
          <option value="Poliza Endüstri A.Ş." selected>Poliza Endüstri A.Ş.</option>
          <?php foreach ($tedarikciler as $t): ?>
          <option value="<?= htmlspecialchars($t['AD']??'') ?>">
            <?= htmlspecialchars($t['AD']??'') ?> — <?= htmlspecialchars($t['KOD']??'') ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-grup">
        <label class="form-et">Proses Adı</label>
        <input class="form-alan" type="text" name="proses_adi" placeholder="Proses adı...">
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Malzeme Giriş/Üretim Tarihi</label>
        <input class="form-alan" type="date" name="malzeme_giris_tarihi">
      </div>
      <div class="form-grup">
        <label class="form-et">İrsaliye / Fatura No</label>
        <input class="form-alan" type="text" name="irsaliye_no">
      </div>
    </div>

    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Toplam Miktar</label>
        <input class="form-alan" type="number" name="uretim_miktar" step="0.01" min="0">
      </div>
      <div class="form-grup">
        <label class="form-et">Hatalı Miktar <span class="zorunlu">*</span></label>
        <input class="form-alan" type="number" name="hatali_miktar" required step="0.01" min="0">
      </div>
    </div>

    <div class="form-grup">
      <label class="form-et">Uygunsuzluk Sebebi <span class="zorunlu">*</span></label>
      <textarea class="form-alan" name="uygunsuzluk_sebebi" rows="4" required placeholder="Uygunsuzluğu detaylı açıklayın..."></textarea>
    </div>

    <div class="form-grup">
      <label class="form-et">Görsel (opsiyonel)</label>
      <input class="form-alan" type="file" name="uygunsuzluk_gorsel" accept="image/*"
             style="padding:6px">
    </div>

    <!-- İmzalar -->
    <div style="border-top:1px solid var(--kenar);margin:16px 0 12px;padding-top:14px">
      <div style="font-size:13px;font-weight:800;margin-bottom:10px">İmzalar</div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Kalite Kontrol Sorumlusu</label>
          <input class="form-alan" type="text" name="kalite_sorumlu" value="Emine Memduha Barut">
        </div>
        <div class="form-grup">
          <label class="form-et">Kalite Güvence Müdürü</label>
          <input class="form-alan" type="text" name="kalite_mudur" value="Aslı Budak">
        </div>
        <div class="form-grup">
          <label class="form-et">Üretim Müdürü</label>
          <input class="form-alan" type="text" name="uretim_mudur" value="Tarkan Aslan">
        </div>
      </div>
    </div>

    <div class="form-footer">
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" class="btn btn-b">İptal</a>
      <button type="submit" name="uygunsuzluk_ekle" class="btn btn-t">💾 Kaydet & Mail Gönder</button>
    </div>

  </form>
</div>
</div>

<script>
// Vardiya otomatik
(function(){ var h=new Date().getHours(); document.getElementById('vardiyaSelect').value=(h>=8&&h<16)?'1':(h>=16)?'2':'3'; })();

// Takip no üret
function takipNoUret(){
    var tarih = document.getElementById('tespit_tarihi').value;
    if(!tarih) return;
    var d = new Date(tarih);
    var yil = d.getFullYear();
    var ay = String(d.getMonth()+1).padStart(2,'0');
    fetch('<?= BASE_URL ?>/islemler/kalite/get_last_takip_no.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'yil='+yil+'&ay='+ay
    }).then(function(r){ return r.json(); })
    .then(function(d){
        var no = ((d.last_no||0)+1).toString().padStart(3,'0');
        document.getElementById('takip_no').value = yil+ay+no;
    }).catch(function(){ document.getElementById('takip_no').value = yil+ay+'001'; });
}
takipNoUret();

// Malzeme kodu ↔ adı senkronizasyonu
document.getElementById('malzemeKodu').addEventListener('change', function(){
    var opt = this.options[this.selectedIndex];
    var ad = opt.getAttribute('data-ad') || '';
    var sel = document.getElementById('malzemeAdi');
    for(var i=0;i<sel.options.length;i++){
        if(sel.options[i].getAttribute('data-kod')===this.value){ sel.selectedIndex=i; break; }
    }
});
document.getElementById('malzemeAdi').addEventListener('change', function(){
    var opt = this.options[this.selectedIndex];
    var kod = opt.getAttribute('data-kod') || '';
    var sel = document.getElementById('malzemeKodu');
    for(var i=0;i<sel.options.length;i++){
        if(sel.options[i].value===kod){ sel.selectedIndex=i; break; }
    }
});
</script>
