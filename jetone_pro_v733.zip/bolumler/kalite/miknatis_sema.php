<?php
/**
 * JETONE.PRO — Mıknatıs Kontrol Sistemi Şemaları
 * bolumler/kalite/miknatis_sema.php
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📐 Sistem Şemaları</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" style="color:var(--t)">Test Cihazları</a> / <b>Şemalar</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" class="btn btn-b btn-sm">← Cihazlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-monitor" class="btn btn-t btn-sm">📡 Monitor</a>
  </div>
</div>

<div class="s-body">

<?php
$tabs = [
  ['id'=>'akis',   'icon'=>'🔄', 'label'=>'İş Akışı'],
  ['id'=>'pin',    'icon'=>'📌', 'label'=>'Pin Şeması'],
  ['id'=>'parca',  'icon'=>'🔌', 'label'=>'Parça Bağlantıları'],
  ['id'=>'guc',    'icon'=>'⚡', 'label'=>'Güç Devresi'],
  ['id'=>'bom',    'icon'=>'📋', 'label'=>'Malzeme (BOM)'],
];
?>

<!-- Sekme navigasyonu -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:20px;flex-wrap:wrap" id="semaTabs">
  <?php foreach ($tabs as $i => $t): ?>
  <button onclick="tabGoster('<?= $t['id'] ?>')" id="tab_<?= $t['id'] ?>"
          style="padding:8px 14px;border:none;
                 background:<?= $i===0?'var(--t)':'var(--kenar-a)' ?>;
                 color:<?= $i===0?'#fff':'var(--m)' ?>;
                 border-radius:6px 6px 0 0;font-size:13px;font-weight:700;
                 cursor:pointer;margin-bottom:-2px;display:flex;align-items:center;gap:5px">
    <?= $t['icon'] ?> <?= $t['label'] ?>
  </button>
  <?php endforeach; ?>
</div>

<!-- ── İŞ AKIŞI ŞEMASI ─────────────────────────────────────── -->
<div id="sema_akis">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">Tekmelik Mıknatıs Kontrol — İş Akışı v5.4</h3>
  <div style="overflow-x:auto">
  <svg width="100%" viewBox="0 0 720 900" style="max-width:720px;display:block;margin:0 auto">
    <defs>
      <marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
        <path d="M2 1L8 5L2 9" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </marker>
    </defs>
    <?php
    $nodes = [
      [260,20,200,52,'#E2E8F0','#475569','#334155','Bekleme','Solenoid AÇIK — ürün koyulabilir'],
      [260,102,200,52,'#CCFBF1','#0F766E','#115E59','SN04-N Tetiklendi','Yakınlık LOW — ürün algılandı'],
      [260,184,200,52,'#FEF9C3','#92400E','#78350F','1 sn Bekle','Ürün fikstüre oturdu'],
      [260,266,200,52,'#FEE2E2','#991B1B','#7F1D1D','Solenoid KAPAT','Her 2 valf — ürün kilitlendi'],
      [260,348,200,52,'#FEF9C3','#92400E','#78350F','6 sn Bekle','Geri sayım OLED ekranda'],
      [260,430,200,52,'#CCFBF1','#0F766E','#115E59','Hall x3 Oku','M1 M2 M3 — US1881'],
      [260,512,200,44,'#E0E7FF','#3730A3','#312E81','3 mıknatıs tamam?',''],
    ];
    foreach ($nodes as $n):
      [$x,$y,$w,$h,$bg,$stroke,$tc,$t1,$t2] = $n;
    ?>
    <rect x="<?=$x?>" y="<?=$y?>" width="<?=$w?>" height="<?=$h?>" rx="8" fill="<?=$bg?>" stroke="<?=$stroke?>" stroke-width="1.5"/>
    <text x="<?=$x+$w/2?>" y="<?=$y+($t2?20:$h/2)?>" text-anchor="middle" dominant-baseline="central" font-size="13" font-weight="700" fill="<?=$tc?>"><?=$t1?></text>
    <?php if($t2): ?>
    <text x="<?=$x+$w/2?>" y="<?=$y+$h-14?>" text-anchor="middle" dominant-baseline="central" font-size="11" fill="<?=$stroke?>"><?=$t2?></text>
    <?php endif; ?>
    <?php endforeach; ?>
    <?php $ys = [72,154,236,318,400,482]; foreach ($ys as $y): ?>
    <line x1="360" y1="<?=$y?>" x2="360" y2="<?=$y+30?>" stroke="#64748B" stroke-width="1.5" marker-end="url(#arr)"/>
    <?php endforeach; ?>
    <line x1="460" y1="534" x2="560" y2="534" stroke="#16A34A" stroke-width="2" marker-end="url(#arr)"/>
    <text x="507" y="525" text-anchor="middle" font-size="11" font-weight="700" fill="#16A34A">EVET</text>
    <line x1="360" y1="556" x2="360" y2="596" stroke="#DC2626" stroke-width="2" marker-end="url(#arr)"/>
    <text x="340" y="578" text-anchor="end" font-size="11" font-weight="700" fill="#DC2626">HAYIR</text>
    <rect x="560" y="510" width="150" height="52" rx="8" fill="#D1FAE5" stroke="#059669" stroke-width="1.5"/>
    <text x="635" y="528" text-anchor="middle" font-size="13" font-weight="700" fill="#065F46">Başarılı</text>
    <text x="635" y="549" text-anchor="middle" font-size="11" fill="#059669">Yeşil LED + Ping</text>
    <line x1="635" y1="562" x2="635" y2="610" stroke="#059669" stroke-width="1.5" marker-end="url(#arr)"/>
    <rect x="560" y="610" width="150" height="52" rx="8" fill="#D1FAE5" stroke="#059669" stroke-width="1.5"/>
    <text x="635" y="628" text-anchor="middle" font-size="13" font-weight="700" fill="#065F46">Etiket Bas</text>
    <text x="635" y="649" text-anchor="middle" font-size="11" fill="#059669">ZPL → Zebra</text>
    <line x1="635" y1="662" x2="635" y2="710" stroke="#059669" stroke-width="1.5" marker-end="url(#arr)"/>
    <rect x="560" y="710" width="150" height="52" rx="8" fill="#D1FAE5" stroke="#059669" stroke-width="1.5"/>
    <text x="635" y="728" text-anchor="middle" font-size="13" font-weight="700" fill="#065F46">Solenoid AÇ</text>
    <text x="635" y="749" text-anchor="middle" font-size="11" fill="#059669">Parça alınabilir</text>
    <text x="720" y="530" text-anchor="start" font-size="10" fill="#94A3B8">DB: basarili</text>
    <rect x="180" y="596" width="220" height="52" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="290" y="614" text-anchor="middle" font-size="13" font-weight="700" fill="#7F1D1D">Kırmızı LED + Buzzer</text>
    <text x="290" y="635" text-anchor="middle" font-size="11" fill="#DC2626">OLED: eksik mıknatıs</text>
    <text x="150" y="620" text-anchor="end" font-size="10" fill="#94A3B8">DB: hata_N</text>
    <line x1="290" y1="648" x2="290" y2="690" stroke="#DC2626" stroke-width="1.5" marker-end="url(#arr)"/>
    <rect x="180" y="690" width="220" height="52" rx="8" fill="#FEF9C3" stroke="#D97706" stroke-width="1.5"/>
    <text x="290" y="708" text-anchor="middle" font-size="13" font-weight="700" fill="#78350F">3 sn Bekle</text>
    <text x="290" y="729" text-anchor="middle" font-size="11" fill="#D97706">Tekrar Hall kontrolü</text>
    <path d="M180 716 L130 716 L130 456 L260 456" fill="none" stroke="#D97706" stroke-width="1.5" stroke-dasharray="5 3" marker-end="url(#arr)"/>
    <text x="122" y="590" text-anchor="end" font-size="10" fill="#D97706">tekrar</text>
    <line x1="635" y1="762" x2="635" y2="840" stroke="#059669" stroke-width="1.5" marker-end="url(#arr)"/>
    <rect x="560" y="840" width="150" height="44" rx="8" fill="#E2E8F0" stroke="#475569" stroke-width="1"/>
    <text x="635" y="862" text-anchor="middle" font-size="13" font-weight="700" fill="#334155">Ürün Alındı</text>
    <path d="M560 862 L360 862 L360 796" fill="none" stroke="#475569" stroke-width="1" stroke-dasharray="4 3" marker-end="url(#arr)"/>
    <text x="460" y="856" text-anchor="middle" font-size="10" fill="#94A3B8">beklemeye dön</text>
  </svg>
  </div>
</div>
</div>

<!-- ── PIN BAĞLANTI ŞEMASI ─────────────────────────────────── -->
<div id="sema_pin" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">ESP32 Pin Bağlantı Şeması — v5.4</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="pin-grid">
    <div>
      <div style="font-size:12px;font-weight:800;color:var(--m2);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px;border-bottom:2px solid #1D9E75;padding-bottom:4px">GİRİŞLER</div>
      <?php foreach ([
        ['34','SN04-N NPN Yakınlık','Ürün varlık algılama','LOW = ürün var — input-only, dış 10kΩ pull-down','#0F766E'],
        ['35','US1881 Hall — M1','1. mıknatıs','LOW = mıknatıs var — input-only, dış 10kΩ pull-down','#0F766E'],
        ['32','US1881 Hall — M2','2. mıknatıs','LOW = mıknatıs var — INPUT_PULLDOWN','#0F766E'],
        ['33','US1881 Hall — M3','3. mıknatıs','LOW = mıknatıs var — INPUT_PULLDOWN','#0F766E'],
      ] as $g): ?>
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:10px 12px;margin-bottom:8px;border-left:4px solid <?= $g[4] ?>">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
          <code style="background:#0F766E;color:#fff;padding:2px 8px;border-radius:4px;font-size:13px;font-weight:800;min-width:32px;text-align:center"><?= $g[0] ?></code>
          <span style="font-weight:700;font-size:13px"><?= $g[1] ?></span>
        </div>
        <div style="font-size:11px;color:var(--m2);margin-left:42px"><?= $g[2] ?></div>
        <div style="font-size:11px;color:<?= $g[4] ?>;margin-left:42px;font-weight:700"><?= $g[3] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div>
      <div style="font-size:12px;font-weight:800;color:var(--m2);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px;border-bottom:2px solid #D97706;padding-bottom:4px">ÇIKIŞLAR</div>
      <?php foreach ([
        ['27','Röle IN1 → Solenoid 1','Fikstür kilidi 1','HIGH = solenoid enerjili (KAPALI)','#DC2626'],
        ['13','Röle IN2 → Solenoid 2','Fikstür kilidi 2','HIGH = solenoid enerjili (KAPALI)','#DC2626'],
        ['25','Trafik Işığı — Yeşil','Başarı göstergesi','HIGH = yanar','#16A34A'],
        ['26','Trafik Işığı — Sarı','Kontrol aşaması','HIGH = yanar','#D97706'],
        ['14','Trafik Işığı — Kırmızı','Hata göstergesi','HIGH = yanar/yanıp söner','#DC2626'],
        ['4', 'Aktif Buzzer','Sesli uyarı','HIGH = ses','#7C3AED'],
        ['17','UART2 TX → Yazıcı RX','Zebra ZPL çıkış','9600 baud','#2563EB'],
        ['16','UART2 RX ← Yazıcı TX','Geri bildirim','Opsiyonel','#2563EB'],
      ] as $c): ?>
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:10px 12px;margin-bottom:8px;border-left:4px solid <?= $c[4] ?>">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
          <code style="background:<?= $c[4] ?>;color:#fff;padding:2px 8px;border-radius:4px;font-size:13px;font-weight:800;min-width:32px;text-align:center"><?= $c[0] ?></code>
          <span style="font-weight:700;font-size:13px"><?= $c[1] ?></span>
        </div>
        <div style="font-size:11px;color:var(--m2);margin-left:42px"><?= $c[2] ?></div>
        <div style="font-size:11px;color:<?= $c[4] ?>;margin-left:42px;font-weight:700"><?= $c[3] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="margin-top:16px">
    <div style="font-size:12px;font-weight:800;color:var(--m2);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px;border-bottom:2px solid #7C3AED;padding-bottom:4px">I2C BUS — SDA=21, SCL=22</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px">
      <?php foreach ([
        ['0x3C','OLED SSD1306 0.96"','128x64 piksel — durum ekranı','Her aşamada mesaj gösterir'],
        ['0x68','DS3231 RTC','Hassas saat/tarih modülü','Etiket tarih/saat damgası'],
      ] as $d): ?>
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:10px 12px;border-left:4px solid #7C3AED">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
          <code style="background:#7C3AED;color:#fff;padding:2px 10px;border-radius:4px;font-size:12px;font-weight:800"><?= $d[0] ?></code>
          <span style="font-weight:700;font-size:13px"><?= $d[1] ?></span>
        </div>
        <div style="font-size:11px;color:var(--m2);margin-left:42px"><?= $d[2] ?></div>
        <div style="font-size:11px;color:#7C3AED;margin-left:42px"><?= $d[3] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</div>

<!-- ── PARÇA BAĞLANTILARI ─────────────────────────────────── -->
<div id="sema_parca" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:4px;color:var(--t)">🔌 Parça Bağlantı Detayları</h3>
  <p style="font-size:12px;color:var(--m2);margin-bottom:16px">Her bileşenin pinleri, hangi kablo hangi noktaya bağlanıyor — detaylı rehber</p>

  <!-- Alt sekmeler -->
  <div style="display:flex;gap:3px;flex-wrap:wrap;border-bottom:2px solid var(--kenar);margin-bottom:16px" id="parcaTabs">
    <?php
    $parcalar = [
      ['solenoid',   '⚙️',  'Solenoid + Röle'],
      ['oled',       '🖥️',  'OLED Ekran'],
      ['buzzer',     '🔊',  'Buzzer'],
      ['trafik',     '🚦',  'Trafik Işığı'],
      ['diyot',      '⚡',  '1N4007 Diyot'],
      ['rtc',        '🕐',  'DS3231 RTC'],
      ['hall',       '🧲',  'Hall Sensörler'],
      ['urun_sns',   '📡',  'Ürün Sensörü'],
      ['topo',       '🗺️',  'Tam Bağlantı'],
    ];
    foreach ($parcalar as $i => $p): ?>
    <button onclick="parcaGoster('<?= $p[0] ?>')" id="ptab_<?= $p[0] ?>"
            style="padding:6px 12px;border:none;background:<?= $i===0?'#1E3A5F':'var(--kenar-a)' ?>;
                   color:<?= $i===0?'#fff':'var(--m)' ?>;border-radius:6px 6px 0 0;
                   font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px">
      <?= $p[1] ?> <?= $p[2] ?>
    </button>
    <?php endforeach; ?>
  </div>

  <!-- SOLENOID + RÖLE -->
  <div id="parca_solenoid">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="pin-grid">

      <!-- SOLENOİD -->
      <div>
        <div style="font-size:13px;font-weight:800;color:#DC2626;margin-bottom:10px">⚙️ 12V Solenoid Valf — 2 adet (Her biri ayrı röle üzerinden)</div>
        <div style="background:#FEF2F2;border-radius:10px;padding:14px;border:1px solid #FCA5A5">
          <div style="font-size:11px;font-weight:700;color:#7F1D1D;margin-bottom:10px;text-transform:uppercase">Her solenoidin 2 ucu</div>
          <?php foreach ([
            ['+','Kırmızı kablo','Röle NO ucundan → 12V DC','#DC2626','Solenoid + ucu'],
            ['−','Siyah kablo', '12V GND / ortak GND hattına','#374151','Solenoid − ucu'],
          ] as $p): ?>
          <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:8px;background:#fff;border-radius:6px;border-left:3px solid <?= $p[3] ?>">
            <code style="background:<?= $p[3] ?>;color:#fff;padding:3px 10px;border-radius:4px;font-weight:800;font-size:14px;min-width:32px;text-align:center"><?= $p[0] ?></code>
            <div>
              <div style="font-weight:700;font-size:12px"><?= $p[1] ?></div>
              <div style="font-size:11px;color:var(--m2)"><?= $p[2] ?></div>
              <div style="font-size:11px;color:<?= $p[3] ?>;font-weight:700"><?= $p[4] ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <div style="background:#FEE2E2;border-radius:6px;padding:8px;margin-top:8px;font-size:11px;color:#7F1D1D">
            <strong>⚠️ 1N4007 Flyback Diyot</strong> — Her solenoid için zorunlu.<br>
            Katot (çizgili uç) → Solenoid (+) ucuna, Anot → (−) ucuna bağla.<br>
            Bobinden kaynaklanan ters gerilimi söndürür, röle ve ESP32&#39;yi korur.
          </div>
        </div>

        <!-- Solenoid × Röle bağlantı özeti -->
        <div style="margin-top:12px;background:#FFF7ED;border-radius:10px;padding:12px;border:1px solid #FED7AA">
          <div style="font-size:11px;font-weight:800;color:#92400E;margin-bottom:8px;text-transform:uppercase">Solenoid 1 → Röle 1 bağlantısı</div>
          <div style="font-size:11px;color:#78350F;line-height:1.8">
            12V(+) → Röle COM1<br>
            Röle NO1 → Solenoid 1 (+)<br>
            Solenoid 1 (−) → GND<br>
            <span style="color:#D97706">GPIO 27 → Röle IN1 (LOW = çeker)</span>
          </div>
          <div style="font-size:11px;font-weight:800;color:#92400E;margin-top:8px;margin-bottom:4px;text-transform:uppercase">Solenoid 2 → Röle 2 bağlantısı</div>
          <div style="font-size:11px;color:#78350F;line-height:1.8">
            12V(+) → Röle COM2<br>
            Röle NO2 → Solenoid 2 (+)<br>
            Solenoid 2 (−) → GND<br>
            <span style="color:#D97706">GPIO 13 → Röle IN2 (LOW = çeker)</span>
          </div>
        </div>
      </div>

      <!-- RÖLE -->
      <div>
        <div style="font-size:13px;font-weight:800;color:#DC2626;margin-bottom:10px">🔧 1 Kanallı Röle Modülü × 2 adet (Her solenoid için ayrı)</div>
        <div style="background:#FEF2F2;border-radius:10px;padding:14px;border:1px solid #FCA5A5">

          <div style="font-size:11px;font-weight:700;color:#7F1D1D;margin-bottom:4px;text-transform:uppercase">Kontrol Tarafı — 3 pin (GND, VCC, IN)</div>
          <div style="font-size:10px;color:#9CA3AF;margin-bottom:10px">Modülün kontrol bloğu — ESP32'ye bağlanır</div>
          <?php foreach ([
            ['GND','Siyah','ESP32 GND','#374151','Kontrol devresi toprak'],
            ['VCC','Kırmızı','ESP32 5V veya harici 5V','#DC2626','Röle coil beslemesi'],
            ['IN', 'Sarı/Turuncu','GPIO 27 (Röle-1) veya GPIO 13 (Röle-2)','#D97706','LOW = röle çeker'],
          ] as $p): ?>
          <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:7px;padding:7px 10px;background:#fff;border-radius:6px;border-left:3px solid <?= $p[3] ?>">
            <code style="background:<?= $p[3] ?>;color:#fff;padding:2px 8px;border-radius:4px;font-weight:800;font-size:12px;min-width:36px;text-align:center"><?= $p[0] ?></code>
            <div>
              <span style="font-weight:700;font-size:12px"><?= $p[1] ?></span>
              <span style="font-size:11px;color:var(--m2);margin-left:4px">— <?= $p[2] ?></span>
              <div style="font-size:11px;color:<?= $p[3] ?>;font-weight:700"><?= $p[4] ?></div>
            </div>
          </div>
          <?php endforeach; ?>

          <div style="font-size:11px;font-weight:700;color:#7F1D1D;margin-bottom:4px;margin-top:12px;text-transform:uppercase">Yük Tarafı — 2 pin (COM, NO)</div>
          <div style="font-size:10px;color:#9CA3AF;margin-bottom:10px">Modülün yük terminali — 12V devresi buraya girer</div>
          <?php foreach ([
            ['COM','Gri','12V(+) güç kaynağından','#6B7280','Ortak uç — 12V giriş'],
            ['NO', 'Kırmızı','Solenoid (+) ucuna','#DC2626','Normally Open — röle çekince bağlanır'],
          ] as $p): ?>
          <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:7px;padding:7px 10px;background:#fff;border-radius:6px;border-left:3px solid <?= $p[3] ?>">
            <code style="background:<?= $p[3] ?>;color:#fff;padding:2px 8px;border-radius:4px;font-weight:800;font-size:12px;min-width:36px;text-align:center"><?= $p[0] ?></code>
            <div>
              <span style="font-weight:700;font-size:12px"><?= $p[1] ?></span>
              <span style="font-size:11px;color:var(--m2);margin-left:4px">— <?= $p[2] ?></span>
              <div style="font-size:11px;color:<?= $p[3] ?>;font-weight:700"><?= $p[4] ?></div>
            </div>
          </div>
          <?php endforeach; ?>

          <div style="background:#EFF6FF;border-radius:6px;padding:8px;margin-top:8px;font-size:11px;color:#1D4ED8">
            💡 <strong>LOW aktif</strong>: IN pinine LOW (0V) verilince röle çeker, solenoid enerjilenir = fikstür KAPALI<br>
            💡 <strong>HIGH veya bağlı değil</strong>: röle açık, solenoid enerjisiz = fikstür AÇIK
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- OLED EKRAN -->
  <div id="parca_oled" style="display:none">
    <div style="max-width:520px">
      <div style="font-size:13px;font-weight:800;color:#7C3AED;margin-bottom:10px">🖥️ 0.96" OLED I2C SSD1306 — 4 Pin</div>
      <div style="background:#F5F3FF;border-radius:10px;padding:16px;border:1px solid #DDD6FE">
        <div style="font-size:11px;font-weight:700;color:#5B21B6;margin-bottom:12px;text-transform:uppercase">Modül Pinleri (soldan sağa)</div>
        <?php foreach ([
          ['GND', '1', 'Siyah', 'ESP32 GND pinine','#374151', 'Toprak'],
          ['VCC', '2', 'Kırmızı','ESP32 3.3V veya 5V pinine','#DC2626','Güç — her ikisi de çalışır'],
          ['SCL', '3', 'Sarı',  'ESP32 GPIO 22 (I2C Clock)','#D97706','I2C saat hattı'],
          ['SDA', '4', 'Mavi',  'ESP32 GPIO 21 (I2C Data)','#2563EB', 'I2C veri hattı'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding:10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[4] ?>">
          <div style="text-align:center;min-width:40px">
            <code style="background:<?= $p[4] ?>;color:#fff;padding:3px 8px;border-radius:4px;font-weight:800;font-size:13px;display:block"><?= $p[0] ?></code>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?>. pin</span>
          </div>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[2] ?> kablo → <?= $p[3] ?></div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[5] ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <div style="background:#EDE9FE;border-radius:6px;padding:10px;font-size:11px;color:#5B21B6">
          <strong>I2C Adresi:</strong> 0x3C (default) — birden fazla OLED varsa jumper ile 0x3D yapılabilir<br>
          <strong>Pull-up:</strong> SDA ve SCL hatlarına 4.7kΩ pull-up direnci (genellikle modülde dahili var)
        </div>
      </div>
    </div>
  </div>

  <!-- BUZZER -->
  <div id="parca_buzzer" style="display:none">
    <div style="max-width:520px">
      <div style="font-size:13px;font-weight:800;color:#7C3AED;margin-bottom:10px">🔊 Aktif Buzzer Modülü — 3 Pin</div>
      <div style="background:#F5F3FF;border-radius:10px;padding:16px;border:1px solid #DDD6FE">
        <div style="font-size:11px;font-weight:700;color:#5B21B6;margin-bottom:12px;text-transform:uppercase">Modül Pinleri</div>
        <?php foreach ([
          ['VCC', '1', 'Kırmızı', 'ESP32 5V veya 3.3V','#DC2626', 'Güç beslemesi'],
          ['GND', '2', 'Siyah',   'ESP32 GND','#374151',           'Toprak'],
          ['I/O', '3', 'Sarı',    'ESP32 GPIO 4','#D97706',         'HIGH = ses çıkar, LOW = sessiz'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding:10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[4] ?>">
          <div style="text-align:center;min-width:40px">
            <code style="background:<?= $p[4] ?>;color:#fff;padding:3px 8px;border-radius:4px;font-weight:800;font-size:13px;display:block"><?= $p[0] ?></code>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?>. pin</span>
          </div>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[2] ?> kablo → <?= $p[3] ?></div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[5] ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <div style="background:#FEF9C3;border-radius:6px;padding:10px;font-size:11px;color:#78350F">
          <strong>Aktif buzzer</strong> — dahili osilatörü var, sadece DC gerilim yeterli.<br>
          Pasif buzzer ile karıştırılmamalı — pasif buzzerda frekans verilmesi gerekir.
        </div>
      </div>
    </div>
  </div>

  <!-- TRAFİK IŞIĞI -->
  <div id="parca_trafik" style="display:none">
    <div style="max-width:520px">
      <div style="font-size:13px;font-weight:800;color:#D97706;margin-bottom:10px">🚦 Trafik Işığı Modülü — 4 Pin</div>
      <div style="background:#FFFBEB;border-radius:10px;padding:16px;border:1px solid #FDE68A">
        <div style="font-size:11px;font-weight:700;color:#92400E;margin-bottom:12px;text-transform:uppercase">Modül Pinleri</div>
        <?php foreach ([
          ['GND', '1', 'Siyah',   'ESP32 GND','#374151',           'Ortak toprak'],
          ['R',   '2', 'Kırmızı', 'ESP32 GPIO 14','#DC2626',        'Kırmızı LED — HIGH = yanar (hata)'],
          ['Y',   '3', 'Sarı',    'ESP32 GPIO 26','#D97706',        'Sarı LED — HIGH = yanar (kontrol aşaması)'],
          ['G',   '4', 'Yeşil',   'ESP32 GPIO 25','#16A34A',        'Yeşil LED — HIGH = yanar (başarılı)'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding:10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[4] ?>">
          <div style="text-align:center;min-width:40px">
            <code style="background:<?= $p[4] ?>;color:#fff;padding:3px 8px;border-radius:4px;font-weight:800;font-size:13px;display:block"><?= $p[0] ?></code>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?>. pin</span>
          </div>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[2] ?> kablo → <?= $p[3] ?></div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[5] ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <div style="background:#FEF9C3;border-radius:6px;padding:10px;font-size:11px;color:#78350F">
          Modülde seri direnç dahil — direkt GPIO'ya bağlanabilir.<br>
          Kırmızı LED hata durumunda 600ms'de bir yanıp söner (kod yazılımda).
        </div>
      </div>
    </div>
  </div>

  <!-- 1N4007 DİYOT -->
  <div id="parca_diyot" style="display:none">
    <div style="max-width:580px">
      <div style="font-size:13px;font-weight:800;color:#D97706;margin-bottom:10px">⚡ 1N4007 Diyot — Ters EMF Koruması</div>
      <div style="background:#FFFBEB;border-radius:10px;padding:16px;border:2px solid #F59E0B">

        <div style="background:#FEF3C7;border-radius:8px;padding:12px;margin-bottom:14px">
          <div style="font-weight:800;font-size:13px;color:#78350F;margin-bottom:4px">Neden gerekli?</div>
          <div style="font-size:12px;color:#92400E">Solenoid bobini bir indüktans kaynağıdır. Güç kesildiğinde yüksek ters gerilim (100V+) üretir. Bu gerilim röleyi ve ESP32&#39;yi kalıcı olarak hasar verir. 1N4007 bu gerilimi kısa devre ederek söner.</div>
        </div>

        <div style="font-size:11px;font-weight:700;color:#92400E;margin-bottom:12px;text-transform:uppercase">Bağlantı yöntemi — Her solenoid için ayrı</div>

        <?php foreach ([
          ['Katot (çizgi tarafı)', '—', 'Solenoid (+) ucuna — röle NO çıkışı','#DC2626','Diyotun bant/çizgi tarafı'],
          ['Anot (düz taraf)',     '+', 'Solenoid (−) ucuna — GND hattına','#374151','Diyotun düz/gri tarafı'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding:10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[3] ?>">
          <code style="background:<?= $p[3] ?>;color:#fff;padding:3px 10px;border-radius:4px;font-weight:800;font-size:12px;white-space:nowrap"><?= $p[1] ?></code>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[0] ?></div>
            <div style="font-size:11px;color:var(--m2)">→ <?= $p[2] ?></div>
            <div style="font-size:11px;color:#D97706"><?= $p[4] ?></div>
          </div>
        </div>
        <?php endforeach; ?>

        <!-- SVG Diyot şeması -->
        <div style="text-align:center;margin-top:14px">
          <svg width="340" height="100" viewBox="0 0 340 100">
            <!-- Sol hat - 12V -->
            <line x1="20" y1="50" x2="80" y2="50" stroke="#DC2626" stroke-width="2"/>
            <text x="14" y="45" font-size="10" fill="#DC2626" font-weight="700">12V+</text>
            <!-- Solenoid kutu -->
            <rect x="80" y="30" width="80" height="40" rx="5" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
            <text x="120" y="53" text-anchor="middle" font-size="11" font-weight="700" fill="#7F1D1D">SOLENOİD</text>
            <!-- Sağ hat - GND -->
            <line x1="160" y1="50" x2="220" y2="50" stroke="#374151" stroke-width="2"/>
            <text x="230" y="45" font-size="10" fill="#374151" font-weight="700">GND</text>
            <!-- Diyot -->
            <line x1="80" y1="20" x2="220" y2="20" stroke="#D97706" stroke-width="1.5" stroke-dasharray="3 2"/>
            <!-- Diyot sembolü -->
            <polygon points="130,12 150,20 130,28" fill="#D97706" stroke="#D97706"/>
            <line x1="150" y1="12" x2="150" y2="28" stroke="#D97706" stroke-width="2"/>
            <line x1="80" y1="20" x2="130" y2="20" stroke="#D97706" stroke-width="1.5"/>
            <line x1="150" y1="20" x2="220" y2="20" stroke="#D97706" stroke-width="1.5"/>
            <!-- Bağlantı noktaları -->
            <line x1="80" y1="20" x2="80" y2="30" stroke="#D97706" stroke-width="1.5"/>
            <line x1="220" y1="20" x2="220" y2="50" stroke="#374151" stroke-width="1.5"/>
            <!-- Etiketler -->
            <text x="165" y="15" font-size="10" fill="#D97706" font-weight="700">1N4007 (paralel, ters)</text>
            <text x="148" y="40" font-size="9" fill="#92400E">Katot=+</text>
          </svg>
        </div>
        <div style="background:#FEE2E2;border-radius:6px;padding:8px;margin-top:8px;font-size:11px;color:#7F1D1D;text-align:center">
          ‼️ Diyot yanlış yönde takılırsa solenoid çalışmaz. Çizgili taraf (+) tarafa bakmalı.
        </div>
      </div>
    </div>
  </div>

  <!-- DS3231 RTC -->
  <div id="parca_rtc" style="display:none">
    <div style="max-width:520px">
      <div style="font-size:13px;font-weight:800;color:#7C3AED;margin-bottom:10px">🕐 DS3231 RTC Modülü (ZS-042) — Alt: 6 Pin, Üst: 4 Pin</div>
      <div style="background:#F5F3FF;border-radius:10px;padding:16px;border:1px solid #DDD6FE">
        <div style="font-size:11px;font-weight:700;color:#5B21B6;margin-bottom:12px;text-transform:uppercase">Modül Pinleri</div>
        <?php foreach ([
          ['32K', '1', 'Gri',     'Bağlanmaz (32kHz çıkış, opsiyonel)','#6B7280','Kullanılmıyor'],
          ['SQW', '2', 'Gri',     'Bağlanmaz (kare dalga çıkış)','#6B7280',        'Kullanılmıyor'],
          ['SCL', '3', 'Sarı',    'ESP32 GPIO 22','#D97706',                        'I2C saat — OLED ile aynı hat'],
          ['SDA', '4', 'Mavi',    'ESP32 GPIO 21','#2563EB',                        'I2C veri — OLED ile aynı hat'],
          ['VCC', '5', 'Kırmızı', 'ESP32 3.3V veya 5V','#DC2626',                  'Güç — CR2032 pil ile beraber'],
          ['GND', '6', 'Siyah',   'ESP32 GND','#374151',                            'Toprak'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:8px 10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[4] ?>">
          <div style="text-align:center;min-width:36px">
            <code style="background:<?= $p[4] ?>;color:#fff;padding:2px 6px;border-radius:4px;font-weight:800;font-size:12px;display:block"><?= $p[0] ?></code>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?>. pin</span>
          </div>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[2] ?> kablo → <?= $p[3] ?></div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[5] ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <div style="background:#EDE9FE;border-radius:6px;padding:10px;font-size:11px;color:#5B21B6;margin-top:6px">
          <strong>I2C Adresi:</strong> 0x68 — OLED (0x3C) ile aynı bus'ta, adres çakışmaz.<br>
          <strong>Alt taraf 6 pin (bağlantı için):</strong> SBX — 32K — SQW — SCL — SDA — VCC — GND<br>
          <strong>Üst taraf 4 pin:</strong> SCL — SDA — VCC — GND (aynı I2C bağlantısı, alternatif)<br>
          <strong>Pil:</strong> CR2032 takılı olmalı — güç kesildiğinde saati tutar.<br>
          <strong>SBX (pin 1):</strong> Bağlama — CR2032 şarj edilemez, bu pin boşta kalmalı.<br>
          <strong>İlk kurulumda:</strong> RTC saati compile zamanına göre otomatik ayarlanır.
        </div>
      </div>
    </div>
  </div>

  <!-- HALL SENSÖRLER -->
  <div id="parca_hall" style="display:none">
    <div style="max-width:600px">
      <div style="font-size:13px;font-weight:800;color:#0F766E;margin-bottom:10px">🧲 US1881 Hall Sensörü — 3 Adet × 3 Pin</div>
      <div style="background:#F0FDFA;border-radius:10px;padding:16px;border:1px solid #99F6E4">
        <div style="font-size:11px;font-weight:700;color:#134E4A;margin-bottom:12px;text-transform:uppercase">Sensör Pinleri (Düz yüzeye bakarken: Sol→Sağ)</div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:14px">
          <?php foreach ([
            ['M1','GPIO 35','Kırmızı kablo','INPUT — dış 10kΩ pull-down','#DC2626'],
            ['M2','GPIO 32','Mavi kablo','INPUT_PULLDOWN (dahili)','#2563EB'],
            ['M3','GPIO 33','Yeşil kablo','INPUT_PULLDOWN (dahili)','#16A34A'],
          ] as $m): ?>
          <div style="background:#fff;border-radius:8px;padding:10px;border:2px solid <?= $m[4] ?>;text-align:center">
            <div style="font-size:16px;font-weight:900;color:<?= $m[4] ?>"><?= $m[0] ?></div>
            <code style="background:<?= $m[4] ?>;color:#fff;padding:1px 8px;border-radius:4px;font-size:11px;font-weight:700"><?= $m[1] ?></code>
            <div style="font-size:10px;color:var(--m2);margin-top:4px"><?= $m[2] ?></div>
            <div style="font-size:10px;color:<?= $m[4] ?>;margin-top:2px;font-weight:700"><?= $m[3] ?></div>
          </div>
          <?php endforeach; ?>
        </div>

        <?php foreach ([
          ['VCC', '1. pin', 'Sol','Kırmızı', 'ESP32 3.3V veya 5V','#DC2626', '3.5V–24V geniş besleme'],
          ['GND', '2. pin', 'Orta','Siyah',  'ESP32 GND','#374151',           'Toprak'],
          ['OUT', '3. pin', 'Sağ', 'Sarı/Mavi/Yeşil','ESP32 GPIO 35 / 32 / 33','#0F766E','LOW = mıknatıs algılandı, HIGH = yok'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:8px 10px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[5] ?>">
          <div style="text-align:center;min-width:44px">
            <code style="background:<?= $p[5] ?>;color:#fff;padding:2px 6px;border-radius:4px;font-weight:800;font-size:12px;display:block"><?= $p[0] ?></code>
            <span style="font-size:10px;color:var(--m2)"><?= $p[1] ?> (<?= $p[2] ?>)</span>
          </div>
          <div>
            <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[3] ?> kablo → <?= $p[4] ?></div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[6] ?></div>
          </div>
        </div>
        <?php endforeach; ?>

        <div style="background:#CCFBF1;border-radius:6px;padding:10px;font-size:11px;color:#134E4A;margin-top:6px">
          <strong>GPIO 35 (M1):</strong> input-only pin — dahili pull-down <strong>DESTEKLEMEZ</strong>.<br>
          GPIO 35 ile GND arasına <strong>10kΩ dış pull-down direnci</strong> bağlanmalı.<br>
          <strong>GPIO 32/33 (M2/M3):</strong> INPUT_PULLDOWN ile dahili kullanılabilir.
        </div>
      </div>
    </div>
  </div>

  <!-- ÜRÜN ALGILAMA SENSÖRÜ -->
  <div id="parca_urun_sns" style="display:none">
    <div style="max-width:560px">
      <div style="font-size:13px;font-weight:800;color:#0F766E;margin-bottom:10px">📡 SN04-N NPN Yakınlık Sensörü — 3 Kablo</div>
      <div style="background:#F0FDFA;border-radius:10px;padding:16px;border:1px solid #99F6E4">

        <!-- Kablo bilgisi fotoğraftan -->
        <div style="font-size:11px;font-weight:700;color:#134E4A;margin-bottom:6px;text-transform:uppercase">Kablo Renkleri — BN / BU / BK</div>
        <div style="font-size:11px;color:#64748B;margin-bottom:12px">Modül etiketi: BN-10~30V, BK-NPN.NO, BU-0V</div>

        <?php foreach ([
          ['BN','Kahverengi','VCC (+)','10V–30V DC güç — 12V adaptörden','#92400E','BN = Brown. ESP32 5V ile beslenemez!'],
          ['BU','Mavi',      'GND (−)','12V adaptör GND — ESP32 GND ile ortak','#2563EB','BU = Blue. Ortak toprak hattına bağla.'],
          ['BK','Siyah',     'OUT (Sinyal)','ESP32 GPIO 34','#374151','BK = Black. NPN NO: Nesne var → LOW (0V), yok → HIGH'],
        ] as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px;padding:12px;background:#fff;border-radius:8px;border-left:4px solid <?= $p[4] ?>">
          <div style="text-align:center;min-width:60px">
            <div style="background:<?= $p[4] ?>;color:#fff;border-radius:6px;padding:4px 8px;font-weight:900;font-size:13px"><?= $p[0] ?></div>
            <div style="font-size:10px;color:<?= $p[4] ?>;font-weight:700;margin-top:2px"><?= $p[1] ?></div>
          </div>
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:3px">
              <code style="background:#E2E8F0;color:#1E293B;padding:2px 8px;border-radius:4px;font-weight:800;font-size:12px"><?= $p[2] ?></code>
              <span style="font-weight:700;font-size:12px;color:var(--t)">→ <?= $p[3] ?></span>
            </div>
            <div style="font-size:11px;color:var(--m2)"><?= $p[5] ?></div>
          </div>
        </div>
        <?php endforeach; ?>

        <div style="background:#FEF9C3;border-radius:8px;padding:12px;margin-top:4px;font-size:11px;color:#78350F">
          <div style="font-weight:800;margin-bottom:6px">⚠️ Önemli Notlar</div>
          <div style="line-height:2">
            • <strong>GPIO 34 input-only</strong> — dahili pull-down DESTEKLEMEZ<br>
            • GPIO 34 ile GND arasına <strong>10kΩ dış pull-down direnci</strong> bağla<br>
            • Sinyal hattı (BK) ile 3.3V arasına <strong>10kΩ pull-up</strong> da eklenebilir<br>
            • <strong>Algılama mesafesi:</strong> 4mm — metalik nesne<br>
            • <strong>NPN NO</strong>: Nesne varken OUT = 0V (LOW), yokken = yüksek empedans (pull-down ile LOW)
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TAM BAĞLANTI DİYAGRAMI -->
  <div id="parca_topo" style="display:none">
    <p style="font-size:12px;color:var(--m2);margin-bottom:14px">
      Tüm bileşenlerin ESP32 üzerindeki bağlantı noktaları — tek bakışta tam topoloji.
    </p>

    <div style="overflow-x:auto;-webkit-overflow-scrolling:touch">
    <svg viewBox="0 0 980 720" style="width:100%;min-width:700px;display:block;font-family:sans-serif">
    <defs>
      <marker id="a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
        <path d="M1 1l6 3-6 3" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round"/>
      </marker>
    </defs>

    <!-- ══ ESP32 MERKEZ ══════════════════════════════════════════ -->
    <rect x="370" y="230" width="240" height="260" rx="12"
          fill="#1E3A5F" stroke="#3B82F6" stroke-width="2"/>
    <text x="490" y="258" text-anchor="middle" font-size="15" font-weight="900" fill="#fff">ESP32-WROOM-32</text>
    <text x="490" y="274" text-anchor="middle" font-size="10" fill="#93C5FD">38 Pin — CP2102</text>
    <line x1="380" y1="280" x2="600" y2="280" stroke="#3B82F6" stroke-width="0.5" opacity="0.5"/>

    <?php
    $esp_pins = [
      // [x, y, pin, renk, taraf]  taraf: L=sol, R=sağ
      [370,300,'GPIO 34','#EF4444','L'],
      [370,320,'GPIO 35','#DC2626','L'],
      [370,340,'GPIO 32','#F97316','L'],
      [370,360,'GPIO 33','#F59E0B','L'],
      [370,390,'GPIO 27','#A855F7','L'],
      [370,410,'GPIO 13','#8B5CF6','L'],
      [370,440,'GPIO 21','#6366F1','L'],
      [370,460,'GPIO 22','#818CF8','L'],
      [610,300,'GPIO 25','#22C55E','R'],
      [610,320,'GPIO 26','#EAB308','R'],
      [610,340,'GPIO 14','#EF4444','R'],
      [610,360,'GPIO 4', '#7C3AED','R'],
      [610,390,'GPIO 17','#0EA5E9','R'],
      [610,410,'GPIO 16','#0EA5E9','R'],
      [610,440,'3.3V',   '#DC2626','R'],
      [610,460,'5V',     '#DC2626','R'],
      [490,490,'GND',    '#374151','B'],
    ];
    foreach ($esp_pins as $p):
      [$x,$y,$lbl,$clr,$side] = $p;
      $tx = $side==='L' ? $x-6 : $x+6;
      $anc = $side==='L' ? 'end' : 'start';
      if ($side==='B') { $tx=$x; $anc='middle'; $y2=$y+10; }
    ?>
    <circle cx="<?= $x ?>" cy="<?= $y ?>" r="4" fill="<?= $clr ?>" stroke="#fff" stroke-width="1"/>
    <text x="<?= $side==='B'?$x:($side==='L'?$x-10:$x+10) ?>" y="<?= $y+4 ?>"
          text-anchor="<?= $side==='B'?'middle':($side==='L'?'end':'start') ?>"
          font-size="9" fill="<?= $clr ?>" font-weight="700"><?= $lbl ?></text>
    <?php endforeach; ?>

    <!-- ══ GÜÇ KAYNAĞI ══════════════════════════════════════════ -->
    <rect x="30" y="30" width="130" height="70" rx="8" fill="#FEF2F2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="95" y="55" text-anchor="middle" font-size="12" font-weight="800" fill="#7F1D1D">12V DC</text>
    <text x="95" y="70" text-anchor="middle" font-size="10" fill="#DC2626">Adaptör</text>
    <text x="95" y="85" text-anchor="middle" font-size="9" fill="#9CA3AF">min. 2A</text>
    <!-- 12V → dağıtım -->
    <line x1="160" y1="55" x2="200" y2="55" stroke="#DC2626" stroke-width="1.5" marker-end="url(#a)"/>
    <text x="178" y="50" text-anchor="middle" font-size="9" fill="#DC2626">12V+</text>

    <!-- ══ SN04-N YAKLIK SENSÖRÜ ═════════════════════════════════ -->
    <rect x="30" y="140" width="150" height="80" rx="8" fill="#F0FDFA" stroke="#0F766E" stroke-width="1.5"/>
    <text x="105" y="163" text-anchor="middle" font-size="11" font-weight="800" fill="#134E4A">SN04-N</text>
    <text x="105" y="178" text-anchor="middle" font-size="10" fill="#0F766E">NPN Yakınlık</text>
    <!-- Pin etiketleri -->
    <circle cx="50" cy="195" r="4" fill="#92400E"/><text x="58" y="198" font-size="9" fill="#92400E">BN → 12V+</text>
    <circle cx="50" cy="208" r="4" fill="#2563EB"/><text x="58" y="211" font-size="9" fill="#2563EB">BU → GND</text>
    <circle cx="50" cy="221" r="4" fill="#374151"/><text x="58" y="224" font-size="9" fill="#374151">BK → GPIO 34</text>
    <!-- BK → GPIO34 -->
    <path d="M180 218 Q260 218 260 300 L370 300" fill="none" stroke="#EF4444" stroke-width="1.5" marker-end="url(#a)"/>
    <text x="240" y="213" font-size="9" fill="#EF4444">Sinyal</text>
    <text x="240" y="223" font-size="9" fill="#9CA3AF">+10kΩ↓GND</text>

    <!-- ══ HALL SENSÖRLER ════════════════════════════════════════ -->
    <rect x="30" y="260" width="150" height="110" rx="8" fill="#F0FDFA" stroke="#0F766E" stroke-width="1.5"/>
    <text x="105" y="280" text-anchor="middle" font-size="11" font-weight="800" fill="#134E4A">US1881 Hall ×3</text>
    <!-- M1 -->
    <circle cx="46" cy="298" r="4" fill="#DC2626"/><text x="54" y="302" font-size="9" fill="#DC2626">M1 OUT → GPIO 35</text>
    <!-- M2 -->
    <circle cx="46" cy="315" r="4" fill="#2563EB"/><text x="54" y="319" font-size="9" fill="#2563EB">M2 OUT → GPIO 32</text>
    <!-- M3 -->
    <circle cx="46" cy="332" r="4" fill="#16A34A"/><text x="54" y="336" font-size="9" fill="#16A34A">M3 OUT → GPIO 33</text>
    <text x="105" y="355" text-anchor="middle" font-size="9" fill="#9CA3AF">VCC=3.3V, GND=GND</text>
    <!-- M1 → GPIO35 -->
    <path d="M180 295 Q280 295 280 320 L370 320" fill="none" stroke="#DC2626" stroke-width="1.5" marker-end="url(#a)"/>
    <!-- M2 → GPIO32 -->
    <path d="M180 312 Q295 312 295 340 L370 340" fill="none" stroke="#F97316" stroke-width="1.5" marker-end="url(#a)"/>
    <!-- M3 → GPIO33 -->
    <path d="M180 329 Q310 329 310 360 L370 360" fill="none" stroke="#F59E0B" stroke-width="1.5" marker-end="url(#a)"/>
    <text x="245" y="290" font-size="8" fill="#DC2626">+10kΩ↓</text>

    <!-- ══ RÖLE 1 ════════════════════════════════════════════════ -->
    <rect x="30" y="400" width="140" height="80" rx="8" fill="#FEF2F2" stroke="#A855F7" stroke-width="1.5"/>
    <text x="100" y="420" text-anchor="middle" font-size="11" font-weight="800" fill="#6B21A8">Röle 1</text>
    <text x="100" y="435" text-anchor="middle" font-size="9" fill="#9CA3AF">1 Kanallı</text>
    <circle cx="46" cy="450" r="4" fill="#A855F7"/><text x="54" y="454" font-size="9" fill="#A855F7">IN ← GPIO 27</text>
    <circle cx="46" cy="465" r="4" fill="#DC2626"/><text x="54" y="469" font-size="9" fill="#DC2626">COM ← 12V+</text>
    <circle cx="46" cy="478" r="4" fill="#374151"/><text x="54" y="482" font-size="9" fill="#374151">NO → Sol. 1(+)</text>
    <!-- GPIO27 → Röle1 IN -->
    <path d="M370 390 Q310 390 310 450 L170 450" fill="none" stroke="#A855F7" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- ══ RÖLE 2 ════════════════════════════════════════════════ -->
    <rect x="30" y="510" width="140" height="80" rx="8" fill="#FEF2F2" stroke="#8B5CF6" stroke-width="1.5"/>
    <text x="100" y="530" text-anchor="middle" font-size="11" font-weight="800" fill="#5B21B6">Röle 2</text>
    <text x="100" y="545" text-anchor="middle" font-size="9" fill="#9CA3AF">1 Kanallı</text>
    <circle cx="46" cy="558" r="4" fill="#8B5CF6"/><text x="54" y="562" font-size="9" fill="#8B5CF6">IN ← GPIO 13</text>
    <circle cx="46" cy="573" r="4" fill="#DC2626"/><text x="54" y="577" font-size="9" fill="#DC2626">COM ← 12V+</text>
    <circle cx="46" cy="586" r="4" fill="#374151"/><text x="54" y="590" font-size="9" fill="#374151">NO → Sol. 2(+)</text>
    <!-- GPIO13 → Röle2 IN -->
    <path d="M370 410 Q305 410 305 558 L170 558" fill="none" stroke="#8B5CF6" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- ══ SOLENOİD 1 ════════════════════════════════════════════ -->
    <rect x="800" y="380" width="150" height="70" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="875" y="403" text-anchor="middle" font-size="12" font-weight="800" fill="#7F1D1D">Solenoid 1</text>
    <text x="875" y="420" text-anchor="middle" font-size="10" fill="#DC2626">12V — 0.8A</text>
    <circle cx="810" cy="437" r="4" fill="#DC2626"/><text x="818" y="441" font-size="9" fill="#DC2626">(+) ← Röle 1 NO</text>
    <circle cx="810" cy="450" r="4" fill="#374151"/><text x="818" y="454" font-size="9" fill="#374151">(−) → GND</text>
    <!-- Röle1 NO → Solenoid1 -->
    <line x1="170" y1="478" x2="800" y2="437" stroke="#DC2626" stroke-width="1.2" stroke-dasharray="4 2" marker-end="url(#a)"/>

    <!-- ══ SOLENOİD 2 ════════════════════════════════════════════ -->
    <rect x="800" y="490" width="150" height="70" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="875" y="513" text-anchor="middle" font-size="12" font-weight="800" fill="#7F1D1D">Solenoid 2</text>
    <text x="875" y="530" text-anchor="middle" font-size="10" fill="#DC2626">12V — 0.8A</text>
    <circle cx="810" cy="547" r="4" fill="#DC2626"/><text x="818" y="551" font-size="9" fill="#DC2626">(+) ← Röle 2 NO</text>
    <circle cx="810" cy="560" r="4" fill="#374151"/><text x="818" y="564" font-size="9" fill="#374151">(−) → GND</text>
    <!-- Röle2 NO → Solenoid2 -->
    <line x1="170" y1="586" x2="800" y2="547" stroke="#DC2626" stroke-width="1.2" stroke-dasharray="4 2" marker-end="url(#a)"/>

    <!-- 1N4007 diyot notu -->
    <rect x="800" y="590" width="150" height="36" rx="6" fill="#FEF9C3" stroke="#D97706" stroke-width="1"/>
    <text x="875" y="606" text-anchor="middle" font-size="10" font-weight="700" fill="#78350F">1N4007 Diyot</text>
    <text x="875" y="620" text-anchor="middle" font-size="9" fill="#D97706">Her solenoid paralel</text>

    <!-- ══ TRAFIK IŞIĞI ═══════════════════════════════════════════ -->
    <rect x="740" y="230" width="140" height="100" rx="8" fill="#FFFBEB" stroke="#D97706" stroke-width="1.5"/>
    <text x="810" y="252" text-anchor="middle" font-size="11" font-weight="800" fill="#92400E">Trafik Işığı</text>
    <circle cx="756" cy="268" r="4" fill="#22C55E"/><text x="764" y="272" font-size="9" fill="#22C55E">G ← GPIO 25</text>
    <circle cx="756" cy="283" r="4" fill="#EAB308"/><text x="764" y="287" font-size="9" fill="#EAB308">Y ← GPIO 26</text>
    <circle cx="756" cy="298" r="4" fill="#EF4444"/><text x="764" y="302" font-size="9" fill="#EF4444">R ← GPIO 14</text>
    <circle cx="756" cy="313" r="4" fill="#374151"/><text x="764" y="317" font-size="9" fill="#374151">GND → GND</text>
    <!-- GPIO25 → Yeşil -->
    <line x1="610" y1="300" x2="740" y2="268" stroke="#22C55E" stroke-width="1.5" marker-end="url(#a)"/>
    <!-- GPIO26 → Sarı -->
    <line x1="610" y1="320" x2="740" y2="283" stroke="#EAB308" stroke-width="1.5" marker-end="url(#a)"/>
    <!-- GPIO14 → Kırmızı -->
    <line x1="610" y1="340" x2="740" y2="298" stroke="#EF4444" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- ══ BUZZER ═════════════════════════════════════════════════ -->
    <rect x="740" y="140" width="130" height="70" rx="8" fill="#F5F3FF" stroke="#7C3AED" stroke-width="1.5"/>
    <text x="805" y="162" text-anchor="middle" font-size="11" font-weight="800" fill="#5B21B6">Buzzer</text>
    <circle cx="756" cy="178" r="4" fill="#7C3AED"/><text x="764" y="182" font-size="9" fill="#7C3AED">I/O ← GPIO 4</text>
    <circle cx="756" cy="193" r="4" fill="#DC2626"/><text x="764" y="197" font-size="9" fill="#DC2626">VCC ← 3.3V</text>
    <circle cx="756" cy="205" r="4" fill="#374151"/><text x="764" y="209" font-size="9" fill="#374151">GND → GND</text>
    <!-- GPIO4 → Buzzer -->
    <line x1="610" y1="360" x2="740" y2="178" stroke="#7C3AED" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- ══ OLED ════════════════════════════════════════════════════ -->
    <rect x="740" y="30" width="130" height="90" rx="8" fill="#EDE9FE" stroke="#7C3AED" stroke-width="1.5"/>
    <text x="805" y="52" text-anchor="middle" font-size="11" font-weight="800" fill="#5B21B6">OLED SSD1306</text>
    <text x="805" y="65" text-anchor="middle" font-size="9" fill="#9CA3AF">I2C — 0x3C</text>
    <circle cx="756" cy="80" r="4" fill="#6366F1"/><text x="764" y="84" font-size="9" fill="#6366F1">SDA ← GPIO 21</text>
    <circle cx="756" cy="95" r="4" fill="#818CF8"/><text x="764" y="99" font-size="9" fill="#818CF8">SCL ← GPIO 22</text>
    <circle cx="756" cy="108" r="4" fill="#DC2626"/><text x="764" y="112" font-size="9" fill="#DC2626">VCC ← 3.3V</text>

    <!-- ══ RTC ════════════════════════════════════════════════════ -->
    <rect x="560" y="30" width="140" height="90" rx="8" fill="#EDE9FE" stroke="#7C3AED" stroke-width="1.5"/>
    <text x="630" y="52" text-anchor="middle" font-size="11" font-weight="800" fill="#5B21B6">DS3231 RTC</text>
    <text x="630" y="65" text-anchor="middle" font-size="9" fill="#9CA3AF">I2C — 0x68</text>
    <circle cx="576" cy="80" r="4" fill="#6366F1"/><text x="584" y="84" font-size="9" fill="#6366F1">SDA ← GPIO 21</text>
    <circle cx="576" cy="95" r="4" fill="#818CF8"/><text x="584" y="99" font-size="9" fill="#818CF8">SCL ← GPIO 22</text>
    <circle cx="576" cy="108" r="4" fill="#DC2626"/><text x="584" y="112" font-size="9" fill="#DC2626">VCC ← 3.3V</text>

    <!-- I2C bus: GPIO21 SDA → OLED + RTC -->
    <path d="M490 440 L490 200 L490 120 Q490 80 560 80" fill="none" stroke="#6366F1" stroke-width="1.5" marker-end="url(#a)"/>
    <path d="M490 440 L490 80 L630 80" fill="none" stroke="#818CF8" stroke-width="1" stroke-dasharray="3 2"/>
    <!-- GPIO22 SCL -->
    <path d="M490 460 L490 460 Q490 95 560 95" fill="none" stroke="#818CF8" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- OLED → RTC I2C paylaşım notu -->
    <line x1="700" y1="80" x2="740" y2="80" stroke="#6366F1" stroke-width="1"/>
    <text x="720" y="76" text-anchor="middle" font-size="8" fill="#6366F1">bus</text>

    <!-- ══ ZEBRA YAZICI ════════════════════════════════════════════ -->
    <rect x="740" y="350" width="140" height="60" rx="8" fill="#EFF6FF" stroke="#0EA5E9" stroke-width="1.5"/>
    <text x="810" y="372" text-anchor="middle" font-size="11" font-weight="800" fill="#0369A1">Zebra Yazıcı</text>
    <circle cx="756" cy="390" r="4" fill="#0EA5E9"/><text x="764" y="394" font-size="9" fill="#0EA5E9">RX ← GPIO 17 (TX)</text>
    <circle cx="756" cy="403" r="4" fill="#0EA5E9"/><text x="764" y="407" font-size="9" fill="#0EA5E9">TX → GPIO 16 (RX)</text>
    <!-- GPIO17 → Yazıcı -->
    <line x1="610" y1="390" x2="740" y2="390" stroke="#0EA5E9" stroke-width="1.5" marker-end="url(#a)"/>

    <!-- ══ GND ORTAK HAT ═══════════════════════════════════════════ -->
    <rect x="370" y="640" width="240" height="30" rx="6" fill="#374151" stroke="#6B7280" stroke-width="1"/>
    <text x="490" y="660" text-anchor="middle" font-size="11" font-weight="800" fill="#fff">⏚ GND — Ortak Hat</text>
    <!-- ESP32 GND → Ortak hat -->
    <line x1="490" y1="490" x2="490" y2="640" stroke="#374151" stroke-width="2" marker-end="url(#a)"/>

    <!-- ══ USB BESLEME ════════════════════════════════════════════ -->
    <rect x="200" y="30" width="140" height="50" rx="8" fill="#EFF6FF" stroke="#2563EB" stroke-width="1.5"/>
    <text x="270" y="52" text-anchor="middle" font-size="11" font-weight="800" fill="#1D4ED8">USB 5V</text>
    <text x="270" y="67" text-anchor="middle" font-size="9" fill="#2563EB">ESP32 besleme</text>
    <!-- USB → ESP32 5V -->
    <line x1="270" y1="80" x2="430" y2="230" stroke="#2563EB" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#a)"/>

    <!-- Röle VCC → ESP32 5V -->
    <text x="200" y="390" font-size="9" fill="#2563EB">VCC ← ESP32 5V</text>
    <text x="200" y="510" font-size="9" fill="#2563EB">VCC ← ESP32 5V</text>

    <!-- ══ LEGEND ══════════════════════════════════════════════════ -->
    <rect x="30" y="640" width="320" height="70" rx="6" fill="var(--kenar-a,#F8FAFC)" stroke="var(--kenar,#E2E8F0)" stroke-width="1"/>
    <text x="42" y="658" font-size="10" font-weight="800" fill="var(--t,#1E293B)">AÇIKLAMA</text>
    <line x1="42" y1="668" x2="90" y2="668" stroke="#374151" stroke-width="1.5"/><text x="95" y="672" font-size="9" fill="#374151">Güç hattı</text>
    <line x1="42" y1="682" x2="90" y2="682" stroke="#6366F1" stroke-width="1.5"/><text x="95" y="686" font-size="9" fill="#6366F1">I2C (SDA/SCL)</text>
    <line x1="160" y1="668" x2="208" y2="668" stroke="#0EA5E9" stroke-width="1.5"/><text x="213" y="672" font-size="9" fill="#0EA5E9">UART (TX/RX)</text>
    <line x1="160" y1="682" x2="208" y2="682" stroke="#DC2626" stroke-width="1.5" stroke-dasharray="4 2"/><text x="213" y="686" font-size="9" fill="#DC2626">12V yük devresi</text>
    <line x1="240" y1="668" x2="288" y2="668" stroke="#A855F7" stroke-width="1.5"/><text x="293" y="672" font-size="9" fill="#A855F7">Dijital çıkış</text>
    <line x1="240" y1="682" x2="288" y2="682" stroke="#EF4444" stroke-width="1.5"/><text x="293" y="686" font-size="9" fill="#EF4444">Dijital giriş</text>

    </svg>
    </div><!-- /overflow -->
  </div>

</div><!-- /kart -->
</div><!-- /sema_parca -->

<!-- ── GÜÇ DEVRESİ ─────────────────────────────────────────── -->
<div id="sema_guc" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:12px;color:var(--t)">⚡ Güç Devresi ve Topraklama</h3>

  <!-- Alt sekmeler -->
  <div style="display:flex;gap:3px;flex-wrap:wrap;border-bottom:2px solid var(--kenar);margin-bottom:16px">
    <button onclick="gucTab('blok')" id="gtab_blok"
            style="padding:6px 14px;border:none;background:#1E3A5F;color:#fff;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px">
      📊 Blok Diyagram
    </button>
    <button onclick="gucTab('baglanti')" id="gtab_baglanti"
            style="padding:6px 14px;border:none;background:var(--kenar-a);color:var(--m);border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px">
      🔌 Bağlantı Adımları
    </button>
    <button onclick="gucTab('gnd')" id="gtab_gnd"
            style="padding:6px 14px;border:none;background:var(--kenar-a);color:var(--m);border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px">
      ⏚ Topraklama
    </button>
  </div>

  <!-- Blok Diyagram -->
  <div id="gtab_blok_icerik">
  <div style="overflow-x:auto">
  <svg width="100%" viewBox="0 0 680 520" style="max-width:680px;display:block;margin:0 auto">
    <defs>
      <marker id="arr2" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
        <path d="M2 1L8 5L2 9" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </marker>
    </defs>
    <rect x="20" y="40" width="130" height="60" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="85" y="63" text-anchor="middle" font-size="13" font-weight="700" fill="#7F1D1D">12V DC</text>
    <text x="85" y="82" text-anchor="middle" font-size="11" fill="#DC2626">Güç Adaptörü</text>
    <rect x="200" y="40" width="130" height="60" rx="8" fill="#FEF9C3" stroke="#D97706" stroke-width="1.5"/>
    <text x="265" y="63" text-anchor="middle" font-size="13" font-weight="700" fill="#78350F">12V Dağıtım</text>
    <text x="265" y="82" text-anchor="middle" font-size="11" fill="#D97706">Solenoid + Sensör</text>
    <line x1="150" y1="70" x2="200" y2="70" stroke="#DC2626" stroke-width="2" marker-end="url(#arr2)"/>
    <text x="172" y="65" text-anchor="middle" font-size="10" fill="#DC2626">12V</text>
    <rect x="200" y="140" width="130" height="60" rx="8" fill="#EFF6FF" stroke="#2563EB" stroke-width="1.5"/>
    <text x="265" y="163" text-anchor="middle" font-size="13" font-weight="700" fill="#1D4ED8">ESP32</text>
    <text x="265" y="179" text-anchor="middle" font-size="11" fill="#2563EB">USB 5V besleme</text>
    <text x="265" y="193" text-anchor="middle" font-size="10" fill="#2563EB">CP2102 dahili reg.</text>
    <line x1="265" y1="100" x2="265" y2="140" stroke="#D97706" stroke-width="1.5" marker-end="url(#arr2)"/>
    <text x="280" y="122" font-size="10" fill="#D97706">5V (USB)</text>
    <rect x="380" y="40" width="140" height="60" rx="8" fill="#FEF2F2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="450" y="58" text-anchor="middle" font-size="13" font-weight="700" fill="#7F1D1D">Röle Modülü</text>
    <text x="450" y="74" text-anchor="middle" font-size="11" fill="#DC2626">2 kanallı — 5V coil</text>
    <text x="450" y="88" text-anchor="middle" font-size="10" fill="#DC2626">IN1=pin27 IN2=pin13</text>
    <line x1="330" y1="70" x2="380" y2="70" stroke="#D97706" stroke-width="1.5" marker-end="url(#arr2)"/>
    <text x="352" y="65" font-size="10" fill="#D97706">5V VCC</text>
    <line x1="330" y1="165" x2="450" y2="165" stroke="#2563EB" stroke-width="1" stroke-dasharray="3 2" marker-end="url(#arr2)"/>
    <text x="390" y="158" font-size="10" fill="#2563EB">GPIO 27,13</text>
    <rect x="540" y="20" width="130" height="52" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="605" y="40" text-anchor="middle" font-size="13" font-weight="700" fill="#7F1D1D">Solenoid 1</text>
    <text x="605" y="57" text-anchor="middle" font-size="11" fill="#DC2626">12V 0.8A</text>
    <rect x="540" y="88" width="130" height="52" rx="8" fill="#FEE2E2" stroke="#DC2626" stroke-width="1.5"/>
    <text x="605" y="108" text-anchor="middle" font-size="13" font-weight="700" fill="#7F1D1D">Solenoid 2</text>
    <text x="605" y="125" text-anchor="middle" font-size="11" fill="#DC2626">12V 0.8A</text>
    <line x1="520" y1="50" x2="540" y2="50" stroke="#DC2626" stroke-width="1.5" marker-end="url(#arr2)"/>
    <line x1="520" y1="114" x2="540" y2="114" stroke="#DC2626" stroke-width="1.5" marker-end="url(#arr2)"/>
    <rect x="540" y="155" width="130" height="44" rx="8" fill="#FEF9C3" stroke="#D97706" stroke-width="2"/>
    <text x="605" y="171" text-anchor="middle" font-size="12" font-weight="700" fill="#78350F">1N4007 Diyot</text>
    <text x="605" y="186" text-anchor="middle" font-size="10" fill="#D97706">Her solenoid paralel</text>
    <line x1="540" y1="46" x2="540" y2="155" stroke="#D97706" stroke-width="1" stroke-dasharray="3 2"/>
    <line x1="540" y1="112" x2="540" y2="155" stroke="#D97706" stroke-width="1" stroke-dasharray="3 2"/>
    <line x1="540" y1="155" x2="540" y2="177" stroke="#D97706" stroke-width="1.5" marker-end="url(#arr2)"/>
    <rect x="20" y="260" width="640" height="220" rx="12" fill="none" stroke="var(--kenar)" stroke-width="1"/>
    <text x="36" y="284" font-size="13" font-weight="700" fill="var(--t)">Topraklama (GND) Bağlantıları</text>
    <?php
    $gnds = [
      [40,310,160,44,'#F1F5F9','#475569','ESP32 GND','USB/regülatör GND'],
      [220,310,160,44,'#F1F5F9','#475569','Röle GND','Aynı GND bus'],
      [400,310,160,44,'#F1F5F9','#475569','SN04-N GND','Sensör GND'],
      [40,370,160,44,'#F1F5F9','#475569','US1881 x3 GND','Tüm Hall GND'],
      [220,370,160,44,'#F1F5F9','#475569','OLED GND','I2C modül GND'],
      [400,370,160,44,'#F1F5F9','#475569','RTC GND','DS3231 GND'],
      [580,310,80,44,'#D1FAE5','#065F46','GND BUS','Ortak hat'],
    ];
    foreach ($gnds as $g):
      [$x,$y,$w,$h,$bg,$tc,$t1,$t2]=$g; ?>
    <rect x="<?=$x?>" y="<?=$y?>" width="<?=$w?>" height="<?=$h?>" rx="6" fill="<?=$bg?>" stroke="#94A3B8" stroke-width="0.5"/>
    <text x="<?=$x+$w/2?>" y="<?=$y+15?>" text-anchor="middle" font-size="12" font-weight="700" fill="<?=$tc?>"><?=$t1?></text>
    <text x="<?=$x+$w/2?>" y="<?=$y+30?>" text-anchor="middle" font-size="10" fill="#64748B"><?=$t2?></text>
    <?php endforeach; ?>
    <line x1="200" y1="332" x2="580" y2="332" stroke="#64748B" stroke-width="1.5" stroke-dasharray="4 2"/>
    <line x1="380" y1="332" x2="380" y2="392" stroke="#64748B" stroke-width="1"/>
    <line x1="200" y1="392" x2="580" y2="392" stroke="#64748B" stroke-width="1.5" stroke-dasharray="4 2"/>
    <line x1="580" y1="332" x2="580" y2="392" stroke="#64748B" stroke-width="1"/>
    <line x1="620" y1="354" x2="580" y2="354" stroke="#065F46" stroke-width="2" marker-end="url(#arr2)"/>
    <text x="340" y="440" text-anchor="middle" font-size="11" fill="#64748B">TÜM GND'LER ORTAK BİR BUS'A BAĞLANMALI</text>
    <text x="340" y="456" text-anchor="middle" font-size="11" fill="#DC2626">Solenoid GND, ESP32 GND'den AYRI — yüksek akım paraziti önlemek için</text>
    <text x="340" y="472" text-anchor="middle" font-size="11" fill="#D97706">12V GND ve 5V GND ortak noktada buluşmalı (single-point grounding)</text>
  </svg>
  </div>
  </div><!-- /gtab_blok_icerik -->

  <!-- Bağlantı Adımları -->
  <div id="gtab_baglanti_icerik" style="display:none">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px">

      <?php foreach ([
        ['1','12V Adaptörü Hazırla','#0F766E','#D1FAE5',
         '12V DC min. 2A adaptör.<br>Solenoid ×2 ≈ 1.6A + SN04-N 200mA.<br>Pozitif (+) ve negatif (−) uçları belirle.'],
        ['2','GND Ortak Hat Kur','#374151','#F1F5F9',
         'Tüm GND&#39;leri TEK noktada birleştir:<br>• 12V adaptör (−)<br>• ESP32 GND<br>• Röle 1 ve Röle 2 GND<br>• SN04-N mavi kablo (BU)'],
        ['3','12V Dağıt','#DC2626','#FEF2F2',
         '12V(+) → Aynı hattan:<br>• SN04-N kahverengi (BN) → VCC<br>• Röle 1 COM ucu<br>• Röle 2 COM ucu'],
        ['4','ESP32 Güç','#2563EB','#EFF6FF',
         'ESP32&#39;yi USB 5V ile besle.<br>ESP32&#39;nin 5V pini → Röle 1 VCC + Röle 2 VCC<br>ESP32 GND → Ortak GND hattına'],
        ['5','Röle → Solenoid','#D97706','#FFFBEB',
         '<strong>Röle 1:</strong><br>NO → Solenoid 1 (+), Solenoid 1 (−) → GND<br>1N4007 diyot paralel, katot=(+) tarafa<br><br><strong>Röle 2:</strong><br>Aynı şema, Solenoid 2 için'],
        ['6','Kontrol Sinyalleri','#7C3AED','#F5F3FF',
         'GPIO 27 → Röle 1 IN<br>GPIO 13 → Röle 2 IN<br>GPIO 34 → SN04-N BK + 10kΩ pull-down<br>GPIO 35 → Hall M1 + 10kΩ pull-down<br>GPIO 32,33 → Hall M2,M3 (dahili pull-down)'],
      ] as $adim): ?>
      <div style="background:<?= $adim[3] ?>;border-radius:10px;padding:14px;border-left:4px solid <?= $adim[2] ?>">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:28px;height:28px;border-radius:50%;background:<?= $adim[2] ?>;color:#fff;
                      display:flex;align-items:center;justify-content:center;font-weight:900;font-size:14px;flex-shrink:0"><?= $adim[0] ?></div>
          <div style="font-weight:800;font-size:13px;color:<?= $adim[2] ?>"><?= $adim[1] ?></div>
        </div>
        <div style="font-size:11px;color:#374151;line-height:1.9"><?= $adim[4] ?></div>
      </div>
      <?php endforeach; ?>

    </div>
    <div style="margin-top:16px;background:#FEF9C3;border-radius:10px;padding:14px;border:1px solid #FDE68A">
      <div style="font-weight:800;color:#78350F;margin-bottom:8px">⚡ Devreye Alma Sırası</div>
      <div style="font-size:12px;color:#92400E;line-height:2">
        1. Tüm kabloları bağla — henüz güç verme<br>
        2. Multimetre ile GND-VCC arası ölç — kısa devre yok mu?<br>
        3. 12V tak — solenoidler tetiklenmemeli (ESP32 yok)<br>
        4. ESP32&#39;yi USB'ye bağla — OLED'de "Sistem başlıyor..." görünmeli<br>
        5. .ino yükle, WiFi bağlandıktan sonra test et
      </div>
    </div>
  </div>

  <!-- Topraklama -->
  <div id="gtab_gnd_icerik" style="display:none">
    <div style="background:#F1F5F9;border-radius:10px;padding:16px;border:2px solid #94A3B8;margin-bottom:14px">
      <div style="font-weight:800;color:#1E293B;font-size:13px;margin-bottom:6px">⏚ Single-Point Grounding</div>
      <div style="font-size:12px;color:#475569;line-height:1.9">Tüm GND hatları tek fiziksel noktada buluşmalı — gürültü ve paraziti önler.</div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
      <?php foreach ([
        ['ESP32 GND','USB negatif hattı','#2563EB'],
        ['Röle 1 GND','Kontrol devresi','#D97706'],
        ['Röle 2 GND','Kontrol devresi','#D97706'],
        ['SN04-N (BU)','Mavi kablo','#374151'],
        ['Solenoid 1 (−)','12V devre','#DC2626'],
        ['Solenoid 2 (−)','12V devre','#DC2626'],
        ['Hall M1/M2/M3','Sensör GND','#0F766E'],
        ['OLED + RTC','I2C modüller','#7C3AED'],
        ['12V Adaptör (−)','Ana GND','#059669'],
      ] as $g): ?>
      <div style="background:#fff;border-radius:8px;padding:10px;border-left:4px solid <?= $g[2] ?>">
        <div style="font-weight:800;font-size:12px;color:<?= $g[2] ?>"><?= $g[0] ?></div>
        <div style="font-size:11px;color:var(--m2)"><?= $g[1] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="margin-top:12px;background:#FEF2F2;border-radius:8px;padding:10px;font-size:11px;color:#7F1D1D">
      ⚠️ Solenoid anahtarlama akımı (~800mA) ESP32 GND hattından geçmemeli — ayrı yol kullan, sadece referans noktasında birleştir.
    </div>
  </div>

</div><!-- /kart -->
</div><!-- /sema_guc -->

<!-- ── MALZEME LİSTESİ ────────────────────────────────────── -->
<div id="sema_bom" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">Malzeme Listesi (BOM) — Tekmelik Test Cihazı</h3>
  <div style="overflow-x:auto">
  <table class="tablo" style="width:100%">
    <thead>
      <tr style="background:#1E3A5F">
        <th style="color:#fff;font-weight:700">#</th>
        <th style="color:#fff;font-weight:700">Ürün</th>
        <th style="color:#fff;font-weight:700">Adet</th>
        <th style="color:#fff;font-weight:700">Pin / Bağlantı</th>
        <th style="color:#fff;font-weight:700">Notlar</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $bom = [
        ['1','ESP32-WROOM-32 (38 pin, CP2102)','1','Tüm pinler','Merkez mikrodenetleyici'],
        ['2','SN04-N NPN Yakınlık Sensörü 4mm','1','GPIO 34 — dış 10kΩ pull-down','12V besleme, NPN LOW=aktif'],
        ['3','US1881 Hall Sensörü','3','GPIO 35/32/33','35 → dış pull-down, 32/33 dahili'],
        ['4','12V Solenoid Valf','2','Röle NO üzerinden 12V','1N4007 diyot zorunlu'],
        ['5','DS3231 RTC Modülü','1','SDA=21, SCL=22','CR2032 pil + I2C 0x68'],
        ['6','0.96" OLED SSD1306','1','SDA=21, SCL=22','I2C 0x3C'],
        ['7','LED Trafik Işığı 5V','1','GPIO 25/26/14','Yeşil/Sarı/Kırmızı'],
        ['8','Aktif Buzzer Modülü','1','GPIO 4','HIGH=ses'],
        ['9','2 Kanallı Röle 5V','1','GPIO 27/13','LOW aktif, 12V solenoid sürücüsü'],
        ['10','1N4007 Diyot','2','Solenoid uçlarına paralel ters','Ters EMF koruması — ZORUNLU'],
        ['11','10kΩ Direnç','2','GPIO34-GND / GPIO35-GND','Pull-down — input-only pinler için'],
        ['12','Zebra Etiket Yazıcı','1','GPIO 17=TX, 16=RX','9600 baud ZPL'],
        ['13','12V DC Adaptör (min 2A)','1','Ana güç','Solenoid + SN04-N besler'],
        ['14','CR2032 Pil','1','RTC modülü pil yuvası','Güç kesintisinde saat tutar'],
      ];
      foreach ($bom as $i => $r): ?>
      <tr style="<?= $i%2===0?'':'background:var(--kenar-a)' ?>">
        <td style="font-weight:700;color:var(--m2)"><?= $r[0] ?></td>
        <td style="font-weight:600"><?= $r[1] ?></td>
        <td style="text-align:center;font-weight:800"><?= $r[2] ?></td>
        <td style="font-family:monospace;font-size:12px;color:#1D4ED8"><?= $r[3] ?></td>
        <td style="font-size:12px;color:var(--m2)"><?= $r[4] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
</div>

</div><!-- /s-body -->

<script>
var tumSemaTabs = ['akis','pin','parca','guc','bom'];
function tabGoster(id) {
    tumSemaTabs.forEach(function(s){
        var el  = document.getElementById('sema_' + s);
        var btn = document.getElementById('tab_' + s);
        if (el)  el.style.display  = s===id ? 'block' : 'none';
        if (btn) {
            btn.style.background = s===id ? 'var(--t)' : 'var(--kenar-a)';
            btn.style.color      = s===id ? '#fff'     : 'var(--m)';
        }
    });
}

var tumParcaTabs = ['solenoid','oled','buzzer','trafik','diyot','rtc','hall','urun_sns','topo'];
function parcaGoster(id) {
    tumParcaTabs.forEach(function(s){
        var el  = document.getElementById('parca_' + s);
        var btn = document.getElementById('ptab_' + s);
        if (el)  el.style.display  = s===id ? 'block' : 'none';
        if (btn) {
            btn.style.background = s===id ? '#1E3A5F' : 'var(--kenar-a)';
            btn.style.color      = s===id ? '#fff'    : 'var(--m)';
        }
    });
}

var tumGucTabs = ['blok','baglanti','gnd'];
function gucTab(id) {
    tumGucTabs.forEach(function(s){
        var el  = document.getElementById('gtab_' + s + '_icerik');
        var btn = document.getElementById('gtab_' + s);
        if (el)  el.style.display  = s===id ? 'block' : 'none';
        if (btn) {
            btn.style.background = s===id ? '#1E3A5F' : 'var(--kenar-a)';
            btn.style.color      = s===id ? '#fff'    : 'var(--m)';
        }
    });
}
</script>
<style>
@media(max-width:600px){.pin-grid{grid-template-columns:1fr!important}}
</style>
