<?php
/**
 * JETONE.PRO — Hortum Test Bağlantı Ayarları
 * panel.php: 'kalite-hortum-ayarlar' => 'bolumler/kalite/hortum_ayarlar.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Server durumu
$server_calisiyor = false;
try {
    $s = @fsockopen('127.0.0.1', 5050, $e, $es, 0.5);
    if ($s) { fclose($s); $server_calisiyor = true; }
} catch(Throwable $e) {}

// Log dosyası son satırları
$log_dosya = dirname(dirname(__DIR__)) . '/uploads/moxa_server.log';
$log_satirlar = [];
if (file_exists($log_dosya)) {
    $satirlar = file($log_dosya, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $log_satirlar = array_slice($satirlar, -30); // son 30 satır
}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚙️ Hortum Test — Bağlantı Ayarları</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" style="color:var(--t)">Hortum Test</a> / <b>Ayarlar</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" class="btn btn-b btn-sm">← Test Sayfası</a>
  </div>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="ayar-grid">

<!-- SOL: Node.js Server Yönetimi -->
<div>

  <!-- Server Durumu -->
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div style="font-weight:800;font-size:14px;margin-bottom:14px;color:var(--t)">🖥️ Node.js Server</div>

    <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;padding:12px;border-radius:10px;
                background:<?= $server_calisiyor ? '#D1FAE5' : '#FEF2F2' ?>;">
      <div style="width:14px;height:14px;border-radius:50%;background:<?= $server_calisiyor ? '#22C55E' : '#EF4444' ?>;flex-shrink:0
                  <?= $server_calisiyor ? ';box-shadow:0 0 8px #22C55E88' : '' ?>"></div>
      <div>
        <div style="font-weight:800;font-size:13px;color:<?= $server_calisiyor ? '#065F46' : '#991B1B' ?>">
          <?= $server_calisiyor ? '● Çalışıyor' : '● Durdu' ?>
        </div>
        <div id="serverDurum" style="font-size:11px;color:var(--m2)">
          <?= $server_calisiyor ? 'ws://localhost:5050' : 'Başlatmak için aşağıdaki butona tıklayın' ?>
        </div>
      </div>
    </div>

    <div style="display:flex;gap:8px;margin-bottom:14px">
      <button id="btnBaslat" onclick="serverBaslat()"
              style="flex:1;padding:10px;border:none;border-radius:var(--r);
                     background:<?= $server_calisiyor ? '#E2E8F0' : '#22C55E' ?>;
                     color:<?= $server_calisiyor ? '#94A3B8' : '#fff' ?>;
                     font-weight:700;font-size:13px;cursor:pointer"
              <?= $server_calisiyor ? 'disabled' : '' ?>>
        ▶ Başlat
      </button>
      <button id="btnDurdur" onclick="serverDurdur()"
              style="flex:1;padding:10px;border:none;border-radius:var(--r);
                     background:<?= $server_calisiyor ? '#EF4444' : '#E2E8F0' ?>;
                     color:<?= $server_calisiyor ? '#fff' : '#94A3B8' ?>;
                     font-weight:700;font-size:13px;cursor:pointer"
              <?= $server_calisiyor ? '' : 'disabled' ?>>
        ■ Durdur
      </button>
      <button onclick="location.reload()" class="btn btn-b" style="padding:10px 14px">
        ↺
      </button>
    </div>

    <div style="background:var(--kenar-a);border-radius:8px;padding:10px;font-size:11px;color:var(--m2)">
      <div style="font-weight:700;margin-bottom:4px">Kurulum bilgisi</div>
      Node.js kurulu değilse: <a href="https://nodejs.org" target="_blank" style="color:var(--t)">nodejs.org</a>'dan indirin<br>
      Server konumu: <code>jetone_pro/entegrasyonlar/moxa_server.js</code><br>
      Manuel başlatma: <code>entegrasyonlar/start.bat</code>
    </div>
  </div>

  <!-- WebSocket / MOXA Bağlantısı -->
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div style="font-weight:800;font-size:14px;margin-bottom:14px;color:var(--t)">🔌 Bağlantı</div>

    <div style="display:grid;gap:10px;margin-bottom:14px">
      <div>
        <label class="form-et">Protokol</label>
        <select id="htProtocol" class="form-alan" style="font-size:12px" onchange="htProtocolChange()">
          <option value="mock">🔧 Simülasyon (Test)</option>
          <option value="ws" <?= $server_calisiyor ? 'selected' : '' ?>>🌐 WebSocket (MOXA Server)</option>
        </select>
      </div>

      <div id="htWsFields" style="display:<?= $server_calisiyor ? 'grid' : 'none' ?>;gap:10px">
        <div style="display:grid;grid-template-columns:1fr 100px;gap:8px">
          <div>
            <label class="form-et">MOXA IP <span style="color:var(--m3);font-weight:400">— MOXA E1212 cihazı</span></label>
            <input id="htMoxaIp" class="form-alan" type="text" value="192.168.127.254"
                   style="font-family:monospace" placeholder="192.168.127.254">
          </div>
          <div>
            <label class="form-et">Modbus Port</label>
            <input id="htMoxaPort" class="form-alan" type="number" value="502" style="font-family:monospace">
          </div>
        </div>
        <div>
          <label class="form-et">Node.js WS URL <span style="color:var(--m3);font-weight:400">— bu PC</span></label>
          <input id="htWsUrl" class="form-alan" type="text" value="ws://localhost:5050"
                 style="font-family:monospace" placeholder="ws://localhost:5050">
        </div>
      </div>
    </div>

    <!-- Bağlantı durumu + Bağlan/Kes -->
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:8px;padding:6px 12px;border-radius:20px;background:var(--kenar-a);flex:1">
        <div id="htConnDot" style="width:10px;height:10px;border-radius:50%;background:#EF4444;transition:.4s;flex-shrink:0"></div>
        <span id="htConnLabel" style="font-size:12px;font-weight:700;color:var(--m2)">WS: Bağlı değil</span>
        <div style="width:1px;height:14px;background:var(--kenar)"></div>
        <div id="moxaConnDot" style="width:10px;height:10px;border-radius:50%;background:#94A3B8;transition:.4s;flex-shrink:0"></div>
        <span id="moxaConnLabel" style="font-size:12px;font-weight:700;color:var(--m2)">MOXA: —</span>
      </div>
      <button id="htBtnConnect" onclick="baglan()" class="btn btn-t btn-sm" style="padding:6px 14px">🔗 Bağlan</button>
      <button id="htBtnDisconnect" onclick="kes()" class="btn btn-b btn-sm" style="display:none;padding:6px 14px">✕ Kes</button>
    </div>

    <div id="htConnNote" style="margin-top:10px;font-size:11px;color:var(--m2);padding:8px 12px;
         background:var(--kenar-a);border-radius:8px;display:none"></div>
  </div>

</div>

<!-- SAĞ: Server Logu -->
<div>
  <div class="kart" style="padding:16px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
      <div style="font-weight:800;font-size:14px;color:var(--t)">📋 Server Logu</div>
      <button onclick="logYenile()" class="btn btn-b btn-sm" style="font-size:11px">↺ Yenile</button>
    </div>
    <div id="logKutu" style="background:#0F172A;border-radius:8px;padding:10px;height:420px;
         overflow-y:auto;font-family:monospace;font-size:11px;color:#94A3B8">
      <?php if (empty($log_satirlar)): ?>
      <div style="color:#475569">// Log dosyası boş veya bulunamadı</div>
      <?php else: ?>
      <?php foreach ($log_satirlar as $satir): ?>
      <div style="color:<?=
        str_contains($satir,'HATA')||str_contains($satir,'error')||str_contains($satir,'Error') ? '#F87171' :
        (str_contains($satir,'OK')||str_contains($satir,'Bağlandı')||str_contains($satir,'connected') ? '#4ADE80' :
        (str_contains($satir,'UYARI')||str_contains($satir,'warn') ? '#FBBf24' : '#94A3B8'))
      ?>"><?= htmlspecialchars($satir) ?></div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

</div><!-- /grid -->
</div><!-- /s-body -->

<style>
@media(max-width:800px){ .ayar-grid{grid-template-columns:1fr!important} }
</style>

<script>
var YONET_URL = '<?= BASE_URL ?>/bolumler/kalite/ajax/moxa_server_yonet.php';
var ws = null;

// ── Server Yönetim ────────────────────────────────────────
async function serverBaslat() {
    var btn = document.getElementById('btnBaslat');
    btn.disabled = true; btn.textContent = '⏳ Başlatılıyor...';
    try {
        var fd = new FormData(); fd.append('action','baslat');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        var d  = await r.json();
        if (d.ok) {
            logEkle('✅ ' + (d.mesaj || 'Server başlatıldı'));
            setTimeout(function(){ location.reload(); }, 1500);
        } else {
            logEkle('❌ ' + (d.hata || d.mesaj || 'Başlatılamadı'));
            btn.disabled = false; btn.textContent = '▶ Başlat';
        }
    } catch(e) {
        logEkle('❌ Hata: ' + e.message);
        btn.disabled = false; btn.textContent = '▶ Başlat';
    }
}

async function serverDurdur() {
    var btn = document.getElementById('btnDurdur');
    btn.disabled = true; btn.textContent = '⏳ Durduruluyor...';
    if (ws) { ws.close(); ws = null; }
    try {
        var fd = new FormData(); fd.append('action','durdur');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        var d  = await r.json();
        logEkle(d.ok ? ('✅ ' + (d.mesaj||'Durduruldu')) : ('❌ ' + (d.hata||'')));
        setTimeout(function(){ location.reload(); }, 1000);
    } catch(e) {
        logEkle('❌ ' + e.message);
        btn.disabled = false; btn.textContent = '■ Durdur';
    }
}

// ── WS Bağlantı ───────────────────────────────────────────
function baglan() {
    var proto = document.getElementById('htProtocol').value;
    if (proto === 'mock') {
        durum(true, 'WS: Simülasyon', '#22C55E', 'MOXA: Simülasyon', '#22C55E');
        logEkle('🔧 Simülasyon modu aktif — Hortum otomatik takılı');
        return;
    }
    var url = (document.getElementById('htWsUrl')||{value:'ws://localhost:5050'}).value.trim();
    logEkle('🔗 Bağlanıyor: ' + url);
    try {
        ws = new WebSocket(url);
        ws.onopen = function() {
            durum(true, 'WS: Bağlı', '#22C55E', 'MOXA: Bağlanıyor...', '#F59E0B');
            document.getElementById('htBtnConnect').style.display = 'none';
            document.getElementById('htBtnDisconnect').style.display = '';
            logEkle('✅ WebSocket bağlandı');
            // MOXA config gönder
            var moxaIp   = (document.getElementById('htMoxaIp')||{value:'192.168.127.254'}).value;
            var moxaPort = (document.getElementById('htMoxaPort')||{value:'502'}).value;
            ws.send(JSON.stringify({komut:'config_guncelle', moxa_host:moxaIp, moxa_port:moxaPort}));
        };
        ws.onclose = function() {
            durum(false, 'WS: Kesildi', '#EF4444', 'MOXA: —', '#94A3B8');
            document.getElementById('htBtnConnect').style.display = '';
            document.getElementById('htBtnDisconnect').style.display = 'none';
            logEkle('🔌 Bağlantı kesildi');
        };
        ws.onmessage = function(e) {
            try {
                var msg = JSON.parse(e.data);
                if (msg.tip === 'baglanti') {
                    var baglandı = msg.durum === 'baglandı';
                    document.getElementById('moxaConnDot').style.background = baglandı ? '#22C55E' : '#EF4444';
                    document.getElementById('moxaConnLabel').textContent = baglandı ? 'MOXA: Bağlı' : ('MOXA: ' + (msg.durum==='kesildi'?'Kesildi':'Hata'));
                    logEkle((baglandı?'✅':'❌') + ' MOXA: ' + msg.mesaj);
                }
                if (msg.tip === 'ilk_durum') {
                    document.getElementById('moxaConnDot').style.background = msg.connected ? '#22C55E' : '#EF4444';
                    document.getElementById('moxaConnLabel').textContent = msg.connected ? 'MOXA: Bağlı' : 'MOXA: Bağlı Değil';
                }
            } catch(ex) {}
        };
        ws.onerror = function() { logEkle('❌ WS bağlantı hatası'); };
    } catch(e) { logEkle('❌ ' + e.message); }
}

function kes() {
    if (ws) { ws.close(); ws = null; }
    durum(false, 'WS: Bağlı değil', '#EF4444', 'MOXA: —', '#94A3B8');
    document.getElementById('htBtnConnect').style.display = '';
    document.getElementById('htBtnDisconnect').style.display = 'none';
}

function durum(baglandı, wsText, wsRenk, moxaText, moxaRenk) {
    document.getElementById('htConnDot').style.background   = wsRenk;
    document.getElementById('htConnLabel').textContent      = wsText;
    document.getElementById('moxaConnDot').style.background = moxaRenk;
    document.getElementById('moxaConnLabel').textContent    = moxaText;
}

// ── Protokol değişince ────────────────────────────────────
function htProtocolChange() {
    var v = document.getElementById('htProtocol').value;
    document.getElementById('htWsFields').style.display = v==='ws' ? 'grid' : 'none';
    var note = document.getElementById('htConnNote');
    if (v === 'mock') {
        note.style.display = 'block';
        note.innerHTML = '🔧 <b>Simülasyon:</b> Gerçek cihaz gerekmez. Bağlan butonuna basın — hortum otomatik takılı gelir, direkt BAŞLAT\'a basabilirsiniz. İsterseniz test sayfasında 📦 Ürün Koy/Kaldır ile hortumu çıkarıp tekrar takabilirsiniz.';
    } else {
        note.style.display = 'block';
        note.innerHTML = '🌐 <b>WebSocket:</b> MOXA E1212 Modbus TCP. Node.js server çalışıyor olmalı.';
    }
}

// ── Log ───────────────────────────────────────────────────
function logEkle(mesaj) {
    var kutu = document.getElementById('logKutu');
    var div  = document.createElement('div');
    var saat = new Date().toLocaleTimeString('tr-TR');
    div.style.color = mesaj.startsWith('✅')||mesaj.startsWith('🔧') ? '#4ADE80' :
                      mesaj.startsWith('❌') ? '#F87171' : '#94A3B8';
    div.textContent = '[' + saat + '] ' + mesaj;
    kutu.appendChild(div);
    kutu.scrollTop = kutu.scrollHeight;
}

async function logYenile() {
    try {
        var r = await fetch('<?= BASE_URL ?>/bolumler/kalite/ajax/moxa_server_yonet.php?action=durum');
        var d = await r.json();
        logEkle('ℹ️ Server durumu: ' + (d.calisiyor ? 'Çalışıyor' : 'Durdu') + (d.pid ? ' (PID:'+d.pid+')' : ''));
    } catch(e) { logEkle('❌ ' + e.message); }
}

// Sayfa açılışında: server çalışıyorsa otomatik bağlan
window.addEventListener('DOMContentLoaded', function() {
    htProtocolChange();
    <?php if ($server_calisiyor): ?>
    setTimeout(baglan, 500);
    <?php endif; ?>
    document.getElementById('logKutu').scrollTop = 999999;
});
</script>
