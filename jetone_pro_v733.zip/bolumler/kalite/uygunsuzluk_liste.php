<?php
/**
 * JETONE.PRO — Uygunsuzluk Listesi
 * panel.php: 'kalite-uygunsuzluk-liste' => 'bolumler/kalite/uygunsuzluk_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Tablo oluştur (yoksa)
try { $db->exec(file_get_contents(dirname(dirname(__DIR__)) . '/uygunsuzluk.sql')); } catch (Throwable $e) {}

// Durum mesajı
$durum = $_GET['durum'] ?? '';
$durum_msg = [
    'ok'      => ['✅ İşlem başarıyla tamamlandı.',             'var(--bas-a)',  'var(--bas)'],
    'mailok'  => ['✅ Kayıt oluşturuldu ve mail gönderildi.',   'var(--bas-a)',  'var(--bas)'],
    'no'      => ['❌ İşlem sırasında hata oluştu.',            'var(--hat-a)',  'var(--hat)'],
    'silindi' => ['🗑 Kayıt başarıyla silindi.',                'var(--bas-a)',  'var(--bas)'],
];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚠️ Uygunsuzluk Listesi</h1>
    <div class="s-yol">Kalite / <b>Uygunsuzluk</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-formu" class="btn btn-t btn-sm">+ Yeni Uygunsuzluk</a>
  </div>
</div>

<div class="s-body">

<?php if ($durum && isset($durum_msg[$durum])): [$msg,$bg,$fg] = $durum_msg[$durum]; ?>
<div style="background:<?= $bg ?>;color:<?= $fg ?>;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-weight:700">
  <?= $msg ?>
</div>
<?php endif; ?>

<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <?php $sth = ['#','Takip No','Tespit Tarihi','Malzeme','Uyg. Yeri','Tedarikçi','Durum','İşlemler']; ?>
    <table id="uygunsuzlukTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php
        try {
            $st = $db->query("SELECT * FROM uygunsuzluk ORDER BY kayit_tarihi DESC");
            $i = 0;
            while ($r = $st->fetch(PDO::FETCH_ASSOC)):
                $i++;
                // Durum rozeti
                if ($r['duzeltici_faaliyet'] === 'gerekiyor' && !$r['karar']) {
                    $roz = ['#FEF9C3','#92400E','DÖF Açık'];
                } elseif ($r['karar']) {
                    $roz = ['#D1FAE5','#065F46','Tamamlandı'];
                } else {
                    $roz = ['#E0F2FE','#0369A1','Karar Bekliyor'];
                }
                $yer_map = ['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'];
        ?>
        <tr>
          <td style="color:var(--m3);font-size:11px"><?= $i ?></td>
          <td style="font-weight:800;font-family:monospace;color:var(--t)"><?= htmlspecialchars($r['takip_no']) ?></td>
          <td style="white-space:nowrap"><?= $r['tespit_tarihi'] ? date('d.m.Y', strtotime($r['tespit_tarihi'])) : '—' ?></td>
          <td style="max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?= htmlspecialchars($r['malzeme_adi']??'') ?>">
            <?= htmlspecialchars($r['malzeme_adi']??'') ?>
          </td>
          <td><?= $yer_map[$r['uygunsuzluk_yeri']??''] ?? htmlspecialchars($r['uygunsuzluk_yeri']??'') ?></td>
          <td style="max-width:140px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($r['tedarikci_firma']??'') ?></td>
          <td>
            <span style="background:<?= $roz[0] ?>;color:<?= $roz[1] ?>;padding:2px 9px;border-radius:12px;font-size:11px;font-weight:800">
              <?= $roz[2] ?>
            </span>
          </td>
          <td style="white-space:nowrap">
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-duzenle&id=<?= $r['id'] ?>"
               class="btn btn-sm" style="background:var(--bil-a);color:var(--bil);padding:3px 8px;font-size:11px;text-decoration:none">✏️</a>
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-yazdir&id=<?= $r['id'] ?>" target="_blank"
               class="btn btn-sm" style="background:var(--bas-a);color:var(--bas);padding:3px 8px;font-size:11px;text-decoration:none">🖨</a>
            <form method="POST" action="<?= BASE_URL ?>/islemler/kalite/uygunsuzluk_sil.php" style="display:inline"
                  onsubmit="return confirm('Kaydı silmek istiyor musunuz?')">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button type="submit" class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
            </form>
          </td>
        </tr>
        <?php endwhile;
        } catch (Throwable $e) { echo '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--m2)">Kayıt bulunamadı.</td></tr>'; } ?>
      </tbody>
    </table>
  </div>
</div>

</div>

<script>
$(document).ready(function(){
  var tbl = $('#uygunsuzlukTablo').DataTable({
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollX:true, scrollY:500, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',filename:'Uygunsuzluk_<?= date('Ymd') ?>'},
      {extend:'print',text:'🖨 Yazdır'}
    ],
    drawCallback:function(){ $('#uygunsuzlukTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){
      this.api().columns([1,4,5,6]).every(function(){
        var col=this, sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
        col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+(t.length>28?t.substr(0,28)+'...':t)+'</option>'); });
      });
      $('#uygunsuzlukTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); });
    }
  });
});
</script>
