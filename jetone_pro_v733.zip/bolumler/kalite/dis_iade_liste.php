<?php
/**
 * JETONE.PRO — Dış İade — Satış İade Listesi
 * Tiger'dan iade irsaliyelerini çeker, kontrol edilmemişleri gösterir
 * panel.php: 'kalite-dis-iade-liste'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? 'Anonim';

$hata_tipleri = ['ÇİZİK','FARKLI TİP','SERİGRAFİ YOK','LEKE','KIRIK','EKSİK GRUPLAMA','GRUPLAMA HATASI',
    'YERİNE SAĞLAM ÜRÜN G','CROSS CUT','PİM KIRIK','EKSİK ENJEKSİYON','SİPARİŞ FAZLASI MALZEME',
    'ÇÖKÜNTÜ','ETİKET HATALI','BOYADAN GELDİ','SPARİŞ FAZLASI MALZEME','ÇAPAK','BOYA HATASI T BOYANACAK',
    'ENJEKSİYON HATASI','MTK YOK','DALGALANMA','FONKSİYONEL HATA','SERPİNTİ','NAKLİYE HATASI',
    'EVRAK HATALI','BOYA HATASI','GAZ İZİ','ÖLÇÜSEL HATA','REVİZYON ÖNCESİ ÜRÜN','SERİGRAFİ HATASI',
    'FATURA DÜZELTME','SEHİM-PEŞLİ','KASA İÇİ EKSİK ÜRÜN','AMBALAJ UYGUNSUZLUĞU',
    'DERİN ÇAPAK ALIMI','DÜZENSİZ ÇAPAK ALIMI'];
$aksiyonlar = ['FİRE EDİLDİ','REWORK YAPILIP ÜRETİME TESLİM EDİLDİ','KARANTİNADA KARAR BEKLİYOR',
    'GRUPLU ÜRÜNLERİN FİRE EDİLMESİ','MÜŞTERİYE İADE EDİLDİ','ÜRETİME VERİLDİ',
    'MÜŞTERİYE İADE EDİLECEK','MÜŞTERİYE GÖNDERİLDİ.','KARAR BEKLEMEDE',
    'FATURA FARKI','FATURA DÜZELTME','İADE EDİLDİ'];

// Tarih filtresi
$start = $_POST['start_date'] ?? date('Y-m-d', strtotime('-1 month'));
$end   = $_POST['end_date']   ?? date('Y-m-d');

$tiger_rows = [];
$hata_msg   = '';

try {
    // Tiger'dan tüm iade irsaliyeleri (TRCODE=3: satış iade irsaliyesi)
    $sql = "SELECT
        CONVERT(VARCHAR, STL.DATE_, 104) AS irsaliye_tarihi,
        CASE WHEN IT.CODE IS NOT NULL THEN STF.FICHENO ELSE INV.FICHENO END AS irsaliye_no,
        CL.DEFINITION_ AS musteri_adi,
        CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE  ELSE SRV.CODE END AS malzeme_kodu,
        CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME  ELSE SRV.DEFINITION_ END AS malzeme_adi,
        SUM(STL.AMOUNT) AS miktar
    FROM LG_222_02_STLINE STL
    LEFT JOIN LG_222_ITEMS IT    ON IT.LOGICALREF   = STL.STOCKREF AND STL.LINETYPE=0
    LEFT JOIN LG_222_SRVCARD SRV ON STL.STOCKREF    = SRV.LOGICALREF
    LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF = STF.LOGICALREF
    LEFT JOIN LG_222_02_INVOICE INV ON STL.INVOICEREF  = INV.LOGICALREF
    LEFT JOIN LG_222_CLCARD CL   ON CL.LOGICALREF   = STF.CLIENTREF
    WHERE STF.TRCODE = 3
      AND STF.DATE_ BETWEEN CONVERT(DATETIME, :s1, 102) AND CONVERT(DATETIME, :e1, 102)
    GROUP BY STL.DATE_, IT.CODE, STF.FICHENO, INV.FICHENO, SRV.CODE, IT.NAME, SRV.DEFINITION_, CL.DEFINITION_
    UNION ALL
    SELECT
        CONVERT(VARCHAR, STL.DATE_, 104),
        CASE WHEN IT.CODE IS NOT NULL THEN STF.FICHENO ELSE INV.FICHENO END,
        CL.DEFINITION_,
        CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE  ELSE SRV.CODE END,
        CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME  ELSE SRV.DEFINITION_ END,
        SUM(STL.AMOUNT)
    FROM LG_222_01_STLINE STL
    LEFT JOIN LG_222_ITEMS IT    ON IT.LOGICALREF   = STL.STOCKREF AND STL.LINETYPE=0
    LEFT JOIN LG_222_SRVCARD SRV ON STL.STOCKREF    = SRV.LOGICALREF
    LEFT JOIN LG_222_01_STFICHE STF ON STL.STFICHEREF = STF.LOGICALREF
    LEFT JOIN LG_222_01_INVOICE INV ON STL.INVOICEREF  = INV.LOGICALREF
    LEFT JOIN LG_222_CLCARD CL   ON CL.LOGICALREF   = STF.CLIENTREF
    WHERE STF.TRCODE = 3
      AND STF.DATE_ BETWEEN CONVERT(DATETIME, :s2, 102) AND CONVERT(DATETIME, :e2, 102)
    GROUP BY STL.DATE_, IT.CODE, STF.FICHENO, INV.FICHENO, SRV.CODE, IT.NAME, SRV.DEFINITION_, CL.DEFINITION_
    ORDER BY irsaliye_tarihi DESC, irsaliye_no";

    // MSSQL için tarih formatı: yyyy.mm.dd (format 102)
    $s_fmt = date('Y.m.d', strtotime($start));
    $e_fmt = date('Y.m.d', strtotime($end));

    $st = $tigerdb_pdo->prepare($sql);
    $st->execute([':s1'=>$s_fmt,':e1'=>$e_fmt,':s2'=>$s_fmt,':e2'=>$e_fmt]);
    $tiger_rows = $st->fetchAll(PDO::FETCH_ASSOC);

    // MySQL'den hata kayıtlarını bulk çek (irsaliye+malzeme kombinasyonu)
    $hata_map = [];
    if ($tiger_rows) {
        $st2 = $db->query("SELECT irsaliye_no, malzeme_kodu, SUM(hata_miktar) AS toplam
            FROM dis_iade_kontrol_listesi
            GROUP BY irsaliye_no, malzeme_kodu");
        foreach ($st2->fetchAll(PDO::FETCH_ASSOC) as $hr) {
            $hata_map[$hr['irsaliye_no'].'__'.$hr['malzeme_kodu']] = (float)$hr['toplam'];
        }
    }
} catch (Throwable $e) {
    $hata_msg = 'Tiger bağlantı hatası: ' . htmlspecialchars($e->getMessage());
}

// Satırlara hata oranı ekle
$rows_isle = [];
foreach ($tiger_rows as $r) {
    $key        = $r['irsaliye_no'].'__'.$r['malzeme_kodu'];
    $toplam_hata= $hata_map[$key] ?? 0;
    $miktar     = (float)$r['miktar'];
    $oran       = $miktar > 0 ? round($toplam_hata / $miktar * 100, 1) : 0;
    $rows_isle[] = array_merge($r, [
        'toplam_hata' => $toplam_hata,
        'oran'        => $oran,
        'tamamlandi'  => ($oran >= 100),
    ]);
}

// Özet (filtre öncesi)
$toplam_kalem   = count($rows_isle);
$tamamlanan     = count(array_filter($rows_isle, fn($r)=>$r['tamamlandi']));
$bekleyen       = $toplam_kalem - $tamamlanan;

// Tamamlananları gizle — sadece bekleyenleri göster
$rows_isle = array_values(array_filter($rows_isle, fn($r)=>!$r['tamamlandi']));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Dış İade — Satış İade Raporu</h1>
    <div class="s-yol">Kalite / <b>Dış İade</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-kontrol" class="btn btn-b btn-sm">📋 Kontrol Sonuçları</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-ozet"    class="btn btn-b btn-sm">📊 Özet</a>
  </div>
</div>

<div class="s-body">

<!-- Tarih filtresi -->
<div class="kart" style="margin-bottom:14px;padding:12px">
  <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="start_date" value="<?= $start ?>">
    </div>
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="end_date" value="<?= $end ?>">
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Veri Çek</button>
  </form>
</div>

<?php if ($hata_msg): ?>
<div style="background:var(--hat-a);color:var(--hat);padding:12px 16px;border-radius:var(--r);margin-bottom:14px">
  ⚠️ <?= $hata_msg ?>
</div>
<?php endif; ?>

<!-- Özet kartlar -->
<?php if ($tiger_rows): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:14px">
  <?php foreach ([
    ['Toplam Kalem', $toplam_kalem,  '#1E3A5F','#E0F2FE'],
    ['Tamamlanan',   $tamamlanan,    '#22C55E','#D1FAE5'],
    ['Bekleyen',     $bekleyen,      '#F59E0B','#FEF9C3'],
  ] as [$lbl,$val,$fg,$bg]): ?>
  <div style="background:<?= $bg ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $fg ?>"><?= $val ?></div>
    <div style="font-size:10px;font-weight:700;color:<?= $fg ?>;text-transform:uppercase;opacity:.8;margin-top:2px"><?= $lbl ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0">
  <div style="overflow-x:auto">
    <?php $sth = ['#','İrsaliye Tarihi','İrsaliye No','Müşteri','Malzeme Kodu','Malzeme Adı',
                  'İrs. Miktarı','Hata Miktarı','Kontrol Oranı','Kontrol Et']; ?>
    <table id="iadeTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;
                     padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;
                     padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
      <?php foreach ($rows_isle as $i => $r):
          if ($r['tamamlandi'])    { $rbg='background:#D1FAE5'; $disabled='disabled'; $btn_lbl='✅ Tamamlandı'; $btn_cls=''; }
          elseif ($r['oran'] > 0) { $rbg='background:#FEF9C3'; $disabled=''; $btn_lbl='🔍 Kontrol Et'; $btn_cls=''; }
          else                    { $rbg='background:#FEE2E2'; $disabled=''; $btn_lbl='🔍 Kontrol Et'; $btn_cls=''; }
      ?>
      <tr style="<?= $rbg ?>">
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td style="white-space:nowrap;font-size:12px"><?= htmlspecialchars($r['irsaliye_tarihi']??'') ?></td>
        <td style="font-family:monospace;font-weight:700;white-space:nowrap">
          <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-detay&irsaliye=<?= urlencode($r['irsaliye_no']) ?>"
             style="color:var(--t)"><?= htmlspecialchars($r['irsaliye_no']??'') ?></a>
        </td>
        <td style="font-size:12px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
            title="<?= htmlspecialchars($r['musteri_adi']??'') ?>"><?= htmlspecialchars($r['musteri_adi']??'') ?></td>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['malzeme_kodu']??'') ?></td>
        <td style="font-size:12px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
            title="<?= htmlspecialchars($r['malzeme_adi']??'') ?>"><?= htmlspecialchars($r['malzeme_adi']??'') ?></td>
        <td style="text-align:right;font-weight:700"><?= number_format((float)$r['miktar'],0) ?></td>
        <td style="text-align:right;font-weight:700;color:<?= $r['toplam_hata']>0?'#EF4444':'var(--m3)' ?>">
          <?= $r['toplam_hata'] > 0 ? number_format($r['toplam_hata'],0) : '—' ?>
        </td>
        <td style="text-align:center;font-weight:800;color:<?= $r['tamamlandi']?'#22C55E':($r['oran']>0?'#F59E0B':'#EF4444') ?>">
          <?= $r['oran'] ?>%
        </td>
        <td>
          <button type="button" class="btn btn-t btn-sm kontrol-btn"
                  <?= $disabled ?>
                  data-irsaliye="<?= htmlspecialchars($r['irsaliye_no'],ENT_QUOTES) ?>"
                  data-kod="<?= htmlspecialchars($r['malzeme_kodu'],ENT_QUOTES) ?>"
                  data-adi="<?= htmlspecialchars($r['malzeme_adi'],ENT_QUOTES) ?>"
                  data-miktar="<?= (float)$r['miktar'] ?>"
                  style="white-space:nowrap;<?= $disabled?'opacity:.5;cursor:not-allowed':'' ?>">
            <?= $btn_lbl ?>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php elseif (!$hata_msg): ?>
<div class="kart" style="text-align:center;padding:48px;color:var(--m2)">
  <div style="font-size:40px;margin-bottom:12px">📦</div>
  <div>Veri çekmek için tarih aralığı seçin ve <b>Veri Çek</b> butonuna basın.</div>
</div>
<?php endif; ?>

</div><!-- /s-body -->

<!-- ── Kontrol Modal ──────────────────────────────────────────── -->
<div id="kontrolModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;
     align-items:flex-start;justify-content:center;overflow-y:auto;padding:20px 10px"
     onclick="if(event.target===this)kapatModal()">
  <div style="background:var(--yuzey);border-radius:12px;width:95%;max-width:660px;margin:auto">

    <!-- Header -->
    <div style="background:var(--kenar-a);padding:12px 18px;border-radius:12px 12px 0 0;
                display:flex;align-items:center;justify-content:space-between">
      <div style="font-weight:800;font-size:14px">🔍 İrsaliye Kontrol Kaydı</div>
      <button onclick="kapatModal()" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--m2)">✕</button>
    </div>

    <!-- Body -->
    <div style="padding:16px">

      <!-- Bilgi satırı -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
        <div>
          <label class="form-et">İrsaliye No</label>
          <input id="mIrsaliyeNo" class="form-alan" type="text" readonly
                 style="background:var(--kenar-a);font-family:monospace;font-size:12px">
        </div>
        <div>
          <label class="form-et">Malzeme Kodu</label>
          <input id="mMalzemeKod" class="form-alan" type="text" readonly
                 style="background:var(--kenar-a);font-family:monospace;font-size:12px">
        </div>
        <div style="grid-column:1/-1">
          <label class="form-et">Malzeme Adı</label>
          <input id="mMalzemeAdi" class="form-alan" type="text" readonly
                 style="background:var(--kenar-a);font-size:12px">
        </div>
        <div>
          <label class="form-et">İrsaliye Miktarı</label>
          <input id="mMiktar" class="form-alan" type="number" readonly
                 style="background:var(--kenar-a);font-weight:800">
        </div>
        <div>
          <label class="form-et">Girilen Toplam</label>
          <input id="mToplam" class="form-alan" type="number" readonly
                 style="background:var(--kenar-a);font-weight:800;color:#EF4444">
        </div>
      </div>

      <!-- Hata satırları -->
      <div style="font-size:11px;font-weight:800;color:var(--m2);text-transform:uppercase;margin-bottom:6px">
        Hata Detayları
      </div>
      <div style="overflow-x:auto;margin-bottom:10px">
        <table style="width:100%;border-collapse:collapse;font-size:12px;min-width:500px">
          <thead>
            <tr style="background:#1E3A5F">
              <th style="color:#fff;padding:6px 8px;text-align:left;font-weight:700;min-width:160px">Hata Tipi</th>
              <th style="color:#fff;padding:6px 8px;font-weight:700;width:80px">Miktar</th>
              <th style="color:#fff;padding:6px 8px;text-align:left;font-weight:700;min-width:180px">Alınan Aksiyon</th>
            </tr>
          </thead>
          <tbody id="hataSatirlar"></tbody>
        </table>
      </div>

      <div id="mUyari" style="display:none;color:#EF4444;font-size:12px;font-weight:700;
           padding:6px 10px;background:#FEE2E2;border-radius:6px;margin-bottom:10px"></div>

      <div style="display:flex;gap:8px;justify-content:flex-end;padding-top:8px;border-top:1px solid var(--kenar)">
        <button onclick="kapatModal()" class="btn btn-b btn-sm">İptal</button>
        <button onclick="kontrolKaydet()" class="btn btn-t btn-sm">💾 Kaydet</button>
      </div>
    </div>
  </div>
</div>

<script>
var hataTipleri = <?= json_encode($hata_tipleri) ?>;
var aksiyonlar  = <?= json_encode($aksiyonlar) ?>;

$(document).ready(function(){
  $('#iadeTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true, scrollY:520, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',filename:'DisIade_<?= date('Ymd') ?>'},
      {extend:'print',text:'🖨 Yazdır'}
    ],
    drawCallback:function(){
      $('#iadeTablo thead th,#iadeTablo tfoot th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#fff','important');
      });
    },
    initComplete:function(){
      this.api().columns([1,3,4]).every(function(){
        var col=this, sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo($(col.footer()).empty())
          .on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
        col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); });
      });
      $('#iadeTablo thead th,#iadeTablo tfoot th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#fff','important');
      });
    }
  });
});

document.addEventListener('click', function(e){
  var btn = e.target.closest('.kontrol-btn');
  if (btn && !btn.disabled) {
    acModal(btn.dataset.irsaliye, btn.dataset.kod, btn.dataset.adi, parseFloat(btn.dataset.miktar));
  }
});

function acModal(irs, kod, adi, mkt){
  document.getElementById('mIrsaliyeNo').value = irs;
  document.getElementById('mMalzemeKod').value = kod;
  document.getElementById('mMalzemeAdi').value = adi;
  document.getElementById('mMiktar').value     = mkt;
  document.getElementById('mToplam').value     = 0;
  document.getElementById('mUyari').style.display = 'none';

  var tbody = document.getElementById('hataSatirlar');
  tbody.innerHTML = '';
  var htOpt = hataTipleri.map(function(h){ return '<option>'+h+'</option>'; }).join('');
  var akOpt = aksiyonlar.map(function(a){ return '<option>'+a+'</option>'; }).join('');
  for (var i = 0; i < 5; i++) {
    var tr = document.createElement('tr');
    tr.style.background = i%2===0 ? '' : 'var(--kenar-a)';
    tr.innerHTML =
      '<td style="padding:4px"><select class="form-alan hata-tip" style="font-size:11px;padding:3px 6px">'+htOpt+'</select></td>'+
      '<td style="padding:4px"><input type="number" class="form-alan hata-mkt" min="0" value="0" '+
        'style="font-size:11px;padding:3px 6px;width:72px" oninput="toplamGuncelle()"></td>'+
      '<td style="padding:4px"><select class="form-alan hata-ak" style="font-size:11px;padding:3px 6px">'+akOpt+'</select></td>';
    tbody.appendChild(tr);
  }

  document.getElementById('kontrolModal').style.display = 'flex';
  document.getElementById('kontrolModal').scrollTop = 0;
}

function toplamGuncelle(){
  var toplam = 0;
  document.querySelectorAll('.hata-mkt').forEach(function(inp){ toplam += parseInt(inp.value)||0; });
  document.getElementById('mToplam').value = toplam;
  var mkt = parseFloat(document.getElementById('mMiktar').value)||0;
  var el  = document.getElementById('mUyari');
  if (toplam > 0 && toplam !== mkt) {
    el.textContent = toplam > mkt ? '⚠️ Fazla: '+(toplam-mkt)+' adet' : '⚠️ Eksik: '+(mkt-toplam)+' adet';
    el.style.display = 'block';
  } else { el.style.display = 'none'; }
}

function kapatModal(){ document.getElementById('kontrolModal').style.display = 'none'; }

async function kontrolKaydet(){
  var irs  = document.getElementById('mIrsaliyeNo').value;
  var kod  = document.getElementById('mMalzemeKod').value;
  var adi  = document.getElementById('mMalzemeAdi').value;
  var mkt  = parseFloat(document.getElementById('mMiktar').value)||0;
  var tipler=[], mktlar=[], aksA=[];

  document.querySelectorAll('#hataSatirlar tr').forEach(function(tr){
    var m = parseInt(tr.querySelector('.hata-mkt').value)||0;
    if (m > 0){
      tipler.push(tr.querySelector('.hata-tip').value);
      mktlar.push(m);
      aksA.push(tr.querySelector('.hata-ak').value);
    }
  });

  var toplam = mktlar.reduce(function(a,b){return a+b;},0);
  if (toplam !== mkt){ alert('Toplam hata miktarı ('+toplam+') irsaliye miktarı ('+mkt+') ile eşleşmiyor!'); return; }
  if (!tipler.length){ alert('En az bir hata satırı girilmeli.'); return; }

  var fd = new FormData();
  fd.append('irsaliye_no',  irs);
  fd.append('malzeme_kodu', kod);
  fd.append('malzeme_adi',  adi);
  fd.append('miktar',       mkt);
  tipler.forEach(function(t,i){
    fd.append('hata_tipi['+i+']',      t);
    fd.append('hata_miktar['+i+']',    mktlar[i]);
    fd.append('alinan_aksiyon['+i+']', aksA[i]);
  });

  try {
    var r = await fetch('<?= BASE_URL ?>/islemler/kalite/dis_iade_kayit.php', {method:'POST',body:fd});
    var j = await r.json();
    if (j.status === 'success'){ alert('Kayıt başarılı!'); kapatModal(); location.reload(); }
    else { alert('Hata: '+j.message); }
  } catch(e){ alert('Sunucu hatası: '+e.message); }
}
</script>
