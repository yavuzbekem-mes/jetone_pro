/*
 ╔══════════════════════════════════════════════════════════════════╗
 ║  MIKNATISLİ TEKMELİK KONTROL SİSTEMİ — v5.4                    ║
 ║  Cihaz: KRT-06 — Tekmelik Test Cihazi 6                                            ║
 ║                                                                  ║
 ║  v5.4 — Heartbeat ping eklendi (25 sn'de bir /api/miknatis_ping) ║
 ║  v5.3 — GPIO34/35 input-only pull-down hatası düzeltildi        ║
 ║  v5.2 — trim() zincirleme sorunu düzeltildi (ESP32 core 3.x)    ║
 ║  v5.1 — typedef struct fix                                      ║
 ╚══════════════════════════════════════════════════════════════════╝
  KÜTÜPHANELER:
  - Adafruit BusIO, Adafruit SSD1306, Adafruit GFX Library
  - RTClib by Adafruit
  - ArduinoJson v6.x
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>

// ─────────────────────────────────────────────────────────────
// KONFİGÜRASYON
// ─────────────────────────────────────────────────────────────
const char* WIFI_ADI    = "POLIZA";
const char* WIFI_SIFRE  = "59Yu686!";
const char* API_BASE    = "http://192.168.1.144:4459/jetone_pro";
const char* MAKINA_ADI  = "KRT-06";
const char* NVS_NS      = "krt06";

// ─────────────────────────────────────────────────────────────
// PIN TANIMLARI
// ─────────────────────────────────────────────────────────────
const int PIN_URUN      = 34;   // GPIO34 — input-only, dış pull-down direnci gerekli
const int PIN_M1        = 35;   // GPIO35 — input-only, dış pull-down direnci gerekli
const int PIN_M2        = 32;
const int PIN_M3        = 33;
const int PIN_SOL1      = 27;
const int PIN_SOL2      = 13;
const int PIN_LED_YESIL = 25;
const int PIN_LED_SARI  = 26;
const int PIN_LED_KIRM  = 14;
const int PIN_BUZZER    = 4;
const int PIN_TX        = 17;
const int PIN_RX        = 16;

#define OLED_ADRES 0x3C
#define OLED_W 128
#define OLED_H 64

// ─────────────────────────────────────────────────────────────
// ZAMANLAMA
// ─────────────────────────────────────────────────────────────
const unsigned long URUN_DEBOUNCE       = 80;
const unsigned long SOL_KAPANMA         = 1000;
const unsigned long HALL_BEKLEME_SURE   = 6000;
const unsigned long TEKRAR_KONTROL      = 3000;
const unsigned long WIFI_TIMEOUT        = 10000;
const unsigned long URUN_KODU_SURE      = 300000; // 5 dk'da bir ürün kodu güncelle
const unsigned long PING_SURE           = 300000; // 5 dk'da bir heartbeat (online timeout 10 dk)

// ─────────────────────────────────────────────────────────────
// DURUM MAKİNESİ
// ─────────────────────────────────────────────────────────────
enum Durum { BEKLEME, SOL_KAPANIYOR, HALL_BEKLEME, HALL_KONTROL, BASARILI, HATA_BEKLE, URUN_ALINDI };

Durum sistemDurumu        = BEKLEME;
unsigned long durumZamani = 0;
int  sonHataId            = -1;
bool ilkKontrolMu         = true;

char urunKodu[31]         = "TKM-001";
bool wifiBagliMi          = false;
unsigned long sonUrunKodu = 0;
unsigned long sonPing     = 0;

int gunlukToplam = 0, gunlukTamam = 0, gunlukHata = 0;

// ─────────────────────────────────────────────────────────────
// NESNELER
// ─────────────────────────────────────────────────────────────
Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
RTC_DS3231       rtc;
HardwareSerial   yazici(2);
Preferences      nvs;

typedef struct { bool m1, m2, m3; int eksik; } HallSonuc;

// ─────────────────────────────────────────────────────────────
// OLED
// ─────────────────────────────────────────────────────────────
void oledYaz(const char* s1, const char* s2="", const char* s3="", const char* s4="") {
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(1);
    oled.setCursor(0,0); oled.print(MAKINA_ADI); oled.print(" | "); oled.print(urunKodu);
    oled.drawFastHLine(0,10,128,SSD1306_WHITE);
    if(strlen(s1)){oled.setCursor(0,14);oled.print(s1);}
    if(strlen(s2)){oled.setCursor(0,26);oled.print(s2);}
    if(strlen(s3)){oled.setCursor(0,38);oled.print(s3);}
    if(strlen(s4)){oled.setCursor(0,50);oled.print(s4);}
    oled.display();
}

void oledBuyuk(const char* baslik, const char* alt="") {
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(2); oled.setCursor(0,10); oled.print(baslik);
    if(strlen(alt)){oled.setTextSize(1);oled.setCursor(0,44);oled.print(alt);}
    oled.display();
}

// ─────────────────────────────────────────────────────────────
// LED / BUZZER / SOLENOID
// ─────────────────────────────────────────────────────────────
void ledKapat() { digitalWrite(PIN_LED_YESIL,LOW); digitalWrite(PIN_LED_SARI,LOW); digitalWrite(PIN_LED_KIRM,LOW); }
void bip(int ms, int n) { for(int i=0;i<n;i++){digitalWrite(PIN_BUZZER,HIGH);delay(ms);digitalWrite(PIN_BUZZER,LOW);if(i<n-1)delay(120);} }
void solAc()  { digitalWrite(PIN_SOL1,LOW);  digitalWrite(PIN_SOL2,LOW);  Serial.println("Solenoid ACIK"); }
void solKap() { digitalWrite(PIN_SOL1,HIGH); digitalWrite(PIN_SOL2,HIGH); Serial.println("Solenoid KAPALI"); }

// ─────────────────────────────────────────────────────────────
// HALL
// ─────────────────────────────────────────────────────────────
HallSonuc hallOku() {
    HallSonuc s;
    s.m1=(digitalRead(PIN_M1)==LOW); s.m2=(digitalRead(PIN_M2)==LOW); s.m3=(digitalRead(PIN_M3)==LOW);
    s.eksik=(!s.m1)+(!s.m2)+(!s.m3);
    Serial.printf("Hall: M1=%s M2=%s M3=%s Eksik=%d\n",s.m1?"OK":"--",s.m2?"OK":"--",s.m3?"OK":"--",s.eksik);
    return s;
}

// ─────────────────────────────────────────────────────────────
// WiFi
// ─────────────────────────────────────────────────────────────
void wifiBaglan() {
    WiFi.mode(WIFI_STA); WiFi.begin(WIFI_ADI,WIFI_SIFRE);
    oledYaz("WiFi baglaniyor...",WIFI_ADI);
    unsigned long t=millis();
    while(WiFi.status()!=WL_CONNECTED && millis()-t<WIFI_TIMEOUT){delay(300);Serial.print(".");}
    wifiBagliMi=(WiFi.status()==WL_CONNECTED);
    if(wifiBagliMi){Serial.printf("\nWiFi OK: %s\n",WiFi.localIP().toString().c_str()); oledYaz("WiFi BAGLANDI",WiFi.localIP().toString().c_str());}
    else{Serial.println("\nWiFi YOK"); oledYaz("WiFi YOK","Cevrimdisi mod");}
    delay(800);
}

void wifiKontrol() {
    if(WiFi.status()!=WL_CONNECTED){
        wifiBagliMi=false; WiFi.reconnect();
        unsigned long t=millis();
        while(WiFi.status()!=WL_CONNECTED && millis()-t<5000) delay(200);
        wifiBagliMi=(WiFi.status()==WL_CONNECTED);
    }
}

// ─────────────────────────────────────────────────────────────
// HEARTBEAT PING — 25 sn'de bir server'a bildir
// ─────────────────────────────────────────────────────────────
void pingGonder() {
    if(!wifiBagliMi) { Serial.println("Ping: WiFi yok"); return; }
    HTTPClient http;
    String url = String(API_BASE) + "/bolumler/kalite/api/miknatis_ping.php?makina="
               + MAKINA_ADI + "&ip=" + WiFi.localIP().toString();
    Serial.printf("Ping URL: %s\n", url.c_str());
    http.begin(url);
    http.setTimeout(5000);
    int kod = http.GET();
    Serial.printf("Ping sonuc: HTTP %d\n", kod);
    if (kod > 0) Serial.println(http.getString());
    http.end();
}

// ─────────────────────────────────────────────────────────────
// ÜRÜN KODU GÜNCELLE
// ─────────────────────────────────────────────────────────────
void urunGuncelle() {
    if(!wifiBagliMi) return;
    HTTPClient http;
    String url = String(API_BASE) + "/bolumler/kalite/api/miknatis_kayit.php?action=urun_kodu&makina=" + MAKINA_ADI;
    http.begin(url); http.setTimeout(4000);
    if(http.GET()==200){
        StaticJsonDocument<128> doc;
        if(!deserializeJson(doc,http.getString()) && doc["ok"]==true){
            String uk=doc["urun_kodu"].as<String>(); uk.trim(); uk.toUpperCase();
            if(uk.length()>0 && uk.length()<=30){
                uk.toCharArray(urunKodu,31);
                nvs.begin(NVS_NS,false); nvs.putString("urun_kodu",uk); nvs.end();
                Serial.printf("Urun kodu: %s\n",urunKodu);
            }
        }
    }
    http.end();
}

// ─────────────────────────────────────────────────────────────
// DB KAYIT
// ─────────────────────────────────────────────────────────────
int dbKayit(String durum, bool m1, bool m2, bool m3, String aciklama, int orijId=-1) {
    if(!wifiBagliMi){ Serial.println("WiFi yok - kayit atlandi"); return -1; }
    StaticJsonDocument<350> doc;
    doc["urun_kodu"]=urunKodu; doc["makina_kodu"]=MAKINA_ADI; doc["durum"]=durum;
    doc["m1"]=m1?1:0; doc["m2"]=m2?1:0; doc["m3"]=m3?1:0;
    doc["ip"]=WiFi.localIP().toString();
    if(aciklama.length()) doc["aciklama"]=aciklama;
    if(orijId>0) doc["orijinal_id"]=orijId;
    String json; serializeJson(doc,json);
    HTTPClient http;
    http.begin(String(API_BASE)+"/bolumler/kalite/api/miknatis_kayit.php");
    http.addHeader("Content-Type","application/json");
    http.addHeader("X-Requested-With","XMLHttpRequest");
    http.setTimeout(5000);
    int httpKod=http.POST(json); int kayitId=-1;
    if(httpKod==200){
        StaticJsonDocument<200> r;
        if(!deserializeJson(r,http.getString()) && r["ok"]==true){
            kayitId=r["id"].as<int>();
            if(r.containsKey("ozet")){gunlukToplam=r["ozet"]["toplam"];gunlukTamam=r["ozet"]["basarili"];gunlukHata=r["ozet"]["hatali"];}
        }
        Serial.printf("DB OK id=%d\n",kayitId);
    } else Serial.printf("DB HATA: %d\n",httpKod);
    http.end();
    // Ping de güncelle (kayıt = online demek)
    sonPing = millis();
    return kayitId;
}

// ─────────────────────────────────────────────────────────────
// ETİKET
// ─────────────────────────────────────────────────────────────
void etiketBas() {
    // RTC yoksa compile zamanını kullan
    char ts[20];
    if(rtc.begin()){
        DateTime z=rtc.now();
        sprintf(ts,"%02d.%02d.%04d %02d:%02d",z.day(),z.month(),z.year(),z.hour(),z.minute());
    } else {
        sprintf(ts,__DATE__" "__TIME__);
    }
    yazici.print("^XA\n^CI28\n");
    yazici.printf("^FO20,10^BQN,2,4^FDMA,%s|%s^FS\n",urunKodu,ts);
    yazici.printf("^FO140,15^A0N,28,28^FD%s^FS\n",urunKodu);
    yazici.printf("^FO140,55^A0N,20,20^FD%s^FS\n",ts);
    yazici.printf("^FO140,90^A0N,18,18^FD%s^FS\n",MAKINA_ADI);
    yazici.print("^XZ\n");
    Serial.printf("Etiket: %s / %s\n",urunKodu,ts);
}

// ─────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    Serial.printf("\n=== Tekmelik v5.4 — %s ===\n",MAKINA_ADI);

    // GPIO34, GPIO35 input-only — dahili pulldown desteklemez, dış 10k pull-down kullan
    pinMode(PIN_URUN, INPUT);
    pinMode(PIN_M1,   INPUT);
    pinMode(PIN_M2,   INPUT_PULLDOWN);
    pinMode(PIN_M3,   INPUT_PULLDOWN);
    pinMode(PIN_SOL1, OUTPUT); pinMode(PIN_SOL2, OUTPUT);
    pinMode(PIN_LED_YESIL,OUTPUT); pinMode(PIN_LED_SARI,OUTPUT); pinMode(PIN_LED_KIRM,OUTPUT);
    pinMode(PIN_BUZZER,OUTPUT);

    solAc(); ledKapat(); digitalWrite(PIN_BUZZER,LOW);

    Wire.begin();
    if(!oled.begin(SSD1306_SWITCHCAPVCC,OLED_ADRES)) Serial.println("OLED bulunamadi!");
    oled.clearDisplay(); oled.display();
    oledYaz("Sistem basliyor...",MAKINA_ADI);

    // RTC — yoksa compile zamanını kullan
    if(!rtc.begin()){
        Serial.println("UYARI: RTC yok — compile zamani kullanilacak");
    } else {
        if(rtc.lostPower()) rtc.adjust(DateTime(F(__DATE__),F(__TIME__)));
    }

    yazici.begin(9600,SERIAL_8N1,PIN_RX,PIN_TX);

    nvs.begin(NVS_NS,false);
    String k=nvs.getString("urun_kodu","TKM-001"); k.toCharArray(urunKodu,31);
    gunlukToplam=nvs.getInt("g_toplam",0); gunlukTamam=nvs.getInt("g_tamam",0); gunlukHata=nvs.getInt("g_hata",0);
    nvs.end();

    wifiBaglan();
    urunGuncelle(); sonUrunKodu=millis();
    pingGonder();   sonPing=millis();

    ledKapat();
    digitalWrite(PIN_LED_YESIL,HIGH); delay(300);
    digitalWrite(PIN_LED_SARI,HIGH);  delay(300);
    digitalWrite(PIN_LED_KIRM,HIGH);  delay(300);
    ledKapat(); bip(80,2);

    sistemDurumu=BEKLEME;
    oledYaz("Hazir",urunKodu,"Urun bekleniyor...");
    Serial.printf("Hazir. Urun: %s\n",urunKodu);
}

// ─────────────────────────────────────────────────────────────
// LOOP
// ─────────────────────────────────────────────────────────────
void loop() {
    unsigned long simdi=millis();

    // Serial komut
    if(Serial.available()){
        String cmd=Serial.readStringUntil('\n'); cmd.trim();
        if(cmd.startsWith("KOD:")){
            String yK=cmd.substring(4); yK.trim(); yK.toUpperCase();
            yK.toCharArray(urunKodu,31);
            nvs.begin(NVS_NS,false); nvs.putString("urun_kodu",urunKodu); nvs.end();
            Serial.printf("Urun kodu: %s\n",urunKodu); bip(60,2);
        }
    }

    // Periyodik görevler
    if(simdi-sonUrunKodu > URUN_KODU_SURE){ wifiKontrol(); urunGuncelle(); sonUrunKodu=simdi; }
    if(simdi-sonPing     > PING_SURE)     { wifiKontrol(); pingGonder();   sonPing=simdi;     }

    bool urunVar=(digitalRead(PIN_URUN)==LOW);

    switch(sistemDurumu){

        case BEKLEME:
            ledKapat(); solAc();
            if(urunVar){ delay(URUN_DEBOUNCE);
                if(digitalRead(PIN_URUN)==LOW){
                    Serial.println("Urun algilandi!");
                    oledYaz("Urun Algilandi","1 sn bekleniyor...",urunKodu);
                    digitalWrite(PIN_LED_SARI,HIGH);
                    durumZamani=simdi; ilkKontrolMu=true; sistemDurumu=SOL_KAPANIYOR;
                }
            }
            break;

        case SOL_KAPANIYOR:
            if(simdi-durumZamani>=SOL_KAPANMA){
                solKap(); bip(60,1);
                oledYaz("Solenoid KAPALI","Miknatis kontrol:","6 sn bekleniyor...");
                durumZamani=simdi; sistemDurumu=HALL_BEKLEME;
            }
            break;

        case HALL_BEKLEME:
        {
            int kalan=(int)((HALL_BEKLEME_SURE-(simdi-durumZamani))/1000)+1;
            static int sonK=-1;
            if(kalan!=sonK){ char buf[16]; sprintf(buf,"%d sn...",kalan); oledYaz("Miknatis Kontrol",buf,urunKodu,MAKINA_ADI); sonK=kalan; }
            if(simdi-durumZamani>=HALL_BEKLEME_SURE){ sistemDurumu=HALL_KONTROL; durumZamani=simdi; }
            break;
        }

        case HALL_KONTROL:
        {
            HallSonuc s=hallOku(); gunlukToplam++;
            if(s.eksik==0){
                gunlukTamam++;
                oledBuyuk("TAMAM!",urunKodu); ledKapat(); digitalWrite(PIN_LED_YESIL,HIGH); bip(150,1);
                if(!ilkKontrolMu && sonHataId>0) dbKayit("duzeltildi",s.m1,s.m2,s.m3,"Miknatis eklendi",sonHataId);
                else dbKayit("basarili",s.m1,s.m2,s.m3,"");
                etiketBas(); solAc();
                char oz[32]; sprintf(oz,"OK:%d Hata:%d",gunlukTamam,gunlukHata);
                oledBuyuk("TAMAM!",oz);
                nvs.begin(NVS_NS,false); nvs.putInt("g_toplam",gunlukToplam); nvs.putInt("g_tamam",gunlukTamam); nvs.putInt("g_hata",gunlukHata); nvs.end();
                ilkKontrolMu=true; sonHataId=-1; durumZamani=simdi; sistemDurumu=URUN_ALINDI;
            } else {
                gunlukHata++;
                String eks=""; if(!s.m1)eks+="M1 "; if(!s.m2)eks+="M2 "; if(!s.m3)eks+="M3 "; eks.trim();
                String dur="hata_"+String(s.eksik);
                if(ilkKontrolMu){ sonHataId=dbKayit(dur,s.m1,s.m2,s.m3,"Eksik: "+eks); ilkKontrolMu=false; }
                ledKapat(); digitalWrite(PIN_LED_KIRM,HIGH); bip(400,2);
                char s2[32],s3[32]; sprintf(s2,"Eksik: %s",eks.c_str()); sprintf(s3,"3sn sonra kontrol");
                oledYaz("MIKNATIS EKSIK!",s2,s3,urunKodu);
                durumZamani=simdi; sistemDurumu=HATA_BEKLE;
                nvs.begin(NVS_NS,false); nvs.putInt("g_toplam",gunlukToplam); nvs.putInt("g_hata",gunlukHata); nvs.end();
            }
            break;
        }

        case HATA_BEKLE:
        {
            static unsigned long sonB=0; static bool bDur=false;
            if(simdi-sonB>600){ bDur=!bDur; digitalWrite(PIN_LED_KIRM,bDur?HIGH:LOW); sonB=simdi; }
            if(simdi-durumZamani>=TEKRAR_KONTROL){ sistemDurumu=HALL_KONTROL; durumZamani=simdi; }
            break;
        }

        case URUN_ALINDI:
            if(!urunVar){ delay(URUN_DEBOUNCE);
                if(digitalRead(PIN_URUN)==HIGH){
                    Serial.println("Urun alindi");
                    ledKapat(); solAc(); sistemDurumu=BEKLEME;
                    oledYaz("Hazir",urunKodu,"Yeni urun bekleniyor");
                }
            }
            break;

        default: sistemDurumu=BEKLEME; break;
    }

    delay(20);
}
