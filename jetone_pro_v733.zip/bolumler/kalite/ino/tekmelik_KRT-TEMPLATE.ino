/*
 ╔══════════════════════════════════════════════════════════════════╗
 ║  MIKNATISLİ TEKMELİK KONTROL SİSTEMİ — v5.0                    ║
 ║  Cihaz: %%KOD%% — %%AD%%                                        ║
 ║                                                                  ║
 ║  DONANIM:                                                        ║
 ║  - ESP32-WROOM-32 (38 pin)                                       ║
 ║  - SN04-N NPN Yakınlık Sensörü (ürün algılama)                   ║
 ║  - US1881 Hall Sensörü x3 (mıknatıs kontrolü)                    ║
 ║  - 2x Solenoid Valf 12V (fikstür kilidi)                         ║
 ║  - 0.96" OLED I2C SSD1306 (durum ekranı)                         ║
 ║  - Trafik Işığı Modülü (kırmızı/sarı/yeşil)                      ║
 ║  - Aktif Buzzer                                                  ║
 ║  - DS3231 RTC                                                    ║
 ║  - Zebra etiket yazıcı (ZPL, UART2)                              ║
 ║                                                                  ║
 ║  MANTIK:                                                         ║
 ║  1. Solenoid AÇIK → ürün fikstüre konabilir                      ║
 ║  2. Ürün algılanır (SN04-N LOW) → 1 sn bekle → solenoid KAPAT   ║
 ║  3. 6 sn bekle → Hall sensörler okunur                           ║
 ║  4. Tamam → Yeşil + etiket + solenoid AÇ                        ║
 ║  5. Hata → Kırmızı + buzzer, 3 sn'de bir tekrar kontrol          ║
 ║  6. Düzeltildi → DB güncelle + solenoid AÇ                       ║
 ╚══════════════════════════════════════════════════════════════════╝

  KÜTÜPHANELER (Arduino IDE Kütüphane Yöneticisi):
  - Adafruit SSD1306       (OLED ekran)
  - Adafruit GFX Library   (SSD1306 bağımlılığı)
  - RTClib by Adafruit     (DS3231 RTC)
  - ArduinoJson v6.x       (JSON parse)
  Wire, WiFi, HTTPClient, Preferences — ESP32 ile birlikte gelir
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>

// ─────────────────────────────────────────────────────────────
// KONFİGÜRASYON
// ─────────────────────────────────────────────────────────────
const char* WIFI_ADI    = "POLIZA";
const char* WIFI_SIFRE  = "59Yu686!";
const char* API_BASE    = "http://192.168.1.100/jetone_pro";
const char* CANLI_URL   = "http://192.168.1.100/jetone_pro/bolumler/kalite/api/canli_durum.php";
const char* MAKINA_ADI  = "%%KOD%%";
const char* NVS_NS      = "%%NS%%";     // krt01..krt08

// ─────────────────────────────────────────────────────────────
// PIN TANIMLARI
// ─────────────────────────────────────────────────────────────
// GİRİŞLER — INPUT_PULLDOWN — LOW = aktif (sensör tetiklendi)
const int PIN_URUN  = 34;   // SN04-N NPN yakınlık sensörü
const int PIN_M1    = 35;   // US1881 Hall — mıknatıs 1
const int PIN_M2    = 32;   // US1881 Hall — mıknatıs 2
const int PIN_M3    = 33;   // US1881 Hall — mıknatıs 3

// ÇIKIŞLAR — HIGH = aktif/açık
const int PIN_SOL1      = 27;   // Solenoid valf 1 (röle IN1)
const int PIN_SOL2      = 13;   // Solenoid valf 2 (röle IN2)
const int PIN_LED_YESIL = 25;   // Trafik ışığı — yeşil
const int PIN_LED_SARI  = 26;   // Trafik ışığı — sarı
const int PIN_LED_KIRM  = 14;   // Trafik ışığı — kırmızı
const int PIN_BUZZER    = 4;    // Aktif buzzer

// UART2 — Zebra yazıcı
const int PIN_TX = 17;
const int PIN_RX = 16;

// I2C — OLED + RTC (SDA=21, SCL=22 default ESP32)
#define OLED_ADRES 0x3C
#define OLED_W 128
#define OLED_H 64

// ─────────────────────────────────────────────────────────────
// ZAMANLAMA
// ─────────────────────────────────────────────────────────────
const unsigned long URUN_ALGILAMA_DEBOUNCE = 80;
const unsigned long SOL_KAPANMA_GECIKME    = 1000;  // 1 sn: ürün oturdu
const unsigned long ILK_HALL_GECIKME       = 6000;  // 6 sn: ilk mıknatıs kontrolü
const unsigned long TEKRAR_KONTROL_SURE    = 3000;  // 3 sn: hata döngüsü
const unsigned long WIFI_TIMEOUT           = 10000;
const unsigned long URUN_KODU_GUNCELLE     = 30000; // 30 sn'de bir DB'den çek
const unsigned long CANLI_GUNCELLE         = 500;   // 500ms — anlık sensör gönder

// ─────────────────────────────────────────────────────────────
// DURUM MAKİNESİ
// ─────────────────────────────────────────────────────────────
enum Durum {
    BEKLEME,        // Solenoid açık, ürün bekleniyor
    SOL_KAPANIYOR,  // Ürün algılandı, 1 sn gecikme
    HALL_BEKLEME,   // Solenoid kapandı, 6 sn bekleniyor
    HALL_KONTROL,   // Hall sensörler okunuyor
    BASARILI,       // Tamam, solenoid açılıyor
    HATA_BEKLE,     // Eksik mıknatıs, 3 sn döngüsü
    URUN_ALINDI     // Ürün fikstürden alındı
};

Durum sistemDurumu     = BEKLEME;
unsigned long durumZamani = 0;  // Durum değişim zamanı

int  sonHataId         = -1;    // İlk hata kaydı DB ID'si
bool ilkKontrolMu      = true;  // İlk mi yoksa tekrar kontrolü mü

char    urunKodu[31]   = "%%URUN%%";
bool    wifiBagliMi    = false;
unsigned long sonUrunKoduGuncelle = 0;
unsigned long sonCanliGuncelle    = 0;
int           sonGun              = -1;  // günlük sayaç sıfırlama için

int gunlukToplam = 0;
int gunlukTamam  = 0;
int gunlukHata   = 0;

// ─────────────────────────────────────────────────────────────
// NESNELER
// ─────────────────────────────────────────────────────────────
Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
RTC_DS3231       rtc;
HardwareSerial   yazici(2);
Preferences      nvs;

// ─────────────────────────────────────────────────────────────
// OLED YARDIMCILARI
// ─────────────────────────────────────────────────────────────
void oledYaz(const char* satir1, const char* satir2 = "", const char* satir3 = "", const char* satir4 = "") {
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);

    // Başlık: cihaz adı
    oled.setTextSize(1);
    oled.setCursor(0, 0);
    oled.print(MAKINA_ADI);
    oled.print(" | ");
    oled.print(urunKodu);

    oled.drawFastHLine(0, 10, 128, SSD1306_WHITE);

    oled.setTextSize(1);
    if (strlen(satir1)) { oled.setCursor(0, 14); oled.print(satir1); }
    if (strlen(satir2)) { oled.setCursor(0, 26); oled.print(satir2); }
    if (strlen(satir3)) { oled.setCursor(0, 38); oled.print(satir3); }
    if (strlen(satir4)) { oled.setCursor(0, 50); oled.print(satir4); }

    oled.display();
}

void oledBuyukYaz(const char* baslik, const char* alt = "") {
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(2);
    oled.setCursor(0, 10);
    oled.print(baslik);
    if (strlen(alt)) {
        oled.setTextSize(1);
        oled.setCursor(0, 44);
        oled.print(alt);
    }
    oled.display();
}

// ─────────────────────────────────────────────────────────────
// LED / BUZZER
// ─────────────────────────────────────────────────────────────
void ledHepsiKapat() {
    digitalWrite(PIN_LED_YESIL, LOW);
    digitalWrite(PIN_LED_SARI,  LOW);
    digitalWrite(PIN_LED_KIRM,  LOW);
}

void bipVer(int ms, int adet) {
    for (int i = 0; i < adet; i++) {
        digitalWrite(PIN_BUZZER, HIGH); delay(ms);
        digitalWrite(PIN_BUZZER, LOW);
        if (i < adet - 1) delay(120);
    }
}

// ─────────────────────────────────────────────────────────────
// SOLENOİD
// ─────────────────────────────────────────────────────────────
void solenoidAc() {
    // Solenoid LOW = açık (röle NC, solenoid enerjisiz = fikstür açık)
    digitalWrite(PIN_SOL1, LOW);
    digitalWrite(PIN_SOL2, LOW);
    Serial.println("Solenoid ACIK");
}

void solenoidKapat() {
    // Solenoid HIGH = kapalı (röle NO, solenoid enerjili = fikstür kilitli)
    digitalWrite(PIN_SOL1, HIGH);
    digitalWrite(PIN_SOL2, HIGH);
    Serial.println("Solenoid KAPALI");
}

// ─────────────────────────────────────────────────────────────
// HALL SENSÖRLER
// ─────────────────────────────────────────────────────────────
struct HallSonuc {
    bool m1, m2, m3;
    int  eksik;
};

HallSonuc hallOku() {
    HallSonuc s;
    s.m1    = (digitalRead(PIN_M1) == LOW);
    s.m2    = (digitalRead(PIN_M2) == LOW);
    s.m3    = (digitalRead(PIN_M3) == LOW);
    s.eksik = (!s.m1) + (!s.m2) + (!s.m3);
    Serial.printf("Hall: M1=%s M2=%s M3=%s Eksik=%d\n",
        s.m1?"OK":"--", s.m2?"OK":"--", s.m3?"OK":"--", s.eksik);
    return s;
}

// ─────────────────────────────────────────────────────────────
// VERİTABANI — DB'den ürün kodu çek
// ─────────────────────────────────────────────────────────────
void urunKoduGuncelle() {
    if (!wifiBagliMi) return;
    HTTPClient http;
    String url = String(API_BASE) + "/bolumler/kalite/api/miknatis_kayit.php?action=urun_kodu&makina=" + MAKINA_ADI;
    http.begin(url);
    http.setTimeout(4000);
    int kod = http.GET();
    if (kod == 200) {
        String yanit = http.getString();
        StaticJsonDocument<128> doc;
        if (!deserializeJson(doc, yanit) && doc["ok"] == true) {
            String uk = doc["urun_kodu"].as<String>();
            uk.trim(); uk.toUpperCase();
            if (uk.length() == 10) { // malzeme kodu tam 10 hane
                uk.toCharArray(urunKodu, 11);
                nvs.begin(NVS_NS, false);
                nvs.putString("urun_kodu", uk);
                nvs.end();
                Serial.printf("Urun kodu guncellendi: %s\n", urunKodu);
            }
        }
    }
    http.end();
}

// ─────────────────────────────────────────────────────────────
// VERİTABANI — Kayıt ekle
// ─────────────────────────────────────────────────────────────
int dbKayitEkle(String durum, bool m1, bool m2, bool m3, String aciklama, int orijinalId = -1) {
    if (!wifiBagliMi) { Serial.println("WiFi yok — kayit atlandi"); return -1; }

    StaticJsonDocument<350> doc;
    doc["urun_kodu"]   = urunKodu;
    doc["makina_kodu"] = MAKINA_ADI;
    doc["durum"]       = durum;
    doc["m1"]          = m1 ? 1 : 0;
    doc["m2"]          = m2 ? 1 : 0;
    doc["m3"]          = m3 ? 1 : 0;
    if (aciklama.length()) doc["aciklama"] = aciklama;
    if (orijinalId > 0)    doc["orijinal_id"] = orijinalId;

    String json; serializeJson(doc, json);

    HTTPClient http;
    http.begin(String(API_BASE) + "/bolumler/kalite/api/miknatis_kayit.php");
    http.addHeader("Content-Type", "application/json");
    http.addHeader("X-Requested-With", "XMLHttpRequest");
    http.setTimeout(5000);

    int httpKod = http.POST(json);
    int kayitId = -1;

    if (httpKod == 200) {
        StaticJsonDocument<200> yanDoc;
        if (!deserializeJson(yanDoc, http.getString()) && yanDoc["ok"] == true) {
            kayitId = yanDoc["id"].as<int>();
            if (yanDoc.containsKey("ozet")) {
                gunlukToplam = yanDoc["ozet"]["toplam"].as<int>();
                gunlukTamam  = yanDoc["ozet"]["basarili"].as<int>();
                gunlukHata   = yanDoc["ozet"]["hatali"].as<int>();
            }
        }
        Serial.printf("DB OK id=%d\n", kayitId);
    } else {
        Serial.printf("DB HATA: %d\n", httpKod);
    }
    http.end();
    return kayitId;
}

// ─────────────────────────────────────────────────────────────
// ETİKET BAS
// ─────────────────────────────────────────────────────────────
void etiketBas() {
    DateTime z = rtc.now();
    char ts[20];
    sprintf(ts, "%02d.%02d.%04d %02d:%02d", z.day(), z.month(), z.year(), z.hour(), z.minute());

    yazici.print("^XA\n^CI28\n");
    yazici.printf("^FO20,10^BQN,2,4^FDMA,%s|%s^FS\n", urunKodu, ts);
    yazici.printf("^FO140,15^A0N,28,28^FD%s^FS\n", urunKodu);
    yazici.printf("^FO140,55^A0N,20,20^FD%s^FS\n", ts);
    yazici.printf("^FO140,90^A0N,18,18^FD%s^FS\n", MAKINA_ADI);
    yazici.print("^XZ\n");
    Serial.printf("Etiket: %s / %s\n", urunKodu, ts);
}


// ─────────────────────────────────────────────────────────────
// CANLI DURUM GÖNDER (500ms — DB'ye yazmaz, anlık görünüm için)
// ─────────────────────────────────────────────────────────────
void canliDurumGonder() {
    if (!wifiBagliMi) return;

    bool s0 = (digitalRead(PIN_URUN) == LOW);
    bool m1 = (digitalRead(PIN_M1)   == LOW);
    bool m2 = (digitalRead(PIN_M2)   == LOW);
    bool m3 = (digitalRead(PIN_M3)   == LOW);
    bool solAcik = (sistemDurumu == BEKLEME || sistemDurumu == URUN_ALINDI);

    // Durum string
    String durumStr = "BEKLEME";
    switch(sistemDurumu) {
        case SOL_KAPANIYOR:  durumStr = "SOL_KAPANIYOR"; break;
        case HALL_BEKLEME:   durumStr = "HALL_BEKLEME";  break;
        case HALL_KONTROL:   durumStr = "HALL_KONTROL";  break;
        case BASARILI:       durumStr = "BASARILI";      break;
        case HATA_BEKLE:     durumStr = "HATA_BEKLE";    break;
        case URUN_ALINDI:    durumStr = "URUN_ALINDI";   break;
        default:             durumStr = "BEKLEME";       break;
    }

    String url = String(CANLI_URL);
    url += "?action=yaz";
    url += "&makina=" + String(MAKINA_ADI);
    url += "&urun="   + String(urunKodu);
    url += "&s0="     + String(s0 ? 1 : 0);
    url += "&m1="     + String(m1 ? 1 : 0);
    url += "&m2="     + String(m2 ? 1 : 0);
    url += "&m3="     + String(m3 ? 1 : 0);
    url += "&durum="  + durumStr;
    url += "&sol="    + String(solAcik ? 1 : 0);

    HTTPClient http;
    http.begin(url);
    http.setTimeout(300); // çok kısa timeout — bloklamasın
    http.GET();
    http.end();
}

// ─────────────────────────────────────────────────────────────
// WiFi
// ─────────────────────────────────────────────────────────────
void wifiBaglan() {
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_ADI, WIFI_SIFRE);
    oledYaz("WiFi baglaniyor...", WIFI_ADI);
    unsigned long t = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t < WIFI_TIMEOUT) {
        delay(300); Serial.print(".");
    }
    wifiBagliMi = (WiFi.status() == WL_CONNECTED);
    if (wifiBagliMi) {
        Serial.printf("\nWiFi OK: %s\n", WiFi.localIP().toString().c_str());
        oledYaz("WiFi BAGLANDI", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\nWiFi YOK — cevrimdisi");
        oledYaz("WiFi YOK", "Cevrimdisi mod");
    }
    delay(1000);
}

void wifiKontrol() {
    if (WiFi.status() != WL_CONNECTED) {
        wifiBagliMi = false;
        WiFi.reconnect();
        unsigned long t = millis();
        while (WiFi.status() != WL_CONNECTED && millis() - t < 5000) delay(200);
        wifiBagliMi = (WiFi.status() == WL_CONNECTED);
    }
}

// ─────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    Serial.printf("\n=== Tekmelik v5.0 — %s ===\n", MAKINA_ADI);

    // Pin modları
    pinMode(PIN_URUN, INPUT_PULLDOWN);
    pinMode(PIN_M1,   INPUT_PULLDOWN);
    pinMode(PIN_M2,   INPUT_PULLDOWN);
    pinMode(PIN_M3,   INPUT_PULLDOWN);
    pinMode(PIN_SOL1,     OUTPUT);
    pinMode(PIN_SOL2,     OUTPUT);
    pinMode(PIN_LED_YESIL,OUTPUT);
    pinMode(PIN_LED_SARI, OUTPUT);
    pinMode(PIN_LED_KIRM, OUTPUT);
    pinMode(PIN_BUZZER,   OUTPUT);

    // Başlangıç: solenoid açık, ledler kapalı
    solenoidAc();
    ledHepsiKapat();
    digitalWrite(PIN_BUZZER, LOW);

    // OLED
    Wire.begin();
    if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADRES)) {
        Serial.println("HATA: OLED bulunamadi!");
    }
    oled.clearDisplay(); oled.display();
    oledYaz("Sistem basliyor...", MAKINA_ADI);

    // RTC
    if (!rtc.begin()) {
        Serial.println("HATA: RTC bulunamadi!");
        oledYaz("HATA!", "RTC bulunamadi");
        delay(2000);
    }
    if (rtc.lostPower()) rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));

    // Yazıcı UART2
    yazici.begin(9600, SERIAL_8N1, PIN_RX, PIN_TX);

    // NVS — kalıcı bellek
    nvs.begin(NVS_NS, false);
    String k = nvs.getString("urun_kodu", "%%URUN%%");
    k.toCharArray(urunKodu, 31);
    gunlukToplam = nvs.getInt("g_toplam", 0);
    gunlukTamam  = nvs.getInt("g_tamam",  0);
    gunlukHata   = nvs.getInt("g_hata",   0);
    nvs.end();

    // WiFi
    wifiBaglan();

    // DB'den güncel ürün kodunu çek
    urunKoduGuncelle();
    sonUrunKoduGuncelle = millis();

    // Test bip
    ledHepsiKapat();
    digitalWrite(PIN_LED_YESIL, HIGH); delay(300);
    digitalWrite(PIN_LED_SARI,  HIGH); delay(300);
    digitalWrite(PIN_LED_KIRM,  HIGH); delay(300);
    ledHepsiKapat();
    bipVer(80, 2);

    sistemDurumu = BEKLEME;
    oledYaz("Hazir", urunKodu, "Urun bekleniyor...");
    Serial.printf("Hazir. Urun: %s\n", urunKodu);
}

// ─────────────────────────────────────────────────────────────
// LOOP
// ─────────────────────────────────────────────────────────────
void loop() {
    unsigned long simdi = millis();

    // Serial komut
    if (Serial.available()) {
        String cmd = Serial.readStringUntil('\n'); cmd.trim();
        if (cmd.startsWith("KOD:")) {
            cmd.substring(4).trim().toCharArray(urunKodu, 11);
            nvs.begin(NVS_NS, false); nvs.putString("urun_kodu", urunKodu); nvs.end();
            Serial.printf("Urun kodu: %s\n", urunKodu);
            bipVer(60, 2);
        }
    }

    // Periyodik: WiFi + ürün kodu güncelle
    if (simdi - sonUrunKoduGuncelle > URUN_KODU_GUNCELLE) {
        wifiKontrol();
        urunKoduGuncelle();
        sonUrunKoduGuncelle = simdi;
    }

    // Canlı sensör durumu gönder (500ms)
    if (simdi - sonCanliGuncelle > CANLI_GUNCELLE) {
        canliDurumGonder();
        sonCanliGuncelle = simdi;
    }

    // Günlük sayaç sıfırlama — gece yarısı
    int bugunGun = rtc.now().day();
    if (sonGun == -1) sonGun = bugunGun;
    if (bugunGun != sonGun) {
        sonGun = bugunGun;
        gunlukToplam = 0; gunlukTamam = 0; gunlukHata = 0;
        nvs.begin(NVS_NS, false);
        nvs.putInt("g_toplam", 0);
        nvs.putInt("g_tamam",  0);
        nvs.putInt("g_hata",   0);
        nvs.end();
        Serial.println("Gunluk sayaclar sifirlandi.");
        oledYaz("Yeni Gun!", "Sayaclar sifirlandi", urunKodu);
        delay(1500);
    }

    // Anlık sensör
    bool urunVar = (digitalRead(PIN_URUN) == LOW);

    switch (sistemDurumu) {

        // ══════════════════════════════════════════════════════
        case BEKLEME:
        // Solenoid açık, ürün bekleniyor
        // ══════════════════════════════════════════════════════
            ledHepsiKapat();
            solenoidAc();
            if (urunVar) {
                delay(URUN_ALGILAMA_DEBOUNCE);
                if (digitalRead(PIN_URUN) == LOW) {
                    Serial.println("Urun algilandi!");
                    oledYaz("Urun Algilandi", "1 sn bekleniyor...", urunKodu);
                    digitalWrite(PIN_LED_SARI, HIGH);
                    durumZamani    = simdi;
                    ilkKontrolMu   = true;
                    sistemDurumu   = SOL_KAPANIYOR;
                }
            }
            break;

        // ══════════════════════════════════════════════════════
        case SOL_KAPANIYOR:
        // 1 sn bekle: ürün fikstüre oturdu
        // ══════════════════════════════════════════════════════
            if (simdi - durumZamani >= SOL_KAPANMA_GECIKME) {
                solenoidKapat();
                bipVer(60, 1);
                oledYaz("Solenoid KAPALI", "Miknatis kontrol:", "6 sn bekleniyor...");
                durumZamani  = simdi;
                sistemDurumu = HALL_BEKLEME;
            }
            break;

        // ══════════════════════════════════════════════════════
        case HALL_BEKLEME:
        // 6 sn bekle, sonra ilk Hall kontrolü
        // ══════════════════════════════════════════════════════
        {
            // Geri sayım göster
            int kalan = (int)((ILK_HALL_GECIKME - (simdi - durumZamani)) / 1000) + 1;
            static int sonKalan = -1;
            if (kalan != sonKalan) {
                char buf[16]; sprintf(buf, "%d sn...", kalan);
                oledYaz("Miknatis Kontrol", buf, urunKodu, MAKINA_ADI);
                sonKalan = kalan;
            }
            if (simdi - durumZamani >= ILK_HALL_GECIKME) {
                sistemDurumu = HALL_KONTROL;
                durumZamani  = simdi;
            }
            break;
        }

        // ══════════════════════════════════════════════════════
        case HALL_KONTROL:
        // Hall sensörleri oku, karar ver
        // ══════════════════════════════════════════════════════
        {
            HallSonuc s = hallOku();
            gunlukToplam++;

            if (s.eksik == 0) {
                // TAMAM
                gunlukTamam++;
                oledBuyukYaz("TAMAM!", urunKodu);
                ledHepsiKapat();
                digitalWrite(PIN_LED_YESIL, HIGH);
                bipVer(150, 1);

                String aciklama = "";
                if (!ilkKontrolMu && sonHataId > 0) {
                    // Düzeltildi kaydı
                    dbKayitEkle("duzeltildi", s.m1, s.m2, s.m3, "Miknatis eklendi, duzeltildi", sonHataId);
                    aciklama = "duzeltildi";
                } else {
                    // Direkt başarılı
                    dbKayitEkle("basarili", s.m1, s.m2, s.m3, "");
                }

                etiketBas();
                solenoidAc();

                char ozet[32];
                sprintf(ozet, "OK:%d Hata:%d", gunlukTamam, gunlukHata);
                oledBuyukYaz("TAMAM!", ozet);

                nvs.begin(NVS_NS, false);
                nvs.putInt("g_toplam", gunlukToplam);
                nvs.putInt("g_tamam",  gunlukTamam);
                nvs.putInt("g_hata",   gunlukHata);
                nvs.end();

                ilkKontrolMu = true;
                sonHataId    = -1;
                durumZamani  = simdi;
                sistemDurumu = URUN_ALINDI;

            } else {
                // HATA
                gunlukHata++;

                // Hangi mıknatıslar eksik
                String eksikStr = "";
                if (!s.m1) eksikStr += "M1 ";
                if (!s.m2) eksikStr += "M2 ";
                if (!s.m3) eksikStr += "M3 ";
                eksikStr.trim();

                String durumStr = "hata_" + String(s.eksik);

                if (ilkKontrolMu) {
                    // İlk hata — DB'ye yaz
                    sonHataId = dbKayitEkle(durumStr, s.m1, s.m2, s.m3,
                                            "Eksik: " + eksikStr);
                    ilkKontrolMu = false;
                }
                // Tekrar kontrolde ise DB'ye yeni kayıt atmıyoruz, düzeltildi kaydı bekliyor

                ledHepsiKapat();
                digitalWrite(PIN_LED_KIRM, HIGH);
                bipVer(400, 2);

                char satir2[32], satir3[32];
                sprintf(satir2, "Eksik: %s", eksikStr.c_str());
                sprintf(satir3, "3sn sonra kontrol");
                oledYaz("MIKNATIS EKSIK!", satir2, satir3, urunKodu);

                durumZamani  = simdi;
                sistemDurumu = HATA_BEKLE;

                nvs.begin(NVS_NS, false);
                nvs.putInt("g_toplam", gunlukToplam);
                nvs.putInt("g_hata",   gunlukHata);
                nvs.end();
            }
            break;
        }

        // ══════════════════════════════════════════════════════
        case HATA_BEKLE:
        // 3 sn döngüsü — kırmızı LED yanıp söner
        // ══════════════════════════════════════════════════════
        {
            // Yanıp sönme
            static unsigned long sonBlink = 0;
            static bool blinkDur = false;
            if (simdi - sonBlink > 600) {
                blinkDur = !blinkDur;
                digitalWrite(PIN_LED_KIRM, blinkDur ? HIGH : LOW);
                sonBlink = simdi;
            }

            if (simdi - durumZamani >= TEKRAR_KONTROL_SURE) {
                sistemDurumu = HALL_KONTROL;
                durumZamani  = simdi;
            }
            break;
        }

        // ══════════════════════════════════════════════════════
        case URUN_ALINDI:
        // Solenoid açıldı, ürünün alınmasını bekle
        // ══════════════════════════════════════════════════════
            if (!urunVar) {
                delay(URUN_ALGILAMA_DEBOUNCE);
                if (digitalRead(PIN_URUN) == HIGH) {
                    Serial.println("Urun alindi — beklemeye don");
                    ledHepsiKapat();
                    solenoidAc();
                    sistemDurumu = BEKLEME;
                    oledYaz("Hazir", urunKodu, "Yeni urun bekleniyor");
                }
            }
            break;

        default:
            sistemDurumu = BEKLEME;
            break;
    }

    delay(20);
}
