<?php
/**
 * JETONE.PRO — Uygunsuzluk Yazdır
 * panel.php: 'kalite-uygunsuzluk-yazdir' => 'bolumler/kalite/uygunsuzluk_yazdir.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<p>Geçersiz ID</p>'; exit; }
$st = $db->prepare("SELECT * FROM uygunsuzluk WHERE id=?");
$st->execute([$id]);
$k = $st->fetch(PDO::FETCH_ASSOC);
if (!$k) { echo '<p>Kayıt bulunamadı</p>'; exit; }

function ft($t){ return (!empty($t)&&$t!=='0000-00-00')?date('d.m.Y',strtotime($t)):'—'; }
function ns($v,$d='—'){ $v=trim($v??''); return htmlspecialchars($v!==''?$v:$d); }
$yer_map=['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'];
?>
<style>
@media print {
  .s-bar,.btn,.no-print{display:none!important}
  .s-body{padding:0!important}
  .yazdir-kart{box-shadow:none!important;border:none!important}
}
.yazdir-tablo { width:100%;border-collapse:collapse;font-size:13px; }
.yazdir-tablo td,.yazdir-tablo th { border:1px solid #ccc;padding:7px 10px; }
.yazdir-tablo th { background:#F1F5F9;font-weight:700;width:40%;font-size:12px; }
.sec-baslik { background:#1E3A5F;color:#fff;text-align:center;font-weight:800;padding:8px;font-size:13px; }
</style>

<div class="s-bar no-print">
  <div>
    <h1 class="s-bas">🖨 Uygunsuzluk Raporu</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" style="color:var(--t)">Liste</a> / <b><?= ns($k['takip_no']) ?></b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="window.print()" class="btn btn-t btn-sm">🖨 Yazdır</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-uygunsuzluk-liste" class="btn btn-b btn-sm">← Liste</a>
  </div>
</div>

<div class="s-body">
<div class="kart yazdir-kart" style="max-width:800px;margin:0 auto">
  <div style="text-align:center;margin-bottom:16px;border-bottom:2px solid #1E3A5F;padding-bottom:12px">
    <div style="font-size:18px;font-weight:800">UYGUNSUZLUK RAPORU</div>
    <div style="font-size:11px;color:#666;margin-top:2px">Doküman No: FR.06 | Rev.No: 02 | Rev.Tarihi: 04.07.2024 | Ref.Madde: 7.5/8.7</div>
  </div>

  <table class="yazdir-tablo" style="margin-bottom:12px">
    <tr><th>Uygunsuzluk Takip No</th><td style="font-family:monospace;font-weight:800;color:#1E3A5F"><?= ns($k['takip_no']) ?></td><th>Tespit Tarihi</th><td><?= ft($k['tespit_tarihi']) ?></td></tr>
    <tr><th>Tespit Eden Kişi</th><td><?= ns($k['tespit_eden_kisi']) ?></td><th>Vardiya</th><td><?= ns($k['vardiya']) ?>. Vardiya</td></tr>
  </table>

  <div class="sec-baslik">UYGUNSUZLUK YERİ</div>
  <table class="yazdir-tablo" style="margin-bottom:12px">
    <tr>
      <?php foreach (['musteri'=>'Müşteri','uretim'=>'Üretim','tedarikci'=>'Tedarikçi'] as $v=>$l): ?>
      <td style="text-align:center;width:33%">
        <span style="display:inline-block;width:16px;height:16px;border-radius:50%;border:2px solid #555;
              background:<?= $k['uygunsuzluk_yeri']===$v?'#1E3A5F':'#fff' ?>;vertical-align:middle;margin-right:6px"></span>
        <b><?= $l ?></b>
      </td>
      <?php endforeach; ?>
    </tr>
  </table>

  <div class="sec-baslik">MALZEME BİLGİLERİ</div>
  <table class="yazdir-tablo" style="margin-bottom:12px">
    <tr><th>Malzeme/Parça Adı</th><td><?= ns($k['malzeme_adi']) ?></td><th>Kodu</th><td><?= ns($k['malzeme_kodu']) ?></td></tr>
    <tr><th>Tedarikçi Firma</th><td><?= ns($k['tedarikci_firma']) ?></td><th>Proses</th><td><?= ns($k['proses_adi']) ?></td></tr>
    <tr><th>Malzeme Giriş Tarihi</th><td><?= ft($k['malzeme_giris_tarihi']) ?></td><th>İrsaliye/Fatura No</th><td><?= ns($k['irsaliye_no']) ?></td></tr>
    <tr><th>Toplam Miktar</th><td><?= ns($k['uretim_miktar']) ?></td><th>Hatalı Miktar</th><td><?= ns($k['hatali_miktar']) ?></td></tr>
    <tr><th>Uygunsuzluk Sebebi</th><td colspan="3" style="white-space:pre-wrap"><?= ns($k['uygunsuzluk_sebebi']) ?></td></tr>
    <?php if ($k['uygunsuzluk_gorsel']): ?>
    <tr><th>Görsel</th><td colspan="3"><img src="<?= BASE_URL ?>/kys_dokumanlar/uygunsuzluk/<?= ns($k['uygunsuzluk_gorsel']) ?>" style="max-width:200px;max-height:150px;object-fit:contain"></td></tr>
    <?php endif; ?>
  </table>

  <div class="sec-baslik">KARAR</div>
  <table class="yazdir-tablo" style="margin-bottom:12px">
    <tr><th>Değerlendirme Sonucu</th><td colspan="3" style="white-space:pre-wrap"><?= ns($k['degerlendirme_sonucu']) ?></td></tr>
    <tr><th>Değerlendirme Tarihi</th><td><?= ft($k['degerlendirme_tarihi']) ?></td><th>Karar</th><td style="white-space:pre-wrap"><?= ns($k['karar']) ?></td></tr>
  </table>

  <div class="sec-baslik">DÜZELTİCİ FAALİYET</div>
  <table class="yazdir-tablo" style="margin-bottom:12px">
    <tr>
      <td style="text-align:center">
        <span style="display:inline-block;width:14px;height:14px;border-radius:50%;border:2px solid #555;background:<?= $k['duzeltici_faaliyet']==='gerekiyor'?'#1E3A5F':'#fff' ?>;margin-right:6px"></span>
        <b>Gerekiyor</b>
      </td>
      <td style="text-align:center">
        <span style="display:inline-block;width:14px;height:14px;border-radius:50%;border:2px solid #555;background:<?= $k['duzeltici_faaliyet']==='gerekmiyor'?'#1E3A5F':'#fff' ?>;margin-right:6px"></span>
        <b>Gerekmiyor</b>
      </td>
    </tr>
    <?php if ($k['duzeltici_faaliyet']==='gerekiyor'): ?>
    <tr><th>DÖF No</th><td><?= ns($k['df_no']) ?></td><th>DÖF Hedef Tarihi</th><td><?= ft($k['df_hedef_tarih']) ?></td></tr>
    <tr><th>8D No</th><td><?= ns($k['sekizd_no']) ?></td><th>8D Hedef Tarihi</th><td><?= ft($k['sekizd_hedef_tarih']) ?></td></tr>
    <?php endif; ?>
  </table>

  <!-- İmzalar -->
  <table class="yazdir-tablo" style="margin-top:24px">
    <tr>
      <td style="text-align:center;padding:20px"><div style="border-top:1px solid #555;margin-top:40px;padding-top:6px;font-size:12px"><b>KALİTE KONTROL SORUMLUSU</b><br><?= ns($k['kalite_sorumlu']) ?></div></td>
      <td style="text-align:center;padding:20px"><div style="border-top:1px solid #555;margin-top:40px;padding-top:6px;font-size:12px"><b>KALİTE GÜVENCE MÜDÜRÜ</b><br><?= ns($k['kalite_mudur']) ?></div></td>
      <td style="text-align:center;padding:20px"><div style="border-top:1px solid #555;margin-top:40px;padding-top:6px;font-size:12px"><b>ÜRETİM MÜDÜRÜ</b><br><?= ns($k['uretim_mudur']) ?></div></td>
    </tr>
  </table>

  <div style="text-align:center;font-size:10px;color:#888;margin-top:12px;border-top:1px solid #eee;padding-top:8px">
    DOKÜMAN NO: FR.06 | YAYIN TARİHİ: 02.01.2018 | REVİZYON NO: 02 | REVİZYON TARİHİ: 04.07.2024 | REF.MADDE: 7.5/8.7 | SAYFA NO: 1/1
  </div>
</div>
</div>
