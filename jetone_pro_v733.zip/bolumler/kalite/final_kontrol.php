<?php
/**
 * JETONE.PRO — Final Kontrol Terminal (Mobil Barkod)
 * bolumler/kalite/final_kontrol.php
 * panel.php: 'kalite-final-kontrol' => 'bolumler/kalite/final_kontrol.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul = Auth::kullanici();

// Tablo oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `final_kontrol_listesi` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `paket_no` VARCHAR(100) NOT NULL,
        `stok_kodu` VARCHAR(100) DEFAULT NULL,
        `stok_adi` VARCHAR(255) DEFAULT NULL,
        `miktar` DECIMAL(12,3) DEFAULT NULL,
        `kontrol_sonuc` VARCHAR(20) DEFAULT NULL,
        `kontrol_aciklama` TEXT,
        `kontrol_eden` VARCHAR(100) DEFAULT NULL,
        `kontrol_tarih_saat` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        INDEX (`paket_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

$mes_ok = ($mes_pdo !== null);
?>

<style>
/* Terminal görünüm — mobil öncelikli */
.fk-wrap {
    max-width: 520px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.fk-barkod-alan {
    background: var(--yuzey);
    border: 2px dashed var(--t);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
}
.fk-barkod-input {
    width: 100%;
    padding: 14px 16px;
    font-size: 20px;
    font-weight: 800;
    border: 2px solid var(--t);
    border-radius: 8px;
    text-align: center;
    letter-spacing: .1em;
    outline: none;
    font-family: monospace;
    background: var(--bg);
    color: var(--m);
}
.fk-barkod-input:focus { box-shadow: 0 0 0 3px rgba(249,115,22,.2); }

/* Son kontroller listesi */
.fk-son-list { display: flex; flex-direction: column; gap: 6px; }
.fk-son-item {
    display: flex; align-items: center; gap: 10px;
    background: var(--kenar-a); border-radius: 8px; padding: 8px 12px;
    font-size: 12px;
}
.fk-son-item .paket { font-weight: 800; font-family: monospace; font-size: 13px; flex: 1; }
.fk-son-item .stok  { color: var(--m2); flex: 2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.fk-rozet { padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 800; white-space: nowrap; }
.fk-ok    { background: #D1FAE5; color: #065F46; }
.fk-nok   { background: #FEE2E2; color: #991B1B; }
.fk-zaman { color: var(--m3); font-size: 10px; white-space: nowrap; }

/* Modal */
.fk-modal-bg {
    display: none; position: fixed; inset: 0;
    background: rgba(0,0,0,.55); z-index: 9999;
    align-items: flex-end; justify-content: center;
}
.fk-modal-bg.acik { display: flex; }
.fk-modal {
    background: var(--yuzey); width: 100%; max-width: 520px;
    border-radius: 16px 16px 0 0; padding: 20px 18px 32px;
    animation: slideUp .2s ease;
}
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.fk-modal-baslik { font-size: 16px; font-weight: 800; margin-bottom: 14px; display: flex; align-items: center; gap: 10px; }
.fk-stat { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
.fk-stat-kutu { background: var(--kenar-a); border-radius: 8px; padding: 10px; text-align: center; }
.fk-stat-sayi { font-size: 24px; font-weight: 900; }
.fk-stat-etiket { font-size: 10px; color: var(--m2); font-weight: 700; text-transform: uppercase; margin-top: 2px; }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Final Kontrol Terminal</h1>
    <div class="s-yol">Kalite / <b>Final Kontrol</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-final-liste" class="btn btn-b btn-sm">📋 Liste</a>
  </div>
</div>

<div class="s-body">
<div class="fk-wrap">

  <!-- Bugün istatistik -->
  <?php
  $bugun = ['toplam'=>0,'ok'=>0,'nok'=>0];
  try {
      $st = $db->query("SELECT COUNT(*) t, SUM(kontrol_sonuc='OK') ok, SUM(kontrol_sonuc='NOK') nok
          FROM final_kontrol_listesi WHERE DATE(kontrol_tarih_saat)=CURDATE()");
      $r = $st->fetch(PDO::FETCH_ASSOC);
      $bugun = ['toplam'=>(int)$r['t'],'ok'=>(int)$r['ok'],'nok'=>(int)$r['nok']];
  } catch (Throwable $e) {}
  ?>
  <div class="fk-stat">
    <div class="fk-stat-kutu">
      <div class="fk-stat-sayi" style="color:var(--t)"><?= $bugun['toplam'] ?></div>
      <div class="fk-stat-etiket">Bugün</div>
    </div>
    <div class="fk-stat-kutu">
      <div class="fk-stat-sayi" style="color:#22C55E"><?= $bugun['ok'] ?></div>
      <div class="fk-stat-etiket">OK</div>
    </div>
    <div class="fk-stat-kutu">
      <div class="fk-stat-sayi" style="color:#EF4444"><?= $bugun['nok'] ?></div>
      <div class="fk-stat-etiket">NOK</div>
    </div>
  </div>

  <!-- Barkod okutma alanı -->
  <div class="fk-barkod-alan">
    <div style="font-size:12px;color:var(--m2);margin-bottom:10px;font-weight:700">
      📷 Paket barkodunu okutun veya yazın
    </div>
    <input type="text" id="barkodInput" class="fk-barkod-input"
           placeholder="Paket No..." autocomplete="off" autocorrect="off"
           autocapitalize="off" spellcheck="false" inputmode="text">
    <div style="font-size:11px;color:var(--m3);margin-top:8px">Enter ile onaylayın</div>
  </div>

  <?php if (!$mes_ok): ?>
  <div style="background:var(--uya-a);color:var(--uya);border-radius:var(--r);padding:10px 14px;font-size:12px;font-weight:700">
    ⚠️ MES bağlantısı yok — paket bilgileri manuel girilecek.
  </div>
  <?php endif; ?>

  <!-- Son kontroller -->
  <div>
    <div style="font-size:12px;font-weight:800;color:var(--m2);margin-bottom:8px;text-transform:uppercase;letter-spacing:.05em">
      Son Kontroller
    </div>
    <div class="fk-son-list" id="sonListesi">
      <?php
      try {
          $st = $db->query("SELECT paket_no, stok_kodu, stok_adi, miktar, kontrol_sonuc,
              DATE_FORMAT(kontrol_tarih_saat,'%H:%i') zaman
              FROM final_kontrol_listesi ORDER BY kontrol_tarih_saat DESC LIMIT 10");
          foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r): ?>
      <div class="fk-son-item">
        <span class="paket"><?= htmlspecialchars($r['paket_no']) ?></span>
        <span class="stok"><?= htmlspecialchars($r['stok_kodu'].' '.$r['stok_adi']) ?></span>
        <span class="fk-rozet <?= $r['kontrol_sonuc']==='OK'?'fk-ok':'fk-nok' ?>"><?= $r['kontrol_sonuc'] ?></span>
        <span class="fk-zaman"><?= $r['zaman'] ?></span>
      </div>
          <?php endforeach;
      } catch (Throwable $e) { echo '<div style="color:var(--m3);font-size:12px">Kayıt yok</div>'; } ?>
    </div>
  </div>

</div><!-- /fk-wrap -->
</div><!-- /s-body -->

<!-- MODAL — barkod okutunca açılır -->
<div class="fk-modal-bg" id="fkModal">
  <div class="fk-modal">
    <div class="fk-modal-baslik">
      <span id="modalBaslik">📦 Kontrol Formu</span>
      <button onclick="modalKapat()" style="margin-left:auto;background:var(--kenar-a);border:none;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:16px">✕</button>
    </div>

    <!-- MES uyarısı -->
    <div id="mesUyari" style="display:none;background:#FEF9C3;color:#92400E;border-radius:6px;
         padding:8px 10px;font-size:12px;font-weight:700;margin-bottom:10px"></div>

    <!-- Paket + ürün bilgisi -->
    <div style="background:var(--kenar-a);border-radius:8px;padding:10px 12px;margin-bottom:12px">
      <div style="font-size:11px;color:var(--m2);font-weight:700">PAKET NO</div>
      <div id="mPaketNo" style="font-size:18px;font-weight:900;font-family:monospace;color:var(--t)">—</div>
      <div id="mStokAdi" style="font-size:13px;color:var(--m);margin-top:4px">—</div>
      <div style="display:flex;gap:16px;margin-top:6px">
        <div><span style="font-size:10px;color:var(--m2)">STOK KODU</span><br><b id="mStokKodu" style="font-size:12px">—</b></div>
        <div><span style="font-size:10px;color:var(--m2)">MİKTAR</span><br><b id="mMiktar" style="font-size:12px">—</b></div>
      </div>
    </div>

    <!-- Manuel giriş (MES bulamazsa) -->
    <div id="manuelGirisBlok" style="display:none;margin-bottom:12px">
      <div style="font-size:11px;color:var(--m2);font-weight:700;margin-bottom:6px">BİLGİLERİ MANUEL GİRİN</div>
      <div style="display:flex;gap:8px;margin-bottom:6px">
        <input id="mManuelKod" type="text" class="form-alan" placeholder="Stok Kodu" style="font-size:12px;padding:6px 10px">
        <input id="mManuelMiktar" type="text" class="form-alan" placeholder="Miktar" inputmode="decimal" style="font-size:12px;padding:6px 10px;max-width:100px">
      </div>
      <input id="mManuelAdi" type="text" class="form-alan" placeholder="Stok Adı" style="font-size:12px;padding:6px 10px;width:100%">
    </div>

    <!-- Karar -->
    <div style="margin-bottom:12px">
      <div style="font-size:11px;color:var(--m2);font-weight:700;margin-bottom:6px">KARAR</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <button id="btnOK" onclick="setKarar('OK')"
                style="padding:16px;border-radius:10px;border:2px solid #22C55E;background:#D1FAE5;
                       color:#065F46;font-size:16px;font-weight:800;cursor:pointer">
          ✓ OK
        </button>
        <button id="btnNOK" onclick="setKarar('NOK')"
                style="padding:16px;border-radius:10px;border:2px solid #E2E8F0;background:var(--kenar-a);
                       color:var(--m2);font-size:16px;font-weight:800;cursor:pointer">
          ✗ NOK
        </button>
      </div>
      <input type="hidden" id="mKarar" value="OK">
    </div>

    <!-- Açıklama (opsiyonel) -->
    <div style="margin-bottom:14px">
      <textarea id="mAciklama" rows="2" class="form-alan"
                placeholder="Açıklama (opsiyonel)..." style="font-size:13px;resize:none"></textarea>
    </div>

    <!-- Kaydet -->
    <button id="fkKaydetBtn" onclick="fkKaydet()"
            style="width:100%;padding:16px;border-radius:10px;border:none;
                   background:var(--t);color:#fff;font-size:16px;font-weight:800;cursor:pointer">
      💾 Kaydet
    </button>
  </div>
</div>

<script>
var FK_KARAR = 'OK';
var FK_PAKET = '';
var FK_MES_OK = <?= $mes_ok ? 'true' : 'false' ?>;
var FK_KULLANICI = '<?= htmlspecialchars($kul['ad_soyad'] ?? $kul['email'] ?? 'bilinmiyor', ENT_QUOTES) ?>';
var FK_BASE = '<?= BASE_URL ?>';

// Barkod input — Enter ile tetikle
document.getElementById('barkodInput').addEventListener('keypress', function(e){
    if (e.key !== 'Enter') return;
    e.preventDefault();
    var paket = this.value.trim();
    if (!paket) return;
    FK_PAKET = paket;
    paketSorgu(paket);
});

// Mobil: input value değişince (bazı tarayıcılarda enter yerine change)
document.getElementById('barkodInput').addEventListener('change', function(){
    var paket = this.value.trim();
    if (!paket) return;
    FK_PAKET = paket;
    paketSorgu(paket);
});

function paketSorgu(paket) {
    // Önce duplicate kontrol
    fetch(FK_BASE + '/bolumler/kalite/ajax/final_kontrol_ajax.php?action=kontrol_et&paket=' + encodeURIComponent(paket))
    .then(function(r){ return r.json(); })
    .then(function(d){
        if (!d.ok) { alert(d.hata || 'Hata'); document.getElementById('barkodInput').value=''; return; }
        if (d.zaten_var) {
            alert('⚠️ Bu paket daha önce kontrol edilmiş!\n' + d.mesaj);
            document.getElementById('barkodInput').value='';
            document.getElementById('barkodInput').focus();
            return;
        }
        // Modal doldur
        document.getElementById('mPaketNo').textContent   = paket;
        document.getElementById('mStokKodu').textContent  = d.stok_kodu || '—';
        document.getElementById('mStokAdi').textContent   = d.stok_adi  || (d.uyari || '—');
        document.getElementById('mMiktar').textContent    = d.miktar    || '—';
        // MES uyarısı varsa sarı bilgi kutusu göster
        var uyariEl = document.getElementById('mesUyari');
        var manuelBlok = document.getElementById('manuelGirisBlok');
        if (d.uyari && uyariEl) {
            uyariEl.textContent = '⚠ ' + d.uyari;
            uyariEl.style.display = 'block';
            if (manuelBlok) manuelBlok.style.display = 'block';
        } else {
            if (uyariEl) uyariEl.style.display = 'none';
            if (manuelBlok) manuelBlok.style.display = 'none';
        }
        document.getElementById('mAciklama').value = '';
        setKarar('OK');
        modalAc();
    })
    .catch(function(){ alert('Bağlantı hatası'); });
}

function setKarar(k) {
    FK_KARAR = k;
    document.getElementById('mKarar').value = k;
    var ok  = document.getElementById('btnOK');
    var nok = document.getElementById('btnNOK');
    if (k === 'OK') {
        ok.style.borderColor  = '#22C55E'; ok.style.background  = '#D1FAE5'; ok.style.color  = '#065F46';
        nok.style.borderColor = '#E2E8F0'; nok.style.background = 'var(--kenar-a)'; nok.style.color = 'var(--m2)';
    } else {
        nok.style.borderColor = '#EF4444'; nok.style.background = '#FEE2E2'; nok.style.color = '#991B1B';
        ok.style.borderColor  = '#E2E8F0'; ok.style.background  = 'var(--kenar-a)'; ok.style.color  = 'var(--m2)';
    }
}

function modalAc()  { document.getElementById('fkModal').classList.add('acik'); }
function modalKapat(){ document.getElementById('fkModal').classList.remove('acik'); document.getElementById('barkodInput').value=''; document.getElementById('barkodInput').focus(); }

function fkKaydet() {
    var btn = document.getElementById('fkKaydetBtn');
    btn.disabled = true; btn.textContent = '⏳ Kaydediliyor...';

    var fd = new FormData();
    fd.append('action', 'kaydet');
    fd.append('paket_no',  FK_PAKET);
    // MES'ten geldiyse ID'den al, manuel girildiyse input'tan al
    var sk = document.getElementById('mStokKodu').textContent.replace('—','');
    var sa = document.getElementById('mStokAdi').textContent.replace('—','');
    var mik = document.getElementById('mMiktar').textContent.replace('—','');
    var manuelKod = (document.getElementById('mManuelKod')?.value||'').trim();
    var manuelAdi = (document.getElementById('mManuelAdi')?.value||'').trim();
    var manuelMik = (document.getElementById('mManuelMiktar')?.value||'').trim();
    fd.append('stok_kodu', manuelKod || sk);
    fd.append('stok_adi',  manuelAdi || sa);
    fd.append('miktar',    manuelMik || mik);
    fd.append('karar',     FK_KARAR);
    fd.append('aciklama',  document.getElementById('mAciklama').value);

    fetch(FK_BASE + '/bolumler/kalite/ajax/final_kontrol_ajax.php', {method:'POST', body:fd})
    .then(function(r){ return r.json(); })
    .then(function(d){
        if (d.ok) {
            // Listeye ekle
            var liste = document.getElementById('sonListesi');
            var item = document.createElement('div');
            item.className = 'fk-son-item';
            item.innerHTML =
                '<span class="paket">' + FK_PAKET + '</span>' +
                '<span class="stok">' + d.stok_kodu + ' ' + d.stok_adi + '</span>' +
                '<span class="fk-rozet ' + (FK_KARAR==='OK'?'fk-ok':'fk-nok') + '">' + FK_KARAR + '</span>' +
                '<span class="fk-zaman">' + d.saat + '</span>';
            liste.insertBefore(item, liste.firstChild);
            // İstatistik güncelle
            saydirGuncelle(FK_KARAR);
            modalKapat();
        } else {
            alert('❌ ' + (d.hata || 'Kayıt başarısız'));
        }
        btn.disabled = false; btn.textContent = '💾 Kaydet';
    })
    .catch(function(){
        alert('Bağlantı hatası');
        btn.disabled = false; btn.textContent = '💾 Kaydet';
    });
}

function saydirGuncelle(karar) {
    var kutular = document.querySelectorAll('.fk-stat-sayi');
    kutular[0].textContent = parseInt(kutular[0].textContent||0) + 1;
    if (karar==='OK')  kutular[1].textContent = parseInt(kutular[1].textContent||0) + 1;
    else               kutular[2].textContent = parseInt(kutular[2].textContent||0) + 1;
}

// Modal dışına tıklayınca kapat
document.getElementById('fkModal').addEventListener('click', function(e){
    if (e.target === this) modalKapat();
});

// Sayfa yüklenince input'a focusla
window.addEventListener('load', function(){ document.getElementById('barkodInput').focus(); });
</script>
