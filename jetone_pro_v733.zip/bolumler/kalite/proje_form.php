<?php
/**
 * Proje Oluştur / Düzenle
 * panel.php: 'kalite-proje-form' => 'bolumler/proje/form.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
$p  = ['proje_kodu'=>'','proje_adi'=>'','proje_amaci'=>'','kapsam_icinde'=>'','kapsam_disinda'=>'','basari_kriterleri'=>'','sponsor'=>'','proje_yoneticisi'=>$kul_adi,'onay_makami'=>'','baslangic_tarihi'=>date('Y-m-d'),'hedef_bitis_tarihi'=>'','durum'=>'taslak','oncelik'=>'normal','butce_tahmini'=>'','notlar'=>''];
if ($id) {
    $stmt = $db->prepare("SELECT * FROM prj_proje WHERE id=?"); $stmt->execute([$id]); $p = $stmt->fetch(PDO::FETCH_ASSOC) ?: $p;
}

$mesaj = ''; $mesaj_tip = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kod = trim($_POST['proje_kodu'] ?? '');
    if (!$kod) {
        $yil = date('Y');
        $son = $db->query("SELECT proje_kodu FROM prj_proje WHERE proje_kodu LIKE 'PRJ-{$yil}-%' ORDER BY id DESC LIMIT 1")->fetchColumn();
        $no  = $son ? (int)substr($son,-3)+1 : 1;
        $kod = sprintf('PRJ-%d-%03d', $yil, $no);
    }
    $fields = ['proje_kodu'=>$kod,'proje_adi'=>$_POST['proje_adi'],'proje_amaci'=>$_POST['proje_amaci']??'','kapsam_icinde'=>$_POST['kapsam_icinde']??'','kapsam_disinda'=>$_POST['kapsam_disinda']??'','basari_kriterleri'=>$_POST['basari_kriterleri']??'','sponsor'=>$_POST['sponsor']??'','proje_yoneticisi'=>$_POST['proje_yoneticisi']??'','onay_makami'=>$_POST['onay_makami']??'','baslangic_tarihi'=>$_POST['baslangic_tarihi']??null,'hedef_bitis_tarihi'=>$_POST['hedef_bitis_tarihi']?:null,'durum'=>$_POST['durum'],'oncelik'=>$_POST['oncelik'],'butce_tahmini'=>$_POST['butce_tahmini']?:0,'notlar'=>$_POST['notlar']??''];
    try {
        if ($id) {
            $set = implode(',',array_map(fn($k)=>"$k=?",array_keys($fields)));
            $db->prepare("UPDATE prj_proje SET $set WHERE id=?")->execute([...array_values($fields),$id]);
            $mesaj='Güncellendi.'; $mesaj_tip='ok';
            $stmt2=$db->prepare("SELECT * FROM prj_proje WHERE id=?");$stmt2->execute([$id]);$p=$stmt2->fetch(PDO::FETCH_ASSOC);
        } else {
            $fields['olusturan'] = $kul_adi;
            $cols = implode(',',array_keys($fields));
            $vals = implode(',',array_fill(0,count($fields),'?'));
            $db->prepare("INSERT INTO prj_proje ($cols) VALUES ($vals)")->execute(array_values($fields));
            $id = (int)$db->lastInsertId();
            echo "<script>window.location.href=".json_encode(BASE_URL.'/panel.php?sayfa=kalite-proje-detay&id='.$id).";</script>"; exit;
        }
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?=$id?'✏️ Proje Düzenle':'+ Yeni Proje'?></h1>
    <div class="s-yol">Projeler / <b><?=$id?'Düzenle':'Yeni'?></b></div>
  </div>
  <?php if($id): ?><a href="<?=BASE_URL?>/panel.php?sayfa=kalite-proje-detay&id=<?=$id?>" class="btn btn-b btn-sm">← Detay</a><?php endif; ?>
</div>
<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>
<div style="max-width:820px">
<form method="POST">

<!-- 1. Kimlik -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div style="font-weight:800;font-size:14px;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #2563EB;color:var(--t)">📋 1. Proje Kimliği</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <div><label class="form-et">Proje Kodu <span style="color:var(--m3);font-weight:400">(boş = otomatik)</span></label>
    <input name="proje_kodu" class="form-alan" value="<?=htmlspecialchars($p['proje_kodu'])?>" placeholder="PRJ-2026-001" style="font-family:monospace"></div>
    <div><label class="form-et">Öncelik</label>
    <select name="oncelik" class="form-alan">
      <?php foreach (['dusuk'=>'Düşük','normal'=>'Normal','yuksek'=>'Yüksek','kritik'=>'Kritik'] as $v=>$l): ?>
      <option value="<?=$v?>" <?=$p['oncelik']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?></select></div>
    <div class="col-span-2"><label class="form-et">Proje Adı <span style="color:#EF4444">*</span></label>
    <input name="proje_adi" class="form-alan" required value="<?=htmlspecialchars($p['proje_adi'])?>" style="width:100%;font-size:14px;font-weight:600"></div>
    <div class="col-span-2"><label class="form-et">Proje Amacı <span style="font-size:10px;font-weight:400;color:var(--m2)">Bu proje neden yapılıyor? (1-2 cümle)</span></label>
    <textarea name="proje_amaci" class="form-alan" rows="2" style="width:100%;resize:vertical"><?=htmlspecialchars($p['proje_amaci']??'')?></textarea></div>
  </div>
</div>

<!-- 2. Kapsam -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div style="font-weight:800;font-size:14px;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #6366F1;color:var(--t)">🎯 2. Kapsam ve Başarı Kriterleri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <div><label class="form-et">✅ Kapsam İçinde (Neler yapılacak?)</label>
    <textarea name="kapsam_icinde" class="form-alan" rows="4" style="width:100%;resize:vertical" placeholder="Her satıra bir madde yazın..."><?=htmlspecialchars($p['kapsam_icinde']??'')?></textarea></div>
    <div><label class="form-et">❌ Kapsam Dışında (Neler yapılmayacak?)</label>
    <textarea name="kapsam_disinda" class="form-alan" rows="4" style="width:100%;resize:vertical" placeholder="Her satıra bir madde yazın..."><?=htmlspecialchars($p['kapsam_disinda']??'')?></textarea></div>
    <div class="col-span-2"><label class="form-et">🏆 Başarı Kriterleri <span style="font-size:10px;font-weight:400;color:var(--m2)">Projenin bittiğini nasıl anlayacağız?</span></label>
    <textarea name="basari_kriterleri" class="form-alan" rows="3" style="width:100%;resize:vertical"><?=htmlspecialchars($p['basari_kriterleri']??'')?></textarea></div>
  </div>
</div>

<!-- 3. Takvim + Paydaşlar -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div style="font-weight:800;font-size:14px;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #0EA5E9;color:var(--t)">📅 3. Takvim ve Paydaşlar</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
    <div><label class="form-et">Başlangıç Tarihi</label><input type="date" name="baslangic_tarihi" class="form-alan" value="<?=htmlspecialchars($p['baslangic_tarihi']??'')?>"></div>
    <div><label class="form-et">Hedef Bitiş Tarihi</label><input type="date" name="hedef_bitis_tarihi" class="form-alan" value="<?=htmlspecialchars($p['hedef_bitis_tarihi']??'')?>"></div>
    <div><label class="form-et">Genel Durum</label>
    <select name="durum" class="form-alan">
      <?php foreach (['taslak'=>'Taslak','planlama'=>'Planlama','devam'=>'Devam Ediyor','beklemede'=>'Beklemede','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'] as $v=>$l): ?>
      <option value="<?=$v?>" <?=$p['durum']===$v?'selected':''?>><?=$l?></option><?php endforeach; ?></select></div>
    <div><label class="form-et">Proje Sponsoru</label><input name="sponsor" class="form-alan" value="<?=htmlspecialchars($p['sponsor']??'')?>"></div>
    <div><label class="form-et">Proje Yöneticisi</label><input name="proje_yoneticisi" class="form-alan" value="<?=htmlspecialchars($p['proje_yoneticisi']??'')?>"></div>
    <div><label class="form-et">Onay Makamı</label><input name="onay_makami" class="form-alan" value="<?=htmlspecialchars($p['onay_makami']??'')?>"></div>
  </div>
</div>

<!-- 4. Bütçe -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div style="font-weight:800;font-size:14px;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #16A34A;color:var(--t)">💰 4. Bütçe</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <div><label class="form-et">Tahmini Bütçe (₺)</label><input type="number" name="butce_tahmini" class="form-alan" value="<?=htmlspecialchars($p['butce_tahmini']??0)?>" step="0.01" min="0"></div>
    <div><label class="form-et">Notlar</label><input name="notlar" class="form-alan" value="<?=htmlspecialchars($p['notlar']??'')?>"></div>
  </div>
</div>

<div style="display:flex;gap:8px;justify-content:flex-end">
  <a href="<?=BASE_URL?>/panel.php?sayfa=proje" class="btn btn-b">İptal</a>
  <button type="submit" class="btn btn-t">💾 <?=$id?'Güncelle':'Proje Oluştur'?></button>
</div>
</form>
</div>
</div>
<style>.col-span-2{grid-column:span 2}.col-span-3{grid-column:span 3}</style>
