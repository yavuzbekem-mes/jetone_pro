<?php
/**
 * JETONE.PRO — KYS Doküman Listesi (Pasif)
 * panel.php: 'kalite-dokuman-listesi-pasif' => 'bolumler/kalite/dokuman_listesi_pasif.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_isim = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$turler = ['formlar'=>'FORMLAR','listeler'=>'LİSTELER','sunumlar'=>'SUNUMLAR','planlar'=>'PLANLAR',
    'talimatlar'=>'GENEL TALİMATLAR','mak_talimatlar'=>'MAKİNA TALİMATLARI','semalar'=>'ŞEMALAR',
    'el kitapları'=>'EL KİTAPLARI','sürecler'=>'SÜREÇLER','dkd'=>'DKD','prosedürler'=>'PROSEDÜRLER',
    'tablolar'=>'TABLOLAR','standart'=>'STANDART','raporlar'=>'RAPORLAR','kalibrasyon'=>'KALİBRASYON',
    'atamalar'=>'ATAMA','politikalar'=>'POLİTİKALARIMIZ','taahütname'=>'TAAHÜTNAME'];

// Pasif döküman ekle
if (isset($_POST['dokuman_ekle'])) {
    $tur = trim($_POST['tur'] ?? '');
    $dok_yol = null;
    if (!empty($_FILES['dok_yol']['name']) && $_FILES['dok_yol']['error'] === 0) {
        $dir = dirname(dirname(__DIR__)) . '/kys_dökümanlar/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $fname = rand(10000,99999).rand(10000,99999).preg_replace('/[^a-zA-Z0-9._\-]/','',$_FILES['dok_yol']['name']);
        if (move_uploaded_file($_FILES['dok_yol']['tmp_name'], $dir . $fname)) $dok_yol = 'kys_dökümanlar/' . $fname;
    }
    try {
        $db->prepare("INSERT INTO dokuman_listesi (tür,dok_yol,dok_adi,ref_madde,dok_no,durum,ekleyen) VALUES (?,?,?,?,?,'Pasif',?)")
        ->execute([$tur,$dok_yol,trim($_POST['dok_adi']??''),trim($_POST['ref_madde']??''),trim($_POST['dok_no']??''),$kul_isim]);
    } catch (Throwable $e) {}
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-dokuman-listesi-pasif";</script>'; exit;
}

try {
    $rows = $db->query("SELECT * FROM dokuman_listesi WHERE durum='Pasif' ORDER BY dok_no ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $rows = []; }
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Pasif Dokümanlar</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-listesi" style="color:var(--t)">Doküman Listesi</a> / <b>Pasif</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-listesi" class="btn btn-b btn-sm">← Aktifler</a>
    <button onclick="document.getElementById('dokEkleModal').style.display='flex'" class="btn btn-t btn-sm">+ Pasif Ekle</button>
  </div>
</div>

<div class="s-body">
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <?php $sth = ['#','İşlemler','Durum','Kategori','Doküman No','Doküman Adı','Ref. Madde','Rev. No','Rev. Tarihi','Rev. Eden']; ?>
    <table id="pasifTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php foreach ($rows as $i => $r): ?>
        <tr>
          <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
          <td style="white-space:nowrap">
            <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dokuman-duzenle&id=<?= $r['id'] ?>"
               class="btn btn-sm" style="background:var(--bas-a);color:var(--bas);padding:3px 8px;font-size:11px;text-decoration:none">✏️</a>
            <?php if ($r['dok_yol']): ?>
            <a href="<?= BASE_URL ?>/<?= htmlspecialchars(dirname($r['dok_yol']) . '/' . rawurlencode(basename($r['dok_yol']))) ?>" target="_blank" download
               class="btn btn-sm" style="background:var(--bil-a);color:var(--bil);padding:3px 8px;font-size:11px;text-decoration:none">⬇</a>
            <?php endif; ?>
            <form method="POST" action="<?= BASE_URL ?>/islemler/kalite/dokuman_sil.php" style="display:inline"
                  onsubmit="return confirm('Kaydı silmek istiyor musunuz?')">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <input type="hidden" name="tur" value="<?= htmlspecialchars($r['tür']) ?>">
              <button type="submit" class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
            </form>
          </td>
          <td><span style="background:#FEF9C3;color:#92400E;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">Pasif</span></td>
          <td style="font-size:11px"><?= htmlspecialchars($turler[$r['tür']??'']??$r['tür']??'') ?></td>
          <td style="font-family:monospace;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['dok_no']??'') ?></td>
          <td style="max-width:260px"><?= htmlspecialchars($r['dok_adi']??'') ?></td>
          <td style="font-size:12px"><?= htmlspecialchars($r['ref_madde']??'') ?></td>
          <td style="text-align:center"><?= htmlspecialchars($r['revize_no']??'00') ?></td>
          <td style="white-space:nowrap;font-size:12px"><?= $r['revize_tarih'] ? date('d.m.Y',strtotime($r['revize_tarih'])) : '—' ?></td>
          <td style="font-size:12px"><?= htmlspecialchars($r['revize_eden']??'') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<!-- Modal -->
<div id="dokEkleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:12px;width:95%;max-width:480px;padding:20px;max-height:90vh;overflow-y:auto">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
      <div style="font-size:15px;font-weight:800">📦 Pasif Doküman Ekle</div>
      <button onclick="document.getElementById('dokEkleModal').style.display='none'"
              style="background:var(--kenar-a);border:none;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:16px">✕</button>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="dokuman_ekle" value="1">
      <div class="form-grup">
        <label class="form-et">Tür <span class="zorunlu">*</span></label>
        <select class="form-alan" name="tur" required>
          <?php foreach ($turler as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="form-grup">
        <label class="form-et">Doküman No</label>
        <input class="form-alan" type="text" name="dok_no">
      </div>
      <div class="form-grup">
        <label class="form-et">Ref. Madde</label>
        <input class="form-alan" type="text" name="ref_madde">
      </div>
      <div class="form-grup">
        <label class="form-et">Doküman Adı <span class="zorunlu">*</span></label>
        <textarea class="form-alan" name="dok_adi" rows="2" required></textarea>
      </div>
      <div class="form-grup">
        <label class="form-et">Dosya</label>
        <input class="form-alan" type="file" name="dok_yol" accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg" style="padding:6px">
      </div>
      <div class="form-footer">
        <button type="button" onclick="document.getElementById('dokEkleModal').style.display='none'" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script>
$(document).ready(function(){
  $('#pasifTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true,scrollY:500,scrollCollapse:true,paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'PasifDokuman_<?= date('Ymd') ?>'}],
    drawCallback:function(){ $('#pasifTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){
      this.api().columns([2,3,7]).every(function(){
        var col=this,sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
        col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); });
      });
      $('#pasifTablo thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); });
    }
  });
});
</script>
