<?php
/**
 * JETONE.PRO — Kalite Proses Kontrol Listesi
 * bolumler/kalite/kontrol.php
 * panel.php: 'kalite-kontrol' => 'bolumler/kalite/kontrol.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

// Tarih filtresi
$tarih_b = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['1_tarih'] ?? '') ? $_POST['1_tarih'] : date('Y-m-d', strtotime('-29 days'));
$tarih_e = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['2_tarih'] ?? '') ? $_POST['2_tarih'] : date('Y-m-d');

// Tablo var mı?
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `proses_kontrol` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `urun_kodu` VARCHAR(50) NOT NULL,
        `urun_adi` VARCHAR(200) NOT NULL DEFAULT '',
        `istasyon_kodu` VARCHAR(30) NOT NULL DEFAULT '',
        `vardiya` TINYINT(1) NOT NULL DEFAULT 1,
        `tarih` DATE NOT NULL,
        `gramaj` DECIMAL(10,3) DEFAULT NULL,
        `map_gramaj` DECIMAL(10,3) DEFAULT NULL,
        `gramaj_fark` DECIMAL(10,3) DEFAULT NULL,
        `cevrim` DECIMAL(10,2) DEFAULT NULL,
        `map_cevrim` DECIMAL(10,2) DEFAULT NULL,
        `cevrim_fark` DECIMAL(10,2) DEFAULT NULL,
        `makina_tonaj` DECIMAL(10,2) DEFAULT NULL,
        `map_tonaj` DECIMAL(10,2) DEFAULT NULL,
        `tonaj_fark` DECIMAL(10,2) DEFAULT NULL,
        `cizik_capak` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `kirik_catlak` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `cokuntu` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `hm_lekesi` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `yag_lekesi` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `eksik_enj` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `serpme` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `gazlanma` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `yanma` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `tirnak_pim` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `harelenme` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `sonuc` VARCHAR(5) NOT NULL DEFAULT 'ok',
        `aciklama` TEXT,
        `ekleyen` VARCHAR(100) NOT NULL DEFAULT '',
        `kayit_zaman` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_tarih` (`tarih`),
        KEY `idx_urun` (`urun_kodu`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}
?>

<!-- ── Başlık ─────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">✅ Proses Kontrol</h1>
    <div class="s-yol">Kalite / <b>Proses Kontrol Listesi</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-proses-ekle" class="btn btn-t btn-sm">+ Yeni Kontrol</a>
  </div>
</div>

<div class="s-body">

<!-- ── Tarih filtresi ─────────────────────────────────────────────────── -->
<div class="kart" style="margin-bottom:16px;padding:14px">
  <form method="POST" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="1_tarih" value="<?= $tarih_b ?>">
    </div>
    <div class="form-grup" style="margin:0;min-width:150px">
      <label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="2_tarih" value="<?= $tarih_e ?>">
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Listele</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-kontrol" class="btn btn-b btn-sm">Sıfırla</a>
  </form>
</div>

<!-- ── Tablo ──────────────────────────────────────────────────────────── -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <table id="prosesListeTablo" class="tablo" style="width:100%">
<?php
$sth = ['No','İşlemler','Durum','Ürün Kodu','Ürün Adı','Vrd.','Tarih',
        'GR','Map GR','GR Fark',
        'SN','Map SN','SN Fark',
        'Mak.Ton','Map Ton','Ton Fark',
        'Açıklama','Kaydeden'];
?>
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px;background:#1E3A5F!important"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px;background:#1E3A5F!important"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody id="prosesListeBody">
        <tr><td colspan="18" style="text-align:center;padding:40px;color:var(--m2)">Yükleniyor…</td></tr>
      </tbody>
    </table>
  </div>
</div>

</div><!-- /s-body -->

<script>
$(document).ready(function(){

  var tablo = $('#prosesListeTablo').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: '<?= BASE_URL ?>/bolumler/kalite/ajax/proses_kontrol_api.php',
      type: 'POST',
      data: function(d){
        d['1_tarih'] = '<?= $tarih_b ?>';
        d['2_tarih'] = '<?= $tarih_e ?>';
      }
    },
    columns: [
      {data:0, orderable:false},
      {data:1, orderable:false},
      {data:2, orderable:false},
      {data:3},
      {data:4},
      {data:5, orderable:false},
      {data:6},
      {data:7,  orderable:false},
      {data:8,  orderable:false},
      {data:9,  orderable:false},
      {data:10, orderable:false},
      {data:11, orderable:false},
      {data:12, orderable:false},
      {data:13, orderable:false},
      {data:14, orderable:false},
      {data:15, orderable:false},
      {data:16},
      {data:17}
    ],
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollX: true,
    scrollY: 480,
    scrollCollapse: true,
    paging: true,
    lengthMenu: [[10,25,50,-1],[10,25,50,'Tümü']],
    dom: 'Blfrtip',
    buttons: [
      {extend:'excelHtml5', text:'📊 Excel', filename:'ProsesKontrol_<?= date('Ymd') ?>'},
      {extend:'print',      text:'🖨 Yazdır'}
    ],
    drawCallback: function(){
      $('#prosesListeTablo thead th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#ffffff','important');
        this.style.setProperty('border-color','#2d5986','important');
      });
    },
    initComplete: function(){
      $('#prosesListeTablo thead th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#ffffff','important');
        this.style.setProperty('border-color','#2d5986','important');
      });
    }
  });

  // Tarih filtresi form — DataTable yenile
  $('form').on('submit', function(e){
    e.preventDefault();
    tablo.ajax.settings().data = function(d){
      d['1_tarih'] = $('input[name="1_tarih"]').val();
      d['2_tarih'] = $('input[name="2_tarih"]').val();
    };
    tablo.ajax.reload();
  });
});
</script>
<style>
/* Proses Kontrol — thead tam override */
#prosesListeTablo thead th,
#prosesListeTablo thead th.sorting,
#prosesListeTablo thead th.sorting_asc,
#prosesListeTablo thead th.sorting_desc,
#prosesListeTablo thead th.sorting_disabled,
table#prosesListeTablo thead > tr > th {
  background-color: #1E3A5F !important;
  color: #fff !important;
  border-color: #2d5986 !important;
}
/* DataTables sorting ok rengi de beyaz olsun */
#prosesListeTablo thead th.sorting:before,
#prosesListeTablo thead th.sorting:after,
#prosesListeTablo thead th.sorting_asc:before,
#prosesListeTablo thead th.sorting_asc:after,
#prosesListeTablo thead th.sorting_desc:before,
#prosesListeTablo thead th.sorting_desc:after {
  color: rgba(255,255,255,.6) !important;
}
#prosesListeTablo tfoot th {
  background-color: #1E3A5F !important;
  color: #fff !important;
  border-color: #2d5986 !important;
}
/* Grid border */
#prosesListeTablo th,
#prosesListeTablo td {
  border: 1px solid #94A3B8 !important;
}
</style>
