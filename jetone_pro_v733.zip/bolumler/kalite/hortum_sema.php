<?php
/**
 * JETONE.PRO — Hortum Test Sistemi İş Akışı Şeması
 * panel.php: 'kalite-hortum-sema' => 'bolumler/kalite/hortum_sema.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📐 Hortum Test — İş Akışı Şeması</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" style="color:var(--t)">Hortum Test</a> / <b>Şema</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test"    class="btn btn-b btn-sm">🧪 Test</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-ayarlar" class="btn btn-b btn-sm">⚙️ Ayarlar</a>
  </div>
</div>

<div class="s-body">

<!-- Sekme navigasyonu -->
<?php
$tabs = [
  ['id'=>'akis',   'icon'=>'🔄', 'label'=>'Test İş Akışı'],
  ['id'=>'moxa',   'icon'=>'📡', 'label'=>'MOXA Pin Haritası'],
  ['id'=>'ag',     'icon'=>'🌐', 'label'=>'Ağ Mimarisi'],
  ['id'=>'durum',  'icon'=>'🚦', 'label'=>'Durum Makinesi'],
];
?>
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:20px;flex-wrap:wrap">
  <?php foreach ($tabs as $i => $t): ?>
  <button onclick="tabGoster('<?= $t['id'] ?>')" id="tab_<?= $t['id'] ?>"
          style="padding:8px 16px;border:none;
                 background:<?= $i===0?'var(--t)':'var(--kenar-a)' ?>;
                 color:<?= $i===0?'#fff':'var(--m)' ?>;
                 border-radius:6px 6px 0 0;font-size:13px;font-weight:700;
                 cursor:pointer;margin-bottom:-2px">
    <?= $t['icon'] ?> <?= $t['label'] ?>
  </button>
  <?php endforeach; ?>
</div>

<!-- ══ TEST İŞ AKIŞI ══════════════════════════════════════ -->
<div id="sema_akis">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:6px;color:var(--t)">Tank Kapak Vakum Test — Otomatik İş Akışı</h3>
  <p style="font-size:12px;color:var(--m2);margin-bottom:16px">Start butonuna basıldığında veya DI03 tetiklendiğinde aşağıdaki sekans otomatik çalışır.</p>

  <div style="overflow-x:auto">
  <svg viewBox="0 0 900 980" style="width:100%;min-width:600px;display:block;font-family:sans-serif">
  <defs>
    <marker id="ar" viewBox="0 0 8 8" refX="6" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M1 1l6 3-6 3" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </marker>
  </defs>

  <!-- ── AŞAMA BLOKLARI ── -->
  <?php
  $steps = [
    // [x, y, w, h, bg, border, title, sub, pin, pin_renk]
    [300, 20,  300, 56, '#F0FDF4','#22C55E','BEKLEMEDE','Hortum bağlanmasını ve Start beklenir','DI02=0 → Hortum Yok','#94A3B8'],
    [300,110,  300, 56, '#EFF6FF','#2563EB','① Hortum Kontrol','DI02 sensörü okur — hortum takılı mı?','DI02 → Sensör','#2563EB'],
    [300,200,  300, 56, '#FFF7ED','#D97706','② Piston Kilitle','Coil 2 (D12) = ON → Piston aşağı iner','DO: Coil2=1','#D97706'],
    [300,290,  300, 56, '#F5F3FF','#7C3AED','③ Vakum Başlat','Coil 0 (D10) = ON → Kompresör çalışır','DO: Coil0=1','#7C3AED'],
    [300,380,  300, 56, '#FFF7ED','#D97706','④ Vakum Süresi Bekle','5 saniye boyunca vakum oluşturulur','Timer: 5000ms','#D97706'],
    [300,470,  300, 56, '#F5F3FF','#7C3AED','⑤ Kompresör Kapat','Coil 0 = OFF, Coil 1 = OFF → Sistem kapalı','DO: Coil0=0, Coil1=0','#7C3AED'],
    [300,560,  300, 56, '#EFF6FF','#2563EB','⑥ Basınç İzle','10×500ms boyunca DI00 izlenir','DI00 → Basınç Düşük','#2563EB'],
    [300,670,  300, 56, '#F0FDF4','#22C55E','✅ GEÇTİ','Vakum korundu — sızıntı yok','DB: sonuc=GECTI','#22C55E'],
    [300,760,  300, 56, '#FEF2F2','#EF4444','❌ KALDI','Basınç düştü — sızıntı var','DB: sonuc=KALDI','#EF4444'],
    [300,870,  300, 56, '#F0FDF4','#059669','⑧ Sistemi Sıfırla','Piston aç, Valf tahliye, beklemeye dön','DO: Coil2=0, Coil1=1→0','#059669'],
  ];

  $arrow_ys = [76, 166, 256, 346, 436, 526, 616];
  foreach ($steps as $i => $s):
    [$x,$y,$w,$h,$bg,$border,$title,$sub,$pin,$pinc] = $s;
  ?>
  <rect x="<?=$x?>" y="<?=$y?>" width="<?=$w?>" height="<?=$h?>" rx="10"
        fill="<?=$bg?>" stroke="<?=$border?>" stroke-width="2"/>
  <text x="<?=$x+$w/2?>" y="<?=$y+20?>" text-anchor="middle" font-size="13" font-weight="800" fill="<?=$border?>"><?=$title?></text>
  <text x="<?=$x+$w/2?>" y="<?=$y+36?>" text-anchor="middle" font-size="10" fill="#475569"><?=$sub?></text>
  <!-- Pin badge -->
  <rect x="<?=$x+$w-100?>" y="<?=$y+$h-18?>" width="96" height="14" rx="7" fill="<?=$pinc?>22"/>
  <text x="<?=$x+$w-52?>" y="<?=$y+$h-8?>" text-anchor="middle" font-size="9" font-weight="700" fill="<?=$pinc?>"><?=$pin?></text>
  <?php endforeach; ?>

  <!-- Dikey oklar -->
  <?php foreach ([76,166,256,346,436,526] as $ay): ?>
  <line x1="450" y1="<?=$ay?>" x2="450" y2="<?=$ay+34?>" stroke="#64748B" stroke-width="1.5" marker-end="url(#ar)"/>
  <?php endforeach; ?>

  <!-- DI02=0 → Hata yolu -->
  <path d="M300 137 L200 137 L200 92 L300 92" fill="none" stroke="#EF4444" stroke-width="1.5" stroke-dasharray="5 3" marker-end="url(#ar)"/>
  <rect x="60" y="118" width="130" height="32" rx="8" fill="#FEF2F2" stroke="#EF4444" stroke-width="1"/>
  <text x="125" y="132" text-anchor="middle" font-size="10" font-weight="700" fill="#7F1D1D">DI02 = 0</text>
  <text x="125" y="145" text-anchor="middle" font-size="9" fill="#EF4444">Hortum takılı değil!</text>

  <!-- ⑥ basınç izle sonrası dal -->
  <line x1="450" y1="616" x2="450" y2="650" stroke="#64748B" stroke-width="1.5" marker-end="url(#ar)"/>
  <!-- Karar kutusu -->
  <polygon points="450,650 530,666 450,682 370,666" fill="#E0E7FF" stroke="#4F46E5" stroke-width="1.5"/>
  <text x="450" y="669" text-anchor="middle" font-size="11" font-weight="700" fill="#3730A3">DI00 = 0?</text>

  <!-- EVET → GEÇTİ -->
  <line x1="450" y1="682" x2="450" y2="670" stroke="#64748B" stroke-width="0"/>
  <line x1="450" y1="682" x2="450" y2="670" stroke="none"/>
  <path d="M530 666 L680 666 L680 697" fill="none" stroke="#22C55E" stroke-width="2" marker-end="url(#ar)"/>
  <text x="610" y="660" text-anchor="middle" font-size="10" font-weight="700" fill="#22C55E">EVET (Vakum Korundu)</text>
  <rect x="620" y="697" width="200" height="48" rx="10" fill="#D1FAE5" stroke="#22C55E" stroke-width="2"/>
  <text x="720" y="715" text-anchor="middle" font-size="13" font-weight="800" fill="#065F46">✅ GEÇTİ</text>
  <text x="720" y="732" text-anchor="middle" font-size="10" fill="#059669">Sızıntı yok — Ürün KABUL</text>

  <!-- HAYIR → KALDI -->
  <path d="M370 666 L200 666 L200 713" fill="none" stroke="#EF4444" stroke-width="2" marker-end="url(#ar)"/>
  <text x="282" y="660" text-anchor="middle" font-size="10" font-weight="700" fill="#EF4444">HAYIR (Basınç Düştü)</text>
  <rect x="100" y="713" width="200" height="48" rx="10" fill="#FEE2E2" stroke="#EF4444" stroke-width="2"/>
  <text x="200" y="731" text-anchor="middle" font-size="13" font-weight="800" fill="#7F1D1D">❌ KALDI</text>
  <text x="200" y="748" text-anchor="middle" font-size="10" fill="#DC2626">Sızıntı var — Ürün RET</text>

  <!-- Her iki dal → Sıfırla -->
  <path d="M720 745 L720 900 L600 900" fill="none" stroke="#059669" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#ar)"/>
  <path d="M200 761 L200 900 L300 900" fill="none" stroke="#EF4444" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#ar)"/>

  <!-- Sıfırla → Bekleme -->
  <path d="M450 926 L450 960 L820 960 L820 48 L600 48" fill="none" stroke="#94A3B8" stroke-width="1" stroke-dasharray="5 3" marker-end="url(#ar)"/>
  <text x="700" y="955" text-anchor="middle" font-size="9" fill="#94A3B8">beklemeye dön</text>

  <!-- DB kayıt notu -->
  <rect x="640" y="800" width="200" height="36" rx="6" fill="var(--kenar-a,#F8FAFC)" stroke="#CBD5E1" stroke-width="1"/>
  <text x="740" y="814" text-anchor="middle" font-size="10" font-weight="700" fill="#475569">💾 DB Kaydı</text>
  <text x="740" y="828" text-anchor="middle" font-size="9" fill="#64748B">tank_kapak_test tablosu</text>

  </svg>
  </div>
</div>
</div>

<!-- ══ MOXA PIN HARİTASI ══════════════════════════════════ -->
<div id="sema_moxa" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">MOXA E1212 Pin Haritası — Modbus TCP</h3>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px" class="pin-grid">

    <!-- ÇIKIŞLAR -->
    <div>
      <div style="font-size:12px;font-weight:800;color:var(--m2);text-transform:uppercase;
                  letter-spacing:.05em;margin-bottom:12px;border-bottom:2px solid #7C3AED;padding-bottom:4px">
        ÇIKIŞLAR (DO) — Modbus Coil Write (FC05)
      </div>
      <?php foreach ([
        ['D10','Coil 0','Vakum Kompresör Röle','ON = Kompresör çalışır, vakum oluşur','#7C3AED'],
        ['D11','Coil 1','Hava Valfi Röle','ON = Valf açılır, basınç tahliye edilir','#2563EB'],
        ['D12','Coil 2','Piston Röle','ON = Piston iner, ürün kilitlenir','#D97706'],
        ['D13','Coil 3','Yedek Röle','Kullanımda değil','#94A3B8'],
      ] as $p): ?>
      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding:10px;
                  background:var(--kenar-a);border-radius:8px;border-left:4px solid <?= $p[4] ?>">
        <div style="text-align:center;min-width:50px">
          <code style="background:<?= $p[4] ?>;color:#fff;padding:2px 8px;border-radius:4px;
                       font-weight:800;font-size:12px;display:block"><?= $p[0] ?></code>
          <span style="font-size:10px;color:var(--m3)"><?= $p[1] ?></span>
        </div>
        <div>
          <div style="font-weight:700;font-size:13px;color:var(--t)"><?= $p[2] ?></div>
          <div style="font-size:11px;color:var(--m2);margin-top:2px"><?= $p[3] ?></div>
        </div>
      </div>
      <?php endforeach; ?>

      <div style="background:#F5F3FF;border-radius:8px;padding:10px;font-size:11px;color:#5B21B6;margin-top:4px">
        <strong>Modbus Yazma:</strong> Function Code 05 (Write Single Coil)<br>
        Adres: 0=D10, 1=D11, 2=D12, 3=D13<br>
        Değer: 0xFF00 = ON, 0x0000 = OFF
      </div>
    </div>

    <!-- GİRİŞLER -->
    <div>
      <div style="font-size:12px;font-weight:800;color:var(--m2);text-transform:uppercase;
                  letter-spacing:.05em;margin-bottom:12px;border-bottom:2px solid #0F766E;padding-bottom:4px">
        GİRİŞLER (DI) — Modbus Read Discrete Input (FC02)
      </div>
      <?php foreach ([
        ['DI00','Input 0','Basınç Düşük Sensörü','1 = Basınç düştü → sızıntı tespit edildi','#EF4444'],
        ['DI01','Input 1','Basınç Yüksek Sensörü','1 = Basınç hedef seviyede','#22C55E'],
        ['DI02','Input 2','Ürün/Hortum Sensörü','1 = Hortum bağlı/ürün mevcut','#0F766E'],
        ['DI03','Input 3','START Butonu','1 = Testi başlat (Rising Edge)','#2563EB'],
        ['DI04','Input 4','STOP Butonu','1 = Testi durdur (Acil)','#DC2626'],
        ['DI05','Input 5','Yedek','Kullanımda değil','#94A3B8'],
        ['DI06','Input 6','Yedek','Kullanımda değil','#94A3B8'],
        ['DI07','Input 7','Yedek','Kullanımda değil','#94A3B8'],
      ] as $p): ?>
      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:8px 10px;
                  background:var(--kenar-a);border-radius:8px;border-left:4px solid <?= $p[4] ?>">
        <div style="text-align:center;min-width:50px">
          <code style="background:<?= $p[4] ?>;color:#fff;padding:2px 6px;border-radius:4px;
                       font-weight:800;font-size:11px;display:block"><?= $p[0] ?></code>
          <span style="font-size:9px;color:var(--m3)"><?= $p[1] ?></span>
        </div>
        <div>
          <div style="font-weight:700;font-size:12px;color:var(--t)"><?= $p[2] ?></div>
          <div style="font-size:11px;color:var(--m2);margin-top:1px"><?= $p[3] ?></div>
        </div>
      </div>
      <?php endforeach; ?>

      <div style="background:#F0FDFA;border-radius:8px;padding:10px;font-size:11px;color:#134E4A;margin-top:4px">
        <strong>Modbus Okuma:</strong> Function Code 02 (Read Discrete Inputs)<br>
        Adres: 0=DI00 … 7=DI07 — Her 300ms'de otomatik polling<br>
        Değer: 1 = Aktif (24V), 0 = Pasif (0V)
      </div>
    </div>

  </div>

  <!-- MOXA Bağlantı Bilgisi -->
  <div style="margin-top:16px;background:#EFF6FF;border-radius:10px;padding:14px;border:1px solid #BFDBFE">
    <div style="font-weight:800;color:#1D4ED8;margin-bottom:8px;font-size:13px">📡 MOXA E1212 Bağlantı</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;font-size:12px">
      <?php foreach ([
        ['IP Adresi','192.168.127.254 (varsayılan)'],
        ['Modbus Port','502 (TCP)'],
        ['Unit ID','1'],
        ['Protokol','Modbus TCP/IP'],
        ['Polling','300ms'],
        ['Besleme','24V DC'],
      ] as $b): ?>
      <div style="background:#fff;border-radius:6px;padding:8px 10px">
        <div style="font-size:10px;color:var(--m2)"><?= $b[0] ?></div>
        <div style="font-weight:700;color:var(--t);font-family:monospace"><?= $b[1] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</div>

<!-- ══ AĞ MİMARİSİ ════════════════════════════════════════ -->
<div id="sema_ag" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">🌐 Sistem Ağ Mimarisi</h3>
  <div style="overflow-x:auto">
  <svg viewBox="0 0 860 500" style="width:100%;min-width:600px;display:block;font-family:sans-serif">
  <defs>
    <marker id="ar2" viewBox="0 0 8 8" refX="6" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M1 1l6 3-6 3" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round"/>
    </marker>
  </defs>

  <!-- Tarayıcı -->
  <rect x="20"  y="180" width="140" height="80" rx="10" fill="#EFF6FF" stroke="#2563EB" stroke-width="2"/>
  <text x="90"  y="205" text-anchor="middle" font-size="13" font-weight="800" fill="#1D4ED8">🖥️ Tarayıcı</text>
  <text x="90"  y="220" text-anchor="middle" font-size="10" fill="#3B82F6">PHP Sayfası</text>
  <text x="90"  y="235" text-anchor="middle" font-size="10" fill="#3B82F6">Hortum Test UI</text>
  <text x="90"  y="250" text-anchor="middle" font-size="9"  fill="#93C5FD">JavaScript / WebSocket</text>

  <!-- Laragon (PHP) -->
  <rect x="200" y="80"  width="160" height="80" rx="10" fill="#F0FDF4" stroke="#22C55E" stroke-width="2"/>
  <text x="280" y="108" text-anchor="middle" font-size="13" font-weight="800" fill="#065F46">🟢 Laragon</text>
  <text x="280" y="123" text-anchor="middle" font-size="10" fill="#059669">PHP 8 + MySQL</text>
  <text x="280" y="138" text-anchor="middle" font-size="10" fill="#059669">jetone_pro ERP</text>
  <text x="280" y="153" text-anchor="middle" font-size="9"  fill="#6EE7B7">192.168.1.144:4459</text>

  <!-- Node.js -->
  <rect x="200" y="280" width="160" height="80" rx="10" fill="#FFFBEB" stroke="#D97706" stroke-width="2"/>
  <text x="280" y="308" text-anchor="middle" font-size="13" font-weight="800" fill="#92400E">⚡ Node.js</text>
  <text x="280" y="323" text-anchor="middle" font-size="10" fill="#D97706">moxa_server.js</text>
  <text x="280" y="338" text-anchor="middle" font-size="10" fill="#D97706">WebSocket :5050</text>
  <text x="280" y="353" text-anchor="middle" font-size="9"  fill="#FCD34D">Modbus TCP Client</text>

  <!-- MOXA -->
  <rect x="520" y="180" width="160" height="80" rx="10" fill="#F5F3FF" stroke="#7C3AED" stroke-width="2"/>
  <text x="600" y="208" text-anchor="middle" font-size="13" font-weight="800" fill="#5B21B6">📡 MOXA E1212</text>
  <text x="600" y="223" text-anchor="middle" font-size="10" fill="#7C3AED">Modbus TCP Server</text>
  <text x="600" y="238" text-anchor="middle" font-size="10" fill="#7C3AED">192.168.127.254:502</text>
  <text x="600" y="253" text-anchor="middle" font-size="9"  fill="#C4B5FD">8×DI + 8×DO (24V)</text>

  <!-- Fiziksel Cihazlar -->
  <rect x="700" y="60"  width="140" height="56" rx="8" fill="#FEF2F2" stroke="#DC2626" stroke-width="1.5"/>
  <text x="770" y="82"  text-anchor="middle" font-size="11" font-weight="700" fill="#7F1D1D">⚙️ Vakum Komp.</text>
  <text x="770" y="98"  text-anchor="middle" font-size="9"  fill="#DC2626">D10 (Coil0)</text>

  <rect x="700" y="135" width="140" height="56" rx="8" fill="#EFF6FF" stroke="#2563EB" stroke-width="1.5"/>
  <text x="770" y="157" text-anchor="middle" font-size="11" font-weight="700" fill="#1D4ED8">🔩 Hava Valfi</text>
  <text x="770" y="173" text-anchor="middle" font-size="9"  fill="#2563EB">D11 (Coil1)</text>

  <rect x="700" y="210" width="140" height="56" rx="8" fill="#FFFBEB" stroke="#D97706" stroke-width="1.5"/>
  <text x="770" y="232" text-anchor="middle" font-size="11" font-weight="700" fill="#92400E">⬆️ Piston</text>
  <text x="770" y="248" text-anchor="middle" font-size="9"  fill="#D97706">D12 (Coil2)</text>

  <rect x="700" y="310" width="140" height="56" rx="8" fill="#F0FDFA" stroke="#0F766E" stroke-width="1.5"/>
  <text x="770" y="332" text-anchor="middle" font-size="11" font-weight="700" fill="#134E4A">📊 Basınç Ölçer</text>
  <text x="770" y="348" text-anchor="middle" font-size="9"  fill="#0F766E">DI00/DI01</text>

  <rect x="700" y="385" width="140" height="56" rx="8" fill="#F0FDFA" stroke="#0F766E" stroke-width="1.5"/>
  <text x="770" y="407" text-anchor="middle" font-size="11" font-weight="700" fill="#134E4A">🔗 Ürün Sensörü</text>
  <text x="770" y="423" text-anchor="middle" font-size="9"  fill="#0F766E">DI02</text>

  <rect x="700" y="455" width="140" height="40" rx="8" fill="#EFF6FF" stroke="#2563EB" stroke-width="1.5"/>
  <text x="770" y="474" text-anchor="middle" font-size="11" font-weight="700" fill="#1D4ED8">🔘 Start/Stop</text>
  <text x="770" y="488" text-anchor="middle" font-size="9"  fill="#2563EB">DI03/DI04</text>

  <!-- OK'lar -->
  <!-- Tarayıcı ↔ PHP (HTTP) -->
  <line x1="160" y1="210" x2="200" y2="150" stroke="#22C55E" stroke-width="2" marker-end="url(#ar2)"/>
  <line x1="200" y1="140" x2="165" y2="200" stroke="#22C55E" stroke-width="2" marker-end="url(#ar2)"/>
  <text x="172" y="178" text-anchor="middle" font-size="9" fill="#22C55E" transform="rotate(-30 172 178)">HTTP</text>

  <!-- Tarayıcı ↔ Node.js (WS) -->
  <line x1="155" y1="230" x2="200" y2="300" stroke="#D97706" stroke-width="2" marker-end="url(#ar2)"/>
  <line x1="200" y1="290" x2="158" y2="238" stroke="#D97706" stroke-width="2" marker-end="url(#ar2)"/>
  <text x="168" y="265" text-anchor="middle" font-size="9" fill="#D97706" transform="rotate(30 168 265)">WebSocket</text>

  <!-- PHP ↔ MySQL -->
  <rect x="200" y="410" width="160" height="50" rx="8" fill="#E0E7FF" stroke="#6366F1" stroke-width="1.5"/>
  <text x="280" y="432" text-anchor="middle" font-size="11" font-weight="700" fill="#3730A3">🗄️ MySQL</text>
  <text x="280" y="448" text-anchor="middle" font-size="9"  fill="#6366F1">tank_kapak_test</text>
  <line x1="280" y1="360" x2="280" y2="410" stroke="#6366F1" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#ar2)"/>
  <text x="295" y="388" font-size="9" fill="#6366F1">SQL</text>

  <!-- PHP → Node.js (exec başlat) -->
  <line x1="280" y1="160" x2="280" y2="280" stroke="#059669" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#ar2)"/>
  <text x="295" y="225" font-size="9" fill="#059669">exec()</text>
  <text x="295" y="238" font-size="9" fill="#059669">başlat</text>

  <!-- Node.js ↔ MOXA (Modbus TCP) -->
  <line x1="360" y1="320" x2="520" y2="240" stroke="#7C3AED" stroke-width="2" marker-end="url(#ar2)"/>
  <line x1="520" y1="250" x2="362" y2="330" stroke="#7C3AED" stroke-width="2" marker-end="url(#ar2)"/>
  <text x="445" y="282" text-anchor="middle" font-size="9" fill="#7C3AED">Modbus TCP</text>
  <text x="445" y="295" text-anchor="middle" font-size="9" fill="#7C3AED">:502</text>

  <!-- MOXA → Fiziksel -->
  <line x1="680" y1="200" x2="700" y2="195" stroke="#DC2626" stroke-width="1.5" marker-end="url(#ar2)"/>
  <line x1="680" y1="205" x2="700" y2="210" stroke="#2563EB" stroke-width="1.5" marker-end="url(#ar2)"/>
  <line x1="680" y1="215" x2="700" y2="235" stroke="#D97706" stroke-width="1.5" marker-end="url(#ar2)"/>
  <line x1="680" y1="235" x2="700" y2="335" stroke="#0F766E" stroke-width="1.5" marker-end="url(#ar2)"/>
  <line x1="680" y1="240" x2="700" y2="410" stroke="#0F766E" stroke-width="1.5" marker-end="url(#ar2)"/>
  <line x1="680" y1="245" x2="700" y2="470" stroke="#2563EB" stroke-width="1.5" marker-end="url(#ar2)"/>

  <!-- Legend -->
  <rect x="20" y="380" width="160" height="100" rx="8" fill="var(--kenar-a,#F8FAFC)" stroke="#E2E8F0"/>
  <text x="30" y="398" font-size="10" font-weight="700" fill="var(--t,#1E293B)">AÇIKLAMA</text>
  <line x1="30" y1="410" x2="65" y2="410" stroke="#22C55E" stroke-width="2"/>
  <text x="70" y="414" font-size="9" fill="#374151">HTTP (PHP)</text>
  <line x1="30" y1="425" x2="65" y2="425" stroke="#D97706" stroke-width="2"/>
  <text x="70" y="429" font-size="9" fill="#374151">WebSocket</text>
  <line x1="30" y1="440" x2="65" y2="440" stroke="#7C3AED" stroke-width="2"/>
  <text x="70" y="444" font-size="9" fill="#374151">Modbus TCP</text>
  <line x1="30" y1="455" x2="65" y2="455" stroke="#059669" stroke-width="1.5" stroke-dasharray="4 2"/>
  <text x="70" y="459" font-size="9" fill="#374151">exec() / process</text>
  <line x1="30" y1="470" x2="65" y2="470" stroke="#6366F1" stroke-width="1.5" stroke-dasharray="4 2"/>
  <text x="70" y="474" font-size="9" fill="#374151">SQL (MySQL)</text>

  </svg>
  </div>
</div>
</div>

<!-- ══ DURUM MAKİNESİ ══════════════════════════════════════ -->
<div id="sema_durum" style="display:none">
<div class="kart" style="padding:20px">
  <h3 style="font-size:14px;font-weight:800;margin-bottom:16px;color:var(--t)">🚦 Test Durum Makinesi (State Machine)</h3>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;margin-bottom:20px">
    <?php
    $durumlar = [
      ['BEKLEMEDE',   '#94A3B8','#F1F5F9', 'Sistem hazır, hortum bekleniyor.',
       ['DI02=1 → BASLATIYOR','DI03=1 (Start butonu) → BASLATIYOR']],
      ['BASLATIYOR',  '#D97706','#FFFBEB', 'Hortum kontrolü yapılıyor.',
       ['DI02=0 → HATA (Hortum yok)','DI02=1 → VAKUM']],
      ['VAKUM',       '#7C3AED','#F5F3FF', 'Coil0=1 (Kompresör), Coil2=1 (Piston). 5sn bekle.',
       ['5sn sonra → TEST','DI04=1 → HATA (Stop)']],
      ['TEST',        '#2563EB','#EFF6FF', 'Coil0=0, Coil1=0. 10×500ms DI00 izle.',
       ['DI00=0 (tüm ölçüm) → TAMAMLANDI/GECTİ','DI00=1 → TAMAMLANDI/KALDI','DI04=1 → HATA']],
      ['TAMAMLANDI',  '#22C55E','#F0FDF4', 'Sonuç DB\'ye yazıldı. Sistem sıfırlanıyor.',
       ['→ BEKLEMEDE (otomatik)']],
      ['HATA',        '#EF4444','#FEF2F2', 'Tüm çıkışlar kapatıldı. Hata mesajı gösterildi.',
       ['→ BEKLEMEDE (Reset sonrası)']],
    ];
    foreach ($durumlar as $d):
      [$ad, $renk, $bg, $acik, $gecisler] = $d;
    ?>
    <div style="background:<?= $bg ?>;border-radius:10px;padding:14px;border:2px solid <?= $renk ?>">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="width:12px;height:12px;border-radius:50%;background:<?= $renk ?>;flex-shrink:0"></div>
        <span style="font-weight:800;font-size:13px;color:<?= $renk ?>"><?= $ad ?></span>
      </div>
      <div style="font-size:11px;color:#475569;margin-bottom:8px"><?= $acik ?></div>
      <div style="font-size:10px;font-weight:700;color:var(--m2);margin-bottom:4px;text-transform:uppercase">Geçişler:</div>
      <?php foreach ($gecisler as $g): ?>
      <div style="font-size:11px;color:var(--m2);padding:2px 0;border-left:2px solid <?= $renk ?>;padding-left:6px;margin-bottom:2px">
        <?= $g ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Zamanlama tablosu -->
  <div style="background:var(--kenar-a);border-radius:10px;padding:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:10px;color:var(--t)">⏱️ Zamanlama</div>
    <table class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F">
          <th style="color:#fff">Parametre</th>
          <th style="color:#fff">Değer</th>
          <th style="color:#fff">Açıklama</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ([
          ['Polling Süresi','300ms','DI/DO durumu her 300ms güncellenir'],
          ['Vakum Süresi','5000ms','Kompresör bu süre boyunca çalışır'],
          ['Basınç Ölçüm','10 × 500ms = 5sn','Kompresör kapandıktan sonra izleme süresi'],
          ['WS Timeout','2000ms','Modbus komut cevap bekleme süresi'],
          ['Yeniden Bağlan','3sn','MOXA bağlantısı kesilirse otomatik yeniden bağlan'],
          ['Toplam Test','~12-15sn','Normal koşullarda bir testin ortalama süresi'],
        ] as $i => $r): ?>
        <tr style="<?= $i%2?'background:var(--kenar-a)':'' ?>">
          <td style="font-weight:600"><?= $r[0] ?></td>
          <td><code style="background:var(--kenar-a);padding:1px 6px;border-radius:3px;font-weight:700"><?= $r[1] ?></code></td>
          <td style="font-size:12px;color:var(--m2)"><?= $r[2] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

</div><!-- /s-body -->

<style>
@media(max-width:600px){ .pin-grid{grid-template-columns:1fr!important} }
</style>

<script>
var tabs = ['akis','moxa','ag','durum'];
function tabGoster(id) {
    tabs.forEach(function(s) {
        var el  = document.getElementById('sema_' + s);
        var btn = document.getElementById('tab_' + s);
        if (el)  el.style.display  = s===id ? 'block' : 'none';
        if (btn) {
            btn.style.background = s===id ? 'var(--t)' : 'var(--kenar-a)';
            btn.style.color      = s===id ? '#fff'     : 'var(--m)';
        }
    });
}
</script>
