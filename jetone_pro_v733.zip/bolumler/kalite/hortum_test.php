<?php
/**
 * JETONE.PRO — Hortum Test Sistemi
 * panel.php: 'kalite-hortum-test' => 'bolumler/kalite/hortum_test.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? 'Operatör';

// DB tablolarını oluştur
try { $db->exec(file_get_contents(dirname(dirname(__DIR__)).'/hortum_test.sql')); } catch (Throwable $e) {}

// Receteler
try {
    $receteler = $db->query("SELECT * FROM hortum_test_recete WHERE aktif=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $receteler = []; }

// Server durumu sayfa acilisinda kontrol
$server_calisiyor = false;
try {
    $s = @fsockopen('127.0.0.1', 5050, $e, $es, 0.3);
    if ($s) { fclose($s); $server_calisiyor = true; }
} catch(Throwable $e) {}
?>
<style>
/* ─── Hortum Test Sayfa Stilleri ─── */
:root {
  --ht-primary:#1E3A5F; --ht-teal:#0EA5E9; --ht-success:#22C55E;
  --ht-danger:#EF4444;  --ht-warn:#F59E0B; --ht-border:#CBD5E1;
}
.ht-body { display:grid; grid-template-columns:1fr 300px; gap:14px; align-items:start; }
@media(max-width:900px){ .ht-body{grid-template-columns:1fr} }

/* Stage Tabs */
.ht-tabs { display:flex; gap:0; border-radius:10px; overflow:hidden; border:1px solid var(--ht-border); margin-bottom:12px; }
.ht-tab  { flex:1; padding:10px 14px; background:var(--kenar-a); border:none; cursor:default;
           display:flex; align-items:center; gap:10px; border-right:1px solid var(--ht-border); }
.ht-tab:last-child { border-right:none; }
.ht-tab.active  { background:linear-gradient(135deg,var(--ht-primary),var(--ht-teal)); color:#fff; }
.ht-tab.done    { background:#D1FAE5; }
.ht-tab.failed  { background:#FEE2E2; }
.ht-tab-num { width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.25);
              display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;flex-shrink:0; }
.ht-tab:not(.active) .ht-tab-num { background:var(--ht-border); color:var(--m2); }
.ht-tab.done   .ht-tab-num { background:var(--ht-success); color:#fff; }
.ht-tab.failed .ht-tab-num { background:var(--ht-danger);  color:#fff; }

/* Status badge */
.ht-status { display:flex;align-items:center;justify-content:center;gap:10px;padding:10px 16px;
             border-radius:10px;font-size:.9rem;font-weight:700;margin-bottom:12px;transition:all .4s; }
.ht-status.idle    { background:#EFF6FF; color:var(--ht-primary); }
.ht-status.running { background:#E0F7FA; color:#0277BD; }
.ht-status.pass    { background:#D1FAE5; color:#065F46; }
.ht-status.fail    { background:#FEE2E2; color:#991B1B; }

/* Gauge */
.ht-gauge-wrap { display:flex;flex-direction:column;align-items:center;gap:2px; }
.ht-gauge-val  { font-size:1.6rem;font-weight:900;color:var(--ht-primary);letter-spacing:-1px; }
.ht-gauge-unit { font-size:.75rem;color:var(--m2); }

/* Progress */
.ht-prog-bg   { height:10px;background:var(--kenar);border-radius:10px;overflow:hidden; }
.ht-prog-fill { height:100%;border-radius:10px;background:linear-gradient(90deg,var(--ht-primary),var(--ht-teal));transition:width .5s ease;width:0% }

/* Product bar */
.ht-prod-bar { display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:10px;
               border:2px solid;font-weight:700;font-size:.85rem;transition:all .4s; }
.ht-prod-bar.no-product { border-color:var(--ht-border);background:var(--kenar-a);color:var(--m2); }
.ht-prod-bar.has-product{ border-color:var(--ht-success);background:#D1FAE5;color:#065F46; }

/* Piston göstergesi */
.ht-piston { width:100%;text-align:center;padding:12px;border-radius:10px;font-weight:800;font-size:.9rem;transition:all .4s; }
.ht-piston.yukari { background:#E0F2FE;color:var(--ht-primary);border:2px solid var(--ht-teal); }
.ht-piston.asagi  { background:#FEF9C3;color:#92400E;border:2px solid var(--ht-warn); }

/* Kontrol butonları */
.ht-btn-start { width:100%;padding:12px;border-radius:10px;border:none;cursor:pointer;
                font-weight:800;font-size:1rem;background:var(--ht-success);color:#fff;
                transition:all .2s; }
.ht-btn-start:disabled { background:#94A3B8;cursor:not-allowed; }
.ht-btn-stop  { width:100%;padding:10px;border-radius:10px;border:none;cursor:pointer;
                font-weight:700;background:var(--ht-danger);color:#fff;margin-top:6px;display:none; }
.ht-btn-reset { width:100%;padding:8px;border-radius:10px;border:2px solid var(--ht-border);
                background:none;cursor:pointer;font-weight:700;color:var(--m2);margin-top:6px; }

/* Lamba */
.ht-lamp { width:40px;height:40px;border-radius:50%;transition:all .4s;flex-shrink:0; }
.ht-lamp-green { background:#22C55E;box-shadow:0 0 12px #22C55E; }
.ht-lamp-red   { background:#EF4444;box-shadow:0 0 12px #EF4444; }
.ht-lamp-off   { background:#CBD5E1;box-shadow:none; }

/* Tablo */
.ht-history-tablo td,
.ht-history-tablo th { padding:6px 10px; font-size:12px; border-bottom:1px solid var(--kenar); }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🧪 Hortum Test Sistemi</h1>
    <div class="s-yol">Kalite / <b>Hortum Test</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <!-- Bağlantı durum rozeti (sadece görüntü) -->
    <div style="display:flex;align-items:center;gap:8px;padding:5px 12px;border-radius:20px;background:var(--kenar-a)">
      <div id="htConnDot" style="width:9px;height:9px;border-radius:50%;background:#EF4444;transition:.4s;flex-shrink:0"></div>
      <span id="htConnLabel" style="font-size:11px;font-weight:700;color:var(--m2)">WS: Bağlı değil</span>
      <div style="width:1px;height:14px;background:var(--kenar)"></div>
      <div id="moxaConnDot" style="width:9px;height:9px;border-radius:50%;background:#94A3B8;transition:.4s;flex-shrink:0"></div>
      <span id="moxaConnLabel" style="font-size:11px;font-weight:700;color:var(--m2)">MOXA: —</span>
    </div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-recete"  class="btn btn-b btn-sm" style="font-size:11px">📋 Reçeteler</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-sema"    class="btn btn-b btn-sm" style="font-size:11px">📐</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-ayarlar" class="btn btn-b btn-sm" style="font-size:11px">⚙️</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-gecmis" class="btn btn-b btn-sm">📋 Geçmiş</a>
  </div>
</div>

<div class="s-body">
<div class="ht-body">

<!-- ─── SOL: Ana Test Alanı ─────────────────────────────────── -->
<div>

  <!-- Bağlantı Satırı (gizli - ayarlar sayfasından yönetilir) -->
  <div class="kart" style="display:none;margin-bottom:12px;padding:12px 16px">
    <div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:10px">🔌 Bağlantı Ayarları</div>
    <div style="display:flex;align-items:flex-end;gap:10px;flex-wrap:wrap">

      <!-- Protokol seçimi -->
      <div>
        <label style="font-size:10px;color:var(--m2);font-weight:700;display:block;margin-bottom:3px">Protokol</label>
        <select id="htProtocol" class="form-alan" style="width:160px;font-size:12px;padding:5px 8px" onchange="htProtocolChange()">
          <option value="mock">🔧 Simülasyon (Test)</option>
          <option value="ws">🌐 WebSocket (MOXA Server)</option>
        </select>
      </div>

      <!-- WebSocket alanları -->
      <div id="htWsFields" style="display:none;gap:10px;align-items:flex-end" class="ht-conn-fields">
        <div>
          <label style="font-size:10px;color:var(--m2);font-weight:700;display:block;margin-bottom:3px">
            MOXA IP
            <span style="color:var(--m3);font-weight:400"> — fabrikadaki MOXA E1212</span>
          </label>
          <input id="htMoxaIp" class="form-alan" type="text" value="192.168.127.254"
                 style="width:160px;font-size:12px;padding:5px 8px;font-family:monospace"
                 placeholder="192.168.127.254">
        </div>
        <div>
          <label style="font-size:10px;color:var(--m2);font-weight:700;display:block;margin-bottom:3px">Modbus Port</label>
          <input id="htMoxaPort" class="form-alan" type="number" value="502"
                 style="width:80px;font-size:12px;padding:5px 8px;font-family:monospace">
        </div>
        <div>
          <label style="font-size:10px;color:var(--m2);font-weight:700;display:block;margin-bottom:3px">
            Node.js Server
            <span style="color:var(--m3);font-weight:400"> — bu ERP&#39;nin çalıştığı PC</span>
          </label>
          <input id="htWsUrl" class="form-alan" type="text" value="ws://localhost:5050"
                 style="width:190px;font-size:12px;padding:5px 8px;font-family:monospace"
                 placeholder="ws://localhost:5050">
        </div>
      </div>

      <!-- Bağlan butonu -->
      <div>
        <button id="htBtnConnect" onclick="htApp.connect()" class="btn btn-t btn-sm" style="padding:6px 16px">
          🔗 Bağlan
        </button>
        <button onclick="htApp.disconnect()" class="btn btn-b btn-sm" style="padding:6px 12px;margin-left:4px;display:none" id="htBtnDisconnect">
          ✕
        </button>
      </div>

      <!-- Durum göstergesi s-bar'da -->

      <!-- Sim: ürün koy/kaldır butonu -->
      <button id="htBtnMockProd2" onclick="htApp.toggleMockProduct()"
              style="display:none;padding:6px 12px;border-radius:8px;border:2px dashed var(--ht-border);
                     background:none;cursor:pointer;font-size:12px;font-weight:700;color:var(--m2)">
        📦 Ürün Koy/Kaldır
      </button>
    </div>

    <!-- Bilgi notu -->
    <div id="htConnNote" style="margin-top:10px;font-size:11px;color:var(--m2);padding:8px 12px;
         background:var(--kenar-a);border-radius:8px;display:none">
    </div>
  </div>

  <!-- Stage Tabs -->
  <div class="ht-tabs">
    <div class="ht-tab active" id="htTab1">
      <div class="ht-tab-num">1</div>
      <div>
        <strong style="font-size:.9rem">Kaçak Testi</strong>
        <div style="font-size:.75rem;opacity:.7">Her iki uç kapalı</div>
      </div>
    </div>
    <div class="ht-tab" id="htTab2">
      <div class="ht-tab-num">2</div>
      <div>
        <strong style="font-size:.9rem">Tıkanıklık Testi</strong>
        <div style="font-size:.75rem;opacity:.7">Uç açılır, akış ölçülür</div>
      </div>
    </div>
  </div>

  <div class="kart">
    <!-- Status Badge -->
    <div class="ht-status idle" id="htStatus">
      <div style="font-size:1.2rem">⏸</div>
      <div>Teste başlamak için <b>Başlat</b> butonuna basın</div>
    </div>

    <!-- 2 Kolon: SVG + Gauge -->
    <div style="display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center;margin-bottom:12px">

      <!-- Hortum SVG -->
      <div>
        <svg id="htHoseSvg" viewBox="0 0 580 120" style="width:100%;max-width:560px">
          <defs>
            <linearGradient id="hoseGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#60A5FA"/>
              <stop offset="100%" stop-color="#818CF8"/>
            </linearGradient>
            <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0,0 L10,5 L0,10 Z" fill="#0EA5E9"/>
            </marker>
          </defs>
          <!-- Zemin -->
          <rect x="20" y="50" width="540" height="20" rx="10" fill="url(#hoseGrad)" opacity=".25"/>
          <!-- Ana hortum -->
          <rect id="htHoseBody" x="20" y="52" width="540" height="16" rx="8" fill="url(#hoseGrad)" opacity=".7"/>
          <!-- Sol kapak (piston) -->
          <rect id="htCapL" x="8"  y="44" width="18" height="32" rx="5" fill="#1E3A5F"/>
          <text x="17" y="64" text-anchor="middle" font-size="8" fill="#fff">P</text>
          <!-- Sağ kapak -->
          <rect id="htCapR" x="554" y="44" width="18" height="32" rx="5" fill="#1E3A5F"/>
          <text x="563" y="64" text-anchor="middle" font-size="8" fill="#fff">K</text>
          <!-- Basınç noktası -->
          <circle cx="290" cy="44" r="6" fill="#F59E0B" opacity=".8" id="htPressPoint"/>
          <text x="290" y="38" text-anchor="middle" font-size="9" fill="#92400E">P</text>
          <!-- Hava partikülleri (tıkanıklık testinde animasyonlu) -->
          <circle id="htP1" class="ht-particle" cx="100" cy="60" r="3" fill="#0EA5E9" opacity="0"/>
          <circle id="htP2" class="ht-particle" cx="200" cy="60" r="3" fill="#0EA5E9" opacity="0"/>
          <circle id="htP3" class="ht-particle" cx="350" cy="60" r="3" fill="#0EA5E9" opacity="0"/>
          <circle id="htP4" class="ht-particle" cx="450" cy="60" r="3" fill="#0EA5E9" opacity="0"/>
          <!-- Sonuç overlay -->
          <text id="htHoseResult" x="290" y="40" text-anchor="middle" font-size="13" font-weight="bold" fill="transparent"></text>
        </svg>
      </div>

      <!-- Manometre -->
      <div class="ht-gauge-wrap">
        <div style="font-size:10px;color:var(--m2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Basınç</div>
        <svg viewBox="0 0 120 120" width="110">
          <circle cx="60" cy="60" r="54" fill="none" stroke="#E2E8F0" stroke-width="12"/>
          <circle id="htGaugeArc" cx="60" cy="60" r="54" fill="none"
                  stroke="url(#hoseGrad)" stroke-width="12"
                  stroke-dasharray="0 339" stroke-linecap="round"
                  transform="rotate(-90 60 60)" style="transition:stroke-dasharray .5s"/>
          <text x="60" y="55" text-anchor="middle" font-size="8" fill="#94A3B8">BAR</text>
          <text id="htGaugeText" x="60" y="72" text-anchor="middle" font-size="18" font-weight="900" fill="#1E3A5F">0.000</text>
        </svg>
        <div id="htGaugeVal" class="ht-gauge-val" style="display:none">0.000</div>
        <div id="htFlowVal" style="font-size:12px;font-weight:700;color:var(--ht-teal);margin-top:2px">— L/dk</div>
      </div>
    </div>

    <!-- Progress -->
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--m2);margin-bottom:5px">
        <span id="htProgLabel">Hazır</span>
        <span id="htProgTimer"></span>
      </div>
      <div class="ht-prog-bg"><div class="ht-prog-fill" id="htProgFill"></div></div>
    </div>

    <!-- Sonuç Kartları -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px" id="htResultCards" style="display:none">
      <div id="htRes1" style="padding:10px;border-radius:8px;border:2px solid var(--kenar);font-size:12px;text-align:center;display:none">
        <div style="font-weight:800;margin-bottom:3px">Aşama 1</div>
        <div id="htRes1Detail"></div>
      </div>
      <div id="htRes2" style="padding:10px;border-radius:8px;border:2px solid var(--kenar);font-size:12px;text-align:center;display:none">
        <div style="font-weight:800;margin-bottom:3px">Aşama 2</div>
        <div id="htRes2Detail"></div>
      </div>
    </div>
  </div>
</div><!-- /sol -->

<!-- ─── SAĞ: Kontroller + Reçete ────────────────────────────── -->
<div style="display:flex;flex-direction:column;gap:12px">

  <!-- Ürün Algılama -->
  <div class="kart" style="padding:12px">
    <div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:8px">Ürün Algılama</div>
    <div class="ht-prod-bar no-product" id="htProdBar">
      <div class="ht-lamp ht-lamp-off" id="htProdLamp"></div>
      <div id="htProdText">Hortum bekleniyor...</div>
    </div>
<!-- mock product butonu üst satıra taşındı -->
  </div>

  <!-- Piston Durumu -->
  <div class="kart" style="padding:12px">
    <div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:8px">Piston Durumu</div>
    <div class="ht-piston yukari" id="htPistonStatus">⬆ YUKARI (Serbest)</div>
    <div style="display:flex;gap:8px;margin-top:8px">
      <div class="ht-lamp ht-lamp-off" id="htLampGreen" style="width:32px;height:32px"></div>
      <div style="font-size:11px;flex:1;color:var(--m2)">OK — Yeşil Lamba</div>
    </div>
    <div style="display:flex;gap:8px;margin-top:6px">
      <div class="ht-lamp ht-lamp-off" id="htLampRed" style="width:32px;height:32px"></div>
      <div style="font-size:11px;flex:1;color:var(--m2)">HATA — Kırmızı Lamba</div>
    </div>
  </div>

  <!-- Kontrol Butonları -->
  <div class="kart" style="padding:12px">
    <button id="htBtnStart" class="ht-btn-start" onclick="htApp.start()" disabled>
      ▶ BAŞLAT
    </button>
    <button id="htBtnStop" class="ht-btn-stop" onclick="htApp.stop()">
      ⏹ DURDUR
    </button>
    <button class="ht-btn-reset" onclick="htApp.reset()">↺ Sıfırla</button>
  </div>

  <!-- Reçete -->
  <div class="kart" style="padding:12px">
    <div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:8px">Aktif Reçete</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
      <label class="form-et" style="margin:0">Aktif Reçete</label>
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-recete" class="btn btn-b btn-sm" style="font-size:10px;padding:2px 8px">⚙️ Yönet</a>
    </div>
    <select id="htReceteSelect" class="form-alan" style="font-size:12px;padding:5px 8px;margin-bottom:8px" onchange="htApp.loadRecete(this.value)">
      <?php foreach ($receteler as $r): ?>
      <option value="<?= $r['id'] ?>"
              data-p="<?= $r['hedef_basinc'] ?>"
              data-l="<?= $r['kacak_esigi'] ?>"
              data-h="<?= $r['bekle_sure'] ?>"
              data-f="<?= $r['min_akis'] ?>"
              data-s="<?= $r['stabilize_sure'] ?>">
        <?= htmlspecialchars($r['recete_adi']) ?>
      </option>
      <?php endforeach; ?>
    </select>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px">
      <div>
        <label class="form-et" style="font-size:10px">Hedef Basınç (bar)</label>
        <input id="htHedefBar" class="form-alan" type="number" step=".001" style="padding:4px 6px;font-size:12px">
      </div>
      <div>
        <label class="form-et" style="font-size:10px">Kaçak Eşiği (bar)</label>
        <input id="htKacakEsigi" class="form-alan" type="number" step=".001" style="padding:4px 6px;font-size:12px">
      </div>
      <div>
        <label class="form-et" style="font-size:10px">Bekleme (sn)</label>
        <input id="htBekleSure" class="form-alan" type="number" style="padding:4px 6px;font-size:12px">
      </div>
      <div>
        <label class="form-et" style="font-size:10px">Min. Akış (L/dk)</label>
        <input id="htMinAkis" class="form-alan" type="number" step=".1" style="padding:4px 6px;font-size:12px">
      </div>
    </div>
  </div>

</div><!-- /sag -->
</div><!-- /ht-body -->

<!-- Son 10 Test Geçmişi -->
<div class="kart" style="margin-top:14px;padding:0">
  <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <b style="font-size:13px">📋 Son Test Kayıtları</b>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-gecmis" style="font-size:11px;color:var(--t)">Tümü →</a>
  </div>
  <div id="htGecmisWrap" style="overflow-x:auto">
    <table class="ht-history-tablo" style="width:100%;border-collapse:collapse">
      <thead><tr style="background:#1E3A5F">
        <?php foreach(['#','Tarih','Reçete','Operatör','A1 Sonuç','A1 Düşüş','A2 Sonuç','A2 Akış','Süre','Genel'] as $h): ?>
        <th style="background:#1E3A5F;color:#fff;padding:7px 10px;font-size:11px;font-weight:700;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody id="htGecmisTbody">
        <tr><td colspan="10" style="text-align:center;color:var(--m2);padding:20px">Yükleniyor...</td></tr>
      </tbody>
    </table>
  </div>
</div>

</div><!-- /s-body -->

<script>
var HT_BASE_URL = '<?= BASE_URL ?>';
var HT_OPERATOR = '<?= addslashes($kul_adi) ?>';

// ─────────────────────────────────────────────────────────────────
// HTAPP — Hortum Test Uygulaması
// ─────────────────────────────────────────────────────────────────
// ── MOXA Server Otomatik Yönetim ─────────────────────────
var YONET_URL = '<?= BASE_URL ?>/bolumler/kalite/ajax/moxa_server_yonet.php';
var serverCalisiyor = <?= $server_calisiyor ? 'true' : 'false' ?>;

// Server durum göstergesi güncelle
function serverBadgeGuncelle(calisiyor, bilgi) {
    var badge = document.getElementById('serverBadge');
    var btn   = document.getElementById('btnServerToggle');
    var durum = document.getElementById('serverDurum');
    if (!badge) return;
    if (calisiyor) {
        badge.style.background = '#D1FAE5'; badge.style.color = '#065F46';
        badge.textContent = '● Node.js Çalışıyor';
        if (btn) { btn.textContent = '■ Durdur'; btn.style.background = '#EF4444'; }
        if (durum) durum.textContent = bilgi || 'ws://localhost:5050';
    } else {
        badge.style.background = '#FEE2E2'; badge.style.color = '#991B1B';
        badge.textContent = '● Node.js Durdu';
        if (btn) { btn.textContent = '▶ Başlat'; btn.style.background = '#22C55E'; }
        if (durum) durum.textContent = bilgi || 'Başlatmak için tıklayın';
    }
}

// Server başlat
async function serverBaslat() {
    var btn = document.getElementById('btnServerToggle');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Başlatılıyor...'; }
    try {
        var fd = new FormData(); fd.append('action','baslat');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        var d  = await r.json();
        serverCalisiyor = d.ok && d.calisiyor !== false;
        serverBadgeGuncelle(serverCalisiyor, d.mesaj || (d.ws_url || ''));
        if (serverCalisiyor && typeof htApp !== 'undefined') {
            // WS URL'yi ayarla ve bağlan
            var wsInput = document.getElementById('htWsUrl');
            if (wsInput) wsInput.value = d.ws_url || 'ws://localhost:5050';
            setTimeout(function(){ htApp.connect(); }, 500);
        }
        if (!d.ok) { alert('Server başlatılamadı: ' + (d.hata||d.mesaj)); }
    } catch(e) {
        serverBadgeGuncelle(false, 'Hata: ' + e.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

// Server durdur
async function serverDurdur() {
    var btn = document.getElementById('btnServerToggle');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Durduruluyor...'; }
    try {
        if (typeof htApp !== 'undefined') htApp.disconnect();
        var fd = new FormData(); fd.append('action','durdur');
        var r  = await fetch(YONET_URL, {method:'POST', body:fd});
        var d  = await r.json();
        serverCalisiyor = false;
        serverBadgeGuncelle(false, d.mesaj || 'Durduruldu');
    } catch(e) {
        serverBadgeGuncelle(false, 'Hata: ' + e.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

// Toggle butonu
function serverToggle() {
    if (serverCalisiyor) serverDurdur(); else serverBaslat();
}

// Sayfa açılışında: server çalışmıyorsa otomatik başlat
window.addEventListener('DOMContentLoaded', function() {
    serverBadgeGuncelle(serverCalisiyor);
    if (!serverCalisiyor) {
        // Server durumu: ayarlar sayfasına yönlendir
        var dot = document.getElementById('htConnDot');
        var lbl = document.getElementById('htConnLabel');
        if (dot) dot.style.background = '#F59E0B';
        if (lbl) lbl.textContent = 'WS: Başlatılıyor...';
        serverBaslat(); // Otomatik başlat
    } else {
        // Server çalışıyor — otomatik bağlan
        setTimeout(function(){ if (typeof htApp !== 'undefined') htApp.connect(); }, 600);
    }
});

var htApp = (function(){
  var connected     = false;
  var running       = false;
  var stage         = 0;
  var productDetected = false;
  var mockProductPlaced = false;
  var ws            = null;
  var mockInt       = null;
  var _testStart    = null;
  var _stageStart   = null;
  var _stage1Data   = null;
  var _stage2Data   = null;
  var pressure      = 0;
  var receteData    = {};
  var pistonAsagi   = false;
  var particleTick  = 0;
  var particleAnim  = null;

  // ── DOM kısayolları ──
  var $ = id => document.getElementById(id);

  // ── Basınç Göstergesi ──
  function setGauge(v) {
    pressure = v;
    var pct  = Math.min(1, v / (receteData.hedef || 3));
    var circ = 339;
    $('htGaugeArc').setAttribute('stroke-dasharray', (pct*circ) + ' ' + circ);
    $('htGaugeText').textContent = v.toFixed(3);
    // Renk
    var col = v >= (receteData.hedef||3)*0.9 ? '#22C55E' : v >= (receteData.hedef||3)*0.5 ? '#F59E0B' : '#EF4444';
    $('htGaugeArc').setAttribute('stroke', col);
    $('htGaugeText').setAttribute('fill', col);
  }

  function setFlow(v) {
    $('htFlowVal').textContent = v !== null ? v.toFixed(1)+' L/dk' : '— L/dk';
  }

  // ── Status ──
  function setStatus(cls, msg) {
    var el = $('htStatus');
    el.className = 'ht-status '+cls;
    var icons = {idle:'⏸',running:'⚙️',pass:'✅',fail:'🚨'};
    el.innerHTML = '<div style="font-size:1.2rem">'+(icons[cls]||'⏸')+'</div><div>'+msg+'</div>';
  }

  // ── Stage Tab ──
  function setTab(n, cls) {
    $('htTab'+n).className = 'ht-tab '+(cls||'');
  }

  // ── Progress ──
  function setProgress(pct, lbl, sn) {
    $('htProgFill').style.width = pct+'%';
    $('htProgLabel').textContent = lbl||'';
    $('htProgTimer').textContent = sn !== undefined ? sn+' sn' : '';
  }

  // ── Ürün bar ──
  function setProduct(v) {
    productDetected = v;
    var bar  = $('htProdBar');
    var lamp = $('htProdLamp');
    var txt  = $('htProdText');
    if (v) {
      bar.className = 'ht-prod-bar has-product';
      lamp.className = 'ht-lamp ht-lamp-green';
      txt.textContent = '✅ Hortum algılandı';
    } else {
      bar.className = 'ht-prod-bar no-product';
      lamp.className = 'ht-lamp ht-lamp-off';
      txt.textContent = 'Hortum bekleniyor...';
    }
    $('htBtnStart').disabled = (!v || running);
  }

  // ── Piston ──
  function setPiston(asagi) {
    pistonAsagi = asagi;
    var el = $('htPistonStatus');
    if (asagi) {
      el.className = 'ht-piston asagi';
      el.textContent = '⬇ AŞAĞI (Tutuyor)';
      $('htCapL').setAttribute('fill','#F59E0B');
    } else {
      el.className = 'ht-piston yukari';
      el.textContent = '⬆ YUKARI (Serbest)';
      $('htCapL').setAttribute('fill','#1E3A5F');
    }
  }

  // ── Lambalar ──
  function setLamp(color) {
    $('htLampGreen').className = 'ht-lamp '+(color==='green'?'ht-lamp-green':'ht-lamp-off');
    $('htLampRed'  ).className = 'ht-lamp '+(color==='red'  ?'ht-lamp-red'  :'ht-lamp-off');
  }

  // ── Hortum SVG ──
  function setHoseViz(stage, mode) {
    var body  = $('htHoseBody');
    var capR  = $('htCapR');
    var parts = document.querySelectorAll('.ht-particle');
    // Partikülleri gizle
    parts.forEach(p => p.setAttribute('opacity','0'));
    if (stage===1) {
      // Kaçak: her iki uç kapalı, basınç altında kırmızı/sarı renk
      body.setAttribute('fill','#FEF9C3');
      capR.setAttribute('fill','#1E3A5F');
      if (particleAnim) { clearInterval(particleAnim); particleAnim=null; }
    } else if (stage===2 && mode==='flow') {
      // Tıkanıklık: akış var, partiküller hareket ediyor
      body.setAttribute('fill','url(#hoseGrad)');
      capR.setAttribute('fill','#94A3B8'); // açık
      parts.forEach(p => p.setAttribute('opacity','.7'));
      particleTick=0;
      if (particleAnim) clearInterval(particleAnim);
      particleAnim = setInterval(function(){
        particleTick += 3;
        var bases=[80,180,280,400];
        parts.forEach(function(p,i){
          var x=((bases[i]+particleTick*(1+i*.4))%480)+50;
          p.setAttribute('cx',x);
        });
      },40);
    } else {
      body.setAttribute('fill','url(#hoseGrad)');
      capR.setAttribute('fill','#1E3A5F');
      if (particleAnim) { clearInterval(particleAnim); particleAnim=null; }
    }
  }

  // ── Sonuç kartları ──
  function showResult(stage, pass, detail) {
    var id='htRes'+stage, det=$('htRes'+stage+'Detail');
    var el=$(id);
    el.style.display='block';
    el.style.background = pass?'#D1FAE5':'#FEE2E2';
    el.style.borderColor= pass?'#22C55E':'#EF4444';
    det.innerHTML = (pass?'✅':'❌')+' '+(pass?'GEÇTI':'KALDI')+'<br><small style="color:var(--m2)">'+detail+'</small>';
  }

  // ── Reçete Parametreleri ──
  function P() {
    return {
      hedef : parseFloat($('htHedefBar').value)  || 2.5,
      kacak : parseFloat($('htKacakEsigi').value) || 0.05,
      bekle : parseInt($('htBekleSure').value)    || 10,
      akis  : parseFloat($('htMinAkis').value)    || 8.0,
      stab  : 3
    };
  }

  // ── Geçmiş Tablosu ──
  function loadGecmis() {
    fetch(HT_BASE_URL+'/islemler/kalite/hortum_test_gecmis.php')
    .then(r=>r.json()).then(function(j){
      if (!j.ok) return;
      var html='';
      j.data.forEach(function(r,i){
        var gb = r.genel_sonuc=='1';
        var bg = gb?'#D1FAE5':'#FEE2E2';
        html+='<tr style="background:'+bg+'">'
          +'<td style="color:var(--m3)">'+(i+1)+'</td>'
          +'<td style="white-space:nowrap">'+r.kayit_tarihi+'</td>'
          +'<td>'+escH(r.recete_adi||'—')+'</td>'
          +'<td>'+escH(r.operatör||'—')+'</td>'
          +'<td style="text-align:center">'+(r.asama1_sonuc=='1'?'✅':'❌')+'</td>'
          +'<td style="text-align:right">'+(r.asama1_dusus_bar?parseFloat(r.asama1_dusus_bar).toFixed(3):'—')+'</td>'
          +'<td style="text-align:center">'+(r.asama2_sonuc!==null?(r.asama2_sonuc=='1'?'✅':'❌'):'—')+'</td>'
          +'<td style="text-align:right">'+(r.asama2_akis_ldk?parseFloat(r.asama2_akis_ldk).toFixed(1)+'L/dk':'—')+'</td>'
          +'<td style="text-align:right">'+(r.sure_sn||'—')+'sn</td>'
          +'<td style="text-align:center;font-weight:800">'+(gb?'✅ GEÇTI':'❌ KALDI')+'</td>'
          +'</tr>';
      });
      $('htGecmisTbody').innerHTML = html || '<tr><td colspan="10" style="text-align:center;color:var(--m2);padding:16px">Kayıt yok</td></tr>';
    }).catch(function(){ $('htGecmisTbody').innerHTML='<tr><td colspan="10" style="text-align:center;color:var(--m2)">Yüklenemedi</td></tr>'; });
  }

  function escH(s){ var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

  // ── DB'ye Kaydet ──
  function dbKaydet(pass) {
    var dur = Math.round((Date.now()-_testStart)/1000);
    var payload = {
      recete_adi : $('htReceteSelect').options[$('htReceteSelect').selectedIndex]?.text || '—',
      operator   : HT_OPERATOR,
      test_baslangic: new Date(_testStart).toISOString().slice(0,19).replace('T',' '),
      test_bitis    : new Date().toISOString().slice(0,19).replace('T',' '),
      sure_sn    : dur,
      asama1     : _stage1Data,
      asama2     : _stage2Data,
      genel_sonuc: pass?1:0,
      piston_durum: pistonAsagi?'ASAGI':'YUKARI'
    };
    fetch(HT_BASE_URL+'/islemler/kalite/hortum_test_kaydet.php',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    }).then(r=>r.json()).then(function(j){
      if (j.ok) { loadGecmis(); }
    }).catch(function(){});
  }

  // ── WS / Modbus Bağlantı ──
  function connect() {
    var proto = $('htProtocol').value;
    if (proto === 'mock') {
      connected = true;
      $('htConnDot').style.background = '#22C55E';
      $('htConnLabel').textContent = '🔧 Simülasyon';
      $('htBtnMockProd2').style.display = 'inline-block';
      // Simülasyonda hortum otomatik takılı — kullanıcı isterse kaldırabilir
      mockProductPlaced = true;
      setProduct(true);
      toast('Simülasyon aktif — Hortum takılı ✓');
      return;
    }
    if (proto === 'ws') {
      var url = 'ws://localhost:5050';
      try {
        ws = new WebSocket(url);
        ws.onopen = function(){
          connected=true;
          $('htConnDot').style.background='#22C55E';
          $('htConnLabel').textContent='WS: Bağlı';
          $('moxaConnDot').style.background='#F59E0B';
          $('moxaConnLabel').textContent='MOXA: Bağlanıyor...';
          $('htBtnDisconnect').style.display='inline';
          toast('WebSocket bağlandı ✓');
          // MOXA IP ve port bilgisini server'a ilet
          var moxaIp   = (document.getElementById('htMoxaIp')   || {value:'192.168.127.254'}).value;
          var moxaPort = (document.getElementById('htMoxaPort') || {value:'502'}).value;
          ws.send(JSON.stringify({komut:'config_guncelle', moxa_host:moxaIp, moxa_port:moxaPort}));
        };
        ws.onclose  = function(){ connected=false; $('htConnDot').style.background='#EF4444'; $('htConnLabel').textContent='WS: Bağlı değil';
          $('moxaConnDot').style.background='#94A3B8'; $('moxaConnLabel').textContent='MOXA: —'; };
        ws.onmessage = function(e){ handleWsMsg(JSON.parse(e.data)); };
        ws.onerror  = function(){ toast('WS bağlantı hatası!'); };
      } catch(e) { toast('WS hatası: '+e.message); }
      return;
    }
  }

  function disconnect() {
    if (ws) { try { ws.close(); } catch(e){} ws = null; }
    connected = false;
    document.getElementById('htConnDot').style.background = '#EF4444';
    document.getElementById('htConnLabel').textContent = 'WS: Bağlı değil';
    document.getElementById('moxaConnDot').style.background = '#94A3B8';
    document.getElementById('moxaConnLabel').textContent = 'MOXA: —';
    document.getElementById('htBtnDisconnect').style.display = 'none';
    document.getElementById('htBtnMockProd2').style.display = 'none';
    toast('Bağlantı kesildi');
  }

  function handleWsMsg(msg) {
    // MOXA bağlantı durumu (moxa_server.js'ten gelen)
    if (msg.tip === 'baglanti') {
      var baglandı = msg.durum === 'baglandı';
      var dot   = document.getElementById('moxaConnDot');
      var label = document.getElementById('moxaConnLabel');
      if (dot) dot.style.background = baglandı ? '#22C55E' : '#EF4444';
      if (label) label.textContent  = baglandı
        ? ('MOXA: Bağlı (' + (msg.mesaj || '') + ')')
        : ('MOXA: ' + (msg.durum === 'kesildi' ? 'Kesildi' : 'Hata'));
      return;
    }
    // MOXA anlık durum (polling)
    if (msg.tip === 'durum' || msg.tip === 'ilk_durum') {
      var dot   = document.getElementById('moxaConnDot');
      var label = document.getElementById('moxaConnLabel');
      if (dot) dot.style.background = msg.connected !== false ? '#22C55E' : '#EF4444';
      if (label) label.textContent  = msg.connected !== false ? 'MOXA: Bağlı' : 'MOXA: Bağlı Değil';
      return;
    }

    // server.js formatı: type='sensor'|'result'|'ack'|'error'|'info'
    if (msg.type === 'sensor') {
      if (msg.pressure        !== undefined) setGauge(msg.pressure);
      if (msg.flow            !== undefined) setFlow(msg.flow);
      if (msg.productDetected !== undefined) setProduct(msg.productDetected);
      if (msg.pistonExtended  !== undefined) setPiston(msg.pistonExtended);
      if (msg.timer           !== undefined && msg.status === 1) {
        var pct = 0;
        if (msg.stage === 1) pct = Math.min(99, (receteData.bekle||10 - msg.timer) / (receteData.bekle||10) * 100);
        if (msg.stage === 2) pct = Math.min(99, (10 - msg.timer) / 10 * 100);
        setProgress(pct, msg.stage===1?'Kaçak testi...':'Tıkanıklık testi...', msg.timer);
      }
    } else if (msg.type === 'result') {
      if (msg.stage === 1) finishStage1(msg.pass, msg.drop || 0);
      if (msg.stage === 2) finishStage2(msg.pass, msg.flow || 0);
    } else if (msg.type === 'ack') {
      if (msg.cmd === 'START_STAGE1' && msg.ok) {
        setStatus('running', 'Piston indi — Kaçak testi başlıyor...');
        setPiston(true);
      } else if (msg.cmd === 'START_STAGE2' && msg.ok) {
        setStatus('running', 'Piston kalktı — Tıkanıklık testi başlıyor...');
        setPiston(false); // 2. aşamada piston yukarı
      } else if (msg.cmd === 'STOP' || msg.cmd === 'RESET') {
        setStatus('idle', 'Test durduruldu');
        setPiston(false); setLamp(null);
      }
    } else if (msg.type === 'error') {
      toast('⚠ ' + (msg.msg || 'Hata'));
      setStatus('fail', msg.msg || 'Hata');
    } else if (msg.type === 'info') {
      toast('ℹ ' + (msg.msg || ''));
    }
    // Eski format geriye dönük uyumluluk
    if (msg.type === 'SENSOR') {
      if (msg.pressure !== undefined) setGauge(msg.pressure);
      if (msg.product  !== undefined) setProduct(msg.product);
    }
  }

  function sendCmd(cmd, params) {
    if (!ws || ws.readyState!==1) return;
    // server.js formatı: cmd düzeyinde flat params
    var payload = Object.assign({ cmd: cmd }, params || {});
    ws.send(JSON.stringify(payload));
  }

  // ── MOCK Simülasyon ──
  function runMockStage1() {
    var p = P();
    setTab(1,'active'); setTab(2,'');
    setHoseViz(1,'closed');
    setPiston(true);
    stage = 1;
    var startP = 0, cur = 0;
    var totalTick = p.stab*10 + p.bekle*10;
    var tick=0;
    clearInterval(mockInt);
    mockInt = setInterval(function(){
      tick++;
      var pct = tick/totalTick*100;
      // Dolum fazı
      if (tick <= p.stab*10) {
        cur = p.hedef * (tick/(p.stab*10));
      } else {
        // Tutma fazı — küçük sızıntı simülasyonu
        var drop = (Math.random()<0.3) ? 0.12 : 0.01; // %30 ihtimalle kaçaklı
        cur = Math.max(0, cur - drop/100);
      }
      if (tick === p.stab*10) startP = cur;
      setGauge(cur);
      setProgress(pct, 'Kaçak testi: basınç tutuluyor...', Math.ceil((totalTick-tick)/10));
      if (tick >= totalTick) {
        clearInterval(mockInt);
        var drop = startP - cur;
        finishStage1(drop <= p.kacak, drop);
      }
    }, 100);
  }

  function runMockStage2() {
    var p = P();
    setTab(2,'active');
    setHoseViz(2,'flow');
    setPiston(false); // 2. aşamada piston yukarı (serbest)
    stage = 2;
    var tick=0, totalTick=p.stab*10+30;
    clearInterval(mockInt);
    mockInt = setInterval(function(){
      tick++;
      var pct = tick/totalTick*100;
      var pr  = Math.max(0, pressure*(1-tick/(p.stab*10)));
      setGauge(pr);
      var flow = p.akis + (Math.random()*3-1); // ±1 varyasyon
      if (Math.random()<0.15) flow = 1.2; // %15 ihtimalle tıkalı
      setFlow(flow);
      setProgress(pct, 'Tıkanıklık testi: akış ölçülüyor... '+flow.toFixed(1)+' L/dk', Math.ceil((totalTick-tick)/10));
      if (tick >= totalTick) {
        clearInterval(mockInt);
        finishStage2(flow >= p.akis-0.5, flow);
      }
    },100);
  }

  function finishStage1(pass, drop) {
    _stage1Data = {sonuc:pass?1:0, hedef_bar:P().hedef, dusus_bar:parseFloat(drop.toFixed(4)), sure_sn:Math.round((Date.now()-_stageStart)/1000)};
    _stageStart = Date.now();
    setTab(1, pass?'done':'failed');
    showResult(1, pass, 'Düşüş: '+drop.toFixed(4)+' bar');
    if (pass) {
      setStatus('running','✅ Aşama 1 geçti! Aşama 2 başlıyor...');
      toast('Aşama 1 GEÇTI — Kaçak yok ✓');
      setTimeout(function(){ if(running) runMockStage2(); }, 1500);
    } else {
      setStatus('fail','🚨 KAÇAK TESPİT EDİLDİ! Piston kalkıyor...');
      toast('Aşama 1 BAŞARISIZ — Kaçak var! Düşüş: '+drop.toFixed(4)+' bar');
      setPiston(false);
      setLamp('red');
      finishTest(false);
    }
  }

  function finishStage2(pass, flow) {
    _stage2Data = {sonuc:pass?1:0, akis_ldk:parseFloat(flow.toFixed(2)), min_akis:P().akis, sure_sn:Math.round((Date.now()-_stageStart)/1000)};
    setTab(2, pass?'done':'failed');
    showResult(2, pass, 'Akış: '+flow.toFixed(1)+' L/dk');
    if (pass) {
      setStatus('pass','✅ TEST BAŞARILI — Kaçak yok, hortum açık ✓');
      toast('Test TAMAMLANDI ✓');
      setLamp('green');
    } else {
      setStatus('fail','🚨 TIKANIKLIK TESPİT EDİLDİ! Piston kalkıyor...');
      toast('Aşama 2 BAŞARISIZ — Tıkanıklık var!');
      setLamp('red');
    }
    setPiston(false);
    finishTest(pass);
  }

  function finishTest(pass) {
    running = false;
    stage   = 0;
    clearInterval(mockInt);
    setProgress(100, pass?'Test tamamlandı ✅':'Test BAŞARISIZ ❌', 0);
    $('htBtnStart').disabled = !productDetected;
    $('htBtnStop').style.display = 'none';
    $('htBtnStart').style.background = pass ? '#22C55E' : '#EF4444';
    $('htBtnStart').textContent = pass ? '▶ BAŞLAT' : '▶ TEKRAR DEN';
    dbKaydet(pass);
  }

  function toast(msg) {
    var el=document.createElement('div');
    el.style.cssText='position:fixed;bottom:24px;right:24px;background:#1E3A5F;color:#fff;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:700;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,.2);max-width:320px';
    el.textContent=msg;
    document.body.appendChild(el);
    setTimeout(function(){ el.remove(); },3000);
  }

  // ── Public API ──
  return {
    connect,
    disconnect,
    start: function(){
      var proto = $('htProtocol').value;
      if (!connected && proto!=='mock') { toast('Önce cihaza bağlanın!'); return; }
      if (proto==='mock' && !mockProductPlaced) { toast('⚠ Hortumu yerleştirin!'); return; }
      if (proto!=='mock' && !productDetected) { toast('⚠ Hortum algılanamıyor!'); return; }
      _stage1Data=_stage2Data=null;
      _testStart=_stageStart=Date.now();
      running=true;
      $('htBtnStart').disabled=true;
      $('htBtnStart').style.background='#94A3B8';
      $('htBtnStop').style.display='block';
      $('htRes1').style.display=$('htRes2').style.display='none';
      setGauge(0); setFlow(null); setLamp(null);
      setStatus('running','Piston aşağı iniyor, hortum kapatılıyor...');
      setTab(1,'active'); setTab(2,'');
      if (proto==='mock') {
        setTimeout(function(){ runMockStage1(); },600);
      } else {
        var p = P();
        sendCmd('START_STAGE1', {
          target : p.hedef,
          hold   : p.bekle,
          leak   : p.kacak,
          minFlow: p.akis
        });
      }
    },
    stop: function(){
      running=false; clearInterval(mockInt);
      setPiston(false); setLamp(null);
      setStatus('idle','Test durduruldu');
      setProgress(0,'Durduruldu');
      $('htBtnStart').disabled=!productDetected;
      $('htBtnStop').style.display='none';
      $('htBtnStart').textContent='▶ BAŞLAT';
      $('htBtnStart').style.background='#22C55E';
      sendCmd('STOP',{});
    },
    reset: function(){
      this.stop();
      setGauge(0); setFlow(null); setLamp(null);
      setTab(1,'active'); setTab(2,'');
      setHoseViz(0,'');
      setPiston(false);
      $('htRes1').style.display=$('htRes2').style.display='none';
      setStatus('idle','Teste başlamak için Başlat butonuna basın');
      setProgress(0,'Hazır');
    },
    toggleMockProduct: function(){
      mockProductPlaced = !mockProductPlaced;
      setProduct(mockProductPlaced);
    },
    loadRecete: function(id){
      var sel=$('htReceteSelect');
      var opt=Array.from(sel.options).find(o=>o.value==id);
      if (!opt) return;
      $('htHedefBar').value  = opt.dataset.p;
      $('htKacakEsigi').value= opt.dataset.l;
      $('htBekleSure').value = opt.dataset.h;
      $('htMinAkis').value   = opt.dataset.f;
    }
  };
})();

// ── Protokol değişince alanları göster/gizle ──
function htProtocolChange(){
  var v = document.getElementById('htProtocol').value;
  document.getElementById('htWsFields').style.display    = v==='ws' ? 'flex' : 'none';
  document.getElementById('htBtnMockProd2').style.display = 'none';
  // Not bilgisini güncelle
  var note = document.getElementById('htConnNote');
  if (v === 'mock') {
    note.style.display = 'block';
    note.innerHTML = '🔧 <b>Simülasyon modu:</b> Gerçek cihaz gerekmez. '
      + '"Bağlan" butonuna basın, ardından <b>📦 Ürün Koy/Kaldır</b> ile sensörü simüle edin.';
  } else if (v === 'ws') {
    note.style.display = 'block';
    note.innerHTML = '🌐 <b>WebSocket modu:</b> Node.js server otomatik başlatılır. '
      + 'MOXA IP alanına <b>MOXA E1212 cihazının fabrika ağındaki IP adresini</b> girin. '
      + 'Modbus TCP portu genellikle <code>502</code>dir.';
  } else {
    note.style.display = 'none';
  }
}

// ── WS URL otomatik oluştur ──
function htBuildWsUrl(){
  // WS URL değiştirilebilir, otomatik build yok
}

// ── İlk yükleme ──
(function(){
  htProtocolChange(); // notu ve alanları ilk açılışta göster
  // İlk reçeteyi yükle
  var sel=document.getElementById('htReceteSelect');
  if (sel && sel.options.length) htApp.loadRecete(sel.options[0].value);
  // Geçmişi yükle
  setTimeout(function(){
    fetch(HT_BASE_URL+'/islemler/kalite/hortum_test_gecmis.php')
    .then(r=>r.json()).then(function(j){
      if (!j.ok || !j.data.length) { document.getElementById('htGecmisTbody').innerHTML='<tr><td colspan="10" style="text-align:center;color:var(--m2);padding:16px">Henüz kayıt yok</td></tr>'; return; }
      var html='';
      j.data.forEach(function(r,i){
        var gb=r.genel_sonuc=='1';
        var bg=gb?'#D1FAE5':'#FEE2E2';
        html+='<tr style="background:'+bg+'">'
          +'<td style="color:var(--m3)">'+(i+1)+'</td>'
          +'<td style="white-space:nowrap;font-size:11px">'+r.kayit_tarihi+'</td>'
          +'<td>'+(r.recete_adi||'—')+'</td>'
          +'<td style="font-size:11px">'+(r.operatör||'—')+'</td>'
          +'<td style="text-align:center">'+(r.asama1_sonuc=='1'?'✅':'❌')+'</td>'
          +'<td style="text-align:right">'+(r.asama1_dusus_bar?parseFloat(r.asama1_dusus_bar).toFixed(3):'—')+'</td>'
          +'<td style="text-align:center">'+(r.asama2_sonuc!=null?(r.asama2_sonuc=='1'?'✅':'❌'):'—')+'</td>'
          +'<td style="text-align:right">'+(r.asama2_akis_ldk?parseFloat(r.asama2_akis_ldk).toFixed(1)+' L/dk':'—')+'</td>'
          +'<td style="text-align:right">'+(r.sure_sn||'—')+' sn</td>'
          +'<td style="text-align:center;font-weight:800">'+(gb?'✅':'❌')+'</td>'
          +'</tr>';
      });
      document.getElementById('htGecmisTbody').innerHTML=html;
    }).catch(function(){ document.getElementById('htGecmisTbody').innerHTML='<tr><td colspan="10" style="text-align:center;color:var(--m2);padding:16px">Yüklenemedi</td></tr>'; });
  }, 200);
})();
</script>
