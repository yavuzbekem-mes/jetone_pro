<?php
/**
 * GKK Red Surec Takip - Kalite
 * Route: kalite-gkk-surec
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();
global $db;

// Tablolar
foreach([
"CREATE TABLE IF NOT EXISTS gkk_red_surec (id INT AUTO_INCREMENT PRIMARY KEY, gkk_id INT NOT NULL UNIQUE, irsaliye_no VARCHAR(50), stok_kodu VARCHAR(50), stok_adi VARCHAR(255) DEFAULT '', miktar DECIMAL(15,4) DEFAULT 0, birim VARCHAR(20) DEFAULT 'ADET', red_tarihi DATETIME, red_aciklama TEXT, kontrol_eden VARCHAR(100) DEFAULT '', aksiyon_tipi ENUM('BEKLIYOR','IADE','AYIKLAMA','SART_ONAY','YENI_SEVKIYAT','DIGER') DEFAULT 'BEKLIYOR', asama ENUM('RED','TEDARIKCI_BILDIRIMI','TEDARIKCI_YANITI','AKSIYON_SECIMI','GERCEKLESMIS','KAPANDI') DEFAULT 'RED', bildirim_tarihi DATETIME, bildirim_yapan VARCHAR(100) DEFAULT '', tedarikci_yanit_tarihi DATETIME, tedarikci_yanit_notu TEXT, yeni_sevkiyat_tarihi DATE, gerceklesme_tarihi DATE, gerceklesme_notu TEXT, olusturan VARCHAR(100) DEFAULT '', olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP, guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_gkk(gkk_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS gkk_red_log (id INT AUTO_INCREMENT PRIMARY KEY, surec_id INT NOT NULL, islem_tipi VARCHAR(50), eski_asama VARCHAR(50) DEFAULT '', yeni_asama VARCHAR(50) DEFAULT '', aciklama TEXT, dosya_yolu VARCHAR(500) DEFAULT '', dosya_adi VARCHAR(255) DEFAULT '', yapan VARCHAR(100) DEFAULT '', tarih DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_surec(surec_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
] as $sql) { try{$db->exec($sql);}catch(Throwable $e){} }

// JSON log istegi
if(isset($_GET['surec_id']) && isset($_GET['json'])) {
    $sid = (int)$_GET['surec_id'];
    header('Content-Type: application/json; charset=utf-8');
    try {
        $ls = $db->prepare("SELECT * FROM gkk_red_log WHERE surec_id=? ORDER BY tarih DESC");
        $ls->execute([$sid]);
        echo json_encode(['logs'=>$ls->fetchAll(PDO::FETCH_ASSOC),'surec_id'=>$sid]);
    } catch(Throwable $e){ echo json_encode(['logs'=>[],'error'=>$e->getMessage()]); }
    exit;
}

// Filtreler
$f_basl  = trim($_GET['basl']  ?? date('Y-m-d', strtotime('-3 months')));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));
$f_asama = trim($_GET['asama'] ?? '');
$f_stok  = trim($_GET['stok']  ?? '');

// Liste
$liste = [];
try {
    $w = ["g.sonuc='RED'"]; $p = [];
    if($f_basl && $f_bitis){ $w[]="DATE(g.kontrol_tarihi) BETWEEN ? AND ?"; $p[]=$f_basl; $p[]=$f_bitis; }
    if($f_stok){ $w[]="(g.stok_kodu LIKE ? OR g.irsaliye_no LIKE ?)"; $p[]="%$f_stok%"; $p[]="%$f_stok%"; }
    if($f_asama){ $w[]="COALESCE(s.asama,'RED')=?"; $p[]=$f_asama; }
    $st = $db->prepare("SELECT g.id AS gkk_id, g.irsaliye_no, g.stok_kodu, g.stok_adi,
               g.miktar, g.birim, g.kontrol_tarihi, g.kontrol_eden,
               g.aciklama AS red_aciklama, g.hata_adet, g.kontrol_adet,
               COALESCE(s.id,0) AS surec_id,
               COALESCE(s.asama,'RED') AS asama,
               COALESCE(s.aksiyon_tipi,'BEKLIYOR') AS aksiyon_tipi,
               s.bildirim_tarihi, s.tedarikci_yanit_notu, s.yeni_sevkiyat_tarihi
        FROM gkk_kontrol_sonuclari g
        LEFT JOIN gkk_red_surec s ON s.gkk_id=g.id
        WHERE ".implode(' AND ',$w)." ORDER BY g.kontrol_tarihi DESC");
    $st->execute($p);
    $liste = $st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){}

// Tedarikci bilgisi
$ted_map = [];
if(!empty($liste) && isset($tigerdb_pdo) && $tigerdb_pdo) {
    try {
        $irsno_list = array_unique(array_column($liste,'irsaliye_no'));
        $in = implode(',',array_fill(0,count($irsno_list),'?'));
        $tst = $tigerdb_pdo->prepare(
            "SELECT F.FICHENO, C.DEFINITION_ AS CARI FROM
             (SELECT FICHENO,CLIENTREF FROM LG_222_01_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1
              UNION ALL SELECT FICHENO,CLIENTREF FROM LG_222_02_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1) F
             LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF"
        );
        $tst->execute(array_merge($irsno_list,$irsno_list));
        foreach($tst->fetchAll(PDO::FETCH_ASSOC) as $r) $ted_map[$r['FICHENO']] = $r['CARI']??'';
    } catch(Throwable $e){}
}

// Asama tanimlari
$asama_def = [
    'RED'                  => ['label'=>'Red Edildi',          'bg'=>'#FEE2E2','fg'=>'#7F1D1D'],
    'TEDARIKCI_BILDIRIMI'  => ['label'=>'Bildirim Yapildi',    'bg'=>'#FEF3C7','fg'=>'#92400E'],
    'TEDARIKCI_YANITI'     => ['label'=>'Tedarikci Yaniti',    'bg'=>'#DBEAFE','fg'=>'#1E40AF'],
    'AKSIYON_SECIMI'       => ['label'=>'Aksiyon Secildi',     'bg'=>'#EDE9FE','fg'=>'#5B21B6'],
    'GERCEKLESMIS'         => ['label'=>'Gerceklesti',         'bg'=>'#D1FAE5','fg'=>'#065F46'],
    'KAPANDI'              => ['label'=>'Kapandi',             'bg'=>'#F3F4F6','fg'=>'#6B7280'],
];
$aksiyon_def = ['BEKLIYOR'=>'Bekleniyor','IADE'=>'Iade','AYIKLAMA'=>'Ayiklama','SART_ONAY'=>'Sartli Onay','YENI_SEVKIYAT'=>'Yeni Sevkiyat','DIGER'=>'Diger'];
$ozet = array_fill_keys(array_keys($asama_def),0);
foreach($liste as $r) { $k=$r['asama']??'RED'; $ozet[$k]=($ozet[$k]??0)+1; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">GKK Red Surec Takip</h1>
    <div class="s-yol">Kalite / GKK Red Surec</div>
  </div>
</div>
<div class="s-body">

<!-- Ozet kartlar -->
<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-bottom:14px">
<?php foreach($asama_def as $k=>$a):
    $sayi = $ozet[$k]??0;
    $aktif = $f_asama===$k ? 'box-shadow:0 0 0 3px '.$a['fg'].';' : '';
    $href = '?sayfa=kalite-gkk-surec&asama='.urlencode($k).'&basl='.urlencode($f_basl).'&bitis='.urlencode($f_bitis);
?>
<a href="<?=$href?>" style="background:<?=$a['bg']?>;border-radius:var(--r);padding:10px 12px;border-left:4px solid <?=$a['fg']?>;text-decoration:none;<?=$aktif?>display:block">
  <div style="font-size:10px;font-weight:700;color:<?=$a['fg']?>"><?=htmlspecialchars($a['label'])?></div>
  <div style="font-size:22px;font-weight:900;color:<?=$a['fg']?>"><?=$sayi?></div>
</a>
<?php endforeach;?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="GET" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="kalite-gkk-surec">
    <div><label class="form-et" style="font-size:11px">Baslangic</label><input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
    <div><label class="form-et" style="font-size:11px">Bitis</label><input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
    <div><label class="form-et" style="font-size:11px">Stok/Irsaliye</label><input type="text" name="stok" class="form-alan" value="<?=htmlspecialchars($f_stok)?>" placeholder="Ara..."></div>
    <div>
      <label class="form-et" style="font-size:11px">Asama</label>
      <select name="asama" class="form-alan">
        <option value="">Tumu</option>
        <?php foreach($asama_def as $k=>$a):?>
        <option value="<?=htmlspecialchars($k)?>" <?=$f_asama===$k?'selected':''?>><?=htmlspecialchars($a['label'])?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="display:flex;gap:6px">
      <button type="submit" class="btn btn-t" style="padding:10px 16px">Ara</button>
      <a href="?sayfa=kalite-gkk-surec" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">Sifirla</a>
    </div>
  </form>
</div>

<!-- Liste -->
<?php if(empty($liste)):?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)"><div>Kayit bulunamadi.</div></div>
<?php else:?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($liste as $r):
    $asama_k = $r['asama']??'RED';
    $ad = $asama_def[$asama_k]??$asama_def['RED'];
    $ka = (int)($r['kontrol_adet']??0); $ha = (int)($r['hata_adet']??0);
    $oran = $ka>0 ? round(($ha/$ka)*100,1) : null;
    $oran_renk = $oran===null?'#6B7280':($oran>=50?'#DC2626':($oran>=20?'#F59E0B':'#16A34A'));
    $ted_adi = $ted_map[$r['irsaliye_no']] ?? '';
    $gkk_id   = (int)$r['gkk_id'];
    $surec_id = (int)$r['surec_id'];
    $irsno_esc  = htmlspecialchars($r['irsaliye_no'],ENT_QUOTES);
    $stok_esc   = htmlspecialchars($r['stok_kodu'],ENT_QUOTES);
?>
<div class="kart" style="padding:0;overflow:hidden;border-left:5px solid <?=$ad['fg']?>">
  <div style="padding:10px 14px;background:<?=$ad['bg']?>20;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="display:flex;align-items:center;gap:10px">
      <span style="background:<?=$ad['bg']?>;color:<?=$ad['fg']?>;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:800"><?=htmlspecialchars($a['label']??$ad['label'])?></span>
      <span style="font-weight:800;font-family:monospace;font-size:12px"><?=htmlspecialchars($r['irsaliye_no'])?></span>
      <span style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($ted_adi)?></span>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <span style="font-size:11px;color:var(--m3)"><?=htmlspecialchars(substr($r['kontrol_tarihi']??'',0,10))?></span>
      <button type="button"
              data-gkk="<?=$gkk_id?>"
              data-surec="<?=$surec_id?>"
              data-irsno="<?=$irsno_esc?>"
              data-stok="<?=$stok_esc?>"
              onclick="surec_ac(this)"
              style="padding:4px 12px;background:#4F46E5;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
        Surec
      </button>
    </div>
  </div>
  <div style="padding:10px 14px;display:grid;grid-template-columns:2fr 1fr 1fr 1fr 2fr;gap:10px;font-size:12px">
    <div>
      <div style="font-size:10px;color:var(--m3);font-weight:700">STOK</div>
      <div style="font-family:monospace;font-weight:700"><?=htmlspecialchars($r['stok_kodu']??'')?></div>
      <div style="font-size:11px;color:var(--m2)"><?=htmlspecialchars(mb_substr($r['stok_adi']??'',0,35))?></div>
    </div>
    <div>
      <div style="font-size:10px;color:var(--m3);font-weight:700">MIKTAR</div>
      <div style="font-weight:700"><?=number_format((float)($r['miktar']??0),0)?> <?=htmlspecialchars($r['birim']??'')?></div>
    </div>
    <div>
      <div style="font-size:10px;color:var(--m3);font-weight:700">KONTROL</div>
      <?php if($ka>0):?>
      <div><?=$ka?> adet</div>
      <div style="color:#DC2626;font-weight:700">Hata: <?=$ha?></div>
      <?php else:?><div style="color:var(--m3)">--</div><?php endif;?>
    </div>
    <div>
      <div style="font-size:10px;color:var(--m3);font-weight:700">HATA ORANI</div>
      <?php if($oran!==null):?>
      <div style="font-weight:900;color:<?=$oran_renk?>;font-size:14px">%<?=$oran?></div>
      <?php else:?><div style="color:var(--m3)">--</div><?php endif;?>
    </div>
    <div>
      <div style="font-size:10px;color:var(--m3);font-weight:700">SON DURUM</div>
      <div style="font-size:11px"><?=htmlspecialchars($asama_def[$asama_k]['label'])?></div>
      <?php if(!empty($r['tedarikci_yanit_notu'])):?>
      <div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars(mb_substr($r['tedarikci_yanit_notu'],0,40))?></div>
      <?php endif;?>
      <?php if(!empty($r['yeni_sevkiyat_tarihi'])):?>
      <div style="font-size:10px;color:#16A34A;font-weight:700">Sevk: <?=htmlspecialchars($r['yeni_sevkiyat_tarihi'])?></div>
      <?php endif;?>
    </div>
  </div>
</div>
<?php endforeach;?>
</div>
<?php endif;?>
</div>

<!-- Surec Modal -->
<div id="surec-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.5);z-index:99000;align-items:flex-start;justify-content:center;padding-top:60px;overflow-y:auto">
  <div style="background:#fff;border-radius:12px;width:680px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.3);margin-bottom:40px">
    <div style="padding:16px 20px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-weight:800;font-size:15px" id="sm-baslik">Surec</div>
        <div style="font-size:12px;color:var(--m3)" id="sm-alt"></div>
      </div>
      <button onclick="document.getElementById('surec-modal').style.display='none'" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--m3)">X</button>
    </div>
    <!-- Adimlar -->
    <div style="padding:12px 20px;border-bottom:1px solid var(--kenar);display:flex;gap:6px;flex-wrap:wrap" id="sm-adimlar"></div>
    <!-- Form -->
    <div style="padding:16px 20px;min-height:80px" id="sm-form"></div>
    <!-- Log -->
    <div style="border-top:1px solid var(--kenar)">
      <div style="padding:8px 20px;font-size:11px;font-weight:700;color:var(--m3);text-transform:uppercase">Surec Gecmisi</div>
      <div id="sm-log" style="max-height:200px;overflow-y:auto;padding:0 20px 14px;font-size:11px"></div>
    </div>
  </div>
</div>

<script>
var SUREC_BASE = <?=json_encode(BASE_URL)?>;
var SUREC_SAYFA = <?=json_encode('kalite-gkk-surec')?>;
var SM_DATA = {gkk_id:0, surec_id:0, irsno:'', stok:''};

function surec_ac(btn) {
    SM_DATA.gkk_id   = parseInt(btn.getAttribute('data-gkk'));
    SM_DATA.surec_id = parseInt(btn.getAttribute('data-surec'));
    SM_DATA.irsno    = btn.getAttribute('data-irsno');
    SM_DATA.stok     = btn.getAttribute('data-stok');
    document.getElementById('sm-baslik').textContent = SM_DATA.irsno + ' / ' + SM_DATA.stok;
    document.getElementById('sm-alt').textContent    = 'GKK: ' + SM_DATA.gkk_id;
    document.getElementById('sm-form').innerHTML     = '';
    document.getElementById('sm-log').innerHTML      = 'Yukleniyor...';
    document.getElementById('surec-modal').style.display = 'flex';
    surec_adimlar();
    surec_log();
}

function surec_adimlar() {
    var btns = SM_DATA.surec_id === 0
        ? [{a:'surec_baslat', t:'Surec Baslat'}]
        : [
            {a:'bildirim',         t:'Bildirim Yap'},
            {a:'tedarikci_yanit',  t:'Tedarikci Yaniti'},
            {a:'aksiyon',          t:'Aksiyon Sec'},
            {a:'gerceklesme',      t:'Gerceklesme'},
            {a:'not_ekle',         t:'Not Ekle'},
            {a:'kapat',            t:'Kapat'}
          ];
    document.getElementById('sm-adimlar').innerHTML = btns.map(function(b){
        return '<button type="button" onclick="surec_form(\'' + b.a + '\')" style="padding:5px 10px;border:1px solid var(--kenar);border-radius:5px;background:#fff;font-size:11px;cursor:pointer">' + b.t + '</button>';
    }).join('');
}

function surec_form(action) {
    var el = document.getElementById('sm-form');
    var h = '';
    if (action === 'surec_baslat') {
        h = '<button onclick="surec_kaydet(\'surec_baslat\')" style="padding:9px 18px;background:#DC2626;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer">Surec Baslat</button>';
    } else if (action === 'bildirim') {
        h  = '<label class="form-et">Bildirim Notu</label>';
        h += '<textarea id="f-not" class="form-alan" rows="3" placeholder="Bildirilen detaylar..."></textarea>';
        h += '<label class="form-et" style="margin-top:8px">Belge (opsiyonel)</label>';
        h += '<input type="file" id="f-belge" class="form-alan">';
        h += '<button onclick="surec_kaydet(\'bildirim_yap\')" style="margin-top:8px;padding:9px 18px;background:#F59E0B;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Bildirimi Kaydet</button>';
    } else if (action === 'tedarikci_yanit') {
        h  = '<label class="form-et">Tedarikci Yaniti</label>';
        h += '<textarea id="f-yanit" class="form-alan" rows="3" placeholder="Tedarikci yaniti..."></textarea>';
        h += '<label class="form-et" style="margin-top:8px">Yeni Sevkiyat Tarihi (varsa)</label>';
        h += '<input type="date" id="f-sevk" class="form-alan">';
        h += '<label class="form-et" style="margin-top:8px">Belge (opsiyonel)</label>';
        h += '<input type="file" id="f-belge2" class="form-alan">';
        h += '<button onclick="surec_kaydet(\'tedarikci_yaniti\')" style="margin-top:8px;padding:9px 18px;background:#3B82F6;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Yaniti Kaydet</button>';
    } else if (action === 'aksiyon') {
        h  = '<label class="form-et">Aksiyon Turu</label>';
        h += '<select id="f-aksiyon" class="form-alan"><option value="IADE">Iade</option><option value="AYIKLAMA">Ayiklama</option><option value="SART_ONAY">Sartli Onay</option><option value="YENI_SEVKIYAT">Yeni Sevkiyat</option><option value="DIGER">Diger</option></select>';
        h += '<textarea id="f-aksiyon-not" class="form-alan" rows="2" placeholder="Detay..." style="margin-top:6px"></textarea>';
        h += '<button onclick="surec_kaydet(\'aksiyon_sec\')" style="margin-top:8px;padding:9px 18px;background:#8B5CF6;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Aksiyon Kaydet</button>';
    } else if (action === 'gerceklesme') {
        h  = '<label class="form-et">Gerceklesme Tarihi</label>';
        h += '<input type="date" id="f-gtarih" class="form-alan">';
        h += '<textarea id="f-gnot" class="form-alan" rows="2" placeholder="Detay..." style="margin-top:6px"></textarea>';
        h += '<button onclick="surec_kaydet(\'gerceklesme\')" style="margin-top:8px;padding:9px 18px;background:#16A34A;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Gerceklesmeni Kaydet</button>';
    } else if (action === 'not_ekle') {
        h  = '<textarea id="f-snot" class="form-alan" rows="3" placeholder="Serbest not..."></textarea>';
        h += '<input type="file" id="f-belge3" class="form-alan" style="margin-top:6px">';
        h += '<button onclick="surec_kaydet(\'not_ekle\')" style="margin-top:8px;padding:9px 18px;background:#6B7280;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Not Ekle</button>';
    } else if (action === 'kapat') {
        h  = '<textarea id="f-knot" class="form-alan" rows="2" placeholder="Kapanis notu..."></textarea>';
        h += '<button onclick="surec_kaydet(\'kapat\')" style="margin-top:8px;padding:9px 18px;background:#374151;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Sureci Kapat</button>';
    }
    el.innerHTML = h;
}

function g(id) { var e=document.getElementById(id); return e?e.value:''; }

function surec_kaydet(action) {
    var fd = new FormData();
    fd.append('action',   action);
    fd.append('gkk_id',   SM_DATA.gkk_id);
    fd.append('surec_id', SM_DATA.surec_id);
    if (action === 'bildirim_yap')    { fd.append('aciklama', g('f-not')); var b=document.getElementById('f-belge'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action === 'tedarikci_yaniti'){ fd.append('yanit', g('f-yanit')); fd.append('sevk_tarihi', g('f-sevk')); var b=document.getElementById('f-belge2'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action === 'aksiyon_sec')     { fd.append('aksiyon_tipi', g('f-aksiyon')); fd.append('aciklama', g('f-aksiyon-not')); }
    if (action === 'gerceklesme')     { fd.append('not', g('f-gnot')); fd.append('tarih', g('f-gtarih')); }
    if (action === 'not_ekle')        { fd.append('aciklama', g('f-snot')); var b=document.getElementById('f-belge3'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action === 'kapat')           { fd.append('not', g('f-knot')); }

    fetch(SUREC_BASE + '/islemler/kalite/gkk_surec_kaydet.php', {method:'POST', body:fd})
    .then(function(r){ return r.text().then(function(t){ try{return JSON.parse(t);}catch(e){throw new Error(t.substring(0,200));} }); })
    .then(function(d){
        if (d.success) {
            if (d.surec_id) SM_DATA.surec_id = d.surec_id;
            document.getElementById('sm-form').innerHTML = '<div style="color:#16A34A;font-weight:700;padding:10px">Kaydedildi.</div>';
            surec_adimlar();
            surec_log();
        } else {
            alert('Hata: ' + d.message);
        }
    })
    .catch(function(e){ alert('Hata: ' + e.message); });
}

function surec_log() {
    if (!SM_DATA.surec_id) {
        document.getElementById('sm-log').innerHTML = 'Henuz surec baslatilmamis.';
        return;
    }
    fetch(SUREC_BASE + '/islemler/kalite/gkk_surec_kaydet.php?surec_id=' + SM_DATA.surec_id)
    .then(function(r){ return r.json(); })
    .then(function(d){
        var logs = d.logs || [];
        if (!logs.length) { document.getElementById('sm-log').innerHTML = 'Log yok.'; return; }
        document.getElementById('sm-log').innerHTML = logs.map(function(l){
            return '<div style="border-left:3px solid var(--kenar);padding:5px 8px;margin-bottom:6px">'
                + '<b>' + (l.islem_tipi||'') + '</b>'
                + (l.yeni_asama ? ' -&gt; ' + l.yeni_asama : '')
                + (l.aciklama ? '<div>' + l.aciklama + '</div>' : '')
                + (l.dosya_adi ? '<div style="color:#4F46E5">Belge: ' + l.dosya_adi + '</div>' : '')
                + '<div style="color:var(--m3)">' + (l.yapan||'') + ' - ' + (l.tarih||'') + '</div>'
                + '</div>';
        }).join('');
    })
    .catch(function(){ document.getElementById('sm-log').innerHTML = 'Log yuklenemedi.'; });
}

document.getElementById('surec-modal').addEventListener('click', function(e){
    if (e.target === this) this.style.display = 'none';
});
</script>
