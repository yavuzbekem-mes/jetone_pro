<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$db->exec("CREATE TABLE IF NOT EXISTS kal_sekizd (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sekizd_no VARCHAR(30) UNIQUE NOT NULL,
    kaynak ENUM('musteri_sikayet','ic_denetim','urun_hatasi','proses_hatasi','tedarikci','diger') DEFAULT 'diger',
    kaynak_ref VARCHAR(100),
    problem_ozeti TEXT NOT NULL,
    acilis_tarihi DATE NOT NULL,
    hedef_tarih DATE,
    kapanma_tarihi DATE,
    durum ENUM('d1','d2','d3','d4','d5','d6','d7','d8','kapandi','iptal') DEFAULT 'd1',
    kritiklik ENUM('dusuk','orta','yuksek','kritik') DEFAULT 'orta',
    d1_ekip TEXT, d1_lider VARCHAR(100),
    d2_problem TEXT, d2_etkilenen_urun VARCHAR(200), d2_etkilenen_adet VARCHAR(100),
    d3_gecici_onlem TEXT, d3_stok_blokaj TEXT, d3_musteri_bildirim TEXT, d3_uygulama_tarihi DATE,
    d4_kok_neden TEXT, d4_kacis_nokta TEXT,
    d4_balik_insan TEXT, d4_balik_yontem TEXT, d4_balik_makine TEXT,
    d4_balik_malzeme TEXT, d4_balik_olcum TEXT, d4_balik_cevre TEXT,
    d5_secenekler TEXT, d5_secilen TEXT,
    d6_uygulama TEXT, d6_olcum_sonuc TEXT, d6_sorumlu VARCHAR(100), d6_tamamlanma DATE,
    d7_sistem_degisim TEXT, d7_egitim TEXT, d7_yayilim TEXT,
    d8_tebrik TEXT, d8_kapanma_onay VARCHAR(100), d8_kapanma_notu TEXT,
    olusturan VARCHAR(100),
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS kal_sekizd_dokuman (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sekizd_id INT UNSIGNED NOT NULL,
    adim VARCHAR(5),
    dosya_adi VARCHAR(255),
    dosya_yolu VARCHAR(500),
    tur ENUM('foto','rapor','olcum','prosedur','diger') DEFAULT 'diger',
    aciklama VARCHAR(255),
    yukleyen VARCHAR(100),
    yuklenme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sekizd_id) REFERENCES kal_sekizd(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$f_durum = $_GET['durum'] ?? '';
$where = "WHERE 1=1"; $params = [];
if ($f_durum) { $where .= " AND durum=?"; $params[] = $f_durum; }

$stmt = $db->prepare("SELECT s.*, COUNT(dk.id) AS dok_sayisi
    FROM kal_sekizd s LEFT JOIN kal_sekizd_dokuman dk ON dk.sekizd_id=s.id
    $where GROUP BY s.id ORDER BY
    CASE s.durum WHEN 'd1' THEN 1 WHEN 'd2' THEN 2 WHEN 'd3' THEN 3 WHEN 'd4' THEN 4
    WHEN 'd5' THEN 5 WHEN 'd6' THEN 6 WHEN 'd7' THEN 7 WHEN 'd8' THEN 8
    WHEN 'kapandi' THEN 9 ELSE 10 END, s.acilis_tarihi DESC");
$stmt->execute($params);
$kayitlar = $stmt->fetchAll(PDO::FETCH_ASSOC);

$oz = $db->query("SELECT COUNT(*) toplam, SUM(durum NOT IN ('kapandi','iptal')) devam,
    SUM(durum='kapandi') kapandi,
    SUM(durum NOT IN('kapandi','iptal') AND hedef_tarih < CURDATE()) gecikti
    FROM kal_sekizd")->fetch(PDO::FETCH_ASSOC);

$adimlar = ['d1'=>'D1 Ekip','d2'=>'D2 Problem','d3'=>'D3 Koruma','d4'=>'D4 Kök Neden',
    'd5'=>'D5 Seçim','d6'=>'D6 Uygulama','d7'=>'D7 Önleme','d8'=>'D8 Kapanış','kapandi'=>'Kapandı','iptal'=>'İptal'];
$kaynak_etiket = ['musteri_sikayet'=>'👤 Müşteri Şikayeti','ic_denetim'=>'🔍 İç Denetim',
    'urun_hatasi'=>'🔧 Ürün Hatası','proses_hatasi'=>'⚙️ Proses Hatası','tedarikci'=>'🚛 Tedarikçi','diger'=>'📌 Diğer'];
?>
<div class="s-bar">
  <div><h1 class="s-bas">8️⃣ 8D Problem Çözme</h1><div class="s-yol">Kalite / <b>8D Sekiz Disiplin</b></div></div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-form" class="btn btn-t btn-sm">+ Yeni 8D Aç</a>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php foreach([
    ['📋','Toplam',$oz['toplam']??0,'#1E3A5F','#EFF6FF'],
    ['⏳','Devam',$oz['devam']??0,'#0EA5E9','#F0F9FF'],
    ['✅','Kapandı',$oz['kapandi']??0,'#16A34A','#F0FDF4'],
    ['⚠️','Gecikti',$oz['gecikti']??0,'#DC2626','#FEF2F2'],
  ] as $k): ?>
  <div class="kart" style="padding:12px;border-left:3px solid <?=$k[3]?>;background:<?=$k[4]?>;text-align:center">
    <div style="font-size:20px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700"><?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;display:flex;gap:10px;align-items:center">
  <span style="font-size:12px;font-weight:700;color:var(--m2)">Adım:</span>
  <select class="form-alan" style="font-size:12px;padding:4px 8px" onchange="var u=new URL(window.location.href);u.searchParams.set('sayfa','kalite-8d');u.searchParams.set('durum',this.value);window.location.href=u.href">
    <option value="">Tümü</option>
    <?php foreach($adimlar as $v=>$l): ?>
    <option value="<?=$v?>" <?=$f_durum===$v?'selected':''?>><?=$l?></option>
    <?php endforeach; ?>
  </select>
  <span style="margin-left:auto;font-size:12px;color:var(--m2)"><?=count($kayitlar)?> kayıt</span>
</div>
<?php if(empty($kayitlar)): ?>
<div class="kart" style="padding:50px;text-align:center;color:var(--m3)">
  <div style="font-size:44px;margin-bottom:12px">8️⃣</div>
  <div style="font-size:14px;font-weight:700;margin-bottom:10px">8D kaydı yok</div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-form" class="btn btn-t">+ Yeni 8D Aç</a>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($kayitlar as $r):
  $adim_no = (int)(preg_match('/^d(\d)$/', $r['durum'], $mm) ? $mm[1] : 0);
  $gecikti = !in_array($r['durum'],['kapandi','iptal']) && $r['hedef_tarih'] && $r['hedef_tarih'] < date('Y-m-d');
?>
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
    <div style="min-width:140px">
      <div style="font-weight:900;font-size:14px;font-family:monospace"><?=htmlspecialchars($r['sekizd_no'])?></div>
      <div style="display:flex;gap:2px;margin-top:5px">
        <?php for($i=1;$i<=8;$i++):
          $bg = ($adim_no >= $i) ? '#1E3A5F' : 'var(--kenar)';
          $fg = ($adim_no >= $i) ? '#fff' : 'var(--m3)';
        ?>
        <div style="width:16px;height:16px;border-radius:3px;font-size:8px;font-weight:700;display:flex;align-items:center;justify-content:center;background:<?=$bg?>;color:<?=$fg?>"><?=$i?></div>
        <?php endfor; ?>
        <?php if($r['durum']==='kapandi'): ?>
        <div style="width:24px;height:16px;border-radius:3px;font-size:8px;font-weight:700;display:flex;align-items:center;justify-content:center;background:#16A34A;color:#fff">✓</div>
        <?php endif; ?>
      </div>
    </div>
    <div style="flex:1;min-width:200px">
      <div style="font-size:14px;font-weight:700;color:var(--t);margin-bottom:3px"><?=htmlspecialchars(mb_strimwidth($r['problem_ozeti'],0,80,'…'))?></div>
      <div style="display:flex;gap:12px;font-size:11px;color:var(--m2);flex-wrap:wrap">
        <span><?=htmlspecialchars($kaynak_etiket[$r['kaynak']] ?? '📌')?></span>
        <span>📅 <?=date('d.m.Y',strtotime($r['acilis_tarihi']))?></span>
        <?php if($r['d1_lider']): ?><span>👤 <?=htmlspecialchars($r['d1_lider'])?></span><?php endif; ?>
        <?php if($r['hedef_tarih']): ?>
        <span style="color:<?=$gecikti?'#DC2626':'var(--m2)'?>">🏁 <?=date('d.m.Y',strtotime($r['hedef_tarih']))?></span>
        <?php endif; ?>
        <span style="font-weight:700;color:<?=$r['durum']==='kapandi'?'#16A34A':'#0EA5E9'?>"><?=htmlspecialchars($adimlar[$r['durum']] ?? '?')?></span>
        <?php if($gecikti): ?><span style="color:#DC2626;font-weight:700">⚠️ GECİKTİ</span><?php endif; ?>
        <?php if($r['dok_sayisi']>0): ?><span>📎 <?=$r['dok_sayisi']?></span><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;gap:6px">
      <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-detay&id=<?=$r['id']?>" class="btn btn-t btn-sm" style="font-size:11px;padding:5px 12px">📋 Detay</a>
      <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-8d-form&id=<?=$r['id']?>" class="btn btn-b btn-sm" style="font-size:11px;padding:5px 10px">✏️</a>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
