<?php
/**
 * Denetim Detay — Bulgular + Dokümanlar
 * panel.php: 'kalite-denetim-detay' => 'bolumler/kalite/denetim_detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-denetim';</script>"; exit; }

$stmt = $db->prepare("SELECT * FROM kal_denetim WHERE id=?");
$stmt->execute([$id]);
$d = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$d) { echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-denetim';</script>"; exit; }

$mesaj=''; $mesaj_tip='';

// ── Bulgu CRUD ────────────────────────────────────────────
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'bulgu_ekle': case 'bulgu_guncelle':
            $bid = (int)($_POST['bulgu_id']??0);
            $data = [$_POST['bulgu_tanimi'],$_POST['bulgu_turu'],$_POST['standart_madde']??'',$_POST['kok_neden']??'',$_POST['dof_aksiyon']??'',$_POST['sorumlu']??'',$_POST['hedef_tarih']?:null,$_POST['durum']];
            if ($bid) {
                $db->prepare("UPDATE kal_denetim_bulgu SET bulgu_tanimi=?,bulgu_turu=?,standart_madde=?,kok_neden=?,dof_aksiyon=?,sorumlu=?,hedef_tarih=?,durum=? WHERE id=? AND denetim_id=?")
                   ->execute([...$data,$bid,$id]);
                // Tamamlandı ise tarihi yaz
                if ($_POST['durum']==='tamamlandi') $db->prepare("UPDATE kal_denetim_bulgu SET tamamlanma_tarihi=CURDATE(),dogrulayan=? WHERE id=? AND tamamlanma_tarihi IS NULL")->execute([$kul_adi,$bid]);
                $mesaj='Bulgu güncellendi.';
            } else {
                $son_no = $db->prepare("SELECT COUNT(*)+1 FROM kal_denetim_bulgu WHERE denetim_id=?"); $son_no->execute([$id]);
                $bulgu_no = $d['denetim_kodu'].'-B'.str_pad($son_no->fetchColumn(),2,'0',STR_PAD_LEFT);
                $db->prepare("INSERT INTO kal_denetim_bulgu (denetim_id,bulgu_no,bulgu_tanimi,bulgu_turu,standart_madde,kok_neden,dof_aksiyon,sorumlu,hedef_tarih,durum) VALUES (?,?,?,?,?,?,?,?,?,?)")
                   ->execute([$id,$bulgu_no,...$data]);
                $mesaj='Bulgu eklendi.';
            }
            $mesaj_tip='ok'; break;

        case 'bulgu_sil':
            $db->prepare("DELETE FROM kal_denetim_bulgu WHERE id=? AND denetim_id=?")->execute([(int)$_POST['bulgu_id'],$id]);
            $mesaj='Bulgu silindi.'; $mesaj_tip='ok'; break;

        case 'durum_guncelle':
            $db->prepare("UPDATE kal_denetim SET genel_durum=? WHERE id=?")->execute([$_POST['genel_durum'],$id]);
            $d['genel_durum'] = $_POST['genel_durum'];
            $mesaj='Durum güncellendi.'; $mesaj_tip='ok'; break;

        case 'denetim_sil':
            try {
                // Doküman dosyalarını fiziksel sil
                $dok_list = $db->prepare("SELECT dosya_yolu FROM kal_denetim_dokuman WHERE denetim_id=?");
                $dok_list->execute([$id]);
                foreach ($dok_list->fetchAll(PDO::FETCH_COLUMN) as $yol) {
                    $f = dirname(dirname(__DIR__)).'/'.$yol;
                    if (file_exists($f)) @unlink($f);
                }
                $db->prepare("DELETE FROM kal_denetim WHERE id=?")->execute([$id]);
                echo "<script>window.location.href='".BASE_URL."/panel.php?sayfa=kalite-denetim';</script>";
                exit;
            } catch(Throwable $e){ $mesaj='Silinemedi: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
    }
}

// ── Doküman yükleme ───────────────────────────────────────
if (isset($_FILES['dosya']) && $_FILES['dosya']['error']===0) {
    $uploadDir = dirname(dirname(__DIR__)).'/uploads/denetim/'.$id.'/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    $ext      = strtolower(pathinfo($_FILES['dosya']['name'],PATHINFO_EXTENSION));
    $izin     = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','gif','zip'];
    if (in_array($ext,$izin)) {
        $dosya_adi  = time().'_'.preg_replace('/[^a-z0-9._-]/i','_',$_FILES['dosya']['name']);
        $hedef      = $uploadDir.$dosya_adi;
        if (move_uploaded_file($_FILES['dosya']['tmp_name'],$hedef)) {
            $db->prepare("INSERT INTO kal_denetim_dokuman (denetim_id,bulgu_id,dosya_adi,dosya_yolu,dosya_turu,aciklama,yukleyen) VALUES (?,?,?,?,?,?,?)")
               ->execute([$id,$_POST['bulgu_id_dok']??null,$_FILES['dosya']['name'],'uploads/denetim/'.$id.'/'.$dosya_adi,$_POST['dosya_turu']??'diger',$_POST['dok_aciklama']??'',$kul_adi]);
            $mesaj='Doküman yüklendi.'; $mesaj_tip='ok';
        }
    } else { $mesaj='Desteklenmeyen dosya türü.'; $mesaj_tip='hata'; }
}

// ── Doküman sil ───────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action']==='dok_sil') {
    $dok = $db->prepare("SELECT * FROM kal_denetim_dokuman WHERE id=? AND denetim_id=?");
    $dok->execute([(int)$_POST['dok_id'],$id]);
    $dok = $dok->fetch(PDO::FETCH_ASSOC);
    if ($dok) {
        $path = dirname(dirname(__DIR__)).'/'.$dok['dosya_yolu'];
        if (file_exists($path)) @unlink($path);
        $db->prepare("DELETE FROM kal_denetim_dokuman WHERE id=?")->execute([$dok['id']]);
        $mesaj='Doküman silindi.'; $mesaj_tip='ok';
    }
}

// ── Veri yükle ────────────────────────────────────────────
$bulgular  = $db->prepare("SELECT * FROM kal_denetim_bulgu WHERE denetim_id=? ORDER BY id")->execute([$id]) ? [] : [];
$stmt2 = $db->prepare("SELECT * FROM kal_denetim_bulgu WHERE denetim_id=? ORDER BY id"); $stmt2->execute([$id]); $bulgular=$stmt2->fetchAll(PDO::FETCH_ASSOC);
$stmt3 = $db->prepare("SELECT * FROM kal_denetim_dokuman WHERE denetim_id=? ORDER BY yuklenme_tarihi DESC"); $stmt3->execute([$id]); $dokumanlar=$stmt3->fetchAll(PDO::FETCH_ASSOC);

$tur_etiket = ['ic_denetim'=>'İç Denetim','tedarikci'=>'Tedarikçi','iso_9001'=>'ISO 9001','musteri'=>'Müşteri','proses'=>'Proses','diger'=>'Diğer'];
$durum_stil = ['planlandi'=>['#6B7280','#F1F5F9','Planlandı'],'devam_ediyor'=>['#D97706','#FFFBEB','Devam Ediyor'],'tamamlandi'=>['#16A34A','#F0FDF4','Tamamlandı'],'iptal'=>['#94A3B8','#F8FAFC','İptal']];
$bulgu_stil = ['buyuk_uygunsuzluk'=>['#DC2626','#FEF2F2','Büyük Uyg.'],'kucuk_uygunsuzluk'=>['#D97706','#FFFBEB','Küçük Uyg.'],'gozlem'=>['#2563EB','#EFF6FF','Gözlem'],'iyilestirme'=>['#7C3AED','#F5F3FF','İyileştirme']];
$bdur_stil  = ['acik'=>['#EF4444','Açık'],'devam_ediyor'=>['#F59E0B','Devam'],'tamamlandi'=>['#22C55E','Tamamlandı'],'gecikti'=>['#DC2626','Gecikti'],'kapandi'=>['#6B7280','Kapandı']];
$ds = $durum_stil[$d['genel_durum']] ?? ['#6B7280','#F1F5F9','?'];
$dok_turu_etiket = ['denetim_raporu'=>'📄 Denetim Raporu','kanit'=>'🖼️ Kanıt','dof'=>'📋 DÖF','foto'=>'📷 Fotoğraf','diger'=>'📎 Diğer'];

// Özet
$b_acik = count(array_filter($bulgular,fn($b)=>in_array($b['durum'],['acik','devam_ediyor'])));
$b_tam  = count(array_filter($bulgular,fn($b)=>in_array($b['durum'],['tamamlandi','kapandi'])));
$b_gec  = count(array_filter($bulgular,fn($b)=>$b['durum']==='gecikti'||($b['durum']==='acik'&&$b['hedef_tarih']&&$b['hedef_tarih']<date('Y-m-d'))));
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔍 <?=htmlspecialchars($d['denetim_kodu'])?></h1>
    <div class="s-yol">Kalite / <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim" style="color:var(--t)">Denetimler</a> / <b><?=htmlspecialchars($d['denetim_kodu'])?></b></div>
  </div>
  <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="durum_guncelle">
      <select name="genel_durum" class="form-alan" style="font-size:12px;padding:4px 8px" onchange="this.form.submit()">
        <?php foreach(['planlandi'=>'Planlandı','devam_ediyor'=>'Devam Ediyor','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'] as $v=>$l): ?>
        <option value="<?=$v?>" <?=$d['genel_durum']===$v?'selected':''?>><?=$l?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim-form&id=<?=$id?>" class="btn btn-b btn-sm">✏️ Düzenle</a>
    <?php
      $sil_kod  = htmlspecialchars($d['denetim_kodu']);
      $sil_bcnt = count($bulgular);
      $sil_dcnt = count($dokumanlar);
    ?>
    <button id="silBtn"
      data-kod="<?=$sil_kod?>"
      data-bcnt="<?=$sil_bcnt?>"
      data-dcnt="<?=$sil_dcnt?>"
      class="btn btn-sm" style="background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;font-size:12px;padding:5px 12px">
      🗑️ Sil
    </button>
    <a href="<?=BASE_URL?>/panel.php?sayfa=kalite-denetim" class="btn btn-b btn-sm">← Geri</a>
  </div>
</div>

<div class="s-body">
<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>"><?=htmlspecialchars($mesaj)?></div>
<?php endif; ?>

<!-- Başlık Kartı -->
<?php
  $ds0 = $ds[0];
  $ds1 = $ds[1];
  $ds2 = $ds[2];
  $pct_val = count($bulgular)>0 ? round(count(array_filter($bulgular,fn($b)=>in_array($b['durum'],['tamamlandi','kapandi'])))/count($bulgular)*100) : 0;
?>
<div class="kart" style="padding:14px 18px;margin-bottom:14px;border-left:4px solid <?=$ds0?>">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
    <div>
      <div style="font-size:15px;font-weight:800;color:var(--t);margin-bottom:6px"><?=htmlspecialchars($d['denetim_konusu'])?></div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--m2)">
        <span>🗂️ <?=$tur_etiket[$d['denetim_turu']]??htmlspecialchars($d['denetim_turu'])?></span>
        <?php if($d['denetim_tarihi']): ?><span>📅 <?=date('d.m.Y',strtotime($d['denetim_tarihi']))?></span><?php endif; ?>
        <?php if($d['denetci_adi']): ?><span>👤 <?=htmlspecialchars($d['denetci_adi'])?></span><?php endif; ?>
        <?php if($d['denetlenen_bolum']): ?><span>🏢 <?=htmlspecialchars($d['denetlened_bolum']??$d['denetlenen_bolum'])?></span><?php endif; ?>
        <span>📋 <?=count($bulgular)?> bulgu · <?=count($dokumanlar)?> doküman</span>
      </div>
    </div>
    <span style="font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;background:<?=$ds1?>;color:<?=$ds0?>"><?=$ds2?></span>
  </div>
  <?php if(count($bulgular)>0): ?>
  <div style="margin-top:10px">
    <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
      <span>Bulgular: <?=$b_tam?>/<?=count($bulgular)?> tamamlandı</span>
      <?php if($b_gec>0): ?><span style="color:#DC2626">⚠️ <?=$b_gec?> gecikmiş</span><?php endif; ?>
    </div>
    <div style="height:6px;background:var(--kenar);border-radius:3px">
      <div style="height:100%;width:<?=$pct_val?>%;background:#22C55E;border-radius:3px"></div>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:16px">
  <button onclick="tabGoster('bulgular')" id="tab_btn_bulgular"
    style="padding:7px 14px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;background:var(--t);color:#fff">
    📋 Bulgular (<?=count($bulgular)?>)
  </button>
  <button onclick="tabGoster('dokumanlar')" id="tab_btn_dokumanlar"
    style="padding:7px 14px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;background:var(--kenar-a);color:var(--m)">
    📎 Dokümanlar (<?=count($dokumanlar)?>)
  </button>
</div>

<!-- BULGULAR -->
<div id="tab_bulgular">
  <div style="display:flex;justify-content:flex-end;margin-bottom:12px">
    <button onclick="bulguModalAc()" class="btn btn-t btn-sm">+ Bulgu Ekle</button>
  </div>
  <?php if(empty($bulgular)): ?>
  <div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Henüz bulgu eklenmemiş.</div>
  <?php else: ?>
  <div style="display:flex;flex-direction:column;gap:8px">
  <?php foreach($bulgular as $b):
    $bs  = $bulgu_stil[$b['bulgu_turu']] ?? ['#6B7280','#F1F5F9','?'];
    $bds = $bdur_stil[$b['durum']]      ?? ['#6B7280','?'];
    $bGec = $b['durum']==='acik' && $b['hedef_tarih'] && $b['hedef_tarih']<date('Y-m-d');
    $bid_safe = (int)$b['id'];
  ?>
  <div class="kart" style="padding:12px 16px;border-left:4px solid <?=$bs[0]?>">
    <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
      <div style="min-width:100px">
        <div style="font-weight:900;font-size:12px;font-family:monospace"><?=htmlspecialchars($b['bulgu_no']??'')?></div>
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px;background:<?=$bs[1]?>;color:<?=$bs[0]?>"><?=$bs[2]?></span>
      </div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:700;margin-bottom:4px"><?=htmlspecialchars($b['bulgu_tanimi'])?></div>
        <div style="display:flex;gap:10px;font-size:11px;color:var(--m2);flex-wrap:wrap">
          <?php if($b['standart_madde']): ?><span>📌 <?=htmlspecialchars($b['standart_madde'])?></span><?php endif; ?>
          <?php if($b['sorumlu']): ?><span>👤 <?=htmlspecialchars($b['sorumlu'])?></span><?php endif; ?>
          <?php if($b['hedef_tarih']): ?><span style="color:<?=$bGec?'#DC2626':'var(--m2)'?>">🗓 <?=date('d.m.Y',strtotime($b['hedef_tarih']))?><?=$bGec?' ⚠️':''?></span><?php endif; ?>
        </div>
      </div>
      <div style="display:flex;gap:6px;align-items:center">
        <span style="font-size:11px;font-weight:700;color:<?=$bds[0]?>"><?=$bds[1]?></span>
        <button onclick="bulguDuzenleById(<?=$bid_safe?>)" class="btn btn-b btn-sm" style="font-size:10px;padding:3px 8px">✏️</button>
        <button onclick="bulguSil(<?=$bid_safe?>)" class="btn btn-sm" style="font-size:10px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
      </div>
    </div>
    <?php if($b['kok_neden']): ?><div style="font-size:11px;color:var(--m2);margin-top:6px;padding-left:112px">🔎 <?=htmlspecialchars(mb_strimwidth($b['kok_neden'],0,100,'…'))?></div><?php endif; ?>
  </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DOKÜMANLAR -->
<div id="tab_dokumanlar" style="display:none">
  <div style="display:flex;justify-content:flex-end;margin-bottom:12px">
    <button onclick="dokModalAc()" class="btn btn-t btn-sm">📎 Doküman Yükle</button>
  </div>
  <?php if(empty($dokumanlar)): ?>
  <div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Doküman yüklenmemiş.</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px">
  <?php foreach($dokumanlar as $dok):
    $ext=strtolower(pathinfo($dok['dosya_adi'],PATHINFO_EXTENSION));
    $dikon=in_array($ext,['jpg','jpeg','png','gif'])?'🖼️':($ext==='pdf'?'📄':($ext==='zip'?'🗜️':'📎'));
    $dok_id_safe = (int)$dok['id'];
  ?>
  <div class="kart" style="padding:12px">
    <div style="display:flex;gap:8px;margin-bottom:8px">
      <div style="font-size:22px"><?=$dikon?></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:12px;word-break:break-word"><?=htmlspecialchars($dok['dosya_adi'])?></div>
        <div style="font-size:10px;color:var(--m2)"><?=$dok_turu_etiket[$dok['dosya_turu']]??'📎'?></div>
        <?php if($dok['aciklama']): ?><div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars($dok['aciklama'])?></div><?php endif; ?>
      </div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:10px;color:var(--m3)"><?=date('d.m.Y',strtotime($dok['yuklenme_tarihi']))?></span>
      <div style="display:flex;gap:5px">
        <a href="<?=BASE_URL?>/<?=$dok['dosya_yolu']?>" target="_blank" class="btn btn-b btn-sm" style="font-size:11px;padding:3px 8px">⬇️</a>
        <form method="POST" style="display:inline">
          <input type="hidden" name="action" value="dok_sil">
          <input type="hidden" name="dok_id" value="<?=$dok_id_safe?>">
          <button type="submit" onclick="return confirm('Silinsin mi?')" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- BULGU MODAL -->
<div id="bulguModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center;padding:16px;overflow-y:auto">
<div class="kart" style="width:580px;max-width:100%;padding:20px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800;font-size:14px" id="bulguModalBaslik">📋 Bulgu Ekle</div>
    <button onclick="modalKapat('bulguModal')" style="border:none;background:none;font-size:20px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" id="b_action" value="bulgu_ekle">
    <input type="hidden" name="bulgu_id" id="b_id" value="">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div style="grid-column:span 2">
        <label class="form-et">Bulgu Tanımı *</label>
        <textarea name="bulgu_tanimi" id="b_tanim" class="form-alan" rows="3" style="width:100%;resize:vertical" required></textarea>
      </div>
      <div>
        <label class="form-et">Tür</label>
        <select name="bulgu_turu" id="b_tur" class="form-alan">
          <option value="buyuk_uygunsuzluk">Büyük Uygunsuzluk</option>
          <option value="kucuk_uygunsuzluk">Küçük Uygunsuzluk</option>
          <option value="gozlem">Gözlem</option>
          <option value="iyilestirme">İyileştirme Fırsatı</option>
        </select>
      </div>
      <div>
        <label class="form-et">Durum</label>
        <select name="durum" id="b_durum" class="form-alan">
          <option value="acik">Açık</option>
          <option value="devam_ediyor">Devam Ediyor</option>
          <option value="tamamlandi">Tamamlandı</option>
          <option value="kapandi">Kapandı</option>
        </select>
      </div>
      <div>
        <label class="form-et">Standart Maddesi</label>
        <input name="standart_madde" id="b_standart" class="form-alan">
      </div>
      <div>
        <label class="form-et">Sorumlu</label>
        <input name="sorumlu" id="b_sorumlu" class="form-alan">
      </div>
      <div>
        <label class="form-et">Hedef Tarih</label>
        <input type="date" name="hedef_tarih" id="b_hedef" class="form-alan">
      </div>
      <div style="grid-column:span 2">
        <label class="form-et">Kök Neden</label>
        <textarea name="kok_neden" id="b_kok" class="form-alan" rows="2" style="width:100%;resize:vertical"></textarea>
      </div>
      <div style="grid-column:span 2">
        <label class="form-et">DÖF / Aksiyon</label>
        <textarea name="dof_aksiyon" id="b_dof" class="form-alan" rows="2" style="width:100%;resize:vertical"></textarea>
      </div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('bulguModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">💾 Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- DOKÜMAN MODAL -->
<div id="dokModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:420px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;margin-bottom:14px">
    <div style="font-weight:800">📎 Doküman Yükle</div>
    <button onclick="modalKapat('dokModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Dosya</label><input type="file" name="dosya" class="form-alan" required></div>
      <div><label class="form-et">Tür</label>
        <select name="dosya_turu" class="form-alan">
          <option value="denetim_raporu">📄 Denetim Raporu</option>
          <option value="kanit">🖼️ Kanıt</option>
          <option value="dof">📋 DÖF</option>
          <option value="foto">📷 Fotoğraf</option>
          <option value="diger">📎 Diğer</option>
        </select>
      </div>
      <div><label class="form-et">İlgili Bulgu (opsiyonel)</label>
        <select name="bulgu_id_dok" class="form-alan">
          <option value="">— Genel denetim —</option>
          <?php foreach($bulgular as $b): ?>
          <option value="<?=(int)$b['id']?>"><?=htmlspecialchars($b['bulgu_no']??'')?> — <?=htmlspecialchars(mb_strimwidth($b['bulgu_tanimi'],0,40,'…'))?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-et">Açıklama</label><input name="dok_aciklama" class="form-alan"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('dokModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">⬆️ Yükle</button>
    </div>
  </form>
</div>
</div>

<!-- GİZLİ FORMLAR -->
<form method="POST" id="bulguSilForm" style="display:none">
  <input type="hidden" name="action" value="bulgu_sil">
  <input type="hidden" name="bulgu_id" id="bulguSilId">
</form>
<form method="POST" id="denetimSilForm" style="display:none">
  <input type="hidden" name="action" value="denetim_sil">
</form>

</div><!-- /s-body -->

<script>
var _bulgular = JSON.parse(atob('<?=base64_encode(json_encode($bulgular))?>'));

document.getElementById('silBtn').addEventListener('click', function(){
    var kod  = this.dataset.kod;
    var bcnt = parseInt(this.dataset.bcnt);
    var dcnt = parseInt(this.dataset.dcnt);
    var msg  = '\u26a0\ufe0f "' + kod + '" denetimini silmek istiyorsunuz.\n';
    if(bcnt > 0) msg += bcnt + ' bulgu silinecek.\n';
    if(dcnt > 0) msg += dcnt + ' dokuman silinecek.\n';
    msg += '\nGERI ALINAMAZ. Devam?';
    if(!confirm(msg)) return;
    var girilen = prompt('Onaylamak icin denetim kodunu girin:\n\n' + kod);
    if(girilen === null) return;
    if(girilen.trim().toUpperCase() !== kod.toUpperCase()){
        alert('Kod eslesmed. Iptal.');
        return;
    }
    document.getElementById('denetimSilForm').submit();
});

function tabGoster(id){
    ['bulgular','dokumanlar'].forEach(function(t){
        document.getElementById('tab_'+t).style.display = t===id ? 'block' : 'none';
        var b = document.getElementById('tab_btn_'+t);
        if(b){ b.style.background = t===id ? 'var(--t)' : 'var(--kenar-a)'; b.style.color = t===id ? '#fff' : 'var(--m)'; }
    });
}

function modalKapat(id){ document.getElementById(id).style.display = 'none'; }

function bulguModalAc(){
    document.getElementById('bulguModalBaslik').textContent = 'Bulgu Ekle';
    document.getElementById('b_action').value   = 'bulgu_ekle';
    document.getElementById('b_id').value       = '';
    document.getElementById('b_tanim').value    = '';
    document.getElementById('b_tur').value      = 'kucuk_uygunsuzluk';
    document.getElementById('b_durum').value    = 'acik';
    document.getElementById('b_standart').value = '';
    document.getElementById('b_sorumlu').value  = '';
    document.getElementById('b_hedef').value    = '';
    document.getElementById('b_kok').value      = '';
    document.getElementById('b_dof').value      = '';
    document.getElementById('bulguModal').style.display = 'flex';
}

function dokModalAc(){ document.getElementById('dokModal').style.display = 'flex'; }

function bulguDuzenleById(id){
    var b = _bulgular.find(function(x){ return x.id == id; });
    if(!b) return;
    document.getElementById('bulguModalBaslik').textContent = 'Bulgu Duzenle';
    document.getElementById('b_action').value   = 'bulgu_guncelle';
    document.getElementById('b_id').value       = b.id;
    document.getElementById('b_tanim').value    = b.bulgu_tanimi   || '';
    document.getElementById('b_tur').value      = b.bulgu_turu     || 'kucuk_uygunsuzluk';
    document.getElementById('b_durum').value    = b.durum          || 'acik';
    document.getElementById('b_standart').value = b.standart_madde || '';
    document.getElementById('b_sorumlu').value  = b.sorumlu        || '';
    document.getElementById('b_hedef').value    = b.hedef_tarih    || '';
    document.getElementById('b_kok').value      = b.kok_neden      || '';
    document.getElementById('b_dof').value      = b.dof_aksiyon    || '';
    document.getElementById('bulguModal').style.display = 'flex';
}

function bulguSil(id){
    if(!confirm('Bu bulguyu silmek istediginizden emin misiniz?')) return;
    document.getElementById('bulguSilId').value = id;
    document.getElementById('bulguSilForm').submit();
}
</script>
