<?php
/**
 * Dış İade Özet Dashboard — Aylık hata, PPM hesabı dahil
 * panel.php: 'kalite-dis-iade-ozet'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$yil    = (int)($_GET['yil'] ?? date('Y'));
$hedef_ppm = 7500; // sabit hedef

$where_yil = "WHERE YEAR(kayit_tarih) = $yil";

try {
    // Genel özet
    $ozet = $db->query("SELECT
        COUNT(DISTINCT irsaliye_no)  toplam_irs,
        COUNT(*)                     toplam_kayit,
        SUM(hata_miktar)             toplam_hata,
        COUNT(DISTINCT malzeme_kodu) farkli_malzeme
        FROM dis_iade_kontrol_listesi $where_yil")->fetch(PDO::FETCH_ASSOC);

    // Aylık fire (hata) adetleri — MySQL
    $aylik_hata = [];
    $st = $db->query("SELECT MONTH(kayit_tarih) ay, SUM(hata_miktar) toplam
        FROM dis_iade_kontrol_listesi $where_yil
        GROUP BY MONTH(kayit_tarih) ORDER BY ay");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $aylik_hata[(int)$r['ay']] = (float)$r['toplam'];
    }

    // Hata tipi dağılımı top 10
    $hata_dagilim = $db->query("SELECT hata_tipi, SUM(hata_miktar) toplam
        FROM dis_iade_kontrol_listesi $where_yil
        GROUP BY hata_tipi ORDER BY toplam DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

    // Aksiyon dağılımı
    $aksiyon_dagilim = $db->query("SELECT alinan_aksiyon, SUM(hata_miktar) toplam
        FROM dis_iade_kontrol_listesi $where_yil
        GROUP BY alinan_aksiyon ORDER BY toplam DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);

    // İrsaliye bazlı top 10
    $irs_top = $db->query("SELECT irsaliye_no, SUM(hata_miktar) toplam_hata,
        COUNT(*) kayit_sayisi, MAX(kayit_tarih) son_tarih
        FROM dis_iade_kontrol_listesi $where_yil
        GROUP BY irsaliye_no ORDER BY toplam_hata DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

    // Malzeme bazlı top 10
    $malz_top = $db->query("SELECT malzeme_kodu, malzeme_adi, SUM(hata_miktar) toplam_hata
        FROM dis_iade_kontrol_listesi $where_yil
        GROUP BY malzeme_kodu, malzeme_adi ORDER BY toplam_hata DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    $ozet=[]; $aylik_hata=[]; $hata_dagilim=[]; $aksiyon_dagilim=[]; $irs_top=[]; $malz_top=[];
}

// ── Tiger'dan aylık satış — tek UNION sorgusu ──────────────────
$aylik_satis = [];
if (!empty($tigerdb_pdo)) {
    try {
        $st = $tigerdb_pdo->prepare("
            SELECT ay, SUM(toplam) toplam FROM (
                SELECT STL.MONTH_ ay, SUM(STL.AMOUNT) toplam
                FROM LG_222_01_STLINE STL WITH(NOLOCK)
                LEFT JOIN LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                WHERE STF.TRCODE=8 AND STL.YEAR_=?
                GROUP BY STL.MONTH_
                UNION ALL
                SELECT STL.MONTH_, SUM(STL.AMOUNT)
                FROM LG_222_02_STLINE STL WITH(NOLOCK)
                LEFT JOIN LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                WHERE STF.TRCODE=8 AND STL.YEAR_=?
                GROUP BY STL.MONTH_
            ) t GROUP BY ay");
        $st->execute([$yil, $yil]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $aylik_satis[(int)$r['ay']] = (float)$r['toplam'];
        }
    } catch (Throwable $e) {}
}

// ── PPM hesapla her ay için ───────────────────────────────────
// PPM = (iade_adet / satış_adet) × 1.000.000
$aylik_ppm = [];
for ($m = 1; $m <= 12; $m++) {
    $satis = $aylik_satis[$m] ?? 0;
    $hata  = $aylik_hata[$m]  ?? 0;
    $aylik_ppm[$m] = ($satis > 0) ? round($hata / $satis * 1_000_000, 0) : null;
}

$ay_adlari = ['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
$yillar    = range(date('Y')-2, date('Y')+1);
$max_hata  = max(1, max(array_merge([0], array_values($aylik_hata))));
$max_ppm   = max($hedef_ppm, max(array_merge([0], array_filter(array_values($aylik_ppm)))));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Dış İade Özet</h1>
    <div class="s-yol">Kalite /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-liste" style="color:var(--t)">Dış İade</a> /
      <b>Özet</b>
    </div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-liste"    class="btn btn-b btn-sm">← İrsaliye</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-kontrol" class="btn btn-b btn-sm">📋 Kontrol Listesi</a>
  </div>
</div>

<div class="s-body">

<!-- Yıl filtresi -->
<div class="kart" style="margin-bottom:14px;padding:10px 14px">
  <form method="GET" action="<?= BASE_URL ?>/panel.php" style="display:flex;gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="kalite-dis-iade-ozet">
    <div class="form-grup" style="margin:0">
      <label class="form-et">Yıl</label>
      <select class="form-alan" name="yil">
        <?php foreach ($yillar as $y): ?>
        <option value="<?= $y ?>" <?= $yil===$y?'selected':'' ?>><?= $y ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
  </form>
</div>

<!-- Özet kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:16px">
  <?php
  $yillik_satis = array_sum($aylik_satis);
  $yillik_hata  = array_sum($aylik_hata);
  $yillik_ppm   = $yillik_satis > 0 ? round($yillik_hata / $yillik_satis * 1_000_000, 0) : 0;
  foreach ([
    ['Toplam İrsaliye',  $ozet['toplam_irs']??0,          '#1E3A5F','#E0F2FE', ''],
    ['Toplam Hata Adedi',$ozet['toplam_hata']??0,         '#EF4444','#FEE2E2', ''],
    ['Yıllık Satış',     number_format($yillik_satis,0),  '#22C55E','#D1FAE5', ''],
    ['Yıllık PPM',       number_format($yillik_ppm,0),    $yillik_ppm<=$hedef_ppm?'#22C55E':'#EF4444',
                         $yillik_ppm<=$hedef_ppm?'#D1FAE5':'#FEE2E2', 'Hedef: '.number_format($hedef_ppm)],
    ['Farklı Malzeme',   $ozet['farkli_malzeme']??0,      '#F59E0B','#FEF9C3', ''],
  ] as [$lbl,$val,$fg,$bg,$alt]): ?>
  <div style="background:<?= $bg ?>;border-radius:var(--r);padding:14px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $fg ?>"><?= is_numeric($val)?number_format((int)$val):$val ?></div>
    <div style="font-size:10px;font-weight:700;color:<?= $fg ?>;text-transform:uppercase;opacity:.8;margin-top:3px"><?= $lbl ?></div>
    <?php if ($alt): ?><div style="font-size:10px;color:<?= $fg ?>;opacity:.6;margin-top:1px"><?= $alt ?></div><?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- ── Aylık Fire + PPM Tablosu ────────────────────────────── -->
<div class="kart" style="margin-bottom:16px;padding:14px">
  <div style="font-size:13px;font-weight:800;margin-bottom:14px">
    📅 <?= $yil ?> Yılı — Aylık Fire Adetleri & PPM
    <span style="font-size:11px;font-weight:400;color:var(--m2);margin-left:8px">
      Hedef PPM: <b><?= number_format($hedef_ppm) ?></b> | PPM = (İade Adedi / Satış Adedi) × 1.000.000
    </span>
  </div>

  <!-- Bar grafik -->
  <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:6px;align-items:end;height:100px;margin-bottom:8px">
    <?php for ($m = 1; $m <= 12; $m++):
        $h = $aylik_hata[$m]  ?? 0;
        $s = $aylik_satis[$m] ?? 0;
        $p = $aylik_ppm[$m];
        $bar_h = $h > 0 ? max(6, round($h / $max_hata * 80)) : 4;
        $over  = ($p !== null && $p > $hedef_ppm);
        $cur   = ($m === (int)date('m') && $yil === (int)date('Y'));
    ?>
    <div style="display:flex;flex-direction:column;align-items:center;gap:2px">
      <div style="font-size:8px;font-weight:700;color:<?= $over?'#EF4444':'var(--m2)' ?>">
        <?= $h > 0 ? number_format($h,0) : '' ?>
      </div>
      <div style="height:<?= $bar_h ?>px;width:100%;
           background:<?= $over?'#EF4444':($cur?'#1E3A5F':'#94A3B8') ?>;
           border-radius:3px 3px 0 0;
           opacity:<?= $h>0?'1':'0.2' ?>"></div>
      <div style="font-size:8px;color:<?= $cur?'var(--t)':'var(--m2)' ?>;font-weight:<?= $cur?'800':'400' ?>">
        <?= $ay_adlari[$m] ?>
      </div>
    </div>
    <?php endfor; ?>
  </div>

  <!-- Aylık veri tablosu -->
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead>
        <tr style="background:#1E3A5F">
          <th style="color:#fff;padding:7px 10px;text-align:left;font-weight:700">Ay</th>
          <?php for ($m=1;$m<=12;$m++): ?>
          <th style="color:#fff;padding:7px 6px;text-align:center;font-weight:700;
              <?= ($m===(int)date('m')&&$yil===(int)date('Y'))?'background:#0F2A4A':'' ?>">
            <?= $ay_adlari[$m] ?>
          </th>
          <?php endfor; ?>
          <th style="color:#fff;padding:7px 10px;font-weight:700">Toplam</th>
        </tr>
      </thead>
      <tbody>
        <!-- Satış Miktarı -->
        <tr style="background:var(--kenar-a)">
          <td style="padding:6px 10px;font-weight:700;color:var(--m2);white-space:nowrap;font-size:11px">Satış Adedi</td>
          <?php $ytoplam=0; for ($m=1;$m<=12;$m++): $v=$aylik_satis[$m]??0; $ytoplam+=$v; ?>
          <td style="padding:6px;text-align:right;font-size:11px"><?= $v>0?number_format($v,0):'—' ?></td>
          <?php endfor; ?>
          <td style="padding:6px 10px;text-align:right;font-weight:700"><?= number_format($ytoplam,0) ?></td>
        </tr>
        <!-- İade Adedi -->
        <tr>
          <td style="padding:6px 10px;font-weight:700;color:#EF4444;white-space:nowrap;font-size:11px">İade Adedi</td>
          <?php $ytoplam=0; for ($m=1;$m<=12;$m++): $v=$aylik_hata[$m]??0; $ytoplam+=$v; ?>
          <td style="padding:6px;text-align:right;font-weight:<?= $v>0?'700':'400' ?>;color:<?= $v>0?'#EF4444':'var(--m3)' ?>">
            <?= $v>0?number_format($v,0):'—' ?>
          </td>
          <?php endfor; ?>
          <td style="padding:6px 10px;text-align:right;font-weight:700;color:#EF4444"><?= $ytoplam>0?number_format($ytoplam,0):'—' ?></td>
        </tr>
        <!-- PPM Gerçekleşen -->
        <tr style="background:var(--kenar-a)">
          <td style="padding:6px 10px;font-weight:700;white-space:nowrap;font-size:11px">PPM Gerçekleşen</td>
          <?php $ppm_dolu=0; $ppm_toplam=0; for ($m=1;$m<=12;$m++): $p=$aylik_ppm[$m]; ?>
          <?php if ($p !== null): $over=($p>$hedef_ppm); $ppm_dolu++; $ppm_toplam+=$p; ?>
          <td style="padding:6px;text-align:right;font-weight:800;
              color:<?= $over?'#EF4444':'#22C55E' ?>;
              background:<?= $over?'#FEE2E2':'#D1FAE5' ?>">
            <?= number_format($p,0) ?>
          </td>
          <?php else: ?>
          <td style="padding:6px;text-align:center;color:var(--m3);font-size:10px">—</td>
          <?php endif; ?>
          <?php endfor; ?>
          <td style="padding:6px 10px;text-align:right;font-weight:800;font-size:11px;color:var(--m2)">
            <?= $ppm_dolu>0?number_format(round($ppm_toplam/$ppm_dolu)):'—' ?>
            <div style="font-size:9px;font-weight:400">ort.</div>
          </td>
        </tr>
        <!-- PPM Hedef -->
        <tr>
          <td style="padding:6px 10px;font-weight:700;white-space:nowrap;font-size:11px;color:#6366F1">PPM Hedef</td>
          <?php for ($m=1;$m<=12;$m++): ?>
          <td style="padding:6px;text-align:right;color:#6366F1;font-weight:700"><?= number_format($hedef_ppm) ?></td>
          <?php endfor; ?>
          <td style="padding:6px 10px;text-align:right;color:#6366F1;font-weight:700"><?= number_format($hedef_ppm) ?></td>
        </tr>
        <!-- PPM Oranı % = Gerçekleşen/Hedef -->
        <tr style="background:var(--kenar-a)">
          <td style="padding:6px 10px;font-weight:700;white-space:nowrap;font-size:11px;color:var(--m2)">PPM Oranı (Gerç./Hedef %)</td>
          <?php for ($m=1;$m<=12;$m++): $p=$aylik_ppm[$m]; ?>
          <?php if ($p !== null): $oran_pct=round($p/$hedef_ppm*100,1); $iyi=($oran_pct<=100); ?>
          <td style="padding:6px;text-align:right;font-weight:800;
              color:<?= $iyi?'#22C55E':'#EF4444' ?>;
              background:<?= $iyi?'':'#FEE2E2' ?>">
            %<?= number_format($oran_pct,1) ?>
          </td>
          <?php else: ?>
          <td style="padding:6px;text-align:center;color:var(--m3);font-size:10px">—</td>
          <?php endif; ?>
          <?php endfor; ?>
          <td style="padding:6px 10px"></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="margin-top:8px;font-size:11px;color:var(--m2)">
    🟢 Hedef altı &nbsp;|&nbsp; 🔴 Hedef üstü &nbsp;|&nbsp;
    PPM = (İade Adedi ÷ Satış Adedi) × 1.000.000 &nbsp;|&nbsp; Hedef: <?= number_format($hedef_ppm) ?> PPM
  </div>
</div>

<!-- Hata tipi + Aksiyon -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
  <div class="kart">
    <div style="font-size:13px;font-weight:800;margin-bottom:10px">🔴 Hata Tipi Dağılımı (Top 10)</div>
    <?php if ($hata_dagilim):
        $mx = max(array_column($hata_dagilim,'toplam'));
        foreach ($hata_dagilim as $h): $pct=round($h['toplam']/$mx*100); ?>
    <div style="margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($h['hata_tipi']) ?></span>
        <b><?= number_format($h['toplam']) ?></b>
      </div>
      <div style="height:6px;background:var(--kenar);border-radius:3px">
        <div style="height:100%;width:<?= $pct ?>%;background:#EF4444;border-radius:3px"></div>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
  <div class="kart">
    <div style="font-size:13px;font-weight:800;margin-bottom:10px">✅ Alınan Aksiyon Dağılımı</div>
    <?php if ($aksiyon_dagilim):
        $mx = max(array_column($aksiyon_dagilim,'toplam'));
        foreach ($aksiyon_dagilim as $a): $pct=round($a['toplam']/$mx*100); ?>
    <div style="margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($a['alinan_aksiyon']) ?></span>
        <b><?= number_format($a['toplam']) ?></b>
      </div>
      <div style="height:6px;background:var(--kenar);border-radius:3px">
        <div style="height:100%;width:<?= $pct ?>%;background:#22C55E;border-radius:3px"></div>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- Top irsaliye + Malzeme -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
  <div class="kart" style="padding:0">
    <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);font-weight:700;font-size:13px">🔝 En Fazla Hata — İrsaliye</div>
    <table class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach(['İrsaliye No','Hata','Kayıt','Tarih'] as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:6px 10px;font-size:11px;font-weight:700"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach ($irs_top as $r): ?>
      <tr>
        <td>
          <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-dis-iade-detay&irsaliye=<?= urlencode($r['irsaliye_no']) ?>"
             style="color:var(--t);font-family:monospace;font-size:11px"><?= htmlspecialchars($r['irsaliye_no']) ?></a>
        </td>
        <td style="text-align:right;font-weight:700;color:#EF4444"><?= number_format($r['toplam_hata']) ?></td>
        <td style="text-align:center"><?= $r['kayit_sayisi'] ?></td>
        <td style="font-size:11px;white-space:nowrap"><?= $r['son_tarih'] ? date('d.m.Y',strtotime($r['son_tarih'])) : '—' ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="kart" style="padding:0">
    <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);font-weight:700;font-size:13px">🔝 En Fazla Hata — Malzeme</div>
    <table class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach(['Malzeme Kodu','Malzeme Adı','Hata'] as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:6px 10px;font-size:11px;font-weight:700"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach ($malz_top as $r): ?>
      <tr>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['malzeme_kodu']) ?></td>
        <td style="font-size:11px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
            title="<?= htmlspecialchars($r['malzeme_adi']) ?>"><?= htmlspecialchars($r['malzeme_adi']) ?></td>
        <td style="text-align:right;font-weight:700;color:#EF4444"><?= number_format($r['toplam_hata']) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</div><!-- /s-body -->
