<?php
/**
 * JETONE.PRO — Final Kontrol Listesi
 * bolumler/kalite/final_kontrol_liste.php
 * panel.php: 'kalite-final-liste' => 'bolumler/kalite/final_kontrol_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

// Tablo oluştur (yoksa)
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `final_kontrol_listesi` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `paket_no` VARCHAR(100) NOT NULL,
        `stok_kodu` VARCHAR(100) DEFAULT NULL,
        `stok_adi` VARCHAR(255) DEFAULT NULL,
        `miktar` DECIMAL(12,3) DEFAULT NULL,
        `kontrol_sonuc` VARCHAR(20) DEFAULT NULL,
        `kontrol_aciklama` TEXT,
        `kontrol_eden` VARCHAR(100) DEFAULT NULL,
        `kontrol_tarih_saat` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`), INDEX (`paket_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

// Silme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['delete_id'])) {
    try {
        $db->prepare("DELETE FROM final_kontrol_listesi WHERE id=?")->execute([(int)$_POST['delete_id']]);
    } catch (Throwable $e) {}
    echo '<script>location.href="' . BASE_URL . '/panel.php?sayfa=kalite-final-liste&silindi=1";</script>';
    exit;
}

// Tarih filtresi
$tarih_b = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['1_tarih'] ?? '') ? $_POST['1_tarih'] : date('Y-m-d', strtotime('-29 days'));
$tarih_e = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['2_tarih'] ?? '') ? $_POST['2_tarih'] : date('Y-m-d');

// Özet istatistik
$ozet = ['toplam'=>0,'ok'=>0,'nok'=>0,'miktar'=>0];
try {
    $st = $db->prepare("SELECT COUNT(*) t, SUM(kontrol_sonuc='OK') ok, SUM(kontrol_sonuc='NOK') nok,
        COALESCE(SUM(miktar),0) mik
        FROM final_kontrol_listesi WHERE DATE(kontrol_tarih_saat) BETWEEN ? AND ?");
    $st->execute([$tarih_b, $tarih_e]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    $ozet = ['toplam'=>(int)$r['t'],'ok'=>(int)$r['ok'],'nok'=>(int)$r['nok'],'miktar'=>(float)$r['mik']];
} catch (Throwable $e) {}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Final Kontrol Listesi</h1>
    <div class="s-yol">Kalite / <b>Final Kontrol</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-final-kontrol" class="btn btn-t btn-sm">+ Kontrol Yap</a>
  </div>
</div>

<div class="s-body">

<!-- Özet istatistik -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:16px">
  <?php
  $kutular = [
    ['Toplam Kontrol', $ozet['toplam'], 'var(--t)', 'var(--t-a)'],
    ['OK',   $ozet['ok'],  '#22C55E','#D1FAE5'],
    ['NOK',  $ozet['nok'], '#EF4444','#FEE2E2'],
    ['Toplam Miktar', number_format($ozet['miktar'],0,',','.'), '#7C3AED','#EDE9FE'],
  ];
  foreach ($kutular as $k): ?>
  <div style="background:<?= $k[3] ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $k[2] ?>"><?= $k[1] ?></div>
    <div style="font-size:10px;font-weight:700;color:<?= $k[2] ?>;text-transform:uppercase;margin-top:2px;opacity:.8"><?= $k[0] ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Tarih filtresi -->
<div class="kart" style="margin-bottom:16px;padding:12px">
  <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <div class="form-grup" style="margin:0;min-width:140px">
      <label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="1_tarih" value="<?= $tarih_b ?>">
    </div>
    <div class="form-grup" style="margin:0;min-width:140px">
      <label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="2_tarih" value="<?= $tarih_e ?>">
    </div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-final-liste" class="btn btn-b btn-sm">Sıfırla</a>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <?php
    $sth2 = ['#','Paket No','Stok Kodu','Stok Adı','Miktar','Sonuç','Kontrol Eden','Tarih/Saat','İşlemler'];
    ?>
    <table id="finalListeTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth2 as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;white-space:nowrap;padding:8px 10px;font-size:12px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth2 as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php
        try {
            $st = $db->prepare("SELECT * FROM final_kontrol_listesi
                WHERE DATE(kontrol_tarih_saat) BETWEEN ? AND ?
                ORDER BY kontrol_tarih_saat DESC");
            $st->execute([$tarih_b, $tarih_e]);
            $i = 0;
            while ($r = $st->fetch(PDO::FETCH_ASSOC)):
                $i++;
                $sonuc_bg = $r['kontrol_sonuc']==='OK' ? '#D1FAE5' : '#FEE2E2';
                $sonuc_fg = $r['kontrol_sonuc']==='OK' ? '#065F46' : '#991B1B';
                $miktar_g = '';
                if ($r['miktar'] !== null) {
                    $n = (float)$r['miktar'];
                    $miktar_g = floor($n)==$n ? number_format($n,0,',','.') : rtrim(rtrim(number_format($n,3,',','.'),'0'),',');
                }
        ?>
        <tr>
          <td style="color:var(--m3);font-size:11px"><?= $i ?></td>
          <td style="font-weight:700;font-family:monospace"><?= htmlspecialchars($r['paket_no']) ?></td>
          <td><code style="background:var(--kenar-a);padding:1px 6px;border-radius:3px;font-size:11px;font-weight:700"><?= htmlspecialchars($r['stok_kodu']??'') ?></code></td>
          <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($r['stok_adi']??'') ?></td>
          <td style="text-align:right;font-weight:700"><?= $miktar_g ?></td>
          <td>
            <span style="background:<?= $sonuc_bg ?>;color:<?= $sonuc_fg ?>;padding:2px 10px;border-radius:12px;font-size:11px;font-weight:800">
              <?= htmlspecialchars($r['kontrol_sonuc']??'') ?>
            </span>
          </td>
          <td><?= htmlspecialchars($r['kontrol_eden']??'') ?></td>
          <td style="white-space:nowrap;font-size:12px"><?= $r['kontrol_tarih_saat'] ? date('d.m.Y H:i', strtotime($r['kontrol_tarih_saat'])) : '' ?></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Kaydı silmek istiyor musunuz?')">
              <input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>">
              <button type="submit" class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px">🗑</button>
            </form>
          </td>
        </tr>
        <?php endwhile;
        } catch (Throwable $e) { echo '<tr><td colspan="9" style="text-align:center;padding:24px;color:var(--m2)">Kayıt yok</td></tr>'; } ?>
      </tbody>
    </table>
  </div>
</div>

</div><!-- /s-body -->

<script>
$(document).ready(function(){
  var tbl = $('#finalListeTablo').DataTable({
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollX:true, scrollY:520, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',filename:'FinalKontrol_<?= date('Ymd') ?>'},
      {extend:'print',text:'🖨 Yazdır'}
    ],
    drawCallback: function(){
      $('#finalListeTablo thead th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#ffffff','important');
      });
    },
    initComplete: function(){
      this.api().columns([2,5,6]).every(function(){
        var col=this;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo($(col.footer()).empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var t=$('<div/>').html(d).text();
          sel.append('<option value="'+t+'">'+(t.length>28?t.substr(0,28)+'...':t)+'</option>');
        });
      });
      $('#finalListeTablo thead th').each(function(){
        this.style.setProperty('background-color','#1E3A5F','important');
        this.style.setProperty('color','#ffffff','important');
      });
    }
  });
});
</script>
