<?php
/**
 * Hortum Test Geçmiş + Özet
 * panel.php: 'kalite-hortum-gecmis'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$bas = $_GET['bas'] ?? date('Y-m-01');
$bit = $_GET['bit'] ?? date('Y-m-d');

try {
    $ozet = $db->prepare("SELECT COUNT(*) toplam,
        SUM(genel_sonuc=1) gecti, SUM(genel_sonuc=0) kaldi,
        ROUND(AVG(sure_sn),1) ort_sure,
        ROUND(AVG(asama1_dusus_bar),4) ort_dusus,
        ROUND(AVG(asama2_akis_ldk),2) ort_akis
        FROM hortum_test_kayit WHERE DATE(kayit_tarihi) BETWEEN ? AND ?")->execute([$bas,$bit]) && false;
    $st = $db->prepare("SELECT COUNT(*) toplam, SUM(genel_sonuc=1) gecti, SUM(genel_sonuc=0) kaldi,
        ROUND(AVG(sure_sn),1) ort_sure, ROUND(AVG(asama1_dusus_bar),4) ort_dusus, ROUND(AVG(asama2_akis_ldk),2) ort_akis
        FROM hortum_test_kayit WHERE DATE(kayit_tarihi) BETWEEN ? AND ?");
    $st->execute([$bas,$bit]);
    $ozet = $st->fetch(PDO::FETCH_ASSOC);

    $st2 = $db->prepare("SELECT * FROM hortum_test_kayit WHERE DATE(kayit_tarihi) BETWEEN ? AND ? ORDER BY id DESC LIMIT 200");
    $st2->execute([$bas,$bit]);
    $rows = $st2->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $ozet=[]; $rows=[]; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Hortum Test Geçmişi</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" style="color:var(--t)">Hortum Test</a> / <b>Geçmiş</b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-hortum-test" class="btn btn-b btn-sm">← Test Ekranı</a>
</div>

<div class="s-body">

<!-- Filtre -->
<div class="kart" style="margin-bottom:14px;padding:10px 14px">
  <form method="GET" action="<?= BASE_URL ?>/panel.php" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="kalite-hortum-gecmis">
    <div class="form-grup" style="margin:0"><label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="bas" value="<?= $bas ?>"></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="bit" value="<?= $bit ?>"></div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
  </form>
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:16px">
  <?php foreach ([
    ['Toplam Test',     $ozet['toplam']??0,    '#1E3A5F','#E0F2FE'],
    ['Geçti',           $ozet['gecti']??0,     '#22C55E','#D1FAE5'],
    ['Kaldı',           $ozet['kaldi']??0,     '#EF4444','#FEE2E2'],
    ['Ort. Süre (sn)',  $ozet['ort_sure']??'—','#6366F1','#EDE9FE'],
    ['Ort. Basınç Düş.',$ozet['ort_dusus']??'—','#F59E0B','#FEF9C3'],
    ['Ort. Akış L/dk',  $ozet['ort_akis']??'—','#0EA5E9','#E0F7FA'],
  ] as [$l,$v,$f,$b]): ?>
  <div style="background:<?= $b ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:20px;font-weight:900;color:<?= $f ?>"><?= $v ?></div>
    <div style="font-size:9px;color:<?= $f ?>;font-weight:700;text-transform:uppercase;margin-top:2px"><?= $l ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0">
  <div style="overflow-x:auto">
    <?php $sth=['#','Tarih','Reçete','Operatör','A1','A1 Düşüş','A2','A2 Akış','Süre','Sonuç']; ?>
    <table id="htGecmisTbl" class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach($sth as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:8px 10px;font-size:12px;font-weight:700;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $i => $r):
          $gb=$r['genel_sonuc']=='1';
          $rbg=$gb?'background:#D1FAE5':'background:#FEE2E2';
      ?>
      <tr style="<?= $rbg ?>">
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td style="white-space:nowrap;font-size:11px"><?= htmlspecialchars($r['kayit_tarihi']) ?></td>
        <td style="font-size:12px"><?= htmlspecialchars($r['recete_adi']??'—') ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['operatör']??'—') ?></td>
        <td style="text-align:center;font-weight:700"><?= $r['asama1_sonuc']=='1'?'✅':'❌' ?></td>
        <td style="text-align:right;font-size:11px"><?= $r['asama1_dusus_bar']?number_format($r['asama1_dusus_bar'],4).' bar':'—' ?></td>
        <td style="text-align:center;font-weight:700"><?= $r['asama2_sonuc']!==null?($r['asama2_sonuc']=='1'?'✅':'❌'):'—' ?></td>
        <td style="text-align:right;font-size:11px"><?= $r['asama2_akis_ldk']?number_format($r['asama2_akis_ldk'],1).' L/dk':'—' ?></td>
        <td style="text-align:right;font-size:11px"><?= $r['sure_sn'] ?> sn</td>
        <td style="font-weight:800;text-align:center"><?= $gb?'✅ GEÇTI':'❌ KALDI' ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
$(document).ready(function(){
  $('#htGecmisTbl').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true,scrollY:500,scrollCollapse:true,paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'HortumTest_<?= date('Ymd') ?>'}],
    drawCallback:function(){ $('#htGecmisTbl thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){ $('#htGecmisTbl thead th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); }
  });
});
</script>
