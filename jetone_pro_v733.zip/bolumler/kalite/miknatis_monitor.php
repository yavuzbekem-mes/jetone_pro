<?php
/**
 * JETONE.PRO — Tekmelik Mıknatıs Canlı İzleme (Simülasyon + Gerçek)
 * bolumler/kalite/miknatis_monitor.php
 * panel.php: 'kalite-miknatis-monitor' => 'bolumler/kalite/miknatis_monitor.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$cihazlar = [
    'KRT-01','KRT-02','KRT-03','KRT-04',
    'KRT-05','KRT-06','KRT-07','KRT-08',
];
$secili = in_array($_GET['cihaz'] ?? '', $cihazlar)
        ? $_GET['cihaz'] : 'KRT-01';

// ── AJAX: Son durum ───────────────────────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'son_durum') {
    header('Content-Type: application/json; charset=utf-8');
    ob_end_clean();
    $mak = in_array($_GET['makina'] ?? '', $cihazlar) ? $_GET['makina'] : 'KRT-01';
    try {
        $row = $db->prepare("
            SELECT id, urun_kodu, durum, m1, m2, m3, eksik_adet, aciklama,
                   DATE_FORMAT(kontrol_zamani,'%H:%i:%s') AS saat,
                   kontrol_zamani
            FROM miknatis_kontroller
            WHERE makina_kodu = ?
            ORDER BY kontrol_zamani DESC
            LIMIT 1
        ");
        $row->execute([$mak]);
        $son = $row->fetch(PDO::FETCH_ASSOC);

        $ozet = $db->prepare("
            SELECT COUNT(*) AS toplam,
                   SUM(durum='basarili') AS basarili,
                   SUM(durum IN('hata_1','hata_2','hata_3')) AS hatali,
                   SUM(durum='duzeltildi') AS duzeltildi,
                   ROUND(SUM(durum IN('basarili','duzeltildi'))/NULLIF(COUNT(*),0)*100,1) AS oran
            FROM miknatis_kontroller
            WHERE makina_kodu=? AND DATE(kontrol_zamani)=CURDATE()
        ");
        $ozet->execute([$mak]);
        $oz = $ozet->fetch(PDO::FETCH_ASSOC);

        // Son 20 kayıt
        $liste = $db->prepare("
            SELECT id, urun_kodu, durum, m1, m2, m3, eksik_adet,
                   DATE_FORMAT(kontrol_zamani,'%H:%i:%s') AS saat,
                   aciklama
            FROM miknatis_kontroller
            WHERE makina_kodu=?
            ORDER BY kontrol_zamani DESC
            LIMIT 20
        ");
        $liste->execute([$mak]);

        echo json_encode(['ok'=>true,'son'=>$son,'ozet'=>$oz,'liste'=>$liste->fetchAll(PDO::FETCH_ASSOC)]);
    } catch (Throwable $e) {
        echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
    }
    exit;
}

// ── AJAX: Simülasyon kaydı ekle ───────────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'sim_kayit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    ob_end_clean();
    $mak  = in_array($_POST['makina'] ?? '', $cihazlar) ? $_POST['makina'] : 'KRT-01';
    $m1   = (int)(bool)($_POST['m1'] ?? 0);
    $m2   = (int)(bool)($_POST['m2'] ?? 0);
    $m3   = (int)(bool)($_POST['m3'] ?? 0);
    $urun = strtoupper(trim($_POST['urun_kodu'] ?? 'TEST'));
    $eksik = 3 - ($m1 + $m2 + $m3);
    $durum = $eksik === 0 ? 'basarili' : "hata_{$eksik}";
    try {
        $db->prepare("INSERT INTO miknatis_kontroller
            (urun_kodu, makina_kodu, durum, m1, m2, m3, eksik_adet, aciklama)
            VALUES (?,?,?,?,?,?,?,?)")
          ->execute([$urun, $mak, $durum, $m1, $m2, $m3, $eksik, 'Simülasyon']);
        echo json_encode(['ok'=>true,'durum'=>$durum,'eksik'=>$eksik]);
    } catch (Throwable $e) {
        echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
    }
    exit;
}

// Tanımlı ürün kodu
$tanim_urun = '';
try {
    $t = $db->prepare("SELECT urun_kodu FROM miknatis_cihaz_tanim WHERE makina_kodu=? AND aktif=1 LIMIT 1");
    $t->execute([$secili]);
    $tanim_urun = $t->fetchColumn() ?: '';
} catch (Throwable $e) {}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📡 Canlı Sensör İzleme</h1>
    <div class="s-yol">Kalite / <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" style="color:var(--t)">Test Cihazları</a> / <b>Canlı Monitor</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-cihazlar" class="btn btn-b btn-sm">← Cihazlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-sonuclar&makina=<?= $secili ?>" class="btn btn-b btn-sm">📋 Sonuçlar</a>
  </div>
</div>

<div class="s-body">

<!-- Cihaz seçici -->
<div class="kart" style="margin-bottom:16px;padding:12px 16px">
  <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <span style="font-size:12px;color:var(--m2);font-weight:700">CİHAZ SEÇ:</span>
    <?php foreach ($cihazlar as $c): ?>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-monitor&cihaz=<?= $c ?>"
       style="padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;text-decoration:none;
              background:<?= $c===$secili?'var(--t)':'var(--kenar-a)' ?>;
              color:<?= $c===$secili?'#fff':'var(--m)' ?>">
      <?= $c ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" class="monitor-grid">

  <!-- Sol: Canlı Sensör Durumu -->
  <div>

    <!-- Makina Görsel Paneli -->
    <div class="kart" style="margin-bottom:14px;padding:14px">

      <div style="font-size:10px;color:var(--m2);font-weight:700;letter-spacing:.08em;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <span>CİHAZ: <span id="monMakina" style="color:var(--t)"><?= $secili ?></span></span>
          <span style="margin-left:10px;background:var(--t-a);color:var(--t);padding:1px 8px;border-radius:10px;font-size:10px;font-weight:800">
            <?= $tanim_urun ?: '—' ?>
          </span>
        </div>
        <span id="monBlink" style="color:#22C55E;font-size:8px">●</span>
      </div>

      <div style="display:flex;gap:8px;align-items:stretch">
        <!-- Solenoid 1 -->
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px">
          <div id="monSol1" style="width:28px;height:44px;border-radius:5px;background:#D1FAE5;border:2px solid #22C55E;
                           display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;transition:.3s">
            <span id="monSol1Iko" style="font-size:15px">🔓</span>
            <span id="monSol1Txt" style="font-size:7px;font-weight:800;color:#065F46">AÇK</span>
          </div>
          <div style="font-size:8px;color:var(--m2);font-weight:700">SOL1</div>
        </div>

        <!-- Fikstür orta -->
        <div id="monFikstur" style="flex:1;background:#F8FAFC;border:2px solid #CBD5E1;border-radius:8px;padding:8px;transition:.3s">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <code id="monUrunKod" style="background:rgba(0,0,0,.07);padding:2px 7px;border-radius:4px;font-size:11px;font-weight:800">—</code>
            <span id="monDurumRoz" style="padding:2px 8px;border-radius:10px;font-size:9px;font-weight:800;background:#F1F5F9;color:#64748B">— Bekleniyor</span>
          </div>
          <!-- M1 M2 M3 büyük daireler -->
          <div style="display:flex;align-items:center;gap:8px;justify-content:center;margin-bottom:6px">
            <div style="font-size:9px;font-weight:800;color:var(--m2)">TEKMELİK</div>
            <?php for ($i = 1; $i <= 3; $i++): ?>
            <div style="text-align:center">
              <div id="m<?= $i ?>Ring" style="width:40px;height:40px;border-radius:50%;border:2px solid #94A3B8;
                    background:#F1F5F9;display:flex;align-items:center;justify-content:center;
                    margin:0 auto 3px;transition:.3s">
                <span id="m<?= $i ?>Icon" style="font-size:16px;font-weight:800;color:#94A3B8">M<?= $i ?></span>
              </div>
              <div id="m<?= $i ?>Label" style="font-size:9px;color:#94A3B8">—</div>
            </div>
            <?php endfor; ?>
          </div>
          <div style="text-align:center;font-size:10px;color:var(--m2)">
            Ürün: <span id="monUrunVar" style="font-weight:700;color:#94A3B8">○ Yok</span>
          </div>
        </div>

        <!-- Sağ: SOL2 + LED trafik -->
        <div style="display:flex;flex-direction:column;align-items:center;gap:5px">
          <div id="monSol2" style="width:28px;height:44px;border-radius:5px;background:#D1FAE5;border:2px solid #22C55E;
                           display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;transition:.3s">
            <span id="monSol2Iko" style="font-size:15px">🔓</span>
            <span id="monSol2Txt" style="font-size:7px;font-weight:800;color:#065F46">AÇK</span>
          </div>
          <div style="font-size:8px;color:var(--m2);font-weight:700">SOL2</div>
          <div style="display:flex;flex-direction:column;gap:3px;margin-top:4px">
            <div id="monLedK" style="width:12px;height:12px;border-radius:50%;background:#E2E8F0;transition:.3s"></div>
            <div id="monLedS" style="width:12px;height:12px;border-radius:50%;background:#F59E0B"></div>
            <div id="monLedY" style="width:12px;height:12px;border-radius:50%;background:#E2E8F0;transition:.3s"></div>
          </div>
        </div>
      </div>

      <!-- OLED Ekran — 0.96" 128x64 layout -->
      <div style="background:#0a0f1a;border-radius:6px;border:2px solid #1E3A5F;padding:8px 10px;
                  margin-top:10px;font-family:monospace;font-size:11px;color:#22C55E;line-height:1.6">
        <!-- Satır 1: Cihaz | WiFi -->
        <div style="display:flex;justify-content:space-between;align-items:center;
                    border-bottom:1px solid #1E293B;padding-bottom:3px;margin-bottom:4px">
          <span style="color:#F97316;font-weight:700;font-size:10px"><?= $secili ?></span>
          <span id="monWifi" style="font-size:10px;color:#22C55E">▲ WiFi</span>
        </div>
        <!-- Satır 2: Ürün kodu — kalın -->
        <div style="font-size:14px;font-weight:900;color:#fff;letter-spacing:.04em;
                    margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
             id="monOledUrun"><?= htmlspecialchars($tanim_urun ?: '—') ?></div>
        <!-- Satır 3: Günlük sayaç -->
        <div style="display:flex;gap:10px;font-size:10px;color:#64748B;margin-bottom:3px" id="monOledSayac">
          <span>OK: <b id="monOledOk" style="color:#22C55E">—</b></span>
          <span>Hata: <b id="monOledHata" style="color:#EF4444">—</b></span>
          <span>Top: <b id="monOledTop" style="color:#94A3B8">—</b></span>
        </div>
        <!-- Satır 4-5: Durum + Açıklama -->
        <div id="monOledS1" style="font-size:11px;font-weight:700;color:#22C55E">Hazır</div>
        <div id="monOledS2" style="font-size:10px;color:#94A3B8">Ürün bekleniyor</div>
        <div id="monOledS3" style="font-size:9px;color:#475569"></div>
      </div>

      <!-- Sonuç rozeti büyük -->
      <div style="text-align:center;margin-top:10px">
        <span id="sonucRoz" style="display:inline-block;padding:5px 20px;border-radius:20px;font-size:13px;font-weight:800;
                                    background:var(--kenar-a);color:var(--m2)">— Bekleniyor —</span>
      </div>

      <!-- Alt: Yazıcı Buzzer ESP32 + Özet sayaçlar -->
      <div style="display:flex;gap:6px;margin-top:10px">
        <div style="flex:1;background:var(--kenar-a);border-radius:5px;padding:5px;text-align:center">
          <div style="font-size:8px;color:var(--m2);font-weight:700">YAZICI</div>
          <div id="monYaziciD" style="font-size:10px;font-weight:700;color:#CBD5E1">○ Bekle</div>
        </div>
        <div style="background:var(--kenar-a);border-radius:5px;padding:5px;text-align:center;min-width:34px">
          <div style="font-size:8px;color:var(--m2);font-weight:700">BZR</div>
          <div id="monBzrD" style="font-size:12px">🔇</div>
        </div>
        <div style="flex:1;background:var(--kenar-a);border-radius:5px;padding:5px;text-align:center">
          <div style="font-size:8px;color:var(--m2);font-weight:700">ESP32</div>
          <div style="font-size:9px;font-weight:700;color:#2563EB">Wi-Fi</div>
        </div>
      </div>

      <!-- Özet sayaçlar -->
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:10px">
        <?php
        $kutu = [['basarili','#22C55E'],['hatali','#EF4444'],['duzeltildi','#A855F7'],['oran%','#F97316']];
        $ids  = ['monBasarili','monHatali','monDuz','monOran'];
        for ($i=0;$i<4;$i++): ?>
        <div style="text-align:center;background:var(--kenar-a);border-radius:6px;padding:8px 4px">
          <div id="<?= $ids[$i] ?>" style="font-size:18px;font-weight:800;color:<?= $kutu[$i][1] ?>">—</div>
          <div style="font-size:9px;color:var(--m2);text-transform:uppercase;margin-top:2px"><?= $kutu[$i][0] ?></div>
        </div>
        <?php endfor; ?>
      </div>
    </div>

    <!-- Simülasyon paneli -->
    <div class="kart" style="border-left:4px solid var(--uya)">
      <div style="font-size:13px;font-weight:800;margin-bottom:12px">🎮 Simülasyon — Manuel Test Gönder</div>
      <div style="font-size:11px;color:var(--m2);margin-bottom:12px">
        Fiziksel cihaz yokken test verileri oluşturmak için kullanın.
      </div>

      <div class="form-grid-2" style="gap:8px;margin-bottom:12px">
        <div class="form-grup" style="margin:0">
          <label class="form-et">Ürün Kodu</label>
          <select class="form-alan" id="simUrun" style="font-size:12px;padding:6px 10px">
            <?php
            $sim_urunler = ['2985310100','2985310200','2985310300','2985310400','2985310500','2985310600','2985310700',
                            '2987910100','2987910200','2987910300','2987910400','2987910500','2987910600','2987910700',
                            '2988080100','2988080200','2988080300','2988080400','2988080500','2988080600','2988080700',
                            '2995190100','2995190200','2995190400','2995190500','2995190600'];
            foreach ($sim_urunler as $su): ?>
            <option value="<?= $su ?>" <?= ($tanim_urun===$su)?'selected':'' ?>><?= $su ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup" style="margin:0">
          <label class="form-et">Cihaz</label>
          <input class="form-alan" type="text" value="<?= $secili ?>" readonly
                 style="font-size:12px;padding:6px 10px;background:var(--kenar-a)">
        </div>
      </div>

      <!-- M1 M2 M3 toggle -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px">
        <?php for ($i=1;$i<=3;$i++): ?>
        <div>
          <label class="form-et">M<?= $i ?> Sensör</label>
          <button type="button" id="simM<?= $i ?>Btn" onclick="toggleSim(<?= $i ?>)"
                  style="width:100%;padding:10px;border-radius:var(--r);border:2px solid var(--kenar);
                         background:var(--hat-a);color:var(--hat);font-weight:800;font-size:13px;cursor:pointer">
            ✗ Yok
          </button>
          <input type="hidden" id="simM<?= $i ?>" value="0">
        </div>
        <?php endfor; ?>
      </div>

      <!-- Hazır senaryolar -->
      <div style="margin-bottom:12px;display:flex;gap:6px;flex-wrap:wrap">
        <span style="font-size:11px;color:var(--m2);align-self:center">Hızlı:</span>
        <button onclick="senaryo(1,1,1)" class="btn btn-sm"
                style="background:#D1FAE5;color:#065F46;font-size:11px">✓✓✓ Tümü Var</button>
        <button onclick="senaryo(0,1,1)" class="btn btn-sm"
                style="background:#FEE2E2;color:#991B1B;font-size:11px">✗✓✓ M1 Yok</button>
        <button onclick="senaryo(1,0,1)" class="btn btn-sm"
                style="background:#FEE2E2;color:#991B1B;font-size:11px">✓✗✓ M2 Yok</button>
        <button onclick="senaryo(1,1,0)" class="btn btn-sm"
                style="background:#FEE2E2;color:#991B1B;font-size:11px">✓✓✗ M3 Yok</button>
        <button onclick="senaryo(0,0,0)" class="btn btn-sm"
                style="background:#7F1D1D;color:#fff;font-size:11px">✗✗✗ Hiç Yok</button>
      </div>

      <button onclick="simGonder()" class="btn btn-t" style="width:100%;font-size:13px">
        ▶ Test Kaydı Gönder
      </button>
      <div id="simSonuc" style="margin-top:8px;font-size:12px;display:none"></div>
    </div>

  </div>

  <!-- Sağ: Son 20 kayıt -->
  <div>
    <div class="kart" style="padding:0;overflow:hidden">
      <div style="padding:12px 16px;background:#1E3A5F;display:flex;align-items:center;justify-content:space-between">
        <div style="font-weight:800;font-size:13px;color:#fff">📋 Son Testler</div>
        <div style="font-size:10px;color:#94A3B8" id="sonGun">—</div>
      </div>
      <div style="overflow-y:auto;max-height:620px">
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead>
            <tr style="background:#F1F5F9">
              <th style="padding:7px 10px;text-align:left;color:#000;font-weight:700;white-space:nowrap;border-bottom:2px solid #E2E8F0">Saat</th>
              <th style="padding:7px 10px;text-align:left;color:#000;font-weight:700;border-bottom:2px solid #E2E8F0">Ürün</th>
              <th style="padding:7px 10px;text-align:center;color:#000;font-weight:700;border-bottom:2px solid #E2E8F0">M1</th>
              <th style="padding:7px 10px;text-align:center;color:#000;font-weight:700;border-bottom:2px solid #E2E8F0">M2</th>
              <th style="padding:7px 10px;text-align:center;color:#000;font-weight:700;border-bottom:2px solid #E2E8F0">M3</th>
              <th style="padding:7px 10px;text-align:left;color:#000;font-weight:700;border-bottom:2px solid #E2E8F0">Durum</th>
            </tr>
          </thead>
          <tbody id="monTablo">
            <tr><td colspan="6" style="text-align:center;padding:20px;color:#94A3B8">Yükleniyor...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div><!-- /grid -->
</div><!-- /s-body -->

<style>
@media(max-width:768px){.monitor-grid{grid-template-columns:1fr!important}}
</style>

<script>
const MON_MAKINA = '<?= $secili ?>';
const MON_BASE   = '<?= BASE_URL ?>/panel.php?sayfa=kalite-miknatis-monitor';
const AJAX_BASE  = '<?= BASE_URL ?>/bolumler/kalite/ajax/miknatis_ajax.php';

const DURUM_HTML = {
  basarili:   '<span style="background:#D1FAE5;color:#065F46;padding:2px 9px;border-radius:12px;font-weight:800;font-size:11px">✓ Başarılı</span>',
  hata_1:     '<span style="background:#FEF9C3;color:#92400E;padding:2px 9px;border-radius:12px;font-weight:800;font-size:11px">⚠ 1 Eksik</span>',
  hata_2:     '<span style="background:#FEE2E2;color:#991B1B;padding:2px 9px;border-radius:12px;font-weight:800;font-size:11px">✗ 2 Eksik</span>',
  hata_3:     '<span style="background:#7F1D1D;color:#fff;padding:2px 9px;border-radius:12px;font-weight:800;font-size:11px">✗✗ 3 Eksik</span>',
  duzeltildi: '<span style="background:#EDE9FE;color:#5B21B6;padding:2px 9px;border-radius:12px;font-weight:800;font-size:11px">✔ Düzeltildi</span>',
};
const DOT = v => v==1
  ? '<span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:#22C55E;border:2px solid #166534"></span>'
  : '<span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:#EF4444;border:2px solid #7F1D1D"></span>';

function oledGuncelle(son, ozet) {
    if (!son) return;
    const durum = son.durum || '';
    const m = [+son.m1, +son.m2, +son.m3];
    const eksikler = [];
    if (!m[0]) eksikler.push('M1');
    if (!m[1]) eksikler.push('M2');
    if (!m[2]) eksikler.push('M3');

    let s1='Hazır', s2='Ürün bekleniyor', s3='', renk='#22C55E';
    if (durum==='basarili')   { s1='TAMAM!'; s2='Parça alınabilir'; s3='Solenoid: AÇIK'; renk='#22C55E'; }
    else if (durum==='duzeltildi') { s1='DÜZELTİLDİ!'; s2='Parça alınabilir'; s3='Solenoid: AÇIK'; renk='#A855F7'; }
    else if (durum.startsWith('hata')) { s1='MIK. EKSİK!'; s2='Eksik: '+eksikler.join(' '); s3='3sn tekrar kontrol'; renk='#EF4444'; }

    const o1=document.getElementById('monOledUrun');
    const o2=document.getElementById('monOledS1');
    const o3=document.getElementById('monOledS2');
    const o4=document.getElementById('monOledS3');
    // urun_kodu OLED'de gösterilmez — tanim tablosundan geliyor, PHP render'da zaten var
    if(o2){ o2.textContent=s1; o2.style.color=renk; }
    if(o3) o3.textContent=s2;
    if(o4) o4.textContent=s3;
    // Günlük sayaçlar
    if(ozet){
        var ok  =document.getElementById('monOledOk');   if(ok)   ok.textContent  = ozet.basarili   ||0;
        var ht  =document.getElementById('monOledHata'); if(ht)   ht.textContent  = ozet.hatali     ||0;
        var top =document.getElementById('monOledTop');  if(top)  top.textContent = ozet.toplam     ||0;
    }
}

function guncelleSensor(son) {
  if (!son) return;
  const durum = son.durum || '';
  const solAcik = (durum==='basarili'||durum==='duzeltildi'||!durum);
  const hata = durum.startsWith('hata');

  // Mıknatıs daireler
  [1,2,3].forEach(function(idx){
    const ring  = document.getElementById('m'+idx+'Ring');
    const icon  = document.getElementById('m'+idx+'Icon');
    const label = document.getElementById('m'+idx+'Label');
    if(!ring) return;
    const v = son['m'+idx]==1;
    ring.style.background   = v ? '#D1FAE5' : '#FEE2E2';
    ring.style.borderColor  = v ? '#22C55E' : '#EF4444';
    icon.textContent        = v ? ('M'+idx) : '✗';
    icon.style.color        = v ? '#065F46' : '#7F1D1D';
    if(label){ label.textContent = v?'VAR':'YOK'; label.style.color = v?'#22C55E':'#EF4444'; }
  });

  // Sonuç rozeti
  const roz = document.getElementById('sonucRoz');
  const RMAP = {
    basarili:   {bg:'#D1FAE5',fg:'#065F46',txt:'✓ BAŞARILI'},
    hata_1:     {bg:'#FEF9C3',fg:'#92400E',txt:'⚠ 1 EKSİK'},
    hata_2:     {bg:'#FEE2E2',fg:'#991B1B',txt:'✗ 2 EKSİK'},
    hata_3:     {bg:'#FCA5A5',fg:'#7F1D1D',txt:'✗✗ 3 EKSİK'},
    duzeltildi: {bg:'#EDE9FE',fg:'#5B21B6',txt:'✔ DÜZELTİLDİ'},
  };
  const r = RMAP[durum] || {bg:'var(--kenar-a)',fg:'var(--m2)',txt:'— Bekleniyor —'};
  if(roz){ roz.style.background=r.bg; roz.style.color=r.fg; roz.textContent=r.txt+(son.saat?' — '+son.saat:''); }

  // Solenoid
  function setSol(id, ikoId, txtId, acik) {
    const el=document.getElementById(id); if(!el) return;
    el.style.background = acik?'#D1FAE5':'#FEE2E2';
    el.style.borderColor = acik?'#22C55E':'#EF4444';
    const ik=document.getElementById(ikoId); if(ik) ik.textContent=acik?'🔓':'🔒';
    const tx=document.getElementById(txtId); if(tx){ tx.textContent=acik?'AÇK':'KLT'; tx.style.color=acik?'#065F46':'#7F1D1D'; }
  }
  setSol('monSol1','monSol1Iko','monSol1Txt',solAcik);
  setSol('monSol2','monSol2Iko','monSol2Txt',solAcik);

  // LED trafik
  const ledY=document.getElementById('monLedY');
  const ledS=document.getElementById('monLedS');
  const ledK=document.getElementById('monLedK');
  if(ledY) ledY.style.background = (solAcik&&durum)?'#22C55E':'#E2E8F0';
  if(ledS) ledS.style.background = !durum?'#F59E0B':'#E2E8F0';
  if(ledK) ledK.style.background = hata?'#EF4444':'#E2E8F0';

  // Fikstür border
  const fk=document.getElementById('monFikstur');
  if(fk){ fk.style.borderColor = solAcik&&durum?'#22C55E':(hata?'#EF4444':'#CBD5E1');
          fk.style.background  = solAcik&&durum?'#F0FDF4':(hata?'#FEF2F2':'#F8FAFC'); }

  // Durum rozeti fikstür içi
  const dr=document.getElementById('monDurumRoz');
  if(dr){ dr.style.background=r.bg; dr.style.color=r.fg; dr.textContent=r.txt+(son.saat?' '+son.saat:''); }

  // Ürün kodu
  const uk=document.getElementById('monUrunKod');
  if(uk) uk.textContent=son.urun_kodu||'—';

  // Ürün varlık
  const uv=document.getElementById('monUrunVar');
  if(uv){ uv.textContent='● Aktif'; uv.style.color='#22C55E'; }

  // Yazıcı + Buzzer
  const yz=document.getElementById('monYaziciD');
  if(yz){ yz.textContent=(solAcik&&durum)?'● ZPL':'○ Bekle'; yz.style.color=(solAcik&&durum)?'#A855F7':'#CBD5E1'; }
  const bz=document.getElementById('monBzrD');
  if(bz) bz.textContent=hata?'🔊':'🔇';
}

function guncelleOzet(oz) {
  if (!oz) return;
  document.getElementById('monBasarili').textContent = oz.basarili  || 0;
  document.getElementById('monHatali').textContent   = oz.hatali    || 0;
  document.getElementById('monDuz').textContent      = oz.duzeltildi|| 0;
  document.getElementById('monOran').textContent     = (oz.oran||0)+'%';
}

function guncelleTablo(liste) {
  if (!liste || !liste.length) {
    document.getElementById('monTablo').innerHTML =
      '<tr><td colspan="6" style="text-align:center;padding:20px;color:#94A3B8">Kayıt yok</td></tr>';
    return;
  }
  document.getElementById('monTablo').innerHTML = liste.map(r => `
    <tr style="border-bottom:1px solid #F1F5F9">
      <td style="padding:6px 10px;white-space:nowrap;color:#64748B">${r.saat}</td>
      <td style="padding:6px 10px;font-weight:700">${r.urun_kodu}</td>
      <td style="padding:6px 10px;text-align:center">${DOT(r.m1)}</td>
      <td style="padding:6px 10px;text-align:center">${DOT(r.m2)}</td>
      <td style="padding:6px 10px;text-align:center">${DOT(r.m3)}</td>
      <td style="padding:6px 10px">${DURUM_HTML[r.durum]||r.durum}</td>
    </tr>
  `).join('');
  document.getElementById('sonGun').textContent = liste.length + ' kayıt · ' + new Date().toLocaleTimeString('tr-TR');
}

// Blink animasyonu
let blinkOn = true;
setInterval(()=>{
  const el = document.getElementById('monBlink');
  if(el){ el.style.opacity = blinkOn?'1':'0'; blinkOn=!blinkOn; }
}, 800);

async function yenile() {
  try {
    const r = await fetch(AJAX_BASE + '?action=son_durum&makina=' + MON_MAKINA);
    const d = await r.json();
    if (d.ok) {
      guncelleSensor(d.son);
      guncelleOzet(d.ozet);
      guncelleTablo(d.liste);
      oledGuncelle(d.son, d.ozet);
    }
  } catch(e){}
}

// Simülasyon
function toggleSim(i) {
  const inp = document.getElementById('simM'+i);
  const btn = document.getElementById('simM'+i+'Btn');
  inp.value = inp.value=='1' ? '0' : '1';
  if (inp.value=='1') {
    btn.style.background='#D1FAE5'; btn.style.color='#065F46'; btn.style.borderColor='#22C55E';
    btn.textContent='✓ Var';
  } else {
    btn.style.background='var(--hat-a)'; btn.style.color='var(--hat)'; btn.style.borderColor='var(--kenar)';
    btn.textContent='✗ Yok';
  }
}

function senaryo(m1,m2,m3) {
  [m1,m2,m3].forEach((v,i)=>{
    document.getElementById('simM'+(i+1)).value = v;
    const btn = document.getElementById('simM'+(i+1)+'Btn');
    if(v){ btn.style.background='#D1FAE5';btn.style.color='#065F46';btn.style.borderColor='#22C55E';btn.textContent='✓ Var'; }
    else  { btn.style.background='var(--hat-a)';btn.style.color='var(--hat)';btn.style.borderColor='var(--kenar)';btn.textContent='✗ Yok'; }
  });
}

async function simGonder() {
  const m1 = document.getElementById('simM1').value;
  const m2 = document.getElementById('simM2').value;
  const m3 = document.getElementById('simM3').value;
  const ur = document.getElementById('simUrun').value.trim();
  if (!ur) { alert('Ürün kodu seçin'); return; }
  const sonuc = document.getElementById('simSonuc');
  sonuc.style.display='block'; sonuc.style.color='var(--uya)'; sonuc.textContent='Gönderiliyor...';
  try {
    const fd = new FormData();
    fd.append('makina', MON_MAKINA); fd.append('m1',m1); fd.append('m2',m2); fd.append('m3',m3); fd.append('urun_kodu',ur);
    const r = await fetch(AJAX_BASE+'?action=sim_kayit', {method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}});
    const d = await r.json();
    if(d.ok){
      sonuc.style.color='var(--bas)';
      sonuc.textContent='✅ Kayıt eklendi — ' + (d.durum==='basarili'?'Başarılı':`${d.eksik} Eksik`);
      yenile();
    } else { sonuc.style.color='var(--hat)'; sonuc.textContent='❌ '+d.hata; }
  } catch(e){ sonuc.style.color='var(--hat)'; sonuc.textContent='Bağlantı hatası'; }
}

yenile();
setInterval(yenile, 5000);

// ── CANLI POLLING (1 sn — ESP32'den anlık sensör) ─────────────
const CANLI_URL = '<?= BASE_URL ?>/bolumler/kalite/api/canli_durum.php';

// Durum string → Türkçe açıklama
function durumAcikla(d) {
    const map = {
        'BEKLEME':       {txt:'Ürün bekleniyor',     renk:'#22C55E'},
        'SOL_KAPANIYOR': {txt:'Solenoid kapanıyor…', renk:'#F59E0B'},
        'HALL_BEKLEME':  {txt:'Mıknatıs kontrolü…',  renk:'#F59E0B'},
        'HALL_KONTROL':  {txt:'Sensörler okunuyor…', renk:'#F59E0B'},
        'BASARILI':      {txt:'TAMAM! Parça alın.',  renk:'#22C55E'},
        'HATA_BEKLE':    {txt:'EKSİK MIKNATIS!',     renk:'#EF4444'},
        'URUN_ALINDI':   {txt:'Ürün alındı.',        renk:'#A855F7'},
    };
    return map[d] || {txt: d || '—', renk:'#94A3B8'};
}

async function canliYenile() {
    try {
        const url = CANLI_URL + '?action=oku&makina=' + MON_MAKINA + '&_t=' + Date.now();
        const r = await fetch(url);
        const d = await r.json();
        console.log('[canliYenile]', d);  // DEBUG

        // Online/Offline — her sorguda güncelle
        const online = d.online === true;
        const ip     = d.ip || '';
        const blink  = document.getElementById('monBlink');
        if (blink) {
            blink.style.color = online ? '#22C55E' : '#EF4444';
            blink.textContent = online ? ('● Online' + (ip ? ' ' + ip : '')) : '● Offline';
        }
        const wf = document.getElementById('monWifi');
        if (wf) { wf.textContent = online ? '▲ WiFi' : '✗ WiFi'; wf.style.color = online ? '#22C55E' : '#EF4444'; }

        if (!d.ok || !d.veri) return;
        const v = d.veri;

        // Mıknatıs daireler
        [1,2,3].forEach(function(i){
            const ring = document.getElementById('m'+i+'Ring');
            const icon = document.getElementById('m'+i+'Icon');
            const lbl  = document.getElementById('m'+i+'Label');
            if (!ring) return;
            const val = v['m'+i] == 1;
            ring.style.background  = val ? '#D1FAE5' : '#FEE2E2';
            ring.style.borderColor = val ? '#22C55E' : '#EF4444';
            if(icon){ icon.textContent = val ? ('M'+i) : '✗'; icon.style.color = val ? '#065F46' : '#7F1D1D'; }
            if(lbl) { lbl.textContent  = val ? 'VAR'  : 'YOK'; lbl.style.color = val ? '#22C55E' : '#EF4444'; }
        });

        // Ürün sensörü
        const urunVar = document.getElementById('monUrunVar');
        if (urunVar) {
            urunVar.textContent = v.s0==1 ? '● Var' : '○ Yok';
            urunVar.style.color = v.s0==1 ? '#22C55E' : '#94A3B8';
        }

        // Solenoid
        const solAcik = v.sol == 1;
        function setSol(id, ikoId, txtId) {
            const el=document.getElementById(id); if(!el) return;
            el.style.background  = solAcik?'#D1FAE5':'#FEE2E2';
            el.style.borderColor = solAcik?'#22C55E':'#EF4444';
            const ik=document.getElementById(ikoId); if(ik) ik.textContent=solAcik?'🔓':'🔒';
            const tx=document.getElementById(txtId); if(tx){ tx.textContent=solAcik?'AÇK':'KLT'; tx.style.color=solAcik?'#065F46':'#7F1D1D'; }
        }
        setSol('monSol1','monSol1Iko','monSol1Txt');
        setSol('monSol2','monSol2Iko','monSol2Txt');

        // LED
        const ledY=document.getElementById('monLedY'), ledS=document.getElementById('monLedS'), ledK=document.getElementById('monLedK');
        if(ledY) ledY.style.background = v.durum==='BASARILI'?'#22C55E':'#E2E8F0';
        if(ledS) ledS.style.background = ['HALL_BEKLEME','HALL_KONTROL','SOL_KAPANIYOR'].includes(v.durum)?'#F59E0B':'#E2E8F0';
        if(ledK) ledK.style.background = v.durum==='HATA_BEKLE'?'#EF4444':'#E2E8F0';

        // Fikstür border
        const fk=document.getElementById('monFikstur');
        if(fk){
            if(v.durum==='BASARILI')   { fk.style.borderColor='#22C55E'; fk.style.background='#F0FDF4'; }
            else if(v.durum==='HATA_BEKLE') { fk.style.borderColor='#EF4444'; fk.style.background='#FEF2F2'; }
            else { fk.style.borderColor='#CBD5E1'; fk.style.background='#F8FAFC'; }
        }

        // Durum rozeti
        const dr  = document.getElementById('monDurumRoz');
        const ac  = durumAcikla(v.durum);
        if(dr){ dr.textContent=ac.txt; dr.style.color=ac.renk; dr.style.background=ac.renk+'22'; }

        // Sonuç rozeti
        const roz = document.getElementById('sonucRoz');
        if(roz){ roz.textContent=ac.txt+' — '+v.saat; roz.style.color=ac.renk; roz.style.background=ac.renk+'22'; }

        // OLED
        const os1=document.getElementById('monOledS1'), os2=document.getElementById('monOledS2');
        if(os1){ os1.textContent=ac.txt; os1.style.color=ac.renk; }
        if(os2){
            if(v.durum==='HATA_BEKLE'){
                const eks=[]; if(!v.m1) eks.push('M1'); if(!v.m2) eks.push('M2'); if(!v.m3) eks.push('M3');
                os2.textContent='Eksik: '+eks.join(' ');
            } else { os2.textContent=''; }
        }

    } catch(e){}
}

// Online — sayfa açılışında + 10 dk'da bir
function onlineGuncelle() {
    fetch('<?= BASE_URL ?>/bolumler/kalite/api/miknatis_online.php?_t=' + Date.now())
    .then(function(r){ return r.json(); })
    .then(function(d){
        if (!d.ok) return;
        var c = d.cihazlar[MON_MAKINA];
        if (!c) return;
        var online = c.online === true;
        var ip     = c.ip || '';
        var blink  = document.getElementById('monBlink');
        if (blink) {
            blink.style.color = online ? '#22C55E' : '#EF4444';
            blink.textContent = online ? ('● Online' + (ip ? ' ' + ip : '')) : '● Offline';
        }
        var wf = document.getElementById('monWifi');
        if (wf) { wf.textContent = online ? '▲ WiFi' : '✗ WiFi'; wf.style.color = online ? '#22C55E' : '#EF4444'; }
    })
    .catch(function(){});
}

setInterval(canliYenile, 5000);
canliYenile();
onlineGuncelle();
setInterval(onlineGuncelle, 600000);
</script>
