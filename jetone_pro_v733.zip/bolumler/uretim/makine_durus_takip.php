<?php
if(!defined('ROOT_DIR')) require_once dirname(__DIR__,2).'/core/config.php';
if(!isset($mes_pdo))     require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth'))require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

$f_emri  = trim($_GET['emri']  ?? '');
$f_ist   = trim($_GET['ist']   ?? '');
$f_neden = trim($_GET['neden'] ?? '');
$f_basl  = trim($_GET['basl']  ?? date('Y-m-01'));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));

$duruslar = []; $nedenleri = [];
$ozet = ['toplam'=>0,'sure_dk'=>0];

if($mes_pdo){
    try {
        $where = ["CONVERT(date,BASLANGIC_ZAMANI) BETWEEN ? AND ?"];
        $params = [$f_basl,$f_bitis];
        if($f_emri)  { $where[]="URETIM_EMRI_NO LIKE ?"; $params[]="%$f_emri%"; }
        if($f_ist)   { $where[]="IS_ISTASYONU LIKE ?";    $params[]="%$f_ist%"; }
        if($f_neden) { $where[]="DURUS_NEDENI=?";         $params[]=$f_neden; }
        $ws = implode(' AND ',$where);

        $st = $mes_pdo->prepare("SELECT * FROM MAKINE_DURUSLARI WHERE $ws ORDER BY BASLANGIC_ZAMANI DESC");
        $st->execute($params); $duruslar = $st->fetchAll(PDO::FETCH_ASSOC);
        $ozet['toplam']  = count($duruslar);
        $ozet['sure_dk'] = (int)array_sum(array_column($duruslar,'SURE_DK'));

        $ns = $mes_pdo->query("SELECT DISTINCT DURUS_NEDENI FROM MAKINE_DURUSLARI WHERE DURUS_NEDENI IS NOT NULL ORDER BY DURUS_NEDENI");
        $nedenleri = $ns->fetchAll(PDO::FETCH_COLUMN);
    } catch(Throwable $e){ error_log("[DURUS_TAKIP]".$e->getMessage()); }
}

// Grafik verisi — günlük duruş
$gunluk = []; $neden_ozet = []; $ist_ozet = [];
foreach($duruslar as $d){
    $gun = substr($d['BASLANGIC_ZAMANI']??'',0,10);
    if(!isset($gunluk[$gun])) $gunluk[$gun] = ['sayi'=>0,'sure'=>0];
    $gunluk[$gun]['sayi']++;
    $gunluk[$gun]['sure'] += (int)($d['SURE_DK']??0);

    $n = $d['DURUS_NEDENI']??'Bilinmiyor';
    if(!isset($neden_ozet[$n])) $neden_ozet[$n] = ['sayi'=>0,'sure'=>0];
    $neden_ozet[$n]['sayi']++;
    $neden_ozet[$n]['sure'] += (int)($d['SURE_DK']??0);

    $ist = $d['IS_ISTASYONU']??'Bilinmiyor';
    if(!isset($ist_ozet[$ist])) $ist_ozet[$ist] = ['sayi'=>0,'sure'=>0];
    $ist_ozet[$ist]['sayi']++;
    $ist_ozet[$ist]['sure'] += (int)($d['SURE_DK']??0);
}
ksort($gunluk); arsort($neden_ozet); arsort($ist_ozet);

$s_saat = floor($ozet['sure_dk']/60); $s_dk = $ozet['sure_dk']%60;

$all_nedeni=['Kalıp Değişimi','Setup / Ayar Süresi','Hammadde Bekleme','İş Emri Yok',
             'Yarı Mamul Bekleme','Kalıp Arızası','Makine Arıza','Enerji Kesintisi',
             'Deneme Üretimi','Planlama Kaynaklı','Planlı Duruş','Eleman Eksikliği','Üretim Bitti','Diğer'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">⏱️ Makine Duruş Takip</h1>
    <div class="s-yol">Üretim / <b>Makine Duruş Takip</b></div>
  </div>
</div>

<div class="s-body">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
.dt-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:16px}
.dt-ozet{background:var(--yuzey);border-radius:var(--r);padding:18px 20px;text-align:center;box-shadow:var(--shadow);border-top:4px solid}
.dt-kart{background:var(--yuzey);border-radius:var(--r-xl);box-shadow:var(--shadow);margin-bottom:16px;overflow:visible}
.dt-kart-head{padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center}
.dt-tablo{width:100%;border-collapse:collapse;font-size:13px}
.dt-tablo th{padding:10px 14px;font-weight:700;color:var(--m2);background:var(--kenar-a);border-bottom:2px solid var(--kenar);text-align:left;white-space:nowrap}
.dt-tablo td{padding:9px 14px;border-bottom:1px solid var(--kenar);vertical-align:middle}
.dt-tablo tbody tr:hover{background:var(--kenar-a)}
.dt-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700}
.btn-sm{padding:5px 10px;border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:700;transition:all .15s}
.dt-grafik-grid{display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:16px}
@media(max-width:900px){.dt-grid3{grid-template-columns:1fr 1fr}.dt-grafik-grid{grid-template-columns:1fr}}
@media(max-width:600px){.dt-grid3{grid-template-columns:1fr}}
</style>

<!-- ÖZET KARTLAR -->
<div class="dt-grid3">
  <div class="dt-ozet" style="border-color:#0EA5E9">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:8px">Toplam Kayıt</div>
    <div style="font-size:32px;font-weight:900;color:#0EA5E9"><?=$ozet['toplam']?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">duruş kaydı</div>
  </div>
  <div class="dt-ozet" style="border-color:#DC2626">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:8px">Toplam Süre</div>
    <div style="font-size:32px;font-weight:900;color:#DC2626"><?=$s_saat?>s <?=$s_dk?>dk</div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px"><?=$ozet['sure_dk']?> dakika</div>
  </div>
  <div class="dt-ozet" style="border-color:#F59E0B">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:8px">Ort. Süre</div>
    <div style="font-size:32px;font-weight:900;color:#F59E0B"><?=$ozet['toplam']>0?round($ozet['sure_dk']/$ozet['toplam']):0?>dk</div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">kayıt başına</div>
  </div>
</div>

<!-- FİLTRELER -->
<div class="dt-kart" style="padding:16px 20px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="uretim-durus-takip">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="form-et" style="font-size:11px">Başlangıç</label>
           <input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Bitiş</label>
           <input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Üretim Emri</label>
           <input type="text" name="emri" class="form-alan" value="<?=htmlspecialchars($f_emri)?>" placeholder="UE-..." style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">İstasyon</label>
           <input type="text" name="ist" class="form-alan" value="<?=htmlspecialchars($f_ist)?>" placeholder="EN-..." style="width:130px"></div>
      <div><label class="form-et" style="font-size:11px">Neden</label>
           <select name="neden" class="form-alan" style="width:180px">
             <option value="">Tümü</option>
             <?php foreach($nedenleri as $n): ?>
             <option value="<?=htmlspecialchars($n)?>" <?=$f_neden===$n?'selected':''?>><?=htmlspecialchars($n)?></option>
             <?php endforeach; ?>
           </select></div>
      <button type="submit" class="btn btn-t" style="padding:10px 20px">🔍 Filtrele</button>
      <a href="?sayfa=uretim-durus-takip" class="btn" style="padding:10px 16px;background:var(--kenar-a);color:var(--m2)">↺</a>
    </div>
  </form>
</div>

<?php if(!empty($duruslar)): ?>
<!-- GRAFİKLER -->
<div class="dt-grafik-grid">
  <!-- Günlük bar grafik -->
  <div class="dt-kart" style="padding:20px">
    <div style="font-weight:800;font-size:13px;margin-bottom:14px">📅 Günlük Duruş Süresi (dakika)</div>
    <canvas id="chartGunluk" height="100"></canvas>
  </div>
  <!-- Neden pie -->
  <div class="dt-kart" style="padding:20px">
    <div style="font-weight:800;font-size:13px;margin-bottom:14px">🥧 Neden Dağılımı</div>
    <canvas id="chartNeden" height="160"></canvas>
  </div>
</div>

<!-- İstasyon + Neden tabloları yan yana -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
  <!-- İstasyona göre -->
  <div class="dt-kart" style="padding:0">
    <div class="dt-kart-head"><span style="font-weight:800;font-size:13px">🏭 İstasyona Göre</span></div>
    <div style="overflow-y:auto;max-height:280px">
    <table class="dt-tablo" style="width:100%">
      <thead style="position:sticky;top:0;z-index:1"><tr><th>İstasyon</th><th style="text-align:right">Kayıt</th><th style="text-align:right">Toplam Süre</th></tr></thead>
      <tbody>
      <?php foreach($ist_ozet as $ist=>$v):
        $s=floor($v['sure']/60); $d=$v['sure']%60; ?>
      <tr>
        <td style="font-weight:700;font-size:12px"><?=htmlspecialchars($ist)?></td>
        <td style="text-align:right"><span class="dt-badge" style="background:#DBEAFE;color:#1E40AF"><?=$v['sayi']?></span></td>
        <td style="text-align:right;font-weight:700;color:#DC2626;font-size:12px"><?=$s>0?"$s s $d dk":"$d dk"?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>

  <!-- Nedene göre -->
  <div class="dt-kart" style="padding:0">
    <div class="dt-kart-head"><span style="font-weight:800;font-size:13px">📋 Nedene Göre</span></div>
    <div style="overflow-y:auto;max-height:280px">
    <table class="dt-tablo" style="width:100%">
      <thead style="position:sticky;top:0;z-index:1"><tr><th>Neden</th><th style="text-align:right">Kayıt</th><th style="text-align:right">Toplam Süre</th></tr></thead>
      <tbody>
      <?php foreach($neden_ozet as $n=>$v):
        $s=floor($v['sure']/60); $d=$v['sure']%60; ?>
      <tr>
        <td style="font-size:12px"><?=htmlspecialchars($n)?></td>
        <td style="text-align:right"><span class="dt-badge" style="background:#FEF3C7;color:#92400E"><?=$v['sayi']?></span></td>
        <td style="text-align:right;font-weight:700;color:#DC2626;font-size:12px"><?=$s>0?"$s s $d dk":"$d dk"?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- DURUŞ LİSTESİ -->
<div class="dt-kart" style="padding:0;overflow:visible">
  <div class="dt-kart-head">
    <span style="font-weight:800;font-size:14px">⏱️ Duruş Kayıtları</span>
    <span style="font-size:12px;color:var(--m3)"><?=$ozet['toplam']?> kayıt</span>
  </div>
  <?php if(empty($duruslar)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">
    <div style="font-size:40px;margin-bottom:12px">⏱️</div>
    <div style="font-weight:600">Seçilen kriterlerde duruş kaydı bulunamadı.</div>
  </div>
  <?php else: ?>
  <div style="overflow-x:auto;overflow-y:auto;max-height:500px">
  <table class="dt-tablo">
    <thead><tr>
      <th>#</th><th>Üretim Emri</th><th>İstasyon</th>
      <th>Başlangıç</th><th>Bitiş</th>
      <th style="text-align:right">Süre</th><th>Neden</th>
      <th style="text-align:center">İşlem</th>
    </tr></thead>
    <tbody>
    <?php foreach($duruslar as $i=>$d):
      $dk = (int)($d['SURE_DK']??0);
      $sure_str = $dk>=60 ? floor($dk/60).'s '.($dk%60).'dk' : $dk.'dk';
      $bb = $dk<30?'#D1FAE5':($dk<60?'#FEF3C7':'#FEE2E2');
      $bc = $dk<30?'#065F46':($dk<60?'#92400E':'#7F1D1D');
      $did = (int)($d['ID']??0);
      // JSON için tek tırnak sorununu önle
      $d_json = json_encode([
          'ID'               => $did,
          'BASLANGIC_ZAMANI' => $d['BASLANGIC_ZAMANI']??'',
          'BITIS_ZAMANI'     => $d['BITIS_ZAMANI']??'',
          'DURUS_NEDENI'     => $d['DURUS_NEDENI']??'',
      ], JSON_HEX_APOS|JSON_HEX_QUOT);
    ?>
    <tr>
      <td style="color:var(--m3);font-size:12px"><?=$i+1?></td>
      <td><a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($d['URETIM_EMRI_NO']??'')?>"
             style="font-weight:700;color:var(--t);text-decoration:none;font-size:12px"><?=htmlspecialchars($d['URETIM_EMRI_NO']??'')?></a></td>
      <td style="font-weight:700;font-size:12px"><?=htmlspecialchars($d['IS_ISTASYONU']??'')?></td>
      <td style="font-size:12px;color:var(--m2)"><?=htmlspecialchars(substr($d['BASLANGIC_ZAMANI']??'',0,16))?></td>
      <td style="font-size:12px;color:var(--m2)"><?=htmlspecialchars(substr($d['BITIS_ZAMANI']??'',0,16))?></td>
      <td style="text-align:right"><span class="dt-badge" style="background:<?=$bb?>;color:<?=$bc?>"><?=$sure_str?></span></td>
      <td style="font-size:12px;max-width:180px"><?=htmlspecialchars($d['DURUS_NEDENI']??'')?></td>
      <td style="text-align:center;white-space:nowrap">
        <button class="btn-sm" style="background:#DBEAFE;color:#1E40AF;margin-right:4px"
                onclick='durusDuzenle(<?=$d_json?>)'>✏️</button>
        <button class="btn-sm" style="background:#FEE2E2;color:#7F1D1D"
                onclick="durusSil(<?=$did?>,this)">🗑️</button>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

<!-- DÜZENLEME MODALİ -->
<div id="durus-edit-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:560px;box-shadow:0 24px 60px rgba(0,0,0,.25);overflow:hidden">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
      <span style="font-size:15px;font-weight:800">✏️ Duruş Kaydını Düzenle</span>
      <button onclick="document.getElementById('durus-edit-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:24px">
      <form id="durusEditForm">
        <input type="hidden" name="id" id="edit-id">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
          <div><label class="form-et">Başlangıç</label>
               <input type="datetime-local" name="baslangic_zamani" id="edit-bas" class="form-alan" required></div>
          <div><label class="form-et">Bitiş</label>
               <input type="datetime-local" name="bitis_zamani" id="edit-bit" class="form-alan" required></div>
        </div>
        <div style="margin-bottom:16px">
          <label class="form-et">Duruş Nedeni</label>
          <select name="durus_nedeni" id="edit-neden" class="form-alan" required
                  onchange="document.getElementById('edit-diger').style.display=this.value==='Diğer'?'block':'none'">
            <?php foreach($all_nedeni as $n): ?>
            <option value="<?=htmlspecialchars($n)?>"><?=htmlspecialchars($n)?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div id="edit-diger" style="display:none;margin-bottom:16px">
          <label class="form-et">Diğer Açıklaması</label>
          <input type="text" name="aciklama" id="edit-aciklama" class="form-alan" placeholder="Açıklama...">
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('durus-edit-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">İptal</button>
          <button type="submit" class="btn btn-t" style="padding:10px 24px">💾 Güncelle</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
var BASE_DT = '<?=BASE_URL?>';

// Grafik verileri
<?php if(!empty($gunluk)): ?>
var gunLabels = <?=json_encode(array_keys($gunluk))?>;
var gunSure   = <?=json_encode(array_column(array_values($gunluk),'sure'))?>;
var gunSayi   = <?=json_encode(array_column(array_values($gunluk),'sayi'))?>;
var nedenLabels = <?=json_encode(array_keys($neden_ozet))?>;
var nedenSure   = <?=json_encode(array_column(array_values($neden_ozet),'sure'))?>;

// Günlük grafik
new Chart(document.getElementById('chartGunluk'), {
    type:'bar',
    data:{
        labels:gunLabels,
        datasets:[{
            label:'Süre (dk)',
            data:gunSure,
            backgroundColor:'rgba(14,165,233,0.7)',
            borderColor:'#0EA5E9',
            borderWidth:1,
            borderRadius:4
        },{
            label:'Kayıt sayısı',
            data:gunSayi,
            type:'line',
            borderColor:'#DC2626',
            backgroundColor:'rgba(220,38,38,0.1)',
            tension:.3,
            yAxisID:'y1',
            pointRadius:4
        }]
    },
    options:{
        responsive:true,
        plugins:{legend:{position:'bottom'}},
        scales:{
            y:{title:{display:true,text:'Dakika'}},
            y1:{position:'right',title:{display:true,text:'Kayıt'},grid:{drawOnChartArea:false}}
        }
    }
});

// Neden pasta grafik
var pieColors=['#0EA5E9','#DC2626','#F59E0B','#10B981','#8B5CF6','#EC4899','#14B8A6','#F97316','#6B7280','#EF4444','#84CC16','#06B6D4','#A855F7'];
new Chart(document.getElementById('chartNeden'), {
    type:'doughnut',
    data:{
        labels:nedenLabels,
        datasets:[{data:nedenSure, backgroundColor:pieColors.slice(0,nedenLabels.length), borderWidth:2}]
    },
    options:{responsive:true,plugins:{legend:{position:'bottom',labels:{font:{size:10}}}}}
});
<?php endif; ?>

function durusDuzenle(d) {
    document.getElementById('edit-id').value   = d.ID;
    var fmt = function(s){ return s ? s.replace(' ','T').substring(0,16) : ''; };
    document.getElementById('edit-bas').value   = fmt(d.BASLANGIC_ZAMANI);
    document.getElementById('edit-bit').value   = fmt(d.BITIS_ZAMANI);
    var neden = d.DURUS_NEDENI || '';
    // Diğer: prefix varsa ayır
    if (neden.indexOf('Diğer: ') === 0) {
        document.getElementById('edit-neden').value   = 'Diğer';
        document.getElementById('edit-aciklama').value = neden.substring(7);
        document.getElementById('edit-diger').style.display = 'block';
    } else {
        document.getElementById('edit-neden').value   = neden;
        document.getElementById('edit-diger').style.display = 'none';
    }
    document.getElementById('durus-edit-modal').style.display = 'flex';
}

function durusSil(id, btn) {
    Swal.fire({
        title:'Durus silinsin mi?', text:'Bu kayit kalici olarak silinecek.',
        icon:'warning', showCancelButton:true,
        confirmButtonColor:'#DC2626', cancelButtonColor:'#6B7280',
        confirmButtonText:'Evet, Sil', cancelButtonText:'Iptal'
    }).then(function(r){
        if(!r.isConfirmed) return;
        btn.disabled=true;
        Swal.fire({title:'Siliniyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
        fetch(BASE_DT+'/islemler/uretim/makine_durus_sil.php',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({id:id})
        }).then(function(r){return r.json();}).then(function(d){
            if(d.success){
                Swal.fire({title:'Silindi!',icon:'success',timer:1500,showConfirmButton:false});
                var satir=btn.closest('tr');
                if(satir){satir.style.opacity='0.3';setTimeout(function(){satir.remove();},600);}
            } else {
                Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
                btn.disabled=false;
            }
        }).catch(function(e){
            Swal.fire({title:'Hata',text:e.message,icon:'error'});
            btn.disabled=false;
        });
    });
}

document.getElementById('durusEditForm').addEventListener('submit',function(e){
    e.preventDefault();
    Swal.fire({title:'Guncelleniyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
    var fd=new FormData(this), obj={};
    fd.forEach(function(v,k){obj[k]=v;});
    fetch(BASE_DT+'/islemler/uretim/makine_durus_guncelle.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(obj)
    }).then(function(r){return r.json();}).then(function(d){
        if(d.success){
            Swal.fire({title:'Guncellendi!',text:d.message,icon:'success',timer:1800,showConfirmButton:false});
            document.getElementById('durus-edit-modal').style.display='none';
            setTimeout(function(){location.reload();},1000);
        } else {
            Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
        }
    }).catch(function(e){Swal.fire({title:'Hata',text:e.message,icon:'error'});});
});
</script>
</div><!-- /s-body -->
