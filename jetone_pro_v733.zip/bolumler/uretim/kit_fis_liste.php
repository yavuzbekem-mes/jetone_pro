<?php
/**
 * BSH Kit Fiş Listesi — Okutulan fişler, yazdır, detay
 * panel.php: 'uretim-kit-fis-liste' => 'bolumler/uretim/kit_fis_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Filtre parametreleri
$f_paket  = trim($_GET['paket_no'] ?? $_POST['paket_no'] ?? '');
$f_tarih1 = trim($_GET['tarih1']   ?? $_POST['tarih1']   ?? '');
$f_tarih2 = trim($_GET['tarih2']   ?? $_POST['tarih2']   ?? '');
$f_urun   = trim($_GET['urun']     ?? $_POST['urun']     ?? '');

// Detay modu
$detay_fis = trim($_GET['detay'] ?? '');
$detay_data = null;
$detay_sarf = [];
if ($detay_fis) {
    try {
        $s = $db->prepare("SELECT * FROM `giriş_fişleri` WHERE `fiş_no`=? LIMIT 1");
        $s->execute([$detay_fis]);
        $detay_data = $s->fetch(PDO::FETCH_ASSOC);

        $s2 = $db->prepare("SELECT * FROM fis_sarf_detay WHERE `fiş_no`=? ORDER BY id");
        $s2->execute([$detay_fis]);
        $detay_sarf = $s2->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Fişleri çek
$fisler = [];
$params = [];
try {
    $where = ['1=1'];
    if ($f_paket)  { $where[] = 'PAKET_NO=?';                          $params[] = $f_paket; }
    if ($f_urun)   { $where[] = '(urun_kodu LIKE ? OR urun_adi LIKE ?)'; $params[] = "%$f_urun%"; $params[] = "%$f_urun%"; }
    if ($f_tarih1) { $where[] = 'tarih >= ?';                           $params[] = $f_tarih1; }
    if ($f_tarih2) { $where[] = 'tarih <= ?';                           $params[] = $f_tarih2; }

    $sql = "SELECT * FROM `giriş_fişleri` WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT 500";
    $st  = $db->prepare($sql);
    $st->execute($params);
    $fisler = $st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) { $hata = $e->getMessage(); }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Fiş Listesi</h1>
    <div class="s-yol">Üretim / <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" style="color:var(--t)">Kit Listesi</a> / <b>Fiş Listesi</b></div>
  </div>
</div>

<div class="s-body">

<!-- Detay Paneli -->
<?php if ($detay_fis && $detay_data): ?>
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:16px;border-top:4px solid #2563EB">
  <div style="padding:12px 16px;background:#EFF6FF;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="font-weight:800;font-size:13px;color:#2563EB">📄 Fiş Detayı — <?=htmlspecialchars($detay_fis)?></div>
    <div style="display:flex;gap:8px">
      <a href="<?=BASE_URL?>/bolumler/uretim/kit_fis_yazdir.php?fis_no=<?=urlencode($detay_fis)?>"
         target="_blank" class="btn btn-t btn-sm">🖨️ Yazdır</a>
      <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-fis-liste" class="btn btn-b btn-sm">✕ Kapat</a>
    </div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 2fr;gap:0" class="det-grid">
    <!-- Fiş Bilgi -->
    <div style="padding:16px;border-right:1px solid var(--kenar)">
      <?php foreach([
        ['Fiş No',    $detay_fis],
        ['Paket No',  $detay_data['PAKET_NO']??''],
        ['Ürün Kodu', $detay_data['urun_kodu']??''],
        ['Ürün Adı',  $detay_data['urun_adi']??''],
        ['Tarih/Saat',$detay_data['tarih_saat']??''],
        ['Personel',  $detay_data['personel']??''],
      ] as $r): if(!$r[1]) continue; ?>
      <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:12px">
        <span style="color:var(--m2)"><?=$r[0]?></span>
        <span style="font-weight:700;max-width:200px;text-align:right;word-break:break-all"><?=htmlspecialchars($r[1])?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <!-- Sarf Detay -->
    <div>
      <?php if(empty($detay_sarf)): ?>
      <div style="padding:24px;text-align:center;color:var(--m3)">Sarf kaydı yok.</div>
      <?php else: ?>
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <thead><tr style="background:#2563EB;color:#fff">
          <th style="padding:8px 12px;text-align:left">#</th>
          <th style="padding:8px 12px;text-align:left">Malzeme Kodu</th>
          <th style="padding:8px 12px;text-align:left">Malzeme Adı</th>
          <th style="padding:8px 12px;text-align:right">Adet</th>
        </tr></thead>
        <tbody>
        <?php foreach($detay_sarf as $i=>$s): ?>
        <tr style="border-bottom:1px solid var(--kenar)">
          <td style="padding:6px 12px;color:var(--m3)"><?=$i+1?></td>
          <td style="padding:6px 12px;font-family:monospace"><?=htmlspecialchars($s['malzeme_kodu']??'')?></td>
          <td style="padding:6px 12px"><?=htmlspecialchars($s['malzeme_adi']??'')?></td>
          <td style="padding:6px 12px;text-align:right;font-weight:700"><?=(int)$s['okutulan_miktar']?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Filtre -->
<form method="GET" action="<?=BASE_URL?>/panel.php" style="margin-bottom:14px">
  <input type="hidden" name="sayfa" value="uretim-kit-fis-liste">
  <div class="kart" style="padding:14px">
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:10px;align-items:end" class="filtre-grid">
      <div>
        <label class="form-et">Paket No</label>
        <input name="paket_no" class="form-alan" value="<?=htmlspecialchars($f_paket)?>" placeholder="Paket no ara...">
      </div>
      <div>
        <label class="form-et">Ürün Kodu / Adı</label>
        <input name="urun" class="form-alan" value="<?=htmlspecialchars($f_urun)?>" placeholder="Ürün kodu veya adı...">
      </div>
      <div>
        <label class="form-et">Başlangıç Tarihi</label>
        <input type="date" name="tarih1" class="form-alan" value="<?=htmlspecialchars($f_tarih1)?>">
      </div>
      <div>
        <label class="form-et">Bitiş Tarihi</label>
        <input type="date" name="tarih2" class="form-alan" value="<?=htmlspecialchars($f_tarih2)?>">
      </div>
      <div style="display:flex;gap:6px">
        <button type="submit" class="btn btn-t">🔍 Ara</button>
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-fis-liste" class="btn btn-b">↺</a>
      </div>
    </div>
  </div>
</form>

<?php if(!empty($hata)): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">⚠️ <?=htmlspecialchars($hata)?></div>
<?php endif; ?>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 16px;background:var(--kenar-a);border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="font-weight:800;font-size:13px">📋 Fişler (<?=count($fisler)?> kayıt)</div>
    <?php if($f_paket||$f_urun||$f_tarih1): ?>
    <span style="font-size:11px;color:#2563EB;font-weight:700">🔍 Filtre aktif</span>
    <?php endif; ?>
  </div>
  <?php if(empty($fisler)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Kayıt bulunamadı.</div>
  <?php else: ?>
  <div style="overflow:auto;max-height:600px">
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E3A5F;color:#fff">
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">#</th>
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">Fiş No</th>
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">Paket No</th>
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">Ürün Kodu</th>
        <th style="padding:9px 10px;text-align:left">Ürün Adı</th>
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">Tarih/Saat</th>
        <th style="padding:9px 10px;text-align:left;white-space:nowrap">Personel</th>
        <th style="padding:9px 10px;text-align:center;white-space:nowrap">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($fisler as $i=>$f):
      $fno = $f['fiş_no'] ?? '';
      $aktif = ($detay_fis === $fno);
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$aktif?'#EFF6FF':'inherit'?>">
      <td style="padding:7px 10px;color:var(--m3)"><?=$i+1?></td>
      <td style="padding:7px 10px;font-family:monospace;font-weight:700;color:#1E3A5F">
        <?=htmlspecialchars($fno)?>
      </td>
      <td style="padding:7px 10px;font-family:monospace"><?=htmlspecialchars($f['PAKET_NO']??'')?></td>
      <td style="padding:7px 10px;font-family:monospace"><?=htmlspecialchars($f['urun_kodu']??'')?></td>
      <td style="padding:7px 10px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
          title="<?=htmlspecialchars($f['urun_adi']??'')?>"><?=htmlspecialchars($f['urun_adi']??'')?></td>
      <td style="padding:7px 10px;white-space:nowrap;font-size:11px"><?=htmlspecialchars($f['tarih_saat']??'')?></td>
      <td style="padding:7px 10px"><?=htmlspecialchars($f['personel']??'')?></td>
      <td style="padding:7px 10px;text-align:center;white-space:nowrap">
        <!-- Detay -->
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-fis-liste&detay=<?=urlencode($fno)?><?=$f_paket?'&paket_no='.urlencode($f_paket):''?><?=$f_urun?'&urun='.urlencode($f_urun):''?><?=$f_tarih1?'&tarih1='.urlencode($f_tarih1):''?><?=$f_tarih2?'&tarih2='.urlencode($f_tarih2):''?>"
           class="btn btn-b btn-sm" style="font-size:10px;padding:3px 8px"
           title="Detay ve Sarf">🔍</a>
        <!-- Yazdır -->
        <a href="<?=BASE_URL?>/bolumler/uretim/kit_fis_yazdir.php?fis_no=<?=urlencode($fno)?>"
           target="_blank" class="btn btn-t btn-sm" style="font-size:10px;padding:3px 8px;margin-left:3px"
           title="Yazdır">🖨️</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

</div><!-- /s-body -->
<style>
@media(max-width:800px){.filtre-grid{grid-template-columns:1fr 1fr!important}}
@media(max-width:500px){.filtre-grid{grid-template-columns:1fr!important}}
@media(max-width:700px){.det-grid{grid-template-columns:1fr!important}}
</style>
