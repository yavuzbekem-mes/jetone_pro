<?php
/**
 * BSH Kit Üretim — Okutulacak / Tamamlanan Kitler Listesi
 * panel.php: 'uretim-kit-liste' => 'bolumler/uretim/kit_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Tablolar oluştur
$db->exec("CREATE TABLE IF NOT EXISTS `giriş_fişleri` (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    PAKET_NO    VARCHAR(20),
    urun_kodu   VARCHAR(255),
    urun_adi    VARCHAR(255),
    tarih_saat  DATETIME DEFAULT CURRENT_TIMESTAMP,
    personel    VARCHAR(255),
    `fiş_no`      VARCHAR(100),
    tarih       DATE,
    INDEX idx_paket(PAKET_NO), INDEX idx_fis(`fiş_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS `fis_sarf_detay` (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    PAKET_NO        VARCHAR(20),
    ana_urun_kodu   VARCHAR(100),
    ana_urun_adi    VARCHAR(255),
    malzeme_kodu    VARCHAR(100),
    malzeme_adi     VARCHAR(255),
    okutulan_miktar INT,
    `fiş_no`          VARCHAR(100),
    INDEX idx_paket(PAKET_NO), INDEX idx_fis(`fiş_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// MES verisi çek
$mes_results = [];
$hata = '';
try {
    // urun_recetesi'ndeki tüm ana ürün kodlarını al (BSH kitler)
    $receteStmt = $db->query("SELECT DISTINCT TRIM(ana_urun_kodu) AS kod FROM urun_recetesi ORDER BY kod");
    $anaUrunKodlar = $receteStmt->fetchAll(PDO::FETCH_COLUMN, 0);

    if (!empty($anaUrunKodlar) && $mes_pdo) {
        $kodList = "'" . implode("','", array_map(fn($k) => str_replace("'",'',$k), $anaUrunKodlar)) . "'";
        $mes_sql = "SELECT ID,PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,URETIM_EMRI_NO,URETIM_TARIHI,CALISAN,EKLEYEN
                    FROM dbo.PAKETLER
                    WHERE URETIM_TARIHI >= DATEADD(DAY,-3,GETDATE()) AND STOK_KODU IN ($kodList)
                    ORDER BY ID DESC";
        $mes_stmt = $mes_pdo->query($mes_sql);
        $mes_results = $mes_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch(Throwable $e) { $hata = $e->getMessage(); }

// Paket sayıları (üretilen)
$paketSayilari = [];
try {
    $ps = $db->query("SELECT COUNT(*) as adet, PAKET_NO FROM `giriş_fişleri` GROUP BY PAKET_NO");
    foreach ($ps->fetchAll(PDO::FETCH_ASSOC) as $p) {
        $paketSayilari[$p['PAKET_NO']] = (int)$p['adet'];
    }
} catch(Throwable $e) {}

// Okutulacak ve tamamlananları ayır
$okutulacaklar = [];
$tamamlananlar = [];
foreach ($mes_results as $r) {
    $uretilen = $paketSayilari[$r['PAKET_NO']] ?? 0;
    $fark = (int)$r['MIKTAR'] - $uretilen;
    if ($fark == 0) {
        $tamamlananlar[] = array_merge($r, ['uretilen'=>$uretilen,'fark'=>$fark]);
    } else {
        $okutulacaklar[] = array_merge($r, ['uretilen'=>$uretilen,'fark'=>$fark]);
    }
}

$kul = Auth::kullanici();
$yetkili = in_array($kul['rol_id'] ?? 0, [1,2]) || str_contains(strtolower($kul['rol'] ?? ''), 'planlama');
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 BSH Kit Üretim Listesi</h1>
    <div class="s-yol">Üretim / <b>Kit Üretim</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <button onclick="location.reload()" class="btn btn-b btn-sm">🔄 Yenile</button>

  </div>
</div>

<div class="s-body">
<?php if($hata): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">⚠️ <?=htmlspecialchars($hata)?></div>
<?php endif; ?>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
  <?php foreach([
    ['📋','Toplam Paket', count($mes_results),'#1E3A5F','#EFF6FF'],
    ['⏳','Bekleyen',     count($okutulacaklar),'#D97706','#FFFBEB'],
    ['✅','Tamamlanan',  count($tamamlananlar),'#16A34A','#F0FDF4'],
  ] as $k): ?>
  <div class="kart" style="padding:14px;border-left:4px solid <?=$k[3]?>;background:<?=$k[4]?>;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700"><?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:16px">
  <button onclick="tabGoster('bekleyen')" id="ktab_bekleyen"
    style="padding:7px 14px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;background:var(--t);color:#fff">
    ⏳ Okutulacak Kitler (<?=count($okutulacaklar)?>)
  </button>
  <button onclick="tabGoster('tamamlanan')" id="ktab_tamamlanan"
    style="padding:7px 14px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:-2px;background:var(--kenar-a);color:var(--m)">
    ✅ Tamamlanan Kitler (<?=count($tamamlananlar)?>)
  </button>
</div>

<!-- OKUTULACAK -->
<div id="tab_bekleyen">
<?php if(empty($okutulacaklar)): ?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">
  <div style="font-size:40px;margin-bottom:12px">🎉</div>
  <div style="font-size:14px;font-weight:700">Tüm kitler tamamlanmış!</div>
</div>
<?php else: ?>
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow:auto;max-height:500px">
<table style="width:100%;border-collapse:collapse;font-size:13px">
  <thead style="position:sticky;top:0;z-index:2"><tr style="background:#1E3A5F;color:#fff">
    <?php foreach(['#','Paket No','Stok Kodu','Ürün Adı','Hedef','Üretilen','Fark','Tarih','İşlem'] as $th): ?>
    <th style="padding:10px 12px;text-align:left;white-space:nowrap"><?=$th?></th>
    <?php endforeach; ?>
  </thead>
  <tbody>
  <?php foreach($okutulacaklar as $r):
    $fark = $r['fark'];
    $fark_renk = $fark > 0 ? '#16A34A' : '#DC2626';
    $fark_bg   = $fark > 0 ? '#F0FDF4' : '#FEF2F2';
  ?>
  <tr style="border-bottom:1px solid var(--kenar);background:<?=$fark<0?'#FFFBEB':'inherit'?>">
    <td style="padding:10px 12px;color:var(--m3);font-size:11px"><?=$r['ID']?></td>
    <td style="padding:10px 12px;font-weight:700;font-family:monospace"><?=htmlspecialchars($r['PAKET_NO'])?></td>
    <td style="padding:10px 12px;font-family:monospace"><?=htmlspecialchars($r['STOK_KODU'])?></td>
    <td style="padding:10px 12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars($r['STOK_ADI'])?></td>
    <td style="padding:10px 12px;text-align:right;font-weight:700"><?=$r['MIKTAR']?></td>
    <td style="padding:10px 12px;text-align:right"><?=$r['uretilen']?></td>
    <td style="padding:10px 12px;text-align:right">
      <span style="font-weight:700;font-size:14px;padding:3px 10px;border-radius:8px;background:<?=$fark_bg?>;color:<?=$fark_renk?>"><?=$fark?></span>
    </td>
    <td style="padding:10px 12px;font-size:11px;color:var(--m2)"><?=isset($r['URETIM_TARIHI'])?date('d.m.Y',strtotime($r['URETIM_TARIHI'])):'-'?></td>
    <td style="padding:10px 12px">
      <?php if($fark > 0): ?>
      <form method="POST" action="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-uret" style="display:inline">
        <input type="hidden" name="urun_kodu" value="<?=htmlspecialchars($r['STOK_KODU'])?>">
        <input type="hidden" name="paket_no"  value="<?=htmlspecialchars($r['PAKET_NO'])?>">
        <input type="hidden" name="urun_adi"  value="<?=htmlspecialchars($r['STOK_ADI'])?>">
        <button type="submit" name="kit_baslat" class="btn btn-t btn-sm" style="font-size:11px">🔧 Kit Üret</button>
      </form>
      <?php else: ?>
      <span style="font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;background:#FFFBEB;color:#D97706">⚠️ Fazla Üretim</span>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
<?php endif; ?>
</div>

<!-- TAMAMLANAN -->
<div id="tab_tamamlanan" style="display:none">
<?php if(empty($tamamlananlar)): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">Tamamlanan kit yok.</div>
<?php else: ?>
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow:auto;max-height:500px">
<table style="width:100%;border-collapse:collapse;font-size:13px">
  <thead style="position:sticky;top:0;z-index:2"><tr style="background:#16A34A;color:#fff">
    <?php foreach(['#','Paket No','Stok Kodu','Ürün Adı','Hedef','Üretilen','Durum','Tarih'] as $th): ?>
    <th style="padding:10px 12px;text-align:left;white-space:nowrap"><?=$th?></th>
    <?php endforeach; ?>
  </thead>
  <tbody>
  <?php foreach($tamamlananlar as $r): ?>
  <tr style="border-bottom:1px solid var(--kenar);background:#F0FDF4">
    <td style="padding:10px 12px;color:var(--m3);font-size:11px"><?=$r['ID']?></td>
    <td style="padding:10px 12px;font-weight:700;font-family:monospace"><?=htmlspecialchars($r['PAKET_NO'])?></td>
    <td style="padding:10px 12px;font-family:monospace"><?=htmlspecialchars($r['STOK_KODU'])?></td>
    <td style="padding:10px 12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars($r['STOK_ADI'])?></td>
    <td style="padding:10px 12px;text-align:right;font-weight:700"><?=$r['MIKTAR']?></td>
    <td style="padding:10px 12px;text-align:right;font-weight:700"><?=$r['uretilen']?></td>
    <td style="padding:10px 12px"><span style="font-weight:700;padding:3px 10px;border-radius:8px;background:#D1FAE5;color:#065F46">✅ Tamamlandı</span></td>
    <td style="padding:10px 12px;font-size:11px;color:var(--m2)"><?=isset($r['URETIM_TARIHI'])?date('d.m.Y',strtotime($r['URETIM_TARIHI'])):'-'?></td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
<?php endif; ?>
</div>

</div><!-- /s-body -->
<script>
function tabGoster(id){
    ['bekleyen','tamamlanan'].forEach(function(t){
        document.getElementById('tab_'+t).style.display = t===id ? 'block' : 'none';
        var b = document.getElementById('ktab_'+t);
        if(b){ b.style.background = t===id ? 'var(--t)' : 'var(--kenar-a)'; b.style.color = t===id ? '#fff' : 'var(--m)'; }
    });
}
</script>
