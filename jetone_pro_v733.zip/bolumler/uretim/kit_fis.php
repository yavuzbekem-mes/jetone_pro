<?php
/**
 * BSH Kit Üretim — Fiş Görüntüle + Yazdır
 * panel.php: 'uretim-kit-fis' => 'bolumler/uretim/kit_fis.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$fis_no = trim($_GET['fis_no'] ?? '');
$yazdir = isset($_GET['yazdir']);

$fis = null; $sarf = [];
if ($fis_no) {
    try {
        $s = $db->prepare("SELECT * FROM `giriş_fişleri` WHERE `fiş_no`=? LIMIT 1");
        $s->execute([$fis_no]); $fis = $s->fetch(PDO::FETCH_ASSOC);
        $s2 = $db->prepare("SELECT * FROM fis_sarf_detay WHERE `fiş_no`=? ORDER BY id");
        $s2->execute([$fis_no]); $sarf = $s2->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){}
}

// Paket tamamlandı mı?
$fark_sonraki = 0;
$mes_paket    = null;
if ($fis && $mes_pdo) {
    try {
        $pno = $fis['PAKET_NO'] ?? '';
        $ms = $mes_pdo->prepare("SELECT STOK_KODU,STOK_ADI,MIKTAR,URETIM_EMRI_NO FROM dbo.PAKETLER WHERE PAKET_NO=? AND URETIM_TARIHI >= DATEADD(DAY,-6,GETDATE())");
        $ms->execute([$pno]); $mes_paket = $ms->fetch(PDO::FETCH_ASSOC);
        if ($mes_paket) {
            $cnt = $db->prepare("SELECT COUNT(*) FROM `giriş_fişleri` WHERE PAKET_NO=?");
            $cnt->execute([$pno]);
            $fark_sonraki = (int)$mes_paket['MIKTAR'] - (int)$cnt->fetchColumn();
        }
    } catch(Throwable $e){}
}

// ── YAZDIR MODU ───────────────────────────────────────────
if ($yazdir && $fis):
  $uk = substr(trim($fis['urun_kodu']??''),0,10);
  $ua = substr(trim($fis['urun_adi'] ??''),0,40);
  $ts = $fis['tarih_saat'] ? date('Y-m-d H:i:s',strtotime($fis['tarih_saat'])) : '';
  $pno= $fis['PAKET_NO']??'';
  $personel = $fis['personel']??'';
?>
<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8">
<title>Fis <?=htmlspecialchars($fis_no)?></title>
<script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:Arial,sans-serif;background:#fff;}
.no-print{padding:10px;background:#EFF6FF;display:flex;gap:8px;flex-wrap:wrap;}
.no-print button,.no-print a{padding:8px 16px;border:none;border-radius:4px;cursor:pointer;font-weight:700;font-size:13px;text-decoration:none;display:inline-block;}
.btn-yaz{background:#16A34A;color:#fff;} .btn-geri{background:#2563EB;color:#fff;} .btn-kapat{background:#6B7280;color:#fff;}
.fis-container{padding:15px;}
table{border-collapse:collapse;width:100%;}
th,td{border:1px solid black;padding:5px;text-align:left;font-weight:bold;font-size:14px;}
#qrcode{width:100px!important;height:100px!important;min-width:100px;min-height:100px;border:1px solid #000;padding:3px;margin:5px auto;text-align:center;}
.receipt{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;font-family:Arial,sans-serif;max-width:520px;border:1px solid #ccc;padding:15px;margin-top:10px;}
@media print{
  .no-print{display:none!important;}
  body{margin:0;background:#fff;}
  button:not([style*="display:none"]),
  .mab, .msb, .msb-ic, .nav-it, .nav-grp,
  .acc-baslik, .acc-govde, .acc-ok,
  [onclick], nav, aside, header, footer,
  .s-bar, .s-yol, .s-body > *:not(.fis-container),
  #mobDrawer, .mob-overlay {
    display:none!important;
  }
  .fis-container, .receipt, table {
    display:block!important;
  }
}
</style></head><body>
<div class="no-print">
  <button class="btn-yaz" onclick="window.print()">Yazdir</button>
  <?php if($fark_sonraki > 0): ?>
  <button class="btn-geri" onclick="goYeniUretim()">Devam Et (<?=$fark_sonraki?> kalan)</button>
  <?php else: ?>
  <a class="btn-geri" href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste">Liste</a>
  <?php endif; ?>
  <button class="btn-kapat" onclick="window.close()">Kapat</button>
</div>
<div class="fis-container">
  <div class="receipt">
    <table border="1" cellpadding="5">
      <tr><td>Item Code:</td><td style="font-weight:bold;font-size:25px;" colspan="4"><?=htmlspecialchars($uk)?></td></tr>
      <tr><td>Item Name:</td><td colspan="4"><?=htmlspecialchars($ua)?></td></tr>
      <tr>
        <td>Amount:</td><td>1 Piece</td>
        <td colspan="2" rowspan="3" id="qrcode" style="text-align:center;padding:5px;"></td>
      </tr>
      <tr><td>Date - Time:</td><td><?=htmlspecialchars($ts)?></td></tr>
      <tr><td>Package Nu:</td><td><?=htmlspecialchars($fis_no)?></td></tr>
    </table>
  </div>
</div>
<script>
var BASE_URL = '<?=BASE_URL?>';
var pno  = '<?=addslashes($pno)?>';
var uk   = '<?=addslashes($uk)?>';
var ua   = '<?=addslashes($ua)?>';
new QRCode(document.getElementById('qrcode'),{text:uk,width:100,height:100,colorDark:'#000',colorLight:'#fff',correctLevel:QRCode.CorrectLevel.H});
function goYeniUretim(){
  var f=document.createElement('form');f.method='POST';f.action=BASE_URL+'/panel.php?sayfa=uretim-kit-uret';
  [['urun_kodu',uk],['paket_no',pno],['urun_adi',ua],['kit_baslat','1']].forEach(function(p){
    var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1];f.appendChild(i);
  });document.body.appendChild(f);f.submit();
}
window.onload=function(){setTimeout(function(){window.print();},800);};
</script>
</body></html>
<?php exit; endif;
// ── PANEL GÖRÜNÜMÜ ────────────────────────────────────────
if(!$fis){
    echo '<div class="s-bar"><div><h1 class="s-bas">Fis Bulunamadi</h1></div><a href="'.BASE_URL.'/panel.php?sayfa=uretim-kit-liste" class="btn btn-b btn-sm">Liste</a></div>';
    exit;
}
$urunKodu = trim($fis['urun_kodu']??'');
$urunAdi  = trim($fis['urun_adi'] ??'');
$paket_no = $fis['PAKET_NO']??'';
$tarihsaat= $fis['tarih_saat'] ? date('d.m.Y H:i',strtotime($fis['tarih_saat'])) : '-';
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">Fis — <?=htmlspecialchars($fis_no)?></h1>
    <div class="s-yol">Uretim / <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" style="color:var(--t)">Kit Listesi</a> / <b>Fis</b></div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a href="<?=BASE_URL?>/bolumler/uretim/kit_fis_yazdir.php?fis_no=<?=urlencode($fis_no)?>" target="_blank" class="btn btn-t btn-sm">Yazdir</a>
    <?php if($fark_sonraki > 0): ?>
    <form method="POST" action="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-uret" style="display:inline">
      <input type="hidden" name="urun_kodu"  value="<?=htmlspecialchars($urunKodu)?>">
      <input type="hidden" name="paket_no"   value="<?=htmlspecialchars($paket_no)?>">
      <input type="hidden" name="urun_adi"   value="<?=htmlspecialchars($urunAdi)?>">
      <input type="hidden" name="kit_baslat" value="1">
      <button type="submit" class="btn btn-sm" style="background:#2563EB;color:#fff">Devam Et (<?=$fark_sonraki?> kalan)</button>
    </form>
    <?php else: ?>
    <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" class="btn btn-b btn-sm">Liste</a>
    <?php endif; ?>
  </div>
</div>
<div class="s-body">
<?php if($fark_sonraki==0): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#F0FDF4;color:#065F46;border-left:4px solid #16A34A;font-weight:700">Paket Tamamlandi!</div>
<?php elseif($fark_sonraki>0): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FFFBEB;color:#854D0E;border-left:4px solid #D97706;font-weight:700"><?=$fark_sonraki?> adet daha uretilecek</div>
<?php endif; ?>
<div style="display:grid;grid-template-columns:1fr 2fr;gap:16px" class="fis-grid">
<div class="kart" style="padding:16px;border-top:4px solid #2563EB">
  <div style="font-size:22px;font-weight:900;font-family:monospace;text-align:center;padding:10px;background:#EFF6FF;border-radius:6px;margin-bottom:14px"><?=htmlspecialchars($fis_no)?></div>
  <?php foreach([['Urun Kodu',$urunKodu],['Urun Adi',$urunAdi],['Paket No',$paket_no],['Tarih',$tarihsaat]] as $r): if(!$r[1]) continue; ?>
  <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:12px">
    <span style="color:var(--m2)"><?=$r[0]?></span><span style="font-weight:700;max-width:170px;text-align:right;word-break:break-all"><?=htmlspecialchars($r[1])?></span>
  </div>
  <?php endforeach; ?>
  <div id="qrcode_panel" style="margin:14px auto;text-align:center"></div>
  <div style="display:flex;gap:8px;margin-top:12px">
    <a href="<?=BASE_URL?>/bolumler/uretim/kit_fis_yazdir.php?fis_no=<?=urlencode($fis_no)?>" target="_blank" class="btn btn-t btn-sm" style="flex:1;text-align:center">Yazdir</a>
    <?php if($fark_sonraki>0): ?>
    <form method="POST" action="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-uret" style="flex:1">
      <input type="hidden" name="urun_kodu" value="<?=htmlspecialchars($urunKodu)?>">
      <input type="hidden" name="paket_no"  value="<?=htmlspecialchars($paket_no)?>">
      <input type="hidden" name="urun_adi"  value="<?=htmlspecialchars($urunAdi)?>">
      <input type="hidden" name="kit_baslat" value="1">
      <button type="submit" class="btn btn-b btn-sm" style="width:100%">Devam Et</button>
    </form>
    <?php else: ?>
    <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" class="btn btn-b btn-sm" style="flex:1;text-align:center">Liste</a>
    <?php endif; ?>
  </div>
</div>
<div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #16A34A">
  <div style="padding:12px 16px;background:#F0FDF4;border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px;color:#16A34A">Kullanilan Malzemeler (<?=count($sarf)?>)</div>
  <?php if(empty($sarf)): ?><div style="padding:24px;text-align:center;color:var(--m3)">Sarf kaydi yok.</div><?php else: ?>
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead><tr style="background:#16A34A;color:#fff"><th style="padding:8px 12px">Malzeme Kodu</th><th style="padding:8px 12px">Malzeme Adi</th><th style="padding:8px 12px;text-align:right">Adet</th></tr></thead>
    <tbody>
    <?php foreach($sarf as $s): ?>
    <tr style="border-bottom:1px solid var(--kenar)">
      <td style="padding:7px 12px;font-family:monospace"><?=htmlspecialchars($s['malzeme_kodu']??'')?></td>
      <td style="padding:7px 12px"><?=htmlspecialchars($s['malzeme_adi']??'')?></td>
      <td style="padding:7px 12px;text-align:right;font-weight:700"><?=(int)$s['okutulan_miktar']?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>
</div>
</div>
<style>@media(max-width:700px){.fis-grid{grid-template-columns:1fr!important}}</style>
<script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
<script>
var qrEl = document.getElementById('qrcode_panel');
if(qrEl) new QRCode(qrEl,{text:'<?=addslashes(substr($urunKodu,0,10))?>',width:100,height:100,colorDark:'#000',colorLight:'#fff',correctLevel:QRCode.CorrectLevel.H});
</script>
