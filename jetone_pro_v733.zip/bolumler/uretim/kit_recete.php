<?php
/**
 * BSH Kit Reçete Yönetimi
 * panel.php: 'uretim-kit-recete' => 'bolumler/uretim/kit_recete.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$mesaj = ''; $mesaj_tip = '';

// ── SİL ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'sil') {
    $bom_id = (int)($_POST['bom_id'] ?? 0);
    if ($bom_id > 0) {
        try {
            $db->prepare("DELETE FROM urun_recetesi WHERE bom_id=?")->execute([$bom_id]);
            $mesaj = 'Kayıt silindi.'; $mesaj_tip = 'ok';
        } catch(Throwable $e) { $mesaj = 'Hata: '.$e->getMessage(); $mesaj_tip = 'err'; }
    }
}

// ── EKLE ──────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'ekle') {
    $f = [
        'ana_urun_kodu' => trim($_POST['ana_urun_kodu'] ?? ''),
        'ana_urun_adi'  => trim($_POST['ana_urun_adi']  ?? ''),
        'malzeme_kodu'  => trim($_POST['malzeme_kodu']  ?? ''),
        'malzeme_adi'   => trim($_POST['malzeme_adi']   ?? ''),
        'miktar'        => trim($_POST['miktar']         ?? '1'),
        'birim'         => trim($_POST['birim']          ?? 'ADET'),
        'tur'           => trim($_POST['tur']            ?? 'Yardımcı Malz.'),
        'ekleyen'       => $kul_adi,
    ];
    if (!$f['ana_urun_kodu'] || !$f['malzeme_kodu']) {
        $mesaj = 'Ana Ürün Kodu ve Malzeme Kodu zorunludur.'; $mesaj_tip = 'err';
    } else {
        try {
            $db->prepare("INSERT INTO urun_recetesi
                (ana_urun_kodu,ana_urun_adi,malzeme_kodu,malzeme_adi,miktar,birim,`tür`,ekleyen,tarih)
                VALUES (?,?,?,?,?,?,?,?,NOW())")
            ->execute(array_values($f));
            $mesaj = 'Reçete satırı eklendi.'; $mesaj_tip = 'ok';
        } catch(Throwable $e) { $mesaj = 'Hata: '.$e->getMessage(); $mesaj_tip = 'err'; }
    }
}

// ── FİLTRE ────────────────────────────────────────────────────────────────────
$f_ana  = trim($_GET['ana']  ?? '');
$f_malz = trim($_GET['malz'] ?? '');
$f_tur  = trim($_GET['tur']  ?? '');

$params = [];
$where  = ['1=1'];
if ($f_ana)  { $where[] = '(TRIM(ana_urun_kodu) LIKE ? OR ana_urun_adi LIKE ?)'; $params[] = "%$f_ana%"; $params[] = "%$f_ana%"; }
if ($f_malz) { $where[] = '(malzeme_kodu LIKE ? OR malzeme_adi LIKE ?)';          $params[] = "%$f_malz%"; $params[] = "%$f_malz%"; }
if ($f_tur)  { $where[] = '`tür`=?';                                               $params[] = $f_tur; }

$receteler = [];
$turler    = [];
try {
    $st = $db->prepare("SELECT * FROM urun_recetesi WHERE ".implode(' AND ',$where)." ORDER BY TRIM(ana_urun_kodu), bom_id");
    $st->execute($params);
    $receteler = $st->fetchAll(PDO::FETCH_ASSOC);

    $turler = $db->query("SELECT DISTINCT `tür` FROM urun_recetesi WHERE `tür` IS NOT NULL ORDER BY `tür`")->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e) { $mesaj = 'DB Hata: '.$e->getMessage(); $mesaj_tip = 'err'; }

// Ana ürün bazında grupla
$gruplar = [];
foreach ($receteler as $r) {
    $key = trim($r['ana_urun_kodu']);
    $gruplar[$key]['adi']   = $r['ana_urun_adi'];
    $gruplar[$key]['satir'][] = $r;
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Kit Reçeteleri</h1>
    <div class="s-yol">Üretim / <b>Kit Reçeteleri</b></div>
  </div>
  <button onclick="modalAc('ekleModal')" class="btn btn-t btn-sm">+ Reçete Satırı Ekle</button>
</div>

<div class="s-body">

<?php if($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?=$mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2'?>;color:<?=$mesaj_tip==='ok'?'#065F46':'#7F1D1D'?>;border-left:4px solid <?=$mesaj_tip==='ok'?'#22C55E':'#EF4444'?>">
  <?=$mesaj_tip==='ok'?'✅':'⚠️'?> <?=htmlspecialchars($mesaj)?>
</div>
<?php endif; ?>

<!-- Filtre -->
<form method="GET" action="<?=BASE_URL?>/panel.php">
  <input type="hidden" name="sayfa" value="uretim-kit-recete">
  <div class="kart" style="padding:12px;margin-bottom:14px">
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:10px;align-items:end" class="filtre-grid">
      <div>
        <label class="form-et">Ana Ürün Kodu / Adı</label>
        <input name="ana" class="form-alan" value="<?=htmlspecialchars($f_ana)?>" placeholder="8001303122 veya TRIM KIT...">
      </div>
      <div>
        <label class="form-et">Malzeme Kodu / Adı</label>
        <input name="malz" class="form-alan" value="<?=htmlspecialchars($f_malz)?>" placeholder="Malzeme ara...">
      </div>
      <div>
        <label class="form-et">Tür</label>
        <select name="tur" class="form-alan">
          <option value="">Tümü</option>
          <?php foreach($turler as $t): ?>
          <option value="<?=htmlspecialchars($t)?>" <?=$f_tur===$t?'selected':''?>><?=htmlspecialchars($t)?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:6px">
        <button type="submit" class="btn btn-t">🔍 Ara</button>
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-recete" class="btn btn-b">↺</a>
      </div>
    </div>
  </div>
</form>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px">
  <?php foreach([
    ['📦','Ana Ürün',count($gruplar),'#1E3A5F','#EFF6FF'],
    ['📋','Toplam Satır',count($receteler),'#16A34A','#F0FDF4'],
    ['🔍','Filtre Sonucu',($f_ana||$f_malz||$f_tur)?count($receteler).' kayıt':'Tümü gösteriliyor','#D97706','#FFFBEB'],
  ] as $k): ?>
  <div class="kart" style="padding:12px;border-left:4px solid <?=$k[3]?>;background:<?=$k[4]?>;text-align:center">
    <div style="font-size:18px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700;color:var(--m2)"><?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Accordion Gruplar -->
<?php if(empty($gruplar)): ?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">Kayıt bulunamadı.</div>
<?php else: ?>

<?php
// Tek ürün filtrelendiyse direkt aç
$tek_acik = (count($gruplar) === 1) || $f_ana || $f_malz;
$grup_idx  = 0;
foreach ($gruplar as $ana_kod => $grup):
    $grup_idx++;
    $acik = $tek_acik || $grup_idx === 1;
    $satir_sayisi = count($grup['satir']);
?>
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:8px;border-left:4px solid #1E3A5F">
  <!-- Grup Başlığı -->
  <div onclick="grpToggle(this)"
       style="padding:12px 16px;background:#F8FAFC;border-bottom:1px solid var(--kenar);cursor:pointer;display:flex;justify-content:space-between;align-items:center;user-select:none">
    <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
      <span style="font-family:monospace;font-weight:900;font-size:14px;color:#1E3A5F"><?=htmlspecialchars($ana_kod)?></span>
      <span style="font-size:12px;color:var(--m2)"><?=htmlspecialchars(mb_strimwidth($grup['adi']??'',0,60,'…'))?></span>
      <span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;background:#EFF6FF;color:#1E3A5F"><?=$satir_sayisi?> malzeme</span>
    </div>
    <div style="display:flex;gap:8px;align-items:center">
      <button onclick="event.stopPropagation();satirEkleModal('<?=htmlspecialchars(addslashes($ana_kod))?>','<?=htmlspecialchars(addslashes($grup['adi']??''))?>')"
              class="btn btn-b btn-sm" style="font-size:11px;padding:3px 10px">+ Satır Ekle</button>
      <span class="grp-ok" style="font-size:10px;color:var(--m3);transition:transform .2s;display:inline-block;transform:<?=$acik?'rotate(180deg)':'rotate(0deg)'?>">▼</span>
    </div>
  </div>
  <!-- Grup İçerik -->
  <div class="grp-ic" style="display:<?=$acik?'block':'none'?>">
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead><tr style="background:#1E3A5F;color:#fff">
        <th style="padding:7px 10px;text-align:left">#</th>
        <th style="padding:7px 10px;text-align:left">Malzeme Kodu</th>
        <th style="padding:7px 10px;text-align:left">Malzeme Adı</th>
        <th style="padding:7px 10px;text-align:right">Miktar</th>
        <th style="padding:7px 10px;text-align:left">Birim</th>
        <th style="padding:7px 10px;text-align:left">Tür</th>
        <th style="padding:7px 10px;text-align:left">Ekleyen</th>
        <th style="padding:7px 10px;text-align:left">Tarih</th>
        <th style="padding:7px 10px;text-align:center">Sil</th>
      </tr></thead>
      <tbody>
      <?php foreach($grup['satir'] as $si=>$s): ?>
      <tr style="border-bottom:1px solid var(--kenar)">
        <td style="padding:6px 10px;color:var(--m3)"><?=$si+1?></td>
        <td style="padding:6px 10px;font-family:monospace;font-weight:700"><?=htmlspecialchars($s['malzeme_kodu']??'')?></td>
        <td style="padding:6px 10px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
            title="<?=htmlspecialchars($s['malzeme_adi']??'')?>"><?=htmlspecialchars($s['malzeme_adi']??'')?></td>
        <td style="padding:6px 10px;text-align:right;font-weight:700"><?=htmlspecialchars($s['miktar']??'')?></td>
        <td style="padding:6px 10px"><?=htmlspecialchars($s['birim']??'')?></td>
        <td style="padding:6px 10px">
          <span style="font-size:10px;padding:2px 7px;border-radius:8px;background:var(--kenar-a);color:var(--m)"><?=htmlspecialchars($s['tür']??'')?></span>
        </td>
        <td style="padding:6px 10px;font-size:11px;color:var(--m2)"><?=htmlspecialchars($s['ekleyen']??'')?></td>
        <td style="padding:6px 10px;font-size:11px;color:var(--m3)"><?=$s['tarih']?date('d.m.Y',strtotime($s['tarih'])):''?></td>
        <td style="padding:6px 10px;text-align:center">
          <button onclick="satirSil(<?=(int)$s['bom_id']?>, '<?=htmlspecialchars(addslashes($s['malzeme_kodu']??''))?>')"
                  class="btn btn-sm" style="font-size:10px;padding:2px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">🗑</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

</div><!-- /s-body -->

<!-- EKLE MODAL -->
<div id="ekleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center;padding:16px;overflow-y:auto">
<div class="kart" style="width:680px;max-width:100%;padding:22px">
  <div style="display:flex;justify-content:space-between;margin-bottom:16px">
    <div style="font-weight:800;font-size:15px" id="ekleModalBaslik">+ Reçete Satırı Ekle</div>
    <button onclick="modalKapat('ekleModal')" style="border:none;background:none;font-size:20px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="ekle">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div>
        <label class="form-et">Ana Ürün Kodu *</label>
        <input name="ana_urun_kodu" id="f_ana_kod" class="form-alan" required placeholder="8001303122">
      </div>
      <div>
        <label class="form-et">Ana Ürün Adı *</label>
        <input name="ana_urun_adi" id="f_ana_adi" class="form-alan" placeholder="Trim KIT BM 36...">
      </div>
      <div>
        <label class="form-et">Malzeme Kodu *</label>
        <input name="malzeme_kodu" id="f_malz_kod" class="form-alan" required placeholder="8001272712">
      </div>
      <div>
        <label class="form-et">Malzeme Adı *</label>
        <input name="malzeme_adi" id="f_malz_adi" class="form-alan" placeholder="Top Niche Trim...">
      </div>
      <div>
        <label class="form-et">Miktar *</label>
        <input name="miktar" id="f_miktar" class="form-alan" type="number" step="1" min="1" value="1" required>
      </div>
      <div>
        <label class="form-et">Birim</label>
        <input name="birim" id="f_birim" class="form-alan" value="ADET">
      </div>
      <div style="grid-column:span 2">
        <label class="form-et">Tür</label>
        <select name="tur" id="f_tur" class="form-alan">
          <option value="Yardımcı Malz.">Yardımcı Malz.</option>
          <option value="Hammadde">Hammadde</option>
          <option value="Yarı Mamül">Yarı Mamül</option>
          <option value="Mamül">Mamül</option>
          <option value="Ambalaj">Ambalaj</option>
        </select>
      </div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px">
      <button type="button" onclick="modalKapat('ekleModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">💾 Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- SİL FORM -->
<form method="POST" id="silForm" style="display:none">
  <input type="hidden" name="action" value="sil">
  <input type="hidden" name="bom_id" id="silId">
</form>

<style>
@media(max-width:700px){.filtre-grid{grid-template-columns:1fr 1fr!important}}
@media(max-width:500px){.filtre-grid{grid-template-columns:1fr!important}}
</style>
<script>
function modalAc(id)  { document.getElementById(id).style.display='flex'; }
function modalKapat(id){ document.getElementById(id).style.display='none'; }

function grpToggle(el) {
    var ic = el.nextElementSibling;
    var ok = el.querySelector('.grp-ok');
    var acik = ic.style.display !== 'none';
    ic.style.display = acik ? 'none' : 'block';
    if(ok) ok.style.transform = acik ? 'rotate(0deg)' : 'rotate(180deg)';
}

function satirEkleModal(anaKod, anaAdi) {
    document.getElementById('f_ana_kod').value = anaKod;
    document.getElementById('f_ana_adi').value = anaAdi;
    document.getElementById('f_malz_kod').value = '';
    document.getElementById('f_malz_adi').value = '';
    document.getElementById('f_miktar').value = '1';
    document.getElementById('ekleModalBaslik').textContent = '+ Satır Ekle: ' + anaKod;
    modalAc('ekleModal');
}

function satirSil(id, malzKod) {
    if(!confirm('"' + malzKod + '" malzemesini bu reçeteden silmek istediğinizden emin misiniz?\n\nGeri alınamaz!')) return;
    document.getElementById('silId').value = id;
    document.getElementById('silForm').submit();
}
</script>
