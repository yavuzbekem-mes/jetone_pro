<?php
/**
 * MES Paket Yönetimi
 * Route: uretim-paketler
 */
if(!defined('ROOT_DIR')) require_once dirname(__DIR__,2).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

$f_paket   = trim($_GET['paket_no']  ?? '');
$f_stok    = trim($_GET['stok_kodu'] ?? '');
$f_emri    = trim($_GET['emri']      ?? '');
$f_tur     = trim($_GET['tur']       ?? '');
$f_basl    = trim($_GET['basl']      ?? date('Y-m-01'));
$f_bitis   = trim($_GET['bitis']     ?? date('Y-m-d'));

$paketler = []; $toplam_miktar = 0;
$hata = '';

if($mes_pdo) {
    try {
        $w = [];
        $p = [];

        if($f_paket)  { $w[] = "(PAKET_NO LIKE ? OR ANA_PAKET_NO LIKE ?)"; $p[]="%$f_paket%"; $p[]="%$f_paket%"; }
        if($f_stok)   { $w[] = "STOK_KODU LIKE ?";       $p[] = "%$f_stok%"; }
        if($f_emri)   { $w[] = "URETIM_EMRI_NO LIKE ?";  $p[] = "%$f_emri%"; }
        if($f_tur)    { $w[] = "ISNULL(ETIKET_TURU,'URETIM')=?"; $p[] = $f_tur; }

        if(empty($w)) {
            // Filtre yoksa bu aya ait son 500 kayıt
            $sql = "SELECT TOP 500 P.*,ISNULL(P.EKLEYEN,'') AS EKLEYEN FROM dbo.PAKETLER P
                    WHERE CONVERT(date,ISNULL(EKLENME_TARIHI,URETIM_TARIHI)) BETWEEN ? AND ?
                    ORDER BY ID DESC";
            $p = [$f_basl, $f_bitis];
        } else {
            $ws  = implode(' AND ', $w);
            $sql = "SELECT * FROM dbo.PAKETLER WHERE $ws ORDER BY ID DESC";
        }

        $st = $mes_pdo->prepare($sql);
        $st->execute($p);
        $paketler = $st->fetchAll(PDO::FETCH_ASSOC);
        $toplam_miktar = array_sum(array_column($paketler, 'MIKTAR'));

        // HAMMADDE paketleri için Tiger'dan tedarikçi kodu çek
        $cari_kodu_map = []; // irsaliye_no => cari_kodu
        if($tigerdb_pdo) {
            try {
                $hm_irsno = array_unique(array_column(
                    array_filter($paketler, fn($r) => ($r['ETIKET_TURU']??'') === 'HAMMADDE'),
                    'URETIM_EMRI_NO'
                ));
                if(!empty($hm_irsno)) {
                    $in = implode(',', array_fill(0, count($hm_irsno), '?'));
                    $ts = $tigerdb_pdo->prepare(
                        "SELECT F.FICHENO, C.CODE AS CARI_KODU
                         FROM (SELECT FICHENO,CLIENTREF FROM LG_222_01_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1
                               UNION ALL
                               SELECT FICHENO,CLIENTREF FROM LG_222_02_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1) F
                         LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF"
                    );
                    $ts->execute(array_merge(array_values($hm_irsno), array_values($hm_irsno)));
                    foreach($ts->fetchAll(PDO::FETCH_ASSOC) as $tr) {
                        $cari_kodu_map[$tr['FICHENO']] = $tr['CARI_KODU'];
                    }
                }
            } catch(Throwable $e) {}
        }
    } catch(Throwable $e) {
        $hata = $e->getMessage();
        error_log("[PAKET_YON] $hata");
    }
}

$tur_map = [
    ''        => ['Tümü',      '#6B7280'],
    'URETIM'  => ['1. Kalite', '#16A34A'],
    'IKINCI'  => ['2. Kalite', '#DC2626'],
    'HURDA'   => ['Hurda',     '#EA580C'],
    'FIRE'    => ['Fire',      '#F59E0B'],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Paket Yönetimi</h1>
    <div class="s-yol">Üretim / <b>Paket Yönetimi</b></div>
  </div>
</div>

<div class="s-body">

<?php if($hata): ?>
<div style="padding:12px 16px;margin-bottom:14px;background:#FEF2F2;color:#7F1D1D;border:1px solid #FECACA;border-radius:var(--r);font-size:13px">
  ⚠️ <?=htmlspecialchars($hata)?>
</div>
<?php endif; ?>

<!-- Filtre Kartı -->
<div class="kart" style="padding:18px;margin-bottom:16px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="uretim-paketler">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;align-items:flex-end">
      <div>
        <label class="form-et" style="font-size:11px">Başlangıç</label>
        <input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Bitiş</label>
        <input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Paket No / LOT</label>
        <input type="text" name="paket_no" class="form-alan" value="<?=htmlspecialchars($f_paket)?>" placeholder="LOT25...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Stok Kodu</label>
        <input type="text" name="stok_kodu" class="form-alan" value="<?=htmlspecialchars($f_stok)?>" placeholder="2961...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Üretim Emri</label>
        <input type="text" name="emri" class="form-alan" value="<?=htmlspecialchars($f_emri)?>" placeholder="UE-...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Paket Türü</label>
        <select name="tur" class="form-alan">
          <?php foreach($tur_map as $val=>[$lbl,$_r]): ?>
          <option value="<?=htmlspecialchars($val)?>" <?=$f_tur===$val?'selected':''?>><?=$lbl?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-t" style="flex:1;padding:10px">🔍 Ara</button>
        <a href="?sayfa=uretim-paketler" class="btn" style="padding:10px 14px;background:var(--kenar-a);color:var(--m2)">↺</a>
      </div>
    </div>
  </form>
</div>

<!-- Özet -->
<?php
$say_uretim = count(array_filter($paketler, fn($r)=>($r['ETIKET_TURU']??'URETIM')==='URETIM' || empty($r['ETIKET_TURU'])));
$say_ikinci = count(array_filter($paketler, fn($r)=>($r['ETIKET_TURU']??'')==='IKINCI'));
$say_hurda  = count(array_filter($paketler, fn($r)=>in_array($r['ETIKET_TURU']??'',['HURDA','FIRE'])));
$say_aktif  = count(array_filter($paketler, fn($r)=>($r['AKTIF']??0)==0));
?>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px">
  <?php foreach([
    ['Toplam Kayıt',   count($paketler),            '#6B7280'],
    ['1. Kalite',      $say_uretim,                 '#16A34A'],
    ['2. Kalite/Fire', $say_ikinci+$say_hurda,       '#DC2626'],
    ['Aktif Paket',    $say_aktif,                  '#0EA5E9'],
  ] as [$lbl,$val,$renk]): ?>
  <div style="background:var(--yuzey);border-radius:var(--r);padding:16px 18px;text-align:center;box-shadow:var(--shadow);border-top:3px solid <?=$renk?>">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px"><?=$lbl?></div>
    <div style="font-size:26px;font-weight:900;color:<?=$renk?>"><?=number_format($val)?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <span style="font-weight:800;font-size:14px">📦 Paket Listesi</span>
    <span style="font-size:12px;color:var(--m3)"><?=count($paketler)?> kayıt<?=empty($f_paket)&&empty($f_stok)&&empty($f_emri)?' (filtre ile daha fazlasını görebilirsiniz)':''?></span>
  </div>
  <?php if(empty($paketler)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">
    <div style="font-size:40px;margin-bottom:12px">📦</div>
    <div style="font-weight:600">Seçilen kriterlerde paket bulunamadı.</div>
  </div>
  <?php else: ?>
  <div style="overflow:auto;max-height:600px">
  <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
    <colgroup>
      <col style="width:54px">      <!-- ID -->
      <col style="width:130px">     <!-- Paket No -->
      <col style="width:100px">     <!-- Stok Kodu -->
      <col style="width:200px">     <!-- Stok Adı -->
      <col style="width:70px">      <!-- Miktar -->
      <col style="width:50px">      <!-- Birim -->
      <col style="width:120px">     <!-- Üretim Emri -->
      <col style="width:90px">      <!-- Tür -->
      <col style="width:80px">      <!-- Durum -->
      <col style="width:110px">     <!-- Çalışan -->
      <col style="width:110px">     <!-- Tarih -->
      <col style="width:100px">     <!-- İşlem -->
    </colgroup>
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E293B;color:#fff;border-bottom:2px solid #0F172A">
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">ID</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Paket No</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Stok Kodu</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Stok Adı</th>
        <th style="padding:9px 10px;text-align:right;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Miktar</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Birim</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Üretim Emri</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Tür</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Durum</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Çalışan</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155;white-space:nowrap;overflow:hidden">Tarih</th>
        <th style="padding:9px 10px;text-align:center;font-size:11px;white-space:nowrap;overflow:hidden">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($paketler as $i=>$r):
      $tur    = strtoupper(trim($r['ETIKET_TURU']??'URETIM'));
      $aktif  = (int)($r['AKTIF']??0);
      // Renk
      switch($tur) {
        case 'IKINCI': $tur_bg='#FEF3C7'; $tur_fg='#92400E'; $tur_adi='⚑ 2.Kalite'; break;
        case 'HURDA':
        case 'FIRE':   $tur_bg='#FEE2E2'; $tur_fg='#7F1D1D'; $tur_adi='🔥 Hurda/Fire'; break;
        default:       $tur_bg='#D1FAE5'; $tur_fg='#065F46'; $tur_adi='✅ 1.Kalite'; break;
      }
      // Durum
      switch($aktif) {
        case 0: $dur_bg='#D1FAE5'; $dur_fg='#065F46'; $dur_adi='Aktif'; break;
        case 1: $dur_bg='#FEE2E2'; $dur_fg='#7F1D1D'; $dur_adi='Pasif'; break;
        case 2: $dur_bg='#FEE2E2'; $dur_fg='#7F1D1D'; $dur_adi='Red'; break;
        default:$dur_bg='#F3F4F6'; $dur_fg='#374151'; $dur_adi='Pasif'; break;
      }
      $satir_bg = $aktif!==0 ? '#FFF0F0' : ($i%2===0 ? '#fff' : 'var(--kenar-a)');
      $pid = (int)($r['ID']??0);
      $pno = htmlspecialchars($r['PAKET_NO']??'');
      $sk  = htmlspecialchars($r['STOK_KODU']??'');
      $eno = htmlspecialchars($r['URETIM_EMRI_NO']??'');
      // Etiket JSON verisi — ETIKET_TURU'na göre doğru alanlar
      $is_hammadde = ($tur === 'HAMMADDE');
      // HAMMADDE: CALISAN=tedarikçi adı, EKLEYEN=ERP kullanıcısı
      // FIS_NO varsa tedarikçi kodu olarak kullan (satınalma kayıtlarında boş olabilir)
      $e_firma_kodu = $is_hammadde ? ($cari_kodu_map[$r['URETIM_EMRI_NO']??''] ?? trim($r['FIS_NO']??'') ?: '15601') : '15601';
      $e_firma_adi  = $is_hammadde ? (trim($r['CALISAN']??'') ?: 'POLİZA ENDÜSTRİ A.Ş.') : 'POLİZA ENDÜSTRİ A.Ş.';
      $e_operator   = $is_hammadde ? ($r['EKLEYEN']??$r['CALISAN']??'') : ($r['CALISAN']??'');
      $e_pkt_json   = json_encode([[
          'uretim_emri_no' => $r['URETIM_EMRI_NO']??'',
          'malzeme_kodu'   => $r['STOK_KODU']??'',
          'malzeme_adi'    => $r['STOK_ADI']??'',
          'firma_kodu'     => $e_firma_kodu,
          'firma_adi'      => $e_firma_adi,
          'uretim_tarihi'  => substr($r['URETIM_TARIHI']??'',0,16),
          'operator_kodu'  => $e_operator,
          'miktar'         => (float)($r['MIKTAR']??0),
          'lot_no'         => $r['PAKET_NO']??'',
          'etiket_turu'    => $tur,
      ]], JSON_UNESCAPED_UNICODE);
      $etiket_url = ''; // artık POST form kullanıyoruz
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$satir_bg?>">
      <td style="padding:7px 10px;color:var(--m3);font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;white-space:nowrap"><?=$pid?></td>
      <td style="padding:7px 10px;font-weight:700;font-family:monospace;font-size:10px;border-right:1px solid var(--kenar);overflow:hidden;white-space:nowrap"><?=$pno?></td>
      <td style="padding:7px 10px;font-size:11px;font-weight:600;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=$sk?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['STOK_ADI']??'')?>"><?=htmlspecialchars($r['STOK_ADI']??'')?></td>
      <td style="padding:7px 10px;text-align:right;font-weight:700;color:#16A34A;border-right:1px solid var(--kenar);white-space:nowrap"><?=number_format((float)($r['MIKTAR']??0),2)?></td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars($r['BIRIM']??'ADET')?></td>
      <td style="padding:7px 10px;border-right:1px solid var(--kenar)">
        <a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($eno)?>"
           style="font-weight:700;color:var(--t);text-decoration:none;font-size:11px"><?=$eno?></a>
      </td>
      <td style="padding:7px 10px;border-right:1px solid var(--kenar)">
        <span style="background:<?=$tur_bg?>;color:<?=$tur_fg?>;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:700"><?=$tur_adi?></span>
      </td>
      <td style="padding:7px 10px;border-right:1px solid var(--kenar)">
        <span style="background:<?=$dur_bg?>;color:<?=$dur_fg?>;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:700"><?=$dur_adi?></span>
      </td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m2);border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars($r['CALISAN']??'')?></td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars(substr($r['URETIM_TARIHI']??'',0,16))?></td>
      <td style="padding:8px 12px;text-align:center;white-space:nowrap">
        <!-- Görüntüle -->
        <button onclick="paketDetay(<?=$pid?>)"
                title="Detay"
                style="padding:4px 8px;border:none;border-radius:5px;cursor:pointer;font-size:11px;background:#EDE9FE;color:#5B21B6;margin-right:3px;font-weight:700">
          👁️
        </button>
        <!-- Etiket yazdır -->
        <button type="button"
                onclick="postaEtiketYazdir(<?=htmlspecialchars($e_pkt_json,ENT_QUOTES)?>)"
                title="Etiket Yazdır"
                style="padding:4px 8px;border:none;border-radius:5px;font-size:11px;background:#FEF3C7;color:#92400E;font-weight:700;cursor:pointer;margin-right:3px">
          🖨️
        </button>
        <!-- Böl (sadece aktif paketler) -->
        <?php if($aktif===0): ?>
        <button onclick="paketBol(<?=$pid?>)"
                title="Paketi Böl"
                style="padding:4px 8px;border:none;border-radius:5px;cursor:pointer;font-size:11px;background:#FEE2E2;color:#7F1D1D;font-weight:700;margin-right:3px">
          ✂️
        </button>
        <button onclick='paketIptalAc(<?=$pid?>,"<?=htmlspecialchars($r["PAKET_NO"]??"")?> ",<?=json_encode($r["STOK_KODU"]??"")?>,<?=json_encode($r["STOK_ADI"]??"")?>,<?=(float)($r["MIKTAR"]??0)?>,<?=json_encode($r["URETIM_EMRI_NO"]??"")?> )'
                title="İptal Talebi"
                style="padding:4px 8px;border:none;border-radius:5px;cursor:pointer;font-size:11px;background:#EDE9FE;color:#5B21B6;font-weight:700">
          🚫
        </button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr style="background:var(--kenar-a);border-top:2px solid var(--kenar)">
        <td colspan="4" style="padding:8px 12px;font-weight:700;font-size:12px">TOPLAM</td>
        <td style="padding:8px 12px;text-align:right;font-weight:900;color:#16A34A;font-size:13px"><?=number_format($toplam_miktar,2)?></td>
        <td colspan="7"></td>
      </tr>
    </tfoot>
  </table>
  </div>
  <?php endif; ?>
</div>

<!-- İptal Talebi Modalı -->
<div id="paket-iptal-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:500px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,rgba(124,58,237,.08),var(--yuzey))">
      <span style="font-size:15px;font-weight:800">🚫 İptal Talebi Oluştur</span>
      <button onclick="document.getElementById('paket-iptal-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:24px">
      <div id="iptal-kayit-bilgi" style="background:var(--kenar-a);border-left:4px solid #7C3AED;border-radius:var(--r);padding:12px 14px;margin-bottom:16px;font-size:12px;line-height:1.7"></div>
      <form id="paketIptalForm">
        <input type="hidden" name="mes_kayit_id"    id="iptal-id">
        <input type="hidden" name="kayit_tipi"      value="1K">
        <input type="hidden" name="uretim_emri_no"  id="iptal-emri">
        <input type="hidden" name="paket_no"        id="iptal-paket">
        <input type="hidden" name="stok_kodu"       id="iptal-stok">
        <input type="hidden" name="stok_adi"        id="iptal-stokadi">
        <input type="hidden" name="miktar"          id="iptal-miktar">
        <input type="hidden" name="logo_fis_no"     value="">
        <div style="margin-bottom:16px">
          <label class="form-et">İptal Nedeni <span style="color:#DC2626">*</span></label>
          <textarea name="iptal_nedeni" id="iptal-neden" class="form-alan" rows="3"
                    placeholder="İptal nedenini açıklayın..." required style="resize:vertical"></textarea>
        </div>
        <div style="background:#FEF3C7;border-radius:var(--r);padding:10px 12px;font-size:11px;color:#92400E;margin-bottom:16px">
          ⚠️ Bu talep onaylandığında ilgili paket kaydı kalıcı olarak silinecektir. İşlem loglanacaktır.
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('paket-iptal-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">Vazgeç</button>
          <button type="submit" class="btn" style="padding:10px 24px;background:#7C3AED;color:#fff;font-weight:800">🚫 Talep Oluştur</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Detay Modalı -->
<div id="paket-detay-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:640px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,rgba(93,93,234,.07),var(--yuzey))">
      <span style="font-size:15px;font-weight:800">📦 Paket Detayı</span>
      <button onclick="document.getElementById('paket-detay-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div id="paket-detay-icerik" style="padding:24px">
      <div style="text-align:center;padding:30px;color:var(--m3)">Yükleniyor...</div>
    </div>
  </div>
</div>

<!-- Böl Modalı -->
<div id="paket-bol-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:580px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
      <span style="font-size:15px;font-weight:800">✂️ Paketi Böl</span>
      <button onclick="document.getElementById('paket-bol-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div id="paket-bol-icerik" style="padding:24px">
      <div style="text-align:center;padding:30px;color:var(--m3)">Yükleniyor...</div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
var BASE_PY = '<?=BASE_URL?>';

function paketIptalAc(id, paketno, stok, stokadi, miktar, emri) {
    document.getElementById('iptal-id').value      = id;
    document.getElementById('iptal-paket').value   = paketno.trim();
    document.getElementById('iptal-stok').value    = stok;
    document.getElementById('iptal-stokadi').value = stokadi;
    document.getElementById('iptal-miktar').value  = miktar;
    document.getElementById('iptal-emri').value    = emri.trim();
    document.getElementById('iptal-neden').value   = '';
    document.getElementById('iptal-kayit-bilgi').innerHTML =
        '<b>Paket:</b> ' + paketno.trim() + '<br>' +
        '<b>Stok:</b> ' + stok + ' — ' + stokadi + '<br>' +
        '<b>Miktar:</b> <span style="color:#DC2626;font-weight:700">' + miktar + '</span>' +
        (emri.trim() ? '<br><b>Üretim Emri:</b> ' + emri.trim() : '');
    document.getElementById('paket-iptal-modal').style.display = 'flex';
}

document.getElementById('paketIptalForm').addEventListener('submit', function(e){
    e.preventDefault();
    if(!document.getElementById('iptal-neden').value.trim()){
        alert('İptal nedeni zorunludur.'); return;
    }
    var btn = this.querySelector('button[type=submit]');
    btn.disabled = true; btn.textContent = '⏳ Kaydediliyor...';
    var fd = new FormData(this), obj = {};
    fd.forEach(function(v,k){ obj[k]=v; });
    fetch(BASE_PY+'/islemler/uretim/iptal_talep_olustur.php',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(obj)
    })
    .then(function(r){ return r.text().then(function(t){ try{return JSON.parse(t);}catch(e){throw new Error(t.substring(0,120));} }); })
    .then(function(d){
        btn.disabled=false; btn.textContent='🚫 Talep Oluştur';
        if(d.success){
            document.getElementById('paket-iptal-modal').style.display='none';
            alert('✅ ' + d.message);
        } else {
            alert('Hata: ' + d.message);
        }
    })
    .catch(function(err){ btn.disabled=false; btn.textContent='🚫 Talep Oluştur'; alert('Hata: '+err.message); });
});

function postaEtiketYazdir(pktler) {
    if(!Array.isArray(pktler)) pktler = [pktler];
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = BASE_PY + '/bolumler/uretim/paket_yazdir.php';
    form.target = '_blank';
    var inp = document.createElement('input');
    inp.type = 'hidden'; inp.name = 'paketler';
    inp.value = JSON.stringify(pktler);
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

// Paket Detay
function paketDetay(id) {
    document.getElementById('paket-detay-icerik').innerHTML = '<div style="text-align:center;padding:30px;color:var(--m3)">Yükleniyor...</div>';
    document.getElementById('paket-detay-modal').style.display = 'flex';
    fetch(BASE_PY + '/islemler/uretim/paket_detay.php?id=' + id)
    .then(function(r){return r.json();})
    .then(function(d){ renderDetay(d); })
    .catch(function(e){ document.getElementById('paket-detay-icerik').innerHTML = '<div style="color:#DC2626">Hata: '+e.message+'</div>'; });
}

function renderDetay(d) {
    if(!d || !d.ID) {
        document.getElementById('paket-detay-icerik').innerHTML = '<div style="color:#DC2626">Paket bulunamadı.</div>';
        return;
    }
    var html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">';
    var alanlar = [
        ['Paket No',d.PAKET_NO],['Ana Paket No',d.ANA_PAKET_NO],
        ['Stok Kodu',d.STOK_KODU],['Stok Adı',d.STOK_ADI],
        ['Miktar',d.MIKTAR+' '+d.BIRIM],['Üretim Emri',d.URETIM_EMRI_NO],
        ['Çalışan',d.CALISAN],['Ekleyen',d.EKLEYEN],
        ['Etiket Türü',d.ETIKET_TURU],['Kayıt Türü',d.KAYIT_TURU],
        ['Ambar',d.AMBAR],['Stok Yeri',d.STOK_YERI],
        ['Fiş No',d.FIS_NO],['Üretim Tarihi',d.URETIM_TARIHI],
        ['Eklenme Tarihi',d.EKLENME_TARIHI]
    ];
    alanlar.forEach(function(a){
        if(!a[1]) return;
        html += '<div style="background:var(--kenar-a);border-radius:var(--r);padding:10px 12px;border-left:3px solid var(--t)">';
        html += '<div style="font-size:10px;color:var(--m3);font-weight:700;text-transform:uppercase;margin-bottom:3px">'+a[0]+'</div>';
        html += '<div style="font-size:13px;font-weight:600">'+a[1]+'</div></div>';
    });
    html += '</div>';
    document.getElementById('paket-detay-icerik').innerHTML = html;
}

// Paketi Böl
function paketBol(id) {
    document.getElementById('paket-bol-icerik').innerHTML = '<div style="text-align:center;padding:30px;color:var(--m3)">Yükleniyor...</div>';
    document.getElementById('paket-bol-modal').style.display = 'flex';
    fetch(BASE_PY + '/islemler/uretim/paket_detay.php?id=' + id)
    .then(function(r){return r.json();})
    .then(function(d){ renderBolForm(d); })
    .catch(function(e){ document.getElementById('paket-bol-icerik').innerHTML = '<div style="color:#DC2626">Hata: '+e.message+'</div>'; });
}

// Aktif paket verisi — renderBolForm'da set edilir
var _bolData = null;

function bolEtiketAc() {
    var pktler = window._bolPktler;
    console.log('[ETİKET] _bolPktler:', JSON.stringify(pktler));
    if(!pktler || !pktler.length) {
        alert('Etiket verisi yok! _bolPktler boş.');
        return;
    }
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = BASE_PY+'/bolumler/uretim/paket_yazdir.php';
    form.target = '_blank';
    var inp = document.createElement('input');
    inp.type = 'hidden'; inp.name = 'paketler';
    inp.value = JSON.stringify(pktler);
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

function renderBolForm(d) {
    _bolData = d; // tüm paket verisini sakla
    var orijinal = parseFloat(d.MIKTAR)||0;
    var html = '<div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 14px;margin-bottom:16px;font-size:12px">'
        + '<b>'+d.PAKET_NO+'</b> — '+d.STOK_KODU+' — '+d.STOK_ADI+'<br>'
        + 'Toplam: <b style="color:#16A34A">'+orijinal+' '+d.BIRIM+'</b>'
        + '</div>'
        + '<div style="background:#FEF3C7;border-radius:var(--r);padding:10px 12px;margin-bottom:16px;font-size:11px;color:#92400E">'
        + '⚠️ Toplam bölünen miktar <b>'+orijinal+'</b> olmalıdır.'
        + '</div>'
        + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">'
        + '<div><label class="form-et">1. Paket Miktarı</label>'
        + '<input type="number" id="bol-p1" class="form-alan" step="0.01" min="0.01" max="'+orijinal+'" oninput="bolHesapla()"></div>'
        + '<div><label class="form-et">2. Paket Miktarı</label>'
        + '<input type="number" id="bol-p2" class="form-alan" step="0.01" min="0.01" max="'+orijinal+'" oninput="bolHesapla()"></div>'
        + '</div>'
        + '<div id="bol-sonuc" style="background:var(--kenar-a);border-radius:var(--r);padding:12px;margin-bottom:16px;text-align:center">'
        + '<span style="font-size:11px;color:var(--m3)">Toplam: </span>'
        + '<span id="bol-toplam" style="font-size:18px;font-weight:900;color:var(--t)">0</span>'
        + ' <span style="font-size:12px;color:var(--m3)">'+d.BIRIM+'</span>'
        + '<div id="bol-mesaj" style="font-size:11px;margin-top:4px"></div>'
        + '</div>'
        + '<div style="display:flex;gap:10px;justify-content:flex-end">'
        + '<button type="button" onclick="document.getElementById(\'paket-bol-modal\').style.display=\'none\'" class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">İptal</button>'
        + '<button type="button" id="bol-btn" class="btn btn-t" style="padding:10px 24px" disabled onclick="bolKaydet()">✂️ Böl</button>'
        + '</div>';
    document.getElementById('paket-bol-icerik').innerHTML = html;
}

function bolHesapla() {
    var d = _bolData;
    if(!d) return;
    var orijinal = parseFloat(d.MIKTAR)||0;
    var p1 = parseFloat(document.getElementById('bol-p1').value)||0;
    var p2 = parseFloat(document.getElementById('bol-p2').value)||0;
    var top = p1 + p2;
    document.getElementById('bol-toplam').textContent = top.toFixed(2);
    var msg = document.getElementById('bol-mesaj');
    var btn = document.getElementById('bol-btn');
    if(Math.abs(top-orijinal)<0.01 && p1>0 && p2>0) {
        msg.style.color='#16A34A'; msg.textContent='✅ Toplam doğru!'; btn.disabled=false;
    } else {
        msg.style.color='#DC2626';
        msg.textContent='❌ Toplam '+orijinal.toFixed(2)+' olmalı (şu an '+top.toFixed(2)+')';
        btn.disabled=true;
    }
}

function bolKaydet() {
    var d = _bolData;
    if(!d){ Swal.fire({title:'Hata',text:'Paket verisi yok',icon:'error'}); return; }
    var p1 = parseFloat(document.getElementById('bol-p1').value)||0;
    var p2 = parseFloat(document.getElementById('bol-p2').value)||0;
    var id=d.ID, paketno=d.PAKET_NO, sk=d.STOK_KODU, sa=d.STOK_ADI,
        birim=d.BIRIM, emrino=d.URETIM_EMRI_NO, tarih=d.URETIM_TARIHI,
        calisan=d.CALISAN, etur=d.ETIKET_TURU,
        anahm=d.ANA_HAMMADDE, stokyeri=d.STOK_YERI, ambar=d.AMBAR;
    // Inline loading göster — Swal yerine
    var bolIcerik = document.getElementById('paket-bol-icerik');
    bolIcerik.innerHTML = '<div style="text-align:center;padding:40px">'
        + '<div style="font-size:36px;margin-bottom:12px">⏳</div>'
        + '<div style="font-weight:800;font-size:15px;color:var(--t)">Paket bölünüyor...</div>'
        + '<div style="font-size:12px;color:var(--m3);margin-top:6px">Lütfen bekleyin</div>'
        + '</div>';
    fetch(BASE_PY+'/islemler/uretim/paket_bol_kaydet.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:id,paketno:paketno,stokkodu:sk,stokadi:sa,birim:birim,
            uretimemrino:emrino,uretimtarihi:tarih,calisan:calisan,etiketturu:etur,
            anahammadde:anahm,stokyeri:stokyeri,ambar:ambar,paket1:p1,paket2:p2})
    }).then(function(r){return r.json();}).then(function(d){
        if(d.success){
            // Önce window._bolPktler'ı ata
            window._bolPktler = [];
            if(d.paket_detaylar && d.paket_detaylar.length > 0){
                window._bolPktler = d.paket_detaylar.map(function(p){
                    return {
                        uretim_emri_no: String(p.uretim_emri_no||''),
                        malzeme_kodu:   String(p.stok_kodu||p.malzeme_kodu||''),
                        malzeme_adi:    String(p.stok_adi||p.malzeme_adi||''),
                        firma_kodu:     String(p.firma_kodu||'15601'),
                        firma_adi:      String(p.firma_adi||'Poliza A.S'),
                        uretim_tarihi:  String(p.uretim_tarihi||''),
                        operator_kodu:  String(p.calisan||p.operator_kodu||''),
                        miktar:         parseFloat(p.miktar)||0,
                        lot_no:         String(p.paket_no||p.lot_no||''),
                        etiket_turu:    String(p.etiket_turu||'URETIM')
                    };
                });
            }
            console.log('[BOL_ATANDI] window._bolPktler:', JSON.stringify(window._bolPktler));

            // Sonra innerHTML — buton tıklandığında window._bolPktler zaten hazır
            bolIcerik.innerHTML = '<div style="text-align:center;padding:32px">'
                + '<div style="font-size:42px;margin-bottom:10px">✅</div>'
                + '<div style="font-weight:800;font-size:15px;color:#16A34A">Paket Bölündü!</div>'
                + '<div style="font-size:12px;color:var(--m3);margin-top:8px">'+d.message+'</div>'
                + '<div style="margin-top:20px;display:flex;gap:10px;justify-content:center">'
                + '<button onclick="bolEtiketAc()" class="btn btn-t" style="padding:10px 20px;font-size:13px">🖨️ Etiketleri Yazdır</button>'
                + '<button onclick="document.getElementById(\'paket-bol-modal\').style.display=\'none\';location.reload();" class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">✓ Tamam</button>'
                + '</div>'
                + '</div>';
        } else {
            bolIcerik.innerHTML = '<div style="text-align:center;padding:32px">'
                + '<div style="font-size:42px;margin-bottom:10px">❌</div>'
                + '<div style="font-weight:800;font-size:15px;color:#DC2626">Hata!</div>'
                + '<div style="font-size:12px;color:var(--m3);margin-top:6px">'+d.message+'</div>'
                + '<div style="margin-top:16px"><button onclick="document.getElementById(\'paket-bol-modal\').style.display=\'none\'" class="btn" style="padding:8px 20px;background:var(--kenar-a);color:var(--m2)">Kapat</button></div>'
                + '</div>';
        }
    }).catch(function(e){
        bolIcerik.innerHTML = '<div style="text-align:center;padding:32px">'
            + '<div style="font-size:42px;margin-bottom:10px">❌</div>'
            + '<div style="font-weight:700;color:#DC2626">Bağlantı hatası</div>'
            + '<div style="font-size:12px;color:var(--m3)">'+e.message+'</div>'
            + '</div>';
    });
}
</script>

</div><!-- /s-body -->
