<?php
/**
 * Kalıp Bağlama Özet Dashboard
 * panel.php: 'uretim-kalip-ozet'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$yil = (int)($_GET['yil'] ?? date('Y'));
$ay  = (int)($_GET['ay']  ?? 0);
$where = "WHERE YEAR(baslama_tarih)=$yil" . ($ay ? " AND MONTH(baslama_tarih)=$ay" : '');

try {
    $oz = $db->query("SELECT
        COUNT(*) toplam,
        SUM(durumu='Tamamlandı') tamamlanan,
        SUM(durumu='Devam Ediyor') devam,
        ROUND(AVG(CASE WHEN durumu='Tamamlandı' THEN TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih) END),0) ort_dk,
        MIN(CASE WHEN durumu='Tamamlandı' THEN TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih) END) min_dk,
        MAX(CASE WHEN durumu='Tamamlandı' THEN TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih) END) max_dk,
        SUM(aciliyet='Acil') acil_say
        FROM kalip_degisim $where")->fetch(PDO::FETCH_ASSOC);

    // Aylık trend
    $aylik = [];
    for($m=1;$m<=12;$m++){
        $st=$db->query("SELECT COUNT(*) t, SUM(durumu='Tamamlandı') taman,
            ROUND(AVG(CASE WHEN durumu='Tamamlandı' THEN TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih) END),0) ort
            FROM kalip_degisim WHERE YEAR(baslama_tarih)=$yil AND MONTH(baslama_tarih)=$m");
        $aylik[$m]=$st->fetch(PDO::FETCH_ASSOC);
    }

    // Makine bazlı
    $makine = $db->query("SELECT is_istasyonu, COUNT(*) toplam,
        SUM(durumu='Tamamlandı') tamamlanan,
        ROUND(AVG(CASE WHEN durumu='Tamamlandı' THEN TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih) END),0) ort_dk
        FROM kalip_degisim $where GROUP BY is_istasyonu ORDER BY toplam DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

    // Son 10 işlem
    $son10 = $db->query("SELECT * FROM kalip_degisim ORDER BY kalip_id DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $oz=[]; $aylik=[]; $makine=[]; $son10=[]; }

$ay_adlari=['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
$yillar = range(date('Y')-2,date('Y')+1);
$max_aylik = max(1, max(array_map(fn($a)=>(int)($a['t']??0), $aylik)));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Kalıp Bağlama Özet</h1>
    <div class="s-yol">Üretim / <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" style="color:var(--t)">Kalıp Bağlama</a> / <b>Özet</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-devam"     class="btn btn-b btn-sm">⏳ Devam Edenler</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-tamamlanan" class="btn btn-b btn-sm">✅ Tamamlananlar</a>
  </div>
</div>

<div class="s-body">

<!-- Filtre -->
<div class="kart" style="margin-bottom:14px;padding:10px 14px">
  <form method="GET" action="<?= BASE_URL ?>/panel.php" style="display:flex;gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="uretim-kalip-ozet">
    <div class="form-grup" style="margin:0"><label class="form-et">Yıl</label>
      <select class="form-alan" name="yil"><?php foreach($yillar as $y): ?><option value="<?= $y ?>" <?= $yil===$y?'selected':'' ?>><?= $y ?></option><?php endforeach; ?></select></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Ay</label>
      <select class="form-alan" name="ay"><option value="0" <?= $ay===0?'selected':'' ?>>Tüm Yıl</option>
        <?php for($m=1;$m<=12;$m++): ?><option value="<?= $m ?>" <?= $ay===$m?'selected':'' ?>><?= $ay_adlari[$m] ?></option><?php endfor; ?></select></div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
  </form>
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:16px">
  <?php foreach([
    ['Toplam',       $oz['toplam']??0,     '#1E3A5F','#E0F2FE'],
    ['Tamamlanan',   $oz['tamamlanan']??0, '#22C55E','#D1FAE5'],
    ['Devam Eden',   $oz['devam']??0,      '#F59E0B','#FEF9C3'],
    ['Acil İşlem',   $oz['acil_say']??0,   '#EF4444','#FEE2E2'],
    ['Ort. Süre(dk)',$oz['ort_dk']??'—',  '#6366F1','#EDE9FE'],
    ['En Uzun(dk)',  $oz['max_dk']??'—',   '#0EA5E9','#E0F7FA'],
  ] as [$l,$v,$f,$b]): ?>
  <div style="background:<?= $b ?>;border-radius:var(--r);padding:14px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $f ?>"><?= $v ?></div>
    <div style="font-size:10px;color:<?= $f ?>;font-weight:700;text-transform:uppercase;margin-top:2px"><?= $l ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Aylık Bar Grafiği -->
<div class="kart" style="margin-bottom:16px;padding:14px">
  <div style="font-size:13px;font-weight:800;margin-bottom:12px">📅 <?= $yil ?> Yılı Aylık Kalıp Bağlama Sayısı</div>
  <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:4px;align-items:end;height:90px">
    <?php for($m=1;$m<=12;$m++):
        $t=(int)($aylik[$m]['t']??0);
        $tam=(int)($aylik[$m]['taman']??0);
        $ort=$aylik[$m]['ort']??0;
        $bh=$t>0?max(6,round($t/$max_aylik*70)):4;
        $cur=($m===(int)date('m')&&$yil===(int)date('Y'));
    ?>
    <div style="display:flex;flex-direction:column;align-items:center;gap:2px">
      <div style="font-size:9px;font-weight:700;color:<?= $cur?'var(--t)':'var(--m2)' ?>"><?= $t>0?$t:'' ?></div>
      <div style="width:100%;display:flex;flex-direction:column-reverse;gap:1px">
        <?php if($t>0): ?>
        <div style="height:<?= $bh ?>px;background:<?= $cur?'#1E3A5F':'#94A3B8' ?>;border-radius:3px 3px 0 0"></div>
        <?php if($tam>0&&$tam<$t): ?>
        <div style="height:<?= max(3,round($tam/$max_aylik*70)) ?>px;background:#22C55E;border-radius:3px 3px 0 0"></div>
        <?php endif; ?>
        <?php else: ?>
        <div style="height:4px;background:var(--kenar);border-radius:3px;opacity:.4"></div>
        <?php endif; ?>
      </div>
      <?php if($ort>0): ?>
      <div style="font-size:8px;color:var(--m3)"><?= $ort ?>dk</div>
      <?php endif; ?>
      <div style="font-size:9px;color:<?= $cur?'var(--t)':'var(--m2)' ?>;font-weight:<?= $cur?'800':'400' ?>"><?= $ay_adlari[$m] ?></div>
    </div>
    <?php endfor; ?>
  </div>
  <div style="display:flex;gap:16px;margin-top:8px;font-size:11px">
    <span><span style="display:inline-block;width:12px;height:12px;background:#94A3B8;border-radius:2px;margin-right:4px"></span>Toplam</span>
    <span><span style="display:inline-block;width:12px;height:12px;background:#22C55E;border-radius:2px;margin-right:4px"></span>Tamamlanan</span>
  </div>
</div>

<!-- Makine Bazlı + Son İşlemler -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

  <!-- Makine bazlı -->
  <div class="kart" style="padding:0">
    <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px">🔧 Makine Bazlı İstatistik</div>
    <table class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach(['Makine','Toplam','Tamamlanan','Ort. Süre'] as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:7px 10px;font-size:12px;font-weight:700"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach($makine as $mk): ?>
      <tr>
        <td style="font-family:monospace;font-weight:700;color:var(--t)"><?= htmlspecialchars($mk['is_istasyonu']??'') ?></td>
        <td style="text-align:right;font-weight:700"><?= $mk['toplam'] ?></td>
        <td style="text-align:right;color:#22C55E;font-weight:700"><?= $mk['tamamlanan'] ?></td>
        <td style="text-align:right;color:var(--m2)"><?= $mk['ort_dk']?$mk['ort_dk'].' dk':'—' ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Son 10 işlem -->
  <div class="kart" style="padding:0">
    <div style="padding:10px 14px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px">🕐 Son 10 İşlem</div>
    <table class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach(['Makine','Ürün','Durum','Süre'] as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;padding:7px 10px;font-size:12px;font-weight:700"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tbody>
      <?php foreach($son10 as $r):
          $tam=$r['durumu']==='Tamamlandı';
          $sn=$tam&&$r['bitis_tarih']?round((strtotime($r['bitis_tarih'])-strtotime($r['baslama_tarih']))/60).' dk':'⏳';
      ?>
      <tr style="background:<?= $tam?'#F0FFF4':'#FFF5F5' ?>">
        <td style="font-family:monospace;font-size:11px;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['is_istasyonu']??'') ?></td>
        <td style="font-size:11px;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($r['urun_kodu']??'') ?></td>
        <td><span style="background:<?= $tam?'#D1FAE5':'#FEF9C3' ?>;color:<?= $tam?'#065F46':'#92400E' ?>;padding:2px 7px;border-radius:8px;font-size:11px;font-weight:700"><?= $tam?'✅':'⏳' ?></span></td>
        <td style="font-size:11px;font-weight:700"><?= $sn ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</div>
</div>
