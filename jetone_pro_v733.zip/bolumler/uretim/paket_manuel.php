<?php
/**
 * Manuel Paket Oluşturma
 * Route: uretim-paket-manuel
 */
if(!defined('ROOT_DIR')) require_once dirname(__DIR__,2).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Manuel Paket Oluştur</h1>
    <div class="s-yol">Üretim / Paket Yönetimi / <b>Manuel Oluştur</b></div>
  </div>
</div>
<div class="s-body">

<div style="max-width:680px;margin:0 auto">

  <!-- Form -->
  <div class="kart" style="padding:28px">
    <div style="font-size:13px;color:var(--m3);margin-bottom:22px;background:var(--kenar-a);border-radius:var(--r);padding:12px 14px;border-left:4px solid var(--t)">
      📋 Stok kodunu girin → bilgiler Logo'dan otomatik gelir → miktar ve depo bilgisini girin → etiket oluşturulur.
    </div>

    <form id="manuelForm">
      <!-- Stok Kodu -->
      <div style="margin-bottom:16px">
        <label class="form-et">Stok Kodu <span style="color:#DC2626">*</span></label>
        <div style="display:flex;gap:8px">
          <input type="text" id="stok_kodu" name="stok_kodu" class="form-alan"
                 placeholder="2961..." style="flex:1;text-transform:uppercase"
                 oninput="this.value=this.value.toUpperCase()">
          <button type="button" class="btn btn-t" style="padding:10px 16px;white-space:nowrap"
                  onclick="stokSorgu()">🔍 Sorgula</button>
        </div>
        <div id="stok-hata" style="font-size:11px;color:#DC2626;margin-top:4px"></div>
      </div>

      <!-- Stok bilgisi önizleme -->
      <div id="stok-bilgi" style="display:none;background:var(--kenar-a);border-radius:var(--r);padding:14px 16px;margin-bottom:16px;border-left:4px solid #16A34A">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
          <div><span style="color:var(--m3)">Stok Kodu:</span> <b id="sb-kod"></b></div>
          <div><span style="color:var(--m3)">Birim:</span> <b id="sb-birim"></b></div>
          <div style="grid-column:span 2"><span style="color:var(--m3)">Stok Adı:</span> <b id="sb-adi"></b></div>
        </div>
      </div>

      <!-- Gizli alanlar -->
      <input type="hidden" name="stok_adi"  id="h-stok-adi">
      <input type="hidden" name="birim"     id="h-birim">

      <!-- Miktar -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div>
          <label class="form-et">Miktar <span style="color:#DC2626">*</span></label>
          <input type="number" name="miktar" id="miktar" class="form-alan"
                 min="1" step="1" placeholder="100">
        </div>
        <div>
          <label class="form-et">Adet / Birim</label>
          <input type="text" id="birim-goster" class="form-alan" readonly
                 style="background:var(--kenar-a)" placeholder="Stok sorgulandıktan sonra">
        </div>
      </div>

      <!-- Manuel UE No -->
      <div style="margin-bottom:16px">
        <label class="form-et">Üretim Emri / Referans No</label>
        <input type="text" name="uretim_emri_no" class="form-alan"
               placeholder="Manuel-001 veya boş bırakın"
               style="text-transform:uppercase"
               oninput="this.value=this.value.toUpperCase()">
        <div style="font-size:11px;color:var(--m3);margin-top:3px">Üretim emri no yoksa boş bırakın — "MANUEL" olarak kaydedilir.</div>
      </div>

      <!-- Depo ve Raf -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div>
          <label class="form-et">Ambar / Depo</label>
          <select name="ambar" class="form-alan">
            <option value="0">0 — Merkez</option>
            <option value="1" selected>1 — Üretim</option>
            <option value="2">2 — Karantina</option>
            <option value="3">3 — Kırma</option>
            <option value="4">4 — Emanet</option>
            <option value="5">5 — BSH</option>
            <option value="98">98 — Takım Boz</option>
          </select>
        </div>
        <div>
          <label class="form-et">Raf / Stok Yeri</label>
          <input type="text" name="stok_yeri" class="form-alan"
                 placeholder="GKK" value="GKK" style="text-transform:uppercase"
                 oninput="this.value=this.value.toUpperCase()">
        </div>
      </div>

      <!-- Çalışan / Operatör -->
      <div style="margin-bottom:16px">
        <label class="form-et">Operatör / Çalışan</label>
        <input type="text" name="calisan" class="form-alan"
               placeholder="İsim soyisim" value="<?=htmlspecialchars($kul_adi)?>">
      </div>

      <!-- Tarih -->
      <div style="margin-bottom:22px">
        <label class="form-et">Tarih</label>
        <input type="date" name="uretim_tarihi" class="form-alan"
               value="<?=date('Y-m-d')?>">
      </div>

      <!-- Etiket türü -->
      <div style="margin-bottom:22px">
        <label class="form-et">Paket Türü</label>
        <select name="etiket_turu" class="form-alan">
          <option value="URETIM">✅ 1. Kalite / Üretim</option>
          <option value="IKINCI">⚑ 2. Kalite</option>
          <option value="HURDA">🔥 Hurda</option>
        </select>
      </div>

      <button type="submit" class="btn btn-t"
              style="width:100%;padding:14px;font-size:14px;font-weight:800">
        📦 Paketi Oluştur ve Etiket Yazdır
      </button>
    </form>
  </div>

  <!-- Son oluşturulan paketler -->
  <div id="son-paketler" style="display:none" class="kart" style="padding:0;overflow:hidden;margin-top:16px">
    <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px">
      ✅ Son Oluşturulan Paketler
    </div>
    <div id="son-paketler-liste" style="padding:16px"></div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
var BASE_M = '<?=BASE_URL?>';
var stokBilgi = null;

// Stok kodu sorgula
function stokSorgu() {
    var kod = document.getElementById('stok_kodu').value.trim();
    if(!kod){ document.getElementById('stok-hata').textContent='Stok kodu girin'; return; }
    document.getElementById('stok-hata').textContent = '';
    document.getElementById('stok-bilgi').style.display = 'none';

    fetch(BASE_M+'/islemler/uretim/stok_sorgu.php?kod='+encodeURIComponent(kod))
    .then(function(r){return r.json();})
    .then(function(d){
        if(d.success && d.stok){
            stokBilgi = d.stok;
            document.getElementById('sb-kod').textContent   = d.stok.CODE;
            document.getElementById('sb-adi').textContent   = d.stok.NAME;
            document.getElementById('sb-birim').textContent = d.stok.BIRIM||'ADET';
            document.getElementById('h-stok-adi').value     = d.stok.NAME;
            document.getElementById('h-birim').value        = d.stok.BIRIM||'ADET';
            document.getElementById('birim-goster').value   = d.stok.BIRIM||'ADET';
            document.getElementById('stok-bilgi').style.display = 'block';
            document.getElementById('miktar').focus();
        } else {
            document.getElementById('stok-hata').textContent = d.message||'Stok bulunamadı';
            stokBilgi = null;
        }
    })
    .catch(function(e){ document.getElementById('stok-hata').textContent = 'Hata: '+e.message; });
}

// Enter ile sorgu
document.getElementById('stok_kodu').addEventListener('keydown',function(e){
    if(e.key==='Enter'){e.preventDefault();stokSorgu();}
});

// Form gönder
document.getElementById('manuelForm').addEventListener('submit', function(e){
    e.preventDefault();
    if(!stokBilgi){ document.getElementById('stok-hata').textContent='Önce stok kodu sorgulayın'; return; }
    var miktar = parseFloat(document.getElementById('miktar').value)||0;
    if(miktar<=0){ alert('Miktar giriniz'); return; }

    var fd = new FormData(this);
    // Stok adı ve birim gizli alanlardan gelecek
    var btn = this.querySelector('button[type=submit]');
    btn.disabled = true;
    btn.textContent = '⏳ Oluşturuluyor...';

    fetch(BASE_M+'/islemler/uretim/paket_manuel_kaydet.php',{
        method:'POST', body:fd
    })
    .then(function(r){return r.json();})
    .then(function(d){
        btn.disabled = false;
        btn.textContent = '📦 Paketi Oluştur ve Etiket Yazdır';
        if(d.success){
            // Etiket aç
            var form = document.createElement('form');
            form.method='POST'; form.action=BASE_M+'/bolumler/uretim/paket_yazdir.php';
            form.target='_blank';
            var inp=document.createElement('input');
            inp.type='hidden'; inp.name='paketler';
            inp.value=JSON.stringify([{
                uretim_emri_no: d.paket.uretim_emri_no,
                malzeme_kodu:   d.paket.stok_kodu,
                malzeme_adi:    d.paket.stok_adi,
                firma_kodu:     '15601',
                firma_adi:      'Poliza A.S',
                uretim_tarihi:  d.paket.uretim_tarihi,
                operator_kodu:  d.paket.calisan,
                miktar:         d.paket.miktar,
                lot_no:         d.paket.paket_no,
                etiket_turu:    d.paket.etiket_turu
            }]);
            form.appendChild(inp);
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);

            // Listeye ekle
            var sp = document.getElementById('son-paketler');
            var sl = document.getElementById('son-paketler-liste');
            sp.style.display='block';
            var satir = '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--kenar)">'
                +'<div>'
                +'<b style="font-family:monospace">'+d.paket.paket_no+'</b>'
                +' — '+d.paket.stok_kodu
                +' <span style="color:#16A34A;font-weight:700">'+d.paket.miktar+' '+d.paket.birim+'</span>'
                +'</div>'
                +'<a href="'+BASE_M+'/bolumler/uretim/paket_yazdir.php?lot_no='+encodeURIComponent(d.paket.paket_no)+'&malzeme_kodu='+encodeURIComponent(d.paket.stok_kodu)+'&malzeme_adi='+encodeURIComponent(d.paket.stok_adi)+'&miktar='+d.paket.miktar+'&uretim_emri_no='+encodeURIComponent(d.paket.uretim_emri_no)+'&operator_kodu='+encodeURIComponent(d.paket.calisan)+'&uretim_tarihi='+d.paket.uretim_tarihi+'" target="_blank"'
                +' style="padding:4px 10px;background:#FEF3C7;color:#92400E;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none">🖨️ Tekrar Yazdır</a>'
                +'</div>';
            sl.innerHTML = satir + sl.innerHTML;

            // Formu sıfırla (stok kodu kalacak)
            document.getElementById('miktar').value = '';
        } else {
            alert('Hata: '+d.message);
        }
    })
    .catch(function(e){ btn.disabled=false; btn.textContent='📦 Paketi Oluştur ve Etiket Yazdır'; alert('Hata: '+e.message); });
});
</script>

</div><!-- /s-body -->
