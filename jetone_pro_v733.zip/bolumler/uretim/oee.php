<?php
/**
 * JETONE.PRO — OEE (Overall Equipment Effectiveness)
 * bolumler/uretim/oee.php
 *
 * OEE = Availability × Performance × Quality
 *   Availability  = net_calisma_suresi / 420
 *   Performance   = verimlilik / 100
 *   Quality       = 1 - (fire_oranı / 100)
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// ── Filtre parametreleri ──────────────────────────────────────────────────────
$filtre_tip  = $_GET['tip']      ?? 'enj';        // enj | mont | tumu
$tarih_bas   = $_GET['tarih_bas'] ?? date('Y-m-d', strtotime('-29 days'));
$tarih_bit   = $_GET['tarih_bit'] ?? date('Y-m-d');
$secili_mak  = trim($_GET['makina'] ?? '');

// Tarih format doğrula
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tarih_bas)) $tarih_bas = date('Y-m-d', strtotime('-29 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tarih_bit)) $tarih_bit = date('Y-m-d');

$filtre_sql = match($filtre_tip) {
    'enj'  => "AND makina_kodu LIKE 'EN-%'",
    'mont' => "AND makina_kodu NOT LIKE 'EN-%'",
    default => "",
};

// ── Makina listesi (filtre için) ──────────────────────────────────────────────
try {
    $mak_q = "SELECT DISTINCT makina_kodu FROM verimlilik
               WHERE tarih BETWEEN ? AND ? $filtre_sql
               ORDER BY makina_kodu";
    $mak_s = $db->prepare($mak_q);
    $mak_s->execute([$tarih_bas, $tarih_bit]);
    $makina_list = $mak_s->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) { $makina_list = []; }

// ── Ana OEE sorgusu — makina bazlı ───────────────────────────────────────────
$mak_filtre_sql = $secili_mak ? "AND makina_kodu = " . $db->quote($secili_mak) : "";

try {
    $oee_q = "
        SELECT
            makina_kodu,
            COUNT(DISTINCT tarih)                          AS gun_sayisi,
            COUNT(*)                                        AS kayit_sayisi,
            ROUND(AVG(net_calisma_suresi / 420 * 100), 2)  AS availability,
            ROUND(AVG(verimlilik), 2)                       AS performance,
            ROUND(AVG(GREATEST(0, 100 - COALESCE(fire_oranı,0))), 2) AS quality,
            ROUND(
                AVG(net_calisma_suresi / 420)
                * AVG(verimlilik / 100)
                * AVG(GREATEST(0, 1 - COALESCE(fire_oranı,0) / 100))
                * 100, 2
            )                                               AS oee,
            ROUND(SUM(uretim_miktari), 0)                   AS toplam_uretim,
            ROUND(SUM(fire_miktar), 0)                      AS toplam_fire,
            ROUND(AVG(durus), 1)                            AS ort_durus
        FROM verimlilik
        WHERE tarih BETWEEN ? AND ?
          $filtre_sql $mak_filtre_sql
        GROUP BY makina_kodu
        ORDER BY oee DESC
    ";
    $oee_s = $db->prepare($oee_q);
    $oee_s->execute([$tarih_bas, $tarih_bit]);
    $oee_rows = $oee_s->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $oee_rows = []; }

// ── Günlük OEE trendi ─────────────────────────────────────────────────────────
try {
    $trend_q = "
        SELECT
            tarih,
            ROUND(
                AVG(net_calisma_suresi / 420)
                * AVG(verimlilik / 100)
                * AVG(GREATEST(0, 1 - COALESCE(fire_oranı,0) / 100))
                * 100, 2
            ) AS oee,
            ROUND(AVG(net_calisma_suresi / 420 * 100), 2) AS availability,
            ROUND(AVG(verimlilik), 2)                      AS performance,
            ROUND(AVG(GREATEST(0, 100 - COALESCE(fire_oranı,0))), 2) AS quality
        FROM verimlilik
        WHERE tarih BETWEEN ? AND ?
          $filtre_sql $mak_filtre_sql
        GROUP BY tarih
        ORDER BY tarih ASC
    ";
    $trend_s = $db->prepare($trend_q);
    $trend_s->execute([$tarih_bas, $tarih_bit]);
    $trend_rows = $trend_s->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $trend_rows = []; }

// ── Genel özet ────────────────────────────────────────────────────────────────
try {
    $ozet_q = "
        SELECT
            ROUND(AVG(net_calisma_suresi / 420 * 100), 2)  AS availability,
            ROUND(AVG(verimlilik), 2)                       AS performance,
            ROUND(AVG(GREATEST(0, 100 - COALESCE(fire_oranı,0))), 2) AS quality,
            ROUND(
                AVG(net_calisma_suresi / 420)
                * AVG(verimlilik / 100)
                * AVG(GREATEST(0, 1 - COALESCE(fire_oranı,0) / 100))
                * 100, 2
            ) AS oee,
            COUNT(DISTINCT makina_kodu)  AS makina_sayisi,
            COUNT(DISTINCT tarih)        AS gun_sayisi,
            SUM(uretim_miktari)          AS toplam_uretim,
            SUM(fire_miktar)             AS toplam_fire
        FROM verimlilik
        WHERE tarih BETWEEN ? AND ?
          $filtre_sql $mak_filtre_sql
    ";
    $ozet_s = $db->prepare($ozet_q);
    $ozet_s->execute([$tarih_bas, $tarih_bit]);
    $ozet = $ozet_s->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $ozet = null; }

// ── Yardımcı: OEE rengi ──────────────────────────────────────────────────────
function oee_renk(float $v): string {
    if ($v >= 85) return '#059669'; // Dünya standartı
    if ($v >= 65) return '#D97706'; // Orta
    if ($v >= 45) return '#EA580C'; // Düşük
    return '#DC2626';               // Kritik
}
function oee_bg(float $v): string {
    if ($v >= 85) return '#D1FAE5';
    if ($v >= 65) return '#FEF9C3';
    if ($v >= 45) return '#FFEDD5';
    return '#FEE2E2';
}
function oee_etiket(float $v): string {
    if ($v >= 85) return 'Dünya Standartı';
    if ($v >= 65) return 'Orta';
    if ($v >= 45) return 'Düşük';
    return 'Kritik';
}
?>

<!-- ── Başlık ─────────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 OEE — Ekipman Etkinliği</h1>
    <div class="s-yol">Üretim / <b>Overall Equipment Effectiveness</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste" class="btn btn-b btn-sm">💉 Enjeksiyon</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste-montaj" class="btn btn-b btn-sm">🔧 Montaj</a>
  </div>
</div>

<div class="s-body">

<!-- ── Filtre Kartı ─────────────────────────────────────────────────────────── -->
<div class="kart" style="margin-bottom:16px">
  <form method="GET" action="" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="uretim-oee">

    <div class="form-grup" style="margin:0">
      <label class="form-et">Hat Tipi</label>
      <select class="form-alan" name="tip" style="min-width:160px">
        <option value="enj"  <?= $filtre_tip==='enj' ?'selected':'' ?>>💉 Enjeksiyon (EN-%)</option>
        <option value="mont" <?= $filtre_tip==='mont'?'selected':'' ?>>🔧 Montaj</option>
        <option value="tumu" <?= $filtre_tip==='tumu'?'selected':'' ?>>📊 Tümü</option>
      </select>
    </div>

    <div class="form-grup" style="margin:0">
      <label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="tarih_bas" value="<?= htmlspecialchars($tarih_bas) ?>" style="max-width:150px">
    </div>

    <div class="form-grup" style="margin:0">
      <label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="tarih_bit" value="<?= htmlspecialchars($tarih_bit) ?>" style="max-width:150px">
    </div>

    <?php if (!empty($makina_list)): ?>
    <div class="form-grup" style="margin:0">
      <label class="form-et">Makina</label>
      <select class="form-alan" name="makina" style="min-width:140px">
        <option value="">— Tümü —</option>
        <?php foreach ($makina_list as $m): ?>
        <option value="<?= htmlspecialchars($m) ?>" <?= $secili_mak===$m?'selected':'' ?>>
          <?= htmlspecialchars($m) ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php endif; ?>

    <button type="submit" class="btn btn-t">🔍 Filtrele</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-oee" class="btn btn-b">✕ Temizle</a>
  </form>
</div>

<?php if ($ozet && ($ozet['oee'] ?? 0) > 0): ?>

<!-- ── Özet Göstergeler ──────────────────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px" class="oee-ozet-grid">

  <!-- OEE -->
  <div class="kart" style="text-align:center;border-top:4px solid <?= oee_renk((float)$ozet['oee']) ?>">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:6px">OEE</div>
    <div style="font-size:36px;font-weight:800;color:<?= oee_renk((float)$ozet['oee']) ?>;line-height:1">
      <?= number_format((float)$ozet['oee'], 1) ?>%
    </div>
    <div style="margin-top:8px">
      <span style="background:<?= oee_bg((float)$ozet['oee']) ?>;color:<?= oee_renk((float)$ozet['oee']) ?>;
                   padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700">
        <?= oee_etiket((float)$ozet['oee']) ?>
      </span>
    </div>
    <div style="margin-top:8px;height:8px;background:var(--kenar);border-radius:4px">
      <div style="height:8px;width:<?= min(100,(float)$ozet['oee']) ?>%;
                  background:<?= oee_renk((float)$ozet['oee']) ?>;border-radius:4px;transition:.3s"></div>
    </div>
    <div style="font-size:10px;color:var(--m3);margin-top:4px">Hedef: 85%</div>
  </div>

  <!-- Availability -->
  <div class="kart" style="text-align:center;border-top:4px solid #2563EB">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:6px">Availability</div>
    <div style="font-size:36px;font-weight:800;color:#2563EB;line-height:1">
      <?= number_format((float)$ozet['availability'], 1) ?>%
    </div>
    <div style="font-size:11px;color:var(--m2);margin-top:6px">Net Çalışma / 420 dk (mola hariç)</div>
    <div style="margin-top:8px;height:8px;background:var(--kenar);border-radius:4px">
      <div style="height:8px;width:<?= min(100,(float)$ozet['availability']) ?>%;
                  background:#2563EB;border-radius:4px"></div>
    </div>
  </div>

  <!-- Performance -->
  <div class="kart" style="text-align:center;border-top:4px solid #7C3AED">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:6px">Performance</div>
    <div style="font-size:36px;font-weight:800;color:#7C3AED;line-height:1">
      <?= number_format((float)$ozet['performance'], 1) ?>%
    </div>
    <div style="font-size:11px;color:var(--m2);margin-top:6px">Teorik / Gerçek Üretim</div>
    <div style="margin-top:8px;height:8px;background:var(--kenar);border-radius:4px">
      <div style="height:8px;width:<?= min(100,(float)$ozet['performance']) ?>%;
                  background:#7C3AED;border-radius:4px"></div>
    </div>
  </div>

  <!-- Quality -->
  <div class="kart" style="text-align:center;border-top:4px solid #059669">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:6px">Quality</div>
    <div style="font-size:36px;font-weight:800;color:#059669;line-height:1">
      <?= number_format((float)$ozet['quality'], 1) ?>%
    </div>
    <div style="font-size:11px;color:var(--m2);margin-top:6px">1 − Fire Oranı</div>
    <div style="margin-top:8px;height:8px;background:var(--kenar);border-radius:4px">
      <div style="height:8px;width:<?= min(100,(float)$ozet['quality']) ?>%;
                  background:#059669;border-radius:4px"></div>
    </div>
  </div>

</div>

<!-- ── İkincil bilgi kartları ────────────────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px" class="oee-info-grid">
  <div class="kart" style="padding:12px 16px;display:flex;gap:12px;align-items:center">
    <div style="font-size:24px">🏭</div>
    <div><div style="font-size:20px;font-weight:800;color:var(--t)"><?= (int)$ozet['makina_sayisi'] ?></div>
    <div style="font-size:11px;color:var(--m2)">Aktif Makina</div></div>
  </div>
  <div class="kart" style="padding:12px 16px;display:flex;gap:12px;align-items:center">
    <div style="font-size:24px">📅</div>
    <div><div style="font-size:20px;font-weight:800;color:var(--t)"><?= (int)$ozet['gun_sayisi'] ?></div>
    <div style="font-size:11px;color:var(--m2)">Gün</div></div>
  </div>
  <div class="kart" style="padding:12px 16px;display:flex;gap:12px;align-items:center">
    <div style="font-size:24px">📦</div>
    <div><div style="font-size:20px;font-weight:800;color:var(--t)"><?= number_format((int)$ozet['toplam_uretim']) ?></div>
    <div style="font-size:11px;color:var(--m2)">Toplam Üretim</div></div>
  </div>
  <div class="kart" style="padding:12px 16px;display:flex;gap:12px;align-items:center">
    <div style="font-size:24px">🔥</div>
    <div><div style="font-size:20px;font-weight:800;color:var(--hat)"><?= number_format((int)$ozet['toplam_fire']) ?></div>
    <div style="font-size:11px;color:var(--m2)">Toplam Fire</div></div>
  </div>
</div>

<!-- ── Günlük OEE Trend Grafiği ──────────────────────────────────────────────── -->
<?php if (!empty($trend_rows)): ?>
<div class="kart" style="margin-bottom:20px">
  <div class="kart-ust">
    <div class="kart-bas">📈 Günlük OEE Trendi</div>
  </div>
  <div style="overflow-x:auto">
    <canvas id="oeeChart" style="max-height:280px;min-width:600px"></canvas>
  </div>
</div>
<?php endif; ?>

<!-- ── Makina Bazlı OEE Tablosu ───────────────────────────────────────────────── -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;font-size:14px">
      🏭 Makina Bazlı OEE
      <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($oee_rows) ?> makina</span>
    </div>
    <div style="font-size:11px;color:var(--m2)">
      <?= date('d.m.Y', strtotime($tarih_bas)) ?> — <?= date('d.m.Y', strtotime($tarih_bit)) ?>
    </div>
  </div>
  <div style="overflow-x:auto">
    <table id="oeeTablo" class="tablo" style="width:100%">
      <thead>
        <tr>
          <th class="oee-th">Makina</th>
          <th class="oee-th" style="text-align:center">OEE</th>
          <th class="oee-th" style="text-align:center">Availability</th>
          <th class="oee-th" style="text-align:center">Performance</th>
          <th class="oee-th" style="text-align:center">Quality</th>
          <th class="oee-th" style="text-align:right">Üretim</th>
          <th class="oee-th" style="text-align:right">Fire</th>
          <th class="oee-th" style="text-align:right">Ort. Duruş (dk)</th>
          <th class="oee-th" style="text-align:right">Gün</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($oee_rows as $r):
          $oee_v = (float)$r['oee'];
          $av_v  = (float)$r['availability'];
          $pf_v  = (float)$r['performance'];
          $ql_v  = (float)$r['quality'];
        ?>
        <tr>
          <td style="font-weight:700;white-space:nowrap"><?= htmlspecialchars($r['makina_kodu']) ?></td>
          <td style="text-align:center">
            <div style="display:flex;flex-direction:column;align-items:center;gap:3px">
              <span style="background:<?= oee_bg($oee_v) ?>;color:<?= oee_renk($oee_v) ?>;
                           padding:2px 10px;border-radius:20px;font-size:12px;font-weight:800">
                <?= number_format($oee_v, 1) ?>%
              </span>
              <div style="width:60px;height:4px;background:var(--kenar);border-radius:2px">
                <div style="height:4px;width:<?= min(100,$oee_v) ?>%;background:<?= oee_renk($oee_v) ?>;border-radius:2px"></div>
              </div>
            </div>
          </td>
          <td style="text-align:center;font-size:12px;font-weight:700;color:#2563EB"><?= number_format($av_v, 1) ?>%</td>
          <td style="text-align:center;font-size:12px;font-weight:700;color:#7C3AED"><?= number_format($pf_v, 1) ?>%</td>
          <td style="text-align:center;font-size:12px;font-weight:700;color:#059669"><?= number_format($ql_v, 1) ?>%</td>
          <td style="text-align:right;font-weight:600"><?= number_format((int)$r['toplam_uretim']) ?></td>
          <td style="text-align:right;color:var(--hat);font-weight:600"><?= number_format((int)$r['toplam_fire']) ?></td>
          <td style="text-align:right"><?= number_format((float)$r['ort_durus'], 1) ?></td>
          <td style="text-align:right"><?= (int)$r['gun_sayisi'] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:#F1F5F9">
          <th style="color:#000;font-weight:700">Makina</th>
          <th style="color:#000;font-weight:700">OEE</th>
          <th style="color:#000;font-weight:700">Availability</th>
          <th style="color:#000;font-weight:700">Performance</th>
          <th style="color:#000;font-weight:700">Quality</th>
          <th style="color:#000;font-weight:700">Üretim</th>
          <th style="color:#000;font-weight:700">Fire</th>
          <th style="color:#000;font-weight:700">Ort. Duruş</th>
          <th style="color:#000;font-weight:700">Gün</th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<?php else: ?>
<div class="kart" style="text-align:center;padding:48px;color:var(--m2)">
  <div style="font-size:36px;margin-bottom:8px">📊</div>
  <div style="font-weight:700">Seçilen tarih aralığında kayıt bulunamadı.</div>
  <div style="font-size:12px;margin-top:4px">Tarih aralığını veya hat tipini değiştirin.</div>
</div>
<?php endif; ?>

</div><!-- /s-body -->

<style>
th.oee-th,
table#oeeTablo thead th.oee-th {
  background-color: #E2E8F0 !important;
  color: #000 !important;
  font-weight: 700 !important;
  border-bottom: 2px solid #94A3B8 !important;
}
@media (max-width:768px) {
  .oee-ozet-grid  { grid-template-columns: 1fr 1fr !important; }
  .oee-info-grid  { grid-template-columns: 1fr 1fr !important; }
}
@media (max-width:480px) {
  .oee-ozet-grid  { grid-template-columns: 1fr !important; }
  .oee-info-grid  { grid-template-columns: 1fr 1fr !important; }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
$(document).ready(function(){
    document.title = 'OEE — Ekipman Etkinliği';

    // DataTable
    $('#oeeTablo').DataTable({
        language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
        scrollX: true, paging: false,
        dom: 'Bfrtip',
        order: [[1,'desc']],
        
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'OEE_<?= date('Ymd') ?>'},
            {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
        ],
        initComplete: function(){
            this.api().columns([0]).every(function(){
                var col=this;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
                    .appendTo($(col.footer()).empty())
                    .on('change',function(){
                        col.search($.fn.dataTable.util.escapeRegex($(this).val())?'^'+$.fn.dataTable.util.escapeRegex($(this).val())+'$':'',true,false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var t=$('<div/>').html(d).text();
                    sel.append('<option value="'+t+'">'+t+'</option>');
                });
            });
        }
    });
    // .oee-th class'ı CSS ile zaten koyu yapılıyor
});

<?php if (!empty($trend_rows)): ?>
// Trend grafiği
(function(){
    var labels = <?= json_encode(array_map(fn($r) => date('d.m', strtotime($r['tarih'])), $trend_rows)) ?>;
    var oeeData  = <?= json_encode(array_map(fn($r) => (float)$r['oee'],         $trend_rows)) ?>;
    var avData   = <?= json_encode(array_map(fn($r) => (float)$r['availability'], $trend_rows)) ?>;
    var pfData   = <?= json_encode(array_map(fn($r) => (float)$r['performance'],  $trend_rows)) ?>;
    var qlData   = <?= json_encode(array_map(fn($r) => (float)$r['quality'],      $trend_rows)) ?>;

    new Chart(document.getElementById('oeeChart'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'OEE %',          data: oeeData, borderColor:'#F97316', backgroundColor:'rgba(249,115,22,.1)', borderWidth:2.5, tension:.3, fill:true  },
                { label: 'Availability %', data: avData,  borderColor:'#2563EB', backgroundColor:'transparent', borderWidth:1.5, tension:.3, borderDash:[4,3] },
                { label: 'Performance %',  data: pfData,  borderColor:'#7C3AED', backgroundColor:'transparent', borderWidth:1.5, tension:.3, borderDash:[4,3] },
                { label: 'Quality %',      data: qlData,  borderColor:'#059669', backgroundColor:'transparent', borderWidth:1.5, tension:.3, borderDash:[4,3] }
            ]
        },
        options: {
            responsive: true,
            interaction: { mode:'index', intersect:false },
            plugins: {
                legend: { position:'top' },
                tooltip: {
                    callbacks: {
                        label: function(c){ return c.dataset.label+': '+c.parsed.y.toFixed(1)+'%'; }
                    }
                }
            },
            scales: {
                y: { min:0, max:100, ticks:{ callback: v => v+'%' }, grid:{ color:'rgba(0,0,0,.06)' } },
                x: { grid:{ display:false } }
            },
            annotation: {
                annotations: {
                    hedef: { type:'line', yMin:85, yMax:85, borderColor:'rgba(249,115,22,.4)', borderWidth:1.5,
                             label:{ content:'Hedef 85%', enabled:true, position:'end', font:{size:10} } }
                }
            }
        }
    });
})();
<?php endif; ?>
</script>
