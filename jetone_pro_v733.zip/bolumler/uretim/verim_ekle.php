<?php
/**
 * JETONE.PRO — Üretim Verim Girişi (Enjeksiyon Hatları)
 * bolumler/uretim/verim_ekle.php
 *
 * panel.php sayfaMap_ozel:
 *   'uretim-verim-ekle' => 'bolumler/uretim/verim_ekle.php'
 *
 * Liste kaynağı: MySQL mps_plan tablosu (hat_kodu LIKE 'EN-%')
 * Verim kaydı : MySQL verimlilik tablosu
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$kul      = Auth::kullanici();
$tiger_ok = ($tigerdb_pdo !== null);

// ── URL parametreleri ─────────────────────────────────────────────────────────
$plan_id   = (int)($_GET['plan_id']   ?? 0);
$urun_kodu = trim($_GET['urun_kodu'] ?? '');
$istasyon  = trim($_GET['istasyon']  ?? '');
// plan_id=0: manuel giriş, >0: plandan giriş — ikisinde de form açılır
$form_acik = ($urun_kodu !== '' && $istasyon !== '');

// ── Hat sırası — gunluk_plan_enj.php ile birebir aynı ───────────────────────
$hat_sirasi = [
    'EN-110-01','EN-132-01','EN-80-01','EN-130-01','EN-160-01',
    'EN-201-01','EN-202-01','EN-301-01','EN-302-01','EN-350-01',
    'EN-420-01','EN-500-01','EN-650-01','EN-162-01','EN-131-01',
    'EN-161-01','EN-530-01','EN-650-02','EN-450-01','EN-500-02',
    'EN-260-01','EN-410-01','EN-500-03','EN-700-01','EN-180-01',
    'EN-280-01','EN-650-03','EN-650-04','EN-650-05','EN-650-06',
    'EN-850-01','EN-850-02',
];

// ── Hat renkleri — gunluk_plan_enj.php ile birebir aynı ─────────────────────
$hat_renk = [
    'EN-110-01'=>'#FEE2E2','EN-132-01'=>'#DBEAFE','EN-80-01' =>'#D1FAE5',
    'EN-130-01'=>'#FEF3C7','EN-160-01'=>'#EDE9FE','EN-201-01'=>'#CFFAFE',
    'EN-202-01'=>'#FCE7F3','EN-301-01'=>'#E0F2FE','EN-302-01'=>'#ECFDF5',
    'EN-350-01'=>'#FEF9C3','EN-420-01'=>'#FFEDD5','EN-500-01'=>'#F1F5F9',
    'EN-650-01'=>'#F3E8FF','EN-162-01'=>'#E0F7FA','EN-131-01'=>'#FFF3CD',
    'EN-161-01'=>'#FEF08A','EN-530-01'=>'#FED7AA','EN-650-02'=>'#C7D2FE',
    'EN-450-01'=>'#CCFBF1','EN-500-02'=>'#FFE4E6','EN-260-01'=>'#BFDBFE',
    'EN-410-01'=>'#FDE68A','EN-500-03'=>'#BBF7D0','EN-700-01'=>'#FECACA',
    'EN-180-01'=>'#A7F3D0','EN-280-01'=>'#BAE6FD','EN-650-03'=>'#FDE68A',
    'EN-650-04'=>'#FBCFE8','EN-650-05'=>'#FED7AA','EN-650-06'=>'#DDD6FE',
    'EN-850-01'=>'#FECDD3','EN-850-02'=>'#FEF08A',
];

// ── VERİM GİRİŞ FORMU açıkken: Tiger'dan operasyon + personel ────────────────
$op         = null;
$calisanlar = [];

if ($form_acik) {

    // Tiger: operasyon bilgisi (çevrim süresi, göz sayısı)
    if ($tiger_ok) {
        try {
            $st = $tigerdb_pdo->prepare("
                SELECT TOP 1
                    IT.CODE                        AS MALZEME_KODU,
                    IT.NAME                        AS MALZEME_ADI,
                    dbo.LG_INTTOTIME2(OPR.RUNTIME) AS PROSES_CEVRIMI,
                    OPR.BATCHQUANTITY              AS PARTI_BUYUKLUGU
                FROM dbo.LG_222_OPRTREQ  AS OPR
                LEFT JOIN dbo.LG_222_OPERTION  AS OP  ON OP.LOGICALREF   = OPR.OPERATIONREF
                LEFT JOIN dbo.LG_222_RTNGLINE  AS RTL ON RTL.OPERATIONREF = OP.LOGICALREF
                LEFT JOIN dbo.LG_222_ROUTING   AS RT  ON RT.LOGICALREF   = RTL.ROUTINGREF
                LEFT JOIN dbo.LG_222_BOMREVSN  AS BMR ON BMR.ROUTINGREF  = RT.LOGICALREF
                LEFT JOIN dbo.LG_222_BOMASTER  AS BOM ON BOM.LOGICALREF  = BMR.BOMMASTERREF
                LEFT JOIN dbo.LG_222_ITEMS     AS IT  ON IT.LOGICALREF   = BOM.MAINPRODREF
                WHERE IT.CODE = ?
                  AND (OP.CODE <> 'SKOP.001')
                ORDER BY OPR.RUNTIME DESC
            ");
            $st->execute([$urun_kodu]);
            $op = $st->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {}
    }

    // Tiger: personel listesi
    if ($tiger_ok) {
        try {
            $st2 = $tigerdb_pdo->query("
                SELECT CODE AS KOD, NAME AS AD
                FROM LG_222_EMPLOYEE WITH(NOLOCK)
                WHERE ACTIVE = 0
                ORDER BY NAME
            ");
            $calisanlar = $st2->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {}
    }
}

// ── LİSTE: mps_plan'dan enjeksiyon hatları ───────────────────────────────────
// Sıralama: önce hat_sirasi dizisine göre hat sırası, sonra hat içinde hat_sira_no
$plan_rows = [];
if (!$form_acik) {
    try {
        $raw = $db->query("
            SELECT
                id,
                hat_kodu,
                urun_kodu,
                urun_adi,
                durum,
                kalan_miktar,
                planlanan_miktar,
                uretim_emri_no,
                hat_sira_no
            FROM mps_plan
            WHERE durum NOT IN ('Tamamlandı','İptal','Tamamlandi','Iptal')
              AND hat_kodu LIKE 'EN-%'
              AND urun_kodu != '__DURUS__'
        ")->fetchAll(PDO::FETCH_ASSOC);

        // hat_sirasi dizisine göre PHP tarafında sırala (gunluk_plan_enj ile aynı mantık)
        $hat_sira_idx = array_flip($hat_sirasi); // hat_kodu => index
        usort($raw, function($a, $b) use ($hat_sira_idx) {
            $ia = $hat_sira_idx[$a['hat_kodu']] ?? 999;
            $ib = $hat_sira_idx[$b['hat_kodu']] ?? 999;
            if ($ia !== $ib) return $ia - $ib;
            return (int)($a['hat_sira_no'] ?? 0) - (int)($b['hat_sira_no'] ?? 0);
        });
        $plan_rows = $raw;
    } catch (Throwable $e) {}
}

// ── Durum etiketi renkleri ────────────────────────────────────────────────────
function durum_roz(string $d): string {
    $map = [
        'Devam Ediyor'  => ['#DBEAFE','#1D4ED8'],
        'Devam Edecek'  => ['#DBEAFE','#1D4ED8'],
        'Planlandı'     => ['#FEF9C3','#92400E'],
        'Sıradaki İş'   => ['#FEF9C3','#92400E'],
        'Beklemede'     => ['#FEF9C3','#92400E'],
        'Tamamlandı'    => ['#D1FAE5','#065F46'],
    ];
    $c = $map[$d] ?? ['#F1F5F9','#334155'];
    return "<span style=\"background:{$c[0]};color:{$c[1]};padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700\">"
         . htmlspecialchars($d) . "</span>";
}
?>

<style>
@media (max-width: 768px) {
    .verim-grid  { grid-template-columns: 1fr !important; }
    .manuel-grid { grid-template-columns: 1fr !important; }
}
</style>

<!-- ── Başlık ─────────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Verim Girişi</h1>
    <div class="s-yol">Üretim /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle" style="color:var(--t)">Verim Girişi</a>
      <?php if ($form_acik): ?>
        / <b><?= htmlspecialchars($urun_kodu) ?> — <?= htmlspecialchars($istasyon) ?></b>
      <?php else: ?>
        / <b>Enjeksiyon Plan Listesi</b>
      <?php endif; ?>
    </div>
  </div>
  <?php if ($form_acik): ?>
    <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste" class="btn btn-b btn-sm">📋 Kayıtlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle" class="btn btn-b btn-sm">← Plana Dön</a>
  </div>
  <?php endif; ?>
</div>

<div class="s-body">

<?php if (!$tiger_ok): ?>
<div style="background:var(--hat-a);color:var(--hat);border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-size:12.5px;font-weight:700">
  ⚠️ Tiger ERP bağlantısı yok — çevrim/personel bilgileri yüklenemedi.
</div>
<?php endif; ?>

<?php if ($form_acik): ?>
<!-- ════════════════════════════════════════════════════════════
     VERİM GİRİŞ FORMU
════════════════════════════════════════════════════════════ -->
<div style="display:grid;grid-template-columns:340px 1fr;gap:18px;align-items:start" class="verim-grid">

  <!-- Sol bilgi kartı -->
  <div class="kart" style="border-top:4px solid var(--t);min-width:0">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">Seçili İş</div>
    <div style="font-size:17px;font-weight:800;color:var(--t);margin-bottom:2px;word-break:break-all"><?= htmlspecialchars($urun_kodu) ?></div>
    <div style="font-size:13px;font-weight:600;margin-bottom:14px;color:var(--m);line-height:1.4;word-break:break-word">
      <?= htmlspecialchars($op['MALZEME_ADI'] ?? ($_GET['urun_adi'] ?? '')) ?>
    </div>
    <div style="display:flex;flex-direction:column;gap:8px;font-size:12.5px;border-top:1px solid var(--kenar);padding-top:12px">
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2);white-space:nowrap">Hat</span>
        <span style="font-weight:700;text-align:right"><?= htmlspecialchars($istasyon) ?></span>
      </div>
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2);white-space:nowrap">Çevrim</span>
        <span style="font-weight:700;text-align:right" id="lblCevrim"><?= htmlspecialchars($op['PROSES_CEVRIMI'] ?? '—') ?> sn</span>
      </div>
      <div style="display:flex;justify-content:space-between;gap:8px">
        <span style="color:var(--m2);white-space:nowrap">Göz Sayısı</span>
        <span style="font-weight:700;text-align:right" id="lblGoz"><?= htmlspecialchars($op['PARTI_BUYUKLUGU'] ?? '—') ?></span>
      </div>
    </div>
    <!-- Teorik hedef kutusu -->
    <div id="hedefKutu" style="display:none;margin-top:14px;background:var(--bil-a);border:1px solid var(--bil);border-radius:var(--r);padding:10px 12px">
      <div style="font-size:11px;font-weight:700;color:#0369A1;margin-bottom:2px">🎯 Teorik Hedef</div>
      <div id="hedefDeger" style="font-size:20px;font-weight:800;color:#0369A1">—</div>
      <div id="hedefAlt"   style="font-size:11px;color:#0284C7;margin-top:2px">—</div>
    </div>
  </div>

  <!-- Sağ form kartı -->
  <div class="kart">
    <div style="font-size:15px;font-weight:800;margin-bottom:16px">Verim Bilgilerini Girin</div>
    <form id="verimForm">

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Ürün Adı</label>
          <input class="form-alan" name="malzeme_ad" type="text" readonly
                 value="<?= htmlspecialchars($op['MALZEME_ADI'] ?? ($_GET['urun_adi'] ?? '')) ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Vardiya <span class="zorunlu">*</span></label>
          <select class="form-alan" name="vardiya" id="vardiyaSelect" required>
            <option value="1">1. Vardiya (08:00–16:00)</option>
            <option value="2">2. Vardiya (16:00–24:00)</option>
            <option value="3">3. Vardiya (24:00–08:00)</option>
          </select>
        </div>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Makina No</label>
          <input class="form-alan" name="istasyon_kodu" type="text" readonly
                 value="<?= htmlspecialchars($istasyon) ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Tarih <span class="zorunlu">*</span></label>
          <input class="form-alan" name="tarih" type="date"
                 value="<?= date('Y-m-d') ?>" required>
        </div>
      </div>

      <!-- 3 Personel -->
      <div class="form-grid-3">
        <?php for ($p = 1; $p <= 3; $p++): ?>
        <div class="form-grup">
          <label class="form-et">
            <?= $p ?>. Personel
            <?= $p === 1 ? '<span class="zorunlu">*</span>' : '<span style="font-weight:400;color:var(--m2)">(opsiyonel)</span>' ?>
          </label>
          <select class="form-alan" name="calisan_personel[]" <?= $p === 1 ? 'required' : '' ?>>
            <option value="">— Seçiniz —</option>
            <?php foreach ($calisanlar as $c): ?>
            <option value="<?= htmlspecialchars($c['AD']) ?>"><?= htmlspecialchars($c['AD']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endfor; ?>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Göz Sayısı <span class="zorunlu">*</span></label>
          <input class="form-alan" id="goz_sayisi" name="goz_sayisi"
                 type="number" min="1" required
                 value="<?= htmlspecialchars($op['PARTI_BUYUKLUGU'] ?? '1') ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Proses Çevrimi (sn)</label>
          <input class="form-alan" id="cevrim_input" name="cevrim" type="text"
                 value="<?= htmlspecialchars($op['PROSES_CEVRIMI'] ?? '') ?>"
                 readonly style="background:var(--kenar-a)">
        </div>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Duruş Süresi (Dakika) <span class="zorunlu">*</span></label>
          <input class="form-alan" id="durus" name="durus"
                 type="number" step="0.01" min="0" value="0" required>
        </div>
        <div class="form-grup">
          <label class="form-et">Net Çalışma Süresi (Dakika)</label>
          <input class="form-alan" id="net_calisma" name="net_calisma_suresi"
                 type="number" step="0.01" readonly style="background:var(--kenar-a)">
        </div>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Üretim Miktarı (Adet) <span class="zorunlu">*</span></label>
          <input class="form-alan" id="uretim_miktari" name="uretim_miktari"
                 type="number" min="0" required placeholder="Üretilen adet giriniz">
        </div>
        <div class="form-grup">
          <label class="form-et">Fire Miktarı (Adet)</label>
          <input class="form-alan" id="fire_miktar" name="fire_miktar"
                 type="number" min="0" value="0">
        </div>
      </div>

      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Verimlilik (%)</label>
          <input class="form-alan" id="verimlilik" name="verimlilik"
                 type="number" step="0.01" readonly
                 style="background:var(--kenar-a);font-weight:800;font-size:16px">
        </div>
        <div class="form-grup">
          <label class="form-et">Fire Oranı (%)</label>
          <input class="form-alan" id="fire_orani" name="fire_orani"
                 type="number" step="0.01" readonly style="background:var(--kenar-a)">
        </div>
      </div>

      <!-- Hidden -->
      <input type="hidden" name="urun_kodu" value="<?= htmlspecialchars($urun_kodu) ?>">
      <input type="hidden" name="ekleyen"   value="<?= htmlspecialchars($kul['ad_soyad'] ?? $kul['email'] ?? '') ?>">

      <div class="form-footer">
        <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle" class="btn btn-b">İptal</a>
        <button type="submit" id="submitBtn" class="btn btn-t">💾 Kaydet</button>
      </div>

    </form>
  </div>
</div>

<?php else: ?>
<!-- ════════════════════════════════════════════════════════════
     PLAN LİSTESİ  (mps_plan tablosundan — EN-% hatları)
════════════════════════════════════════════════════════════ -->

<!-- Manuel giriş kutusu -->
<div class="kart" style="margin-bottom:16px;border-left:4px solid var(--bas)">
  <div style="font-weight:800;margin-bottom:12px">
    🔧 Manuel Verim Girişi
    <span style="font-size:12px;color:var(--m2);font-weight:400"> — Günlük planda olmayan ürünler için</span>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end" class="manuel-grid">
    <div class="form-grup" style="margin:0">
      <label class="form-et">Ürün Kodu <span class="zorunlu">*</span></label>
      <input class="form-alan" id="manuelKod" type="text" placeholder="Ürün kodunu giriniz...">
    </div>
    <div class="form-grup" style="margin:0">
      <label class="form-et">Makine / Hat <span class="zorunlu">*</span></label>
      <select class="form-alan" id="manuelHat">
        <option value="">— Seçiniz —</option>
        <?php foreach ($hat_sirasi as $hat): ?>
        <option value="<?= htmlspecialchars($hat) ?>"><?= htmlspecialchars($hat) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <button onclick="manuelBaslat()" class="btn btn-t">▶ Başlat</button>
    </div>
  </div>
</div>

<?php if (empty($plan_rows)): ?>
<div class="kart" style="text-align:center;padding:48px;color:var(--m2)">
  <div style="font-size:36px;margin-bottom:8px">📋</div>
  <div style="font-weight:700">Aktif enjeksiyon planı bulunamadı.</div>
  <div style="font-size:12px;margin-top:4px">mps_plan tablosunda EN-% hattı ve aktif durum aranıyor.</div>
</div>
<?php else: ?>

<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;font-size:14px">
      🏭 Enjeksiyon Plan Listesi
      <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($plan_rows) ?> iş</span>
    </div>
    <div style="font-size:12px;color:var(--m2)">Verim girmek istediğiniz satıra tıklayın ➕</div>
  </div>
  <div style="overflow-x:auto">
    <table id="verimTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F !important">
          <th style="color:#fff !important">Verim Gir</th>
          <th style="color:#fff !important">Hat</th>
          <th style="color:#fff !important">Stok Kodu</th>
          <th style="color:#fff !important">Stok Adı</th>
          <th style="color:#fff !important">Durum</th>
          <th style="color:#fff !important;text-align:right">Kalan</th>
          <th style="color:#fff !important">ÜE No</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($plan_rows as $r):
          $bg  = $hat_renk[$r['hat_kodu']] ?? '#fff';
          $kalan = (int)($r['kalan_miktar'] ?? $r['planlanan_miktar'] ?? 0);
          $url = BASE_URL . '/panel.php?sayfa=uretim-verim-ekle'
               . '&plan_id='   . $r['id']
               . '&urun_kodu=' . urlencode($r['urun_kodu'])
               . '&istasyon='  . urlencode($r['hat_kodu'])
               . '&urun_adi='  . urlencode($r['urun_adi'] ?? '');
        ?>
        <tr style="background:<?= $bg ?>">
          <td>
            <a href="<?= $url ?>" class="btn btn-sm btn-t" title="Verim Gir"
               style="text-decoration:none">➕ Gir</a>
          </td>
          <td style="font-weight:700;white-space:nowrap"><?= htmlspecialchars($r['hat_kodu']) ?></td>
          <td>
            <code style="background:rgba(0,0,0,.05);padding:1px 6px;border-radius:3px;font-size:11px;font-weight:700">
              <?= htmlspecialchars($r['urun_kodu']) ?>
            </code>
          </td>
          <td style="min-width:160px"><?= htmlspecialchars($r['urun_adi'] ?? '') ?></td>
          <td><?= durum_roz($r['durum'] ?? '') ?></td>
          <td style="text-align:right;font-weight:700;color:<?= $kalan > 0 ? 'var(--hat)' : 'var(--bas)' ?>">
            <?= $kalan > 0 ? number_format($kalan) : '✓' ?>
          </td>
          <td style="font-size:11px;color:#0369A1"><?= htmlspecialchars($r['uretim_emri_no'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <th></th>
          <th>Hat</th><th>Stok Kodu</th><th>Stok Adı</th>
          <th>Durum</th><th>Kalan</th><th>ÜE No</th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<?php endif; ?>
<?php endif; ?>
</div><!-- /s-body -->

<!-- ── Scripts ─────────────────────────────────────────────────────────────── -->
<script>
/* Vardiya otomatik seç */
(function(){
    var s = document.getElementById('vardiyaSelect');
    if (!s) return;
    var h = new Date().getHours();
    s.value = (h >= 8 && h < 16) ? '1' : (h >= 16) ? '2' : '3';
})();

/* Verim hesaplama motoru */
(function(){
    ['goz_sayisi','cevrim_input','durus','uretim_miktari','fire_miktar'].forEach(function(id){
        var el = document.getElementById(id);
        if (el) el.addEventListener('input', hesapla);
    });
    hesapla();

    function g(id){ var e=document.getElementById(id); return e ? e.value : ''; }
    function s(id,v){ var e=document.getElementById(id); if(e) e.value=v; }

    function hesapla(){
        var uretim = parseFloat(g('uretim_miktari'))                     || 0;
        var fire   = parseFloat(g('fire_miktar'))                         || 0;
        var durus  = parseFloat(g('durus'))                               || 0;
        var cevrim = parseFloat((g('cevrim_input')||'').replace(',','.')) || 0;
        var goz    = parseFloat(g('goz_sayisi'))                          || 1;

        var net    = 480 - durus;
        s('net_calisma', net.toFixed(2));

        var teorik = cevrim > 0 ? (net * 60 / cevrim) * goz : 0;
        var verim  = teorik > 0 ? (uretim / teorik) * 100   : 0;
        var fireOr = uretim > 0 ? (fire   / uretim) * 100   : 0;

        s('verimlilik', verim.toFixed(2));
        s('fire_orani', fireOr.toFixed(2));

        var vEl = document.getElementById('verimlilik');
        if (vEl) vEl.style.color = verim>=80 ? 'var(--bas)' : verim>=50 ? 'var(--uya)' : 'var(--hat)';

        var k = document.getElementById('hedefKutu');
        if (k && teorik > 0) {
            k.style.display = 'block';
            document.getElementById('hedefDeger').textContent = Math.floor(teorik).toLocaleString('tr-TR') + ' adet';
            document.getElementById('hedefAlt').textContent   = goz + ' göz · ' + cevrim + ' sn · ' + net + ' dk net';
        }
    }
})();

/* Form AJAX gönderimi */
(function(){
    var form = document.getElementById('verimForm');
    if (!form) return;
    form.addEventListener('submit', function(e){
        e.preventDefault();

        var secilen = 0;
        form.querySelectorAll('select[name="calisan_personel[]"]').forEach(function(s){
            if (s.value.trim()) secilen++;
        });
        if (secilen === 0) { alert('En az 1 çalışan personel seçmelisiniz!'); return; }
        if (!confirm(secilen + ' personel için kayıt oluşturulacak. Devam?')) return;

        var btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.textContent = '⏳ Kaydediliyor...';

        fetch('<?= BASE_URL ?>/bolumler/uretim/ajax/verim_kaydet.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: new FormData(form)
        })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d.ok) {
                alert('✅ ' + d.msg);
                window.location.href = '<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle';
            } else {
                alert('❌ ' + d.msg);
                btn.disabled = false;
                btn.textContent = '💾 Kaydet';
            }
        })
        .catch(function(){ alert('Bağlantı hatası!'); btn.disabled=false; btn.textContent='💾 Kaydet'; });
    });
})();

/* Manuel başlatma */
function manuelBaslat(){
    var kod = (document.getElementById('manuelKod').value || '').trim();
    var hat = document.getElementById('manuelHat').value;
    if (!kod) { alert('Ürün kodu giriniz!'); document.getElementById('manuelKod').focus(); return; }
    if (!hat) { alert('Makine seçiniz!'); return; }
    window.location.href = '<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle'
        + '&plan_id=0'
        + '&urun_kodu=' + encodeURIComponent(kod)
        + '&istasyon='  + encodeURIComponent(hat);
}
</script>

<?php if (!$form_acik): ?>
<script>
$(document).ready(function(){
    var tbl = $('#verimTablo').DataTable({
        language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
        scrollY: 550, scrollX: true, scrollCollapse: true, paging: false,
        dom: 'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Verim_<?= date('Ymd') ?>'},'print'],
        initComplete: function(){
            this.api().columns([1,2,3,4]).every(function(){
                var col = this;
                var sel = $('<select class="dt-filtre-sel"><option value=""></option></select>')
                    .appendTo($(col.footer()).empty())
                    .on('change', function(){
                        var v = $.fn.dataTable.util.escapeRegex($(this).val());
                        col.search(v ? '^'+v+'$' : '', true, false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var t = $('<div/>').html(d).text();
                    sel.append('<option value="'+t+'">'+(t.length>30?t.substr(0,30)+'...':t)+'</option>');
                });
            });
        }
    });

    /* thead görünürlük fix */
    $('#verimTablo thead th').css({
        'background-color': '#1E3A5F',
        'color': '#fff'
    });
});
</script>
<?php endif; ?>
