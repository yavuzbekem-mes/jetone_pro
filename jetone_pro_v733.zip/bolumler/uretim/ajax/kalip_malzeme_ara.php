<?php
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/baglanlogo.php';
Auth::zorunlu();
header('Content-Type: application/json; charset=utf-8');
while (ob_get_level()) ob_end_clean();

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) { exit(json_encode(['ok'=>true,'data'=>[]])); }

try {
    $st = $tigerdb_pdo->prepare("
        SELECT TOP 20 CODE AS kod, NAME AS adi
        FROM dbo.LG_222_ITEMS
        WHERE (CODE LIKE ? OR NAME LIKE ?)
          AND CARDTYPE IN (1,2,3,4)
        ORDER BY CODE");
    $st->execute(["%$q%", "%$q%"]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    exit(json_encode(['ok'=>true,'data'=>$rows]));
} catch (Throwable $e) {
    exit(json_encode(['ok'=>false,'data'=>[],'msg'=>$e->getMessage()]));
}
