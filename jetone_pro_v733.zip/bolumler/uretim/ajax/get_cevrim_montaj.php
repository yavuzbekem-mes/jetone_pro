<?php
/**
 * JETONE.PRO — Montaj Ürün Çevrim Süresi AJAX
 * bolumler/uretim/ajax/get_cevrim_montaj.php
 * GET: ?kod=XXXXX
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
require_once $root . '/core/baglanlogo.php';

ini_set('display_errors', 0);
error_reporting(0);
ob_start();
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'XMLHttpRequest') {
    ob_end_clean();
    echo json_encode(['success' => false, 'mesaj' => 'Geçersiz istek']);
    exit;
}

if (!Auth::girisYapilmisMi()) {
    ob_end_clean();
    echo json_encode(['success' => false, 'mesaj' => 'Oturum sona erdi']);
    exit;
}

$kod = trim($_GET['kod'] ?? '');
if ($kod === '') {
    ob_end_clean();
    echo json_encode(['success' => false, 'mesaj' => 'Kod boş']);
    exit;
}

if (!isset($tigerdb_pdo) || $tigerdb_pdo === null) {
    ob_end_clean();
    echo json_encode(['success' => false, 'mesaj' => 'Tiger bağlantısı yok']);
    exit;
}

try {
    // Stok adı
    $stmtAd = $tigerdb_pdo->prepare(
        "SELECT TOP 1 NAME FROM dbo.LG_222_ITEMS WHERE CODE = ?"
    );
    $stmtAd->execute([$kod]);
    $stok_adi = $stmtAd->fetchColumn();

    if (!$stok_adi) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mesaj' => 'Ürün bulunamadı: ' . htmlspecialchars($kod)]);
        exit;
    }

    // Çevrim süresi — LG_INTTOTIME2 saniye olarak döner
    $stmtCv = $tigerdb_pdo->prepare("
        SELECT TOP 1 dbo.LG_INTTOTIME2(OPR.RUNTIME) AS cevrim_sn
        FROM dbo.LG_222_OPRTREQ  OPR
        LEFT JOIN dbo.LG_222_OPERTION  OP  ON OP.LOGICALREF    = OPR.OPERATIONREF
        LEFT JOIN dbo.LG_222_RTNGLINE  RTL ON RTL.OPERATIONREF = OP.LOGICALREF
        LEFT JOIN dbo.LG_222_ROUTING   RT  ON RT.LOGICALREF    = RTL.ROUTINGREF
        LEFT JOIN dbo.LG_222_BOMREVSN  BMR ON BMR.ROUTINGREF   = RT.LOGICALREF
        LEFT JOIN dbo.LG_222_BOMASTER  BOM ON BOM.LOGICALREF   = BMR.BOMMASTERREF
        LEFT JOIN dbo.LG_222_ITEMS     IT  ON IT.LOGICALREF    = BOM.MAINPRODREF
        WHERE IT.CODE = ?
          AND OPR.RUNTIME > 0
        ORDER BY OPR.RUNTIME DESC
    ");
    $stmtCv->execute([$kod]);
    $cevrim = $stmtCv->fetchColumn();

    ob_end_clean();
    echo json_encode([
        'success'  => true,
        'cevrim'   => $cevrim !== false ? (string)intval($cevrim) : '',
        'stok_adi' => (string)$stok_adi,
    ]);

} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['success' => false, 'mesaj' => 'Sorgu hatası: ' . $e->getMessage()]);
}
exit;
