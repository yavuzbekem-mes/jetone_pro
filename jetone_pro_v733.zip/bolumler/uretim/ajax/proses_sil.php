<?php
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_start(); error_reporting(0); ini_set('display_errors',0); ob_end_clean();
Auth::zorunlu();

$id    = (int)($_GET['id']    ?? 0);
$pasif = !empty($_GET['pasif']); // pasif=1 → kalıcı sil, değilse → Pasif yap

if (!$id) { header('Location: '.BASE_URL.'/panel.php?sayfa=uretim-proses-listesi'); exit; }

try {
    if ($pasif) {
        // Pasif listesinden kalıcı sil
        $db->prepare("DELETE FROM proses_formlari WHERE id=?")->execute([$id]);
    } else {
        // Aktif → Pasif yap (yumuşak silme)
        $db->prepare("UPDATE proses_formlari SET durum='Pasif' WHERE id=?")->execute([$id]);
    }
} catch(Throwable $e) {}

$geri = $pasif
    ? BASE_URL.'/panel.php?sayfa=uretim-proses-pasif'
    : BASE_URL.'/panel.php?sayfa=uretim-proses-listesi';

header('Location: '.$geri);
exit;
