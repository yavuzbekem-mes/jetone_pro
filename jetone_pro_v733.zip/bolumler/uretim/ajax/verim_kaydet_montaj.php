<?php
/**
 * JETONE.PRO — Montaj Verim Kayıt AJAX Handler
 * bolumler/uretim/ajax/verim_kaydet_montaj.php
 *
 * Aynı verimlilik tablosuna yazar (makina_kodu = hat kodu)
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

ini_set('display_errors', 0);
error_reporting(0);
ob_start();
header('Content-Type: application/json; charset=utf-8');

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'XMLHttpRequest'
) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Geçersiz istek.']);
    exit;
}

if (!Auth::girisYapilmisMi()) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Oturum sona erdi.']);
    exit;
}

try {
    /* ── Ortak alanlar ── */
    $hat     = htmlspecialchars(trim($_POST['hat']     ?? ''), ENT_QUOTES, 'UTF-8');
    $vardiya = (int)($_POST['vardiya'] ?? 0);
    $durus   = max(0.0, (float)str_replace(',', '.', $_POST['durus'] ?? '0'));
    $tarih   = trim($_POST['tarih'] ?? '');
    $ekleyen = htmlspecialchars(trim($_POST['ekleyen'] ?? ''), ENT_QUOTES, 'UTF-8');

    if (!$hat)                       throw new Exception('Hat bilgisi eksik!');
    if (!$tarih)                     throw new Exception('Tarih alanı boş!');
    if (!in_array($vardiya, [1,2,3]))throw new Exception('Geçersiz vardiya!');

    // Tarih normalize
    $tarih_obj = DateTime::createFromFormat('Y-m-d', $tarih)
              ?: DateTime::createFromFormat('d.m.Y', $tarih);
    if (!$tarih_obj) throw new Exception('Geçersiz tarih formatı!');
    $tarih_db = $tarih_obj->format('Y-m-d');

    /* ── Personel listesi ── */
    $personeller = [];
    if (isset($_POST['calisan_personel']) && is_array($_POST['calisan_personel'])) {
        foreach ($_POST['calisan_personel'] as $p) {
            $p = trim($p);
            if ($p !== '') $personeller[] = htmlspecialchars($p, ENT_QUOTES, 'UTF-8');
        }
    }
    if (empty($personeller)) throw new Exception('En az 1 çalışan personel seçmelisiniz!');

    /* ── Ürün satırları ── */
    $urunler = $_POST['urunler'] ?? [];
    if (empty($urunler)) throw new Exception('Ürün verisi bulunamadı!');

    /* ── INSERT ── */
    $kaydet = $db->prepare("
        INSERT INTO verimlilik
            (makina_kodu, stok_kodu, stok_adi, calisan_personel,
             uretim_miktari, fire_miktar, durus, net_calisma_suresi,
             verimlilik, fire_oranı, vardiya, ekleyen, tarih)
        VALUES (?,?,?,?, ?,?,?,?, ?,?,?,?,?)
    ");

    $basarili = 0;
    $hatalar  = [];

    foreach ($urunler as $idx => $urun) {
        $stok_kodu   = htmlspecialchars(trim($urun['stok_kodu']      ?? ''), ENT_QUOTES, 'UTF-8');
        $stok_adi    = htmlspecialchars(trim($urun['stok_adi']        ?? ''), ENT_QUOTES, 'UTF-8');
        $uretim      = (int)($urun['uretim_miktari']                  ?? 0);
        $fire        = (int)($urun['fire_miktar']                     ?? 0);
        $net_calisma = (float)str_replace(',','.', $urun['net_calisma_suresi'] ?? (480 - $durus));
        $verimlilik  = (float)str_replace(',','.', $urun['verimlilik']          ?? 0);
        $fire_orani  = (float)str_replace(',','.', $urun['fire_orani']           ?? 0);

        if ($stok_kodu === '') continue;
        if ($uretim <= 0) { $hatalar[] = "{$stok_kodu}: Üretim 0, atlandı."; continue; }
        if ($net_calisma <= 0) { $hatalar[] = "{$stok_kodu}: Net çalışma 0, atlandı."; continue; }

        foreach ($personeller as $personel) {
            try {
                $ok = $kaydet->execute([
                    $hat, $stok_kodu, $stok_adi, $personel,
                    $uretim, $fire, $durus, $net_calisma,
                    $verimlilik, $fire_orani, $vardiya, $ekleyen, $tarih_db,
                ]);
                $ok ? $basarili++ : $hatalar[] = "{$stok_kodu}/{$personel}: insert başarısız";
            } catch (PDOException $ex) {
                $hatalar[] = "{$stok_kodu}/{$personel}: " . $ex->getMessage();
            }
        }
    }

    ob_end_clean();
    if ($basarili > 0) {
        $msg = $basarili . ' kayıt başarıyla eklendi.';
        if ($hatalar) $msg .= ' Uyarılar: ' . implode(' | ', $hatalar);
        echo json_encode(['ok' => true, 'msg' => $msg, 'kayit_sayisi' => $basarili]);
    } else {
        echo json_encode(['ok' => false, 'msg' => 'Hiçbir kayıt yapılamadı. ' . implode(' | ', $hatalar)]);
    }

} catch (PDOException $ex) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Veritabanı hatası: ' . $ex->getMessage()]);
} catch (Exception $ex) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => $ex->getMessage()]);
}
exit;
