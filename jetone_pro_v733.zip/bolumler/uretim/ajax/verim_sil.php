<?php
/**
 * JETONE.PRO — Verim Kayıt Silme AJAX Handler
 * bolumler/uretim/ajax/verim_sil.php
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

ini_set('display_errors', 0);
error_reporting(0);
ob_start();
header('Content-Type: application/json; charset=utf-8');

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'XMLHttpRequest'
) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Geçersiz istek.']);
    exit;
}

if (!Auth::girisYapilmisMi()) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Oturum sona erdi.']);
    exit;
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Geçersiz ID.']);
    exit;
}

try {
    $db->prepare("DELETE FROM verimlilik WHERE id = ?")->execute([$id]);
    ob_end_clean();
    echo json_encode(['ok' => true, 'msg' => 'Kayıt silindi.']);
} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}
exit;
