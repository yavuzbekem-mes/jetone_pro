<?php
/**
 * AJAX: Fiş sarf detayını kaydet
 * Çağıran: kit_uret.php JS (2. adım)
 */
ob_start();
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
Auth::zorunlu();

header('Content-Type: text/plain; charset=utf-8');

$urunKodu      = trim($_POST['urunKodu']       ?? '');
$urunAdi       = trim($_POST['urunAdi']        ?? '');
$paketNo       = trim($_POST['paketNo']        ?? '');
$personel      = trim($_POST['personel']       ?? '');
$fisNo         = trim($_POST['fisNo']          ?? '');
$okutulanKodlar = json_decode($_POST['okutulanKodlar'] ?? '[]', true);
$miktarlar      = json_decode($_POST['miktarlar']      ?? '[]', true);

if (!$fisNo || empty($okutulanKodlar)) {
    ob_end_clean();
    http_response_code(400);
    echo "HATA:Eksik parametre";
    exit;
}

try {
    $ins = $db->prepare(
        "INSERT INTO fis_sarf_detay
            (PAKET_NO, ana_urun_kodu, ana_urun_adi, malzeme_kodu, malzeme_adi, okutulan_miktar, `fiş_no`)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );

    for ($i = 0; $i < count($okutulanKodlar); $i++) {
        $mKod    = $okutulanKodlar[$i] ?? '';
        $miktar  = (int)($miktarlar[$i] ?? 0);

        // Malzeme adını reçeteden çek
        $mAdi = '';
        try {
            $rs = $db->prepare("SELECT malzeme_adi FROM urun_recetesi WHERE TRIM(malzeme_kodu)=? LIMIT 1");
            $rs->execute([$mKod]);
            $mAdi = $rs->fetchColumn() ?: '';
        } catch(Throwable $e2) {}

        $ins->execute([$paketNo, $urunKodu, $urunAdi, $mKod, $mAdi, $miktar, $fisNo]);
    }

    ob_end_clean();
    echo 'OK';

} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    echo "HATA:" . $e->getMessage();
}
