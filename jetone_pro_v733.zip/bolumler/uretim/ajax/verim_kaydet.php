<?php
/**
 * JETONE.PRO — Verim Kayıt AJAX Handler
 * bolumler/uretim/ajax/verim_kaydet.php
 *
 * 3 seviye yukarı → root
 * (ajax → uretim → bolumler → root)
 */
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

ini_set('display_errors', 0);
error_reporting(0);
ob_start();
header('Content-Type: application/json; charset=utf-8');

/* Sadece AJAX + POST */
if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'XMLHttpRequest'
) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Geçersiz istek.']);
    exit;
}

if (!Auth::girisYapilmisMi()) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Oturum sona erdi.']);
    exit;
}

try {
    /* Zorunlu alan kontrolü */
    $zorunlu = [
        'istasyon_kodu'      => 'Makina No',
        'urun_kodu'          => 'Ürün Kodu',
        'uretim_miktari'     => 'Üretim Miktarı',
        'net_calisma_suresi' => 'Net Çalışma Süresi',
        'verimlilik'         => 'Verimlilik',
        'vardiya'            => 'Vardiya',
        'tarih'              => 'Tarih',
        'ekleyen'            => 'Ekleyen',
    ];
    foreach ($zorunlu as $alan => $etiket) {
        if (!isset($_POST[$alan]) || (string)$_POST[$alan] === '') {
            throw new Exception($etiket . ' alanı boş bırakılamaz!');
        }
    }

    /* Personel dizisi */
    $personeller = [];
    if (isset($_POST['calisan_personel']) && is_array($_POST['calisan_personel'])) {
        foreach ($_POST['calisan_personel'] as $p) {
            $p = trim($p);
            if ($p !== '') $personeller[] = htmlspecialchars($p, ENT_QUOTES, 'UTF-8');
        }
    }
    if (empty($personeller)) throw new Exception('En az 1 çalışan personel seçmelisiniz!');

    /* Değerleri al */
    $istasyon_kodu = htmlspecialchars(trim($_POST['istasyon_kodu']),    ENT_QUOTES, 'UTF-8');
    $urun_kodu     = htmlspecialchars(trim($_POST['urun_kodu']),        ENT_QUOTES, 'UTF-8');
    $malzeme_ad    = htmlspecialchars(trim($_POST['malzeme_ad'] ?? ''), ENT_QUOTES, 'UTF-8');
    $uretim_miktar = (int)$_POST['uretim_miktari'];
    $fire_miktar   = max(0, (int)($_POST['fire_miktar'] ?? 0));
    $durus         = max(0.0, (float)str_replace(',', '.', $_POST['durus'] ?? '0'));
    $net_calisma   = (float)str_replace(',', '.', $_POST['net_calisma_suresi']);
    $verimlilik    = (float)str_replace(',', '.', $_POST['verimlilik']);
    $fire_orani    = max(0.0, (float)str_replace(',', '.', $_POST['fire_orani'] ?? '0'));
    $vardiya       = (int)$_POST['vardiya'];
    $ekleyen       = htmlspecialchars(trim($_POST['ekleyen']), ENT_QUOTES, 'UTF-8');

    /* Tarih doğrula */
    $tarih_raw = trim($_POST['tarih']);
    $tarih_obj = DateTime::createFromFormat('Y-m-d', $tarih_raw)
              ?: DateTime::createFromFormat('d.m.Y', $tarih_raw);
    if (!$tarih_obj) throw new Exception('Geçersiz tarih: ' . htmlspecialchars($tarih_raw));
    $tarih_db = $tarih_obj->format('Y-m-d');

    /* Değer kontrolleri */
    if ($uretim_miktar <= 0) throw new Exception("Üretim miktarı 0'dan büyük olmalıdır!");
    if ($net_calisma   <= 0) throw new Exception("Net çalışma süresi 0'dan büyük olmalıdır!");
    if ($verimlilik    <= 0) throw new Exception("Verimlilik 0'dan büyük olmalıdır!");
    if (!in_array($vardiya, [1,2,3])) throw new Exception('Geçersiz vardiya!');

    /* INSERT — her personel için ayrı satır */
    $kaydet = $db->prepare("
        INSERT INTO verimlilik
            (makina_kodu, stok_kodu, stok_adi, calisan_personel,
             uretim_miktari, fire_miktar, durus, net_calisma_suresi,
             verimlilik, fire_oranı, vardiya, tarih, ekleyen)
        VALUES (?,?,?,?, ?,?,?,?, ?,?,?,?,?)
    ");

    $basarili = 0;
    $hatalar  = [];
    foreach ($personeller as $personel) {
        try {
            $kaydet->execute([
                $istasyon_kodu, $urun_kodu, $malzeme_ad, $personel,
                $uretim_miktar, $fire_miktar, $durus, $net_calisma,
                $verimlilik, $fire_orani, $vardiya, $tarih_db, $ekleyen,
            ]) ? $basarili++ : $hatalar[] = $personel . ': insert başarısız';
        } catch (PDOException $ex) {
            $hatalar[] = $personel . ': ' . $ex->getMessage();
        }
    }

    ob_end_clean();
    if ($basarili > 0) {
        $msg = $basarili . ' personel için verimlilik kaydı eklendi.';
        if ($hatalar) $msg .= ' (Hatalar: ' . implode('; ', $hatalar) . ')';
        echo json_encode(['ok' => true, 'msg' => $msg, 'kayit_sayisi' => $basarili]);
    } else {
        echo json_encode(['ok' => false, 'msg' => 'Hiçbir kayıt yapılamadı. ' . implode('; ', $hatalar)]);
    }

} catch (PDOException $ex) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => 'Veritabanı hatası: ' . $ex->getMessage()]);
} catch (Exception $ex) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'msg' => $ex->getMessage()]);
}
exit;
