<?php
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/baglanlogo.php';
ob_start(); error_reporting(0); ini_set('display_errors',0); ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$kod = strtoupper(trim($_GET['kod'] ?? ''));
if (!$kod || !$tigerdb_pdo) { echo json_encode(['stok_adi'=>'']); exit; }

try {
    $st = $tigerdb_pdo->prepare("SELECT TOP 1 DEFINITION_ FROM dbo.LG_222_ITEMS WHERE CODE=? AND CARDTYPE IN(1,2,3,4)");
    $st->execute([$kod]);
    $ad = $st->fetchColumn();
    echo json_encode(['stok_adi' => $ad ?: '']);
} catch(Throwable $e) {
    echo json_encode(['stok_adi'=>'']);
}
