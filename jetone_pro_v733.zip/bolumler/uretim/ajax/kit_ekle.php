<?php
/**
 * AJAX: Kit fişi oluştur — atomik fişNo üret
 * Çağıran: kit_uret.php JS
 */
ob_start();
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
Auth::zorunlu();

header('Content-Type: text/plain; charset=utf-8');

$urunKodu = trim($_POST['urunKodu'] ?? '');
$urunAdi  = trim($_POST['urunAdi']  ?? '');
$paketNo  = trim($_POST['paketNo']  ?? '');
$personel = trim($_POST['personel'] ?? '');
$bugun    = date('Y-m-d');

if (!$urunKodu || !$paketNo) {
    http_response_code(400);
    echo "HATA:Eksik parametre";
    exit;
}

try {
    $db->beginTransaction();

    // Son seriyi kilitle — eş zamanlı isteklerde çakışmayı önle
    $stmt = $db->query(
        "SELECT `fiş_no` FROM `giriş_fişleri` ORDER BY id DESC LIMIT 1 FOR UPDATE"
    );
    $son = $stmt->fetchColumn();

    if ($son && preg_match('/(\d{3})$/', $son, $m)) {
        $seri = (int)$m[1] + 1;
    } else {
        $seri = 1;
    }

    $fisNo = 'JTN' . date('y') . date('m') . date('d') . sprintf('%03d', $seri);

    $ins = $db->prepare(
        "INSERT INTO `giriş_fişleri` (PAKET_NO, urun_kodu, urun_adi, personel, `fiş_no`, tarih)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $ins->execute([$paketNo, $urunKodu, $urunAdi, $personel, $fisNo, $bugun]);

    $db->commit();
    ob_end_clean();
    echo $fisNo;

} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    ob_end_clean();
    http_response_code(500);
    echo "HATA:" . $e->getMessage();
}
