<?php
/**
 * Tamamlanan Kalıp Bağlama İşlemleri
 * panel.php: 'uretim-kalip-tamamlanan'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$bas = $_GET['bas'] ?? date('Y-m-01');
$bit = $_GET['bit'] ?? date('Y-m-d');

function zaman_str($bas,$bit=null){$t1=strtotime($bas);$t2=$bit?strtotime($bit):time();$f=max(0,$t2-$t1);if($f<60)return $f.'s';if($f<3600)return round($f/60).' dk';if($f<86400)return round($f/3600,1).' saat';return round($f/86400).' gün';}

try {
    $st = $db->prepare("SELECT * FROM kalip_degisim WHERE durumu='Tamamlandı' AND DATE(baslama_tarih) BETWEEN ? AND ? ORDER BY kalip_id DESC");
    $st->execute([$bas,$bit]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    $ozet = $db->prepare("SELECT COUNT(*) toplam,
        ROUND(AVG(TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih)),0) ort_dk,
        MIN(TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih)) min_dk,
        MAX(TIMESTAMPDIFF(MINUTE,baslama_tarih,bitis_tarih)) max_dk
        FROM kalip_degisim WHERE durumu='Tamamlandı' AND DATE(baslama_tarih) BETWEEN ? AND ?");
    $ozet->execute([$bas,$bit]);
    $oz = $ozet->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $rows=[]; $oz=[]; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">✅ Tamamlanan Kalıp Bağlama</h1>
    <div class="s-yol">Üretim / <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" style="color:var(--t)">Kalıp Bağlama</a> / <b>Tamamlananlar</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat"    class="btn btn-b btn-sm">📋 Plan</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-devam"     class="btn btn-b btn-sm">⏳ Devam Edenler</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-ozet"      class="btn btn-b btn-sm">📊 Özet</a>
  </div>
</div>

<div class="s-body">

<!-- Filtre -->
<div class="kart" style="margin-bottom:14px;padding:10px 14px">
  <form method="GET" action="<?= BASE_URL ?>/panel.php" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="uretim-kalip-tamamlanan">
    <div class="form-grup" style="margin:0"><label class="form-et">Başlangıç</label>
      <input class="form-alan" type="date" name="bas" value="<?= $bas ?>"></div>
    <div class="form-grup" style="margin:0"><label class="form-et">Bitiş</label>
      <input class="form-alan" type="date" name="bit" value="<?= $bit ?>"></div>
    <button type="submit" class="btn btn-t btn-sm">🔍 Filtrele</button>
  </form>
</div>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:14px">
  <?php foreach([
    ['Tamamlanan',     $oz['toplam']??0,   '#22C55E','#D1FAE5'],
    ['Ort. Süre (dk)', $oz['ort_dk']??'—', '#1E3A5F','#E0F2FE'],
    ['En Kısa (dk)',   $oz['min_dk']??'—', '#6366F1','#EDE9FE'],
    ['En Uzun (dk)',   $oz['max_dk']??'—', '#F59E0B','#FEF9C3'],
  ] as [$l,$v,$f,$b]): ?>
  <div style="background:<?= $b ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $f ?>"><?= $v ?></div>
    <div style="font-size:10px;color:<?= $f ?>;font-weight:700;text-transform:uppercase"><?= $l ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="kart" style="padding:0">
  <div style="overflow-x:auto">
    <?php $sth=['#','İşlem','Ürün Kodu','Ürün Adı','Makine','Vardiya','Başlangıç','Bitiş','Süre','Başlayan','Bitiren']; ?>
    <table id="tamTablo" class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach($sth as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tfoot><tr style="background:#1E3A5F!important">
        <?php foreach($sth as $h): ?><th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th><?php endforeach; ?>
      </tr></tfoot>
      <tbody>
      <?php foreach($rows as $i => $r): ?>
      <tr style="background:#F0FFF4">
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td>
          <a href="<?= BASE_URL ?>/islemler/uretim/kalip_sil.php?id=<?= $r['kalip_id'] ?>"
             onclick="return confirm('Silinsin mi?')"
             class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px;text-decoration:none">🗑</a>
        </td>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['urun_kodu']??'') ?></td>
        <td style="font-size:12px;max-width:200px"><?= htmlspecialchars($r['urun_adi']??'') ?></td>
        <td style="font-family:monospace;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['is_istasyonu']??'') ?></td>
        <td style="text-align:center"><?= $r['vardiya']??'-' ?>. Var.</td>
        <td style="white-space:nowrap;font-size:11px"><?= $r['baslama_tarih']?date('d.m.Y H:i',strtotime($r['baslama_tarih'])):'—' ?></td>
        <td style="white-space:nowrap;font-size:11px"><?= $r['bitis_tarih']?date('d.m.Y H:i',strtotime($r['bitis_tarih'])):'—' ?></td>
        <td style="font-weight:700;color:#22C55E"><?= $r['bitis_tarih']?zaman_str($r['baslama_tarih'],$r['bitis_tarih']):'—' ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['ekleyen']??'') ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['tamamlayan']??'') ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
$(document).ready(function(){
  $('#tamTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true,scrollY:500,scrollCollapse:true,paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'KalipTamamlanan_<?= date("Ymd") ?>'}],
    drawCallback:function(){ $('#tamTablo thead th,#tamTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){ this.api().columns([4]).every(function(){ var col=this,sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); }); col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); }); }); $('#tamTablo thead th,#tamTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); }
  });
});
</script>
