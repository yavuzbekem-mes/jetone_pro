<?php
/**
 * Tiger vs Jetone Reçete Fark Karşılaştırma
 * panel.php: 'uretim-kit-recete-fark' => 'bolumler/uretim/kit_recete_fark.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$f_urun   = trim($_GET['urun'] ?? '');
$f_sadece = trim($_GET['sadece'] ?? '');  // 'fark' = sadece farklı, '' = hepsi

// Tiger reçetesi çek
$tiger_map = [];
$tiger_hata = '';
if ($tigerdb_pdo) {
    try {
        // Önce Jetone'daki ana ürün kodlarını al
        $jetone_kodlar = $db->query(
            "SELECT DISTINCT TRIM(ana_urun_kodu) FROM urun_recetesi WHERE ana_urun_kodu IS NOT NULL AND ana_urun_kodu <> ''"
        )->fetchAll(PDO::FETCH_COLUMN, 0);

        if (empty($jetone_kodlar)) {
            $tiger_map = [];
        } else {
            // IN listesi oluştur - parametreli sorgu
            $placeholders = implode(',', array_fill(0, count($jetone_kodlar), '?'));
            $tiger_sql = "SELECT
                BOM.CODE  AS recete_kodu,
                ISNULL(BOM.NAME,'') AS recete_adi,
                IT2.CODE  AS girdi_kodu,
                ISNULL(IT2.NAME,'') AS girdi_adi,
                CAST(
                    CASE WHEN BML.AMOUNT = FLOOR(BML.AMOUNT)
                         THEN CAST(CAST(BML.AMOUNT AS BIGINT) AS NVARCHAR(50))
                         ELSE CAST(CAST(BML.AMOUNT AS DECIMAL(18,5)) AS NVARCHAR(50))
                    END
                AS NVARCHAR(50)) AS miktar
            FROM dbo.LG_222_BOMLINE AS BML
            LEFT JOIN dbo.LG_222_BOMREVSN AS BMR ON BML.BOMREVREF    = BMR.LOGICALREF
            LEFT JOIN dbo.LG_222_BOMASTER AS BOM ON BMR.BOMMASTERREF = BOM.LOGICALREF
            LEFT JOIN dbo.LG_222_ITEMS    AS IT2 ON BML.ITEMREF      = IT2.LOGICALREF
            WHERE BOM.CODE IS NOT NULL AND IT2.CODE IS NOT NULL
              AND BML.AMOUNT IS NOT NULL AND BML.AMOUNT >= 0
              AND BOM.CODE IN ($placeholders)";
            $ts = $tigerdb_pdo->prepare($tiger_sql);
            $ts->execute($jetone_kodlar);
        foreach ($ts->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $tiger_map[trim($r['recete_kodu']) . '|' . trim($r['girdi_kodu'])] = [
                'miktar'     => $r['miktar'],
                'recete_adi' => $r['recete_adi'] ?? '',
                'girdi_adi'  => $r['girdi_adi']  ?? '',
            ];




        }
        } // end if empty
    } catch(Throwable $e) { $tiger_hata = $e->getMessage(); }
}

// Jetone reçetesi çek
$jetone = [];
$jetone_hata = '';
try {
    $where  = $f_urun ? "WHERE TRIM(ana_urun_kodu) LIKE ?" : "";
    $params = $f_urun ? ["%$f_urun%"] : [];
    $st = $db->prepare("SELECT * FROM urun_recetesi $where ORDER BY ana_urun_kodu, bom_id");
    $st->execute($params);
    $jetone = $st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) { $jetone_hata = $e->getMessage(); }

// Jetone'dan ad lookup map oluştur
// ana_urun_kodu → ana_urun_adi (ilk bulunan)
// malzeme_kodu  → malzeme_adi  (ilk bulunan)
$jetone_urun_adi  = []; // ana_urun_kodu => ana_urun_adi
$jetone_malz_adi  = []; // malzeme_kodu  => malzeme_adi
try {
    $all = $db->query("SELECT DISTINCT TRIM(ana_urun_kodu) as ak, TRIM(ana_urun_adi) as aa,
                              TRIM(malzeme_kodu) as mk, TRIM(malzeme_adi) as ma
                       FROM urun_recetesi WHERE ana_urun_kodu IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($all as $ar) {
        if ($ar['ak'] && $ar['aa'] && !isset($jetone_urun_adi[$ar['ak']])) {
            $jetone_urun_adi[$ar['ak']] = $ar['aa'];
        }
        if ($ar['mk'] && $ar['ma'] && !isset($jetone_malz_adi[$ar['mk']])) {
            $jetone_malz_adi[$ar['mk']] = $ar['ma'];
        }
    }
} catch(Throwable $e) {}

// Karşılaştır
$satirlar  = [];
$fark_say  = 0;
$esles_say = 0;
$sadece_jetone_say = 0;

foreach ($jetone as $row) {
    $ak  = trim($row['ana_urun_kodu']);
    $mk  = trim($row['malzeme_kodu']);
    $key = $ak . '|' . $mk;

    $tiger_entry = $tiger_map[$key] ?? null;
    $tiger_m     = $tiger_entry ? $tiger_entry['miktar'] : null;
    $tiger_girdi_adi  = $tiger_entry ? trim($tiger_entry['girdi_adi']  ?? '') : '';
    $tiger_recete_adi = $tiger_entry ? trim($tiger_entry['recete_adi'] ?? '') : '';
    $jetone_m = trim($row['miktar'] ?? '');

    // Adları Jetone'dan al, yoksa lookup map'ten tamamla
    $malzeme_adi_goster = trim($row['malzeme_adi'] ?? '')
        ?: ($jetone_malz_adi[$mk] ?? '')
        ?: $tiger_girdi_adi;
    $ana_adi_goster = trim($row['ana_urun_adi'] ?? '')
        ?: ($jetone_urun_adi[$ak] ?? '')
        ?: $tiger_recete_adi;

    if ($tiger_m === null) {
        $durum = 'sadece_jetone';
        $sadece_jetone_say++;
    } else {
        $t_float = (float)str_replace(',', '.', $tiger_m);
        $j_float = (float)str_replace(',', '.', $jetone_m);
        if (abs($t_float - $j_float) > 0.0001) {
            $durum = 'fark';
            $fark_say++;
        } else {
            $durum = 'esles';
            $esles_say++;
        }
        unset($tiger_map[$key]);
    }

    $satirlar[] = [
        'durum'        => $durum,
        'ana_urun_kodu'=> $ak,
        'ana_urun_adi' => $ana_adi_goster,
        'malzeme_kodu' => $mk,
        'malzeme_adi'  => $malzeme_adi_goster,
        'jetone_miktar'=> $jetone_m,
        'tiger_miktar' => $tiger_m ?? '-',
        'bom_id'       => $row['bom_id'],
    ];
}

// Tiger'da olup Jetone'da olmayan
$sadece_tiger_say = 0;
foreach ($tiger_map as $key => $tiger_entry2) {
    [$ak, $mk] = explode('|', $key, 2);
    if ($f_urun && stripos($ak, $f_urun) === false) continue;
    $tm = is_array($tiger_entry2) ? $tiger_entry2['miktar'] : $tiger_entry2;
    $t_adi_ana = ($jetone_urun_adi[$ak] ?? '') ?: (is_array($tiger_entry2) ? ($tiger_entry2['recete_adi']??'') : '');
    $t_adi_mlz = ($jetone_malz_adi[$mk] ?? '') ?: (is_array($tiger_entry2) ? ($tiger_entry2['girdi_adi'] ??'') : '');
    $satirlar[] = [
        'durum'         => 'sadece_tiger',
        'ana_urun_kodu' => $ak,
        'ana_urun_adi'  => $t_adi_ana,
        'malzeme_kodu'  => $mk,
        'malzeme_adi'   => $t_adi_mlz,
        'jetone_miktar' => '-',
        'tiger_miktar'  => $tm,
        'bom_id'        => '',
    ];
    $sadece_tiger_say++;
}

// Sırala: ana_urun_kodu → malzeme_kodu
usort($satirlar, fn($a,$b) => [$a['ana_urun_kodu'],$a['malzeme_kodu']] <=> [$b['ana_urun_kodu'],$b['malzeme_kodu']]);

// Filtrele
if ($f_sadece === 'fark') {
    $satirlar = array_filter($satirlar, fn($s) => in_array($s['durum'], ['fark','sadece_tiger','sadece_jetone']));
} elseif ($f_sadece === 'esles') {
    $satirlar = array_filter($satirlar, fn($s) => $s['durum'] === 'esles');
}

$durum_stil = [
    'fark'          => ['#FEF2F2','#DC2626','⚠️ Miktar Farklı'],
    'esles'         => ['#F0FDF4','#16A34A','✅ Eşleşiyor'],
    'sadece_jetone' => ['#FFFBEB','#D97706','📋 Sadece Jetone'],
    'sadece_tiger'  => ['#EFF6FF','#2563EB','🔷 Sadece Tiger'],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔄 Tiger vs Jetone Reçete Karşılaştırma</h1>
    <div class="s-yol">Üretim / Kit Üretim / <b>Reçete Fark</b></div>
  </div>
</div>

<div class="s-body">

<?php if($tiger_hata): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">⚠️ Tiger bağlantı hatası: <?=htmlspecialchars($tiger_hata)?></div>
<?php endif; ?>
<?php if($jetone_hata): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">⚠️ Jetone DB hatası: <?=htmlspecialchars($jetone_hata)?></div>
<?php endif; ?>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px" class="ozet-grid">
  <?php foreach([
    ['⚠️','Miktar Farklı',    $fark_say,          '#DC2626','#FEF2F2'],
    ['✅','Eşleşiyor',        $esles_say,          '#16A34A','#F0FDF4'],
    ['📋','Sadece Jetone',    $sadece_jetone_say,  '#D97706','#FFFBEB'],
    ['🔷','Sadece Tiger',     $sadece_tiger_say,   '#2563EB','#EFF6FF'],
  ] as $k): ?>
  <div class="kart" style="padding:14px;border-left:4px solid <?=$k[3]?>;background:<?=$k[4]?>;text-align:center">
    <div style="font-size:24px;font-weight:900;color:<?=$k[3]?>"><?=$k[2]?></div>
    <div style="font-size:11px;font-weight:700;color:<?=$k[3]?>"><?=$k[0]?> <?=$k[1]?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Filtre -->
<form method="GET" action="<?=BASE_URL?>/panel.php" style="margin-bottom:14px">
  <input type="hidden" name="sayfa" value="uretim-kit-recete-fark">
  <div class="kart" style="padding:14px">
    <div style="display:grid;grid-template-columns:2fr 1fr auto;gap:10px;align-items:end" class="flt-grid">
      <div>
        <label class="form-et">Ürün Kodu Filtrele</label>
        <input name="urun" class="form-alan" value="<?=htmlspecialchars($f_urun)?>" placeholder="Ürün kodu veya adı...">
      </div>
      <div>
        <label class="form-et">Göster</label>
        <select name="sadece" class="form-alan">
          <option value=""    <?=$f_sadece===''     ?'selected':''?>>Tümü</option>
          <option value="fark"<?=$f_sadece==='fark' ?'selected':''?>>Sadece Farklılar</option>
          <option value="esles"<?=$f_sadece==='esles'?'selected':''?>>Sadece Eşleşenler</option>
        </select>
      </div>
      <div style="display:flex;gap:6px">
        <button type="submit" class="btn btn-t">🔍 Ara</button>
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-recete-fark" class="btn btn-b">↺</a>
      </div>
    </div>
  </div>
</form>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:10px 16px;background:var(--kenar-a);border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px">
    📊 Karşılaştırma (<?=count($satirlar)?> satır)
  </div>
  <?php if(empty($satirlar)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Gösterilecek satır yok.</div>
  <?php else: ?>
  <div style="overflow:auto;max-height:640px">
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E3A5F;color:#fff">
        <th style="padding:8px 10px;text-align:left;white-space:nowrap">#</th>
        <th style="padding:8px 10px;text-align:left;white-space:nowrap">Durum</th>
        <th style="padding:8px 10px;text-align:left;white-space:nowrap">Ana Ürün Kodu</th>
        <th style="padding:8px 10px;text-align:left">Ana Ürün Adı</th>
        <th style="padding:8px 10px;text-align:left;white-space:nowrap">Malzeme Kodu</th>
        <th style="padding:8px 10px;text-align:left">Malzeme Adı</th>
        <th style="padding:8px 10px;text-align:right;white-space:nowrap">Jetone Miktar</th>
        <th style="padding:8px 10px;text-align:right;white-space:nowrap">Tiger Miktar</th>
      </tr>
    </thead>
    <tbody>
    <?php $no=0; foreach($satirlar as $s):
      $no++;
      $stil = $durum_stil[$s['durum']] ?? ['#fff','#000','?'];
      $bg   = $stil[0];
      $renk = $stil[1];
      $lbl  = $stil[2];
      $fark_vurgu = $s['durum']==='fark';
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:6px 10px;color:var(--m3)"><?=$no?></td>
      <td style="padding:6px 10px">
        <span style="font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;
                     background:<?=$renk?>22;color:<?=$renk?>"><?=$lbl?></span>
      </td>
      <td style="padding:6px 10px;font-family:monospace;font-weight:700"><?=htmlspecialchars($s['ana_urun_kodu'])?></td>
      <td style="padding:6px 10px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
          title="<?=htmlspecialchars($s['ana_urun_adi'])?>"><?=htmlspecialchars($s['ana_urun_adi'])?></td>
      <td style="padding:6px 10px;font-family:monospace"><?=htmlspecialchars($s['malzeme_kodu'])?></td>
      <td style="padding:6px 10px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
          title="<?=htmlspecialchars($s['malzeme_adi'])?>"><?=htmlspecialchars($s['malzeme_adi'])?></td>
      <td style="padding:6px 10px;text-align:right;font-weight:700;
                 color:<?=$fark_vurgu?'#DC2626':'inherit'?>"><?=htmlspecialchars($s['jetone_miktar'])?></td>
      <td style="padding:6px 10px;text-align:right;font-weight:700;
                 color:<?=$fark_vurgu?'#2563EB':'inherit'?>"><?=htmlspecialchars($s['tiger_miktar'])?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

</div><!-- /s-body -->
<style>
@media(max-width:600px){.ozet-grid{grid-template-columns:1fr 1fr!important}.flt-grid{grid-template-columns:1fr!important}}
</style>
