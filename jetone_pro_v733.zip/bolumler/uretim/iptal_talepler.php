<?php
if(!defined('ROOT_DIR')) require_once dirname(__DIR__,2).'/core/config.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

$f_durum = trim($_GET['durum'] ?? '');
$f_basl  = trim($_GET['basl']  ?? date('Y-m-01'));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));
$f_emri  = trim($_GET['emri']  ?? '');

$talepler = []; $ozet = ['toplam'=>0,'bekliyor'=>0,'onaylandi'=>0,'reddedildi'=>0];

if(isset($db)) {
    try {
        $w = ["DATE(talep_tarihi) BETWEEN ? AND ?"];
        $p = [$f_basl,$f_bitis];
        if($f_durum) { $w[]="durum=?"; $p[]=$f_durum; }
        if($f_emri)  { $w[]="uretim_emri_no LIKE ?"; $p[]="%$f_emri%"; }
        $ws = implode(' AND ',$w);
        $st = $db->prepare("SELECT * FROM iptal_talepler WHERE $ws ORDER BY id DESC");
        $st->execute($p); $talepler = $st->fetchAll(PDO::FETCH_ASSOC);
        $ozet_1k = 0; $ozet_2k = 0;
        $ozet_silinen = 0; // onaylananlar = MES'ten silinen
        $gunluk = []; $emri_ozet = [];
        foreach($talepler as $t) {
            $ozet['toplam']++;
            $key = strtolower($t['durum']=='ONAYLANDI'?'onaylandi':($t['durum']=='REDDEDILDI'?'reddedildi':'bekliyor'));
            $ozet[$key]++;
            if($t['kayit_tipi']==='1K') $ozet_1k++;
            if($t['kayit_tipi']==='2K') $ozet_2k++;
            if($t['durum']==='ONAYLANDI') $ozet_silinen++;
            $gun = substr($t['talep_tarihi']??'',0,10);
            if(!isset($gunluk[$gun])) $gunluk[$gun]=0;
            $gunluk[$gun]++;
            $emri = $t['uretim_emri_no']??'';
            if($emri){ if(!isset($emri_ozet[$emri])) $emri_ozet[$emri]=0; $emri_ozet[$emri]++; }
        }
        ksort($gunluk); arsort($emri_ozet);
        $emri_ozet = array_slice($emri_ozet,0,5,true);
    } catch(Throwable $e){ error_log("[IPTAL_TALEPLER] ".$e->getMessage()); }
}

// Log sayfası
$aktif_tab = $_GET['tab'] ?? 'talepler';
$loglar = [];
if($aktif_tab==='log' && isset($db)){
    try {
        $ls=$db->query("SELECT l.*,t.uretim_emri_no,t.stok_kodu,t.kayit_tipi,
                               t.paket_no, t.logo_fis_no
                        FROM iptal_log l LEFT JOIN iptal_talepler t ON t.id=l.talep_id
                        ORDER BY l.id DESC LIMIT 200");
        $loglar=$ls->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){}
}

$dur_badge=['BEKLIYOR'=>['#FEF3C7','#92400E','⏳'],'ONAYLANDI'=>['#D1FAE5','#065F46','✅'],'REDDEDILDI'=>['#FEE2E2','#7F1D1D','❌']];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🚫 İptal Talepleri</h1>
    <div class="s-yol">Üretim / <b>İptal Talepleri</b></div>
  </div>
</div>

<div class="s-body">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
.it-kart{background:var(--yuzey);border-radius:var(--r-xl);box-shadow:var(--shadow);margin-bottom:16px}
.it-tablo{width:100%;border-collapse:collapse;font-size:13px}
.it-tablo th{padding:10px 14px;font-weight:700;color:var(--m2);background:var(--kenar-a);border-bottom:2px solid var(--kenar);text-align:left;white-space:nowrap}
.it-tablo td{padding:9px 14px;border-bottom:1px solid var(--kenar);vertical-align:middle}
.it-tablo tbody tr:hover{background:var(--kenar-a)}
.oz-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.oz-kart{background:var(--yuzey);border-radius:var(--r);padding:16px;text-align:center;box-shadow:var(--shadow);border-top:4px solid}
@media(max-width:700px){.oz-grid{grid-template-columns:1fr 1fr}}
</style>

<!-- Tab -->
<div style="display:flex;border-bottom:2px solid var(--kenar);margin-bottom:16px">
  <a href="?sayfa=uretim-iptal-talepler&tab=talepler&basl=<?=$f_basl?>&bitis=<?=$f_bitis?>"
     style="padding:12px 24px;font-weight:800;font-size:13px;text-decoration:none;color:<?=$aktif_tab==='talepler'?'var(--t)':'var(--m3)'?>;border-bottom:3px solid <?=$aktif_tab==='talepler'?'var(--t)':'transparent'?>;margin-bottom:-2px">
    📋 Talepler
  </a>
  <a href="?sayfa=uretim-iptal-talepler&tab=log"
     style="padding:12px 24px;font-weight:800;font-size:13px;text-decoration:none;color:<?=$aktif_tab==='log'?'var(--t)':'var(--m3)'?>;border-bottom:3px solid <?=$aktif_tab==='log'?'var(--t)':'transparent'?>;margin-bottom:-2px">
    📜 İşlem Logu
  </a>
</div>

<?php if($aktif_tab==='talepler'): ?>

<!-- Özet Kartlar — Satır 1 -->
<div class="oz-grid" style="margin-bottom:12px">
  <div class="oz-kart" style="border-color:#6B7280">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Toplam Talep</div>
    <div style="font-size:32px;font-weight:900;color:#6B7280"><?=$ozet['toplam']?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">seçilen dönemde</div>
  </div>
  <div class="oz-kart" style="border-color:#F59E0B">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Bekliyor</div>
    <div style="font-size:32px;font-weight:900;color:#F59E0B"><?=$ozet['bekliyor']?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">işlem bekliyor</div>
  </div>
  <div class="oz-kart" style="border-color:#16A34A">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Onaylandı</div>
    <div style="font-size:32px;font-weight:900;color:#16A34A"><?=$ozet['onaylandi']?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">kayıt silindi</div>
  </div>
  <div class="oz-kart" style="border-color:#DC2626">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Reddedildi</div>
    <div style="font-size:32px;font-weight:900;color:#DC2626"><?=$ozet['reddedildi']?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">talep reddedildi</div>
  </div>
</div>

<!-- Özet Kartlar — Satır 2 -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
  <div class="oz-kart" style="border-color:#3B82F6">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">1. Kalite İptal</div>
    <div style="font-size:28px;font-weight:900;color:#3B82F6"><?=$ozet_1k?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">
      <?=$ozet['toplam']>0?round($ozet_1k/$ozet['toplam']*100).'%':'-'?> oran
    </div>
  </div>
  <div class="oz-kart" style="border-color:#8B5CF6">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">2. Kalite İptal</div>
    <div style="font-size:28px;font-weight:900;color:#8B5CF6"><?=$ozet_2k?></div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px">
      <?=$ozet['toplam']>0?round($ozet_2k/$ozet['toplam']*100).'%':'-'?> oran
    </div>
  </div>
  <div class="oz-kart" style="border-color:#EA580C">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Onay Oranı</div>
    <div style="font-size:28px;font-weight:900;color:#EA580C">
      <?=$ozet['toplam']>0?round($ozet_silinen/$ozet['toplam']*100).'%':'-%'?>
    </div>
    <div style="font-size:11px;color:var(--m3);margin-top:4px"><?=$ozet_silinen?> onay / <?=$ozet['toplam']?> talep</div>
  </div>
</div>

<?php if(!empty($talepler)): ?>
<!-- Grafikler + Tablolar -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
  <!-- Günlük talep grafiği -->
  <div class="it-kart" style="padding:18px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px">📅 Günlük Talep Sayısı</div>
    <canvas id="it-chart-gunluk" height="90"></canvas>
  </div>
  <!-- En çok talep üretim emirleri -->
  <div class="it-kart" style="padding:0;overflow:hidden">
    <div style="padding:14px 18px;border-bottom:1px solid var(--kenar)">
      <span style="font-weight:800;font-size:13px">📋 En Çok Talep Gelen Emirler</span>
    </div>
    <div style="overflow-y:auto;max-height:220px">
      <table style="width:100%;border-collapse:collapse;font-size:13px">
        <thead style="position:sticky;top:0;background:var(--kenar-a)">
          <tr>
            <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Üretim Emri</th>
            <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:right">Talep</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($emri_ozet as $emri=>$sayi): ?>
        <tr style="border-bottom:1px solid var(--kenar)">
          <td style="padding:8px 14px">
            <a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($emri)?>"
               style="font-weight:700;color:var(--t);text-decoration:none;font-size:12px"><?=htmlspecialchars($emri)?></a>
          </td>
          <td style="padding:8px 14px;text-align:right;font-weight:700;color:#DC2626"><?=$sayi?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Filtre -->
<div class="it-kart" style="padding:14px 18px;margin-bottom:16px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="uretim-iptal-talepler">
    <input type="hidden" name="tab"   value="talepler">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="form-et" style="font-size:11px">Başlangıç</label>
           <input type="date" name="basl" class="form-alan" value="<?=$f_basl?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Bitiş</label>
           <input type="date" name="bitis" class="form-alan" value="<?=$f_bitis?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Üretim Emri</label>
           <input type="text" name="emri" class="form-alan" value="<?=$f_emri?>" placeholder="UE-..." style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Durum</label>
           <select name="durum" class="form-alan" style="width:150px">
             <option value="">Tümü</option>
             <option value="BEKLIYOR"    <?=$f_durum==='BEKLIYOR'?'selected':''?>>⏳ Bekliyor</option>
             <option value="ONAYLANDI"   <?=$f_durum==='ONAYLANDI'?'selected':''?>>✅ Onaylandı</option>
             <option value="REDDEDILDI"  <?=$f_durum==='REDDEDILDI'?'selected':''?>>❌ Reddedildi</option>
           </select></div>
      <button type="submit" class="btn btn-t" style="padding:10px 20px">🔍 Filtrele</button>
      <a href="?sayfa=uretim-iptal-talepler" class="btn" style="padding:10px 16px;background:var(--kenar-a);color:var(--m2)">↺</a>
    </div>
  </form>
</div>

<!-- Tablo -->
<div class="it-kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <span style="font-weight:800;font-size:14px">🚫 İptal Talepleri</span>
    <span style="font-size:12px;color:var(--m3)"><?=count($talepler)?> kayıt</span>
  </div>
  <?php if(empty($talepler)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Seçilen kriterlerde talep bulunamadı.</div>
  <?php else: ?>
  <div style="overflow:auto">
  <table class="it-tablo">
    <thead><tr>
      <th>Talep No</th><th>Tür</th><th>Üretim Emri</th>
      <th>Stok Kodu</th><th>Paket No</th>
      <th style="text-align:right">Miktar</th>
      <th>Logo Fiş No</th><th>İptal Nedeni</th><th>Talep Eden</th><th>Tarih</th>
      <th>Durum</th><th style="text-align:center">İşlem</th>
    </tr></thead>
    <tbody>
    <?php foreach($talepler as $t):
      $dur = $t['durum']??'BEKLIYOR';
      [$bg,$fg,$ico] = $dur_badge[$dur] ?? ['#E5E7EB','#374151','?'];
      $tj = json_encode(['id'=>(int)$t['id'],'talep_no'=>$t['talep_no'],'durum'=>$dur],JSON_HEX_APOS|JSON_HEX_QUOT);
    ?>
    <tr>
      <td style="font-family:monospace;font-size:11px;font-weight:700"><?=htmlspecialchars($t['talep_no'])?></td>
      <td><span style="background:<?=$t['kayit_tipi']==='2K'?'#FEE2E2':'#DBEAFE'?>;color:<?=$t['kayit_tipi']==='2K'?'#7F1D1D':'#1E40AF'?>;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:700"><?=$t['kayit_tipi']?></span></td>
      <td><a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($t['uretim_emri_no'])?>"
             style="font-weight:700;color:var(--t);text-decoration:none;font-size:12px"><?=htmlspecialchars($t['uretim_emri_no'])?></a></td>
      <td style="font-size:11px;font-weight:600"><?=htmlspecialchars($t['stok_kodu']??'')?></td>
      <td style="font-family:monospace;font-size:11px"><?=htmlspecialchars($t['paket_no']??'')?></td>
      <td style="text-align:right;font-weight:700;color:#DC2626"><?=number_format((float)$t['miktar'])?></td>
      <td style="font-size:11px;font-family:monospace;color:var(--m2)"><?=htmlspecialchars($t['logo_fis_no']??'')?></td>
      <td style="font-size:11px;max-width:200px;color:var(--m2)"><?=htmlspecialchars($t['iptal_nedeni']??'')?></td>
      <td style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($t['talep_eden']??'')?></td>
      <td style="font-size:11px;color:var(--m3)"><?=htmlspecialchars(substr($t['talep_tarihi']??'',0,16))?></td>
      <td><span style="background:<?=$bg?>;color:<?=$fg?>;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700"><?=$ico?> <?=$dur?></span></td>
      <td style="text-align:center;white-space:nowrap">
        <?php if($dur==='BEKLIYOR'): ?>
        <button class="btn" style="padding:4px 8px;font-size:11px;background:#D1FAE5;color:#065F46;margin-right:3px"
                onclick='talepIslem(<?=(int)$t["id"]?>,"ONAYLA","<?=htmlspecialchars($t["talep_no"])?>")'> ✅ Onayla</button>
        <button class="btn" style="padding:4px 8px;font-size:11px;background:#FEE2E2;color:#7F1D1D"
                onclick='talepIslem(<?=(int)$t["id"]?>,"REDDET","<?=htmlspecialchars($t["talep_no"])?>")'> ❌ Reddet</button>
        <?php elseif(!empty($t['islem_yapan'])): ?>
        <span style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($t['islem_yapan'])?><br><?=htmlspecialchars(substr($t['islem_tarihi']??'',0,16))?></span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

<?php else: /* LOG TAB */ ?>

<div class="it-kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar)">
    <span style="font-weight:800;font-size:14px">📜 İptal İşlem Logu</span>
    <span style="font-size:12px;color:var(--m3);margin-left:10px">Son 200 kayıt</span>
  </div>
  <?php if(empty($loglar)): ?>
  <div style="padding:30px;text-align:center;color:var(--m3)">Log kaydı bulunamadı.</div>
  <?php else: ?>
  <div style="overflow:auto">
  <table class="it-tablo">
    <thead><tr>
      <th>#</th><th>Tarih</th><th>İşlem</th><th>Kullanıcı</th>
      <th>Üretim Emri</th><th>Paket No</th><th>Logo Fiş No</th><th>Stok Kodu</th><th>Tür</th><th>Detay</th>
    </tr></thead>
    <tbody>
    <?php
    $log_renk=['TALEP_OLUSTUR'=>['#DBEAFE','#1E40AF'],'ONAYLA'=>['#D1FAE5','#065F46'],
               'REDDET'=>['#FEE2E2','#7F1D1D'],'MES_SILINDI'=>['#FEF3C7','#92400E']];
    foreach($loglar as $i=>$l):
      [$lb,$lc]=$log_renk[$l['islem']??''] ?? ['#F3F4F6','#374151'];
    ?>
    <tr>
      <td style="color:var(--m3);font-size:12px"><?=$i+1?></td>
      <td style="font-size:12px;color:var(--m2)"><?=htmlspecialchars(substr($l['tarih']??'',0,16))?></td>
      <td><span style="background:<?=$lb?>;color:<?=$lc?>;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700"><?=htmlspecialchars($l['islem']??'')?></span></td>
      <td style="font-size:12px;font-weight:600"><?=htmlspecialchars($l['kullanici']??'')?></td>
      <td style="font-size:12px"><?=htmlspecialchars($l['uretim_emri_no']??'')?></td>
      <td style="font-size:11px;font-family:monospace"><?=htmlspecialchars($l['paket_no']??'')?></td>
      <td style="font-size:11px;font-family:monospace;color:var(--m2)"><?=htmlspecialchars($l['logo_fis_no']??'')?></td>
      <td style="font-size:11px"><?=htmlspecialchars($l['stok_kodu']??'')?></td>
      <td><span style="font-size:11px;font-weight:700"><?=htmlspecialchars($l['kayit_tipi']??'')?></span></td>
      <td style="font-size:11px;color:var(--m3);max-width:300px"><?=htmlspecialchars($l['detay']??'')?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

<?php endif; ?>

<!-- Onay/Red Modalı -->
<div id="talep-islem-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:460px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
      <span id="ti-baslik" style="font-size:15px;font-weight:800"></span>
      <button onclick="document.getElementById('talep-islem-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:24px">
      <form id="talepIslemForm">
        <input type="hidden" name="id"    id="ti-id">
        <input type="hidden" name="islem" id="ti-islem">
        <p id="ti-aciklama" style="font-size:13px;color:var(--m2);margin-bottom:16px"></p>
        <div style="margin-bottom:16px">
          <label class="form-et">Not <span style="color:var(--m3);font-size:11px">(opsiyonel)</span></label>
          <textarea name="not" id="ti-not" class="form-alan" rows="2" placeholder="İşlem notu..."></textarea>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('talep-islem-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">Vazgeç</button>
          <button type="submit" id="ti-submit-btn" class="btn" style="padding:10px 24px;font-weight:800">Onayla</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
var BASE_IT = '<?=BASE_URL?>';

// Grafik verileri
<?php if(!empty($gunluk)): ?>
var IT_GUNLUK_LABELS = <?=json_encode(array_keys($gunluk))?>;
var IT_GUNLUK_DATA   = <?=json_encode(array_values($gunluk))?>;

document.addEventListener('DOMContentLoaded', function(){
    var el = document.getElementById('it-chart-gunluk');
    if(!el) return;
    new Chart(el, {
        type:'bar',
        data:{
            labels: IT_GUNLUK_LABELS,
            datasets:[{
                label:'Talep Sayısı',
                data: IT_GUNLUK_DATA,
                backgroundColor: function(ctx){
                    var renk = ['rgba(245,158,11,0.7)','rgba(220,38,38,0.7)','rgba(22,163,74,0.7)'];
                    return 'rgba(107,114,128,0.7)';
                },
                borderColor:'#6B7280', borderWidth:1, borderRadius:4
            }]
        },
        options:{
            responsive:true,
            plugins:{legend:{display:false}},
            scales:{
                y:{ticks:{precision:0},title:{display:true,text:'Talep'}},
                x:{ticks:{font:{size:10}}}
            }
        }
    });
});
<?php endif; ?>

function talepIslem(id, islem, talep_no) {
    document.getElementById('ti-id').value    = id;
    document.getElementById('ti-islem').value = islem;
    document.getElementById('ti-not').value   = '';
    var onayla = islem === 'ONAYLA';
    document.getElementById('ti-baslik').textContent = onayla ? '✅ Talebi Onayla' : '❌ Talebi Reddet';
    document.getElementById('ti-aciklama').textContent =
        (onayla ? 'Bu talebi onaylarsanız ilgili MES kaydı kalıcı olarak silinecek.' :
                  'Bu talebi reddedeceksiniz. Kayıt silinmeyecek.') + ' Talep: ' + talep_no;
    var btn = document.getElementById('ti-submit-btn');
    btn.textContent = onayla ? '✅ Onayla' : '❌ Reddet';
    btn.style.background = onayla ? '#16A34A' : '#DC2626';
    btn.style.color = '#fff';
    document.getElementById('talep-islem-modal').style.display = 'flex';
}

document.getElementById('talepIslemForm').addEventListener('submit', function(e){
    e.preventDefault();
    Swal.fire({title:'İşlem yapılıyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
    var fd=new FormData(this),obj={};
    fd.forEach(function(v,k){obj[k]=v;});
    fetch(BASE_IT+'/islemler/uretim/iptal_talep_islem.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(obj)
    }).then(function(r){return r.json();}).then(function(d){
        if(d.success){
            var detayHtml = (d.message||'').replace(/\n/g,'<br>');
            Swal.fire({title:'İşlem Tamamlandı!',html:detayHtml,icon:'success',confirmButtonColor:'#16A34A',confirmButtonText:'Tamam'});
            document.getElementById('talep-islem-modal').style.display='none';
            setTimeout(function(){location.reload();},3000);
        } else {
            Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
        }
    }).catch(function(e){Swal.fire({title:'Hata',text:e.message,icon:'error'});});
});
</script>
</div><!-- /s-body -->
