<?php
/**
 * Hurda/Takoz Giriş Modalı
 * $uretim parent scope'tan geliyor (mes_uretim_emri_detay.php)
 */

$uretim_no    = $uretim['uretim_no']      ?? $ficheno ?? '';
$is_istasyonu = $uretim['is_istasyonu']   ?? '';
$mamul_kodu   = $uretim['mamul_kodu']     ?? '';
$itemref      = (int)($uretim['ITEMREF']  ?? 0);
$uomref       = (int)($uretim['uomref']   ?? 0);
$kul_isim     = $_SESSION['kullanici']['isim'] ?? ($_SESSION['kullanici']['ad'] ?? 'jetone');
?>

<!-- Emri Özet -->
<div style="background:var(--kenar-a);border-radius:var(--r);padding:14px 16px;margin-bottom:18px;border-left:4px solid #DC2626">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px">
    <div><span style="color:var(--m3);font-weight:700">Emri No:</span> <b><?=htmlspecialchars($uretim_no)?></b></div>
    <div><span style="color:var(--m3);font-weight:700">İstasyon:</span> <b><?=htmlspecialchars($is_istasyonu)?></b></div>
    <div style="grid-column:span 2"><span style="color:var(--m3);font-weight:700">Mamul:</span> <?=htmlspecialchars($mamul_kodu)?></div>
  </div>
</div>

<div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:var(--r);padding:12px 14px;margin-bottom:18px;font-size:12px;color:#7F1D1D">
  ⚠️ Bu işlem <b>hammadde fire/takoz</b> kaydı oluşturur. <code>MES_TAKOZ_HAMMADDELER</code> tablosundan hammadde bilgileri alınır ve Logo'ya fire fişi gönderilir.
</div>

<form id="hurdaGirisForm">
  <input type="hidden" name="uretim_emri_no"  value="<?=htmlspecialchars($uretim_no)?>">
  <input type="hidden" name="is_istasyonu"    value="<?=htmlspecialchars($is_istasyonu)?>">
  <input type="hidden" name="stok_kodu"       value="<?=htmlspecialchars($mamul_kodu)?>">
  <input type="hidden" name="itemref"         value="<?=$itemref?>">
  <input type="hidden" name="uomref"          value="<?=$uomref?>">
  <input type="hidden" name="ambar"           value="1">
  <input type="hidden" name="ekleyen"         value="<?=htmlspecialchars($kul_isim)?>">

  <div style="margin-bottom:16px">
    <label class="form-et">Fire / Takoz Miktarı <span style="color:#DC2626">*</span></label>
    <input type="number" name="fire_miktari" id="hurda-miktar" class="form-alan"
           min="0.1" step="0.1" placeholder="Miktar girin..." autocomplete="off" required>
    <div id="hurda-miktar-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
  </div>

  <button type="submit" id="hurda-kaydet-btn" class="btn"
          style="width:100%;padding:12px;font-size:14px;font-weight:800;border-radius:var(--r);background:#DC2626;color:#fff;border:none;cursor:pointer">
    🔥 Hurda/Takoz Girişi Yap
  </button>

  <div id="hurda-sonuc" style="margin-top:12px"></div>
</form>

<style>.swal2-container{z-index:99999!important}.swal2-backdrop-show{z-index:99998!important}</style>
<script>
(function() {
    var form    = document.getElementById('hurdaGirisForm');
    var submitting = false;
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (submitting) return;

        var miktar = document.getElementById('hurda-miktar');
        var mHata  = document.getElementById('hurda-miktar-hata');
        mHata.textContent = '';

        if (!miktar.value || parseFloat(miktar.value) <= 0) {
            mHata.textContent = 'Gecerli bir miktar girin (0\'dan buyuk).';
            return;
        }

        submitting = true;

        Swal.fire({
            title: 'Hurda/Takoz Girisi Yapiliyor...',
            text: 'Logo API ile fire fisi olusturuluyor, lutfen bekleyin.',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function() { Swal.showLoading(); }
        });

        var fd = new FormData(form);

        fetch(BASE + '/islemler/uretim/hurda_takoz_giris.php', {
            method: 'POST',
            body: fd
        })
        .then(function(r) {
            return r.text().then(function(txt) {
                try { return JSON.parse(txt); }
                catch(e) { throw new Error('Sunucu hatasi: ' + txt.substring(0, 150)); }
            });
        })
        .then(function(d) {
            Swal.close();
            if (d.success) {
                Swal.fire({
                    title: 'Basarili!',
                    text: d.message || 'Hurda/Takoz girisi yapildi.',
                    icon: 'success',
                    confirmButtonColor: '#16A34A',
                    confirmButtonText: 'Tamam'
                }).then(function() {
                    var modal = document.getElementById('modal-hurda');
                    if (modal) modal.style.display = 'none';
                    document.body.style.overflow = '';
                    miktar.value = '';
                    location.reload();
                });
            } else {
                Swal.fire({
                    title: 'Hata!',
                    text: d.message || 'Islem gerceklestirilemedi.',
                    icon: 'error',
                    confirmButtonColor: '#DC2626'
                });
            }
        })
        .catch(function(err) {
            Swal.close();
            Swal.fire({
                title: 'Baglanti Hatasi',
                text: err.message,
                icon: 'error',
                confirmButtonColor: '#DC2626'
            });
        })
        .finally(function() {
            submitting = false;
        });
    });
})();
</script>
