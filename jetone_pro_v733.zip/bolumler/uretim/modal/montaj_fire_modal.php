<?php
/**
 * Montaj Fire Giriş Modalı — EN ile BAŞLAMAYAN makineler (montaj hattı)
 * Reçetedeki girdiler listelenir → fire miktarı + nedeni girilir
 * → Logo itemSlips TYPE=25 (ambar transfer: 01→03)
 * $uretim değişkeni parent scope'tan geliyor
 */

// Çalışan listesi
$employeesList_mf = [];
try {
    if ($tigerdb_pdo) {
        $es = $tigerdb_pdo->query(
            "SELECT LOGICALREF as ID, CODE as PERSONEL_KODU, NAME as PERSONEL_ADI
             FROM LG_222_EMPLOYEE WITH(NOLOCK) WHERE ACTIVE=1 ORDER BY NAME"
        );
        $employeesList_mf = $es->fetchAll(PDO::FETCH_ASSOC);
    }
} catch(Throwable $e) {}

// Reçete verileri
$mamul_kodu_mf  = $uretim['mamul_kodu']   ?? '';
$uretim_no_mf   = $uretim['uretim_no']    ?? $ficheno ?? '';
$is_ist_mf      = $uretim['is_istasyonu'] ?? '';
$mamul_adi_mf   = $uretim['mamul_adi']    ?? '';
$uretim_id_mf   = (int)($uretim['ID']     ?? 0);
$kul_mf         = $_SESSION['kullanici']['isim'] ?? ($_SESSION['kullanici']['ad'] ?? 'jetone');

$recete_data = [];
if (!empty($mamul_kodu_mf) && $tigerdb_pdo) {
    try {
        $rs = $tigerdb_pdo->prepare(
            "SELECT IT2.CODE AS GIRDI_KODU, IT2.NAME AS GIRDI_ADI,
                    CAST(BML.AMOUNT AS BIGINT) AS MIKTAR
             FROM dbo.LG_222_BOMLINE BML
             LEFT JOIN dbo.LG_222_BOMREVSN BMR ON BML.BOMREVREF=BMR.LOGICALREF
             LEFT JOIN dbo.LG_222_BOMASTER BOM ON BMR.BOMMASTERREF=BOM.LOGICALREF
             LEFT JOIN dbo.LG_222_ITEMS IT      ON BOM.MAINPRODREF=IT.LOGICALREF
             LEFT JOIN dbo.LG_222_ITEMS IT2     ON BML.ITEMREF=IT2.LOGICALREF
             WHERE BML.LINETYPE=0 AND BOM.ACTIVE=0 AND IT.ACTIVE=0
               AND BOM.CODE=?
               AND IT2.CODE NOT LIKE 'ETK%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'KOL%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'POŞ%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'SEP%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'TOR%' COLLATE SQL_Latin1_General_CP1_CS_AS
             ORDER BY IT2.CODE"
        );
        $rs->execute([$mamul_kodu_mf]);
        $recete_data = $rs->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
        error_log("[MONTAJ_FIRE_MODAL] Reçete: " . $e->getMessage());
    }
}

$fire_nedenleri = [
    'HAMMADDE HATASI', 'İŞÇİLİK HATASI', 'MAKİNE ARIZASI',
    'KALIP PROBLEMİ', 'AYAR FİRESİ', 'OPERATÖR HATASI', 'DİĞER',
];
?>

<!-- Emri özet -->
<div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 16px;margin-bottom:16px;border-left:4px solid #EA580C;font-size:12px">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">
    <div><b>Emri:</b> <?=htmlspecialchars($uretim_no_mf)?></div>
    <div><b>İstasyon:</b> <?=htmlspecialchars($is_ist_mf)?></div>
    <div style="grid-column:span 2"><b>Mamul:</b> <?=htmlspecialchars($mamul_kodu_mf)?> — <?=htmlspecialchars($mamul_adi_mf)?></div>
  </div>
</div>

<div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-size:12px;color:#9A3412">
  🔶 Montaj fire kaydı. Seçilen malzeme için <b>Logo'ya ambar transfer fişi (01→03)</b> gönderilir.
</div>

<?php if(empty($recete_data)): ?>
<div style="padding:20px;text-align:center;color:#DC2626;font-size:13px;background:#FEF2F2;border-radius:var(--r)">
  ⚠️ Bu mamul için reçete bilgisi bulunamadı: <b><?=htmlspecialchars($mamul_kodu_mf)?></b>
</div>
<?php else: ?>

<form id="montajFireForm">
  <input type="hidden" name="uretim_emri_id" value="<?=$uretim_id_mf?>">
  <input type="hidden" name="uretim_emri_no" value="<?=htmlspecialchars($uretim_no_mf)?>">
  <input type="hidden" name="ekleyen"        value="<?=htmlspecialchars($kul_mf)?>">
  <input type="hidden" name="is_istasyonu"   value="<?=htmlspecialchars($is_ist_mf)?>">

  <!-- Reçete tablosu -->
  <div style="overflow-x:auto;border:1px solid var(--kenar);border-radius:var(--r);margin-bottom:16px">
    <table style="width:100%;border-collapse:collapse;font-size:12px;min-width:600px">
      <thead>
        <tr style="background:linear-gradient(135deg,#EA580C,#C2410C);color:#fff">
          <th style="padding:10px 8px;text-align:left;font-weight:700">Girdi Kodu</th>
          <th style="padding:10px 8px;text-align:left;font-weight:700">Girdi Adı</th>
          <th style="padding:10px 8px;text-align:center;font-weight:700">Reçete</th>
          <th style="padding:10px 8px;text-align:center;font-weight:700">Fire Nedeni</th>
          <th style="padding:10px 8px;text-align:center;font-weight:700">Fire Miktarı</th>
        </tr>
      </thead>
      <tbody id="mf-tbody">
        <?php foreach($recete_data as $idx => $row): ?>
        <tr id="mf-satir-<?=$idx?>" style="border-bottom:1px solid var(--kenar);background:<?=$idx%2===0?'#fff':'var(--kenar-a)'?>">
          <td style="padding:8px;font-weight:600;font-family:monospace">
            <?=htmlspecialchars($row['GIRDI_KODU'])?>
            <input type="hidden" name="girdi_kodu[]" value="<?=htmlspecialchars($row['GIRDI_KODU'])?>">
            <input type="hidden" name="girdi_adi[]"  value="<?=htmlspecialchars($row['GIRDI_ADI'])?>">
          </td>
          <td style="padding:8px"><?=htmlspecialchars($row['GIRDI_ADI'])?></td>
          <td style="padding:8px;text-align:center;font-weight:700"><?=htmlspecialchars($row['MIKTAR'])?></td>
          <td style="padding:6px">
            <select name="fire_nedeni[]" class="form-alan mf-neden" style="font-size:11px;padding:6px 8px"
                    data-idx="<?=$idx?>" disabled>
              <option value="">-- Seçin --</option>
              <?php foreach($fire_nedenleri as $n): ?>
              <option value="<?=htmlspecialchars($n)?>"><?=htmlspecialchars($n)?></option>
              <?php endforeach; ?>
            </select>
          </td>
          <td style="padding:6px">
            <input type="number" name="fire_miktari[]" id="mf-miktar-<?=$idx?>"
                   class="form-alan mf-miktar" style="font-size:12px;padding:6px 8px;text-align:right"
                   data-idx="<?=$idx?>" min="0" step="0.01" placeholder="0" disabled>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Toplam -->
  <div style="background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff;border-radius:var(--r);padding:14px 20px;margin-bottom:16px;display:flex;align-items:center;gap:14px">
    <div style="font-size:26px">🔥</div>
    <div>
      <div style="font-size:12px;opacity:.85">Toplam Fire Miktarı</div>
      <div style="font-size:22px;font-weight:900">
        Toplam: <span id="mfToplamGoster" style="color:#FFD700">0</span>
      </div>
    </div>
  </div>

  <!-- Çalışan seçimi -->
  <div style="margin-bottom:16px">
    <label class="form-et">Çalışan <span style="color:#DC2626">*</span></label>
    <select name="calisan_id" id="mf-calisan" class="form-alan" required>
      <option value="">-- Çalışan Seçin --</option>
      <?php foreach($employeesList_mf as $emp): ?>
      <option value="<?=htmlspecialchars($emp['ID'])?>">
        <?=htmlspecialchars($emp['PERSONEL_KODU'].' - '.$emp['PERSONEL_ADI'])?>
      </option>
      <?php endforeach; ?>
    </select>
    <div id="mf-calisan-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
  </div>

  <button type="submit" class="btn"
          style="width:100%;padding:12px;font-size:14px;font-weight:800;border-radius:var(--r);background:#EA580C;color:#fff;border:none;cursor:pointer">
    🔶 Montaj Fire Kaydet &amp; Transfer Et
  </button>
</form>

<?php endif; ?>

<script>
(function() {
    var satirSayisi = <?=count($recete_data)?>;
    var aktifIdx    = -1; // Hangi satırda değer var
    var busy        = false;

    // Toplam hesap
    function hesaplaToplam() {
        var t = 0;
        document.querySelectorAll('.mf-miktar').forEach(function(el) {
            t += parseFloat(el.value) || 0;
        });
        var el = document.getElementById('mfToplamGoster');
        if (el) el.textContent = t.toFixed(2);
        return t;
    }

    // Satır aktivasyon kontrolü — sadece 1 satır aktif olabilir
    function satirKontrol() {
        var aktifBulundu = -1;
        document.querySelectorAll('.mf-miktar').forEach(function(el, i) {
            var miktar = parseFloat(el.value) || 0;
            var neden  = document.querySelectorAll('.mf-neden')[i];
            if (miktar > 0 || (neden && neden.value)) {
                aktifBulundu = i;
            }
        });

        document.querySelectorAll('.mf-miktar').forEach(function(el, i) {
            var neden = document.querySelectorAll('.mf-neden')[i];
            var satir = document.getElementById('mf-satir-' + i);
            if (aktifBulundu === -1) {
                // Hepsi aktif
                el.disabled = false;
                if (neden) neden.disabled = false;
                if (satir) satir.style.opacity = '1';
            } else if (i === aktifBulundu) {
                el.disabled = false;
                if (neden) neden.disabled = false;
                if (satir) satir.style.opacity = '1';
            } else {
                el.disabled = true;
                if (neden) neden.disabled = true;
                if (satir) satir.style.opacity = '0.45';
            }
        });
    }

    // Event listener'lar
    document.querySelectorAll('.mf-miktar').forEach(function(el) {
        el.addEventListener('input', function() { hesaplaToplam(); satirKontrol(); });
    });
    document.querySelectorAll('.mf-neden').forEach(function(el) {
        el.addEventListener('change', function() { satirKontrol(); });
    });

    // İlk yükleme
    satirKontrol();

    // Form submit
    var form = document.getElementById('montajFireForm');
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (busy) return;

        var calisan = document.getElementById('mf-calisan');
        var cHata   = document.getElementById('mf-calisan-hata');
        cHata.textContent = '';

        if (!calisan.value) {
            cHata.textContent = 'Calisan secin.'; return;
        }

        // Fire verilerini topla — sadece aktif (enabled) satırdan
        var fireVerileri = [];
        var toplamMiktar = 0;
        var hataSatir    = -1;

        document.querySelectorAll('.mf-miktar:not(:disabled)').forEach(function(el, i) {
            var miktar = parseFloat(el.value) || 0;
            if (miktar > 0) {
                var satirIdx = parseInt(el.getAttribute('data-idx'));
                var neden    = document.querySelector('.mf-neden[data-idx="'+satirIdx+'"]');
                if (!neden || !neden.value) {
                    hataSatir = satirIdx + 1;
                    return;
                }
                var kodu = form.querySelectorAll('input[name="girdi_kodu[]"]')[satirIdx];
                var adi  = form.querySelectorAll('input[name="girdi_adi[]"]')[satirIdx];
                fireVerileri.push({
                    stok_kodu:  kodu ? kodu.value : '',
                    stok_adi:   adi  ? adi.value  : '',
                    fire_miktar: miktar,
                    fire_neden:  neden.value,
                    birim: 'ADET'
                });
                toplamMiktar += miktar;
            }
        });

        if (hataSatir > 0) {
            Swal.fire({title:'Eksik!', text: hataSatir + '. satirda miktar girilmis ama fire nedeni secilmemis.', icon:'warning'});
            return;
        }
        if (fireVerileri.length === 0) {
            Swal.fire({title:'Uyari!', text:'En az bir malzeme icin fire miktari girin.', icon:'warning'});
            return;
        }

        busy = true;
        Swal.fire({
            title:'Kaydediliyor...', text:'Logo ambar transferi yapiliyor, lutfen bekleyin.',
            allowOutsideClick:false, allowEscapeKey:false, showConfirmButton:false,
            didOpen: function() { Swal.showLoading(); }
        });

        fetch(BASE + '/islemler/uretim/montaj_fire_kaydet.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({
                uretim_emri_id: form.querySelector('[name="uretim_emri_id"]').value,
                uretim_emri_no: form.querySelector('[name="uretim_emri_no"]').value,
                calisan_id:     calisan.value,
                ekleyen:        form.querySelector('[name="ekleyen"]').value,
                is_istasyonu:   form.querySelector('[name="is_istasyonu"]').value,
                fire_verileri:  JSON.stringify(fireVerileri)
            })
        })
        .then(function(r) {
            return r.text().then(function(t) {
                try { return JSON.parse(t); }
                catch(e) { throw new Error(t.substring(0,120)); }
            });
        })
        .then(function(d) {
            Swal.close();
            if (d.success) {
                Swal.fire({
                    title:'Tamamlandi!',
                    html: (d.message || 'Montaj fire kaydi yapildi.') +
                          (d.transferler && d.transferler.length ? '<br><small style="color:#666">' + d.transferler.join('<br>') + '</small>' : ''),
                    icon:'success',
                    confirmButtonColor:'#EA580C', confirmButtonText:'Tamam'
                }).then(function() {
                    var modal = document.getElementById('modal-ikinci');
                    if (modal) modal.style.display = 'none';
                    location.reload();
                });
            } else {
                Swal.fire({title:'Hata!', text:d.message, icon:'error', confirmButtonColor:'#DC2626'});
            }
        })
        .catch(function(err) {
            Swal.close();
            Swal.fire({title:'Baglanti Hatasi', text:err.message, icon:'error', confirmButtonColor:'#DC2626'});
        })
        .finally(function() { busy = false; });
    });
})();
</script>
