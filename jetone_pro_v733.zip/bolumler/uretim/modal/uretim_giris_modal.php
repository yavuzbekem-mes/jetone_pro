<?php
/**
 * Üretim Giriş Modalı
 * $uretim değişkeni parent scope'tan geliyor
 */

// Çalışan listesi Tiger'dan
$employeesList = [];
try {
    if ($tigerdb_pdo) {
        $es = $tigerdb_pdo->query(
            "SELECT LOGICALREF as ID, CODE as PERSONEL_KODU, NAME as PERSONEL_ADI
             FROM LG_222_EMPLOYEE WITH(NOLOCK)
             WHERE ACTIVE=1 ORDER BY NAME"
        );
        $employeesList = $es->fetchAll(PDO::FETCH_ASSOC);
    }
} catch(Throwable $e) {}

$uretim_emri_id  = (int)($uretim['ID']         ?? 0);
$mamul_kodu      = $uretim['mamul_kodu']        ?? '';
$mamul_adi       = $uretim['mamul_adi']         ?? '';
$uretim_no       = $uretim['uretim_no']         ?? $ficheno;
$uretim_tarihi   = substr($uretim['uretim_tarihi']??'',0,10);
$itemref         = (int)($uretim['ITEMREF']     ?? 0);
$uomref          = (int)($uretim['uomref']      ?? 0);
$is_istasyonu    = $uretim['is_istasyonu']       ?? '';
$kalan_miktar    = max(0, (float)($uretim['kalan'] ?? 0));
$kul_isim        = $_SESSION['kullanici']['isim'] ?? ($_SESSION['kullanici']['ad']??'jetone');
?>

<!-- Emri Özet Bilgisi -->
<div style="background:var(--kenar-a);border-radius:var(--r);padding:14px 16px;margin-bottom:18px;border-left:4px solid var(--t)">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px">
    <div><span style="color:var(--m3);font-weight:700">Stok Kodu:</span> <b><?=htmlspecialchars($mamul_kodu)?></b></div>
    <div><span style="color:var(--m3);font-weight:700">Emri No:</span> <b><?=htmlspecialchars($uretim_no)?></b></div>
    <div style="grid-column:span 2"><span style="color:var(--m3);font-weight:700">Stok Adı:</span> <?=htmlspecialchars($mamul_adi)?></div>
    <div><span style="color:var(--m3);font-weight:700">Kalan:</span>
      <b style="color:<?=$kalan_miktar>0?'var(--t)':'#16A34A'?>"><?=number_format($kalan_miktar,0,'.',',')?></b>
    </div>
    <div><span style="color:var(--m3);font-weight:700">Tarih:</span> <?=htmlspecialchars($uretim_tarihi)?></div>
  </div>
</div>

<form id="uretimGirisForm">
  <!-- Hidden alanlar -->
  <input type="hidden" name="uretim_emri_id"  value="<?=$uretim_emri_id?>">
  <input type="hidden" name="stok_kodu"        value="<?=htmlspecialchars($mamul_kodu)?>">
  <input type="hidden" name="stok_adi"         value="<?=htmlspecialchars($mamul_adi)?>">
  <input type="hidden" name="uretim_emri_no"   value="<?=htmlspecialchars($uretim_no)?>">
  <input type="hidden" name="uretim_tarihi"    value="<?=htmlspecialchars($uretim_tarihi)?>">
  <input type="hidden" name="birim"            value="ADET">
  <input type="hidden" name="itemref"          value="<?=$itemref?>">
  <input type="hidden" name="uomref"           value="<?=$uomref?>">
  <input type="hidden" name="isistasyonu"      value="<?=htmlspecialchars($is_istasyonu)?>">
  <input type="hidden" name="ekleyen"          value="<?=htmlspecialchars($kul_isim)?>">
  <input type="hidden" name="stok_yeri"        value="X">
  <input type="hidden" name="ambar"            value="1">
  <input type="hidden" name="etiket_turu"      value="URETIM">
  <input type="hidden" name="ana_hammadde"     value="">

  <!-- Miktar + Çalışan -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
    <div>
      <label class="form-et">Üretilen Miktar <span style="color:#DC2626">*</span></label>
      <input type="number" name="miktar" id="giris-miktar" class="form-alan"
             min="1" max="<?=max(1,(int)$kalan_miktar)?>" step="1"
             placeholder="Adet girin..." autocomplete="off" required>
      <div id="giris-miktar-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
    </div>
    <div>
      <label class="form-et">Çalışan <span style="color:#DC2626">*</span></label>
      <select name="calisan_id" id="giris-calisan" class="form-alan" required>
        <option value="">-- Seçin --</option>
        <?php foreach($employeesList as $emp): ?>
        <option value="<?=htmlspecialchars($emp['PERSONEL_KODU'].' - '.$emp['PERSONEL_ADI'])?>">
          <?=htmlspecialchars($emp['PERSONEL_KODU'].' - '.$emp['PERSONEL_ADI'])?>
        </option>
        <?php endforeach; ?>
      </select>
      <div id="giris-calisan-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
    </div>
  </div>

  <!-- Kaydet Butonu -->
  <button type="submit" id="giris-kaydet-btn" class="btn btn-t"
          style="width:100%;padding:12px;font-size:14px;font-weight:800;border-radius:var(--r)">
    ✅ Üretimi Kaydet
  </button>

  <div id="giris-sonuc" style="margin-top:12px"></div>
</form>

<style>.swal2-container{z-index:99999!important}.swal2-backdrop-show{z-index:99998!important}</style>
<script>
(function() {
    var form    = document.getElementById('uretimGirisForm');
    var btnKyd  = document.getElementById('giris-kaydet-btn');
    var sonuc   = document.getElementById('giris-sonuc');

    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Validasyon
        var miktar  = document.getElementById('giris-miktar');
        var calisan = document.getElementById('giris-calisan');
        var mHata   = document.getElementById('giris-miktar-hata');
        var cHata   = document.getElementById('giris-calisan-hata');
        var gecerli = true;

        mHata.textContent = '';
        cHata.textContent = '';

        if (!miktar.value || parseInt(miktar.value) < 1) {
            mHata.textContent = 'Gecerli bir miktar girin.';
            gecerli = false;
        }
        if (!calisan.value) {
            cHata.textContent = 'Calisan secin.';
            gecerli = false;
        }
        if (!gecerli) return;

        // Loading
        Swal.fire({
            title: 'Kaydediliyor...',
            text: 'Uretim girisi isleniyor, lutfen bekleyin.',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: function() { Swal.showLoading(); }
        });

        // FormData topla
        var fd = new FormData(form);
        // calisan name değerini de ekle (select text)
        var sel = document.getElementById('giris-calisan');
        if (sel.selectedIndex > 0) {
            fd.set('calisan', sel.options[sel.selectedIndex].text);
        }

        // JSON'a çevir
        var obj = {};
        fd.forEach(function(v, k) { obj[k] = v; });

        fetch(BASE + '/islemler/uretim/uretim_giris_kaydet.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(obj)
        })
        .then(function(r) {
            return r.text().then(function(txt) {
                try { return JSON.parse(txt); }
                catch(e) { throw new Error('JSON hatasi: ' + txt.substring(0, 100)); }
            });
        })
        .then(function(d) {
            Swal.close(); // Loading kapat
            if (d.success) {
                // Etiket yeni sekmede aç
                if (d.etiket_url) {
                    var url = d.etiket_url.indexOf('http') === 0
                        ? d.etiket_url
                        : BASE + d.etiket_url;
                    window.open(url, '_blank');
                }
                Swal.fire({
                    title: 'Kayit Basarili!',
                    text: d.message || 'Uretim girisi kaydedildi.',
                    icon: 'success',
                    confirmButtonColor: '#16A34A',
                    confirmButtonText: 'Tamam'
                }).then(function() {
                    document.getElementById('giris-miktar').value = '';
                    document.getElementById('giris-calisan').selectedIndex = 0;
                    sonuc.innerHTML = '';
                    // Modal kapat
                    var modal = document.getElementById('modal-urun');
                    if (modal) modal.style.display = 'none';
                    document.body.style.overflow = '';
                    location.reload();
                });
            } else {
                Swal.fire({
                    title: 'Hata!',
                    text: d.message || 'Islem gerceklestirilemedi.',
                    icon: 'error',
                    confirmButtonColor: '#DC2626'
                });
            }
        })
        .catch(function(err) {
            Swal.close();
            Swal.fire({
                title: 'Baglanti Hatasi',
                text: err.message,
                icon: 'error',
                confirmButtonColor: '#DC2626'
            });
        });
    });
})();
</script>
