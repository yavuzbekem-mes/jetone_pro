<?php
/**
 * Makine Duruşu Giriş Modalı
 * $uretim parent scope'tan geliyor
 */
$uretim_no  = $uretim['uretim_no']    ?? $ficheno ?? '';
$is_ist     = $uretim['is_istasyonu'] ?? '';
$mamul_kodu = $uretim['mamul_kodu']   ?? '';
$mamul_adi  = $uretim['mamul_adi']    ?? '';
$kul_isim   = $_SESSION['kullanici']['isim'] ?? ($_SESSION['kullanici']['ad'] ?? 'jetone');
$now        = date('Y-m-d\TH:i');

$durus_nedenleri = [
    'Kalıp Değişimi', 'Setup / Ayar Süresi', 'Hammadde Bekleme',
    'İş Emri Yok', 'Yarı Mamul Bekleme', 'Kalıp Arızası',
    'Makine Arıza', 'Enerji Kesintisi', 'Deneme Üretimi',
    'Planlama Kaynaklı', 'Planlı Duruş', 'Eleman Eksikliği', 'Üretim Bitti',
];
?>

<!-- Emri özet -->
<div style="background:linear-gradient(135deg,#f5f7fa,#c3cfe2);border-radius:var(--r);padding:14px 16px;margin-bottom:18px;border-left:4px solid #0EA5E9;font-size:12px">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px">
    <div><b>Emri:</b> <?=htmlspecialchars($uretim_no)?></div>
    <div><b>İstasyon:</b> <?=htmlspecialchars($is_ist)?></div>
    <div style="grid-column:span 2"><b>Mamul:</b> <?=htmlspecialchars($mamul_kodu)?> — <?=htmlspecialchars($mamul_adi)?></div>
  </div>
</div>

<form id="makineDurusForm">
  <input type="hidden" name="uretim_emri_no" value="<?=htmlspecialchars($uretim_no)?>">
  <input type="hidden" name="is_istasyonu"   value="<?=htmlspecialchars($is_ist)?>">

  <!-- Tarih/Saat grid -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
    <div>
      <label class="form-et">Başlangıç <span style="color:#DC2626">*</span></label>
      <input type="datetime-local" name="baslangic_zamani" id="md-baslangic"
             class="form-alan" value="<?=$now?>" required>
    </div>
    <div>
      <label class="form-et">Bitiş <span style="color:#DC2626">*</span></label>
      <input type="datetime-local" name="bitis_zamani" id="md-bitis"
             class="form-alan" value="<?=$now?>" required>
    </div>
  </div>

  <!-- Otomatik süre gösterimi -->
  <div id="md-sure-kutu" style="display:none;background:linear-gradient(135deg,#e0f2fe,#bae6fd);border-radius:var(--r);padding:12px 16px;margin-bottom:16px;border-left:4px solid #0EA5E9;display:flex;align-items:center;gap:12px">
    <span style="font-size:22px">⏱️</span>
    <div>
      <div style="font-size:11px;color:#0c4a6e;font-weight:700">Toplam Duruş Süresi</div>
      <div id="md-sure-text" style="font-size:18px;font-weight:900;color:#0369a1">—</div>
    </div>
  </div>

  <!-- Duruş nedeni -->
  <div style="margin-bottom:16px">
    <label class="form-et">Duruş Nedeni <span style="color:#DC2626">*</span></label>
    <select name="durus_nedeni" id="md-neden" class="form-alan" required
            onchange="document.getElementById('md-diger-alan').style.display=this.value==='Diğer'?'block':'none';if(this.value!=='Diğer')document.getElementById('md-aciklama').value=''">
      <option value="">-- Duruş Nedeni Seçin --</option>
      <?php foreach($durus_nedenleri as $n): ?>
      <option value="<?=htmlspecialchars($n)?>"><?=htmlspecialchars($n)?></option>
      <?php endforeach; ?>
    </select>
    <div id="md-neden-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
  </div>

  <!-- Diğer açıklaması — sadece Diğer seçilince görünür -->
  <div id="md-diger-alan" style="display:none;margin-bottom:18px">
    <label class="form-et">Diğer Açıklaması <span style="color:#DC2626">*</span></label>
    <input type="text" name="aciklama" id="md-aciklama" class="form-alan"
           placeholder="Duruş nedenini açıklayın..." maxlength="200">
    <div id="md-aciklama-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
  </div>

  <button type="submit" class="btn"
          style="width:100%;padding:12px;font-size:14px;font-weight:800;border-radius:var(--r);background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;cursor:pointer">
    ⏱️ Duruş Kaydet
  </button>
</form>

<script>
(function() {
    var bas  = document.getElementById('md-baslangic');
    var bit  = document.getElementById('md-bitis');
    var kut  = document.getElementById('md-sure-kutu');
    var txt  = document.getElementById('md-sure-text');
    var form = document.getElementById('makineDurusForm');
    var busy = false;

    function hesaplaSure() {
        if (!bas.value || !bit.value) return;
        var b = new Date(bas.value), e = new Date(bit.value);
        if (e > b) {
            var dk = Math.floor((e - b) / 60000);
            var s  = Math.floor(dk / 60);
            txt.textContent = s > 0 ? s + ' saat ' + (dk % 60) + ' dk (' + dk + ' dk)' : dk + ' dk';
            kut.style.display = 'flex';
        } else {
            kut.style.display = 'none';
        }
    }

    bas.addEventListener('change', hesaplaSure);
    bit.addEventListener('change', hesaplaSure);
    hesaplaSure();

    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (busy) return;

        var neden = document.getElementById('md-neden');
        var nHata = document.getElementById('md-neden-hata');
        nHata.textContent = '';

        var b = new Date(bas.value), en = new Date(bit.value);
        if (en <= b) {
            Swal.fire({title:'Hata!', text:'Bitis zamani baslangictan buyuk olmali.', icon:'error'}); return;
        }
        if (!neden.value) {
            nHata.textContent = 'Durus nedeni secin.'; return;
        }
        var aciklama = document.getElementById('md-aciklama');
        var aHata    = document.getElementById('md-aciklama-hata');
        if (neden.value === 'Diğer' && aciklama && !aciklama.value.trim()) {
            aHata.textContent = 'Diger aciklamasi girin.'; return;
        }
        if (aHata) aHata.textContent = '';

        busy = true;
        Swal.fire({
            title:'Kaydediliyor...', text:'Makine durusu kaydediliyor.',
            allowOutsideClick:false, allowEscapeKey:false, showConfirmButton:false,
            didOpen:function(){Swal.showLoading();}
        });

        var fd = new FormData(form);
        fetch(BASE + '/islemler/uretim/makine_durus_kaydet.php', {method:'POST', body:fd})
        .then(function(r){
            return r.text().then(function(t){
                try{return JSON.parse(t);}catch(e){throw new Error(t.substring(0,120));}
            });
        })
        .then(function(d) {
            Swal.close();
            if (d.success) {
                Swal.fire({
                    title:'Kaydedildi!', text:d.message || 'Makine durusu kaydedildi.',
                    icon:'success', confirmButtonColor:'#059669', confirmButtonText:'Tamam'
                }).then(function(){
                    var modal = document.getElementById('modal-durus');
                    if(modal) modal.style.display='none';
                    document.body.style.overflow='';
                    location.reload();
                });
            } else {
                Swal.fire({title:'Hata!', text:d.message, icon:'error', confirmButtonColor:'#DC2626'});
            }
        })
        .catch(function(err){
            Swal.close();
            Swal.fire({title:'Baglanti Hatasi', text:err.message, icon:'error', confirmButtonColor:'#DC2626'});
        })
        .finally(function(){ busy = false; });
    });
})();
</script>
