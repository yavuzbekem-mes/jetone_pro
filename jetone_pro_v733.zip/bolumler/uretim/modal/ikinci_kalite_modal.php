<?php
/**
 * İkinci Kalite Giriş Modalı — SADECE EN ile başlayan makineler
 * Enjeksiyon defekt türleri girişi → MES IKINCI_KALITE tablosuna INSERT
 * $uretim değişkeni parent scope'tan geliyor
 */

// Çalışan listesi
$employeesList = [];
try {
    if ($tigerdb_pdo) {
        $es = $tigerdb_pdo->query(
            "SELECT LOGICALREF as ID, CODE as PERSONEL_KODU, NAME as PERSONEL_ADI
             FROM LG_222_EMPLOYEE WITH(NOLOCK) WHERE ACTIVE=1 ORDER BY NAME"
        );
        $employeesList = $es->fetchAll(PDO::FETCH_ASSOC);
    }
} catch(Throwable $e) {}

// Değişkenler
$uretim_emri_id = (int)($uretim['ID']           ?? 0);
$uretim_no      = $uretim['uretim_no']           ?? $ficheno ?? '';
$mamul_kodu     = $uretim['mamul_kodu']           ?? '';
$mamul_adi      = $uretim['mamul_adi']            ?? '';
$is_istasyonu   = $uretim['is_istasyonu']         ?? '';
$itemref        = (int)($uretim['ITEMREF']        ?? 0);
$uomref         = (int)($uretim['uomref']         ?? 0);
$uretim_tarihi  = substr($uretim['uretim_tarihi'] ?? '', 0, 10);
$kul_isim       = $_SESSION['kullanici']['isim']  ?? ($_SESSION['kullanici']['ad'] ?? 'jetone');

// Defekt türleri — enjeksiyon makineleri için
$defektler = [
    'ayarfiresi'       => 'AYAR FİRESİ',
    'hammaddelekesi'   => 'HAMMADDE LEKESİ',
    'yaglekesi'        => 'YAĞ LEKESİ',
    'cizik'            => 'ÇİZİK',
    'eksikenjeksiyon'  => 'EKSİK ENJEKSİYON',
    'catlak'           => 'ÇATLAK',
    'gazlanma'         => 'GAZLANMA',
    'cokuntu'          => 'ÇÖKÜNTÜ',
    'serpme'           => 'SERPME',
    'yanma'            => 'YANMA',
];
?>

<!-- Emri özet -->
<div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 16px;margin-bottom:16px;border-left:4px solid #7C3AED;font-size:12px">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">
    <div><b>Emri:</b> <?=htmlspecialchars($uretim_no)?></div>
    <div><b>İstasyon:</b> <?=htmlspecialchars($is_istasyonu)?></div>
    <div style="grid-column:span 2"><b>Mamul:</b> <?=htmlspecialchars($mamul_kodu)?> — <?=htmlspecialchars($mamul_adi)?></div>
  </div>
</div>

<form id="ikinciKaliteForm">
  <!-- Hidden alanlar -->
  <input type="hidden" name="uretim_emri_id"  value="<?=$uretim_emri_id?>">
  <input type="hidden" name="uretim_emri_no"  value="<?=htmlspecialchars($uretim_no)?>">
  <input type="hidden" name="stok_kodu"       value="<?=htmlspecialchars($mamul_kodu)?>">
  <input type="hidden" name="stok_adi"        value="<?=htmlspecialchars($mamul_adi)?>">
  <input type="hidden" name="is_istasyonu"    value="<?=htmlspecialchars($is_istasyonu)?>">
  <input type="hidden" name="itemref"         value="<?=$itemref?>">
  <input type="hidden" name="uomref"          value="<?=$uomref?>">
  <input type="hidden" name="birim"           value="ADET">
  <input type="hidden" name="uretim_tarihi"   value="<?=htmlspecialchars($uretim_tarihi)?>">
  <input type="hidden" name="ekleyen"         value="<?=htmlspecialchars($kul_isim)?>">

  <!-- Defekt türleri grid -->
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
    <?php foreach($defektler as $name => $label): ?>
    <div>
      <label style="display:block;font-size:10px;font-weight:700;color:var(--m3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px">
        <?=htmlspecialchars($label)?>
      </label>
      <input type="number" name="<?=$name?>" id="ik-<?=$name?>"
             class="form-alan" style="padding:8px;font-size:13px"
             min="0" step="0.01" placeholder="0">
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Toplam -->
  <div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border-radius:var(--r);padding:16px 20px;margin-bottom:16px;display:flex;align-items:center;gap:16px">
    <div style="font-size:28px">🧮</div>
    <div>
      <div style="font-size:12px;opacity:.85;margin-bottom:4px">Toplam İkinci Kalite Miktarı</div>
      <div style="font-size:24px;font-weight:900">
        Toplam: <span id="ikToplamGoster" style="color:#FFD700">0</span>
      </div>
      <div style="font-size:11px;opacity:.7;margin-top:2px">Otomatik hesaplanır</div>
    </div>
  </div>

  <!-- Çalışan seçimi -->
  <div style="margin-bottom:16px">
    <label class="form-et">Çalışan <span style="color:#DC2626">*</span></label>
    <select name="calisan_id" id="ik-calisan" class="form-alan" required>
      <option value="">-- Çalışan Seçin --</option>
      <?php foreach($employeesList as $emp): ?>
      <option value="<?=htmlspecialchars($emp['PERSONEL_ADI'])?>">
        <?=htmlspecialchars($emp['PERSONEL_KODU'].' - '.$emp['PERSONEL_ADI'])?>
      </option>
      <?php endforeach; ?>
    </select>
    <div id="ik-calisan-hata" style="font-size:11px;color:#DC2626;margin-top:3px"></div>
  </div>

  <button type="submit" class="btn"
          style="width:100%;padding:12px;font-size:14px;font-weight:800;border-radius:var(--r);background:#7C3AED;color:#fff;border:none;cursor:pointer">
    ⚑ İkinci Kalite Kaydet
  </button>
</form>

<style>
@media(max-width:700px){
  #ikinciKaliteForm > div:first-of-type { grid-template-columns:repeat(2,1fr)!important; }
}
</style>

<script>
(function() {
    var defektIds = <?=json_encode(array_keys($defektler))?>.map(function(k){return 'ik-'+k;});
    var form = document.getElementById('ikinciKaliteForm');
    var busy = false;

    // Toplam hesapla
    function hesaplaToplam() {
        var t = 0;
        defektIds.forEach(function(id) {
            var el = document.getElementById(id);
            if (el && el.value) t += parseFloat(el.value) || 0;
        });
        var el = document.getElementById('ikToplamGoster');
        if (el) el.textContent = t.toFixed(2);
        return t;
    }

    // Her input'a listener ekle
    defektIds.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.addEventListener('input', hesaplaToplam);
    });

    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (busy) return;

        var calisan  = document.getElementById('ik-calisan');
        var cHata    = document.getElementById('ik-calisan-hata');
        var toplam   = hesaplaToplam();
        var ok = true;
        cHata.textContent = '';

        if (!calisan.value) {
            cHata.textContent = 'Calisan secin.'; ok = false;
        }
        if (toplam <= 0) {
            Swal.fire({title:'Uyari!', text:'En az bir defekt turu icin miktar girin.', icon:'warning', confirmButtonText:'Tamam'});
            return;
        }
        if (!ok) return;

        busy = true;
        Swal.fire({
            title: 'Kaydediliyor...', text: 'Ikinci kalite girisi isleniyor.',
            allowOutsideClick:false, allowEscapeKey:false, showConfirmButton:false,
            didOpen: function() { Swal.showLoading(); }
        });

        var fd = new FormData(form);
        fetch(BASE + '/islemler/uretim/ikinci_kalite_kaydet.php', {method:'POST', body:fd})
        .then(function(r) {
            return r.text().then(function(t) {
                try { return JSON.parse(t); }
                catch(e) { throw new Error(t.substring(0,120)); }
            });
        })
        .then(function(d) {
            Swal.close();
            if (d.success) {
                Swal.close();
                if (d.etiket_url) {
                    window.open(d.etiket_url, '_blank');
                }
                Swal.fire({
                    title:'Kaydedildi!', text: d.message || 'Ikinci kalite kaydi yapildi.',
                    icon:'success', confirmButtonColor:'#7C3AED', confirmButtonText:'Tamam'
                }).then(function() {
                    var modal = document.getElementById('modal-ikinci');
                    if (modal) modal.style.display = 'none';
                    location.reload();
                });
            } else {
                Swal.fire({title:'Hata!', text:d.message, icon:'error', confirmButtonColor:'#DC2626'});
            }
        })
        .catch(function(err) {
            Swal.close();
            Swal.fire({title:'Baglanti Hatasi', text:err.message, icon:'error', confirmButtonColor:'#DC2626'});
        })
        .finally(function() { busy = false; });
    });
})();
</script>
