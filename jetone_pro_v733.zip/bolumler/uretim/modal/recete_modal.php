<?php
/**
 * Reçete + Stok Analizi Modalı
 * $uretim parent scope, $tigerdb_pdo mevcut
 */
$r_mamul_kodu = $uretim['mamul_kodu'] ?? '';
$r_uretim_no  = $uretim['uretim_no']  ?? $ficheno ?? '';
$r_kalan      = (float)($uretim['kalan'] ?? 0);
$r_planlanan  = (float)($uretim['planlanan'] ?? 0);
$r_uretilen   = (float)($uretim['uretilen']  ?? 0);

$recete_rows = [];
if ($r_mamul_kodu && $tigerdb_pdo) {
    try {
        $rs = $tigerdb_pdo->prepare(
            "SELECT IT2.CODE AS GIRDI_KODU, IT2.NAME AS GIRDI_ADI,
                    CASE WHEN FLOOR(BML.AMOUNT)=BML.AMOUNT THEN BML.AMOUNT ELSE BML.AMOUNT END AS MIKTAR,
                    ISNULL((
                        SELECT SUM(LV.ONHAND) FROM dbo.LV_222_02_STINVTOT LV
                        LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO
                        WHERE LV.STOCKREF=IT2.LOGICALREF AND LV.INVENNO IN(0,1) AND CAP.FIRMNR=222
                    ),0) AS URETIM_BSH_STOK,
                    ISNULL((
                        SELECT SUM(LV.ONHAND) FROM dbo.LV_222_02_STINVTOT LV
                        LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO
                        WHERE LV.STOCKREF=IT2.LOGICALREF AND LV.INVENNO=5 AND CAP.FIRMNR=222
                    ),0) AS MERKEZ_STOK
             FROM dbo.LG_222_BOMLINE BML
             LEFT JOIN dbo.LG_222_BOMREVSN BMR ON BML.BOMREVREF=BMR.LOGICALREF
             LEFT JOIN dbo.LG_222_BOMASTER BOM ON BMR.BOMMASTERREF=BOM.LOGICALREF
             LEFT JOIN dbo.LG_222_ITEMS IT      ON BOM.MAINPRODREF=IT.LOGICALREF
             LEFT JOIN dbo.LG_222_ITEMS IT2     ON BML.ITEMREF=IT2.LOGICALREF
             WHERE BML.LINETYPE=0 AND BOM.ACTIVE=0 AND IT.ACTIVE=0 AND BOM.CODE=?
               AND IT2.CODE NOT LIKE 'ETK%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'KOL%' COLLATE SQL_Latin1_General_CP1_CS_AS
               AND IT2.CODE NOT LIKE 'POŞ%' COLLATE SQL_Latin1_General_CP1_CS_AS
             ORDER BY IT2.CODE"
        );
        $rs->execute([$r_mamul_kodu]);
        $raw = $rs->fetchAll(PDO::FETCH_ASSOC);

        foreach($raw as $row) {
            $miktar   = (float)$row['MIKTAR'];
            $ihtiyac  = $r_kalan * $miktar;
            $stok     = (float)$row['URETIM_BSH_STOK'];
            $merkez   = (float)$row['MERKEZ_STOK'];
            $fark     = $stok - $ihtiyac;
            $aksiyon  = '';
            if($fark < 0) {
                $aksiyon = $merkez > 0 ? 'MERKEZ DEPODAN AL' : 'PLANLAMAYA HABER VER';
            }
            $recete_rows[] = [
                'kodu'    => $row['GIRDI_KODU'],
                'adi'     => $row['GIRDI_ADI'],
                'miktar'  => $miktar,
                'ihtiyac' => $ihtiyac,
                'stok'    => $stok,
                'merkez'  => $merkez,
                'fark'    => $fark,
                'aksiyon' => $aksiyon,
            ];
        }
    } catch(Throwable $e){ error_log("[RECETE_MODAL] ".$e->getMessage()); }
}

// Kapasite hesabı
$max_kapasite = PHP_INT_MAX;
$kisit_kodu   = '—'; $kisit_adi = '';
foreach($recete_rows as $r){
    if($r['miktar'] > 0){
        $kap = floor($r['stok'] / $r['miktar']);
        if($kap < $max_kapasite){ $max_kapasite=$kap; $kisit_kodu=$r['kodu']; $kisit_adi=$r['adi']; }
    }
}
if($max_kapasite===PHP_INT_MAX) $max_kapasite=0;

$eksik_say  = count(array_filter($recete_rows, fn($r)=>$r['fark']<0));
$yeterli_say= count($recete_rows) - $eksik_say;
$merkez_say = count(array_filter($recete_rows, fn($r)=>$r['aksiyon']==='MERKEZ DEPODAN AL'));
$plan_say   = count(array_filter($recete_rows, fn($r)=>$r['aksiyon']==='PLANLAMAYA HABER VER'));
?>

<!-- Başlık özet -->
<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:16px">
  <div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 16px;flex:1;min-width:180px;border-left:4px solid var(--t)">
    <div style="font-size:11px;color:var(--m3);font-weight:700;text-transform:uppercase;margin-bottom:6px">Mamul</div>
    <div style="font-weight:800;font-size:14px"><?=htmlspecialchars($r_mamul_kodu)?></div>
    <div style="font-size:12px;color:var(--m2);margin-top:2px">Kalan: <b><?=number_format($r_kalan)?></b> adet</div>
  </div>
  <div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 16px;flex:1;min-width:180px;border-left:4px solid <?=$max_kapasite>=$r_kalan?'#16A34A':'#DC2626'?>">
    <div style="font-size:11px;color:var(--m3);font-weight:700;text-transform:uppercase;margin-bottom:6px">Maks. Üretim Kapasitesi</div>
    <div style="font-weight:900;font-size:20px;color:<?=$max_kapasite>=$r_kalan?'#16A34A':'#DC2626'?>"><?=number_format($max_kapasite)?> adet</div>
    <div style="font-size:11px;color:var(--m3);margin-top:2px">Kısıt: <b><?=htmlspecialchars($kisit_kodu)?></b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <span style="background:#D1FAE5;color:#065F46;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700">✅ <?=$yeterli_say?> Yeterli</span>
    <?php if($eksik_say>0): ?>
    <span style="background:#FEE2E2;color:#7F1D1D;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700">❌ <?=$eksik_say?> Eksik</span>
    <?php endif; ?>
    <?php if($merkez_say>0): ?>
    <span style="background:#FEF3C7;color:#92400E;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700">🏭 <?=$merkez_say?> Merkez</span>
    <?php endif; ?>
    <?php if($plan_say>0): ?>
    <span style="background:#FEE2E2;color:#7F1D1D;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700">⚠️ <?=$plan_say?> Planlama</span>
    <?php endif; ?>
  </div>
</div>

<?php if(empty($recete_rows)): ?>
<div style="padding:30px;text-align:center;color:var(--m3)">Bu mamul için reçete bulunamadı: <b><?=htmlspecialchars($r_mamul_kodu)?></b></div>
<?php else: ?>

<!-- Reçete tablosu -->
<div style="overflow:auto;max-height:450px;border:1px solid var(--kenar);border-radius:var(--r)">
<table style="width:100%;border-collapse:collapse;font-size:12px;min-width:700px">
  <thead style="position:sticky;top:0;z-index:2">
    <tr style="background:#1E293B;color:#fff">
      <th style="padding:10px 12px;text-align:left">Girdi Kodu</th>
      <th style="padding:10px 12px;text-align:left">Girdi Adı</th>
      <th style="padding:10px 12px;text-align:right">Reçete</th>
      <th style="padding:10px 12px;text-align:right">İhtiyaç</th>
      <th style="padding:10px 12px;text-align:right">Stok (Ürt+BSH)</th>
      <th style="padding:10px 12px;text-align:right">Merkez</th>
      <th style="padding:10px 12px;text-align:right">Fark</th>
      <th style="padding:10px 12px;text-align:center">Durum</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($recete_rows as $i=>$r):
    $satir_bg = $r['fark']<0 ? '#FFF5F5' : ($i%2===0?'#fff':'var(--kenar-a)');
  ?>
  <tr style="border-bottom:1px solid var(--kenar);background:<?=$satir_bg?>">
    <td style="padding:8px 12px;font-weight:700;font-family:monospace;font-size:11px"><?=htmlspecialchars($r['kodu'])?></td>
    <td style="padding:8px 12px;max-width:200px;font-size:12px"><?=htmlspecialchars($r['adi'])?></td>
    <td style="padding:8px 12px;text-align:right"><?=number_format($r['miktar'],2)?></td>
    <td style="padding:8px 12px;text-align:right;font-weight:700"><?=number_format($r['ihtiyac'],2)?></td>
    <td style="padding:8px 12px;text-align:right"><?=number_format($r['stok'],2)?></td>
    <td style="padding:8px 12px;text-align:right;color:<?=$r['merkez']>0?'#92400E':'var(--m3)'?>;font-weight:<?=$r['merkez']>0?'700':'400'?>"><?=number_format($r['merkez'],2)?></td>
    <td style="padding:8px 12px;text-align:right;font-weight:700;color:<?=$r['fark']>=0?'#16A34A':'#DC2626'?>"><?=($r['fark']>=0?'+':'').number_format($r['fark'],2)?></td>
    <td style="padding:8px 12px;text-align:center">
      <?php if($r['aksiyon']==='MERKEZ DEPODAN AL'): ?>
        <span style="background:#FEF3C7;color:#92400E;padding:3px 8px;border-radius:12px;font-size:10px;font-weight:700;white-space:nowrap">🏭 Merkez'den Al</span>
      <?php elseif($r['aksiyon']==='PLANLAMAYA HABER VER'): ?>
        <span style="background:#FEE2E2;color:#7F1D1D;padding:3px 8px;border-radius:12px;font-size:10px;font-weight:700;white-space:nowrap">⚠️ Planlamaya Bildir</span>
      <?php else: ?>
        <span style="background:#D1FAE5;color:#065F46;padding:3px 8px;border-radius:12px;font-size:10px;font-weight:700">✅ Yeterli</span>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php endif; ?>
