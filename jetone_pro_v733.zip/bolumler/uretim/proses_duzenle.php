<?php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$gun = $kul['ad_soyad'] ?? 'Sistem';

define('PROSES_UPLOAD_DIR2', __DIR__ . '/proses_formlari/');

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: '.BASE_URL.'/panel.php?sayfa=uretim-proses-listesi'); exit; }

$p = null;
try {
    $st = $db->prepare("SELECT * FROM proses_formlari WHERE id=?");
    $st->execute([$id]); $p = $st->fetch(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}
if (!$p) { header('Location: '.BASE_URL.'/panel.php?sayfa=uretim-proses-listesi'); exit; }

$mesaj = ''; $mesaj_tip = '';

// POST: tek form ile güncelle
if (isset($_POST['prosesguncelle'])) {
    $firma     = trim($_POST['firma_adi']   ?? $p['firma_adi']);
    $stok_kodu = trim($_POST['stok_kodu']   ?? $p['stok_kodu']);
    $stok_adi  = trim($_POST['stok_adi']    ?? $p['stok_adi']);
    $proses_no = trim($_POST['proses_no']   ?? $p['proses_no']);
    $durum     = in_array($_POST['durum']??'', ['Aktif','Pasif']) ? $_POST['durum'] : $p['durum'];

    // Dosya var mı? Varsa yükle, yoksa eskiyi koru
    $dosya_yolu = $p['proses_form_görseli_dosya_yolu']; // varsayılan: eski
    if (!empty($_FILES['proses_form_gorseli']['tmp_name'])) {
        if (!is_dir(PROSES_UPLOAD_DIR2)) mkdir(PROSES_UPLOAD_DIR2, 0755, true);
        $orijinal = $_FILES['proses_form_gorseli']['name'];
        $uzanti   = strtolower(pathinfo($orijinal, PATHINFO_EXTENSION));
        if (in_array($uzanti, ['pdf','jpg','jpeg','png','doc','docx','xls','xlsx'])) {
            $yeni_ad = rand(10000000,99999999) . preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $orijinal);
            if (move_uploaded_file($_FILES['proses_form_gorseli']['tmp_name'], PROSES_UPLOAD_DIR2.$yeni_ad)) {
                $dosya_yolu = 'proses_formlari/' . $yeni_ad;
            } else {
                $mesaj = '⚠️ Dosya yüklenemedi, diğer bilgiler güncellendi.';
                $mesaj_tip = 'warn';
            }
        } else {
            $mesaj = '⚠️ Desteklenmeyen dosya türü, dosya değiştirilmedi.';
            $mesaj_tip = 'warn';
        }
    }

    try {
        $db->prepare("UPDATE proses_formlari
            SET firma_adi=?, stok_kodu=?, stok_adi=?, proses_no=?, durum=?,
                proses_form_görseli_dosya_yolu=?, guncelleyen=?, guncelleme_tarihi=NOW()
            WHERE id=?")
           ->execute([$firma, $stok_kodu, $stok_adi, $proses_no, $durum, $dosya_yolu, $gun, $id]);
        if (!$mesaj) { $mesaj = '✅ Güncellendi.'; $mesaj_tip = 'success'; }
        $st->execute([$id]); $p = $st->fetch(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
        $mesaj = '❌ '.$e->getMessage(); $mesaj_tip = 'error';
    }
}

// Firma listesi
$firmalar = [];
if (!empty($tigerdb_pdo)) {
    try {
        $firmalar = $tigerdb_pdo->query("SELECT DISTINCT CLCARD.CODE AS kod, CLCARD.DEFINITION_ AS ad
            FROM dbo.LG_222_02_CLFLINE AS CLFLINE WITH (NOLOCK)
            LEFT JOIN dbo.LG_222_CLCARD AS CLCARD WITH (NOLOCK) ON CLFLINE.CLIENTREF = CLCARD.LOGICALREF
            WHERE CLCARD.DEFINITION_ IS NOT NULL ORDER BY CLCARD.DEFINITION_ ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

$dosya_yolu_db = $p['proses_form_görseli_dosya_yolu'] ?? '';
$uzanti_d      = $dosya_yolu_db ? strtolower(pathinfo($dosya_yolu_db, PATHINFO_EXTENSION)) : '';
// URL: BASE_URL/bolumler/uretim/ + DB yolu
$tam_url       = $dosya_yolu_db ? BASE_URL . '/bolumler/uretim/' . $dosya_yolu_db : '';

$mesaj_renk = ['success'=>['#D1FAE5','#065F46'], 'warn'=>['#FEF9C3','#854D0E'], 'error'=>['#FEE2E2','#991B1B']];
$mr = $mesaj_renk[$mesaj_tip] ?? ['#F1F5F9','#374151'];
?>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1;min-width:0">
    <h1 class="s-bas">✏️ Proses Düzenle</h1>
    <div class="s-yol">Üretim /
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-listesi" style="color:var(--m1)">Proses Listesi</a> /
      <b><?php echo htmlspecialchars($p['proses_no']);?></b>
    </div>
  </div>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-listesi"
     style="background:#64748B;color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;text-decoration:none">← Geri</a>
</div>

<div class="s-body">
<?php if($mesaj): ?>
<div style="background:<?php echo $mr[0];?>;color:<?php echo $mr[1];?>;padding:10px 16px;border-radius:8px;margin-bottom:12px;font-size:13px"><?php echo $mesaj;?></div>
<?php endif;?>

<div style="display:grid;grid-template-columns:360px 1fr;gap:16px;align-items:start">

  <!-- Sol: Tek Form -->
  <div class="kart" style="padding:18px">
    <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:14px">📝 Güncelle</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="prosesguncelle" value="1">

      <label style="display:block;margin-bottom:11px">
        <span style="font-size:11px;font-weight:600;color:#6B7280">Firma</span>
        <select name="firma_adi" style="width:100%;margin-top:3px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px">
          <?php foreach($firmalar as $f): ?>
          <option value="<?php echo htmlspecialchars($f['ad']);?>" <?php echo ($p['firma_adi']==$f['ad'])?'selected':'';?>><?php echo htmlspecialchars($f['ad']);?></option>
          <?php endforeach;?>
          <?php if(empty($firmalar)): // Tiger yoksa serbest giriş ?>
          <option value="<?php echo htmlspecialchars($p['firma_adi']);?>" selected><?php echo htmlspecialchars($p['firma_adi']);?></option>
          <?php endif;?>
        </select>
      </label>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:11px">
        <label>
          <span style="font-size:11px;font-weight:600;color:#6B7280">Stok Kodu</span>
          <input type="text" name="stok_kodu" id="duzStokKodu"
            value="<?php echo htmlspecialchars($p['stok_kodu']??'');?>"
            onblur="duzStokAdiCek(this.value)"
            style="width:100%;margin-top:3px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px;box-sizing:border-box">
        </label>
        <label>
          <span style="font-size:11px;font-weight:600;color:#6B7280">Proses No</span>
          <input type="text" name="proses_no" value="<?php echo htmlspecialchars($p['proses_no']??'');?>"
            style="width:100%;margin-top:3px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px;box-sizing:border-box">
        </label>
      </div>

      <label style="display:block;margin-bottom:11px">
        <span style="font-size:11px;font-weight:600;color:#6B7280">Stok Adı</span>
        <input type="text" name="stok_adi" id="duzStokAdi"
          value="<?php echo htmlspecialchars($p['stok_adi']??'');?>"
          style="width:100%;margin-top:3px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px;box-sizing:border-box">
      </label>

      <label style="display:block;margin-bottom:11px">
        <span style="font-size:11px;font-weight:600;color:#6B7280">Durum</span>
        <select name="durum" style="width:100%;margin-top:3px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px">
          <option value="Aktif" <?php echo $p['durum']==='Aktif'?'selected':'';?>>Aktif</option>
          <option value="Pasif" <?php echo $p['durum']==='Pasif'?'selected':'';?>>Pasif</option>
        </select>
      </label>

      <label style="display:block;margin-bottom:14px">
        <span style="font-size:11px;font-weight:600;color:#6B7280">Yeni Dosya <small style="font-weight:400;color:#9CA3AF">(boş bırakılırsa eski korunur)</small></span>
        <?php if($dosya_yolu_db): ?>
        <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:5px;padding:5px 8px;margin-top:3px;font-size:10px;color:#065F46">
          📎 Mevcut: <strong><?php echo basename($dosya_yolu_db);?></strong>
          <a href="<?php echo $tam_url;?>" download style="color:#0369A1;margin-left:6px">⬇️</a>
        </div>
        <?php endif;?>
        <input type="file" name="proses_form_gorseli"
          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"
          style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-size:12px;box-sizing:border-box">
      </label>

      <button type="submit"
        style="background:#1E3A5F;color:#fff;border:none;padding:9px 0;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;width:100%">
        💾 Güncelle
      </button>
    </form>
  </div>

  <!-- Sağ: Önizleme -->
  <div class="kart" style="padding:14px;min-height:500px">
    <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:10px">👁️ Dosya Önizleme</div>
    <?php if(!$tam_url): ?>
      <div style="text-align:center;padding:80px;color:#94A3B8">Henüz dosya yüklenmemiş</div>
    <?php elseif(in_array($uzanti_d,['jpg','jpeg','png','gif'])): ?>
      <img src="<?php echo $tam_url;?>" alt="Proses Formu"
           style="max-width:100%;height:auto;border-radius:6px;cursor:zoom-in"
           onclick="this.style.maxWidth=this.style.maxWidth==='none'?'100%':'none'">
    <?php elseif($uzanti_d==='pdf'): ?>
      <embed src="<?php echo $tam_url;?>" type="application/pdf" width="100%" height="720px" style="border-radius:6px">
    <?php else: ?>
      <div style="text-align:center;padding:80px">
        <div style="font-size:52px;margin-bottom:12px">📄</div>
        <div style="font-weight:600;margin-bottom:4px;font-size:14px"><?php echo strtoupper($uzanti_d);?> Dosyası</div>
        <div style="color:#64748B;font-size:12px;margin-bottom:16px"><?php echo basename($dosya_yolu_db);?></div>
        <a href="<?php echo $tam_url;?>" download
           style="background:#1E3A5F;color:#fff;padding:9px 24px;border-radius:6px;text-decoration:none;font-size:13px">⬇️ İndir</a>
      </div>
    <?php endif;?>
  </div>
</div>
</div>

<script>
function duzStokAdiCek(kod){
  if(!kod) return;
  fetch('<?php echo BASE_URL;?>/bolumler/uretim/ajax/proses_stok_adi.php?kod='+encodeURIComponent(kod),
    {headers:{'X-Requested-With':'XMLHttpRequest'}})
    .then(r=>r.json()).then(d=>{ if(d.stok_adi) document.getElementById('duzStokAdi').value=d.stok_adi; });
}
</script>
