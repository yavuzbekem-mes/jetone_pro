<?php
/**
 * JETONE.PRO — Kalıp Bağlama Başlatma (mps_plan'a göre liste)
 * panel.php: 'uretim-kalip-baslat' => 'bolumler/uretim/kalip_baslat.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// DB tablo oluştur
try { $db->exec(file_get_contents(dirname(dirname(__DIR__)).'/kalip_degisim.sql')); } catch (Throwable $e) {}

// Hat sıralaması (verim_ekle ile aynı)
$hat_sirasi = [
    'EN-132-01','EN-260-01','EN-80-01','EN-130-01','EN-160-01','EN-201-01',
    'EN-202-01','EN-301-01','EN-302-01','EN-350-01','EN-420-01','EN-500-01',
    'EN-650-01','EN-162-01','EN-131-01','EN-161-01','EN-530-01','EN-650-02',
    'EN-450-01','EN-500-02','EN-110-01','EN-410-01','EN-500-03','EN-700-01',
    'EN-180-01','EN-280-01','EN-650-03','EN-650-04','EN-650-05','EN-650-06',
    'EN-850-01','EN-850-02',
];

$hat_renkler = [
    'EN-132-01'=>'#FFEB99','EN-260-01'=>'#CCE5FF','EN-80-01'=>'#CCFFCC',
    'EN-130-01'=>'#FFDAB9','EN-160-01'=>'#FFCCFF','EN-201-01'=>'#E0FFFF',
    'EN-202-01'=>'#FFE4E1','EN-301-01'=>'#E6E6FA','EN-302-01'=>'#F0FFF0',
    'EN-350-01'=>'#FFFACD','EN-420-01'=>'#FFF5E6','EN-500-01'=>'#F5F5DC',
    'EN-650-01'=>'#D8BFD8','EN-162-01'=>'#B0E0E6','EN-131-01'=>'#FFDEAD',
    'EN-161-01'=>'#F0E68C','EN-530-01'=>'#FFEFD5','EN-650-02'=>'#E6E6FA',
    'EN-450-01'=>'#F5FFFA','EN-500-02'=>'#FFF0F5','EN-110-01'=>'#FAFAD2',
    'EN-410-01'=>'#FDF5E6','EN-500-03'=>'#FFD700','EN-700-01'=>'#FFE4B5',
    'EN-180-01'=>'#F0FFF0','EN-280-01'=>'#FFFAF0','EN-650-03'=>'#FFFACD',
    'EN-650-04'=>'#FFCCCB','EN-650-05'=>'#FFE4C4','EN-650-06'=>'#F8F8FF',
    'EN-850-01'=>'#F0FFF0','EN-850-02'=>'#FFFAF0',
];

// Tiger üretim emri verileri
$prod_info = [];
if (!empty($tigerdb_pdo)) {
    try {
        $st = $tigerdb_pdo->query("
            SELECT
                PRO.FICHENO AS ue_no,
                CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
                CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen
            FROM dbo.LG_222_PRODORD AS PRO
            WHERE YEAR(PRO.DATE_) >= 2024 AND PRO.STATUS IN (0,1)
            GROUP BY PRO.FICHENO, PRO.PLNAMOUNT, PRO.STATUS");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $prod_info[$r['ue_no']] = $r;
        }
    } catch (Throwable $e) {}
}

// mps_plan
try {
    $raw = $db->query("
        SELECT id, hat_kodu, urun_kodu, urun_adi, durum, kalan_miktar, planlanan_miktar, uretim_emri_no, hat_sira_no
        FROM mps_plan
        WHERE durum NOT IN ('Tamamlandı','İptal','Tamamlandi','Iptal')
          AND hat_kodu LIKE 'EN-%'
          AND urun_kodu != '__DURUS__'
    ")->fetchAll(PDO::FETCH_ASSOC);
    $hat_idx = array_flip($hat_sirasi);
    usort($raw, function($a,$b) use ($hat_idx) {
        $ia = $hat_idx[$a['hat_kodu']] ?? 999;
        $ib = $hat_idx[$b['hat_kodu']] ?? 999;
        return $ia !== $ib ? $ia-$ib : (int)($a['hat_sira_no']??0)-(int)($b['hat_sira_no']??0);
    });
    $plan_rows = $raw;
} catch (Throwable $e) { $plan_rows = []; }

// Devam eden kalıp bağlama işlemleri (makine bazında)
try {
    $aktif_kp = [];
    $st = $db->query("SELECT is_istasyonu FROM kalip_degisim WHERE durumu='Devam Ediyor'");
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $ist) { $aktif_kp[$ist] = true; }
} catch (Throwable $e) { $aktif_kp = []; }

function durum_badge($d) {
    $map = [
        'Devam Ediyor'=>['#DBEAFE','#1D4ED8'],'Devam Edecek'=>['#DBEAFE','#1D4ED8'],
        'Planlandı'=>['#FEF9C3','#92400E'],'Sıradaki İş'=>['#FEF9C3','#92400E'],
        'Beklemede'=>['#FEF9C3','#92400E'],'Kalıp Değişecek'=>['#D1FAE5','#065F46'],
        'Renk Değişecek'=>['#FEF3C7','#92400E'],'Tamamlandı'=>['#D1FAE5','#065F46'],
        'Kapalı'=>['#FEE2E2','#991B1B'],'Makina Arızalı'=>['#FEE2E2','#991B1B'],
        'Kalıp Arızalı'=>['#FEE2E2','#991B1B'],
    ];
    [$bg,$fg] = $map[$d] ?? ['#F1F5F9','#334155'];
    return "<span style='background:$bg;color:$fg;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700'>".htmlspecialchars($d)."</span>";
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 Kalıp Bağlama Başlat</h1>
    <div class="s-yol">Üretim / <b>Kalıp Bağlama</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-devam"    class="btn btn-b btn-sm">⏳ Devam Edenler</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-tamamlanan" class="btn btn-b btn-sm">✅ Tamamlananlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-ekle"     class="btn btn-t btn-sm">+ Manuel Ekle</a>
  </div>
</div>

<div class="s-body">
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow-x:auto">
    <?php $sth = ['','Makine','Ürün Kodu','Ürün Adı','Durum','Açıklama','Plan','Üretilen','Kalan']; ?>
    <table id="kalipTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tfoot>
        <tr style="background:#1E3A5F!important">
          <?php foreach ($sth as $h): ?>
          <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </tfoot>
      <tbody>
        <?php foreach ($plan_rows as $r):
            $hat_bg = $hat_renkler[$r['hat_kodu']] ?? '#ffffff';
            $ue_no  = $r['uretim_emri_no'] ?? '';
            $plan   = $prod_info[$ue_no]['planlanan'] ?? $r['planlanan_miktar'] ?? 0;
            $uret   = $prod_info[$ue_no]['uretilen']  ?? 0;
            $kalan  = max(0, $plan - $uret);
            $pct    = $plan > 0 ? min(100,round($uret/$plan*100)) : 0;
            $hat_aktif = $aktif_kp[$r['hat_kodu']] ?? false;
        ?>
        <tr style="background:<?= $hat_bg ?>">
          <td style="white-space:nowrap">
            <?php if ($hat_aktif): ?>
            <span style="background:#FEF9C3;color:#92400E;padding:3px 8px;border-radius:8px;font-size:11px;font-weight:700">⏳ Aktif</span>
            <?php else: ?>
            <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-ekle&hat=<?= urlencode($r['hat_kodu']) ?>&urun_kodu=<?= urlencode($r['urun_kodu']) ?>&urun_adi=<?= urlencode($r['urun_adi']) ?>"
               class="btn btn-t btn-sm" style="white-space:nowrap">▶ Başlat</a>
            <?php endif; ?>
          </td>
          <td style="font-family:monospace;font-weight:800;color:var(--t)"><?= htmlspecialchars($r['hat_kodu']) ?></td>
          <td style="font-family:monospace;font-weight:700"><?= htmlspecialchars($r['urun_kodu']??'') ?></td>
          <td style="max-width:220px;font-size:12px"><?= htmlspecialchars($r['urun_adi']??'') ?></td>
          <td><?= durum_badge($r['durum']??'') ?></td>
          <td style="font-size:11px;max-width:160px"><?= htmlspecialchars($r['aciklama']??'') ?></td>
          <td style="text-align:right"><?= $plan>0?number_format($plan,0):'—' ?></td>
          <td style="text-align:right">
            <div style="display:flex;align-items:center;gap:6px">
              <?= $uret>0?number_format($uret,0):'—' ?>
              <?php if ($pct>0): ?>
              <div style="flex:1;min-width:50px;height:5px;background:var(--kenar);border-radius:3px">
                <div style="height:100%;width:<?= $pct ?>%;background:<?= $pct>=80?'#22C55E':($pct>=50?'#F59E0B':'#EF4444') ?>;border-radius:3px"></div>
              </div>
              <span style="font-size:10px;color:var(--m2)"><?= $pct ?>%</span>
              <?php endif; ?>
            </div>
          </td>
          <td style="text-align:right;font-weight:700;color:<?= $kalan>0?'#EF4444':'#22C55E' ?>"><?= number_format($kalan,0) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
$(document).ready(function(){
  $('#kalipTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true, scrollY:540, scrollCollapse:true, paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'KalipPlani_<?= date('Ymd') ?>'}],
    drawCallback:function(){ $('#kalipTablo thead th,#kalipTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){ this.api().columns([1,4]).every(function(){ var col=this,sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); }); col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); }); }); $('#kalipTablo thead th,#kalipTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); }
  });
});
</script>
