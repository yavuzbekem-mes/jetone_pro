<?php
/**
 * BSH Kit Fis - Yazdir (panel.php bypass, bagimsiz sayfa)
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$fis_no = trim($_GET['fis_no'] ?? '');
$fis    = null;
$fark_sonraki = 0;

if ($fis_no) {
    try {
        $s = $db->prepare("SELECT * FROM `giriş_fişleri` WHERE `fiş_no`=? LIMIT 1");
        $s->execute([$fis_no]);
        $fis = $s->fetch(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

if (!$fis) {
    die('<p style="font-family:Arial;padding:20px">Fis bulunamadi: ' . htmlspecialchars($fis_no) . '</p>');
}

if ($mes_pdo) {
    try {
        $pno_chk = $fis['PAKET_NO'] ?? '';
        $ms = $mes_pdo->prepare("SELECT MIKTAR FROM dbo.PAKETLER WHERE PAKET_NO=? AND URETIM_TARIHI >= DATEADD(DAY,-6,GETDATE())");
        $ms->execute([$pno_chk]);
        $mes_miktar = (int)($ms->fetchColumn() ?: 0);
        if ($mes_miktar > 0) {
            $cnt = $db->prepare("SELECT COUNT(*) FROM `giriş_fişleri` WHERE PAKET_NO=?");
            $cnt->execute([$pno_chk]);
            $fark_sonraki = $mes_miktar - (int)$cnt->fetchColumn();
        }
    } catch(Throwable $e) {}
}

$uk      = htmlspecialchars(substr(trim($fis['urun_kodu'] ?? ''), 0, 10));
$ua      = htmlspecialchars(substr(trim($fis['urun_adi']  ?? ''), 0, 40));
$ts      = $fis['tarih_saat'] ? date('Y-m-d H:i:s', strtotime($fis['tarih_saat'])) : '';
$pno     = $fis['PAKET_NO'] ?? '';
$uk_js   = addslashes(substr(trim($fis['urun_kodu'] ?? ''), 0, 10));
$ua_js   = addslashes(substr(trim($fis['urun_adi']  ?? ''), 0, 40));
$pno_js  = addslashes($pno);
$base    = BASE_URL;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Fis <?=htmlspecialchars($fis_no)?></title>
<script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:Arial,sans-serif;background:#fff;}
.no-print{padding:10px;background:#EFF6FF;display:flex;gap:8px;flex-wrap:wrap;}
.no-print button,.no-print a{padding:8px 18px;border:none;border-radius:4px;cursor:pointer;font-weight:700;font-size:13px;text-decoration:none;display:inline-block;}
.btn-yaz{background:#16A34A;color:#fff;}
.btn-devam{background:#2563EB;color:#fff;}
.btn-liste{background:#4B5563;color:#fff;}
.btn-kapat{background:#9CA3AF;color:#fff;}
.fis-wrap{padding:15px;display:inline-flex;align-items:stretch;border:1px solid #999;margin-top:10px;}
.fis-tablo{border-collapse:collapse;}
.fis-tablo td{border:1px solid #333;padding:6px 10px;font-size:14px;font-weight:bold;}
.td-kod{font-size:24px;font-weight:900;}
.qr-cell{border:1px solid #333;border-left:none;padding:6px;display:flex;align-items:center;justify-content:center;min-width:112px;}
@media print{.no-print{display:none!important;}body{margin:0;}}
</style>
</head>
<body>
<div class="no-print">
  <button class="btn-yaz" onclick="window.print()">Yazdir</button>
  <?php if ($fark_sonraki > 0): ?>
  <button class="btn-devam" onclick="goDevam()">Devam Et (<?=(int)$fark_sonraki?> kalan)</button>
  <?php else: ?>
  <a class="btn-liste" href="<?=$base?>/panel.php?sayfa=uretim-kit-liste">Listeye Don</a>
  <?php endif; ?>
  <button class="btn-kapat" onclick="window.close()">Kapat</button>
</div>
<div class="fis-wrap">
  <table class="fis-tablo">
    <tr><td>Item Code:</td><td class="td-kod"><?=$uk?></td></tr>
    <tr><td>Item Name:</td><td><?=$ua?></td></tr>
    <tr><td>Amount:</td><td>1 Piece</td></tr>
    <tr><td>Date - Time:</td><td><?=htmlspecialchars($ts)?></td></tr>
    <tr><td>Package Nu:</td><td><?=htmlspecialchars($fis_no)?></td></tr>
  </table>
  <div class="qr-cell"><div id="qrcode"></div></div>
</div>
<script>
var BASE_URL = '<?=$base?>';
var uk  = '<?=$uk_js?>';
var ua  = '<?=$ua_js?>';
var pno = '<?=$pno_js?>';
window.onload = function() {
  new QRCode(document.getElementById('qrcode'), {
    text: uk, width: 100, height: 100,
    colorDark: '#000000', colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.H
  });
  setTimeout(function() { window.print(); }, 1000);
};
function goDevam() {
  var f = document.createElement('form');
  f.method = 'POST';
  f.action = BASE_URL + '/panel.php?sayfa=uretim-kit-uret';
  [['urun_kodu',uk],['paket_no',pno],['urun_adi',ua],['kit_baslat','1']].forEach(function(p){
    var i = document.createElement('input');
    i.type='hidden'; i.name=p[0]; i.value=p[1]; f.appendChild(i);
  });
  document.body.appendChild(f); f.submit();
}
</script>
</body>
</html>
