<?php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$gun = $kul['ad_soyad'] ?? 'Sistem';

// Dosya klasörü: bolumler/uretim/proses_formlari/
define('PROSES_UPLOAD_DIR', __DIR__ . '/proses_formlari/');
// DB'de saklanan prefix değişmez: 'proses_formlari/xxxx'
// URL: BASE_URL . '/bolumler/uretim/' . $db_yol

// POST: Yeni proses ekle
if (isset($_POST['prosesekle'])) {
    ob_start(); error_reporting(0); ini_set('display_errors',0); ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');

    $firma     = trim($_POST['firma_adi']   ?? '');
    $stok_kodu = trim($_POST['stok_kodu']   ?? '');
    $proses_no = trim($_POST['proses_no']   ?? '');

    // Stok adını Tiger'dan çek
    $stok_adi = '';
    if ($stok_kodu && !empty($tigerdb_pdo)) {
        try {
            $st = $tigerdb_pdo->prepare("SELECT TOP 1 DEFINITION_ FROM dbo.LG_222_ITEMS WHERE CODE=? AND CARDTYPE IN(1,2,3,4)");
            $st->execute([strtoupper($stok_kodu)]);
            $stok_adi = $st->fetchColumn() ?: '';
        } catch(Throwable $e) {}
    }

    // Dosya yükle
    $dosya_yolu = '';
    if (!empty($_FILES['proses_form_gorseli']['tmp_name'])) {
        if (!is_dir(PROSES_UPLOAD_DIR)) mkdir(PROSES_UPLOAD_DIR, 0755, true);
        $orijinal = $_FILES['proses_form_gorseli']['name'];
        $uzanti   = strtolower(pathinfo($orijinal, PATHINFO_EXTENSION));
        if (!in_array($uzanti, ['pdf','jpg','jpeg','png','doc','docx','xls','xlsx'])) {
            echo json_encode(['ok'=>false,'msg'=>'Desteklenmeyen dosya türü']); exit;
        }
        $yeni_ad = rand(10000000,99999999) . preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $orijinal);
        if (move_uploaded_file($_FILES['proses_form_gorseli']['tmp_name'], PROSES_UPLOAD_DIR . $yeni_ad)) {
            $dosya_yolu = 'proses_formlari/' . $yeni_ad; // DB'de bu şekilde sakla
        } else {
            echo json_encode(['ok'=>false,'msg'=>'Dosya yüklenemedi']); exit;
        }
    }

    try {
        $db->prepare("INSERT INTO proses_formlari
            (firma_adi, stok_kodu, stok_adi, proses_no, proses_form_görseli_dosya_yolu, ekleyen, durum)
            VALUES (?,?,?,?,?,?,'Aktif')")
           ->execute([$firma, $stok_kodu, $stok_adi, $proses_no, $dosya_yolu, $gun]);
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) {
        echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
    }
    exit;
}

// Firma listesi Tiger'dan
$firmalar = [];
if (!empty($tigerdb_pdo)) {
    try {
        $firmalar = $tigerdb_pdo->query("SELECT DISTINCT CLCARD.CODE AS kod, CLCARD.DEFINITION_ AS ad
            FROM dbo.LG_222_02_CLFLINE AS CLFLINE WITH (NOLOCK)
            LEFT JOIN dbo.LG_222_CLCARD AS CLCARD WITH (NOLOCK) ON CLFLINE.CLIENTREF = CLCARD.LOGICALREF
            WHERE CLCARD.DEFINITION_ IS NOT NULL ORDER BY CLCARD.DEFINITION_ ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

$prosesler = [];
try {
    $prosesler = $db->query("SELECT * FROM proses_formlari WHERE durum='Aktif' ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}
?>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1;min-width:0">
    <h1 class="s-bas">📋 Proses Listesi</h1>
    <div class="s-yol">Üretim / <b>Aktif Proses Formları (<?php echo count($prosesler);?>)</b></div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-pasif"
       style="background:#64748B;color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;text-decoration:none">📁 Pasif Formlar</a>
    <button onclick="document.getElementById('prosesEkleModal').style.display='flex'"
       style="background:#065F46;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">➕ Yeni Ekle</button>
  </div>
</div>

<div class="s-body">
<div class="kart" style="padding:0;overflow:visible">
  <div style="overflow-x:auto">
  <table id="prosesTable" class="display nowrap" style="width:100%;font-size:12px;border-collapse:collapse">
    <thead>
      <tr style="background:#1E3A5F!important">
        <th style="padding:8px;color:#fff!important;font-weight:700">No</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">İşlemler</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Firma Adı</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Stok Kodu</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Stok Adı</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Proses No</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Kayıt Tarihi</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Ekleyen</th>
      </tr>
    </thead>
    <tbody>
    <?php $say=0; foreach($prosesler as $p): $say++;
      $dosya_url = $p['proses_form_görseli_dosya_yolu']
        ? BASE_URL . '/bolumler/uretim/' . $p['proses_form_görseli_dosya_yolu']
        : '';
    ?>
      <tr>
        <td style="padding:5px 8px;text-align:center"><?php echo $say;?></td>
        <td style="padding:5px 8px;white-space:nowrap">
          <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-duzenle&id=<?php echo $p['id'];?>"
             style="background:#059669;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none" title="Düzenle">✏️</a>
          <?php if($dosya_url): ?>
          <a href="<?php echo $dosya_url;?>"
             style="background:#0369A1;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none;margin-left:2px" title="İndir" download>⬇️</a>
          <?php endif;?>
          <a href="<?php echo BASE_URL;?>/bolumler/uretim/ajax/proses_sil.php?id=<?php echo $p['id'];?>"
             style="background:#DC2626;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none;margin-left:2px"
             onclick="return confirm('Bu formu pasife al?')">🗑️</a>
        </td>
        <td style="padding:5px 8px"><?php echo htmlspecialchars($p['firma_adi']??'');?></td>
        <td style="padding:5px 8px;font-weight:700"><?php echo htmlspecialchars($p['stok_kodu']??'');?></td>
        <td style="padding:5px 8px"><?php echo htmlspecialchars($p['stok_adi']??'');?></td>
        <td style="padding:5px 8px;font-weight:700;color:#065F46"><?php echo htmlspecialchars($p['proses_no']??'');?></td>
        <td style="padding:5px 8px"><?php echo substr($p['kayit_tarihi']??'',0,10);?></td>
        <td style="padding:5px 8px"><?php echo htmlspecialchars($p['ekleyen']??'');?></td>
      </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>
</div>

<!-- EKLE MODALİ -->
<div id="prosesEkleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:12px;width:100%;max-width:540px;box-shadow:0 20px 60px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
  <div style="background:linear-gradient(135deg,#1E3A5F,#2d5986);border-radius:12px 12px 0 0;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0">
    <div style="color:#fff;font-size:14px;font-weight:700">➕ Proses Formu Ekle</div>
    <button onclick="document.getElementById('prosesEkleModal').style.display='none'"
            style="background:rgba(255,255,255,.15);border:none;color:#fff;width:28px;height:28px;border-radius:6px;cursor:pointer">✕</button>
  </div>
  <form id="prosesEkleForm" method="POST" enctype="multipart/form-data" style="padding:18px">
    <input type="hidden" name="prosesekle" value="1">

    <label style="display:block;margin-bottom:12px">
      <span style="font-size:12px;font-weight:600;color:#374151">Firma</span>
      <select name="firma_adi" id="firmaSelect"
              style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:8px 10px;font-size:13px">
        <option value="">— Seçin —</option>
        <?php foreach($firmalar as $f): ?>
        <option value="<?php echo htmlspecialchars($f['ad']);?>"><?php echo htmlspecialchars($f['ad']??'');?></option>
        <?php endforeach;?>
      </select>
    </label>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
      <label>
        <span style="font-size:12px;font-weight:600;color:#374151">Stok Kodu</span>
        <input type="text" name="stok_kodu" id="stokKoduInput" placeholder="Stok kodu" required
          onblur="prosesStokAdiCek(this.value)"
          style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:8px 10px;font-size:13px;box-sizing:border-box">
      </label>
      <label>
        <span style="font-size:12px;font-weight:600;color:#374151">Proses No</span>
        <input type="text" name="proses_no" placeholder="PRS00001" required
          style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:8px 10px;font-size:13px;box-sizing:border-box">
      </label>
    </div>

    <label style="display:block;margin-bottom:12px">
      <span style="font-size:12px;font-weight:600;color:#374151">Stok Adı <small style="font-weight:400;color:#9CA3AF">(otomatik)</small></span>
      <input type="text" name="stok_adi" id="stokAdiInput" readonly
        style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:8px 10px;font-size:13px;background:#F9FAFB;box-sizing:border-box">
    </label>

    <label style="display:block;margin-bottom:16px">
      <span style="font-size:12px;font-weight:600;color:#374151">Proses Formu</span>
      <input type="file" name="proses_form_gorseli" required accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"
        style="width:100%;margin-top:4px;border:1px solid #D1D5DB;border-radius:6px;padding:8px 10px;font-size:13px;box-sizing:border-box">
    </label>

    <div id="prosesEkleMsg" style="display:none;margin-bottom:12px;padding:8px 12px;border-radius:6px;font-size:12px"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button type="button" onclick="document.getElementById('prosesEkleModal').style.display='none'"
        style="background:#F1F5F9;color:#374151;border:1px solid #D1D5DB;padding:8px 18px;border-radius:6px;font-size:13px;cursor:pointer">İptal</button>
      <button type="submit" id="prosesEkleBtn"
        style="background:#065F46;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer">💾 Kaydet</button>
    </div>
  </form>
</div>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<style>
#prosesTable thead th {
    background: #1E3A5F !important;
    color: #ffffff !important;
    font-weight: 700 !important;
    border-bottom: 2px solid #2d5986 !important;
}
#prosesTable thead th.sorting,
#prosesTable thead th.sorting_asc,
#prosesTable thead th.sorting_desc {
    background: #1E3A5F !important;
    color: #ffffff !important;
}
</style>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
$(function(){
  $('#prosesTable').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    order:[[0,'desc']], pageLength:50
  });
});
function prosesStokAdiCek(kod){
  if(!kod) return;
  fetch('<?php echo BASE_URL;?>/bolumler/uretim/ajax/proses_stok_adi.php?kod='+encodeURIComponent(kod),
    {headers:{'X-Requested-With':'XMLHttpRequest'}})
    .then(r=>r.json()).then(d=>{ document.getElementById('stokAdiInput').value=d.stok_adi||''; });
}
document.getElementById('prosesEkleForm').addEventListener('submit',function(e){
  e.preventDefault();
  var btn=document.getElementById('prosesEkleBtn');
  var msg=document.getElementById('prosesEkleMsg');
  btn.disabled=true; btn.textContent='⏳...';
  fetch('',{method:'POST',body:new FormData(this),headers:{'X-Requested-With':'XMLHttpRequest'}})
    .then(r=>r.json()).then(d=>{
      btn.disabled=false; btn.textContent='💾 Kaydet';
      if(d.ok){
        msg.style.cssText='display:block;background:#D1FAE5;color:#065F46;padding:8px 12px;border-radius:6px;font-size:12px;margin-bottom:12px';
        msg.textContent='✅ Eklendi. Yenileniyor...';
        setTimeout(()=>location.reload(),1200);
      } else {
        msg.style.cssText='display:block;background:#FEE2E2;color:#991B1B;padding:8px 12px;border-radius:6px;font-size:12px;margin-bottom:12px';
        msg.textContent='❌ '+(d.msg||'Hata');
      }
    }).catch(()=>{btn.disabled=false;btn.textContent='💾 Kaydet';});
});
</script>
