<?php
/**
 * JETONE.PRO — Verimlilik Kontrol Listesi (Enjeksiyon)
 * bolumler/uretim/verim_liste.php
 *
 * panel.php sayfaMap_ozel:
 *   'uretim-verim-liste' => 'bolumler/uretim/verim_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();

// ── Tüm kayıtlar ─────────────────────────────────────────────────────────────
try {
    $kayitlar = $db->query("
        SELECT * FROM verimlilik
        WHERE makina_kodu LIKE 'EN-%'
        ORDER BY tarih DESC, vardiya ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $kayitlar = []; }

// ── Son 7 gün: günlük vardiya ortalaması ─────────────────────────────────────
try {
    $vrd_rows = $db->query("
        SELECT DATE(tarih) AS gun, vardiya,
               ROUND(AVG(verimlilik), 2) AS ort
        FROM verimlilik
        WHERE makina_kodu LIKE 'EN-%'
          AND tarih >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY DATE(tarih), vardiya
        ORDER BY gun DESC, vardiya ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
    $vrd_map = [];
    foreach ($vrd_rows as $r) $vrd_map[$r['gun']][$r['vardiya']] = $r['ort'];
} catch (Throwable $e) { $vrd_map = []; }

// ── Son 7 gün: personel bazlı günlük ortalama ────────────────────────────────
try {
    $per_rows = $db->query("
        SELECT calisan_personel, DATE(tarih) AS gun,
               ROUND(AVG(verimlilik), 2) AS ort
        FROM verimlilik
        WHERE makina_kodu LIKE 'EN-%'
          AND tarih >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY calisan_personel, DATE(tarih)
        ORDER BY calisan_personel, gun DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
    $per_map = [];
    $per_list = [];
    foreach ($per_rows as $r) {
        $per_map[$r['calisan_personel']][$r['gun']] = $r['ort'];
        $per_list[$r['calisan_personel']] = true;
    }
    $per_list = array_keys($per_list);
    sort($per_list);
} catch (Throwable $e) { $per_map = []; $per_list = []; }

// ── Yardımcı: verimlilik rengine göre stil ───────────────────────────────────
function vr_stil(float $v): string {
    if ($v >= 90) return 'color:var(--bas);font-weight:800';
    if ($v >= 70) return 'color:var(--uya);font-weight:700';
    return 'color:var(--hat);font-weight:700';
}
function vr_roz(float $v): string {
    if ($v >= 90) return 'background:#D1FAE5;color:#065F46';
    if ($v >= 70) return 'background:#FEF9C3;color:#92400E';
    return 'background:#FEE2E2;color:#991B1B';
}
function fr_stil(float $f): string {
    if ($f <= 3) return 'color:var(--bas);font-weight:700';
    if ($f <= 5) return 'color:var(--uya);font-weight:700';
    return 'color:var(--hat);font-weight:700';
}
?>

<style>
/* Dikey scroll tablolarında başlık sabit */
.scroll-tablo thead th {
    position: sticky;
    top: 0;
    z-index: 2;
    background: #1E3A5F !important;
    color: #fff !important;
}
.scroll-tablo tfoot th {
    position: sticky;
    bottom: 0;
    z-index: 2;
    background: var(--kenar-a);
}
</style>

<!-- ── Başlık ─────────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">📈 Verimlilik Listesi</h1>
    <div class="s-yol">Üretim / <b>Enjeksiyon Verimlilik Kontrol</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste-tumu" class="btn btn-b btn-sm">📊 Tümü</a>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste-montaj" class="btn btn-b btn-sm">🔧 Montaj</a>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-personel" class="btn btn-b btn-sm">👤 Aylık Personel</a>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-ekle" class="btn btn-t">
    ➕ Yeni Giriş
  </a>
</div>
</div>

<div class="s-body">

<!-- ════════════════════════════════════════════════════════════
     BÖLÜM 1 — Son 7 Gün Vardiya Ortalaması
════════════════════════════════════════════════════════════ -->
<div class="kart" style="margin-bottom:20px">
  <div class="kart-ust">
    <div class="kart-bas">📅 Son 7 Gün — Vardiya Bazlı Ortalama Verimlilik</div>
  </div>
  <div style="overflow-x:auto;overflow-y:auto;max-height:320px">
    <table class="tablo scroll-tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F">
          <th style="color:#fff">Tarih</th>
          <th style="color:#fff;text-align:center">1. Vardiya<br><span style="font-size:10px;opacity:.75">08:00–16:00</span></th>
          <th style="color:#fff;text-align:center">2. Vardiya<br><span style="font-size:10px;opacity:.75">16:00–24:00</span></th>
          <th style="color:#fff;text-align:center">3. Vardiya<br><span style="font-size:10px;opacity:.75">24:00–08:00</span></th>
        </tr>
      </thead>
      <tbody>
        <?php for ($i = 0; $i < 7; $i++):
          $gun = date('Y-m-d', strtotime("-{$i} day"));
          $gstr = date('d.m.Y', strtotime($gun));
          $bugun = ($i === 0);
        ?>
        <tr style="<?= $bugun ? 'background:#FFF7ED;border-left:3px solid var(--t)' : '' ?>">
          <td style="font-weight:<?= $bugun ? '800' : '600' ?>;white-space:nowrap">
            <?= $gstr ?><?= $bugun ? ' <span style="background:var(--t-a);color:var(--t);font-size:10px;padding:1px 6px;border-radius:10px;font-weight:700;margin-left:4px">Bugün</span>' : '' ?>
          </td>
          <?php for ($v = 1; $v <= 3; $v++):
            $ort = $vrd_map[$gun][$v] ?? null;
          ?>
          <td style="text-align:center">
            <?php if ($ort !== null): ?>
              <span class="roz" style="<?= vr_roz((float)$ort) ?>;padding:3px 12px;font-size:13px">
                <?= number_format((float)$ort, 1) ?>%
              </span>
            <?php else: ?>
              <span style="color:var(--m3);font-size:12px">—</span>
            <?php endif; ?>
          </td>
          <?php endfor; ?>
        </tr>
        <?php endfor; ?>
      </tbody>
      <tfoot>
        <?php
        // 7 günlük her vardiya genel ortalaması
        $genel = [1=>[], 2=>[], 3=>[]];
        foreach ($vrd_map as $g => $vd) {
            foreach ($vd as $v => $o) $genel[$v][] = (float)$o;
        }
        ?>
        <tr style="background:var(--kenar-a);font-weight:800">
          <th style="font-size:12px;color:var(--m2)">7 Günlük Ort.</th>
          <?php for ($v = 1; $v <= 3; $v++):
            $arr = $genel[$v];
            $ort = count($arr) ? array_sum($arr)/count($arr) : null;
          ?>
          <th style="text-align:center">
            <?php if ($ort !== null): ?>
              <span style="<?= vr_stil($ort) ?>;font-size:14px"><?= number_format($ort, 1) ?>%</span>
            <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
          </th>
          <?php endfor; ?>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<!-- ════════════════════════════════════════════════════════════
     BÖLÜM 2 — Son 7 Gün Personel Bazlı
════════════════════════════════════════════════════════════ -->
<?php if (!empty($per_list)): ?>
<div class="kart" style="margin-bottom:20px">
  <div class="kart-ust">
    <div class="kart-bas">👤 Son 7 Gün — Personel Bazlı Ortalama Verimlilik</div>
  </div>
  <div style="overflow-x:auto;overflow-y:auto;max-height:380px">
    <table class="tablo scroll-tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F">
          <th style="color:#fff;white-space:nowrap">Personel</th>
          <?php for ($i = 0; $i < 7; $i++): ?>
          <th style="color:#fff;text-align:center;white-space:nowrap;font-size:11px">
            <?= date('d.m', strtotime("-{$i} day")) ?>
            <?= $i === 0 ? '<br><span style="font-size:9px;opacity:.8">Bugün</span>' : '' ?>
          </th>
          <?php endfor; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($per_list as $per):
          $satirlar = $per_map[$per] ?? [];
        ?>
        <tr>
          <td style="font-weight:700;white-space:nowrap;min-width:150px"><?= htmlspecialchars($per) ?></td>
          <?php for ($i = 0; $i < 7; $i++):
            $gun = date('Y-m-d', strtotime("-{$i} day"));
            $ort = $satirlar[$gun] ?? null;
          ?>
          <td style="text-align:center">
            <?php if ($ort !== null): ?>
              <span style="<?= vr_stil((float)$ort) ?>;font-size:13px"><?= number_format((float)$ort, 1) ?>%</span>
            <?php else: ?>
              <span style="color:var(--m3);font-size:12px">—</span>
            <?php endif; ?>
          </td>
          <?php endfor; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <?php
        // Günlük tüm personel ortalaması
        $gun_ort = [];
        foreach ($per_map as $p => $gunler) {
            foreach ($gunler as $g => $o) {
                $gun_ort[$g][] = (float)$o;
            }
        }
        ?>
        <tr style="background:var(--kenar-a);font-weight:800">
          <th style="font-size:12px;color:var(--m2)">Günlük Ort.</th>
          <?php for ($i = 0; $i < 7; $i++):
            $gun = date('Y-m-d', strtotime("-{$i} day"));
            $arr = $gun_ort[$gun] ?? [];
            $ort = count($arr) ? array_sum($arr)/count($arr) : null;
          ?>
          <th style="text-align:center">
            <?php if ($ort !== null): ?>
              <span style="<?= vr_stil($ort) ?>;font-size:13px"><?= number_format($ort, 1) ?>%</span>
            <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
          </th>
          <?php endfor; ?>
        </tr>
      </tfoot>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ════════════════════════════════════════════════════════════
     BÖLÜM 3 — Tüm Kayıtlar
════════════════════════════════════════════════════════════ -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:800;font-size:14px">
      🗂 Tüm Verimlilik Kayıtları
      <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($kayitlar) ?> kayıt</span>
    </div>
  </div>
  <div style="overflow-x:auto">
    <table id="verimListeTablo" class="tablo" style="width:100%">
      <thead>
        <tr style="background:#1E3A5F !important">
          <th style="color:#fff !important">Tarih</th>
          <th style="color:#fff !important">Makina</th>
          <th style="color:#fff !important">Ürün Kodu</th>
          <th style="color:#fff !important">Ürün Adı</th>
          <th style="color:#fff !important">Personel</th>
          <th style="color:#fff !important;text-align:center">Vardiya</th>
          <th style="color:#fff !important;text-align:right">Üretim</th>
          <th style="color:#fff !important;text-align:right">Duruş (dk)</th>
          <th style="color:#fff !important;text-align:right">Net (dk)</th>
          <th style="color:#fff !important;text-align:center">Verimlilik</th>
          <th style="color:#fff !important;text-align:right">Fire</th>
          <th style="color:#fff !important;text-align:center">Fire %</th>
          <th style="color:#fff !important;text-align:center">İşlem</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($kayitlar as $k):
          $ver  = (float)$k['verimlilik'];
          $fire = (float)($k['fire_oranı'] ?? 0);
          $vrd_etiket = ['1'=>'1. Vardiya','2'=>'2. Vardiya','3'=>'3. Vardiya'];
        ?>
        <tr>
          <td style="white-space:nowrap;font-size:12px"><?= date('d.m.Y', strtotime($k['tarih'])) ?></td>
          <td style="font-weight:700;white-space:nowrap"><?= htmlspecialchars($k['makina_kodu']) ?></td>
          <td>
            <code style="background:rgba(0,0,0,.05);padding:1px 6px;border-radius:3px;font-size:11px;font-weight:700">
              <?= htmlspecialchars($k['stok_kodu']) ?>
            </code>
          </td>
          <td style="min-width:140px;font-size:12px"><?= htmlspecialchars($k['stok_adi'] ?? '') ?></td>
          <td style="white-space:nowrap;font-size:12px"><?= htmlspecialchars($k['calisan_personel']) ?></td>
          <td style="text-align:center">
            <span class="roz" style="background:var(--kenar-a);color:var(--m);font-size:11px">
              <?= htmlspecialchars($vrd_etiket[$k['vardiya']] ?? $k['vardiya']) ?>
            </span>
          </td>
          <td style="text-align:right;font-weight:600"><?= number_format((int)$k['uretim_miktari']) ?></td>
          <td style="text-align:right"><?= number_format((float)$k['durus'], 1) ?></td>
          <td style="text-align:right"><?= number_format((float)$k['net_calisma_suresi'], 1) ?></td>
          <td style="text-align:center">
            <span class="roz" style="<?= vr_roz($ver) ?>;padding:3px 10px">
              <?= number_format($ver, 1) ?>%
            </span>
          </td>
          <td style="text-align:right"><?= (int)($k['fire_miktar'] ?? 0) ?></td>
          <td style="text-align:center;<?= fr_stil($fire) ?>"><?= number_format($fire, 1) ?>%</td>
          <td style="text-align:center">
            <button onclick="verimSil(<?= (int)$k['id'] ?>)"
                    class="btn btn-sm"
                    style="background:var(--hat-a);color:var(--hat);border:none;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer;border-radius:4px">
              🗑 Sil
            </button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <th>Tarih</th><th>Makina</th><th>Ürün Kodu</th><th>Ürün Adı</th>
          <th>Personel</th><th>Vardiya</th><th>Üretim</th><th>Duruş</th>
          <th>Net</th><th>Verimlilik</th><th>Fire</th><th>Fire %</th><th>İşlem</th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

</div><!-- /s-body -->

<!-- ── Scripts ─────────────────────────────────────────────────────────────── -->
<script>
$(document).ready(function(){
    document.title = 'Verimlilik Listesi';

    $('#verimListeTablo').DataTable({
        language: { url: 'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
        scrollY: 600, scrollX: true, scrollCollapse: true, paging: false,
        dom: 'Bfrtip',
        order: [[0, 'desc']],
        buttons: [
            { extend: 'excelHtml5', text: '📊 Excel', className: 'btn-dt',
              filename: 'Verimlilik_<?= date('Ymd') ?>' },
            { extend: 'print', text: '🖨 Yazdır', className: 'btn-dt' }
        ],
        initComplete: function(){
            this.api().columns([0,1,2,3,4,5,9,11]).every(function(){
                var col = this;
                var sel = $('<select class="dt-filtre-sel"><option value=""></option></select>')
                    .appendTo($(col.footer()).empty())
                    .on('change', function(){
                        var v = $.fn.dataTable.util.escapeRegex($(this).val());
                        col.search(v ? '^'+v+'$' : '', true, false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var t = $('<div/>').html(d).text();
                    sel.append('<option value="'+t+'">'+(t.length>30?t.substr(0,30)+'...':t)+'</option>');
                });
            });
        }
    });

    /* thead renk fix */
    $('#verimListeTablo thead th').css({ 'background-color':'#1E3A5F', 'color':'#fff' });
});

/* Silme işlemi */
function verimSil(id) {
    if (!confirm('Bu kaydı silmek istediğinize emin misiniz?')) return;
    fetch('<?= BASE_URL ?>/bolumler/uretim/ajax/verim_sil.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest',
                   'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + encodeURIComponent(id)
    })
    .then(function(r){ return r.json(); })
    .then(function(d){
        if (d.ok) {
            alert('✅ Kayıt silindi.');
            location.reload();
        } else {
            alert('❌ ' + d.msg);
        }
    })
    .catch(function(){ alert('Bağlantı hatası!'); });
}
</script>
