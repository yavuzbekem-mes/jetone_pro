<?php
// Sayfa ayarlar bölümüne taşındı
header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/panel.php?sayfa=ayarlar-token');
exit;
