<?php
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$prosesler = [];
try {
    $prosesler = $db->query("SELECT * FROM proses_formlari WHERE durum='Pasif' ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}
?>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1;min-width:0">
    <h1 class="s-bas">📁 Pasif Proses Formları</h1>
    <div class="s-yol">Üretim / <b>Pasif Proses Formları</b></div>
  </div>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-listesi"
     style="background:#065F46;color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;text-decoration:none">✅ Aktif Formlar</a>
</div>

<div class="s-body">
<div class="kart" style="padding:0;overflow:visible">
  <div style="overflow-x:auto">
  <table id="prosesTablePasif" class="display nowrap" style="width:100%;font-size:12px;border-collapse:collapse">
    <thead>
      <tr style="background:#1E3A5F!important">
        <th style="padding:8px;color:#fff!important;font-weight:700">No</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">İşlemler</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Firma Adı</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Stok Kodu</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Stok Adı</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Proses No</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Kayıt Tarihi</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Ekleyen</th>
        <th style="padding:8px;color:#fff!important;font-weight:700">Güncelleyen</th>
      </tr>
    </thead>
    <tbody>
    <?php $say=0; foreach($prosesler as $p): $say++; ?>
      <tr>
        <td style="text-align:center"><?php echo $say;?></td>
        <td style="white-space:nowrap">
          <a href="<?php echo BASE_URL;?>/panel.php?sayfa=uretim-proses-duzenle&id=<?php echo $p['id'];?>"
             style="background:#059669;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none" title="Düzenle">✏️</a>
          <?php if($p['proses_form_görseli_dosya_yolu']): ?>
          <a href="<?php echo BASE_URL.'/bolumler/uretim/'.$p['proses_form_görseli_dosya_yolu'];?>"
             style="background:#0369A1;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none;margin-left:2px" download>⬇️</a>
          <?php endif;?>
          <a href="<?php echo BASE_URL;?>/bolumler/uretim/ajax/proses_sil.php?id=<?php echo $p['id'];?>&pasif=1"
             style="background:#DC2626;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;text-decoration:none;margin-left:2px"
             onclick="return confirm('Kalıcı olarak silinsin mi?')">🗑️</a>
        </td>
        <td><?php echo htmlspecialchars($p['firma_adi']??'');?></td>
        <td style="font-weight:700"><?php echo htmlspecialchars($p['stok_kodu']??'');?></td>
        <td><?php echo htmlspecialchars($p['stok_adi']??'');?></td>
        <td style="font-weight:700;color:#64748B"><?php echo htmlspecialchars($p['proses_no']??'');?></td>
        <td><?php echo substr($p['kayit_tarihi']??'',0,10);?></td>
        <td><?php echo htmlspecialchars($p['ekleyen']??'');?></td>
        <td><?php echo htmlspecialchars($p['guncelleyen']??'');?></td>
      </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<style>
#prosesTablePasif thead th {
    background: #1E3A5F !important;
    color: #ffffff !important;
    font-weight: 700 !important;
    border-bottom: 2px solid #2d5986 !important;
}
#prosesTablePasif thead th.sorting,
#prosesTablePasif thead th.sorting_asc,
#prosesTablePasif thead th.sorting_desc {
    background: #1E3A5F !important;
    color: #ffffff !important;
}
</style>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
$(function() {
  $('#prosesTablePasif').DataTable({
    language: { url: 'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    order: [[0,'desc']], pageLength: 25
  });
});
</script>
