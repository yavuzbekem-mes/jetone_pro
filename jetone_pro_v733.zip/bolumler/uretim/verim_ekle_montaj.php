<?php
/**
 * JETONE.PRO — Montaj Verim Girişi
 * bolumler/uretim/verim_ekle_montaj.php
 *
 * panel.php sayfaMap_ozel:
 *   'uretim-verim-montaj' => 'bolumler/uretim/verim_ekle_montaj.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$kul      = Auth::kullanici();
$tiger_ok = ($tigerdb_pdo !== null);

// ── Hat listesi ───────────────────────────────────────────────────────────────
$hat_listesi = [
    'EL İŞÇİLİĞİ 1'   => 'EL İŞÇİLİĞİ 1 — ABX CAM',
    'EL İŞÇİLİĞİ 5'   => 'EL İŞÇİLİĞİ 5 — BX OPAK',
    'EL İŞÇİLİĞİ 9'   => 'EL İŞÇİLİĞİ 9 — ABM KKLI',
    'EL İŞÇİLİĞİ 10'  => 'EL İŞÇİLİĞİ 10 — ABM KKSIZ',
    'MT-01'            => 'MONTAJ 1',
    'EL İŞÇİLİĞİ 6'   => 'EL İŞÇİLİĞİ 6 — ÇAY/PROYO',
    'EL İŞÇİLİĞİ 7'   => 'EL İŞÇİLİĞİ 7 — ŞASE',
    'EL İŞÇİLİĞİ 8'   => 'EL İŞÇİLİĞİ 8 — TRIM',
    'EL İŞÇİLİĞİ 8.1' => 'EL İŞÇİLİĞİ 8.1 — INSTALLATION/DOOR',
    'EL İŞÇİLİĞİ 8.2' => 'EL İŞÇİLİĞİ 8.2 — FAN',
    'EL İŞÇİLİĞİ 8.3' => 'EL İŞÇİLİĞİ 8.3 — SEAL SURF',
    'EL İŞÇİLİĞİ 4'   => 'EL İŞÇİLİĞİ 4 — Eİ',
    'EL İŞÇİLİĞİ 3'   => 'EL İŞÇİLİĞİ 3 — ESANJÖR',
    'SR-01'            => 'SERİGRAFİ',
    'FSN-01'           => 'FASON',
    'KRM-01'           => 'KIRMA',
    'TERM-01'          => 'TERMOFORM',
];

$secili_hat = trim($_GET['hat'] ?? '');
$hat_adi    = $hat_listesi[$secili_hat] ?? $secili_hat;

// ── Tiger: personel listesi (hat seçiliyse) ───────────────────────────────────
$calisanlar = [];
if ($secili_hat && $tiger_ok) {
    try {
        $st = $tigerdb_pdo->query("
            SELECT NAME FROM LG_222_EMPLOYEE WITH(NOLOCK)
            WHERE ACTIVE = 0 ORDER BY NAME
        ");
        $calisanlar = $st->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {}
}
?>

<!-- ── Başlık ─────────────────────────────────────────────────────────────── -->
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 Montaj Verim Girişi</h1>
    <div class="s-yol">Üretim /
      <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-montaj" style="color:var(--t)">Montaj Verim</a>
      <?php if ($secili_hat): ?>
        / <b><?= htmlspecialchars($hat_adi) ?></b>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste" class="btn btn-b btn-sm">📋 Kayıtlar</a>
    <?php if ($secili_hat): ?>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-montaj" class="btn btn-b btn-sm">← Hat Değiştir</a>
    <?php endif; ?>
  </div>
</div>

<div class="s-body">

<?php if (!$tiger_ok): ?>
<div style="background:var(--hat-a);color:var(--hat);border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-size:12.5px;font-weight:700">
  ⚠️ Tiger ERP bağlantısı yok — çevrim/personel bilgileri yüklenemedi.
</div>
<?php endif; ?>

<?php if (!$secili_hat): ?>
<!-- ════════════════════════════════════════════════════════════
     HAT SEÇİM EKRANI
════════════════════════════════════════════════════════════ -->
<div class="kart" style="border-top:4px solid var(--t)">
  <div style="font-size:15px;font-weight:800;margin-bottom:16px">
    🏭 Verim Girişi İçin Hat Seçiniz
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
    <?php foreach ($hat_listesi as $kd => $ad): ?>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-montaj&hat=<?= urlencode($kd) ?>"
       style="display:flex;align-items:center;gap:10px;padding:12px 14px;border:1.5px solid var(--kenar);border-radius:var(--r);background:var(--yuzey);text-decoration:none;color:var(--m);font-size:13px;font-weight:600;transition:all .15s"
       onmouseover="this.style.borderColor='var(--t)';this.style.background='var(--t-a)'"
       onmouseout="this.style.borderColor='var(--kenar)';this.style.background='var(--yuzey)'">
      <span style="font-size:18px;color:var(--t)">⚙️</span>
      <?= htmlspecialchars($ad) ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<?php else: ?>
<!-- ════════════════════════════════════════════════════════════
     VERİM GİRİŞ FORMU
════════════════════════════════════════════════════════════ -->
<form id="verimForm">
  <input type="hidden" name="hat"     value="<?= htmlspecialchars($secili_hat) ?>">
  <input type="hidden" name="ekleyen" value="<?= htmlspecialchars($kul['ad_soyad'] ?? $kul['email'] ?? '') ?>">

  <!-- Genel Bilgiler Kartı -->
  <div class="kart" style="margin-bottom:16px;border-left:4px solid var(--t)">
    <div style="font-size:14px;font-weight:800;margin-bottom:14px">
      🏭 <?= htmlspecialchars($hat_adi) ?> — Genel Bilgiler
    </div>

    <div class="form-grid-3">
      <div class="form-grup">
        <label class="form-et">Vardiya <span class="zorunlu">*</span></label>
        <select class="form-alan" name="vardiya" id="vardiyaSelect" required>
          <option value="1">1. Vardiya — 08:00-16:00</option>
          <option value="2">2. Vardiya — 16:00-24:00</option>
          <option value="3">3. Vardiya — 24:00-08:00</option>
        </select>
      </div>
      <div class="form-grup">
        <label class="form-et">Tarih <span class="zorunlu">*</span></label>
        <input class="form-alan" name="tarih" id="tarihInput" type="date"
               value="<?= date('Y-m-d') ?>" required>
      </div>
      <div class="form-grup">
        <label class="form-et">Duruş Süresi (Dakika)</label>
        <input class="form-alan" name="durus" id="durusInput"
               type="number" step="0.01" min="0" value="0" required>
      </div>
    </div>

    <!-- Özet göstergeler -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:10px">
      <div style="text-align:center;background:var(--bil-a);border:1px solid var(--bil);border-radius:var(--r);padding:10px">
        <div style="font-size:20px;font-weight:800;color:var(--bil)" id="netSureEl">480</div>
        <div style="font-size:11px;color:var(--m2)">Net Çalışma (dk)</div>
      </div>
      <div style="text-align:center;background:var(--bas-a);border:1px solid var(--bas);border-radius:var(--r);padding:10px">
        <div style="font-size:20px;font-weight:800;color:var(--bas)" id="toplamTeorikEl">0.0</div>
        <div style="font-size:11px;color:var(--m2)">Toplam Teorik (dk)</div>
      </div>
      <div style="text-align:center;background:var(--uya-a);border:1px solid var(--uya);border-radius:var(--r);padding:10px">
        <div style="font-size:20px;font-weight:800;color:var(--uya)" id="toplamVerimEl">—</div>
        <div style="font-size:11px;color:var(--m2)">Toplam Verimlilik</div>
      </div>
    </div>

    <!-- Personel Seçimi (9 adet) -->
    <div style="margin-top:16px;border-top:1px solid var(--kenar);padding-top:14px">
      <div style="font-size:13px;font-weight:700;margin-bottom:10px">
        👥 Personeller
        <span id="personelSayac" style="background:var(--bil-a);color:var(--bil);border-radius:20px;padding:2px 10px;font-size:11px;margin-left:6px;font-weight:700">0 seçili</span>
      </div>
      <div class="form-grid-3" style="gap:8px">
        <?php for ($p = 1; $p <= 9; $p++): ?>
        <div class="form-grup" style="margin-bottom:8px">
          <label class="form-et" style="font-size:11px">
            <?= $p ?>. Personel
            <?= $p === 1 ? '<span class="zorunlu">*</span>' : '<span style="font-weight:400;color:var(--m2)">(ops.)</span>' ?>
          </label>
          <select class="form-alan personel-select" name="calisan_personel[]"
                  style="padding:6px 10px;font-size:12px"
                  <?= $p === 1 ? 'required' : '' ?>>
            <option value="">— Seçiniz —</option>
            <?php foreach ($calisanlar as $cal): ?>
            <option value="<?= htmlspecialchars($cal) ?>"><?= htmlspecialchars($cal) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <!-- Ürün Satırları Kartı -->
  <div class="kart" style="margin-bottom:16px;padding:0;overflow:hidden">
    <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:var(--kenar-a)">
      <div style="font-size:14px;font-weight:800">📦 Üretilen Ürünler</div>
      <button type="button" id="urunEkleBtn" class="btn btn-t btn-sm">➕ Ürün Ekle</button>
    </div>

    <!-- Kolon başlıkları (desktop) -->
    <div id="kolonBasliklar" style="display:none;padding:8px 16px;background:#F8FAFC;border-bottom:1px solid var(--kenar)">
      <div style="display:grid;grid-template-columns:140px 1fr 80px 60px 90px 70px 70px 90px 40px;gap:8px;font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;letter-spacing:.05em">
        <div>Ürün Kodu</div>
        <div>Ürün Adı</div>
        <div>Çevrim (sn)</div>
        <div>Göz</div>
        <div>Üretilen</div>
        <div>Fire</div>
        <div>Personel</div>
        <div>Teorik (dk)</div>
        <div></div>
      </div>
    </div>

    <div id="urunSatirlar" style="padding:12px 16px"></div>

    <div id="boslukMesaj" style="text-align:center;padding:40px;color:var(--m3)">
      <div style="font-size:32px;margin-bottom:8px">📦</div>
      <div style="font-size:13px">Ürün eklemek için <strong>Ürün Ekle</strong> butonuna tıklayın.</div>
    </div>
  </div>

  <!-- Kaydet / İptal -->
  <div class="form-footer" style="justify-content:flex-start;gap:10px">
    <button type="button" id="kaydetBtn" class="btn btn-t" style="min-width:140px">
      💾 Kaydet
    </button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-montaj" class="btn btn-b">İptal</a>
  </div>

</form>
<?php endif; ?>

</div><!-- /s-body -->

<script>
document.addEventListener('DOMContentLoaded', function () {

  /* ── Vardiya otomatik seç ── */
  var vs = document.getElementById('vardiyaSelect');
  if (vs) {
    var h = new Date().getHours();
    vs.value = (h >= 8 && h < 16) ? '1' : (h >= 16) ? '2' : '3';
  }

  /* ── Net süre hesabı ── */
  var durusEl   = document.getElementById('durusInput');
  var netSureEl = document.getElementById('netSureEl');
  function getNet() { return 480 - (parseFloat(durusEl ? durusEl.value : 0) || 0); }
  function refreshNet() {
    if (netSureEl) netSureEl.textContent = getNet().toFixed(0);
    document.querySelectorAll('[id^="ncs_"]').forEach(function(e){ e.value = getNet(); });
    refreshToplamlar();
  }
  if (durusEl) durusEl.addEventListener('input', refreshNet);
  refreshNet();

  /* ── Personel sayacı ── */
  function getPersonelSayisi() {
    var n = 0;
    document.querySelectorAll('.personel-select').forEach(function(s){ if (s.value) n++; });
    return n || 1;
  }
  function refreshPersonelSayac() {
    var n = getPersonelSayisi();
    var el = document.getElementById('personelSayac');
    if (el) el.textContent = n + ' seçili';
    document.querySelectorAll('.urun-satir').forEach(function(s) {
      var psEl = document.getElementById('kps_' + s.dataset.idx);
      if (psEl) psEl.value = n;
      hesapla(s.dataset.idx);
    });
    refreshToplamlar();
  }
  document.querySelectorAll('.personel-select').forEach(function(s) {
    s.addEventListener('change', refreshPersonelSayac);
  });

  /* ── Satır yönetimi ── */
  var idx        = 0;
  var satirlarDiv = document.getElementById('urunSatirlar');
  var boslukDiv   = document.getElementById('boslukMesaj');
  var kolonDiv    = document.getElementById('kolonBasliklar');

  document.getElementById('urunEkleBtn')?.addEventListener('click', function(){ ekle(); });

  function ekle() {
    if (boslukDiv) boslukDiv.style.display = 'none';
    if (kolonDiv)  kolonDiv.style.display  = 'block';
    var i  = idx++;
    var d  = document.createElement('div');
    d.className   = 'urun-satir';
    d.dataset.idx = i;
    d.style.cssText = 'border:1px solid var(--kenar);border-radius:var(--r);padding:10px;margin-bottom:8px;background:var(--yuzey)';
    d.innerHTML = satirHtml(i);
    satirlarDiv.appendChild(d);

    /* Sil */
    d.querySelector('.sil-btn').addEventListener('click', function() {
      d.remove();
      refreshToplamlar();
      if (!satirlarDiv.children.length) {
        if (boslukDiv) boslukDiv.style.display = '';
        if (kolonDiv)  kolonDiv.style.display  = 'none';
      }
    });

    /* Ürün kodu AJAX (debounce 600ms) */
    var timer = null;
    d.querySelector('.kod-input').addEventListener('input', function() {
      this.value = this.value.toUpperCase();
      clearTimeout(timer);
      if (this.value.length < 3) return;
      var val = this.value;
      timer = setTimeout(function(){ ajaxCevrim(i, val); }, 600);
    });

    /* Anlık hesap */
    ['cevrim-i','goz-i','uretim-i','fire-i','pers-i'].forEach(function(cls) {
      var el = d.querySelector('.' + cls);
      if (el) el.addEventListener('input', function(){ hesapla(i); refreshToplamlar(); });
    });
  }

  /* ── Satır HTML ── */
  function satirHtml(i) {
    var ps  = getPersonelSayisi();
    var net = getNet();
    return [
      '<div style="display:grid;grid-template-columns:140px 1fr 80px 60px 90px 70px 70px 90px 40px;gap:8px;align-items:end;flex-wrap:wrap" class="satir-grid">',

        /* Ürün kodu */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Ürün Kodu</div>',
          '<div style="position:relative">',
            '<input type="text" name="urunler['+i+'][stok_kodu]" id="kkod_'+i+'"',
            '  class="kod-input form-alan" style="padding:6px 26px 6px 8px;font-size:12px;text-transform:uppercase" placeholder="Kod...">',
            '<span id="spin_'+i+'" class="hidden" style="position:absolute;right:6px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--bil)">⏳</span>',
          '</div>',
          '<div id="hata_'+i+'" class="hidden" style="font-size:10px;color:var(--hat);margin-top:2px">Bulunamadı</div>',
        '</div>',

        /* Ürün adı */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Ürün Adı</div>',
          '<input type="text" name="urunler['+i+'][stok_adi]" id="kad_'+i+'" readonly',
          '  class="form-alan" style="padding:6px 8px;font-size:12px;background:var(--kenar-a);color:var(--m2)" placeholder="—">',
        '</div>',

        /* Çevrim */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Çevrim (sn)</div>',
          '<input type="number" step="0.01" min="0" name="urunler['+i+'][cevrim]" id="kcv_'+i+'"',
          '  class="cevrim-i form-alan" style="padding:6px 8px;font-size:12px" placeholder="sn">',
        '</div>',

        /* Göz */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Göz</div>',
          '<input type="number" min="1" value="1" name="urunler['+i+'][goz_sayisi]" id="kgz_'+i+'"',
          '  class="goz-i form-alan" style="padding:6px 8px;font-size:12px">',
        '</div>',

        /* Üretilen */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Üretilen</div>',
          '<input type="number" min="0" name="urunler['+i+'][uretim_miktari]" id="kur_'+i+'"',
          '  class="uretim-i form-alan" style="padding:6px 8px;font-size:12px" placeholder="0">',
        '</div>',

        /* Fire */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Fire</div>',
          '<input type="number" min="0" value="0" name="urunler['+i+'][fire_miktar]" id="kfr_'+i+'"',
          '  class="fire-i form-alan" style="padding:6px 8px;font-size:12px">',
        '</div>',

        /* Personel */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Personel</div>',
          '<input type="number" min="1" value="'+ps+'" name="urunler['+i+'][personel_sayisi]" id="kps_'+i+'"',
          '  class="pers-i form-alan" style="padding:6px 8px;font-size:12px">',
        '</div>',

        /* Teorik */
        '<div>',
          '<div style="font-size:10px;color:var(--m2);margin-bottom:3px">Teorik (dk)</div>',
          '<input type="number" step="0.01" readonly name="urunler['+i+'][teorik_sure]" id="kts_'+i+'"',
          '  class="form-alan" style="padding:6px 8px;font-size:12px;background:var(--kenar-a);color:var(--m2);font-weight:700" placeholder="—">',
        '</div>',

        /* Sil */
        '<div style="display:flex;align-items:flex-end">',
          '<button type="button" class="sil-btn btn btn-sm"',
          '  style="background:var(--hat-a);color:var(--hat);border:none;padding:6px 10px;border-radius:4px;cursor:pointer;width:100%">🗑</button>',
        '</div>',

        /* Hidden alanlar */
        '<input type="hidden" name="urunler['+i+'][verimlilik]"         id="kvr_'+i+'" value="0">',
        '<input type="hidden" name="urunler['+i+'][fire_orani]"         id="kfo_'+i+'" value="0">',
        '<input type="hidden" name="urunler['+i+'][net_calisma_suresi]" id="ncs_'+i+'" value="'+net+'">',

      '</div>'
    ].join('');
  }

  /* ── AJAX: ürün kodu → çevrim + ad ── */
  function ajaxCevrim(i, kod) {
    var spin = document.getElementById('spin_' + i);
    var hata = document.getElementById('hata_' + i);
    var adEl = document.getElementById('kad_'  + i);
    if (spin) spin.classList.remove('hidden');
    if (hata) hata.classList.add('hidden');

    fetch('<?= BASE_URL ?>/bolumler/uretim/ajax/get_cevrim_montaj.php?kod=' + encodeURIComponent(kod), {
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(function(r){ return r.json(); })
    .then(function(data) {
      if (spin) spin.classList.add('hidden');
      if (data.success) {
        var cvEl = document.getElementById('kcv_' + i);
        if (cvEl && data.cevrim)   cvEl.value = data.cevrim;
        if (adEl && data.stok_adi) adEl.value = data.stok_adi;
        hesapla(i); refreshToplamlar();
      } else {
        if (adEl) adEl.value = '';
        if (hata) hata.classList.remove('hidden');
      }
    })
    .catch(function(){ if (spin) spin.classList.add('hidden'); });
  }

  /* ── Tek ürün satırı hesabı ──
     Teorik = (üretilen / göz) × çevrim_sn / 60 / personel_sayisi
  */
  function hesapla(i) {
    var cv  = parseFloat(document.getElementById('kcv_' + i)?.value) || 0;
    var gz  = parseInt(document.getElementById('kgz_'  + i)?.value)  || 1;
    var ur  = parseFloat(document.getElementById('kur_' + i)?.value) || 0;
    var fr  = parseFloat(document.getElementById('kfr_' + i)?.value) || 0;
    var ps  = parseInt(document.getElementById('kps_'  + i)?.value)  || 1;
    var net = getNet();

    var teorik   = (cv > 0 && ps > 0) ? (ur / gz) * cv / 60 / ps : 0;
    var fireOran = ur > 0 ? (fr / ur * 100) : 0;

    var tsEl  = document.getElementById('kts_' + i);
    var ncsEl = document.getElementById('ncs_' + i);
    var foEl  = document.getElementById('kfo_' + i);
    if (tsEl)  tsEl.value  = teorik.toFixed(2);
    if (ncsEl) ncsEl.value = net.toFixed(2);
    if (foEl)  foEl.value  = fireOran.toFixed(2);
  }

  /* ── Toplam verimlilik ── */
  function refreshToplamlar() {
    var topTeorik = 0;
    document.querySelectorAll('.urun-satir').forEach(function(s) {
      topTeorik += parseFloat(document.getElementById('kts_' + s.dataset.idx)?.value) || 0;
    });
    var net   = getNet();
    var verim = net > 0 ? (topTeorik / net * 100) : 0;

    var ttEl = document.getElementById('toplamTeorikEl');
    var tvEl = document.getElementById('toplamVerimEl');
    if (ttEl) ttEl.textContent = topTeorik.toFixed(1);
    if (tvEl) {
      tvEl.textContent = verim.toFixed(1) + '%';
      tvEl.style.color = verim >= 85 ? 'var(--bas)' : verim >= 60 ? 'var(--uya)' : 'var(--hat)';
    }
    /* Tüm satırların hidden verimlilik alanını güncelle */
    document.querySelectorAll('.urun-satir').forEach(function(s) {
      var el = document.getElementById('kvr_' + s.dataset.idx);
      if (el) el.value = verim.toFixed(2);
    });
  }

  /* ── KAYDET ── */
  document.getElementById('kaydetBtn')?.addEventListener('click', function() {
    /* Son hesap */
    document.querySelectorAll('.urun-satir').forEach(function(s){ hesapla(s.dataset.idx); });
    refreshToplamlar();

    var pSayisi = getPersonelSayisi() - (document.querySelectorAll('.personel-select').length > 0 &&
      Array.from(document.querySelectorAll('.personel-select')).filter(s => s.value).length === 0 ? 1 : 0);
    var secilenP = Array.from(document.querySelectorAll('.personel-select')).filter(s => s.value).length;

    if (secilenP === 0)                { alert('En az 1 personel seçiniz!'); return; }
    if (!satirlarDiv.children.length)  { alert('En az 1 ürün ekleyiniz!');  return; }

    var bosKod = false;
    document.querySelectorAll('.kod-input').forEach(function(e){ if (!e.value.trim()) bosKod = true; });
    if (bosKod) { alert('Tüm ürün kodlarını doldurunuz!'); return; }

    var uSayisi = satirlarDiv.children.length;
    if (!confirm(secilenP + ' personel × ' + uSayisi + ' ürün = ' + (secilenP * uSayisi) + ' kayıt oluşturulacak. Devam?')) return;

    var btn = this;
    btn.disabled    = true;
    btn.textContent = '⏳ Kaydediliyor...';

    fetch('<?= BASE_URL ?>/bolumler/uretim/ajax/verim_kaydet_montaj.php', {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: new FormData(document.getElementById('verimForm'))
    })
    .then(function(r){ return r.json(); })
    .then(function(d) {
      btn.disabled    = false;
      btn.textContent = '💾 Kaydet';
      if (d.ok) {
        alert('✅ ' + d.msg);
        window.location.href = '<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-montaj';
      } else {
        alert('❌ ' + d.msg);
      }
    })
    .catch(function() {
      btn.disabled    = false;
      btn.textContent = '💾 Kaydet';
      alert('Bağlantı hatası!');
    });
  });

  /* ── Responsive satir-grid ── */
  function responsiveGrid() {
    var isMobile = window.innerWidth < 640;
    document.querySelectorAll('.satir-grid').forEach(function(g) {
      g.style.gridTemplateColumns = isMobile
        ? 'repeat(2,1fr)'
        : '140px 1fr 80px 60px 90px 70px 70px 90px 40px';
    });
  }
  window.addEventListener('resize', responsiveGrid);
  responsiveGrid();

});
</script>
