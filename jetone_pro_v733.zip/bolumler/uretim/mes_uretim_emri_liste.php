<?php
/**
 * MES Üretim Emri Listesi
 * panel.php: 'uretim-mes-emri-liste' => 'bolumler/uretim/mes_uretim_emri_liste.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$hata    = '';
$emriler = [];

if (!$tigerdb_pdo) {
    $hata = 'Tiger DB bağlantısı kurulamadı.';
} else {
    try {
        $st = $tigerdb_pdo->query("SELECT
            WS.CODE AS is_istasyonu,
            CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor'
                 WHEN PRO.STATUS=0 THEN 'Başlamadı'
                 ELSE 'Başlamadı' END AS durum,
            CONVERT(date, PRO.DATE_) AS uretim_tarihi,
            PRO.FICHENO AS uretim_no,
            IT.CODE AS mamul_kodu,
            IT.NAME AS mamul_adi,
            CONVERT(decimal(18,0),(
                SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT
                WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN (0,1)
            )) AS stok,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT) - ISNULL((
                SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
                WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
            ),0)) AS birinci_kalite,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT) + ISNULL((
                SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
                WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
            ),0)) AS kalan,
            CONVERT(decimal(18,0), ISNULL((
                SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
                WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
            ),0)) AS ikinci_kalite
        FROM dbo.LG_222_PRODORD AS PRO
        LEFT JOIN dbo.LG_222_ITEMS AS IT ON IT.LOGICALREF=PRO.ITEMREF
        LEFT JOIN dbo.LG_222_BOMASTER AS BOM ON BOM.LOGICALREF=PRO.MASTERREF
        LEFT JOIN dbo.LG_222_DISPLINE AS DIS ON DIS.PRODORDREF=PRO.LOGICALREF
        LEFT JOIN dbo.LG_222_WORKSTAT AS WS ON WS.LOGICALREF=DIS.WSREF
        WHERE YEAR(PRO.DATE_)=YEAR(GETDATE()) AND MONTH(PRO.DATE_)=MONTH(GETDATE()) AND PRO.STATUS IN (0,1,3)
        GROUP BY YEAR(PRO.DATE_),MONTH(PRO.DATE_),WS.CODE,
            CONVERT(date,PRO.DATE_),PRO.FICHENO,IT.CODE,IT.NAME,
            PRO.PLNAMOUNT,PRO.STATUS,IT.LOGICALREF
        ORDER BY WS.CODE");
        $emriler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 Üretim Emri Listesi</h1>
    <div class="s-yol">Üretim / Veri Giriş / <b>Üretim Emirleri</b></div>
  </div>
</div>

<div class="s-body">

<?php if($hata): ?>
<div style="padding:12px 16px;margin-bottom:14px;background:#FEF2F2;color:#7F1D1D;border:1px solid #FECACA;border-radius:var(--r-lg);font-size:13px">
  ⚠️ <?=htmlspecialchars($hata)?>
</div>
<?php endif; ?>

<!-- Özet -->
<?php
$toplam    = count($emriler);
$devam     = count(array_filter($emriler, fn($r) => $r['durum']==='Devam Ediyor'));
$baslamadi = $toplam - $devam;
?>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px">
  <div class="kart" style="padding:16px;border-left:4px solid var(--t)">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--m3);margin-bottom:6px">Toplam Emir</div>
    <div style="font-size:26px;font-weight:900;color:var(--t)"><?=$toplam?></div>
  </div>
  <div class="kart" style="padding:16px;border-left:4px solid #16A34A">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--m3);margin-bottom:6px">Devam Ediyor</div>
    <div style="font-size:26px;font-weight:900;color:#16A34A"><?=$devam?></div>
  </div>
  <div class="kart" style="padding:16px;border-left:4px solid #DC2626">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--m3);margin-bottom:6px">Başlamadı</div>
    <div style="font-size:26px;font-weight:900;color:#DC2626"><?=$baslamadi?></div>
  </div>
</div>

<!-- Arama -->
<div class="kart" style="padding:12px 16px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:13px;color:var(--m2);font-weight:600">🔍 Filtrele:</span>
    <input id="ara-inp" type="text" placeholder="Emri no, mamul kodu veya açıklama ara..."
           class="form-alan" style="max-width:380px"
           oninput="araFiltrele(this.value)">
    <select id="durum-sel" class="form-alan" style="max-width:160px" onchange="araFiltrele()">
      <option value="">Tüm Durumlar</option>
      <option value="Devam Ediyor">Devam Ediyor</option>
      <option value="Başlamadı">Başlamadı</option>
    </select>
    <span style="margin-left:auto;font-size:12px;color:var(--m3)" id="sayi-goster"><?=$toplam?> kayıt</span>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="overflow:auto;max-height:640px">
  <table id="emri-tablo" style="width:100%;border-collapse:collapse;font-size:13px">
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:var(--m);color:#fff">
        <th style="padding:11px 14px;text-align:left;font-weight:700;white-space:nowrap">İşlem</th>
        <th style="padding:11px 14px;text-align:left;font-weight:700;white-space:nowrap">İş İstasyonu</th>
        <th style="padding:11px 14px;text-align:center;font-weight:700;white-space:nowrap">Durum</th>
        <th style="padding:11px 14px;text-align:left;font-weight:700;white-space:nowrap">Tarih</th>
        <th style="padding:11px 14px;text-align:left;font-weight:700;white-space:nowrap">Üretim No</th>
        <th style="padding:11px 14px;text-align:left;font-weight:700;white-space:nowrap">Mamul Kodu</th>
        <th style="padding:11px 14px;text-align:left;font-weight:700;min-width:200px">Mamul Adı</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">Stok</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">Planlanan</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">Üretilen</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">1.Kalite</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">Kalan</th>
        <th style="padding:11px 14px;text-align:right;font-weight:700;white-space:nowrap">2.Kalite</th>
        <th style="padding:11px 14px;text-align:center;font-weight:700;white-space:nowrap">Tamamlanma</th>
        <th style="padding:11px 14px;text-align:center;font-weight:700;white-space:nowrap">Kalitesizlik</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($emriler as $i=>$r):
      $planlanan = (float)($r['planlanan']??0);
      $uretilen  = (float)($r['uretilen']??0);
      $ikinci    = (float)($r['ikinci_kalite']??0);
      $kalan     = (float)($r['kalan']??0);
      $pct = $planlanan > 0 ? min(100, round($uretilen/$planlanan*100,1)) : 0;
      $kal = $uretilen  > 0 ? round($ikinci/$uretilen*100,1) : 0;
      $devam_ediyor = ($r['durum']==='Devam Ediyor');
      $bg = $i%2===0 ? 'var(--yuzey)' : 'var(--kenar-a)';
    ?>
    <tr class="emri-satir" style="border-bottom:1px solid var(--kenar);background:<?=$bg?>"
        data-ara="<?=strtolower($r['uretim_no'].' '.$r['mamul_kodu'].' '.$r['mamul_adi'].' '.$r['is_istasyonu'])?>"
        data-durum="<?=htmlspecialchars($r['durum'])?>">
      <td style="padding:9px 14px;white-space:nowrap">
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($r['uretim_no'])?>"
           class="btn btn-t btn-sm">SEÇ →</a>
      </td>
      <td style="padding:9px 14px;font-size:12px;font-weight:600;color:var(--m2)"><?=htmlspecialchars($r['is_istasyonu']??'')?></td>
      <td style="padding:9px 14px;text-align:center">
        <?php if($devam_ediyor): ?>
        <span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:#D1FAE5;color:#065F46">● Devam Ediyor</span>
        <?php else: ?>
        <span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:#FEE2E2;color:#7F1D1D">○ Başlamadı</span>
        <?php endif; ?>
      </td>
      <td style="padding:9px 14px;font-size:12px;color:var(--m2);white-space:nowrap"><?=htmlspecialchars(substr($r['uretim_tarihi']??'',0,10))?></td>
      <td style="padding:9px 14px;font-family:monospace;font-weight:700;color:var(--t);white-space:nowrap"><?=htmlspecialchars($r['uretim_no']??'')?></td>
      <td style="padding:9px 14px;font-family:monospace;font-size:12px"><?=htmlspecialchars($r['mamul_kodu']??'')?></td>
      <td style="padding:9px 14px;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
          title="<?=htmlspecialchars($r['mamul_adi']??'')?>"><?=htmlspecialchars($r['mamul_adi']??'')?></td>
      <td style="padding:9px 14px;text-align:right;font-weight:600"><?=number_format((float)($r['stok']??0),0,'.',',')?></td>
      <td style="padding:9px 14px;text-align:right;font-weight:700"><?=number_format($planlanan,0,'.',',')?></td>
      <td style="padding:9px 14px;text-align:right;font-weight:700;color:var(--t)"><?=number_format($uretilen,0,'.',',')?></td>
      <td style="padding:9px 14px;text-align:right;font-weight:700;color:#16A34A"><?=number_format((float)($r['birinci_kalite']??0),0,'.',',')?></td>
      <td style="padding:9px 14px;text-align:right;font-weight:700;color:<?=$kalan<0?'#DC2626':'var(--m2)'?>">
        <?=number_format($kalan,0,'.',',')?>
      </td>
      <td style="padding:9px 14px;text-align:right;color:<?=$ikinci>0?'#DC2626':'var(--m3)'?>;font-weight:<?=$ikinci>0?'700':'400'?>">
        <?=number_format($ikinci,0,'.',',')?>
      </td>
      <td style="padding:9px 14px">
        <!-- İlerleme barı -->
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;background:var(--kenar);border-radius:4px;height:8px;overflow:hidden;min-width:60px">
            <div style="width:<?=$pct?>%;height:100%;border-radius:4px;background:<?=$pct>=100?'#16A34A':($pct>=60?'var(--t)':'#DC2626')?>"></div>
          </div>
          <span style="font-size:11px;font-weight:700;color:<?=$pct>=100?'#16A34A':($pct>=60?'var(--t)':'#DC2626');?>;white-space:nowrap">%<?=$pct?></span>
        </div>
      </td>
      <td style="padding:9px 14px;text-align:center">
        <?php
        $kal_bg  = $kal < 3  ? '#D1FAE5' : ($kal < 10 ? '#FEF3C7' : '#FEE2E2');
        $kal_col = $kal < 3  ? '#065F46' : ($kal < 10 ? '#92400E' : '#7F1D1D');
        ?>
        <span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;background:<?=$kal_bg?>;color:<?=$kal_col?>">
          %<?=$kal?>
        </span>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

</div>

<script>
function araFiltrele(q) {
    var q   = (document.getElementById('ara-inp').value||'').toLowerCase();
    var dur = document.getElementById('durum-sel').value;
    var satirlar = document.querySelectorAll('#emri-tablo .emri-satir');
    var gorunen  = 0;
    satirlar.forEach(function(s) {
        var araEsles  = !q   || s.dataset.ara.includes(q);
        var durEsles  = !dur || s.dataset.durum === dur;
        var goster = araEsles && durEsles;
        s.style.display = goster ? '' : 'none';
        if (goster) gorunen++;
    });
    document.getElementById('sayi-goster').textContent = gorunen + ' kayıt';
}
</script>
