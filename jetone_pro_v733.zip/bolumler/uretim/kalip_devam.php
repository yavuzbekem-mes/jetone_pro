<?php
/**
 * Devam Eden Kalıp Bağlama İşlemleri
 * panel.php: 'uretim-kalip-devam'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

try { $db->exec(file_get_contents(dirname(dirname(__DIR__)).'/kalip_degisim.sql')); } catch (Throwable $e) {}

function zaman_str($bas, $bit=null) {
    $t1=strtotime($bas); $t2=$bit?strtotime($bit):time(); $f=max(0,$t2-$t1);
    if($f<60) return $f.'s';
    if($f<3600) return round($f/60).' dk';
    if($f<86400) return round($f/3600,1).' saat';
    return round($f/86400).' gün';
}
function aciliyet_rozet($a) {
    if($a==='Acil')   return '<span style="background:#FEE2E2;color:#991B1B;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:800">ACİL</span>';
    if($a==='Normal') return '<span style="background:#E0F2FE;color:#1E3A5F;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">Normal</span>';
    return '<span style="background:#F1F5F9;color:#64748B;padding:2px 8px;border-radius:10px;font-size:11px">'.htmlspecialchars($a).'</span>';
}

try {
    $rows = $db->query("SELECT * FROM kalip_degisim WHERE durumu='Devam Ediyor' ORDER BY aciliyet='Acil' DESC, kalip_id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $rows = []; }

$durum_msg = $_GET['durum'] ?? '';
$acil_say  = count(array_filter($rows, fn($r)=>$r['aciliyet']==='Acil'));
$uzun_say  = count(array_filter($rows, fn($r)=>time()-strtotime($r['baslama_tarih'])>7200));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">⏳ Devam Eden Kalıp Bağlama</h1>
    <div class="s-yol">Üretim / <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" style="color:var(--t)">Kalıp Bağlama</a> / <b>Devam Edenler</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat"     class="btn btn-b btn-sm">📋 Plan</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-tamamlanan" class="btn btn-b btn-sm">✅ Tamamlananlar</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-ekle"       class="btn btn-t btn-sm">+ Yeni Ekle</a>
  </div>
</div>

<div class="s-body">
<?php if ($durum_msg==='ok'): ?>
<div style="background:var(--bas-a);color:var(--bas);padding:10px 14px;border-radius:var(--r);margin-bottom:12px;font-weight:700">✅ İşlem başarılı.</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:14px">
  <?php foreach ([
    ['Devam Eden', count($rows),  '#1E3A5F','#E0F2FE'],
    ['Acil',       $acil_say,     '#EF4444','#FEE2E2'],
    ['2s+ Süren',  $uzun_say,     '#F59E0B','#FEF9C3'],
  ] as [$l,$v,$f,$b]): ?>
  <div style="background:<?= $b ?>;border-radius:var(--r);padding:12px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $f ?>"><?= $v ?></div>
    <div style="font-size:10px;color:<?= $f ?>;font-weight:700;text-transform:uppercase"><?= $l ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="kart" style="padding:0">
  <div style="overflow-x:auto">
    <?php $sth=['#','İşlem','Aciliyet','Ürün Kodu','Ürün Adı','Makine','Vardiya','Başlangıç','Geçen Süre','Açıklama','Başlayan']; ?>
    <table id="devamTablo" class="tablo" style="width:100%">
      <thead><tr style="background:#1E3A5F!important">
        <?php foreach($sth as $h): ?>
        <th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:8px 10px;font-size:12px;white-space:nowrap"><?= $h ?></th>
        <?php endforeach; ?>
      </tr></thead>
      <tfoot><tr style="background:#1E3A5F!important">
        <?php foreach($sth as $h): ?><th style="background:#1E3A5F!important;color:#fff!important;font-weight:700;padding:6px 10px;font-size:11px"><?= $h ?></th><?php endforeach; ?>
      </tr></tfoot>
      <tbody>
      <?php foreach($rows as $i => $r):
          $sure_sn = time()-strtotime($r['baslama_tarih']);
          $rbg = $r['aciliyet']==='Acil' ? 'background:#FFF5F5' : ($sure_sn>7200 ? 'background:#FFFBEB' : '');
      ?>
      <tr style="<?= $rbg ?>">
        <td style="color:var(--m3);font-size:11px"><?= $i+1 ?></td>
        <td style="white-space:nowrap">
          <a href="<?= BASE_URL ?>/islemler/uretim/kalip_tamamla.php?id=<?= $r['kalip_id'] ?>&tamamlayan=<?= urlencode($kul_adi) ?>"
             onclick="return confirm('Tamamlandı olarak işaretlensin mi?')"
             class="btn btn-sm" style="background:var(--bas-a);color:var(--bas);padding:3px 8px;font-size:11px;text-decoration:none">✅ Tamamla</a>
          <a href="<?= BASE_URL ?>/islemler/uretim/kalip_sil.php?id=<?= $r['kalip_id'] ?>"
             onclick="return confirm('Silinsin mi?')"
             class="btn btn-sm" style="background:var(--hat-a);color:var(--hat);padding:3px 8px;font-size:11px;text-decoration:none">🗑</a>
        </td>
        <td><?= aciliyet_rozet($r['aciliyet']??'') ?></td>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['urun_kodu']??'') ?></td>
        <td style="font-size:12px;max-width:200px"><?= htmlspecialchars($r['urun_adi']??'') ?></td>
        <td style="font-family:monospace;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['is_istasyonu']??'') ?></td>
        <td style="text-align:center"><?= $r['vardiya']??'-' ?>. Var.</td>
        <td style="white-space:nowrap;font-size:11px"><?= $r['baslama_tarih']?date('d.m.Y H:i',strtotime($r['baslama_tarih'])):'—' ?></td>
        <td><span style="font-weight:800;color:<?= $sure_sn>7200?'#EF4444':($sure_sn>3600?'#F59E0B':'#22C55E') ?>"><?= zaman_str($r['baslama_tarih']) ?></span></td>
        <td style="font-size:11px;max-width:160px"><?= htmlspecialchars($r['kalip_aciklama']??'') ?></td>
        <td style="font-size:11px"><?= htmlspecialchars($r['ekleyen']??'') ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script>
$(document).ready(function(){
  $('#devamTablo').DataTable({
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollX:true,scrollY:480,scrollCollapse:true,paging:false,
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',filename:'KalipDevam_<?= date("Ymd") ?>'}],
    drawCallback:function(){ $('#devamTablo thead th,#devamTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); },
    initComplete:function(){ this.api().columns([2,5]).every(function(){ var col=this,sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); }); col.data().unique().sort().each(function(d){ var t=$('<div/>').html(d).text(); sel.append('<option value="'+t+'">'+t+'</option>'); }); }); $('#devamTablo thead th,#devamTablo tfoot th').each(function(){ this.style.setProperty('background-color','#1E3A5F','important'); this.style.setProperty('color','#fff','important'); }); }
  });
  // 60sn otomatik yenile
  var kalan=60, el=document.createElement('div');
  el.style.cssText='position:fixed;bottom:16px;right:16px;background:#1E3A5F;color:#fff;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;z-index:999;cursor:pointer';
  el.title='Sayfayı yenile'; document.body.appendChild(el);
  el.onclick=function(){ location.reload(); };
  setInterval(function(){ el.textContent='🔄 '+kalan+'s'; if(--kalan<0) location.reload(); },1000);
});
</script>
