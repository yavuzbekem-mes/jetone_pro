<?php
/**
 * JETONE.PRO — Aylık Personel Verimlilik Raporu
 * bolumler/uretim/verim_personel_rapor.php
 * İki tablo: Enjeksiyon (EN-%) + Montaj (NOT EN-%)
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// ── Ay parametresi ────────────────────────────────────────────────────────────
$secili_ay    = preg_match('/^\d{4}-\d{2}$/', $_GET['secili_ay'] ?? '') ? $_GET['secili_ay'] : date('Y-m');
$ay_baslangic = $secili_ay . '-01';
$ay_bitis     = date('Y-m-t', strtotime($ay_baslangic));
$gun_sayisi   = (int)date('t', strtotime($ay_baslangic));

// Ay adı Türkçe
$tr_aylar = ['January'=>'Ocak','February'=>'Şubat','March'=>'Mart','April'=>'Nisan',
             'May'=>'Mayıs','June'=>'Haziran','July'=>'Temmuz','August'=>'Ağustos',
             'September'=>'Eylül','October'=>'Ekim','November'=>'Kasım','December'=>'Aralık'];
$ay_adi = strtr(date('F Y', strtotime($ay_baslangic)), $tr_aylar);

$tr_gunler = ['Mon'=>'Pzt','Tue'=>'Sal','Wed'=>'Çar','Thu'=>'Per','Fri'=>'Cum','Sat'=>'Cmt','Sun'=>'Paz'];

// ── Ortak veri çekici fonksiyon ───────────────────────────────────────────────
function aylik_veri(PDO $db, string $baslangic, string $bitis, string $filtre): array {
    // Personel listesi
    $ps = $db->prepare("
        SELECT DISTINCT calisan_personel FROM verimlilik
        WHERE tarih >= ? AND tarih <= ? AND makina_kodu $filtre
        ORDER BY calisan_personel
    ");
    $ps->execute([$baslangic, $bitis]);
    $personeller = $ps->fetchAll(PDO::FETCH_COLUMN);

    // Tüm günlük ortalamalar tek sorguda
    $vs = $db->prepare("
        SELECT calisan_personel, DATE(tarih) AS gun,
               ROUND(AVG(verimlilik), 2) AS ort
        FROM verimlilik
        WHERE tarih >= ? AND tarih <= ? AND makina_kodu $filtre
        GROUP BY calisan_personel, DATE(tarih)
    ");
    $vs->execute([$baslangic, $bitis]);
    $per_map = [];
    foreach ($vs->fetchAll(PDO::FETCH_ASSOC) as $r)
        $per_map[$r['calisan_personel']][$r['gun']] = (float)$r['ort'];

    // Günlük genel ortalama
    $gs = $db->prepare("
        SELECT DATE(tarih) AS gun, ROUND(AVG(verimlilik), 2) AS ort
        FROM verimlilik
        WHERE tarih >= ? AND tarih <= ? AND makina_kodu $filtre
        GROUP BY DATE(tarih)
    ");
    $gs->execute([$baslangic, $bitis]);
    $gun_ort = [];
    foreach ($gs->fetchAll(PDO::FETCH_ASSOC) as $r)
        $gun_ort[$r['gun']] = (float)$r['ort'];

    return ['personeller' => $personeller, 'per_map' => $per_map, 'gun_ort' => $gun_ort];
}

$enj  = aylik_veri($db, $ay_baslangic, $ay_bitis, "LIKE 'EN-%'");
$mont = aylik_veri($db, $ay_baslangic, $ay_bitis, "NOT LIKE 'EN-%'");

// ── Renk yardımcısı ───────────────────────────────────────────────────────────
function roz_bg(float $v): string {
    if ($v >= 90) return 'background:#059669;color:#fff';
    if ($v >= 70) return 'background:#D97706;color:#fff';
    return 'background:#DC2626;color:#fff';
}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">👤 Aylık Personel Verimlilik Raporu</h1>
    <div class="s-yol">Üretim / <b><?= $ay_adi ?></b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste" class="btn btn-b btn-sm">Enjeksiyon Liste</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-liste-montaj" class="btn btn-b btn-sm">Montaj Liste</a>
  </div>
</div>

<div class="s-body">

<!-- Ay Seçim Formu -->
<div class="kart" style="margin-bottom:16px">
  <form method="GET" action="" style="display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="uretim-verim-personel">
    <div class="form-grup" style="margin:0">
      <label class="form-et">Ay Seçiniz</label>
      <input class="form-alan" type="month" name="secili_ay" value="<?= htmlspecialchars($secili_ay) ?>" style="max-width:200px">
    </div>
    <button type="submit" class="btn btn-t">🔍 Filtrele</button>
    <?php if (isset($_GET['secili_ay'])): ?>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-verim-personel" class="btn btn-b">✕ Temizle</a>
    <?php endif; ?>
    <div style="margin-left:auto;display:flex;gap:8px;font-size:12px;align-items:center">
      <span style="background:#059669;color:#fff;padding:3px 10px;border-radius:4px">≥ 90%</span>
      <span style="background:#D97706;color:#fff;padding:3px 10px;border-radius:4px">70–89%</span>
      <span style="background:#DC2626;color:#fff;padding:3px 10px;border-radius:4px">&lt; 70%</span>
    </div>
  </form>
</div>

<?php
// ── Ortak tablo render fonksiyonu ─────────────────────────────────────────────
function render_aylik_tablo(array $veri, int $gun_sayisi, string $ay_baslangic,
                             array $tr_gunler, string $tablo_id, string $ay_adi, string $baslik): void {
    $personeller = $veri['personeller'];
    $per_map     = $veri['per_map'];
    $gun_ort     = $veri['gun_ort'];
?>
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:24px">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:14px;background:var(--kenar-a)">
    <?= htmlspecialchars($baslik) ?>
    <span style="background:var(--t-a);color:var(--t);border-radius:20px;padding:2px 10px;font-size:12px;margin-left:6px"><?= count($personeller) ?> personel</span>
  </div>
  <?php if (empty($personeller)): ?>
  <div style="padding:32px;text-align:center;color:var(--m2)">Bu ay için kayıt bulunamadı.</div>
  <?php else: ?>
  <div style="overflow-x:auto;overflow-y:auto;max-height:500px">
    <table id="<?= $tablo_id ?>" class="tablo" style="width:100%;border-collapse:collapse">
      <thead>
        <tr style="background:#1E3A5F;position:sticky;top:0;z-index:2">
          <th style="color:#fff;position:sticky;left:0;z-index:3;background:#1E3A5F;white-space:nowrap;min-width:150px">Personel</th>
          <?php for ($i = 1; $i <= $gun_sayisi; $i++):
            $tarih    = date('Y-m-d', strtotime($ay_baslangic . ' +' . ($i-1) . ' day'));
            $fmt      = date('d.m', strtotime($tarih));
            $gun_adi  = $tr_gunler[date('D', strtotime($tarih))] ?? date('D', strtotime($tarih));
            $haftasonu = in_array(date('N', strtotime($tarih)), [6,7]);
          ?>
          <th style="color:#fff;text-align:center;min-width:44px;font-size:10px;<?= $haftasonu?'opacity:.6':'' ?>">
            <div><?= $fmt ?></div>
            <div style="font-weight:400;opacity:.8"><?= $gun_adi ?></div>
          </th>
          <?php endfor; ?>
          <th style="color:#fff;text-align:center;position:sticky;right:0;z-index:3;background:#1E3A5F;min-width:60px">Ort.</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($personeller as $per):
          $gunler = $per_map[$per] ?? [];
          $top = 0; $cnt = 0;
          foreach ($gunler as $o) { $top += $o; $cnt++; }
          $ort = $cnt > 0 ? $top/$cnt : 0;
        ?>
        <tr>
          <td style="font-weight:700;white-space:nowrap;position:sticky;left:0;background:var(--yuzey);z-index:1;font-size:12px;padding:4px 10px;border-bottom:1px solid var(--kenar)"><?= htmlspecialchars($per) ?></td>
          <?php for ($i = 1; $i <= $gun_sayisi; $i++):
            $tarih = date('Y-m-d', strtotime($ay_baslangic . ' +' . ($i-1) . ' day'));
            $v = $gunler[$tarih] ?? null;
          ?>
          <td style="text-align:center;padding:3px;border-bottom:1px solid var(--kenar)">
            <?php if ($v !== null): ?>
              <span style="<?= roz_bg($v) ?>;display:block;border-radius:3px;padding:2px 4px;font-size:11px;font-weight:700">
                <?= number_format($v, 1) ?>
              </span>
            <?php else: ?>
              <span style="color:var(--m3);font-size:11px">—</span>
            <?php endif; ?>
          </td>
          <?php endfor; ?>
          <td style="text-align:center;position:sticky;right:0;z-index:1;padding:4px;border-bottom:1px solid var(--kenar)">
            <?php if ($ort > 0): ?>
              <span style="<?= roz_bg($ort) ?>;display:block;border-radius:3px;padding:3px 6px;font-size:12px;font-weight:800">
                <?= number_format($ort, 1) ?>%
              </span>
            <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:var(--kenar-a);position:sticky;bottom:0;z-index:2">
          <th style="font-size:12px;color:var(--m2);position:sticky;left:0;background:var(--kenar-a);padding:6px 10px;text-align:left">Günlük Ort.</th>
          <?php
          $ay_top = 0; $ay_cnt = 0;
          for ($i = 1; $i <= $gun_sayisi; $i++):
            $tarih = date('Y-m-d', strtotime($ay_baslangic . ' +' . ($i-1) . ' day'));
            $o = $gun_ort[$tarih] ?? null;
            if ($o !== null) { $ay_top += $o; $ay_cnt++; }
          ?>
          <th style="text-align:center;padding:4px">
            <?php if ($o !== null): ?>
              <span style="<?= roz_bg($o) ?>;display:block;border-radius:3px;padding:2px 4px;font-size:11px;font-weight:700">
                <?= number_format($o, 1) ?>
              </span>
            <?php else: ?><span style="color:var(--m3);font-size:11px">—</span><?php endif; ?>
          </th>
          <?php endfor; ?>
          <?php $ay_ort = $ay_cnt > 0 ? $ay_top/$ay_cnt : 0; ?>
          <th style="text-align:center;position:sticky;right:0;background:var(--kenar-a);padding:4px">
            <?php if ($ay_ort > 0): ?>
              <span style="<?= roz_bg($ay_ort) ?>;display:block;border-radius:3px;padding:3px 6px;font-size:12px;font-weight:800">
                <?= number_format($ay_ort, 1) ?>%
              </span>
            <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
          </th>
        </tr>
      </tfoot>
    </table>
  </div>
  <!-- Excel / Print butonları -->
  <div style="padding:10px 16px;border-top:1px solid var(--kenar);display:flex;gap:8px">
    <button onclick="exportExcel('<?= $tablo_id ?>','<?= addslashes($baslik) ?> - <?= $ay_adi ?>')"
            class="btn btn-b btn-sm">📊 Excel</button>
    <button onclick="window.print()" class="btn btn-b btn-sm">🖨 Yazdır</button>
  </div>
  <?php endif; ?>
</div>
<?php
} // /render_aylik_tablo

render_aylik_tablo($enj,  $gun_sayisi, $ay_baslangic, $tr_gunler, 'tbl_enj',  $ay_adi, '💉 Personel Bazlı Aylık Enjeksiyon Verimlilik Analizi');
render_aylik_tablo($mont, $gun_sayisi, $ay_baslangic, $tr_gunler, 'tbl_mont', $ay_adi, '🔧 Personel Bazlı Aylık Montaj Verimlilik Analizi');
?>

</div><!-- /s-body -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
function exportExcel(tabloId, baslik) {
    var tbl = document.getElementById(tabloId);
    if (!tbl) return;
    var wb  = XLSX.utils.book_new();
    var ws  = XLSX.utils.table_to_sheet(tbl);
    XLSX.utils.book_append_sheet(wb, ws, 'Rapor');
    XLSX.writeFile(wb, baslik.replace(/[\\/:*?"<>|]/g,'_') + '.xlsx');
}
</script>
