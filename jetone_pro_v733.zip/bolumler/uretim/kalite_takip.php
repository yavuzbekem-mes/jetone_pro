<?php
/**
 * Kalite Takip Sayfası
 * - Sekme 1: İkinci Kalite Girişleri (PAKETLER ETIKET_TURU=IKINCI)
 * - Sekme 2: Montaj Fire (Tiger STFICHE DOC_NUMBER LIKE 'MONTAJ_FIRE%')
 * Route: uretim-kalite-takip
 */
if(!defined('ROOT_DIR')) require_once dirname(__DIR__,2).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

$aktif_tab = $_GET['tab'] ?? '2k';
$f_emri  = trim($_GET['emri']  ?? '');
$f_basl  = trim($_GET['basl']  ?? date('Y-m-01'));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));

// ── İkinci Kalite: dbo.IKINCI_KALITE tablosu ────────────────────────────────
$kayitlar_2k = []; $toplam_2k_miktar = 0;
if($mes_pdo) {
    try {
        $w = ["CONVERT(date,URETIM_TARIHI) BETWEEN ? AND ?"];
        $p = [$f_basl,$f_bitis];
        if($f_emri){ $w[]="URETIM_EMRI_NO LIKE ?"; $p[]="%$f_emri%"; }
        $ws = implode(' AND ',$w);
        $st = $mes_pdo->prepare(
            "SELECT ID, URETIM_EMRI_NO, STOK_KODU, STOK_ADI,
                    CALISAN, URETIM_TARIHI, TOPLAM,
                    ISNULL([AYAR_FIRESİ],0)       AS AYAR_FIRESI,
                    ISNULL(HAMMADDE_LEKESI,0)      AS HAMMADDE_LEKESI,
                    ISNULL(YAG_LEKESI,0)           AS YAG_LEKESI,
                    ISNULL(CIZIK,0)                AS CIZIK,
                    ISNULL(EKSIK_ENJEKSIYON,0)     AS EKSIK_ENJEKSIYON,
                    ISNULL(CATLAK,0)               AS CATLAK,
                    ISNULL(GAZLANMA,0)             AS GAZLANMA,
                    ISNULL(COKUNTU,0)              AS COKUNTU,
                    ISNULL(SERPME,0)               AS SERPME,
                    ISNULL(YANMA,0)                AS YANMA
             FROM dbo.IKINCI_KALITE WHERE $ws ORDER BY ID DESC"
        );
        $st->execute($p);
        $kayitlar_2k = $st->fetchAll(PDO::FETCH_ASSOC);
        $toplam_2k_miktar = array_sum(array_column($kayitlar_2k,'TOPLAM'));

// 2K Grafik verileri
$ik_gunluk = []; $ik_calisan = []; $ik_emri = [];
$ik_defekt_toplam = ['AYAR_FIRESI'=>0,'HAMMADDE_LEKESI'=>0,'YAG_LEKESI'=>0,'CIZIK'=>0,
    'EKSIK_ENJEKSIYON'=>0,'CATLAK'=>0,'GAZLANMA'=>0,'COKUNTU'=>0,'SERPME'=>0,'YANMA'=>0];
foreach($kayitlar_2k as $r) {
    $gun = substr($r['URETIM_TARIHI']??'',0,10);
    $cal = $r['CALISAN']??'Bilinmiyor';
    $emri= $r['URETIM_EMRI_NO']??'';
    $top = (float)($r['TOPLAM']??0);
    if(!isset($ik_gunluk[$gun])) $ik_gunluk[$gun]=['sayi'=>0,'miktar'=>0];
    $ik_gunluk[$gun]['sayi']++; $ik_gunluk[$gun]['miktar']+=$top;
    if(!isset($ik_calisan[$cal])) $ik_calisan[$cal]=0;
    $ik_calisan[$cal]+=$top;
    if(!isset($ik_emri[$emri])) $ik_emri[$emri]=0;
    $ik_emri[$emri]+=$top;
    foreach(array_keys($ik_defekt_toplam) as $dk) {
        $ik_defekt_toplam[$dk]+=(float)($r[$dk]??0);
    }
}
ksort($ik_gunluk);
arsort($ik_calisan);
arsort($ik_emri);    $ik_emri=array_slice($ik_emri,0,8,true);
$ik_defekt_toplam = array_filter($ik_defekt_toplam,fn($v)=>$v>0);
    } catch(Throwable $e){ error_log("[KAL_TAKIP_2K] ".$e->getMessage()); }
}

// ── Montaj Fire: jetone_pro DB montaj_fire_kayitlar tablosu ─────────────────
$montaj_fireler = []; $toplam_mf = 0;
if(isset($db)) {
    try {
        $mf_w = ["DATE(kayit_tarihi) BETWEEN ? AND ?"];
        $mf_p = [$f_basl, $f_bitis];
        if($f_emri) { $mf_w[] = "uretim_emri_no LIKE ?"; $mf_p[] = "%$f_emri%"; }
        $mf_ws = implode(' AND ', $mf_w);
        $mf_st = $db->prepare(
            "SELECT id, uretim_emri_no, stok_kodu, stok_adi,
                    fire_miktar, birim, fire_nedeni,
                    tiger_fis_no, is_istasyonu, kayit_eden,
                    kayit_tarihi
             FROM montaj_fire_kayitlar
             WHERE $mf_ws
             ORDER BY id DESC"
        );
        $mf_st->execute($mf_p);
        $montaj_fireler = $mf_st->fetchAll(PDO::FETCH_ASSOC);
        $toplam_mf = (float)array_sum(array_column($montaj_fireler,'fire_miktar'));

// MF Grafik verileri
$mf_gunluk=[]; $mf_istasyon=[]; $mf_neden=[];
foreach($montaj_fireler as $r) {
    $gun = substr($r['kayit_tarihi']??'',0,10);
    $ist = $r['is_istasyonu']??'Bilinmiyor';
    $ned = $r['fire_nedeni']??'Bilinmiyor';
    $mik = (float)($r['fire_miktar']??0);
    if(!isset($mf_gunluk[$gun])) $mf_gunluk[$gun]=['sayi'=>0,'miktar'=>0];
    $mf_gunluk[$gun]['sayi']++; $mf_gunluk[$gun]['miktar']+=$mik;
    if(!isset($mf_istasyon[$ist])) $mf_istasyon[$ist]=0;
    $mf_istasyon[$ist]+=$mik;
    if(!isset($mf_neden[$ned])) $mf_neden[$ned]=0;
    $mf_neden[$ned]+=$mik;
}
ksort($mf_gunluk);
arsort($mf_istasyon);
arsort($mf_neden);
    } catch(Throwable $e){ error_log("[KAL_TAKIP_MF] ".$e->getMessage()); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔶 Kalite Takip</h1>
    <div class="s-yol">Üretim / <b>Kalite Takip</b></div>
  </div>
</div>

<div class="s-body">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
.kt-tab-bar{display:flex;border-bottom:2px solid var(--kenar);margin-bottom:16px}
.kt-tab{padding:12px 24px;font-weight:800;font-size:13px;border:none;cursor:pointer;background:none;border-bottom:3px solid transparent;margin-bottom:-2px;color:var(--m3);transition:all .15s}
.kt-tab.aktif{color:var(--t);border-bottom-color:var(--t);background:none}
.kt-kart{background:var(--yuzey);border-radius:var(--r-xl);box-shadow:var(--shadow);margin-bottom:16px}
.kt-kart-head{padding:14px 18px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center}
.kt-tablo{width:100%;border-collapse:collapse;font-size:13px}
.kt-tablo th{padding:10px 14px;font-weight:700;color:var(--m2);background:var(--kenar-a);border-bottom:2px solid var(--kenar);text-align:left;white-space:nowrap}
.kt-tablo td{padding:9px 14px;border-bottom:1px solid var(--kenar);vertical-align:middle}
.kt-tablo tbody tr:hover{background:var(--kenar-a)}
.ozet-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:16px}
.ozet-kart{background:var(--yuzey);border-radius:var(--r);padding:18px 20px;text-align:center;box-shadow:var(--shadow);border-top:4px solid}
@media(max-width:700px){.ozet-grid{grid-template-columns:1fr 1fr}}
</style>

<!-- Tab Bar -->
<div class="kt-tab-bar">
  <button class="kt-tab <?=$aktif_tab==='2k'?'aktif':''?>"
          onclick="switchKtTab('2k',this)">
    ⚑ İkinci Kalite Girişleri
    <span style="background:<?=$aktif_tab==='2k'?'var(--t)':'var(--kenar)'?>;color:<?=$aktif_tab==='2k'?'#fff':'var(--m2)'?>;border-radius:12px;padding:2px 8px;font-size:11px;margin-left:6px">
      <?=count($kayitlar_2k)?> kayıt
    </span>
  </button>
  <button class="kt-tab <?=$aktif_tab==='mf'?'aktif':''?>"
          onclick="switchKtTab('mf',this)">
    🔶 Montaj Fire Fişleri (Tiger)
    <span style="background:<?=$aktif_tab==='mf'?'var(--t)':'var(--kenar)'?>;color:<?=$aktif_tab==='mf'?'#fff':'var(--m2)'?>;border-radius:12px;padding:2px 8px;font-size:11px;margin-left:6px">
      <?=count($montaj_fireler)?> kayıt
    </span>
  </button>
</div>

<!-- Filtre -->
<div class="kt-kart" style="padding:16px 20px;margin-bottom:16px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="uretim-kalite-takip">
    <input type="hidden" name="tab"   id="tab-hidden" value="<?=htmlspecialchars($aktif_tab)?>">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="form-et" style="font-size:11px">Başlangıç</label>
           <input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Bitiş</label>
           <input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>" style="width:140px"></div>
      <div><label class="form-et" style="font-size:11px">Üretim Emri</label>
           <input type="text" name="emri" class="form-alan" value="<?=htmlspecialchars($f_emri)?>" placeholder="UE-..." style="width:150px"></div>
      <button type="submit" class="btn btn-t" style="padding:10px 20px">🔍 Filtrele</button>
      <a href="?sayfa=uretim-kalite-takip" class="btn" style="padding:10px 16px;background:var(--kenar-a);color:var(--m2)">↺</a>
    </div>
  </form>
</div>

<!-- ═══════════════════ SEKMEİ 1: İKİNCİ KALİTE ═══════════════════ -->
<div id="panel-2k" style="<?=$aktif_tab!=='2k'?'display:none':''?>">

  <!-- Özet Kartlar -->
  <div class="ozet-grid" style="grid-template-columns:repeat(4,1fr)">
    <div class="ozet-kart" style="border-color:#F59E0B">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Toplam Kayıt</div>
      <div style="font-size:28px;font-weight:900;color:#F59E0B"><?=count($kayitlar_2k)?></div>
    </div>
    <div class="ozet-kart" style="border-color:#DC2626">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Toplam 2K Adet</div>
      <div style="font-size:28px;font-weight:900;color:#DC2626"><?=number_format($toplam_2k_miktar)?></div>
    </div>
    <div class="ozet-kart" style="border-color:#8B5CF6">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Çalışan Sayısı</div>
      <div style="font-size:28px;font-weight:900;color:#8B5CF6"><?=count($ik_calisan)?></div>
    </div>
    <div class="ozet-kart" style="border-color:#6B7280">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Defekt Türü</div>
      <div style="font-size:28px;font-weight:900;color:#6B7280"><?=count($ik_defekt_toplam)?></div>
    </div>
  </div>

  <?php if(!empty($kayitlar_2k)): ?>
  <!-- Grafikler -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
    <!-- Günlük bar -->
    <div class="kt-kart" style="padding:18px">
      <div style="font-weight:800;font-size:13px;margin-bottom:12px">📅 Günlük 2. Kalite (adet)</div>
      <canvas id="ik-chart-gunluk" height="80"></canvas>
    </div>
    <!-- Defekt dağılım -->
    <div class="kt-kart" style="padding:18px">
      <div style="font-weight:800;font-size:13px;margin-bottom:12px">🥧 Defekt Türü Dağılımı</div>
      <div style="position:relative;height:200px">
        <canvas id="ik-chart-defekt"></canvas>
      </div>
    </div>
  </div>
  <!-- Çalışan + Emri -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
    <div class="kt-kart" style="padding:0;overflow:hidden">
      <div class="kt-kart-head">
        <span style="font-weight:800;font-size:13px">👤 Çalışana Göre</span>
        <span style="font-size:11px;color:var(--m3)"><?=count($ik_calisan)?> çalışan</span>
      </div>
      <div style="overflow-y:auto;max-height:260px">
      <table class="kt-tablo">
        <thead style="position:sticky;top:0;z-index:1">
          <tr><th>Çalışan</th><th style="text-align:right">Toplam Adet</th></tr>
        </thead>
        <tbody>
        <?php foreach($ik_calisan as $cal=>$mik): ?>
        <tr>
          <td style="font-size:12px"><?=htmlspecialchars($cal)?></td>
          <td style="text-align:right;font-weight:700;color:#DC2626;font-size:12px"><?=number_format($mik)?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
    <div class="kt-kart" style="padding:0;overflow:hidden">
      <div class="kt-kart-head"><span style="font-weight:800;font-size:13px">📋 Defekt Detay</span></div>
      <div style="overflow-y:auto;max-height:260px">
      <table class="kt-tablo">
        <thead style="position:sticky;top:0;z-index:1">
          <tr><th>Defekt</th><th style="text-align:right">Toplam</th></tr>
        </thead>
        <tbody>
        <?php
        $def_lbls=['AYAR_FIRESI'=>'Ayar Firesi','HAMMADDE_LEKESI'=>'H.Madde Lekesi',
                   'YAG_LEKESI'=>'Yağ Lekesi','CIZIK'=>'Çizik','EKSIK_ENJEKSIYON'=>'Eksik Enj.',
                   'CATLAK'=>'Çatlak','GAZLANMA'=>'Gazlanma','COKUNTU'=>'Çöküntü',
                   'SERPME'=>'Serpme','YANMA'=>'Yanma'];
        arsort($ik_defekt_toplam);
        foreach($ik_defekt_toplam as $dk=>$dv): if($dv<=0) continue; ?>
        <tr>
          <td style="font-size:12px"><?=htmlspecialchars($def_lbls[$dk]??$dk)?></td>
          <td style="text-align:right;font-weight:700;color:#DC2626;font-size:12px"><?=number_format($dv,1)?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <div class="kt-kart" style="padding:0;overflow:hidden">
    <div class="kt-kart-head">
      <span style="font-weight:800;font-size:14px">⚑ İkinci Kalite Kayıtları</span>
      <span style="font-size:12px;color:var(--m3)"><?=count($kayitlar_2k)?> kayıt | <?=number_format($toplam_2k_miktar)?> adet</span>
    </div>
    <?php if(empty($kayitlar_2k)): ?>
    <div style="padding:40px;text-align:center;color:var(--m3)">Seçilen kriterlerde 2. kalite kaydı yok.</div>
    <?php else: ?>
    <div style="overflow:auto;max-height:520px">
    <table class="kt-tablo">
      <thead style="position:sticky;top:0;z-index:2"><tr>
        <th>#</th><th>Üretim Emri</th><th>Stok Kodu</th>
        <th>Çalışan</th><th>Tarih</th>
        <th style="text-align:right">Ayar</th>
        <th style="text-align:right">H.Leke</th>
        <th style="text-align:right">Yağ</th>
        <th style="text-align:right">Çizik</th>
        <th style="text-align:right">Ek.Enj</th>
        <th style="text-align:right">Çatlak</th>
        <th style="text-align:right">Gaz</th>
        <th style="text-align:right">Çöküntü</th>
        <th style="text-align:right">Serpme</th>
        <th style="text-align:right">Yanma</th>
        <th style="text-align:right;color:#DC2626">TOPLAM</th>
        <th style="text-align:center">İşlem</th>
      </tr></thead>
      <tbody>
      <?php
      $def_cols = ['AYAR_FIRESI','HAMMADDE_LEKESI','YAG_LEKESI','CIZIK',
                   'EKSIK_ENJEKSIYON','CATLAK','GAZLANMA','COKUNTU','SERPME','YANMA'];
      foreach($kayitlar_2k as $i=>$r):
        $rid = (int)($r['ID']??0);
        $rj  = json_encode([
            'ID'=>$rid,
            'URETIM_EMRI_NO'=>$r['uretim_emri_no']??'',
            'STOK_KODU'=>$r['stok_kodu']??'',
            'TOPLAM'=>$r['TOPLAM']??0,
            'CALISAN'=>$r['CALISAN']??'',
            'AYAR_FIRESI'=>$r['AYAR_FIRESI']??0,
            'HAMMADDE_LEKESI'=>$r['HAMMADDE_LEKESI']??0,
            'YAG_LEKESI'=>$r['YAG_LEKESI']??0,
            'CIZIK'=>$r['CIZIK']??0,
            'EKSIK_ENJEKSIYON'=>$r['EKSIK_ENJEKSIYON']??0,
            'CATLAK'=>$r['CATLAK']??0,
            'GAZLANMA'=>$r['GAZLANMA']??0,
            'COKUNTU'=>$r['COKUNTU']??0,
            'SERPME'=>$r['SERPME']??0,
            'YANMA'=>$r['YANMA']??0,
        ], JSON_HEX_APOS|JSON_HEX_QUOT);
      ?>
      <tr>
        <td style="color:var(--m3);font-size:12px"><?=$i+1?></td>
        <td><a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($r['uretim_emri_no']??'')?>"
               style="font-weight:700;color:var(--t);text-decoration:none;font-size:12px"><?=htmlspecialchars($r['uretim_emri_no']??'')?></a></td>
        <td style="font-size:11px;font-weight:600"><?=htmlspecialchars($r['stok_kodu']??'')?></td>
        <td style="font-size:12px"><?=htmlspecialchars($r['CALISAN']??'')?></td>
        <td style="font-size:11px;color:var(--m2)"><?=htmlspecialchars(substr($r['URETIM_TARIHI']??'',0,16))?></td>
        <?php foreach($def_cols as $dc): $dv=(float)($r[$dc]??0); ?>
        <td style="text-align:right;font-size:12px;color:<?=$dv>0?'#DC2626':'var(--m3)'?>;font-weight:<?=$dv>0?'700':'400'?>"><?=$dv>0?number_format($dv,1):'—'?></td>
        <?php endforeach; ?>
        <td style="text-align:right;font-weight:900;color:#DC2626;font-size:13px"><?=number_format((float)($r['TOPLAM']??0))?></td>
        <td style="text-align:center;white-space:nowrap">
          <button class="btn" style="padding:4px 10px;font-size:11px;background:#DBEAFE;color:#1E40AF;margin-right:4px"
                  onclick='ikDuzenle(<?=$rj?>)'>✏️</button>
          <button class="btn" style="padding:4px 10px;font-size:11px;background:#FEE2E2;color:#7F1D1D;margin-right:4px"
                  onclick="ikSil(<?=$rid?>,this)">🗑️</button>
          <button class="btn" style="padding:4px 10px;font-size:11px;background:#7C3AED;color:#fff"
                  onclick='iptalTalepAc(<?=$rid?>,"2K",<?=json_encode($r["URETIM_EMRI_NO"]??"")?>,<?=json_encode("")?>,<?=json_encode($r["STOK_KODU"]??"")?>,<?=json_encode($r["STOK_ADI"]??"")?>,<?=(float)($r["TOPLAM"]??0)?>)'>🚫 İptal</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot><tr style="background:#FEE2E2">
        <td colspan="15" style="padding:9px 14px;font-weight:800">TOPLAM</td>
        <td style="padding:9px 14px;text-align:right;font-weight:900;color:#DC2626;font-size:14px"><?=number_format($toplam_2k_miktar)?></td>
        <td></td>
      </tr></tfoot>
    </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- ═══════════════════ SEKME 2: MONTAJ FİRE ═══════════════════ -->
<div id="panel-mf" style="<?=$aktif_tab!=='mf'?'display:none':''?>">
  <!-- 4'lü Özet Kartlar -->
  <div class="ozet-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
    <div class="ozet-kart" style="border-color:#EA580C">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Toplam Kayıt</div>
      <div style="font-size:28px;font-weight:900;color:#EA580C"><?=count($montaj_fireler)?></div>
      <div style="font-size:11px;color:var(--m3);margin-top:4px">fire girişi</div>
    </div>
    <div class="ozet-kart" style="border-color:#DC2626">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Toplam Fire</div>
      <div style="font-size:28px;font-weight:900;color:#DC2626"><?=number_format($toplam_mf,2)?></div>
      <div style="font-size:11px;color:var(--m3);margin-top:4px">adet / kg</div>
    </div>
    <div class="ozet-kart" style="border-color:#F59E0B">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">İstasyon</div>
      <div style="font-size:28px;font-weight:900;color:#F59E0B"><?=count($mf_istasyon)?></div>
      <div style="font-size:11px;color:var(--m3);margin-top:4px">farklı istasyon</div>
    </div>
    <div class="ozet-kart" style="border-color:#8B5CF6">
      <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:6px">Fire Nedeni</div>
      <div style="font-size:28px;font-weight:900;color:#8B5CF6"><?=count($mf_neden)?></div>
      <div style="font-size:11px;color:var(--m3);margin-top:4px">farklı neden</div>
    </div>
  </div>

  <?php if(!empty($montaj_fireler)): ?>
  <!-- Grafikler -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
    <div class="kt-kart" style="padding:18px">
      <div style="font-weight:800;font-size:13px;margin-bottom:12px">📅 Günlük Montaj Fire Miktarı</div>
      <canvas id="mf-chart-gunluk" height="80"></canvas>
    </div>
    <div class="kt-kart" style="padding:18px">
      <div style="font-weight:800;font-size:13px;margin-bottom:12px">🥧 Fire Nedeni Dağılımı</div>
      <div style="position:relative;height:200px">
        <canvas id="mf-chart-neden"></canvas>
      </div>
    </div>
  </div>
  <!-- İstasyon + Neden tabloları -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
    <div class="kt-kart" style="padding:0;overflow:hidden">
      <div class="kt-kart-head">
        <span style="font-weight:800;font-size:13px">🏭 İstasyona Göre Fire</span>
        <span style="font-size:11px;color:var(--m3)"><?=count($mf_istasyon)?> istasyon</span>
      </div>
      <div style="overflow-y:auto;max-height:220px">
        <table class="kt-tablo">
          <thead style="position:sticky;top:0;z-index:1">
            <tr><th>İstasyon</th><th style="text-align:right">Toplam Fire</th></tr>
          </thead>
          <tbody>
          <?php foreach($mf_istasyon as $ist=>$mik): ?>
          <tr>
            <td style="font-size:12px;font-weight:600"><?=htmlspecialchars($ist)?></td>
            <td style="text-align:right;font-weight:700;color:#EA580C;font-size:12px"><?=number_format($mik,2)?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="kt-kart" style="padding:0;overflow:hidden">
      <div class="kt-kart-head">
        <span style="font-weight:800;font-size:13px">📋 Nedene Göre Fire</span>
        <span style="font-size:11px;color:var(--m3)"><?=count($mf_neden)?> neden</span>
      </div>
      <div style="overflow-y:auto;max-height:220px">
        <table class="kt-tablo">
          <thead style="position:sticky;top:0;z-index:1">
            <tr><th>Neden</th><th style="text-align:right">Toplam Fire</th></tr>
          </thead>
          <tbody>
          <?php foreach($mf_neden as $ned=>$mik): ?>
          <tr>
            <td style="font-size:12px"><?=htmlspecialchars($ned)?></td>
            <td style="text-align:right;font-weight:700;color:#EA580C;font-size:12px"><?=number_format($mik,2)?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <div class="kt-kart" style="padding:0;overflow:hidden">
    <div class="kt-kart-head">
      <span style="font-weight:800;font-size:14px">🔶 Montaj Fire Fişleri (Tiger)</span>
      <span style="font-size:12px;color:var(--m3)"><?=count($montaj_fireler)?> satır</span>
    </div>
    <?php if(empty($montaj_fireler)): ?>
    <div style="padding:40px;text-align:center;color:var(--m3)">Seçilen kriterlerde montaj fire fişi bulunamadı.<br><small style="font-size:11px">Tiger'da <code>DOC_NUMBER LIKE 'MONTAJ_FIRE%'</code> ve <code>TRCODE=25</code> kontrolü yapılmaktadır.</small></div>
    <?php else: ?>
    <div style="overflow:auto;max-height:520px">
    <table class="kt-tablo">
      <thead style="position:sticky;top:0;z-index:2"><tr>
        <th>#</th><th>Tiger Fiş No</th><th>Tarih</th>
        <th>Üretim Emri</th><th>İstasyon</th><th>Stok Kodu</th><th>Stok Adı</th>
        <th>Kaydeden</th><th style="text-align:right">Miktar</th><th>Birim</th>
        <th>Fire Nedeni</th>
      </tr></thead>
      <tbody>
      <?php foreach($montaj_fireler as $i=>$r): ?>
      <tr>
        <td style="color:var(--m3);font-size:12px"><?=$i+1?></td>
        <td style="font-family:monospace;font-size:11px;font-weight:600"><?=htmlspecialchars($r['tiger_fis_no']??'')?></td>
        <td style="font-size:12px;color:var(--m2)"><?=htmlspecialchars(substr($r['kayit_tarihi']??'',0,16))?></td>
        <td>
          <?php if(!empty($r['uretim_emri_no'])): ?>
          <a href="?sayfa=uretim-mes-emri-detay&ficheno=<?=urlencode($r['uretim_emri_no'])?>"
             style="font-weight:700;color:var(--t);text-decoration:none;font-size:12px"><?=htmlspecialchars($r['uretim_emri_no'])?></a>
          <?php endif; ?>
        </td>
        <td style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($r['is_istasyonu']??'')?></td>
        <td style="font-size:12px;font-weight:600"><?=htmlspecialchars($r['stok_kodu']??'')?></td>
        <td style="font-size:12px;max-width:200px"><?=htmlspecialchars($r['stok_adi']??'')?></td>
        <td style="font-size:11px;color:var(--m3)"><?=htmlspecialchars($r['kayit_eden']??'')?></td>
        <td style="text-align:right;font-weight:700;color:#EA580C;font-size:13px"><?=number_format((float)($r['fire_miktar']??0),2)?></td>
        <td style="font-size:12px;color:var(--m3)"><?=htmlspecialchars($r['birim']??'')?></td>
        <td style="font-size:11px;color:var(--m3);max-width:160px"><?=htmlspecialchars($r['fire_nedeni']??'')?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot><tr style="background:#FEF3C7">
        <td colspan="9" style="padding:9px 14px;font-weight:800">TOPLAM</td>
        <td style="padding:9px 14px;text-align:right;font-weight:900;color:#EA580C;font-size:14px"><?=number_format($toplam_mf,2)?></td>
        <td colspan="2"></td>
      </tr></tfoot>
    </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- İK Düzenleme Modalı -->
<div id="ik-edit-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:500px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
      <span style="font-size:15px;font-weight:800">✏️ 2. Kalite Kaydını Düzenle</span>
      <button onclick="document.getElementById('ik-edit-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:24px">
      <form id="ikEditForm">
        <input type="hidden" name="id" id="ik-edit-id">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
          <div>
            <label class="form-et" style="font-size:11px">Üretim Emri</label>
            <input type="text" id="ik-edit-emri" class="form-alan" readonly style="background:var(--kenar-a);font-size:12px">
          </div>
          <div>
            <label class="form-et" style="font-size:11px">Çalışan</label>
            <input type="text" name="calisan" id="ik-edit-calisan" class="form-alan" style="font-size:12px">
          </div>
        </div>
        <!-- Defekt grid -->
        <div style="background:var(--kenar-a);border-radius:var(--r);padding:12px;margin-bottom:12px">
          <div style="font-size:11px;font-weight:700;color:var(--m3);margin-bottom:8px;text-transform:uppercase">Defekt Miktarları</div>
          <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px">
            <?php
            $defs=[
              ['ayar_firesi','Ayar Firesi'],['hammadde_lekesi','H. Madde Lekesi'],
              ['yag_lekesi','Yağ Lekesi'],['cizik','Çizik'],
              ['eksik_enjeksiyon','Eksik Enjeksiyon'],['catlak','Çatlak'],
              ['gazlanma','Gazlanma'],['cokuntu','Çöküntü'],
              ['serpme','Serpme'],['yanma','Yanma'],
            ];
            foreach($defs as $df): ?>
            <div>
              <label class="form-et" style="font-size:10px"><?=htmlspecialchars($df[1])?></label>
              <input type="number" name="<?=$df[0]?>" id="ik-<?=$df[0]?>"
                     class="form-alan" min="0" value="0" style="font-size:12px;padding:6px 10px"
                     oninput="ikHesaplaToplam()">
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div style="background:#FEE2E2;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between">
          <span style="font-weight:700;color:#7F1D1D;font-size:13px">Toplam</span>
          <span id="ik-toplam-goster" style="font-weight:900;color:#DC2626;font-size:18px">0</span>
          <input type="hidden" name="toplam" id="ik-edit-toplam">
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('ik-edit-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">İptal</button>
          <button type="submit" class="btn btn-t" style="padding:10px 24px">💾 Güncelle</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- İptal Talebi Modalı -->
<div id="iptal-talep-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:520px;box-shadow:0 24px 60px rgba(0,0,0,.25)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,#7C3AED11,var(--yuzey))">
      <span style="font-size:15px;font-weight:800">🚫 İptal Talebi Oluştur</span>
      <button onclick="document.getElementById('iptal-talep-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:24px">
      <!-- Kayıt bilgisi -->
      <div id="iptal-kayit-bilgi" style="background:var(--kenar-a);border-radius:var(--r);padding:12px 14px;margin-bottom:16px;font-size:12px;border-left:4px solid #7C3AED"></div>
      <form id="iptalTalepForm">
        <input type="hidden" name="mes_kayit_id" id="iptal-id">
        <input type="hidden" name="kayit_tipi"   id="iptal-tip">
        <input type="hidden" name="uretim_emri_no" id="iptal-emri">
        <input type="hidden" name="paket_no"     id="iptal-paket">
        <input type="hidden" name="stok_kodu"    id="iptal-stok">
        <input type="hidden" name="stok_adi"     id="iptal-stokadi">
        <input type="hidden" name="miktar"       id="iptal-miktar">
        <div style="margin-bottom:16px">
          <label class="form-et">İptal Nedeni <span style="color:#DC2626">*</span></label>
          <textarea name="iptal_nedeni" id="iptal-neden" class="form-alan" rows="3"
                    placeholder="İptal nedenini açıklayın..." required
                    style="resize:vertical"></textarea>
        </div>
        <div style="background:#FEF3C7;border-radius:var(--r);padding:10px 12px;font-size:11px;color:#92400E;margin-bottom:16px">
          ⚠️ Bu talep onaylandığında ilgili kayıt kalıcı olarak silinecektir. İşlem loglanacaktır.
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('iptal-talep-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">Vazgeç</button>
          <button type="submit" class="btn" style="padding:10px 24px;background:#7C3AED;color:#fff;font-weight:800">🚫 Talep Oluştur</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
var BASE_KT = '<?=BASE_URL?>';

// ── Grafik verileri (PHP inject) ──────────────────────────────────────────
var IK_GUNLUK  = <?=json_encode(['labels'=>array_keys($ik_gunluk),'miktar'=>array_column(array_values($ik_gunluk),'miktar'),'sayi'=>array_column(array_values($ik_gunluk),'sayi')])?>;
var IK_DEFEKT  = <?=json_encode(['labels'=>array_values(array_map(fn($k)=>['AYAR_FIRESI'=>'Ayar','HAMMADDE_LEKESI'=>'H.Leke','YAG_LEKESI'=>'Yağ','CIZIK'=>'Çizik','EKSIK_ENJEKSIYON'=>'Ek.Enj','CATLAK'=>'Çatlak','GAZLANMA'=>'Gaz','COKUNTU'=>'Çöküntü','SERPME'=>'Serpme','YANMA'=>'Yanma'][$k]??$k, array_keys($ik_defekt_toplam))),'data'=>array_values($ik_defekt_toplam)])?>;
var IK_CALISAN = <?=json_encode(['labels'=>array_keys($ik_calisan),'data'=>array_values($ik_calisan)])?>;

var MF_GUNLUK  = <?=json_encode(['labels'=>array_keys($mf_gunluk),'miktar'=>array_column(array_values($mf_gunluk),'miktar'),'sayi'=>array_column(array_values($mf_gunluk),'sayi')])?>;
var MF_NEDEN   = <?=json_encode(['labels'=>array_keys($mf_neden),'data'=>array_values($mf_neden)])?>;
var MF_ISTASYON= <?=json_encode(['labels'=>array_keys($mf_istasyon),'data'=>array_values($mf_istasyon)])?>;

var RENK_PALETTE = ['#DC2626','#EA580C','#D97706','#16A34A','#0EA5E9','#8B5CF6','#EC4899','#14B8A6','#F97316','#84CC16'];

var ikChartOlusturuldu = false, mfChartOlusturuldu = false;

function olusturIkGrafik() {
    if(ikChartOlusturuldu || !IK_GUNLUK.labels.length) return;
    ikChartOlusturuldu = true;

    if(IK_GUNLUK.labels.length && document.getElementById('ik-chart-gunluk')) {
        new Chart(document.getElementById('ik-chart-gunluk'), {
            type:'bar',
            data:{labels:IK_GUNLUK.labels, datasets:[{
                label:'2K Miktar',data:IK_GUNLUK.miktar,
                backgroundColor:'rgba(220,38,38,0.7)',borderColor:'#DC2626',borderWidth:1,borderRadius:4
            },{
                label:'Kayıt',data:IK_GUNLUK.sayi,type:'line',
                borderColor:'#F59E0B',backgroundColor:'rgba(245,158,11,0.1)',
                tension:.3,yAxisID:'y1',pointRadius:4
            }]},
            options:{responsive:true,plugins:{legend:{position:'bottom',labels:{font:{size:10}}}},
                scales:{y:{title:{display:true,text:'Adet'}},y1:{position:'right',title:{display:true,text:'Kayıt'},grid:{drawOnChartArea:false}}}}
        });
    }

    if(IK_DEFEKT.labels.length && document.getElementById('ik-chart-defekt')) {
        new Chart(document.getElementById('ik-chart-defekt'), {
            type:'doughnut',
            data:{labels:IK_DEFEKT.labels, datasets:[{
                data:IK_DEFEKT.data, backgroundColor:RENK_PALETTE.slice(0,IK_DEFEKT.labels.length), borderWidth:2
            }]},
            options:{responsive:true,maintainAspectRatio:false,
                plugins:{legend:{position:'right',labels:{font:{size:9},boxWidth:10,padding:6}}}}
        });
    }
}

function olusturMfGrafik() {
    if(mfChartOlusturuldu || !MF_GUNLUK.labels.length) return;
    mfChartOlusturuldu = true;

    if(MF_GUNLUK.labels.length && document.getElementById('mf-chart-gunluk')) {
        new Chart(document.getElementById('mf-chart-gunluk'), {
            type:'bar',
            data:{labels:MF_GUNLUK.labels, datasets:[{
                label:'Fire Miktarı',data:MF_GUNLUK.miktar,
                backgroundColor:'rgba(234,88,12,0.7)',borderColor:'#EA580C',borderWidth:1,borderRadius:4
            },{
                label:'Kayıt',data:MF_GUNLUK.sayi,type:'line',
                borderColor:'#D97706',backgroundColor:'rgba(217,119,6,0.1)',
                tension:.3,yAxisID:'y1',pointRadius:4
            }]},
            options:{responsive:true,plugins:{legend:{position:'bottom',labels:{font:{size:10}}}},
                scales:{y:{title:{display:true,text:'Miktar'}},y1:{position:'right',title:{display:true,text:'Kayıt'},grid:{drawOnChartArea:false}}}}
        });
    }

    if(MF_NEDEN.labels.length && document.getElementById('mf-chart-neden')) {
        new Chart(document.getElementById('mf-chart-neden'), {
            type:'doughnut',
            data:{labels:MF_NEDEN.labels, datasets:[{
                data:MF_NEDEN.data, backgroundColor:RENK_PALETTE.slice(0,MF_NEDEN.labels.length), borderWidth:2
            }]},
            options:{responsive:true,maintainAspectRatio:false,
                plugins:{legend:{position:'right',labels:{font:{size:9},boxWidth:10,padding:6}}}}
        });
    }
}

function switchKtTab(tab, btn) {
    if(tab==='2k') setTimeout(olusturIkGrafik, 50);
    if(tab==='mf') setTimeout(olusturMfGrafik, 50);
    document.getElementById('panel-2k').style.display = tab==='2k' ? '' : 'none';
    document.getElementById('panel-mf').style.display = tab==='mf' ? '' : 'none';
    document.querySelectorAll('.kt-tab').forEach(function(b){ b.classList.remove('aktif'); });
    btn.classList.add('aktif');
    document.getElementById('tab-hidden').value = tab;
}

function ikHesaplaToplam() {
    var cols = ['ayar_firesi','hammadde_lekesi','yag_lekesi','cizik',
                'eksik_enjeksiyon','catlak','gazlanma','cokuntu','serpme','yanma'];
    var top = 0;
    cols.forEach(function(c){ top += parseFloat(document.getElementById('ik-'+c).value)||0; });
    document.getElementById('ik-toplam-goster').textContent = top;
    document.getElementById('ik-edit-toplam').value = top;
}

function ikDuzenle(r) {
    document.getElementById('ik-edit-id').value       = r.ID;
    document.getElementById('ik-edit-emri').value     = r.URETIM_EMRI_NO;
    document.getElementById('ik-edit-calisan').value  = r.CALISAN||'';
    // Defekt değerlerini doldur
    var map = {
        'ayar_firesi':r.AYAR_FIRESI,'hammadde_lekesi':r.HAMMADDE_LEKESI,
        'yag_lekesi':r.YAG_LEKESI,'cizik':r.CIZIK,
        'eksik_enjeksiyon':r.EKSIK_ENJEKSIYON,'catlak':r.CATLAK,
        'gazlanma':r.GAZLANMA,'cokuntu':r.COKUNTU,
        'serpme':r.SERPME,'yanma':r.YANMA
    };
    Object.keys(map).forEach(function(k){
        var el=document.getElementById('ik-'+k);
        if(el) el.value = parseFloat(map[k])||0;
    });
    ikHesaplaToplam();
    document.getElementById('ik-edit-modal').style.display = 'flex';
}

function ikSil(id, btn) {
    Swal.fire({
        title:'Kayit silinsin mi?', text:'Bu 2. kalite kaydi kalici olarak silinecek.',
        icon:'warning', showCancelButton:true,
        confirmButtonColor:'#DC2626', cancelButtonColor:'#6B7280',
        confirmButtonText:'Evet, Sil', cancelButtonText:'Iptal'
    }).then(function(r){
        if(!r.isConfirmed) return;
        btn.disabled=true;
        Swal.fire({title:'Siliniyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
        fetch(BASE_KT+'/islemler/uretim/ikinci_kalite_sil.php',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({id:id})
        }).then(function(r){return r.json();}).then(function(d){
            if(d.success){
                Swal.fire({title:'Silindi!',icon:'success',timer:1500,showConfirmButton:false});
                var satir=btn.closest('tr');
                if(satir){satir.style.opacity='0.3';setTimeout(function(){satir.remove();},600);}
            } else {
                Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
                btn.disabled=false;
            }
        }).catch(function(e){Swal.fire({title:'Hata',text:e.message,icon:'error'});btn.disabled=false;});
    });
}

document.getElementById('ikEditForm').addEventListener('submit',function(e){
    e.preventDefault();
    Swal.fire({title:'Guncelleniyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
    var fd=new FormData(this),obj={};
    fd.forEach(function(v,k){obj[k]=v;});
    fetch(BASE_KT+'/islemler/uretim/ikinci_kalite_guncelle.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(obj)
    }).then(function(r){return r.json();}).then(function(d){
        if(d.success){
            Swal.fire({title:'Guncellendi!',text:d.message,icon:'success',timer:1800,showConfirmButton:false});
            document.getElementById('ik-edit-modal').style.display='none';
            setTimeout(function(){location.reload();},1000);
        } else {
            Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
        }
    }).catch(function(e){Swal.fire({title:'Hata',text:e.message,icon:'error'});});
});

function iptalTalepAc(id, tip, emri, paket, stok, stokadi, miktar) {
    document.getElementById('iptal-id').value      = id;
    document.getElementById('iptal-tip').value     = tip;
    document.getElementById('iptal-emri').value    = emri;
    document.getElementById('iptal-paket').value   = paket||'';
    document.getElementById('iptal-stok').value    = stok||'';
    document.getElementById('iptal-stokadi').value = stokadi||'';
    document.getElementById('iptal-miktar').value  = miktar||0;
    document.getElementById('iptal-neden').value   = '';
    document.getElementById('iptal-kayit-bilgi').innerHTML =
        '<b>'+tip+' Kaydı</b> | Emri: <b>'+emri+'</b><br>'+
        'Stok: '+stok+' — Miktar: <b style="color:#DC2626">'+miktar+'</b>';
    document.getElementById('iptal-talep-modal').style.display = 'flex';
}

document.getElementById('iptalTalepForm').addEventListener('submit', function(e){
    e.preventDefault();
    if(!document.getElementById('iptal-neden').value.trim()){
        Swal.fire({title:'Hata!',text:'İptal nedeni zorunludur.',icon:'warning'}); return;
    }
    Swal.fire({title:'Talep oluşturuluyor...',allowOutsideClick:false,showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
    var fd=new FormData(this),obj={};
    fd.forEach(function(v,k){obj[k]=v;});
    fetch(BASE_KT+'/islemler/uretim/iptal_talep_olustur.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(obj)
    }).then(function(r){return r.json();}).then(function(d){
        if(d.success){
            Swal.fire({title:'Talep Oluşturuldu!',text:d.message,icon:'success',confirmButtonColor:'#7C3AED'});
            document.getElementById('iptal-talep-modal').style.display='none';
        } else {
            Swal.fire({title:'Hata!',text:d.message,icon:'error',confirmButtonColor:'#DC2626'});
        }
    }).catch(function(e){Swal.fire({title:'Hata',text:e.message,icon:'error'});});
});

document.addEventListener('DOMContentLoaded', function(){
    var aktifTab = document.getElementById('tab-hidden') ? document.getElementById('tab-hidden').value : '2k';
    if(aktifTab==='2k') setTimeout(olusturIkGrafik, 100);
    if(aktifTab==='mf') setTimeout(olusturMfGrafik, 100);
});
</script>
</div><!-- /s-body -->
