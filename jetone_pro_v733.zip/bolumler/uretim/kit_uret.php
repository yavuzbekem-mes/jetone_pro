<?php
/**
 * BSH Kit Üretim — Barkod Okutma ve Kutu Kapatma
 * panel.php: 'uretim-kit-uret' => 'bolumler/uretim/kit_uret.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$urun_kodu = '';
$urun_adi  = '';
$paket_no  = '';
$baslatildi = false;

if (isset($_POST['kit_baslat']) || isset($_POST['urun_kodu'])) {
    $urun_kodu  = trim($_POST['urun_kodu'] ?? '');
    $paket_no   = trim($_POST['paket_no']  ?? '');
    $urun_adi   = trim($_POST['urun_adi']  ?? '');
    $baslatildi = ($urun_kodu !== '');

    // MES'teki miktarla karşılaştır — fazla üretim kontrolü
    if ($baslatildi && $mes_pdo) {
        try {
            $chk = $mes_pdo->prepare("SELECT MIKTAR FROM dbo.PAKETLER WHERE PAKET_NO=? AND URETIM_TARIHI >= DATEADD(DAY,-6,GETDATE())");
            $chk->execute([$paket_no]);
            $mes_miktar = (int)($chk->fetchColumn() ?: 0);

            $cnt = $db->prepare("SELECT COUNT(*) FROM `giriş_fişleri` WHERE PAKET_NO=?");
            $cnt->execute([$paket_no]);
            $uretilen = (int)$cnt->fetchColumn();

            if ($mes_miktar > 0 && $uretilen >= $mes_miktar) {
                $baslatildi = false;
                $hata_msg = "Bu paket için hedef miktar ($mes_miktar) zaten tamamlandı! ($uretilen/$mes_miktar üretildi)";
            }
        } catch(Throwable $e) { $hata_msg = "MES bağlantı hatası: ".$e->getMessage(); }
    }
}

// Reçete çek
$recete = [];
if ($baslatildi && $urun_kodu) {
    try {
        // ana_urun_kodu TRIM ile eslestirilir (DBde newline olabilir), miktar VARCHAR
        $rs = $db->prepare("SELECT malzeme_kodu, malzeme_adi, CAST(miktar AS UNSIGNED) as miktar FROM urun_recetesi WHERE TRIM(ana_urun_kodu)=? ORDER BY bom_id");
        $rs->execute([trim($urun_kodu)]);
        $recete = $rs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($recete)) {
            // Reçete bulunamadı uyarısı
            $hata_msg = ($hata_msg ?? '') . ' Reçete bulunamadı: ' . htmlspecialchars($urun_kodu);
        }
    } catch(Throwable $e) { $hata_msg = ($hata_msg ?? '') . ' Reçete hatası: '.$e->getMessage(); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 Kit Üretim</h1>
    <div class="s-yol">Üretim / <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" style="color:var(--t)">Kit Listesi</a> / <b>Kit Üret</b></div>
  </div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" class="btn btn-b btn-sm">← Listeye Dön</a>
</div>

<div class="s-body">
<?php if(!empty($hata_msg)): ?>
<div class="kart" style="padding:12px;margin-bottom:12px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">⚠️ <?=htmlspecialchars($hata_msg)?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:16px" class="kit-grid">

<!-- SOL: Ürün + Barkod -->
<div style="display:flex;flex-direction:column;gap:12px">

  <!-- Ürün Kodu Kutusu -->
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #0EA5E9">
    <div style="padding:14px;background:#F0F9FF;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#0EA5E9">📦 Ürün Bilgisi</div>
    </div>
    <div style="padding:16px">
      <?php if($baslatildi): ?>
      <div style="font-size:22px;font-weight:900;font-family:monospace;color:var(--t);margin-bottom:4px"><?=htmlspecialchars($urun_kodu)?></div>
      <div style="font-size:13px;color:var(--m2);margin-bottom:8px"><?=htmlspecialchars($urun_adi)?></div>
      <div style="font-size:12px;padding:6px 10px;background:#EFF6FF;border-radius:6px">
        <span style="color:var(--m2)">Paket No:</span> <strong style="font-family:monospace"><?=htmlspecialchars($paket_no)?></strong>
      </div>
      <input type="hidden" id="h_urun_kodu" value="<?=htmlspecialchars($urun_kodu)?>">
      <input type="hidden" id="h_urun_adi"  value="<?=htmlspecialchars($urun_adi)?>">
      <input type="hidden" id="h_paket_no"  value="<?=htmlspecialchars($paket_no)?>">
      <input type="hidden" id="h_personel"  value="<?=htmlspecialchars($kul_adi)?>">
      <?php else: ?>
      <div style="color:var(--m3);text-align:center;padding:16px">
        <div style="font-size:32px;margin-bottom:8px">📋</div>
        Kit listesinden "Kit Üret" butonuna tıklayarak başlatın.
        <br><br>
        <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-kit-liste" class="btn btn-t btn-sm">← Kit Listesine Dön</a>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <?php if($baslatildi): ?>
  <!-- Barkod Okutma -->
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #16A34A">
    <div style="padding:14px;background:#F0FDF4;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#16A34A">🔍 Barkod Okut</div>
    </div>
    <div style="padding:16px">
      <input id="barcodeInput" class="form-alan" placeholder="Barkodu okutun veya girin..." style="width:100%;font-size:16px;margin-bottom:10px" autocomplete="off" autofocus>
      <button onclick="barkodOkut()" class="btn btn-t" style="width:100%;margin-bottom:8px">📷 Okut</button>
      <div id="okutma_sonuc"></div>
    </div>
  </div>

  <!-- Kutu Kapat -->
  <div class="kart" style="padding:16px;border-top:4px solid #7C3AED">
    <div style="font-weight:800;font-size:13px;color:#7C3AED;margin-bottom:12px">📦 Kutu İşlemi</div>
    <div id="durum_ozet" style="font-size:12px;color:var(--m2);margin-bottom:12px">Henüz barkod okutulmadı.</div>
    <button id="kapatBtn" onclick="kutuKapat()" class="btn" style="width:100%;background:#7C3AED;color:#fff;opacity:.5" disabled>
      🔒 Kutuyu Kapat & Kaydet
    </button>
  </div>
  <?php endif; ?>

</div>

<!-- SAĞ: Reçete Tablosu -->
<div>
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #D97706">
    <div style="padding:14px;background:#FFFBEB;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:800;font-size:13px;color:#D97706">📋 Reçete Kontrol</div>
      <?php if($baslatildi): ?>
      <span id="tamamlanma_badge" style="font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px;background:#FEF9C3;color:#854D0E">0/<?=count($recete)?> tamamlandı</span>
      <?php endif; ?>
    </div>
    <div style="padding:0">
      <?php if(!$baslatildi): ?>
      <div style="padding:40px;text-align:center;color:var(--m3)">Ürün kodu girerek kontrolü başlatın.</div>
      <?php elseif(empty($recete)): ?>
      <div style="padding:24px;text-align:center;color:var(--m3)">Bu ürün için reçete bulunamadı.</div>
      <?php else: ?>
      <table id="receteTable" style="width:100%;border-collapse:collapse;font-size:13px">
        <thead><tr style="background:#1E3A5F;color:#fff">
          <th style="padding:10px 12px;text-align:left">Malzeme Kodu</th>
          <th style="padding:10px 12px;text-align:left">Malzeme Adı</th>
          <th style="padding:10px 12px;text-align:right">Hedef</th>
          <th style="padding:10px 12px;text-align:right">Okutulan</th>
          <th style="padding:10px 12px;text-align:right">Fark</th>
        </thead>
        <tbody>
        <?php foreach($recete as $rc): ?>
        <tr id="row_<?=htmlspecialchars($rc['malzeme_kodu'])?>" style="border-bottom:1px solid var(--kenar)"
            data-kod="<?=htmlspecialchars($rc['malzeme_kodu'])?>"
            data-hedef="<?=(int)$rc['miktar']?>"
            data-okutulan="0">
          <td style="padding:10px 12px;font-family:monospace"><?=htmlspecialchars($rc['malzeme_kodu'])?></td>
          <td style="padding:10px 12px"><?=htmlspecialchars($rc['malzeme_adi'])?></td>
          <td style="padding:10px 12px;text-align:right;font-weight:700"><?=(int)$rc['miktar']?></td>
          <td style="padding:10px 12px;text-align:right" class="td-okutulan">0</td>
          <td style="padding:10px 12px;text-align:right" class="td-fark">
            <span style="font-weight:700;padding:2px 8px;border-radius:6px;background:#FEF2F2;color:#DC2626"><?=(int)$rc['miktar']?></span>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>
</div>

</div><!-- /kit-grid -->

</div>

</div><!-- /s-body -->
<style>
@media(max-width:700px){.kit-grid{grid-template-columns:1fr!important}}
tr.tamam td { background:#F0FDF4 !important; }
tr.fazla td { background:#FFFBEB !important; }
</style>
<script>
var okutulanVeriler = {};
var receteToplam    = <?=count($recete)?>;
var miktarlarEsit   = false;

// Enter ile barkod okut
document.addEventListener('DOMContentLoaded', function(){
    var inp = document.getElementById('barcodeInput');
    if(inp) inp.addEventListener('keydown', function(e){
        if(e.key==='Enter'){ e.preventDefault(); barkodOkut(); }
    });
});

function barkodOkut() {
    var inp = document.getElementById('barcodeInput');
    var barkod = (inp ? inp.value : '').trim();
    if(!barkod) return;

    var satir = document.querySelector('[data-kod="' + barkod + '"]');
    if(!satir) {
        goster_sonuc('⚠️ Barkod reçetede bulunamadı: ' + barkod, 'hata');
        inp.value = ''; inp.focus();
        return;
    }

    var hedef    = parseInt(satir.dataset.hedef);
    var okutulan = parseInt(satir.dataset.okutulan) || 0;

    if(okutulan >= hedef) {
        goster_sonuc('⚠️ Bu malzeme için maksimum miktar okutuldu!', 'uyari');
        inp.value = ''; inp.focus();
        return;
    }

    // Güncelle
    okutulan += 1;
    satir.dataset.okutulan = okutulan;
    okutulanVeriler[barkod] = okutulan;

    var fark = hedef - okutulan;
    satir.querySelector('.td-okutulan').textContent = okutulan;
    var farkSpan = satir.querySelector('.td-fark span');
    farkSpan.textContent = fark;

    if(fark === 0) {
        farkSpan.style.background = '#D1FAE5'; farkSpan.style.color = '#065F46';
        satir.classList.add('tamam'); satir.classList.remove('fazla');
    } else if(fark < 0) {
        farkSpan.style.background = '#FEF9C3'; farkSpan.style.color = '#854D0E';
        satir.classList.add('fazla');
    } else {
        farkSpan.style.background = '#FEF2F2'; farkSpan.style.color = '#DC2626';
    }

    goster_sonuc('✅ ' + barkod + ' okutuldu (' + okutulan + '/' + hedef + ')', 'ok');

    // Tamamlanma kontrolü
    var tumSatirlar = document.querySelectorAll('#receteTable tbody tr');
    var tamam = 0;
    tumSatirlar.forEach(function(s){
        if(parseInt(s.dataset.hedef) === parseInt(s.dataset.okutulan)) tamam++;
    });
    document.getElementById('tamamlanma_badge').textContent = tamam + '/' + receteToplam + ' tamamlandı';

    miktarlarEsit = (tamam === receteToplam);
    var btn = document.getElementById('kapatBtn');
    if(miktarlarEsit) {
        btn.disabled = false; btn.style.opacity = '1';
        document.getElementById('durum_ozet').innerHTML = '<span style="color:#16A34A;font-weight:700">✅ Tüm malzemeler okutuldu! Kutuyu kapatabilirsiniz.</span>';
    } else {
        document.getElementById('durum_ozet').textContent = tamam + '/' + receteToplam + ' malzeme tamamlandı.';
    }

    inp.value = ''; inp.focus();
}

function goster_sonuc(mesaj, tip) {
    var el = document.getElementById('okutma_sonuc');
    var renkler = {ok:'#D1FAE5|#065F46', hata:'#FEF2F2|#7F1D1D', uyari:'#FFFBEB|#854D0E'};
    var r = (renkler[tip]||renkler['hata']).split('|');
    el.innerHTML = '<div style="padding:8px 12px;border-radius:6px;font-size:12px;font-weight:700;background:' + r[0] + ';color:' + r[1] + '">' + mesaj + '</div>';
    setTimeout(function(){ el.innerHTML = ''; }, 3000);
}

function kutuKapat() {
    if(!miktarlarEsit) {
        alert('Tüm malzemeler okutulmadan kutu kapatılamaz!');
        return;
    }

    if(!confirm('Kutuyu bantladınız mı? Onaylamak için Tamam\'a basın.')) return;

    var urunKodu = document.getElementById('h_urun_kodu').value;
    var urunAdi  = document.getElementById('h_urun_adi').value;
    var paketNo  = document.getElementById('h_paket_no').value;
    var personel = document.getElementById('h_personel').value;

    document.getElementById('kapatBtn').disabled = true;
    document.getElementById('kapatBtn').textContent = '⏳ Kaydediliyor...';

    var okutulanKodlar  = JSON.stringify(Object.keys(okutulanVeriler));
    var okutulanMiktar  = JSON.stringify(Object.values(okutulanVeriler));

    // Adım 1: Kit ekle → fişNo al
    var xhr1 = new XMLHttpRequest();
    xhr1.open('POST', '<?=BASE_URL?>/bolumler/uretim/ajax/kit_ekle.php', true);
    xhr1.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr1.onreadystatechange = function(){
        if(xhr1.readyState !== 4) return;
        if(xhr1.status !== 200 || xhr1.responseText.indexOf('HATA') === 0){
            alert('Kayıt hatası: ' + xhr1.responseText);
            document.getElementById('kapatBtn').disabled = false;
            document.getElementById('kapatBtn').textContent = '🔒 Kutuyu Kapat & Kaydet';
            return;
        }
        var fisNo = xhr1.responseText.trim();

        // Adım 2: Sarf detayı kaydet
        var xhr2 = new XMLHttpRequest();
        xhr2.open('POST', '<?=BASE_URL?>/bolumler/uretim/ajax/fis_sarf_detay.php', true);
        xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr2.onreadystatechange = function(){
            if(xhr2.readyState !== 4) return;
            // Adım 3: Fiş sayfasına yönlendir (otomatik yazdır)
            window.location.href =
                '<?=BASE_URL?>/bolumler/uretim/kit_fis_yazdir.php?fis_no=' + encodeURIComponent(fisNo);
        };
        xhr2.send(
            'urunKodu='        + encodeURIComponent(urunKodu)  +
            '&urunAdi='        + encodeURIComponent(urunAdi)   +
            '&paketNo='        + encodeURIComponent(paketNo)   +
            '&personel='       + encodeURIComponent(personel)  +
            '&fisNo='          + encodeURIComponent(fisNo)     +
            '&okutulanKodlar=' + encodeURIComponent(okutulanKodlar) +
            '&miktarlar='      + encodeURIComponent(okutulanMiktar)
        );
    };
    xhr1.send(
        'urunKodu=' + encodeURIComponent(urunKodu) +
        '&urunAdi=' + encodeURIComponent(urunAdi)  +
        '&paketNo=' + encodeURIComponent(paketNo)  +
        '&personel='+ encodeURIComponent(personel)
    );
}


</script>
