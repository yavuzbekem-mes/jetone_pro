<?php
/**
 * Paket Etiketi Yazdır — HTML + JsBarcode (inline SVG + CSS rotate)
 */
if (!defined('ROOT_DIR')) {
    require_once dirname(__DIR__, 2) . '/core/config.php';
}
if (!class_exists('Auth')) {
    require_once ROOT_DIR . '/core/auth.php';
}
if (!Auth::girisYapilmisMi()) {
    http_response_code(403); echo 'Oturum gecersiz'; exit;
}

function _g(string $k, string $def = ''): string {
    $v = urldecode($_GET[$k] ?? $def);
    if (!mb_check_encoding($v, 'UTF-8')) {
        $v = mb_convert_encoding($v, 'UTF-8', 'auto');
    }
    return trim($v);
}

// ── Çoklu paket desteği — paketler[] JSON POST veya tek GET ──────────────
$paketler_list = [];

if (!empty($_POST['paketler'])) {
    // JSON POST: paket bölme sonrası çoklu
    $paketler_list = json_decode($_POST['paketler'], true) ?: [];
} elseif (!empty($_GET['paketler'])) {
    $paketler_list = json_decode(urldecode($_GET['paketler']), true) ?: [];
}

// Tek GET parametresi ile geliyorsa (eski yöntem) — listeye ekle
if (empty($paketler_list)) {
    $paketler_list = [[
        'uretim_emri_no' => _g('uretim_emri_no'),
        'malzeme_kodu'   => _g('malzeme_kodu'),
        'malzeme_adi'    => _g('malzeme_adi'),
        'firma_kodu'     => _g('firma_kodu','15601'),
        'firma_adi'      => _g('firma_adi','Poliza A.S'),
        'uretim_tarihi'  => _g('uretim_tarihi', date('Y-m-d')),
        'operator_kodu'  => _g('operator_kodu'),
        'miktar'         => _g('miktar','0'),
        'lot_no'         => _g('lot_no'),
        'etiket_turu'    => strtoupper(_g('etiket_turu','URETIM')),
    ]];
}

// İlk paket — no-print bar için
$ilk = $paketler_list[0];
$uretim_no   = $ilk['uretim_emri_no'] ?? '';
$malz_kodu   = $ilk['malzeme_kodu']   ?? $ilk['stok_kodu']   ?? '';
$malz_adi    = $ilk['malzeme_adi']    ?? $ilk['stok_adi']    ?? '';
$lot_no      = $ilk['lot_no']         ?? $ilk['paket_no']    ?? '';
$miktar      = $ilk['miktar']         ?? '0';
$firma_kodu  = $ilk['firma_kodu']     ?? '15601';
$firma_adi   = $ilk['firma_adi']      ?? 'Poliza A.S';
$uretim_tar  = $ilk['uretim_tarihi']  ?? date('Y-m-d');
$operator    = $ilk['operator_kodu']  ?? $ilk['calisan']     ?? '';
$etiket_turu = strtoupper($ilk['etiket_turu'] ?? 'URETIM');
$kart_baslik = ($etiket_turu === 'IKINCI') ? 'Fire Tanitim Karti' : 'Malzeme Tanitim Karti';
$miktar_fmt  = is_numeric($miktar) ? number_format((float)$miktar, 0, '.', '') : $miktar;

// ── Stok koduna göre firma / logo belirleme ──────────────────────────────
// İleride DB'den veya config'den çekilebilir
// Şimdilik prefix bazlı kural:
$firma_map = [
    // 'PREFIX' => ['logo_yazi' => '...', 'firma_adi' => '...']
    // Varsayılan — tüm stoklar için POLIZA
];

// Stok kodu prefix kontrolü
$logo_yazi_html = '<span style="color:#CC0000">P</span>OL<span style="color:#CC0000">İ</span>ZA';
$firma_adi_goster = 'POLİZA ENDÜSTRİ A.Ş.';
$kart_baslik_goster = $kart_baslik;

// Örnek: BSH stokları için farklı logo (ileride eklenecek)
// if (str_starts_with($malz_kodu, '8001')) {
//     $logo_yazi_html = '<b>BSH</b>';
//     $firma_adi_goster = 'BSH Ev Aletleri';
// }

// Eğer GET'ten firma_adi geliyorsa onu kullan (override)
// Firma adı her zaman tam yazılır
$firma_adi_goster = 'POLİZA ENDÜSTRİ A.Ş.';

// İleride stok koduna göre farklı firma göstermek için:
// if (str_starts_with($malz_kodu, 'BSH')) {
//     $firma_adi_goster = 'BSH EV ALETLERİ SANAYİ A.Ş.';
// }
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Etiket — <?=htmlspecialchars($malz_kodu)?> (<?=count($paketler_list)?> etiket)</title>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { background:#f0f0f0; font-family:Arial, sans-serif; }

.no-print {
    background:#1E3A5F; color:#fff; padding:10px 20px;
    display:flex; gap:10px; align-items:center;
    position:fixed; top:0; left:0; right:0; z-index:100;
}
.no-print button {
    padding:8px 20px; border:none; border-radius:6px;
    font-size:13px; font-weight:700; cursor:pointer;
}
.btn-yazdir { background:#F97316; color:#fff; }
.btn-kapat  { background:#4B5563; color:#fff; }

.etiket-wrap {
    margin: 60px auto 20px;
    display: flex;
    justify-content: center;
}

/* Etiket 100mm x 120mm @ 96dpi = 378 x 453px */
.etiket {
    width: 378px;
    background: #fff;
    border: 1px solid #999;
    box-shadow: 0 4px 20px rgba(0,0,0,.15);
    display: flex;
    flex-direction: column;
}

/* ── ÜST ALAN: dikey barkodlar + orta logo ── */
.ust-alan {
    display: flex;
    align-items: stretch;
    height: 150px;
    border-bottom: 2px solid #222;
    overflow: hidden;
}

/* Dikey barkod wrapper — SVG rotate için */
.bc-dikey-wrap {
    width: 44px;
    min-width: 44px;
    height: 150px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
}
.bc-dikey-wrap.sol { border-right: 1px solid #ddd; }
.bc-dikey-wrap.sag { border-left:  1px solid #ddd; }

/* Dönen konteyner — wrapper'ı döndür, SVG normal kalır */
.bc-rotate {
    transform: rotate(90deg);
    transform-origin: center center;
    width: 148px;   /* ust-alan yüksekliği */
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
}
.bc-rotate svg {
    width: 148px !important;
    height: 40px !important;
}

/* Orta logo alanı */
.ust-orta {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 10px 6px;
    gap: 4px;
}
.firma-logo {
    font-size: 30px;
    font-weight: 900;
    letter-spacing: 4px;
    color: #000;
    line-height: 1;
}
.firma-logo .kirmizi { color: #CC0000; }
.firma-adi-txt  {
    font-size: 11px;
    font-weight: 600;
    color: #222;
    letter-spacing: .3px;
    text-align: center;
    margin-top: 2px;
}
.kart-baslik-txt {
    font-size: 11px;
    font-weight: 700;
    color: #1E3A5F;
    text-align: center;
    margin-top: 2px;
}

/* ── İÇERİK ── */
.icerik {
    padding: 8px 14px 6px 14px;
    border-bottom: 2px solid #222;
}
.satir {
    display: flex;
    align-items: baseline;
    padding: 3.5px 0;
    border-bottom: 1px solid #eee;
    font-size: 11.5px;
}
.satir:last-child { border-bottom: none; }
.etiket-kol {
    width: 115px;
    font-weight: 700;
    flex-shrink: 0;
    font-size: 11px;
    color: #222;
}
.deger-kol { flex: 1; color: #000; }
.malz-kodu-satir .deger-kol {
    font-size: 19px;
    font-weight: 900;
    letter-spacing: 1px;
}
.miktar-satir .etiket-kol { font-size: 17px; font-weight: 900; }
.miktar-satir .deger-kol  { font-size: 22px; font-weight: 900; }

/* ── ALT BARKOD ── */
.alt-barkod {
    padding: 6px 10px 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
}
.alt-barkod svg { width: 100%; max-height: 60px; }

/* ── PRINT ── */
@media print {
    .no-print { display: none !important; }
    body { background: #fff; margin: 0; padding: 0; }
    .etiket-wrap { margin: 0; }
    .etiket {
        width: 100mm;
        border: none;
        box-shadow: none;
        page-break-inside: avoid;
        overflow: hidden;
    }
    /* İçerik taşarsa küçült */
    .icerik-alan { font-size: 10px !important; }
    .satir { padding: 3px 8px !important; }
    .malz-kodu-satir .deger-kol { font-size: 17px !important; }
    .miktar-satir .etiket-kol   { font-size: 15px !important; }
    .miktar-satir .deger-kol    { font-size: 19px !important; }
    .alt-barkod { padding: 4px 8px 3px !important; }
    .alt-barkod svg { max-height: 52px !important; }
    @page { size: 100mm 130mm; margin: 0; }
    .etiket-wrap { page-break-after: always; break-after: page; }
    .etiket-wrap:last-child { page-break-after: avoid; break-after: avoid; }
}
</style>
</head>
<body>

<div class="no-print">
  <button class="btn-yazdir" onclick="yazdir()">🖨️ Yazdır</button>
  <button class="btn-kapat"  onclick="window.close()">✕ Kapat</button>
  <span style="font-size:12px;opacity:.7;margin-left:8px">
    <?=htmlspecialchars($malz_kodu)?> — <?=count($paketler_list)?> etiket
  </span>
</div>

<?php foreach($paketler_list as $pkt_idx => $pkt):
  $p_uretim_no  = $pkt['uretim_emri_no'] ?? $pkt['uretim_no'] ?? '';
  $p_malz_kodu  = $pkt['malzeme_kodu']   ?? $pkt['stok_kodu'] ?? '';
  $p_malz_adi   = $pkt['malzeme_adi']    ?? $pkt['stok_adi']  ?? '';
  $p_lot_no     = $pkt['lot_no']         ?? $pkt['paket_no']  ?? '';
  $raw_miktar   = $pkt['miktar'] ?? 0;
  $p_miktar     = (string)(float)$raw_miktar;
  $p_miktar_fmt = number_format((float)$raw_miktar, 0, '.', ''); // ayraçsız tam sayı
  error_log("[YAZDIR] idx=$pkt_idx lot=$p_lot_no raw_miktar=$raw_miktar p_miktar=$p_miktar fmt=$p_miktar_fmt");
  $p_operator   = $pkt['operator_kodu']  ?? $pkt['calisan']   ?? '';
  // Tarih — saat dahil göster
  $raw_tar = $pkt['uretim_tarihi'] ?? date('Y-m-d H:i');
  // Eğer sadece tarih varsa (Y-m-d) saati ekleme, varsa olduğu gibi kullan
  $p_uretim_tar = strlen($raw_tar) > 10 ? substr($raw_tar,0,16) : $raw_tar;
  $p_firma_kodu = trim($pkt['firma_kodu'] ?? '15601');
  if(!$p_firma_kodu) $p_firma_kodu = '15601';
  $p_firma_adi  = trim($pkt['firma_adi']  ?? '');
  // HAMMADDE/satınalma: tedarikçi adı geliyorsa kullan, gelmiyor ise POLİZA
  // Üretim/manuel: her zaman POLİZA
  if(!$p_firma_adi) $p_firma_adi = 'POLİZA ENDÜSTRİ A.Ş.';
  $p_etiket_tur = strtoupper($pkt['etiket_turu'] ?? 'URETIM');
  $p_is_hammadde = ($p_etiket_tur === 'HAMMADDE');
  if($p_etiket_tur==='IKINCI')     $p_kart_bas = 'Fire Tanitim Karti';
  elseif($p_is_hammadde)           $p_kart_bas = 'Hammadde Tanitim Karti';
  else                              $p_kart_bas = 'Malzeme Tanitim Karti';
  // Alan etiketleri
  $lbl_ue   = $p_is_hammadde ? 'Irsaliye No'    : 'Uretim Emri No';
  $lbl_fk   = $p_is_hammadde ? 'Tedarikci No'   : 'Firma Kodu';
  $lbl_fa   = $p_is_hammadde ? 'Tedarikci Adi'  : 'Firma Adi';
  $p_idx        = $pkt_idx; // barkod ID için
?>
<div class="etiket-wrap">
<div class="etiket">

  <!-- ÜST: sol dikey barkod | logo | sağ dikey barkod -->
  <div class="ust-alan">

    <div class="bc-dikey-wrap sol">
      <div class="bc-rotate">
        <svg id="bc-sol-<?=$p_idx?>"></svg>
      </div>
    </div>

    <div class="ust-orta">
      <div class="firma-logo"><?=$logo_yazi_html?></div>
      <div class="firma-adi-txt"><?=htmlspecialchars($firma_adi_goster)?></div>
      <div class="kart-baslik-txt"><?=htmlspecialchars($p_kart_bas)?></div>
    </div>

    <div class="bc-dikey-wrap sag">
      <div class="bc-rotate">
        <svg id="bc-sag-<?=$p_idx?>"></svg>
      </div>
    </div>

  </div>

  <!-- İÇERİK -->
  <div class="icerik">
    <div class="satir">
      <div class="etiket-kol"><?=$lbl_ue?></div>
      <div class="deger-kol">: <?=htmlspecialchars($p_uretim_no)?></div>
    </div>
    <div class="satir malz-kodu-satir">
      <div class="etiket-kol">Malzeme Kodu</div>
      <div class="deger-kol">: <?=htmlspecialchars($p_malz_kodu)?></div>
    </div>
    <div class="satir">
      <div class="etiket-kol">Malzeme Adi</div>
      <div class="deger-kol">: <?=htmlspecialchars($p_malz_adi)?></div>
    </div>
    <div class="satir">
      <div class="etiket-kol"><?=$lbl_fk?></div>
      <div class="deger-kol">: <?=htmlspecialchars($p_firma_kodu)?></div>
    </div>
    <div class="satir">
      <div class="etiket-kol"><?=$lbl_fa?></div>
      <div class="deger-kol">: <?=htmlspecialchars($p_firma_adi)?></div>
    </div>
    <div class="satir">
      <div class="etiket-kol">Uretim Tarihi</div>
      <div class="deger-kol">: <?=htmlspecialchars($p_uretim_tar)?></div>
    </div>
    <div class="satir">
      <div class="etiket-kol">Operator Kodu</div>
      <div class="deger-kol">: <?=htmlspecialchars($p_operator)?></div>
    </div>
    <!-- Miktar + GKK Kaşe yan yana -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:0;border-top:1px solid #ccc">
      <!-- Sol: Miktar + İrsaliye -->
      <div style="border-right:1px solid #ccc">
        <div class="satir miktar-satir" style="border-top:none">
          <div class="etiket-kol">Miktar</div>
          <div class="deger-kol">: <?=htmlspecialchars($p_miktar_fmt)?></div>
        </div>
        <div class="satir" style="border-top:1px solid #eee">
          <div class="etiket-kol">Irsaliye No</div>
          <div class="deger-kol">: </div>
        </div>
        <div class="satir" style="border-top:1px solid #eee">
          <div class="etiket-kol">Irsaliye Tarihi</div>
          <div class="deger-kol">: </div>
        </div>
      </div>
      <!-- Sağ: GKK Kaşe -->
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:4px 6px;min-height:60px">
        <div style="font-size:8px;font-weight:800;color:#555;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:3px">GKK</div>
        <div style="width:100%;height:44px;border:1.5px dashed #999;border-radius:3px;background:#FAFAFA"></div>
      </div>
    </div>
  </div>

  <!-- ALT: lot barkodu -->
  <div class="alt-barkod">
    <svg id="bc-alt-<?=$p_idx?>"></svg>
  </div>

</div>
</div>
<?php endforeach; ?>

<script>
var PAKETLER_LIST = <?=json_encode(array_map(function($pkt,$i){
    return [
        'idx'       => $i,
        'malz_kodu' => $pkt['malzeme_kodu'] ?? $pkt['stok_kodu'] ?? '',
        'firma_kodu'=> '15601', // Barkod tarafı daima sabit
        'lot_no'    => $pkt['lot_no']       ?? $pkt['paket_no']  ?? '',
    ];
},$paketler_list,array_keys($paketler_list)))?>;

var YAZDIR_YAPILDI = false;

function olusturBarkodlar() {
    PAKETLER_LIST.forEach(function(p) {
        var i = p.idx;
        var opt_dikey = {
            format:'CODE128', width:1.2, height:36,
            displayValue:true, fontSize:7, textMargin:1, margin:2,
            background:'#ffffff', lineColor:'#000000'
        };
        var opt_yatay = {
            format:'CODE128', width:1.5, height:50,
            displayValue:true, fontSize:10, textMargin:3, margin:5,
            background:'#fff', lineColor:'#000'
        };

        var elSol = document.getElementById('bc-sol-'+i);
        if(elSol && p.malz_kodu) {
            JsBarcode(elSol, p.malz_kodu, opt_dikey);
            elSol.setAttribute('width','148'); elSol.setAttribute('height','40');
        }
        var elSag = document.getElementById('bc-sag-'+i);
        if(elSag) {
            JsBarcode(elSag, '15601', opt_dikey); // Sabit 15601
            elSag.setAttribute('width','148'); elSag.setAttribute('height','40');
        }
        var elAlt = document.getElementById('bc-alt-'+i);
        if(elAlt && p.lot_no) {
            JsBarcode(elAlt, p.lot_no, opt_yatay);
        }
    });
}

function yazdir() {
    window.print();
}

// Sayfa yüklenince barkodları oluştur, sonra yazdır
window.addEventListener('load', function() {
    try {
        olusturBarkodlar();
    } catch(e) {
        console.error('Barkod hatasi:', e);
    }

    // Barkodlar render edildikten sonra yazdır
    setTimeout(function() {
        if (!YAZDIR_YAPILDI) {
            YAZDIR_YAPILDI = true;
            window.print();
        }
    }, 900);
});
</script>
</body>
</html>
