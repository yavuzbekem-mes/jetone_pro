<style>
/* ── İşlem Butonları — Critical CSS (flash önleme) ───────── */
.islem-btn-wrap {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(110px,1fr));
  gap:12px;
  width:100%;
}
.islem-btn {
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:10px;padding:22px 8px;border:none;border-radius:12px;
  width:100%;min-height:110px;cursor:pointer;font-size:14px;font-weight:800;
  font-family:inherit;transition:transform .15s,box-shadow .15s;
  box-shadow:0 3px 10px rgba(0,0,0,.1);
}
.islem-btn:hover { transform:translateY(-3px);box-shadow:0 8px 22px rgba(0,0,0,.2); }
.islem-btn:active { transform:translateY(0); }
@media(max-width:900px){ .islem-btn-wrap{grid-template-columns:repeat(3,1fr)} }
@media(max-width:600px){
  .islem-btn-wrap{grid-template-columns:repeat(2,1fr);gap:10px}
  .islem-btn{min-height:80px;font-size:12px;padding:14px 8px}
}
/* SweetAlert2 */
.swal2-container{z-index:99999!important}
/* Üst kart grid */
.ust-grid{display:grid;grid-template-columns:2fr 1fr 1fr;gap:14px;margin-bottom:16px}
@media(max-width:700px){
  .ust-grid{grid-template-columns:1fr!important}
}
</style>
<script>
/* ── Critical JS: Butonlar yüklenmeden önce tanımlı olmalı ── */
/* PHP değişkenleri henüz yok, stub olarak tanımla — gerçek versiyon aşağıda override edilir */
function openModal(id) {
    var el = document.getElementById(id);
    if (el) {
        el.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}
function closeModal(id) {
    var el = document.getElementById(id);
    if (el) {
        el.style.display = 'none';
        document.body.style.overflow = '';
    }
}
function switchTab(tab) {
    document.getElementById('tab-1k').style.display  = tab==='1k' ? 'block' : 'none';
    document.getElementById('tab-2k').style.display  = tab==='2k' ? 'block' : 'none';
    document.getElementById('tab-1k-btn').style.background = tab==='1k' ? 'var(--t)'      : 'var(--kenar-a)';
    document.getElementById('tab-1k-btn').style.color      = tab==='1k' ? '#fff'           : 'var(--m2)';
    document.getElementById('tab-2k-btn').style.background = tab==='2k' ? 'var(--t)'      : 'var(--kenar-a)';
    document.getElementById('tab-2k-btn').style.color      = tab==='2k' ? '#fff'           : 'var(--m2)';
}

function fireFisiUyarisi() {
    alert('Fire girisi yapilmadan urun girisi yapilamaz.');
}
function uretimTamamlandiUyari() {
    alert('Uretim tamamlandi. Daha fazla giris yapilamaz.');
}
function uretimBaslat(no) { /* yukleniyor */ }
function uretimKapat(no)  { /* yukleniyor */ }
function openFislerModal() {
    var el = document.getElementById('modal-fisler');
    if (el) { el.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
}
</script>
<?php
/**
 * MES Üretim Emri Detay
 * panel.php: 'uretim-mes-emri-detay' => 'bolumler/uretim/mes_uretim_emri_detay.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$ficheno = trim($_GET['ficheno'] ?? '');
if (!$ficheno) { echo '<div class="s-body"><div class="kart" style="padding:24px;text-align:center;color:var(--m3)">Üretim emri no belirtilmedi.</div></div>'; return; }
if (!$tigerdb_pdo) { echo '<div class="s-body"><div style="padding:12px;background:#FEF2F2;color:#7F1D1D;border-radius:var(--r-lg)">Tiger DB bağlantısı yok.</div></div>'; return; }

// ─── Tiger'dan emri bilgisi ────────────────────────────────────────────────────
$uretim = null;
try {
    $st = $tigerdb_pdo->prepare("SELECT
        PRO.LOGICALREF as ID,
        WS.CODE AS is_istasyonu, WS.NAME AS makine_adi,
        CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor'
             WHEN PRO.STATUS=0 THEN 'Başlamadı' ELSE 'Başlamadı' END AS durum,
        CONVERT(date, PRO.DATE_) AS uretim_tarihi,
        PRO.FICHENO AS uretim_no,
        IT.CODE AS mamul_kodu, IT.NAME AS mamul_adi,
        CONVERT(decimal(18,0),(
            SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT
            WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN (0,1)
        )) AS stok,
        CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
        CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
        CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT) - ISNULL((
            SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
            WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
        ),0)) AS birinci_kalite,
        CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT) + ISNULL((
            SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
            WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
        ),0)) AS kalan,
        CONVERT(decimal(18,0), ISNULL((
            SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE AS IK
            WHERE PRO.FICHENO=URETIM_EMRI_NO AND YEAR(URETIM_TARIHI)>=2026
        ),0)) AS ikinci_kalite,
        PRO.ITEMREF, IT.UNITSETREF AS uomref
    FROM dbo.LG_222_PRODORD AS PRO
    LEFT JOIN dbo.LG_222_ITEMS AS IT ON IT.LOGICALREF=PRO.ITEMREF
    LEFT JOIN dbo.LG_222_BOMASTER AS BOM ON BOM.LOGICALREF=PRO.MASTERREF
    LEFT JOIN dbo.LG_222_DISPLINE AS DIS ON DIS.PRODORDREF=PRO.LOGICALREF
    LEFT JOIN dbo.LG_222_WORKSTAT AS WS ON WS.LOGICALREF=DIS.WSREF
    WHERE PRO.FICHENO=?
    GROUP BY PRO.LOGICALREF,WS.CODE,WS.NAME,PRO.STATUS,
        CONVERT(date,PRO.DATE_),PRO.FICHENO,IT.CODE,IT.NAME,
        PRO.PLNAMOUNT,IT.LOGICALREF,PRO.ITEMREF,IT.UNITSETREF
    ORDER BY WS.CODE");
    $st->execute([$ficheno]);
    $uretim = $st->fetch(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

if (!$uretim) { echo '<div class="s-body"><div class="kart" style="padding:24px;text-align:center;color:var(--m3)">Üretim emri bulunamadı: '.htmlspecialchars($ficheno).'</div></div>'; return; }

// Hesaplar
$planlanan       = (float)($uretim['planlanan']??0);
$uretilen        = (float)($uretim['uretilen']??0);
$birinci_kalite  = (float)($uretim['birinci_kalite']??0);
$ikinci_kalite   = (float)($uretim['ikinci_kalite']??0);
$kalan           = (float)($uretim['kalan']??0);
$pct             = $planlanan > 0 ? min(100, round($birinci_kalite/$planlanan*100,1)) : 0;
$kal_pct         = $uretilen  > 0 ? round($ikinci_kalite/$uretilen*100,1) : 0;
$devam           = ($uretim['durum']==='Devam Ediyor');
$tamamlandi      = ($birinci_kalite >= $planlanan && $planlanan > 0);

// MES verileri
require_once dirname(dirname(__DIR__)) . '/core/db.php';
$mes_pdo_lokal = null;
try {
    require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
    $mes_pdo_lokal = $mes_pdo ?? null;
} catch(Throwable $e) {}

$duruslar = [];
if ($mes_pdo_lokal) {
    try {
        $sd = $mes_pdo_lokal->prepare("SELECT * FROM dbo.MAKINE_DURUSLARI WHERE URETIM_EMRI_NO=? ORDER BY BASLANGIC_ZAMANI DESC");
        $sd->execute([$ficheno]);
        $duruslar = $sd->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

$toplam_durus_dk = (int)array_sum(array_column($duruslar, 'SURE_DK'));

// ── Üretim girişleri — 1. Kalite (PAKETLER) ──────────────────────────────────
$giris_1k = [];
if($mes_pdo_lokal) {
    try {
        $gd = $mes_pdo_lokal->prepare(
            "SELECT ID,PAKET_NO,STOK_KODU,MIKTAR,BIRIM,CALISAN,URETIM_TARIHI,FIS_NO
             FROM dbo.PAKETLER
             WHERE URETIM_EMRI_NO=?
               AND ISNULL(ETIKET_TURU,'') NOT IN ('IKINCI','HURDA','FIRE')
             ORDER BY ID DESC"
        );
        $gd->execute([$ficheno]);
        $giris_1k = $gd->fetchAll(PDO::FETCH_ASSOC);

        // Tiger'dan üretim emrinin URETIM fişlerini al (gerçek Logo fiş no)
        if ($tigerdb_pdo && !empty($giris_1k)) {
            try {
                $pro_s = $tigerdb_pdo->prepare("SELECT LOGICALREF FROM dbo.LG_222_PRODORD WHERE FICHENO=?");
                $pro_s->execute([$ficheno]);
                $pro_row = $pro_s->fetch(PDO::FETCH_ASSOC);
                if ($pro_row) {
                    $pro_ref = (int)$pro_row['LOGICALREF'];
                    $fis_s = $tigerdb_pdo->prepare(
                        "SELECT STF.FICHENO AS FIS_NO,
                                CONVERT(varchar(16),STL.DATE_,120) AS FIS_TARIHI,
                                CONVERT(decimal(18,2),STL.AMOUNT) AS MIKTAR
                         FROM dbo.LG_222_02_STLINE STL
                         INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
                         WHERE STL.TRCODE=13 AND STL.PRODORDERREF=?
                           AND STL.LPRODSTAT=0 AND STF.CANCELLED=0
                         ORDER BY STL.DATE_ ASC"
                    );
                    $fis_s->execute([$pro_ref]);
                    $tiger_fisler = $fis_s->fetchAll(PDO::FETCH_ASSOC);
                    // Sıraya göre eşleştir (en eski fişe en eski paketi)
                    foreach ($giris_1k as $idx => &$paket) {
                        if (isset($tiger_fisler[$idx])) {
                            $paket['LOGO_FIS_NO'] = $tiger_fisler[$idx]['FIS_NO'];
                        }
                    }
                    unset($paket);
                }
            } catch(Throwable $te) {}
        }
    } catch(Throwable $e) {}
}

// ── İkinci Kalite girişleri (IKINCI_KALITE) ───────────────────────────────────
$giris_2k = [];
if($mes_pdo_lokal) {
    try {
        // 2. Kalite = PAKETLER tablosunda ETIKET_TURU='IKINCI'
        $gk = $mes_pdo_lokal->prepare(
            "SELECT ID,PAKET_NO,STOK_KODU,MIKTAR,BIRIM,CALISAN,URETIM_TARIHI,FIS_NO
             FROM dbo.PAKETLER
             WHERE URETIM_EMRI_NO=? AND ISNULL(ETIKET_TURU,'')='IKINCI'
             ORDER BY ID DESC"
        );
        $gk->execute([$ficheno]);
        $giris_2k = $gk->fetchAll(PDO::FETCH_ASSOC);

        // Ek olarak IKINCI_KALITE tablosunda da ara (varsa)
        try {
            $gk2 = $mes_pdo_lokal->prepare(
                "SELECT ID,URETIM_EMRI_NO,TOPLAM as MIKTAR,CALISAN,URETIM_TARIHI,
                        ISNULL(KALITE_PROBLEMI,'') AS KALITE_PROBLEMI
                 FROM dbo.IKINCI_KALITE WHERE URETIM_EMRI_NO=? ORDER BY ID DESC"
            );
            $gk2->execute([$ficheno]);
            $ik_rows = $gk2->fetchAll(PDO::FETCH_ASSOC);
            // IKINCI_KALITE satırlarını PAKETLER formatına uyarla
            foreach ($ik_rows as $ikr) {
                $giris_2k[] = [
                    'ID'           => $ikr['ID'],
                    'PAKET_NO'     => '',
                    'STOK_KODU'    => $uretim['mamul_kodu'] ?? '',
                    'MIKTAR'       => $ikr['MIKTAR'],
                    'BIRIM'        => 'ADET',
                    'CALISAN'      => $ikr['CALISAN'] ?? '',
                    'URETIM_TARIHI'=> $ikr['URETIM_TARIHI'] ?? '',
                    'FIS_NO'       => '',
                    'KALITE_PROBLEMI' => $ikr['KALITE_PROBLEMI'] ?? '',
                ];
            }
        } catch(Throwable $ek) {}
    } catch(Throwable $e) {}
}
$toplam_1k = (float)array_sum(array_column($giris_1k,'MIKTAR'));
$toplam_2k = (float)array_sum(array_column($giris_2k,'MIKTAR'));

// ─── Fire Fişi Kontrolü (EN ile başlayan makineler) ───────────────────────
$is_en         = stripos($uretim['is_istasyonu']??'','EN') === 0;
$fire_fisi_var = !$is_en; // EN değilse fire şartı yok

if ($is_en && $tigerdb_pdo) {
    try {
        $pro_ref = (int)($uretim['ID'] ?? 0);
        $fs = $tigerdb_pdo->prepare(
            "SELECT COUNT(DISTINCT STF.LOGICALREF) AS ADET
             FROM dbo.LG_222_02_STLINE STL
             INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
             WHERE STL.TRCODE=11 AND STL.PRODORDERREF=?
               AND STL.LPRODSTAT=0 AND STF.CANCELLED=0"
        );
        $fs->execute([$pro_ref]);
        $fr = $fs->fetch(PDO::FETCH_ASSOC);
        $fire_fisi_var = (($fr['ADET']??0) > 0);
    } catch(Throwable $e) {
        $fire_fisi_var = false; // Hata durumunda güvenli taraf
    }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">Üretim Emri: <span style="color:var(--t)"><?=htmlspecialchars($ficheno)?></span></h1>
    <div class="s-yol">Üretim / <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-mes-emri-liste" style="color:var(--t)">Emri Listesi</a> / <b><?=htmlspecialchars($ficheno)?></b></div>
  </div>
  <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-mes-emri-liste" class="btn btn-b">← Geri Dön</a>
</div>

<div class="s-body">

<!-- ─── Üst Bilgi Satırı ──────────────────────────────────────────────── -->
<div class="ust-grid">

  <!-- Stok Bilgisi -->
  <div class="kart" style="padding:20px;background:linear-gradient(135deg,#1E3A5F 0%,#2D5A8E 100%);border:none;color:#fff">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;opacity:.7;margin-bottom:10px">Mamul Bilgisi</div>
    <div style="font-size:22px;font-weight:900;letter-spacing:-.5px;margin-bottom:6px"><?=htmlspecialchars($uretim['mamul_kodu']??'')?></div>
    <div style="font-size:13px;opacity:.9;margin-bottom:14px;line-height:1.4"><?=htmlspecialchars($uretim['mamul_adi']??'')?></div>
    <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:12px;opacity:.8">
      <span>📅 <?=htmlspecialchars(substr($uretim['uretim_tarihi']??'',0,10))?></span>
      <span>🏭 <?=htmlspecialchars($uretim['is_istasyonu']??'')?></span>
      <span>⚙️ <?=htmlspecialchars($uretim['makine_adi']??'')?></span>
    </div>
    <?php if($devam): ?>
    <div style="margin-top:16px">
      <button onclick="uretimKapat('<?=htmlspecialchars($ficheno)?>')"
              style="background:#DC2626;color:#fff;border:none;border-radius:var(--r);padding:9px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">
        ⏹ Üretimi Kapat
      </button>
    </div>
    <?php else: ?>
    <div style="margin-top:16px">
      <button onclick="uretimBaslat('<?=htmlspecialchars($ficheno)?>')"
              style="background:#16A34A;color:#fff;border:none;border-radius:var(--r);padding:9px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">
        ▶ Üretimi Başlat
      </button>
    </div>
    <?php endif; ?>
  </div>

  <!-- Durum Kartı -->
  <div class="kart" style="padding:20px;border-top:4px solid <?=$devam?'#16A34A':'#DC2626'?>">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3);margin-bottom:12px">Üretim Durumu</div>
    <div style="margin-bottom:8px">
      <span style="display:inline-flex;align-items:center;gap:6px;padding:5px 14px;border-radius:20px;font-size:13px;font-weight:800;
             background:<?=$devam?'#D1FAE5':'#FEE2E2'?>;color:<?=$devam?'#065F46':'#7F1D1D'?>">
        <span style="width:8px;height:8px;border-radius:50%;background:<?=$devam?'#16A34A':'#DC2626'?>;display:inline-block"></span>
        <?=htmlspecialchars($uretim['durum'])?>
      </span>
    </div>
    <div style="margin-top:16px">
      <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--m2);margin-bottom:4px">
        <span>Planlanan: <?=number_format($planlanan,0,'.',',')?></span>
        <span>Kalan: <b style="color:<?=$kalan<0?'#DC2626':'var(--m)'?>"><?=number_format($kalan,0,'.',',')?></b></span>
      </div>
      <div style="background:var(--kenar);border-radius:6px;height:12px;overflow:hidden">
        <div style="width:<?=$pct?>%;height:100%;border-radius:6px;background:<?=$pct>=100?'#16A34A':($pct>=60?'var(--t)':'#DC2626')?>;transition:width .4s"></div>
      </div>
      <div style="text-align:right;font-size:13px;font-weight:900;margin-top:4px;color:<?=$pct>=100?'#16A34A':($pct>=60?'var(--t)':'#DC2626')?>">
        %<?=$pct?>
      </div>
    </div>
    <?php if($tamamlandi): ?>
    <div style="margin-top:12px;padding:8px 12px;background:#FEE2E2;border-radius:var(--r);font-size:12px;font-weight:700;color:#7F1D1D;text-align:center">
      ⚠️ Üretim tamamlandı — planlamaya haber ver
    </div>
    <?php endif; ?>
  </div>

  <!-- Kalite Kartı -->
  <div class="kart" style="padding:20px;border-top:4px solid <?=$kal_pct>=3?'#DC2626':'#F59E0B'?>">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3);margin-bottom:12px">Kalite Özeti</div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:var(--m2)">Toplam Üretilen</span>
        <span style="font-weight:700;font-size:14px"><?=number_format($uretilen,0,'.',',')?></span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:var(--m2)">1. Kalite</span>
        <span style="font-weight:800;font-size:14px;color:#16A34A"><?=number_format($birinci_kalite,0,'.',',')?></span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:var(--m2)">2. Kalite / Fire</span>
        <span style="font-weight:800;font-size:14px;color:<?=$ikinci_kalite>0?'#DC2626':'var(--m3)'?>"><?=number_format($ikinci_kalite,0,'.',',')?></span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:12px;color:var(--m2)">Kalitesizlik</span>
        <?php
        $kbg = $kal_pct<3?'#D1FAE5':($kal_pct<10?'#FEF3C7':'#FEE2E2');
        $kco = $kal_pct<3?'#065F46':($kal_pct<10?'#92400E':'#7F1D1D');
        ?>
        <span style="font-weight:800;font-size:13px;padding:2px 10px;border-radius:10px;background:<?=$kbg?>;color:<?=$kco?>">
          %<?=$kal_pct?>
        </span>
      </div>
      <div style="font-size:11px;color:var(--m3);text-align:right">Stok: <?=number_format((float)($uretim['stok']??0),0,'.',',')?></div>
    </div>
  </div>
</div>

<!-- ─── İşlem Butonları ──────────────────────────────────────────────── -->
<div class="kart" style="padding:20px;margin-bottom:16px">
  <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3);margin-bottom:16px">İşlemler</div>
  <div class="islem-btn-wrap">

    <?php
    // $is_en ve $fire_fisi_var üstte PHP'de hesaplandı
    // Ürün Girişi
    if($tamamlandi): ?>
    <button onclick="uretimTamamlandiUyari()" class="islem-btn" style="background:#D1FAE5;color:#065F46;border:2px solid #A7F3D0;cursor:not-allowed">
      <span style="font-size:28px">＋</span>
      <span>Ürün Girişi</span>
    </button>
    <?php elseif($is_en && !$fire_fisi_var): ?>
    <button onclick="fireFisiUyarisi()" class="islem-btn" style="background:#F59E0B;color:#fff">
      <span style="font-size:28px">⚠️</span>
      <span>Ürün Girişi</span>
    </button>
    <?php else: ?>
    <button onclick="openModal('modal-urun')" class="islem-btn" style="background:#16A34A;color:#fff">
      <span style="font-size:28px">＋</span>
      <span>Ürün Girişi</span>
    </button>
    <?php endif; ?>

    <?php if($is_en): ?>
    <button onclick="openModal('modal-hurda')" class="islem-btn" style="background:#DC2626;color:#fff">
      <span style="font-size:28px">🔥</span>
      <span>Hurda/Takoz</span>
    </button>
    <?php endif; ?>

    <?php if($is_en): ?>
    <button onclick="openModal('modal-ikinci')" class="islem-btn" style="background:#F59E0B;color:#fff">
      <span style="font-size:28px">⚑</span>
      <span>İkinci Kalite</span>
    </button>
    <?php else: ?>
    <button onclick="openModal('modal-montaj-fire')" class="islem-btn" style="background:#EA580C;color:#fff">
      <span style="font-size:28px">🔶</span>
      <span>Montaj Fire</span>
    </button>
    <?php endif; ?>

    <button onclick="openModal('modal-durus')" class="islem-btn" style="background:#0EA5E9;color:#fff">
      <span style="font-size:28px">⏱</span>
      <span>Makine Duruşu</span>
    </button>

    <button onclick="openModal('modal-recete')" class="islem-btn" style="background:#2563EB;color:#fff">
      <span style="font-size:28px">📄</span>
      <span>Reçete Raporu</span>
    </button>

    <button onclick="openFislerModal()" class="islem-btn" style="background:#7C3AED;color:#fff">
      <span style="font-size:28px">📋</span>
      <span>Üretim Fişleri</span>
    </button>
  </div>
</div>

<!-- ─── Makine Duruşları ──────────────────────────────────────────────── -->
<!-- ──────────────────────────────────────────────────────────────────────────
     ÜRETİM GİRİŞLERİ KARTI — 1. Kalite ve 2. Kalite
──────────────────────────────────────────────────────────────────────────── -->
<?php if(!empty($giris_1k) || !empty($giris_2k)): ?>
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:16px">
  <!-- Tab başlıkları -->
  <div style="display:flex;border-bottom:2px solid var(--kenar)">
    <button id="tab-1k-btn" onclick="switchTab('1k')"
            style="flex:1;padding:14px;font-weight:800;font-size:13px;border:none;cursor:pointer;background:var(--t);color:#fff;border-radius:0">
      ✅ 1. Kalite Girişleri
      <span style="background:rgba(255,255,255,.25);border-radius:12px;padding:2px 8px;font-size:11px;margin-left:6px">
        <?=count($giris_1k)?> kayıt | <?=number_format($toplam_1k)?> adet
      </span>
    </button>
    <button id="tab-2k-btn" onclick="switchTab('2k')"
            style="flex:1;padding:14px;font-weight:800;font-size:13px;border:none;cursor:pointer;background:var(--kenar-a);color:var(--m2)">
      ⚑ 2. Kalite / Fire Girişleri
      <span style="background:rgba(0,0,0,.08);border-radius:12px;padding:2px 8px;font-size:11px;margin-left:6px">
        <?=count($giris_2k)?> kayıt | <?=number_format($toplam_2k)?> adet
      </span>
    </button>
  </div>

  <!-- 1. Kalite Tablosu -->
  <div id="tab-1k" style="overflow:auto;max-height:300px">
    <?php if(empty($giris_1k)): ?>
    <div style="padding:24px;text-align:center;color:var(--m3);font-size:13px">Henüz 1. kalite girişi yok.</div>
    <?php else: ?>
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead style="position:sticky;top:0">
        <tr style="background:var(--kenar-a);border-bottom:1px solid var(--kenar)">
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">#</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Paket No</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Tarih</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Çalışan</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:right">Miktar</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Birim</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Logo Fiş No</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:center">Etiket</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($giris_1k as $gi=>$g):
        $logo_fis = $g['LOGO_FIS_NO'] ?? ($g['FIS_NO'] ?? '');
        $etiket_url = BASE_URL.'/bolumler/uretim/paket_yazdir.php'
            .'?uretim_emri_no='.urlencode($g['FIS_NO']??$ficheno)
            .'&malzeme_kodu='.urlencode($g['STOK_KODU']??$uretim['mamul_kodu']??'')
            .'&malzeme_adi='.urlencode($uretim['mamul_adi']??'')
            .'&firma_kodu=15601'
            .'&firma_adi='.urlencode('Poliza A.S')
            .'&uretim_tarihi='.urlencode(substr($g['URETIM_TARIHI']??'',0,10))
            .'&operator_kodu='.urlencode($g['CALISAN']??'')
            .'&miktar='.urlencode((string)(float)($g['MIKTAR']??0))
            .'&lot_no='.urlencode($g['PAKET_NO']??'')
            .'&etiket_turu=URETIM';
      ?>
      <tr style="border-bottom:1px solid var(--kenar);background:<?=$gi%2===0?'#fff':'var(--kenar-a)'?>">
        <td style="padding:8px 14px;color:var(--m3)"><?=$gi+1?></td>
        <td style="padding:8px 14px;font-weight:600;font-family:monospace;font-size:11px"><?=htmlspecialchars($g['PAKET_NO']??'')?></td>
        <td style="padding:8px 14px;font-size:11px;color:var(--m2)"><?=htmlspecialchars(substr($g['URETIM_TARIHI']??'',0,16))?></td>
        <td style="padding:8px 14px;font-size:11px"><?=htmlspecialchars($g['CALISAN']??'')?></td>
        <td style="padding:8px 14px;text-align:right;font-weight:700;color:#16A34A"><?=number_format((float)($g['MIKTAR']??0))?></td>
        <td style="padding:8px 14px;font-size:11px;color:var(--m3)"><?=htmlspecialchars($g['BIRIM']??'ADET')?></td>
        <td style="padding:8px 14px;font-size:11px;font-family:monospace;color:var(--m2)"><?=htmlspecialchars($logo_fis)?></td>
        <td style="padding:8px 14px;text-align:center;white-space:nowrap">
          <a href="<?=$etiket_url?>" target="_blank"
             style="display:inline-flex;align-items:center;gap:4px;padding:4px 8px;background:#F97316;color:#fff;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none;margin-bottom:4px">
            🖨️ Yazdır
          </a><br>
          <button onclick='detayIptalAc(<?=(int)($g["ID"]??0)?>,"1K",<?=json_encode($ficheno)?>,<?=json_encode($g["PAKET_NO"]??"")?>,<?=json_encode($uretim["mamul_kodu"]??"")?>,<?=json_encode($uretim["mamul_adi"]??"")?>,<?=(float)($g["MIKTAR"]??0)?>,<?=json_encode($logo_fis)?>)'
                  style="display:inline-flex;align-items:center;gap:3px;padding:4px 8px;background:#7C3AED;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
            🚫 İptal
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:var(--kenar-a);border-top:2px solid var(--kenar)">
          <td colspan="4" style="padding:8px 14px;font-weight:700;font-size:12px">TOPLAM</td>
          <td style="padding:8px 14px;text-align:right;font-weight:900;color:#16A34A;font-size:13px"><?=number_format($toplam_1k)?></td>
          <td colspan="2" style="padding:8px 14px;font-size:11px;color:var(--m3)">adet</td>
        </tr>
      </tfoot>
    </table>
    <?php endif; ?>
  </div>

  <!-- 2. Kalite Tablosu -->
  <div id="tab-2k" style="overflow:auto;max-height:300px;display:none">
    <?php if(empty($giris_2k)): ?>
    <div style="padding:24px;text-align:center;color:var(--m3);font-size:13px">Henüz 2. kalite / fire girişi yok.</div>
    <?php else: ?>
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead style="position:sticky;top:0">
        <tr style="background:var(--kenar-a);border-bottom:1px solid var(--kenar)">
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">#</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Paket No</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Tarih</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Çalışan</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:right">Miktar</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:left">Açıklama</th>
          <th style="padding:8px 14px;font-weight:700;color:var(--m2);text-align:center">Etiket</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($giris_2k as $ki=>$k):
        $sorun_str = htmlspecialchars($k['KALITE_PROBLEMI'] ?? '');
        $k_etiket_url = BASE_URL.'/bolumler/uretim/paket_yazdir.php'
            .'?uretim_emri_no='.urlencode($ficheno)
            .'&malzeme_kodu='.urlencode($k['STOK_KODU']??$uretim['mamul_kodu']??'')
            .'&malzeme_adi='.urlencode($uretim['mamul_adi']??'')
            .'&firma_kodu=15601&firma_adi='.urlencode('Poliza A.S')
            .'&uretim_tarihi='.urlencode(substr($k['URETIM_TARIHI']??'',0,10))
            .'&operator_kodu='.urlencode($k['CALISAN']??'')
            .'&miktar='.urlencode((string)(float)($k['MIKTAR']??0))
            .'&lot_no='.urlencode($k['PAKET_NO']??'')
            .'&etiket_turu=IKINCI';
      ?>
      <tr style="border-bottom:1px solid var(--kenar);background:<?=$ki%2===0?'#FFF5F5':'#FFF0F0'?>">
        <td style="padding:8px 14px;color:var(--m3)"><?=$ki+1?></td>
        <td style="padding:8px 14px;font-weight:600;font-family:monospace;font-size:11px"><?=htmlspecialchars($k['PAKET_NO']??'')?></td>
        <td style="padding:8px 14px;font-size:11px;color:var(--m2)"><?=htmlspecialchars(substr($k['URETIM_TARIHI']??'',0,16))?></td>
        <td style="padding:8px 14px;font-size:11px"><?=htmlspecialchars($k['CALISAN']??'')?></td>
        <td style="padding:8px 14px;text-align:right;font-weight:700;color:#DC2626"><?=number_format((float)($k['MIKTAR']??0))?></td>
        <td style="padding:8px 14px;font-size:11px;color:var(--m2)"><?=$sorun_str?></td>
        <td style="padding:8px 14px;text-align:center;white-space:nowrap">
          <?php if(!empty($k['PAKET_NO'])): ?>
          <a href="<?=$k_etiket_url?>" target="_blank"
             style="display:inline-flex;align-items:center;gap:4px;padding:4px 8px;background:#DC2626;color:#fff;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none;margin-bottom:4px">
            🖨️ Yazdır
          </a><br>
          <?php endif; ?>
          <button onclick='detayIptalAc(<?=(int)($k["ID"]??0)?>,"2K",<?=json_encode($ficheno)?>,<?=json_encode($k["PAKET_NO"]??"")?>,<?=json_encode($uretim["mamul_kodu"]??"")?>,<?=json_encode($uretim["mamul_adi"]??"")?>,<?=(float)($k["MIKTAR"]??0)?>,"")'
                  style="display:inline-flex;align-items:center;gap:3px;padding:4px 8px;background:#7C3AED;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
            🚫 İptal
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:#FEE2E2;border-top:2px solid #FECACA">
          <td colspan="4" style="padding:8px 14px;font-weight:700;font-size:12px">TOPLAM 2. KALİTE</td>
          <td style="padding:8px 14px;text-align:right;font-weight:900;color:#DC2626;font-size:13px"><?=number_format($toplam_2k)?></td>
          <td colspan="2" style="padding:8px 14px;font-size:11px;color:var(--m3)">adet</td>
        </tr>
      </tfoot>
    </table>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if(!empty($duruslar)): ?>
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:16px">
  <div style="padding:12px 18px;background:var(--kenar-a);border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <span style="font-weight:800;font-size:13px">⏱️ Makine Duruşları (<?=count($duruslar)?> kayıt)</span>
    <a href="<?=BASE_URL?>/panel.php?sayfa=uretim-durus-takip&emri=<?=urlencode($ficheno)?>" style="font-size:11px;color:var(--t);font-weight:700;text-decoration:none;padding:4px 10px;background:var(--t-a);border-radius:6px">📋 Tüm Duruşlar</a>
    <span style="font-size:12px;color:#DC2626;font-weight:700">
      Toplam: <?=floor($toplam_durus_dk/60)?>s <?=$toplam_durus_dk%60?>dk
    </span>
  </div>
  <div style="overflow:auto;max-height:260px">
  <table style="width:100%;border-collapse:collapse;font-size:12.5px">
    <thead style="position:sticky;top:0">
      <tr style="background:var(--kenar-a);border-bottom:1px solid var(--kenar)">
        <th style="padding:8px 14px;text-align:left;font-weight:700;color:var(--m2)">#</th>
        <th style="padding:8px 14px;text-align:left;font-weight:700;color:var(--m2)">İstasyon</th>
        <th style="padding:8px 14px;text-align:left;font-weight:700;color:var(--m2)">Başlangıç</th>
        <th style="padding:8px 14px;text-align:left;font-weight:700;color:var(--m2)">Bitiş</th>
        <th style="padding:8px 14px;text-align:right;font-weight:700;color:var(--m2)">Süre</th>
        <th style="padding:8px 14px;text-align:left;font-weight:700;color:var(--m2)">Neden</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($duruslar as $i=>$d):
      $dk = (int)($d['SURE_DK']??0);
      $sure = $dk>=60 ? floor($dk/60).'s '.($dk%60).'dk' : $dk.'dk';
    ?>
    <tr style="border-bottom:1px solid var(--kenar)">
      <td style="padding:8px 14px;color:var(--m3)"><?=$i+1?></td>
      <td style="padding:8px 14px;font-size:11px;font-weight:600"><?=htmlspecialchars($d['IS_ISTASYONU']??'')?></td>
      <td style="padding:8px 14px;font-size:11px;color:var(--m2)"><?=htmlspecialchars(substr($d['BASLANGIC_ZAMANI']??'',0,16))?></td>
      <td style="padding:8px 14px;font-size:11px;color:var(--m2)"><?=htmlspecialchars(substr($d['BITIS_ZAMANI']??'',0,16))?></td>
      <td style="padding:8px 14px;text-align:right;font-weight:700;color:#DC2626"><?=$sure?></td>
      <td style="padding:8px 14px"><?=htmlspecialchars($d['DURUS_NEDENI']??'')?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
<?php endif; ?>

<!-- ─── Modallar ──────────────────────────────────────────────────────── -->
<?php
$modal_cevreleri = [
    ['modal-urun',   '➕ Ürün Girişi',        'modal/uretim_giris_modal.php'],
    ['modal-hurda',  '🔥 Hurda/Fire Girişi',   'modal/hurda_giris_modal.php'],
    ['modal-ikinci',       '⚑ İkinci Kalite',        'modal/ikinci_kalite_modal.php'],
    ['modal-montaj-fire',  '🔶 Montaj Fire Girişi',  'modal/montaj_fire_modal.php'],
    ['modal-durus',  '⏱ Makine Duruşu',        'modal/makine_durusu_modal.php'],
    ['modal-recete', '📄 Reçete Raporu',        'modal/recete_modal.php'],
    ['modal-fisler', '📋 Üretim Fişleri',       null],
];

foreach($modal_cevreleri as [$mid, $mbaslik, $mdosya]):
?>
<div id="<?=$mid?>" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:40px 20px" onclick="if(event.target===this)closeModal('<?=$mid?>')">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);max-width:<?=in_array($mid,['modal-recete','modal-fisler'])?'1300px':(in_array($mid,['modal-ikinci','modal-montaj-fire'])?'900px':'600px')?>;width:100%;margin:0 auto;box-shadow:0 24px 60px rgba(0,0,0,.25);overflow:hidden">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,var(--t-a),var(--yuzey))">
      <span style="font-size:15px;font-weight:800"><?=$mbaslik?></span>
      <button onclick="closeModal('<?=$mid?>')" style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;color:var(--m2)">✕</button>
    </div>
    <div style="padding:20px;max-height:80vh;overflow-y:auto">
      <?php if($mdosya && file_exists(__DIR__.'/'.$mdosya)):
          include __DIR__.'/'.$mdosya;
      elseif($mid==='modal-fisler'): ?>
      <div id="fisler-yukleniyor" style="text-align:center;padding:40px;color:var(--m3)">⏳ Yükleniyor...</div>
      <div id="fisler-icerik" style="display:none"></div>
      <?php else: ?>
      <div style="padding:20px;text-align:center;color:var(--m3)">Modal dosyası bulunamadı.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>

</div><!-- /s-body -->

<style>
/* SweetAlert2 z-index */
.swal2-container { z-index: 99999 !important; }
.swal2-backdrop-show { z-index: 99998 !important; }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
var FICHENO        = '<?=htmlspecialchars($ficheno)?>';
var BASE           = '<?=BASE_URL?>';
var URETIM_DURUM   = '<?=htmlspecialchars($uretim['durum']??'')?>';
var URETIM_EMRI_ID = '<?=(int)($uretim['ID']??0)?>';
var IS_EN          = <?=$is_en?'true':'false'?>;
var FIRE_FISI_VAR  = <?=$fire_fisi_var?'true':'false'?>;
var TAMAMLANDI     = <?=$tamamlandi?'true':'false'?>;

function switchTab(tab) {
    document.getElementById('tab-1k').style.display  = tab==='1k' ? 'block' : 'none';
    document.getElementById('tab-2k').style.display  = tab==='2k' ? 'block' : 'none';
    document.getElementById('tab-1k-btn').style.background = tab==='1k' ? 'var(--t)'      : 'var(--kenar-a)';
    document.getElementById('tab-1k-btn').style.color      = tab==='1k' ? '#fff'           : 'var(--m2)';
    document.getElementById('tab-2k-btn').style.background = tab==='2k' ? 'var(--t)'      : 'var(--kenar-a)';
    document.getElementById('tab-2k-btn').style.color      = tab==='2k' ? '#fff'           : 'var(--m2)';
}

function fireFisiUyarisi() {
    Swal.fire({
        title: 'Fire Fisi Bulunamadi!',
        html: '<p>Urun girisi yapmadan once <b>Hurda/Takoz</b> fire girisi yapmaniz gerekiyor.</p>',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#DC2626',
        cancelButtonColor: '#16A34A',
        confirmButtonText: 'Tamam',
        cancelButtonText: 'Fire Girisi Yap'
    }).then(function(r) {
        if (r.dismiss === Swal.DismissReason.cancel) {
            openModal('modal-hurda');
        }
    });
}

function openModal(id) {
    if (id !== 'modal-recete' && URETIM_DURUM === 'Başlamadı') {
        Swal.fire({
            title: 'Üretim Başlatılmamış',
            text: FICHENO + ' nolu üretim emri henüz başlatılmamış. Başlatmak ister misiniz?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#16A34A',
            cancelButtonColor: '#6B7280',
            confirmButtonText: '▶ Evet, Başlat',
            cancelButtonText: 'İptal'
        }).then(r => { if (r.isConfirmed) uretimBaslat(FICHENO); });
        return;
    }
    document.getElementById(id).style.display = 'block';
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    document.getElementById(id).style.display = 'none';
    document.body.style.overflow = '';
}
function openFislerModal() {
    openModal('modal-fisler');
    var y = document.getElementById('fisler-yukleniyor');
    var i = document.getElementById('fisler-icerik');
    if (y) y.style.display = 'block';
    if (i) i.style.display = 'none';
    fetch(BASE + '/islemler/uretim/get_uretim_fisleri.php?uretim_no=' + encodeURIComponent(FICHENO))
        .then(r => r.json())
        .then(d => {
            if (y) y.style.display = 'none';
            if (i) {
                i.style.display = 'block';
                if (d.success && d.fisler && d.fisler.length) {
                    var html = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px">';
                    html += '<thead><tr style="background:var(--m);color:#fff">';
                    ['Fiş No','Tür','Tarih','Malzeme Kodu','Malzeme Adı','Miktar','Birim'].forEach(h => {
                        html += '<th style="padding:9px 12px;text-align:left;font-weight:700">'+h+'</th>';
                    });
                    html += '</tr></thead><tbody>';
                    d.fisler.forEach((f,idx) => {
                        var bg = idx%2===0?'var(--yuzey)':'var(--kenar-a)';
                        var renk = f.FIS_TURU==='FIRE'?'#DC2626':f.FIS_TURU==='SARF'?'#F59E0B':'#16A34A';
                        html += '<tr style="border-bottom:1px solid var(--kenar);background:'+bg+'">';
                        html += '<td style="padding:8px 12px;font-family:monospace;font-weight:700">'+(f.FIS_NO||'-')+'</td>';
                        html += '<td style="padding:8px 12px"><span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;background:'+renk+'22;color:'+renk+'">'+(f.FIS_TURU||'-')+'</span></td>';
                        html += '<td style="padding:8px 12px;font-size:11px;color:var(--m2)">'+(f.FIS_TARIHI||'-')+'</td>';
                        html += '<td style="padding:8px 12px;font-family:monospace;font-size:12px">'+(f.MALZEME_KODU||'-')+'</td>';
                        html += '<td style="padding:8px 12px">'+(f.MALZEME_ADI||'-')+'</td>';
                        html += '<td style="padding:8px 12px;text-align:right;font-weight:700">'+(f.MIKTAR||0)+'</td>';
                        html += '<td style="padding:8px 12px;text-align:center">'+(f.BIRIM||'-')+'</td>';
                        html += '</tr>';
                    });
                    html += '</tbody></table></div>';
                    i.innerHTML = html;
                } else {
                    i.innerHTML = '<div style="text-align:center;padding:40px;color:var(--m3)">Fiş kaydı bulunamadı.</div>';
                }
            }
        })
        .catch(e => {
            if (y) y.style.display = 'none';
            if (i) { i.style.display='block'; i.innerHTML='<div style="padding:20px;color:#DC2626">Hata: '+e.message+'</div>'; }
        });
}
function uretimTamamlandiUyari() {
    Swal.fire({
        title: 'Üretim Tamamlandı!',
        html: '<p>Planlanan miktara ulaşıldı.</p><p style="color:#DC2626;font-weight:700;margin-top:8px">Daha fazla ürün girişi yapılamaz.</p>',
        icon: 'warning',
        confirmButtonColor: '#DC2626',
        confirmButtonText: 'Tamam'
    });
}
function uretimBaslat(no) {
    Swal.fire({
        title: 'Üretim Emri Başlatılsın mı?',
        html: '<b>' + no + '</b> nolu emri başlatmak istediğinize emin misiniz?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#16A34A',
        cancelButtonColor: '#6B7280',
        confirmButtonText: '▶ Evet, Başlat',
        cancelButtonText: 'İptal'
    }).then(r => {
        if (!r.isConfirmed) return;

        // Bekleyin ekranı
        Swal.fire({
            title: 'Başlatılıyor...',
            html: '<div style="font-size:15px;color:#667085;margin-top:8px">Üretim emri başlatılıyor, lütfen bekleyin.</div>',
            icon: 'info',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => Swal.showLoading()
        });

        fetch(BASE + '/islemler/uretim/ue_durum.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({uretim_emri_no: no})
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                Swal.fire({
                    title: 'Başlatıldı!',
                    text: no + ' nolu üretim emri başarıyla başlatıldı.',
                    icon: 'success',
                    confirmButtonColor: '#16A34A',
                    confirmButtonText: 'Tamam'
                }).then(() => location.reload());
            } else {
                Swal.fire({
                    title: 'Hata!',
                    text: d.message || 'İşlem gerçekleştirilemedi.',
                    icon: 'error',
                    confirmButtonColor: '#DC2626'
                });
            }
        })
        .catch(e => {
            Swal.fire({
                title: 'Bağlantı Hatası',
                text: e.message,
                icon: 'error',
                confirmButtonColor: '#DC2626'
            });
        });
    });
}
function uretimKapat(no) {
    Swal.fire({
        title: 'Üretim Emri Kapatılsın mı?',
        html: '<b>' + no + '</b> nolu emri kapatmak istediğinize emin misiniz?<br><span style="color:#DC2626;font-size:13px">Bu işlem geri alınamaz.</span>',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#DC2626',
        cancelButtonColor: '#6B7280',
        confirmButtonText: '⏹ Evet, Kapat',
        cancelButtonText: 'İptal'
    }).then(r => {
        if (!r.isConfirmed) return;

        // Bekleyin ekranı
        Swal.fire({
            title: 'Kapatılıyor...',
            html: '<div style="font-size:15px;color:#667085;margin-top:8px">Üretim emri kapatılıyor, lütfen bekleyin.</div>',
            icon: 'info',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => Swal.showLoading()
        });

        fetch(BASE + '/islemler/uretim/ue_kapat.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({uretim_emri_no: no})
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                Swal.fire({
                    title: 'Kapatıldı!',
                    text: no + ' nolu üretim emri başarıyla kapatıldı.',
                    icon: 'success',
                    confirmButtonColor: '#16A34A',
                    confirmButtonText: 'Listeye Dön'
                }).then(() => {
                    location.href = BASE + '/panel.php?sayfa=uretim-mes-emri-liste';
                });
            } else {
                Swal.fire({
                    title: 'Hata!',
                    text: d.message || 'İşlem gerçekleştirilemedi.',
                    icon: 'error',
                    confirmButtonColor: '#DC2626'
                });
            }
        })
        .catch(e => {
            Swal.fire({
                title: 'Bağlantı Hatası',
                text: e.message,
                icon: 'error',
                confirmButtonColor: '#DC2626'
            });
        });
    });
}
</script>

<!-- ─── İptal Talebi Modalı (Detay Sayfası) ─────────────────────────────── -->
<div id="detay-iptal-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99000;overflow:auto;padding:40px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:500px;box-shadow:0 24px 60px rgba(0,0,0,.3)">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,rgba(124,58,237,.08),var(--yuzey))">
      <span style="font-size:15px;font-weight:800">🚫 İptal Talebi Oluştur</span>
      <button onclick="document.getElementById('detay-iptal-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer;font-size:16px">✕</button>
    </div>
    <div style="padding:22px">
      <div id="detay-iptal-bilgi" style="background:var(--kenar-a);border-left:4px solid #7C3AED;border-radius:var(--r);padding:12px 14px;margin-bottom:16px;font-size:12px;line-height:1.6"></div>
      <form id="detayIptalForm">
        <input type="hidden" name="mes_kayit_id"    id="di-id">
        <input type="hidden" name="kayit_tipi"      id="di-tip">
        <input type="hidden" name="uretim_emri_no"  id="di-emri">
        <input type="hidden" name="paket_no"        id="di-paket">
        <input type="hidden" name="stok_kodu"       id="di-stok">
        <input type="hidden" name="stok_adi"        id="di-stokadi">
        <input type="hidden" name="miktar"          id="di-miktar">
        <input type="hidden" name="logo_fis_no"    id="di-logo-fis">
        <div style="margin-bottom:16px">
          <label class="form-et">İptal Nedeni <span style="color:#DC2626">*</span></label>
          <textarea name="iptal_nedeni" id="di-neden" class="form-alan" rows="3"
                    placeholder="İptal nedenini açıklayın..." required style="resize:vertical"></textarea>
        </div>
        <div style="background:#FEF3C7;border-radius:var(--r);padding:10px 12px;margin-bottom:16px;font-size:11px;color:#92400E">
          ⚠️ Talep onaylandığında ilgili kayıt silinecektir. Tüm işlemler loglanmaktadır.
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" onclick="document.getElementById('detay-iptal-modal').style.display='none'"
                  class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">Vazgeç</button>
          <button type="submit" class="btn"
                  style="padding:10px 24px;background:#7C3AED;color:#fff;font-weight:800">🚫 Talep Oluştur</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function detayIptalAc(id, tip, emri, paket, stok, stokadi, miktar, logo_fis) {
    document.getElementById('di-id').value        = id;
    document.getElementById('di-tip').value       = tip;
    document.getElementById('di-emri').value      = emri;
    document.getElementById('di-paket').value     = paket || '';
    document.getElementById('di-stok').value      = stok  || '';
    document.getElementById('di-stokadi').value   = stokadi || '';
    document.getElementById('di-miktar').value    = miktar  || 0;
    document.getElementById('di-logo-fis').value  = logo_fis || '';
    document.getElementById('di-neden').value     = '';
    var fisStr = logo_fis ? ' — Logo Fiş: <b style="font-family:monospace">' + logo_fis + '</b>' : '';
    document.getElementById('detay-iptal-bilgi').innerHTML =
        '<b>' + tip + ' Kaydı</b> &nbsp;|&nbsp; Emri: <b>' + emri + '</b><br>' +
        'Stok: ' + stok + ' — Paket: ' + (paket||'—') + ' — Miktar: <b style="color:#DC2626">' + miktar + '</b>' + fisStr;
    document.getElementById('detay-iptal-modal').style.display = 'flex';
}

document.getElementById('detayIptalForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (!document.getElementById('di-neden').value.trim()) {
        Swal.fire({title:'Uyarı', text:'İptal nedeni zorunludur.', icon:'warning'}); return;
    }
    Swal.fire({title:'Talep oluşturuluyor...', allowOutsideClick:false, showConfirmButton:false,
               didOpen:function(){Swal.showLoading();}});
    var fd = new FormData(this), obj = {};
    fd.forEach(function(v,k){obj[k]=v;});
    fetch(BASE + '/islemler/uretim/iptal_talep_olustur.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(obj)
    })
    .then(function(r){
        return r.text().then(function(t){
            try{return JSON.parse(t);}catch(e){throw new Error(t.substring(0,120));}
        });
    })
    .then(function(d) {
        if (d.success) {
            Swal.fire({title:'Talep Oluşturuldu!', text: d.message, icon:'success',
                       confirmButtonColor:'#7C3AED', confirmButtonText:'Tamam'});
            document.getElementById('detay-iptal-modal').style.display = 'none';
        } else {
            Swal.fire({title:'Hata!', text: d.message, icon:'error', confirmButtonColor:'#DC2626'});
        }
    })
    .catch(function(err) {
        Swal.fire({title:'Bağlantı Hatası', text: err.message, icon:'error'});
    });
});
</script>
