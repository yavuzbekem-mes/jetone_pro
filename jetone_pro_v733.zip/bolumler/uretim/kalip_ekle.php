<?php
/**
 * Kalıp Bağlama Ekle / Formu
 * panel.php: 'uretim-kalip-ekle'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// GET'ten gelen ön doldurma (baslat sayfasından)
$pre_hat     = htmlspecialchars($_GET['hat']      ?? '');
$pre_urun    = htmlspecialchars($_GET['urun_kodu'] ?? '');
$pre_urun_adi= htmlspecialchars($_GET['urun_adi'] ?? '');

// İstasyonlar
try {
    // is_istasyonlari: istasyon_kodu + istasyon_mak_group
    $ist_rows = $db->query("SELECT istasyon_kodu, istasyon_mak_group FROM is_istasyonlari WHERE istasyon_group='ENJEKSİYON' ORDER BY istasyon_kodu")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $ist_rows = []; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔧 Kalıp Bağlama Ekle</h1>
    <div class="s-yol">Üretim / <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" style="color:var(--t)">Kalıp Bağlama</a> / <b>Yeni Ekle</b></div>
  </div>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" class="btn btn-b btn-sm">← Geri</a>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:480px 1fr;gap:16px;align-items:start">

  <div class="kart">
    <div style="font-size:13px;font-weight:800;margin-bottom:16px">⚙️ Kalıp Bağlama Bilgileri</div>
    <form action="<?= BASE_URL ?>/islemler/uretim/kalip_ekle.php" method="POST">

      <!-- Plan dışı: Tiger'dan malzeme ara -->
      <div class="form-grup">
        <label class="form-et">Ürün Kodu <span style="font-size:10px;color:var(--m2)">(mps_plan dışı ekleme için Tiger'dan ara)</span></label>
        <div style="display:flex;gap:8px">
          <input class="form-alan" type="text" name="urun_kodu" id="kalipUrunKod"
                 value="<?= $pre_urun ?>" style="font-family:monospace;flex:1"
                 placeholder="Kodu girin veya ara..." oninput="kalipKodDegisti()">
          <button type="button" onclick="kalipMalzemeAra()" class="btn btn-b btn-sm" style="white-space:nowrap">🔍 Tiger'dan Ara</button>
        </div>
      </div>
      <div id="kalipAramaSonuc" style="display:none;margin-bottom:10px;border:1px solid var(--kenar);border-radius:8px;overflow:hidden;max-height:200px;overflow-y:auto"></div>
      <div class="form-grup">
        <label class="form-et">Ürün Adı <span class="zorunlu">*</span></label>
        <input class="form-alan" type="text" name="urun_adi" id="kalipUrunAdi" value="<?= $pre_urun_adi ?>" required>
      </div>

      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Makine No <span class="zorunlu">*</span></label>
          <select class="form-alan" name="is_istasyonu" required>
            <option value="">Seçiniz</option>
            <?php foreach ($ist_rows as $ist):
                $ist_kod = $ist['istasyon_kodu'] ?? '';
                $ist_mak = $ist['istasyon_mak_group'] ?? $ist_kod;
            ?>
            <option value="<?= htmlspecialchars($ist_mak) ?>"
                    <?= $pre_hat===$ist_mak?'selected':'' ?>>
              <?= htmlspecialchars($ist_kod) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Vardiya</label>
          <select class="form-alan" name="vardiya" id="vardiyaSelect">
            <option value="1">1. Vardiya 08:00-16:00</option>
            <option value="2">2. Vardiya 16:00-24:00</option>
            <option value="3">3. Vardiya 24:00-08:00</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Aciliyet</label>
          <select class="form-alan" name="aciliyet">
            <option value="Normal">Normal</option>
            <option value="Acil">Acil</option>
            <option value="Acelesi Yok">Acelesi Yok</option>
          </select>
        </div>
      </div>

      <div class="form-grup">
        <label class="form-et">Açıklama</label>
        <textarea class="form-alan" name="kalip_aciklama" rows="3" placeholder="Kalıp değişimi ile ilgili notlar..."></textarea>
      </div>

      <input type="hidden" name="ekleyen" value="<?= htmlspecialchars($kul_adi) ?>">
      <div class="form-footer">
        <a href="<?= BASE_URL ?>/panel.php?sayfa=uretim-kalip-baslat" class="btn btn-b">İptal</a>
        <button type="submit" class="btn btn-t">🔧 Kalıp Bağlamayı Başlat</button>
      </div>
    </form>
  </div>

  <!-- Sağ: Bilgi -->
  <div class="kart" style="border-left:4px solid var(--uya)">
    <div style="font-size:13px;font-weight:800;margin-bottom:12px">ℹ️ Kalıp Bağlama Akışı</div>
    <?php foreach ([
      ['1', '🔧', 'Kalıp bağlama işlemini başlatın', 'Makine, ürün ve vardiya bilgilerini girin'],
      ['2', '⏳', 'Devam Edenler sayfasında takip edin', '"Tamamla" butonuyla işlemi kapatın'],
      ['3', '✅', 'Tamamlanan sayfasında arşive gider', 'Geçen süre otomatik hesaplanır'],
    ] as [$n,$ik,$bas,$alt]): ?>
    <div style="display:flex;gap:12px;margin-bottom:14px">
      <div style="width:28px;height:28px;border-radius:50%;background:var(--t);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;flex-shrink:0"><?= $n ?></div>
      <div>
        <div style="font-weight:700;font-size:13px"><?= $ik ?> <?= $bas ?></div>
        <div style="font-size:12px;color:var(--m2)"><?= $alt ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

</div>
</div>

<script>
(function(){
  var s = document.getElementById('vardiyaSelect');
  var h = new Date().getHours();
  s.value = h>=8&&h<16?'1':(h>=16?'2':'3');
})();
function kalipKodDegisti(){
  var v=document.getElementById('kalipUrunKod').value.trim();
  if(v.length<2){ document.getElementById('kalipAramaSonuc').style.display='none'; return; }
}
function kalipMalzemeAra(){
  var kod=document.getElementById('kalipUrunKod').value.trim();
  if(!kod){ alert('Ürün kodu veya adı giriniz'); return; }
  var div=document.getElementById('kalipAramaSonuc');
  div.style.display='block'; div.innerHTML='<div style="padding:10px;color:var(--m2)">Aranıyor...</div>';
  fetch('<?= BASE_URL ?>/bolumler/uretim/ajax/kalip_malzeme_ara.php?q='+encodeURIComponent(kod))
  .then(r=>r.json()).then(function(j){
    if(!j.ok||!j.data.length){ div.innerHTML='<div style="padding:10px;color:var(--m2)">Sonuç bulunamadı</div>'; return; }
    var html='';
    j.data.forEach(function(m){
      html+='<div style="padding:8px 12px;border-bottom:1px solid var(--kenar);cursor:pointer;font-size:12px" '
        +'onmouseover="this.style.background='var(--kenar-a)'" onmouseout="this.style.background=''" '
        +'onclick="kalipSecMalzeme(''+m.kod.replace(/'/g,"\'")+'',''+m.adi.replace(/'/g,"\'")+'')">'
        +'<span style="font-family:monospace;font-weight:700;color:var(--t)">'+m.kod+'</span> '
        +'<span style="color:var(--m2)">'+m.adi+'</span></div>';
    });
    div.innerHTML=html;
  }).catch(function(){ div.innerHTML='<div style="padding:10px;color:#EF4444">Hata oluştu</div>'; });
}
function kalipSecMalzeme(kod,adi){
  document.getElementById('kalipUrunKod').value=kod;
  document.getElementById('kalipUrunAdi').value=adi;
  document.getElementById('kalipAramaSonuc').style.display='none';
}
</script>
