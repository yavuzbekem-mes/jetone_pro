<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = htmlspecialchars($kul['ad_soyad'] ?? $kul['email'] ?? '');
?>
<style>
#aip-wrap { display:flex; flex-direction:column; height:calc(100vh - 130px); border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,.10); }
#aip-header { background:linear-gradient(135deg,#667EEA,#764BA2); padding:14px 20px; display:flex; align-items:center; gap:12px; flex-shrink:0; }
#aip-ikon { width:42px;height:42px;background:rgba(255,255,255,.2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px; }
#aip-info { flex:1; }
#aip-baslik { color:#fff;font-weight:800;font-size:15px; }
#aip-durum { color:rgba(255,255,255,.75);font-size:11px;margin-top:2px; }
#aip-actions { display:flex;gap:8px; }
#aip-actions button { background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:#fff;padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;transition:background .15s; }
#aip-actions button:hover { background:rgba(255,255,255,.28); }
#aip-oneriler { display:flex;gap:6px;flex-wrap:wrap;padding:10px 16px 0;background:#F8FAFC;flex-shrink:0; }
.aip-oneri { background:#EEF2FF;color:#667EEA;border:1px solid #C7D2FE;border-radius:20px;padding:5px 13px;font-size:12px;cursor:pointer;white-space:nowrap;transition:background .15s; }
.aip-oneri:hover { background:#E0E7FF; }
#aip-mesajlar { flex:1;overflow-y:auto;padding:20px;background:#F8FAFC;display:flex;flex-direction:column;gap:10px; }
.aip-msg { max-width:78%;padding:10px 15px;border-radius:14px;font-size:13px;line-height:1.6;word-break:break-word; }
.aip-msg.user { align-self:flex-end;background:#667EEA;color:#fff;border-radius:14px 14px 2px 14px; }
.aip-msg.bot { align-self:flex-start;background:#fff;color:#1E293B;border:1px solid #E2E8F0;border-radius:14px 14px 14px 2px;box-shadow:0 2px 8px rgba(0,0,0,.06); }
.aip-msg.bot table { border-collapse:collapse;width:100%;margin:8px 0;font-size:12px; }
.aip-msg.bot table th { background:#EEF2FF;padding:6px 10px;border:1px solid #C7D2FE;text-align:left; }
.aip-msg.bot table td { padding:5px 10px;border:1px solid #E2E8F0; }
.aip-msg.bot table tr:nth-child(even) td { background:#F8FAFC; }
.aip-msg.bot code { background:#F1F5F9;padding:2px 6px;border-radius:4px;font-size:11px; }
.aip-msg.bot pre { background:#1E293B;color:#E2E8F0;padding:10px 14px;border-radius:8px;overflow-x:auto;font-size:11px;margin:6px 0; }
.aip-msg.bot ul,.aip-msg.bot ol { padding-left:18px;margin:4px 0; }
.aip-msg.bot strong { font-weight:700; }
.aip-meta { font-size:10px;color:#94A3B8;margin-top:2px; }
.aip-meta.user { align-self:flex-end; }
.aip-meta.bot { align-self:flex-start; }
.aip-sep { align-self:center;background:#E2E8F0;color:#64748B;font-size:10px;padding:3px 12px;border-radius:10px;margin:6px 0; }
.aip-typing { align-self:flex-start;background:#fff;border:1px solid #E2E8F0;border-radius:14px;padding:12px 16px;display:flex;gap:5px;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.06); }
.aip-typing span { width:8px;height:8px;background:#94A3B8;border-radius:50%;animation:aipT 1.2s infinite; }
.aip-typing span:nth-child(2){animation-delay:.2s} .aip-typing span:nth-child(3){animation-delay:.4s}
@keyframes aipT{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-7px)}}
.aip-debug { font-size:10px;color:#CBD5E1;align-self:flex-start;padding:0 4px;font-style:italic; }
#aip-footer { background:#fff;border-top:1px solid #E2E8F0;padding:14px 16px;flex-shrink:0; }
#aip-input-row { display:flex;gap:10px;align-items:flex-end; }
#aip-input { flex:1;border:1.5px solid #E2E8F0;border-radius:12px;padding:10px 16px;font-size:13px;outline:none;font-family:inherit;resize:none;max-height:120px;overflow-y:auto;line-height:1.5;transition:border-color .15s; }
#aip-input:focus { border-color:#667EEA; }
#aip-btn { width:42px;height:42px;border-radius:50%;background:#667EEA;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s; }
#aip-btn:hover { background:#5B6FD1; }
#aip-btn:disabled { background:#CBD5E1;cursor:not-allowed; }
#aip-btn svg { width:18px;height:18px;fill:#fff; }
#aip-hint { font-size:10px;color:#94A3B8;margin-top:6px;text-align:center; }
@media(max-width:600px){ .aip-msg{max-width:92%} }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🤖 AI Asistan</h1>
    <div class="s-yol">Yapay Zeka / <b>Sohbet</b></div>
  </div>
</div>

<div class="kart" style="padding:0;overflow:hidden;margin-bottom:0">
<div id="aip-wrap">

  <div id="aip-header">
    <div id="aip-ikon">🤖</div>
    <div id="aip-info">
      <div id="aip-baslik">Jetone AI Asistan</div>
      <div id="aip-durum">● Çevrimiçi · Gerçek zamanlı veritabanı erişimi</div>
    </div>
    <div id="aip-actions">
      <button onclick="aipExport()">📥 Dışa Aktar</button>
      <button onclick="aipTemizle()">🗑 Temizle</button>
    </div>
  </div>

  <div id="aip-oneriler">
    <button class="aip-oneri" onclick="aipSor(this.textContent)">📦 Aktif siparişler</button>
    <button class="aip-oneri" onclick="aipSor(this.textContent)">🏭 Üretim durumu</button>
    <button class="aip-oneri" onclick="aipSor(this.textContent)">👷 Bugün kaç kişi geldi?</button>
    <button class="aip-oneri" onclick="aipSor(this.textContent)">⚠️ Temin tarihi geçmiş siparişler</button>
    <button class="aip-oneri" onclick="aipSor(this.textContent)">📊 OEM tekmelik stokları</button>
    <button class="aip-oneri" onclick="aipSor(this.textContent)">🔴 Geciken satış siparişleri</button>
  </div>

  <div id="aip-mesajlar"></div>

  <div id="aip-footer">
    <div id="aip-input-row">
      <textarea id="aip-input" placeholder="Soru sorun... (Enter: gönder, Shift+Enter: yeni satır)" rows="1"
        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();aipGonder()}"></textarea>
      <button id="aip-btn" onclick="aipGonder()">
        <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
      </button>
    </div>
    <div id="aip-hint">Ctrl+K: Yeni sohbet &nbsp;·&nbsp; Veriler gerçek zamanlı veritabanından</div>
  </div>

</div>
</div>

<script>
var _aip = { gecmis:[], yukleniyor:false, KEY:'jetone_ai_chat_v2' };

// ── LOCALSTORAGE ─────────────────────────────────────────────────
function aipKaydet() {
  try {
    var mesajlar = [];
    document.querySelectorAll('[data-aip-rol]').forEach(function(el) {
      mesajlar.push({ rol:el.dataset.aipRol, metin:el.dataset.aipMetin, zaman:el.dataset.aipZaman });
    });
    localStorage.setItem(_aip.KEY, JSON.stringify({ gecmis:_aip.gecmis, mesajlar:mesajlar }));
  } catch(e) {}
}

function aipYukle() {
  try {
    var s = localStorage.getItem(_aip.KEY);
    if (s) {
      var data = JSON.parse(s);
      _aip.gecmis = data.gecmis || [];
      var mesajlar = data.mesajlar || [];
      if (mesajlar.length > 0) {
        document.getElementById('aip-oneriler').style.display = 'none';
        var sonTarih = null;
        mesajlar.forEach(function(m) {
          var tarih = m.zaman ? m.zaman.slice(0,10) : null;
          if (tarih && tarih !== sonTarih) { aipSepEkle(tarih); sonTarih = tarih; }
          aipMsj(m.rol, m.metin, m.zaman, false);
        });
        aipScrollAlt();
        return;
      }
    }
  } catch(e) {}
  aipKarsila();
}

function aipKarsila() {
  aipMsj('bot', 'Merhaba <?php echo $kul_adi; ?>! 👋\n\nBen Jetone ERP asistanıyım. Sipariş, üretim, stok, personel ve satınalma sorularını gerçek zamanlı veritabanı verilerine dayanarak yanıtlayabilirim.\n\nNe öğrenmek istersiniz?', new Date().toISOString(), false);
}

// ── MESAJ RENDER ─────────────────────────────────────────────────
function aipMsj(rol, metin, zaman, scroll) {
  if (scroll === undefined) scroll = true;
  var c = document.getElementById('aip-mesajlar');
  var el = document.createElement('div');
  el.className = 'aip-msg ' + rol;
  el.dataset.aipRol = rol;
  el.dataset.aipMetin = metin;
  el.dataset.aipZaman = zaman || new Date().toISOString();
  el.innerHTML = rol === 'bot' ? aipMd(metin) : escHtml(metin);
  c.appendChild(el);
  if (zaman) {
    var mt = document.createElement('div');
    mt.className = 'aip-meta ' + rol;
    try { mt.textContent = new Date(zaman).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'}); } catch(e){}
    c.appendChild(mt);
  }
  if (scroll) aipScrollAlt();
}

function aipSepEkle(tarih) {
  var bugun = new Date().toISOString().slice(0,10);
  var dun   = new Date(Date.now()-86400000).toISOString().slice(0,10);
  var etiket = tarih===bugun?'Bugün':tarih===dun?'Dün':tarih;
  var el = document.createElement('div');
  el.className = 'aip-sep';
  el.textContent = etiket;
  document.getElementById('aip-mesajlar').appendChild(el);
}

function aipScrollAlt() { var m=document.getElementById('aip-mesajlar'); m.scrollTop=m.scrollHeight; }
function escHtml(t) { return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ── GÖNDER ───────────────────────────────────────────────────────
function aipSor(t) { document.getElementById('aip-input').value=t; aipGonder(); }

function aipGonder() {
  if (_aip.yukleniyor) return;
  var inp = document.getElementById('aip-input');
  var soru = inp.value.trim();
  if (!soru) return;
  inp.value = ''; inp.style.height = '';
  document.getElementById('aip-oneriler').style.display = 'none';
  var zaman = new Date().toISOString();
  // Tarih ayracı — bugünün ilk mesajı mı?
  var mevcutSep = document.querySelector('.aip-sep');
  var bugun = zaman.slice(0,10);
  var sonSep = document.querySelectorAll('.aip-sep');
  var sonSepTarih = sonSep.length ? sonSep[sonSep.length-1].textContent : null;
  if (!mevcutSep || (sonSepTarih !== 'Bugün' && sonSepTarih !== bugun)) aipSepEkle(bugun);
  aipMsj('user', soru, zaman);
  aipCagir(soru, null);
}

function aipCagir(soru, sql_run) {
  _aip.yukleniyor = true;
  document.getElementById('aip-btn').disabled = true;
  var tp = document.createElement('div');
  tp.className = 'aip-typing'; tp.id = 'aip-typing';
  tp.innerHTML = '<span></span><span></span><span></span>';
  if (sql_run) {
    var b=document.createElement('span');
    b.style.cssText='font-size:10px;color:#667EEA;margin-left:8px';
    b.textContent='Veritabanı sorgulanıyor...';
    tp.appendChild(b);
  }
  document.getElementById('aip-mesajlar').appendChild(tp);
  aipScrollAlt();

  var fd = new FormData();
  fd.append('soru', soru);
  fd.append('gecmis', JSON.stringify(_aip.gecmis));
  if (sql_run) fd.append('sql_run', JSON.stringify(sql_run));

  fetch('<?php echo BASE_URL;?>/bolumler/planlama/ajax/ai_chat.php', {
    method:'POST', body:fd, credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  })
  .then(function(r){ return r.text().then(function(t){
    try{return JSON.parse(t);}
    catch(e){return {ok:false,msg:'Sunucu: '+t.substring(0,400)};}
  }); })
  .then(function(d) {
    var t=document.getElementById('aip-typing'); if(t)t.remove();
    _aip.yukleniyor=false;
    document.getElementById('aip-btn').disabled=false;
    if (!d.ok) { aipMsj('bot','❌ '+(d.msg||'Hata')); aipKaydet(); return; }

    if (!sql_run) _aip.gecmis.push({role:'user',content:soru});
    _aip.gecmis.push({role:'assistant',content:d.cevap});
    if (_aip.gecmis.length>30) _aip.gecmis=_aip.gecmis.slice(-30);

    if (d.action==='navigate'&&d.navigate) {
      aipMsj('bot','🔀 '+d.cevap); aipKaydet();
      setTimeout(function(){ window.location.href=BASE_URL+'/panel.php?sayfa='+d.navigate; },800);
    } else if (d.action==='query'&&d.sql_run) {
      aipMsj('bot','🔍 '+d.cevap);
      setTimeout(function(){ aipCagir(soru,d.sql_run); },200);
    } else if (d.action==='ask'&&d.ask) {
      aipMsj('bot',d.cevap);
      var inp2=document.getElementById('aip-input');
      if (d.ask_ipucu){inp2.placeholder=d.ask_ipucu;setTimeout(function(){inp2.placeholder='Soru sorun...';},12000);}
      inp2.focus(); aipKaydet();
    } else {
      aipMsj('bot',d.cevap); aipKaydet();
    }
    if (d.debug_ctx) {
      var dbg=document.createElement('div'); dbg.className='aip-debug';
      dbg.textContent='📊 '+d.debug_ctx;
      document.getElementById('aip-mesajlar').appendChild(dbg);
    }
  })
  .catch(function(e){
    var t=document.getElementById('aip-typing'); if(t)t.remove();
    _aip.yukleniyor=false; document.getElementById('aip-btn').disabled=false;
    aipMsj('bot','❌ Bağlantı hatası: '+e.message);
  });
}

// ── ARAÇLAR ──────────────────────────────────────────────────────
function aipTemizle() {
  if (!confirm('Tüm sohbet geçmişi silinecek. Emin misiniz?')) return;
  localStorage.removeItem(_aip.KEY);
  _aip.gecmis=[];
  document.getElementById('aip-mesajlar').innerHTML='';
  document.getElementById('aip-oneriler').style.display='flex';
  aipKarsila();
}

function aipExport() {
  var satirlar=['Jetone AI Sohbet — '+new Date().toLocaleString('tr-TR'),''];
  document.querySelectorAll('[data-aip-rol]').forEach(function(el){
    var rol=el.dataset.aipRol==='user'?'SİZ':'AI';
    var t=el.dataset.aipZaman?new Date(el.dataset.aipZaman).toLocaleString('tr-TR'):'';
    satirlar.push('['+t+'] '+rol+':');
    satirlar.push(el.dataset.aipMetin||el.textContent.trim());
    satirlar.push('');
  });
  var blob=new Blob([satirlar.join('\n')],{type:'text/plain;charset=utf-8'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='jetone-ai-'+new Date().toISOString().slice(0,10)+'.txt';
  a.click();
}

// ── MARKDOWN ─────────────────────────────────────────────────────
function aipMd(text) {
  text=text.replace(/```[\w]*\n?([\s\S]*?)```/g,'<pre><code>$1</code></pre>');
  text=text.replace(/`([^`]+)`/g,'<code>$1</code>');
  text=text.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
  text=text.replace(/^### (.+)$/gm,'<strong style="font-size:13px;color:#1E3A5F;display:block;margin:6px 0 2px">$1</strong>');
  text=text.replace(/^## (.+)$/gm,'<strong style="font-size:14px;color:#1E3A5F;display:block;margin:8px 0 2px">$1</strong>');
  text=text.replace(/^# (.+)$/gm,'<strong style="font-size:15px;color:#1E3A5F;display:block;margin:8px 0 4px">$1</strong>');
  text=text.replace(/^[\*\-] (.+)$/gm,'<li>$1</li>');
  text=text.replace(/^(\d+)\. (.+)$/gm,'<li>$2</li>');
  text=text.replace(/(<li>[\s\S]*?<\/li>\n?)+/g,'<ul>$&</ul>');
  // Tablo
  var lines=text.split('\n'),result=[],inT=false,tRows=[];
  for(var i=0;i<lines.length;i++){
    var l=lines[i].trim();
    if(l.startsWith('|')&&l.endsWith('|')){
      if(!inT){inT=true;tRows=[];}
      if(!l.match(/^\|[-:\s|]+\|$/))tRows.push(l);
    }else{
      if(inT){result.push(aipTablo(tRows));inT=false;tRows=[];}
      result.push(lines[i]);
    }
  }
  if(inT)result.push(aipTablo(tRows));
  text=result.join('\n').replace(/\n/g,'<br>').replace(/(<br>){3,}/g,'<br><br>');
  return text;
}

function aipTablo(rows) {
  if(!rows.length)return '';
  var html='<table>';
  rows.forEach(function(row,i){
    var cells=row.split('|').filter(function(c){return c.trim()!=='';});
    var tag=i===0?'th':'td';
    html+='<tr>'+cells.map(function(c){return'<'+tag+'>'+c.trim()+'</'+tag+'>';}).join('')+'</tr>';
  });
  return html+'</table>';
}

// Textarea auto-height
document.getElementById('aip-input').addEventListener('input',function(){
  this.style.height='auto';
  this.style.height=Math.min(this.scrollHeight,120)+'px';
});

// Ctrl+K = temizle
document.addEventListener('keydown',function(e){
  if(e.ctrlKey&&e.key==='k'){e.preventDefault();aipTemizle();}
});

// Yükle
document.addEventListener('DOMContentLoaded', aipYukle);
</script>
