<?php
// Düzenleme/Silme POST işlemleri
if (!empty($_POST['gantt_action'])) {
    require_once dirname(dirname(__DIR__)) . '/core/config.php';
    require_once dirname(dirname(__DIR__)) . '/core/db.php';
    require_once dirname(dirname(__DIR__)) . '/core/auth.php';
    require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
    ob_end_clean();
    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['gantt_action'];
    $id = (int)($_POST['id']??0);

    if ($action === 'sil' && $id) {
        try {
            $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'duzenle' && $id) {
        $miktar = (int)($_POST['planlanan_miktar']??0);
        $kap    = max(1,(int)($_POST['kapasite_vardiya']??1));
        $not_   = trim($_POST['notlar']??'');
        $ue     = trim($_POST['uretim_emri_no']??'');
        $tv     = max(1,(int)ceil($miktar/$kap));
        try {
            $db->prepare("UPDATE mps_plan SET planlanan_miktar=?, kalan_miktar=?, kapasite_vardiya=?,
                toplam_vardiya=?, kalan_vardiya=?, uretim_emri_no=?, notlar=?, guncelleme=NOW()
                WHERE id=?")
               ->execute([$miktar,$miktar,$kap,$tv,$tv,$ue?:null,$not_,$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'detay' && $id) {
        try {
            $r = $db->prepare("SELECT * FROM mps_plan WHERE id=?");
            $r->execute([$id]);
            $row = $r->fetch(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'data'=>$row]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen eylem']); exit;
}

require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
$gantt_renkler=['#22C55E','#3B82F6','#F97316','#8B5CF6','#EC4899','#14B8A6','#EAB308','#DC2626'];

set_time_limit(0);
$bugun    = date('Y-m-d');
$saat     = (int)date('H');
$dakika   = (int)date('i');

$hat_renkleri = [
    'EN-110-01'=>'#FEE2E2',
    'EN-132-01'=>'#DBEAFE',
    'EN-80-01'=>'#D1FAE5',
    'EN-130-01'=>'#FEF3C7',
    'EN-160-01'=>'#EDE9FE',
    'EN-201-01'=>'#CFFAFE',
    'EN-202-01'=>'#FCE7F3',
    'EN-301-01'=>'#E0F2FE',
    'EN-302-01'=>'#ECFDF5',
    'EN-350-01'=>'#FEF9C3',
    'EN-420-01'=>'#FFEDD5',
    'EN-500-01'=>'#F1F5F9',
    'EN-650-01'=>'#F3E8FF',
    'EN-162-01'=>'#E0F7FA',
    'EN-131-01'=>'#FFF3CD',
    'EN-161-01'=>'#FEF08A',
    'EN-530-01'=>'#FED7AA',
    'EN-650-02'=>'#C7D2FE',
    'EN-450-01'=>'#CCFBF1',
    'EN-500-02'=>'#FFE4E6',
    'EN-260-01'=>'#BFDBFE',
    'EN-410-01'=>'#FDE68A',
    'EN-500-03'=>'#BBF7D0',
    'EN-700-01'=>'#FECACA',
    'EN-180-01'=>'#A7F3D0',
    'EN-280-01'=>'#BAE6FD',
    'EN-650-03'=>'#FDE68A',
    'EN-650-04'=>'#FBCFE8',
    'EN-650-05'=>'#FED7AA',
    'EN-650-06'=>'#DDD6FE',
    'EN-850-01'=>'#FECDD3',
    'EN-850-02'=>'#FEF08A',
];
$hat_sirasi = array_keys($hat_renkleri);

$resmi_tatiller = [
    '2025-01-01','2025-04-23','2025-05-01','2025-05-19',
    '2025-03-30','2025-03-31','2025-04-01',
    '2025-06-06','2025-06-07','2025-06-08',
    '2025-07-15','2025-08-30','2025-10-29',
    '2026-01-01','2026-04-23','2026-05-01','2026-05-19',
    '2026-03-20','2026-03-21','2026-03-22',
    '2026-05-27','2026-05-28','2026-05-29',
    '2026-07-15','2026-08-30','2026-10-29',
];

// Şu anki vardiya ve kalan dakika
// S=08-16, O=16-24, G=00-08
if ($saat >= 8 && $saat < 16)       { $aktif_vrd='S'; $kalan_dk=(16-$saat)*60-$dakika; }
elseif ($saat >= 16 && $saat < 24)  { $aktif_vrd='O'; $kalan_dk=(24-$saat)*60-$dakika; }
else                                  { $aktif_vrd='G'; $kalan_dk=(8-$saat)*60-$dakika; if($kalan_dk<0)$kalan_dk+=480; }

$vrd_sirasi  = ['S','O','G']; // bir günün vardiya sırası
$vrd_etiket  = ['S'=>'08-16','O'=>'16-24','G'=>'00-08'];

// 28 günlük takvim
$takvim = [];
$dt = new DateTime($bugun);
for($i=0;$i<28;$i++){
    $gs  = $dt->format('Y-m-d');
    $dow = (int)$dt->format('N');
    $tat = ($dow===7||in_array($gs,$resmi_tatiller));
    $takvim[] = [
        'tarih'   => $gs,
        'tatil'   => $tat,
        'tatil_lbl'=> $dow===7?'Pazar':(in_array($gs,$resmi_tatiller)?'Tatil':''),
        'dow_lbl' => ['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$dow-1],
        'bugun'   => ($gs===$bugun),
    ];
    $dt->modify('+1 day');
}

// Planlı işleri çek
$hat_planlar = [];
try {
    $rows = $db->query("SELECT *, COALESCE(personel_sayisi,1) AS personel_sayisi FROM mps_plan WHERE durum NOT IN('Tamamlandı','İptal') ORDER BY hat_kodu, hat_sira_no ASC")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r) $hat_planlar[$r['hat_kodu']][] = $r;
} catch(Throwable $e){}

// Gantt hesapla - her iş ayrı satır
// gantt[hat][is_idx][gun_idx] = ['vrd'=>[vk=>{...}], 'gun'=>{...}]
$gantt = []; // [hat][is_idx][gun_idx]

foreach($hat_planlar as $hk => $isler) {
    $gantt[$hk] = [];

    // Pointer: tüm işler sıralı çalışır, bir önceki iş bitince sonraki başlar
    $gun_ptr = 0;
    $vrd_ptr = array_search($aktif_vrd, $vrd_sirasi);
    while($gun_ptr < count($takvim) && $takvim[$gun_ptr]['tatil']) $gun_ptr++;

    foreach($isler as $is_idx => $is) {
        $gantt[$hk][$is_idx] = [];
        $kalan_vrd = max(1,(int)($is['kalan_vardiya']??$is['toplam_vardiya']??0));
        $km        = (int)($is['kalan_miktar']??$is['planlanan_miktar']??0);
        $cycle_sn  = floatval($is['cycle_sn']??0);
        $kap       = (int)($is['kapasite_vardiya']??0);
        if($kap<1 && $cycle_sn>0) $kap=(int)floor(25200/$cycle_sn);
        if($kap<1) $kap=1;

        $vrd_kalan     = $kalan_vrd;
        $local_gun_ptr = $gun_ptr;
        $local_vrd_ptr = $vrd_ptr;

        while($vrd_kalan > 0 && $local_gun_ptr < count($takvim)) {
            if($takvim[$local_gun_ptr]['tatil']) { $local_gun_ptr++; $local_vrd_ptr=0; continue; }

            $gi       = $local_gun_ptr;
            $vk       = $vrd_sirasi[$local_vrd_ptr];
            $is_bugun = $takvim[$gi]['bugun'];
            $is_aktif = ($is_bugun && $vk===$aktif_vrd);

            if($is_aktif) {
                $doluluk   = max(5,min(100,(int)round($kalan_dk/480*100)));
                $bu_miktar = (int)round($kap*$kalan_dk/480);
            } else {
                $doluluk   = 100;
                $bu_miktar = $kap;
            }
            $bu_miktar = max(0,min($km,$bu_miktar));

            if(!isset($gantt[$hk][$is_idx][$gi])) {
                $gantt[$hk][$is_idx][$gi] = ['vrd'=>[],'gun'=>null];
            }

            if($is_bugun) {
                $gantt[$hk][$is_idx][$gi]['vrd'][$vk] = [
                    'miktar'   => $bu_miktar,
                    'doluluk'  => $doluluk,
                    'cycle_sn' => $cycle_sn,
                    'aktif'    => $is_aktif,
                ];
            } else {
                if(!$gantt[$hk][$is_idx][$gi]['gun']) {
                    $gantt[$hk][$is_idx][$gi]['gun'] = ['miktar'=>0,'doluluk'=>100,'cycle_sn'=>$cycle_sn];
                }
                $gantt[$hk][$is_idx][$gi]['gun']['miktar'] += $bu_miktar;
            }

            $km -= $bu_miktar;
            $vrd_kalan--;
            $local_vrd_ptr++;
            if($local_vrd_ptr >= count($vrd_sirasi)) {
                $local_vrd_ptr = 0;
                $local_gun_ptr++;
                while($local_gun_ptr<count($takvim)&&$takvim[$local_gun_ptr]['tatil']) $local_gun_ptr++;
            }
        }
        // Sonraki iş bu pointerdan devam eder
        $gun_ptr = $local_gun_ptr;
        $vrd_ptr = $local_vrd_ptr;
    }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Enjeksiyon Gantt Planı</h1>
    <div class="s-yol">Planlama / <b>Gantt Görünümü</b>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">
        ● <?php echo date('d.m.Y H:i');?> &nbsp;|&nbsp;
        Aktif Vardiya: <b><?php echo $vrd_etiket[$aktif_vrd];?></b> &nbsp;|&nbsp;
        Kalan: <b><?php echo $kalan_dk;?> dk</b>
      </span>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:8px;padding:8px 0">
    <input type="text" id="ganttFiltre" placeholder="Hat veya stok kodu filtrele..." oninput="ganttFiltrele(this.value)"
      style="border:1px solid var(--kenar);border-radius:6px;padding:5px 10px;font-size:12px;width:220px;font-family:inherit">
    <button onclick="ganttExcel()" class="btn-dt" style="background:#1D6F42;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">📊 Excel</button>
    <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:6px 10px;border-radius:6px;font-size:12px;cursor:pointer" title="Yenile">🔄</button>
  </div>
</div>

<style>
.gt-wrap{overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 155px)}
.gt{border-collapse:collapse;font-size:11px;white-space:nowrap}
.gt th{background:#2d5986;color:#e0f0ff;padding:4px 6px;border:1px solid #3b6fa3;position:sticky;top:0;z-index:3;font-size:10px;text-align:center}
.gt th.s-th{position:sticky!important;z-index:6!important;text-align:left;top:0}
.gt td{padding:1px 2px;border:1px solid #E2E8F0;vertical-align:top}
.gt td.s-td{position:sticky;z-index:2;padding:3px 6px;border-right:1px solid #CBD5E1;font-size:11px;vertical-align:middle}
.gorev-kart{border-radius:3px;padding:2px 5px;margin:1px 0;font-size:10px;line-height:1.4;border-left:3px solid rgba(0,0,0,.15)}
.gk-adet{font-size:9px;color:#374151}
.doluluk-bar{height:3px;background:rgba(0,0,0,.08);border-radius:2px;margin-top:2px}
.doluluk-fill{height:3px;border-radius:2px}
.tat-td{background:#FFF1F2!important;text-align:center;color:#DC2626;font-size:9px;vertical-align:middle}
.bug-col{border-left:2px solid #3B82F6!important;border-right:2px solid #3B82F6!important}
</style>

<div class="s-body" style="padding:0">
<div class="gt-wrap">
<table class="gt">
<thead>
  <tr>
    <th class="s-th" style="left:0;min-width:100px;z-index:6">Hat</th>
    <th class="s-th" style="left:100px;min-width:70px;z-index:6">İşlem</th>
    <th class="s-th" style="left:160px;min-width:90px;z-index:6">ÜE No</th>
    <th class="s-th" style="left:250px;min-width:110px;z-index:6">Stok Kodu</th>
    <th class="s-th" style="left:360px;min-width:160px;z-index:6">Stok Adı</th>
    <th class="s-th" style="left:520px;min-width:80px;z-index:6;text-align:right">Kalan</th>
    <?php foreach($takvim as $gi => $gun):
      $is_bug = $gun['bugun'];
      $is_tat = $gun['tatil'];
    ?>
    <?php if($is_bug): foreach(['S'=>'08-16','O'=>'16-24','G'=>'00-08'] as $vk=>$vl):
      $is_aktif=($vk===$aktif_vrd);
    ?>
    <th style="min-width:70px;background:<?php echo $is_aktif?'#1D4ED8':'#BFDBFE';?>;color:<?php echo $is_aktif?'#fff':'#1E40AF';?>;border:1px solid #93C5FD">
      <?php echo $vl;?>
      <?php if($is_aktif): ?><br><span style="font-size:7px;background:#FCD34D;color:#1E40AF;border-radius:2px;padding:0 3px"><?php echo $kalan_dk;?>dk</span><?php endif;?>
    </th>
    <?php endforeach; elseif($is_tat): ?>
    <th style="background:#DC2626;color:#fff;min-width:70px;font-size:9px">
      <?php echo date('d.m',strtotime($gun['tarih']));?> <?php echo $gun['dow_lbl'];?><br>
      <span style="font-size:8px;opacity:.9"><?php echo $gun['tatil_lbl'];?></span>
    </th>
    <?php else: ?>
    <th style="min-width:70px;background:#2d5986;color:#e0f0ff">
      <?php echo date('d.m',strtotime($gun['tarih']));?><br>
      <span style="font-size:9px;opacity:.8"><?php echo $gun['dow_lbl'];?></span>
    </th>
    <?php endif; endforeach;?>
  </tr>
</thead>
<tbody id="ganttTbody">
<?php foreach($hat_sirasi as $hk):
  $hr    = $hat_renkleri[$hk] ?? '#F8FAFC';
  $isler = $hat_planlar[$hk] ?? [];
  $is_say = count($isler);
?>
<?php if(empty($isler)): ?>
<tr style="opacity:.3" data-hat="<?php echo $hk;?>" data-kod="">
  <td class="s-td" style="left:0;background:<?php echo $hr;?>;font-weight:700;min-width:100px;border-right:2px solid #94A3B8"><?php echo $hk;?></td>
  <td class="s-td" style="left:100px;background:<?php echo $hr;?>;min-width:60px;border-right:2px solid #94A3B8">—</td>
  <td class="s-td" style="left:160px;background:<?php echo $hr;?>;min-width:90px">—</td>
  <td class="s-td" style="left:250px;background:<?php echo $hr;?>;min-width:110px">—</td>
  <td class="s-td" style="left:360px;background:<?php echo $hr;?>;min-width:160px;white-space:normal">—</td>
  <td class="s-td" style="left:520px;background:<?php echo $hr;?>;min-width:80px">—</td>
  <?php foreach($takvim as $gun): ?>
  <td style="color:#F1F5F9;font-size:8px;text-align:center">·</td>
  <?php endforeach;?>
</tr>
<?php else: foreach($isler as $is_idx => $is):
  $km   = (int)($is['kalan_miktar']??$is['planlanan_miktar']??0);
  $ue   = $is['uretim_emri_no']??'—';
  $kod  = $is['urun_kodu'];
  $adi  = $is['urun_adi']??'';
  $topbrd = $is_idx===0 ? 'border-top:2px solid #94A3B8;' : '';
?>
<tr style="<?php echo $topbrd;?>" data-hat="<?php echo htmlspecialchars($hk);?>" data-kod="<?php echo htmlspecialchars($kod);?>">
  <?php if($is_idx===0): ?>
  <td class="s-td" style="left:0;background:<?php echo $hr;?>;font-weight:700;min-width:100px;border-right:2px solid #94A3B8;vertical-align:top" rowspan="<?php echo $is_say;?>">
    <?php echo htmlspecialchars($hk);?>
    <?php if($is_say>1): ?><div style="font-size:9px;color:#64748B;margin-top:2px"><?php echo $is_say;?> iş</div><?php endif;?>
  </td>
  <?php endif;?>
  <td class="s-td" style="left:100px;background:<?php echo $hr;?>;min-width:70px;text-align:center;border-right:2px solid #94A3B8;padding:3px">
    <div style="display:flex;gap:3px;justify-content:center">
      <button onclick="isDuzenle(<?php echo $is['id'];?>)" title="Düzenle"
        style="background:#EFF6FF;color:#1E40AF;border:none;padding:3px 7px;border-radius:4px;cursor:pointer;font-size:11px">✏</button>
      <button onclick="isSil(<?php echo $is['id'];?>,<?php echo htmlspecialchars(json_encode($kod));?>)" title="Sil"
        style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 7px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button>
    </div>
  </td>
  <td class="s-td" style="left:160px;background:<?php echo $hr;?>;min-width:90px;color:#0369A1;font-size:10px"><?php echo htmlspecialchars($ue);?></td>
  <td class="s-td" style="left:250px;background:<?php echo $hr;?>;min-width:110px">
    <code style="font-size:10px;font-weight:700;background:rgba(0,0,0,.05);padding:1px 4px;border-radius:3px"><?php echo htmlspecialchars($kod);?></code>
  </td>
  <td class="s-td" style="left:360px;background:<?php echo $hr;?>;min-width:160px;font-size:10px;white-space:normal;word-break:break-word"><?php echo htmlspecialchars($adi);?></td>
  <td class="s-td" style="left:520px;background:<?php echo $hr;?>;min-width:80px;text-align:right;font-weight:700;color:<?php echo $km>0?'#DC2626':'#059669';?>">
    <?php echo $km>0?number_format($km,0,',','.') :'✓';?>
  </td>
  <!-- Gün hücreleri bu iş için -->
  <?php foreach($takvim as $gi => $gun):
    if($gun['tatil']):
  ?>
  <td class="tat-td"><?php echo $gun['tatil_lbl'];?></td>
  <?php elseif($gun['bugun']):
    foreach(['S','O','G'] as $vk):
      $g = $gantt[$hk][$is_idx][$gi]['vrd'][$vk] ?? null;
      $is_av = ($vk===$aktif_vrd);
  ?>
  <td style="<?php echo $is_av?'background:#EFF6FF;':'';?>min-width:70px">
    <?php if($g): ?>
    <div class="gorev-kart" style="background:<?php echo $hr;?>;<?php echo $g['aktif']?'border-left-color:#3B82F6':'';?>">
      <div class="gk-adet"><?php echo number_format($g['miktar'],0,',','.');?> ad<?php if($g['cycle_sn']>0): ?> | <?php echo round($g['cycle_sn'],1);?>sn<?php endif;?><?php if(($g['personel']??1)>0): ?> | <?php echo $g['personel']??1;?>👤<?php endif;?></div>
      <div class="doluluk-bar"><?php $gc=$gantt_renkler[$is_idx%count($gantt_renkler)];?><div class="doluluk-fill" style="width:<?php echo $g['doluluk'];?>%;background:<?php echo $gc;?>"></div></div>
    </div>
    <?php else: ?><div style="color:#E2E8F0;font-size:8px;text-align:center;padding:3px">·</div><?php endif;?>
  </td>
  <?php endforeach; else:
    $g = $gantt[$hk][$is_idx][$gi]['gun'] ?? null;
  ?>
  <td style="min-width:70px">
    <?php if($g): ?>
    <div class="gorev-kart" style="background:<?php echo $hr;?>">
      <div class="gk-adet"><?php echo number_format($g['miktar'],0,',','.');?> ad</div>
      <div class="doluluk-bar"><div class="doluluk-fill" style="width:100%;background:<?php echo $gantt_renkler[$is_idx%count($gantt_renkler)];?>"></div></div>
    </div>
    <?php else: ?><div style="color:#E2E8F0;font-size:8px;text-align:center;padding:3px">·</div><?php endif;?>
  </td>
  <?php endif; endforeach;?>
</tr>
<?php endforeach; endif; endforeach;?>
</tbody>
<tfoot>
  <tr style="background:#F8FAFC;border-top:2px solid #CBD5E1">
    <td class="s-td" style="left:0;background:#F1F5F9;font-weight:700;font-size:10px;text-align:center;padding:4px">Toplam<br>Personel</td>
    <td class="s-td" style="left:100px;background:#F1F5F9"></td>
    <td class="s-td" style="left:160px;background:#F1F5F9"></td>
    <td class="s-td" style="left:250px;background:#F1F5F9"></td>
    <td class="s-td" style="left:360px;background:#F1F5F9"></td>
    <td class="s-td" style="left:520px;background:#F1F5F9"></td>
    <?php
    // Her kolon için toplam personel hesapla
    foreach($takvim as $gi => $gun):
      if($gun['tatil']):
    ?>
    <td style="background:#FEE2E2;border:1px solid #E2E8F0"></td>
    <?php elseif($gun['bugun']): foreach(['S','O','G'] as $vk):
      // Bu vardiyadaki tüm hatlardaki toplam personel
      $toplam_pers = 0;
      foreach($hat_planlar as $hk2 => $isler2) {
          foreach($isler2 as $is_idx2 => $is2) {
              if (isset($gantt[$hk2][$is_idx2][$gi]['vrd'][$vk])) {
                  $toplam_pers += (int)($gantt[$hk2][$is_idx2][$gi]['vrd'][$vk]['personel']??1);
              }
          }
      }
    ?>
    <td style="background:#EFF6FF;text-align:center;font-weight:700;font-size:11px;color:#1E40AF;border:1px solid #BFDBFE;padding:3px">
      <?php echo $toplam_pers>0?$toplam_pers.'👤':'·';?>
    </td>
    <?php endforeach; else:
      // Günlük toplam personel
      $toplam_pers = 0;
      foreach($hat_planlar as $hk2 => $isler2) {
          foreach($isler2 as $is_idx2 => $is2) {
              if (isset($gantt[$hk2][$is_idx2][$gi]['gun'])) {
                  $toplam_pers += (int)($gantt[$hk2][$is_idx2][$gi]['gun']['personel']??1);
              }
          }
      }
    ?>
    <td style="background:#F8FAFC;text-align:center;font-weight:700;font-size:11px;color:#374151;border:1px solid #E2E8F0;padding:3px">
      <?php echo $toplam_pers>0?($toplam_pers*3).'👤':'·';?>
    </td>
    <?php endif; endforeach;?>
  </tr>
</tfoot>
</tbody>
</table>
</div>
</div>

<!-- Düzenleme Modal -->
<div id="duzModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:12px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid #E2E8F0;background:#f8fafc;border-radius:12px 12px 0 0">
    <div style="font-size:13px;font-weight:800;color:#0F172A" id="duzBaslik">İş Düzenle</div>
    <button onclick="duzKapat()" style="background:#F1F5F9;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer">✕</button>
  </div>
  <div style="padding:18px">
    <input type="hidden" id="duzId">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Miktar (adet)</label>
        <input type="number" id="duzMiktar" class="form-alan" min="1" oninput="duzHesapla()">
      </div>
      <div>
        <label class="form-etiket">Kapasite/Vardiya</label>
        <input type="number" id="duzKap" class="form-alan" min="1" readonly style="background:#F8FAFC">
      </div>
    </div>
    <div id="duzHesap" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:6px;padding:8px 12px;margin-bottom:12px;font-size:11px;display:none">
      <span id="duzHesapTxt"></span>
    </div>
    <div style="margin-bottom:12px">
      <label class="form-etiket">ÜE No</label>
      <input type="text" id="duzUe" class="form-alan" placeholder="Üretim Emri No...">
    </div>
    <div style="margin-bottom:16px">
      <label class="form-etiket">Notlar</label>
      <input type="text" id="duzNot" class="form-alan" placeholder="Açıklama...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="duzKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:8px 16px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="duzKaydet()" id="duzBtn" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:8px 18px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✅ Kaydet</button>
    </div>
  </div>
</div>
</div>

<script>
var BASE='<?php echo BASE_URL;?>';
var GANTT_URL=BASE+'/panel.php?sayfa=planlama-gantt';

function ganttPost(fields,cb){
  var fd=new FormData();
  Object.keys(fields).forEach(function(k){fd.append(k,fields[k]||'');});
  fetch(GANTT_URL,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb)
  .catch(function(e){alert('Hata: '+e);});
}

function isSil(id,kod){
  if(!confirm(kod+' isini silmek istediginize emin misiniz?'))return;
  ganttPost({gantt_action:'sil',id:id},function(d){
    if(d.ok)location.reload();
    else alert('Silinemedi: '+(d.hata||''));
  });
}

function isDuzenle(id){
  ganttPost({gantt_action:'detay',id:id},function(d){
    if(!d.ok){alert('Veri alinamadi');return;}
    var r=d.data;
    document.getElementById('duzId').value=id;
    document.getElementById('duzBaslik').textContent='Duzenle - '+r.urun_kodu;
    document.getElementById('duzMiktar').value=r.kalan_miktar||r.planlanan_miktar;
    document.getElementById('duzKap').value=r.kapasite_vardiya||1;
    document.getElementById('duzUe').value=r.uretim_emri_no||'';
    document.getElementById('duzNot').value=r.notlar||'';
    duzHesapla();
    document.getElementById('duzModal').style.display='flex';
  });
}

function duzHesapla(){
  var mik=parseInt(document.getElementById('duzMiktar').value)||0;
  var kap=parseInt(document.getElementById('duzKap').value)||1;
  if(mik<1){document.getElementById('duzHesap').style.display='none';return;}
  var tv=Math.max(1,Math.ceil(mik/kap));
  document.getElementById('duzHesap').style.display='block';
  document.getElementById('duzHesapTxt').innerHTML=
    '<b>'+mik.toLocaleString('tr-TR')+'</b> adet - <b>'+tv+'</b> vardiya (~<b>'+Math.ceil(tv/3)+'</b> gun)';
}

function duzKapat(){document.getElementById('duzModal').style.display='none';}

function duzKaydet(){
  var id=document.getElementById('duzId').value;
  var mik=parseInt(document.getElementById('duzMiktar').value)||0;
  var kap=parseInt(document.getElementById('duzKap').value)||1;
  if(!id||mik<1){alert('Miktar giriniz.');return;}
  var btn=document.getElementById('duzBtn');
  btn.disabled=true;btn.textContent='Kaydediliyor...';
  ganttPost({
    gantt_action:'duzenle',id:id,
    planlanan_miktar:mik,kapasite_vardiya:kap,
    uretim_emri_no:document.getElementById('duzUe').value,
    notlar:document.getElementById('duzNot').value
  },function(d){
    btn.disabled=false;btn.textContent='Kaydet';
    if(d.ok){duzKapat();location.reload();}
    else alert('Kaydedilemedi: '+(d.hata||''));
  });
}

function ganttFiltrele(q){
  q=(q||'').toLowerCase().trim();
  document.querySelectorAll('#ganttTbody tr').forEach(function(tr){
    if(!q){tr.style.display='';return;}
    var hat=(tr.dataset.hat||'').toLowerCase();
    var kod=(tr.dataset.kod||'').toLowerCase();
    tr.style.display=(hat.indexOf(q)>=0||kod.indexOf(q)>=0)?'':'none';
  });
}

function ganttExcel(){
  var rows=[];
  var header=['Hat','Islem','UE No','Stok Kodu','Stok Adi','Kalan'];
  document.querySelectorAll('.gt thead tr th').forEach(function(th,i){
    if(i>=6) header.push(th.textContent.trim().split('\n').join(' '));
  });
  rows.push(header);
  document.querySelectorAll('#ganttTbody tr').forEach(function(tr){
    if(tr.style.display==='none') return;
    var cells=[];
    tr.querySelectorAll('td').forEach(function(td){
      cells.push('"'+td.textContent.trim().split('\n').join(' ').split('"').join('""')+'"');
    });
    if(cells.length>0) rows.push(cells);
  });
  var csv=rows.map(function(r){return r.join(';');}).join('\r\n');
  var blob=new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='Gantt_Plan_'+new Date().toISOString().slice(0,10)+'.csv';
  a.click();
}

document.addEventListener('DOMContentLoaded',function(){
  var rows=document.querySelectorAll('.gt thead tr');
  if(rows.length>=2){
    var h1=rows[0].getBoundingClientRect().height;
    rows[1].querySelectorAll('th').forEach(function(th){
      th.style.top=Math.round(h1)+'px';
    });
  }
});

document.addEventListener('keydown',function(e){if(e.key==='Escape')duzKapat();});
</script>
