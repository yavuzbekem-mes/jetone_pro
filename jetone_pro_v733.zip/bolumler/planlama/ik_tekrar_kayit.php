<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok  = ($tigerdb_pdo !== null);
$mes_ok    = ($mes_pdo !== null);
$formGeldi = !empty($_POST) && isset($_POST['yil']);
$yil       = (int)($_POST['yil'] ?? date('Y'));

// ── SORGU ────────────────────────────────────────────────────────
$rows = []; $hata = '';

if ($tiger_ok && $formGeldi) {
    try {
        $sql = "SELECT a.*
            FROM MES.dbo.IKINCI_KALITE a
            INNER JOIN MES.dbo.IKINCI_KALITE b ON b.ID = a.ID + 1
            WHERE YEAR(a.URETIM_TARIHI) = ?
              AND a.URETIM_EMRI_NO   = b.URETIM_EMRI_NO
              AND a.STOK_KODU        = b.STOK_KODU
              AND a.TOPLAM           = b.TOPLAM
              AND CONVERT(date,a.URETIM_TARIHI) = CONVERT(date,b.URETIM_TARIHI)
            UNION
            SELECT b.*
            FROM MES.dbo.IKINCI_KALITE a
            INNER JOIN MES.dbo.IKINCI_KALITE b ON b.ID = a.ID + 1
            WHERE YEAR(a.URETIM_TARIHI) = ?
              AND a.URETIM_EMRI_NO   = b.URETIM_EMRI_NO
              AND a.STOK_KODU        = b.STOK_KODU
              AND a.TOPLAM           = b.TOPLAM
              AND CONVERT(date,a.URETIM_TARIHI) = CONVERT(date,b.URETIM_TARIHI)
            ORDER BY ID";
        $st = $tigerdb_pdo->prepare($sql);
        $st->execute([$yil, $yil]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblTekrar th { background:#991B1B !important; color:#fff !important; }
#tblTekrar td, #tblTekrar th { border:1px solid #CBD5E1 !important; white-space:nowrap !important; }
#tblTekrar tbody tr:nth-child(odd)  { background:#FFF5F5 }
#tblTekrar tbody tr:nth-child(even) { background:#FEE2E2 }
.sil-btn {
    background:#DC2626; color:#fff; border:none;
    padding:3px 10px; border-radius:5px;
    font-size:11px; font-weight:700; cursor:pointer;
    transition:opacity .15s;
}
.sil-btn:hover { opacity:.8 }
.sil-btn:disabled { background:#94A3B8; cursor:not-allowed; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">🔴 Tekrar İkinci Kalite Kayıtları</h1>
    <div class="s-yol">Planlama / <b>Arka Arkaya Aynı IK Kayıtları</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger/MES DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<div style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#92400E;font-weight:600">
  ⚠️ Bu sayfa aynı üretim emri + stok kodu + miktar + tarih kombinasyonuna sahip arka arkaya kayıtları gösterir.
  Satırdaki <b>Sil</b> butonu kaydı <b>MES veritabanından kalıcı olarak siler</b>.
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px;font-size:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Filtre -->
<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <div>
      <label class="form-etiket">Yıl</label>
      <input type="number" name="yil" class="form-alan" value="<?php echo $yil;?>" min="2020" max="2030" style="width:100px">
    </div>
    <button type="submit" style="background:#991B1B;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      🔍 Tekrar Kayıtları Bul
    </button>
  </form>
</div>

<?php if(!$formGeldi):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">🔴</div>
  <div style="font-weight:600">Yıl seçip "Tekrar Kayıtları Bul" butonuna basın.</div>
</div>

<?php elseif(empty($rows) && !$hata):?>
<div style="background:#D1FAE5;border:1px solid #86EFAC;padding:20px;text-align:center;color:#065F46;border-radius:10px;font-weight:700">
  ✅ <?php echo $yil;?> yılında arka arkaya tekrar eden kayıt bulunamadı.
</div>

<?php else:?>

<div id="silMesaj" style="display:none;margin-bottom:10px"></div>

<div style="margin-bottom:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
  <span id="kayitSayac" style="background:#FEE2E2;border:1px solid #FECACA;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:700;color:#991B1B">
    🔴 <?php echo count($rows);?> tekrar kayıt tespit edildi
  </span>
  <?php if(!$mes_ok):?>
  <span style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:600;color:#92400E">
    ⚠️ MES DB bağlı değil — silme işlemi devre dışı
  </span>
  <?php endif;?>
</div>

<div class="kart" style="overflow:hidden;padding:0"><div style="overflow-x:auto">
<table id="tblTekrar" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <?php if($mes_ok):?><th style="width:70px;text-align:center">İşlem</th><?php endif;?>
      <?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <?php if($mes_ok):?><th>İşlem</th><?php endif;?>
      <?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($rows as $r):
    $id = (int)($r['ID'] ?? 0);
  ?>
  <tr id="satir-<?php echo $id;?>">
    <?php if($mes_ok):?>
    <td style="text-align:center;background:#FFF !important">
      <button class="sil-btn" onclick="silKayit(<?php echo $id;?>, this)"
        title="ID=<?php echo $id;?> kaydını sil">
        🗑 Sil
      </button>
    </td>
    <?php endif;?>
    <?php foreach($r as $k=>$v):?>
    <td style="<?php echo $k==='ID'?'font-weight:700;color:#DC2626':''?>"><?php echo htmlspecialchars((string)($v??''));?></td>
    <?php endforeach;?>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div></div>

<script>
var AJAX_URL = '<?php echo BASE_URL;?>/bolumler/planlama/ajax/ik_sil.php';
var _silSayisi = 0;

function silKayit(id, btn) {
    if (!confirm('⚠️ ID=' + id + ' kaydı MES veritabanından kalıcı olarak silinecek.\n\nDevam etmek istiyor musunuz?')) return;

    btn.disabled = true;
    btn.textContent = '⏳';

    fetch(AJAX_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: 'delete_id=' + encodeURIComponent(id)
    })
    .then(function(r){ return r.json(); })
    .then(function(d) {
        if (d.ok) {
            // Satırı tablodan kaldır
            var satir = document.getElementById('satir-' + id);
            if (satir) {
                satir.style.transition = 'opacity .3s';
                satir.style.opacity = '0';
                setTimeout(function(){ satir.remove(); }, 300);
            }
            _silSayisi++;
            // Sayacı güncelle
            var sayac = document.getElementById('kayitSayaci');
            if (sayac) sayac.textContent = parseInt(sayac.textContent||'0') + 1;
            mesajGoster('✅ ' + d.msg, 'ok');
        } else {
            btn.disabled = false;
            btn.textContent = '🗑 Sil';
            mesajGoster('❌ ' + d.msg, 'err');
        }
    })
    .catch(function(e) {
        btn.disabled = false;
        btn.textContent = '🗑 Sil';
        mesajGoster('❌ Bağlantı hatası: ' + e, 'err');
    });
}

function mesajGoster(msg, tip) {
    var el = document.getElementById('silMesaj');
    el.style.display = 'block';
    el.innerHTML = '<div style="background:' + (tip==='ok'?'#D1FAE5':'#FEE2E2') + ';color:' + (tip==='ok'?'#065F46':'#991B1B') + ';padding:9px 14px;border-radius:8px;font-weight:700;font-size:12px">' + msg + '</div>';
    clearTimeout(el._t);
    el._t = setTimeout(function(){ el.style.display='none'; }, 4000);
}

$(document).ready(function(){
    var colOffset = <?php echo $mes_ok ? 1 : 0;?>;
    $('#tblTekrar').DataTable({
        initComplete: function(){
            this.api().columns().every(function(){
                var idx = this.index();
                if(idx < colOffset) return; // İşlem sütununu atla
                var col=this, th=$(col.footer());
                if(!th||!th.length) return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){
                        var v=$.fn.dataTable.util.escapeRegex($(this).val());
                        col.search(v?'^'+v+'$':'',true,false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var v=$('<div/>').html(d).text();
                    if(v.length>30) v=v.substr(0,30)+'...';
                    sel.append('<option value="'+v+'">'+v+'</option>');
                });
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'550px', paging:false, scrollX:true,
        <?php if($mes_ok):?>columnDefs:[{orderable:false,targets:0}],<?php endif;?>
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',
             filename:'Tekrar_IK_<?php echo date("Ymd");?>',
             exportOptions:{columns:':not(:first-child)'}
            },
            'print'
        ]
    });
});
</script>
<?php endif; endif;?>
