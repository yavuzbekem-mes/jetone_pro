<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$formGeldi = !empty($_POST);

function norm_tarih($t){
    if(preg_match('/^(\d{2})\.(\d{2})\.(\d{4})$/',$t,$m)) return "{$m[3]}-{$m[2]}-{$m[1]}";
    return $t;
}

$startDate = norm_tarih(trim($_POST['start_date'] ?? date('Y-m-d', strtotime('-1 day'))));
$endDate   = norm_tarih(trim($_POST['end_date']   ?? date('Y-m-d')));
$mamulKodu = trim($_POST['mamul_kodu'] ?? '');

$rows = []; $hata = '';

if ($tiger_ok && $formGeldi) {
    $sql = "SELECT
        PRO.FICHENO                         AS [Üretim Emri No],
        CONVERT(VARCHAR,ST.DATE_,104)       AS [Tarih],
        ST.YEAR_                            AS [Yıl],
        ST.MONTH_                           AS [Ay],
        WS.CODE                             AS [Makine Kodu],
        IT.SPECODE                          AS [Müşteri],
        IT.CODE                             AS [Mamul Kodu],
        IT.NAME                             AS [Mamul Adı],
        SUM(ST.AMOUNT)                      AS [Toplam Miktar],
        ISNULL(MAX(IK_AGR.IK_Toplam),0)    AS [İkinci Kalite],
        SUM(ST.AMOUNT)-ISNULL(MAX(IK_AGR.IK_Toplam),0) AS [Hatasız Miktar]
    FROM dbo.LG_222_02_STLINE ST WITH(NOLOCK)
    LEFT JOIN dbo.LG_222_ITEMS      IT   WITH(NOLOCK) ON ST.STOCKREF     = IT.LOGICALREF
    LEFT JOIN dbo.LG_222_02_STFICHE STF  WITH(NOLOCK) ON ST.STFICHEREF   = STF.LOGICALREF
    LEFT JOIN dbo.LG_222_PRODORD    PRO  WITH(NOLOCK) ON ST.PRODORDERREF = PRO.LOGICALREF
    LEFT JOIN dbo.LG_222_DISPLINE   DISP WITH(NOLOCK) ON PRO.LOGICALREF  = DISP.PRODORDREF
    LEFT JOIN dbo.LG_222_WORKSTAT   WS   WITH(NOLOCK) ON DISP.WSREF      = WS.LOGICALREF
    LEFT JOIN (
        SELECT URETIM_EMRI_NO, CONVERT(date,URETIM_TARIHI) Tarih,
               SUM(CONVERT(decimal,TOPLAM)) IK_Toplam
        FROM MES.dbo.IKINCI_KALITE
        WHERE YEAR(URETIM_TARIHI) >= 2024
        GROUP BY URETIM_EMRI_NO, CONVERT(date,URETIM_TARIHI)
    ) IK_AGR ON PRO.FICHENO=IK_AGR.URETIM_EMRI_NO AND CONVERT(date,ST.DATE_)=IK_AGR.Tarih
    WHERE ST.TRCODE=13 AND ST.LPRODSTAT=0
      AND ST.DATE_ BETWEEN ? AND ?
      AND STF.TRCODE=13";
    $params = [$startDate, $endDate];
    if ($mamulKodu !== '') { $sql .= " AND IT.CODE=?"; $params[]=$mamulKodu; }
    $sql .= " GROUP BY PRO.FICHENO,CONVERT(VARCHAR,ST.DATE_,104),ST.YEAR_,ST.MONTH_,
              WS.CODE,IT.SPECODE,IT.CODE,IT.NAME
              HAVING PRO.FICHENO IS NOT NULL
              ORDER BY PRO.FICHENO,[Tarih]";
    try {
        $st=$tigerdb_pdo->prepare($sql); $st->execute($params);
        $rows=$st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){ $hata=$e->getMessage(); }
}
?>
<style>
#tblVerim th{background:#1E3A5F !important;color:#fff !important;}
#tblVerim td,#tblVerim th{border:1px solid #CBD5E1 !important;white-space:nowrap !important;}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">📈 Üretim Personel Verimlilik</h1>
    <div class="s-yol">Planlama / <b>Üretim Verimlilik Raporu</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px;font-size:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div><label class="form-etiket">Başlangıç</label>
      <input type="date" name="start_date" class="form-alan" value="<?php echo $startDate;?>"></div>
    <div><label class="form-etiket">Bitiş</label>
      <input type="date" name="end_date" class="form-alan" value="<?php echo $endDate;?>"></div>
    <div><label class="form-etiket">Mamul Kodu <span style="font-weight:400;color:#94A3B8">(boş=tümü)</span></label>
      <input type="text" name="mamul_kodu" class="form-alan" value="<?php echo htmlspecialchars($mamulKodu);?>" placeholder="Ör: 2988080600"></div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Veri Çek</button>
    <?php if($formGeldi):?><a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-uretim-verimlilik"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a><?php endif;?>
  </form>
</div>

<?php if(!$formGeldi):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">📈</div>
  <div style="font-weight:600">Tarih aralığı seçip "Veri Çek" butonuna basın.</div>
</div>
<?php elseif(empty($rows)&&!$hata):?>
<div style="background:#F1F5F9;padding:30px;text-align:center;color:#94A3B8;border-radius:10px">Seçilen aralıkta kayıt bulunamadı.</div>
<?php else:?>
<div style="margin-bottom:8px">
  <span style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:700;color:#1D4ED8"><?php echo count($rows);?> kayıt</span>
</div>
<div class="kart" style="overflow:hidden;padding:0"><div style="overflow-x:auto">
<table id="tblVerim" style="width:100%;border-collapse:collapse">
  <thead><tr><?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></thead>
  <tfoot><tr><?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></tfoot>
  <tbody>
  <?php foreach($rows as $r): ?>
  <tr><?php foreach($r as $v) echo '<td>'.htmlspecialchars((string)($v??'')).'</td>';?></tr>
  <?php endforeach;?>
  </tbody>
</table>
</div></div>
<script>
$(document).ready(function(){
    $('#tblVerim').DataTable({
        initComplete:function(){
            this.api().columns([0,1,3,4,5,6]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'550px',paging:false,scrollX:true,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Verimlilik_<?php echo date("Ymd");?>'},'print']
    });
});
</script>
<?php endif; endif;?>
