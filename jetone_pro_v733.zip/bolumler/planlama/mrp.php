<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$satirlar = []; $gun_kolonlari = []; $satin_alma_map = [];
$mlz_kullanim_detay = []; $mlz2_kullanim_detay = []; $gantt_map = [];

// Müşteri listesi
$musteri_listesi = [];
try {
    $musteri_listesi = $db->query("SELECT DISTINCT musteri_firma_adi FROM siparis WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL AND musteri_firma_adi!='' ORDER BY musteri_firma_adi ASC")->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e) {}

$secili_musteriler = [];
if (!empty($_POST['musteriler'])) { $secili_musteriler = array_filter((array)$_POST['musteriler']); }
$form_gonderildi = isset($_POST['mrp_calistir']);

if ($form_gonderildi && $tigerdb_pdo) {
try {
    // 1. Siparişler
    $musteri_where = '';
    $sip_params = ['Aktif'];
    if (!empty($secili_musteriler)) {
        $placeholders = implode(',', array_fill(0, count($secili_musteriler), '?'));
        $musteri_where = "AND musteri_firma_adi IN ($placeholders)";
        $sip_params = array_merge($sip_params, $secili_musteriler);
    }
    $sip_stmt = $db->prepare("SELECT sip_kodu, DATE(sip_teslim_tarihi) AS teslim_tarihi, SUM(sip_miktar - sip_sevk_miktari) AS kalan_miktar
        FROM siparis WHERE sip_statu=? AND (sip_miktar-sip_sevk_miktari)>0 AND sip_teslim_tarihi IS NOT NULL
        AND sip_teslim_tarihi <= DATE_ADD(CURDATE(),INTERVAL 2 MONTH) $musteri_where
        GROUP BY sip_kodu, DATE(sip_teslim_tarihi) ORDER BY teslim_tarihi ASC");
    $sip_stmt->execute($sip_params);
    $siparis_map = [];
    foreach ($sip_stmt->fetchAll(PDO::FETCH_ASSOC) as $sip) {
        $kod = trim($sip['sip_kodu']); if (!$kod || !$sip['teslim_tarihi']) continue;
        $siparis_map[$kod][$sip['teslim_tarihi']] = ($siparis_map[$kod][$sip['teslim_tarihi']] ?? 0) + floatval($sip['kalan_miktar']);
    }

    // 2. BOM
    $bom_rows = $tigerdb_pdo->query("SELECT URUN.CODE AS Urun_Kodu, MLZ.CODE AS Malzeme_Kodu, MLZ.NAME AS Malzeme_Adi, MLZ.STGRPCODE AS Malzeme_Grubu, BL.AMOUNT AS Miktar
        FROM dbo.LG_222_BOMLINE BL WITH(NOLOCK)
        LEFT OUTER JOIN dbo.LG_222_BOMREVSN BR ON BL.BOMREVREF=BR.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_BOMASTER BM ON BR.BOMMASTERREF=BM.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_ITEMS URUN ON BM.MAINPRODREF=URUN.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_ITEMS MLZ ON BL.ITEMREF=MLZ.LOGICALREF
        WHERE BL.LINETYPE=0 AND BM.ACTIVE=0 AND URUN.ACTIVE=0 AND MLZ.ACTIVE=0")->fetchAll(PDO::FETCH_ASSOC);
    $bom_map = [];
    foreach ($bom_rows as $bom) {
        if (!$bom['Urun_Kodu'] || !$bom['Malzeme_Kodu']) continue;
        $bom_map[$bom['Urun_Kodu']][] = ['kod'=>$bom['Malzeme_Kodu'],'adi'=>$bom['Malzeme_Adi'],'grup'=>$bom['Malzeme_Grubu'],'birim'=>floatval($bom['Miktar'])];
    }

    // 3. Stoklar
    $stok_rows = $tigerdb_pdo->query("SELECT IT.CODE AS Kod, IT.NAME AS Adi, IT.STGRPCODE AS Grup,
        ISNULL(SUM(CASE WHEN LV.INVENNO IN (0,1,5) THEN LV.ONHAND ELSE 0 END),0) AS Stok
        FROM dbo.LG_222_ITEMS AS IT
        LEFT OUTER JOIN dbo.LV_222_02_STINVTOT AS LV ON LV.STOCKREF=IT.LOGICALREF
        LEFT OUTER JOIN dbo.L_CAPIWHOUSE AS CAP ON CAP.NR=LV.INVENNO
        WHERE IT.CARDTYPE NOT IN (4,22) AND IT.CANCONFIGURE=0 AND CAP.FIRMNR=222 AND LV.INVENNO IN (0,1,5,2,3,4,98)
        AND IT.STGRPCODE IN ('Ambalaj','Plastik HM','Mamül','Yarımamül','Masterbatch','Yardımcı Malz.')
        GROUP BY IT.CODE,IT.NAME,IT.LOGICALREF,IT.STGRPCODE")->fetchAll(PDO::FETCH_ASSOC);
    $stok_map = [];
    foreach ($stok_rows as $s) { $stok_map[$s['Kod']] = ['adi'=>$s['Adi'],'grup'=>$s['Grup'],'stok'=>floatval($s['Stok'])]; }

    // 4. Tarih kolonları
    $bugun_dt = new DateTime(); $bugun_dt->setTime(0,0,0);
    $bugun_str_hesap = $bugun_dt->format('Y-m-d');
    $bitis = (new DateTime())->modify('+2 months'); $bitis->setTime(0,0,0);
    $gun_kolonlari = []; $dt_iter = clone $bugun_dt;
    while ($dt_iter <= $bitis) { $gun_kolonlari[] = $dt_iter->format('Y-m-d'); $dt_iter->modify('+1 day'); }

    // 5. Hesaplama fonksiyonu
    function hesaplaGunluk(float $stok, array $ihtiyac, array $kolonlar, string $bugun): array {
        $tumT = array_keys($ihtiyac); sort($tumT);
        $bakiye = $stok;
        foreach ($tumT as $t) { if ($t < $bugun) { $bakiye -= ($ihtiyac[$t] ?? 0); } }
        $bas_bak = $bakiye; $ilk_eksik = null;
        if ($bakiye < 0) $ilk_eksik = $bugun;
        $gunluk = [];
        foreach ($kolonlar as $tarih) {
            $sip = $ihtiyac[$tarih] ?? 0; $onceki = $bakiye; $bakiye -= $sip;
            if ($bakiye < 0 && $onceki > 0) $net = abs($bakiye);
            elseif ($bakiye < 0 && $onceki <= 0) $net = $sip;
            else $net = 0;
            $gunluk[$tarih] = ['ihtiyac'=>$sip,'net_ihtiyac'=>$net,'bakiye'=>$bakiye];
            if ($bakiye < 0 && $ilk_eksik === null) $ilk_eksik = $tarih;
        }
        return ['ilk_eksik'=>$ilk_eksik,'gunluk'=>$gunluk,'son_bakiye'=>$bakiye,'baslangic_bakiye'=>$bas_bak];
    }

    // 6. Sipariş satırları
    $siparis_satirlari = [];
    foreach ($siparis_map as $urun_kodu => $tarih_miktarlar) {
        $stok = $stok_map[$urun_kodu]['stok'] ?? 0;
        $hesap = hesaplaGunluk($stok, $tarih_miktarlar, $gun_kolonlari, $bugun_str_hesap);
        $siparis_satirlari[$urun_kodu] = ['tip'=>'siparis','kod'=>$urun_kodu,
            'adi'=>$stok_map[$urun_kodu]['adi']??$urun_kodu,'grup'=>$stok_map[$urun_kodu]['grup']??'',
            'stok'=>$stok,'toplam'=>array_sum($tarih_miktarlar),'son_bakiye'=>$hesap['son_bakiye'],
            'baslangic_bakiye'=>$hesap['baslangic_bakiye'],'ilk_eksik'=>$hesap['ilk_eksik'],'gunluk'=>$hesap['gunluk']];
    }

    // Malzeme ihtiyaç
    $malzeme_ihtiyac_map = [];
    foreach ($siparis_satirlari as $urun_kodu => $sip) {
        if (!isset($bom_map[$urun_kodu])) continue;
        foreach ($bom_map[$urun_kodu] as $mlz) {
            foreach ($gun_kolonlari as $t) {
                $net = $sip['gunluk'][$t]['net_ihtiyac'] ?? 0;
                if ($net <= 0) continue;
                $malzeme_ihtiyac_map[$mlz['kod']][$t] = ($malzeme_ihtiyac_map[$mlz['kod']][$t] ?? 0) + $net * $mlz['birim'];
                if (!isset($malzeme_ihtiyac_map[$mlz['kod']]['__info'])) $malzeme_ihtiyac_map[$mlz['kod']]['__info'] = ['adi'=>$mlz['adi'],'grup'=>$mlz['grup']];
            }
        }
    }
    // Kullanım detay
    $mlz_kullanim_detay = [];
    foreach ($siparis_satirlari as $urun_kodu => $sip) {
        if (!isset($bom_map[$urun_kodu])) continue;
        foreach ($bom_map[$urun_kodu] as $mlz) {
            foreach ($gun_kolonlari as $t) {
                $net = $sip['gunluk'][$t]['net_ihtiyac'] ?? 0;
                if ($net <= 0) continue;
                $mlz_kullanim_detay[$mlz['kod']][$t][] = ['urun_kodu'=>$urun_kodu,'urun_adi'=>$sip['adi'],'miktar'=>round($net*$mlz['birim'],2)];
            }
        }
    }

    // Malzeme satırları
    $malzeme_satirlari = [];
    foreach ($malzeme_ihtiyac_map as $mlz_kodu => $veriler) {
        $info = $veriler['__info'] ?? ['adi'=>$mlz_kodu,'grup'=>''];
        $gi = array_filter($veriler, function($k){return $k!=='__info';}, ARRAY_FILTER_USE_KEY);
        $stok = $stok_map[$mlz_kodu]['stok'] ?? 0;
        $hesap = hesaplaGunluk($stok, $gi, $gun_kolonlari, $bugun_str_hesap);
        $malzeme_satirlari[$mlz_kodu] = ['tip'=>'malzeme','kod'=>$mlz_kodu,
            'adi'=>$stok_map[$mlz_kodu]['adi']??$info['adi'],'grup'=>$stok_map[$mlz_kodu]['grup']??$info['grup'],
            'stok'=>$stok,'toplam'=>array_sum($gi),'son_bakiye'=>$hesap['son_bakiye'],
            'baslangic_bakiye'=>$hesap['baslangic_bakiye'],'ilk_eksik'=>$hesap['ilk_eksik'],'gunluk'=>$hesap['gunluk']];
    }

    // Seviye 2
    $malzeme2_ihtiyac_map = [];
    foreach ($malzeme_satirlari as $mlz_kodu => $mlz_satiri) {
        if (!isset($bom_map[$mlz_kodu])) continue;
        foreach ($bom_map[$mlz_kodu] as $mlz2) {
            foreach ($gun_kolonlari as $t) {
                $net = $mlz_satiri['gunluk'][$t]['net_ihtiyac'] ?? 0;
                if ($net <= 0) continue;
                $malzeme2_ihtiyac_map[$mlz2['kod']][$t] = ($malzeme2_ihtiyac_map[$mlz2['kod']][$t] ?? 0) + $net * $mlz2['birim'];
                if (!isset($malzeme2_ihtiyac_map[$mlz2['kod']]['__info'])) $malzeme2_ihtiyac_map[$mlz2['kod']]['__info'] = ['adi'=>$mlz2['adi'],'grup'=>$mlz2['grup']];
            }
        }
    }
    $mlz2_kullanim_detay = [];
    foreach ($malzeme_satirlari as $mlz_kodu => $mlz_satiri) {
        if (!isset($bom_map[$mlz_kodu])) continue;
        foreach ($bom_map[$mlz_kodu] as $mlz2) {
            foreach ($gun_kolonlari as $t) {
                $net = $mlz_satiri['gunluk'][$t]['net_ihtiyac'] ?? 0;
                if ($net <= 0) continue;
                $mlz2_kullanim_detay[$mlz2['kod']][$t][] = ['urun_kodu'=>$mlz_kodu,'urun_adi'=>$mlz_satiri['adi'],'miktar'=>round($net*$mlz2['birim'],2)];
            }
        }
    }
    $malzeme2_satirlari = [];
    foreach ($malzeme2_ihtiyac_map as $mlz_kodu => $veriler) {
        $info = $veriler['__info'] ?? ['adi'=>$mlz_kodu,'grup'=>''];
        $gi2 = array_filter($veriler, function($k){return $k!=='__info';}, ARRAY_FILTER_USE_KEY);
        if (isset($malzeme_ihtiyac_map[$mlz_kodu])) {
            $gi1 = array_filter($malzeme_ihtiyac_map[$mlz_kodu], function($k){return $k!=='__info';}, ARRAY_FILTER_USE_KEY);
            $combined = [];
            foreach (array_unique(array_merge(array_keys($gi1), array_keys($gi2))) as $t) {
                $combined[$t] = ($gi1[$t]??0) + ($gi2[$t]??0);
            }
            $stok = $stok_map[$mlz_kodu]['stok'] ?? 0;
            $hesap = hesaplaGunluk($stok, $combined, $gun_kolonlari, $bugun_str_hesap);
            $malzeme_satirlari[$mlz_kodu]['toplam'] = array_sum($combined);
            $malzeme_satirlari[$mlz_kodu]['son_bakiye'] = $hesap['son_bakiye'];
            $malzeme_satirlari[$mlz_kodu]['baslangic_bakiye'] = $hesap['baslangic_bakiye'];
            $malzeme_satirlari[$mlz_kodu]['ilk_eksik'] = $hesap['ilk_eksik'];
            $malzeme_satirlari[$mlz_kodu]['gunluk'] = $hesap['gunluk'];
        } else {
            $stok = $stok_map[$mlz_kodu]['stok'] ?? 0;
            $hesap = hesaplaGunluk($stok, $gi2, $gun_kolonlari, $bugun_str_hesap);
            $malzeme2_satirlari[$mlz_kodu] = ['tip'=>'malzeme2','kod'=>$mlz_kodu,
                'adi'=>$stok_map[$mlz_kodu]['adi']??$info['adi'],'grup'=>$stok_map[$mlz_kodu]['grup']??$info['grup'],
                'stok'=>$stok,'toplam'=>array_sum($gi2),'son_bakiye'=>$hesap['son_bakiye'],
                'baslangic_bakiye'=>$hesap['baslangic_bakiye'],'ilk_eksik'=>$hesap['ilk_eksik'],'gunluk'=>$hesap['gunluk']];
        }
    }

    // Gantt
    $gantt_map = [];
    foreach ($siparis_satirlari as $urun_kodu => $ana) {
        if ($ana['ilk_eksik'] === null || !isset($bom_map[$urun_kodu]) || isset($gantt_map[$urun_kodu])) continue;
        $gun_list = []; $mlz_data = [];
        foreach ($gun_kolonlari as $t) {
            $ihtiyac = $ana['gunluk'][$t]['ihtiyac'] ?? 0;
            $net = $ana['gunluk'][$t]['net_ihtiyac'] ?? 0;
            if ($ihtiyac <= 0) continue;
            $bak = round($ana['gunluk'][$t]['bakiye'] ?? 0);
            $gun_list[] = ['ts'=>$t,'t'=>date('d.m',strtotime($t)),'d'=>round($ihtiyac),'n'=>round($net),'b'=>$bak];
        }
        foreach ($bom_map[$urun_kodu] as $mlz) {
            $mk = $mlz['kod'];
            $ms = $malzeme_satirlari[$mk] ?? $malzeme2_satirlari[$mk] ?? null;
            $mlz_days = [];
            foreach ($gun_list as $g) {
                $gerek = round($g['n'] * $mlz['birim'], 1);
                $m_net = $ms ? round($ms['gunluk'][$g['ts']]['net_ihtiyac'] ?? 0) : 0;
                $mlz_days[$g['ts']] = ['g'=>$gerek,'n'=>$m_net,'i'=>$ms?round($ms['gunluk'][$g['ts']]['ihtiyac']??0):0];
            }
            $has = false; foreach ($mlz_days as $d) { if ($d['g']>0||$d['n']>0){$has=true;break;} }
            if (!$has) continue;
            $mlz_data[] = ['kod'=>$mk,'adi'=>$stok_map[$mk]['adi']??$mlz['adi'],'grup'=>$mlz['grup'],'stok'=>$ms?round($ms['stok']):0,'days'=>$mlz_days];
        }
        if (empty($gun_list)) continue;
        $gantt_map[$urun_kodu] = ['kod'=>$urun_kodu,'adi'=>$ana['adi'],'stok'=>round($ana['stok']),
            'bas_bakiye'=>round($ana['baslangic_bakiye']??$ana['stok']),'gunler'=>$gun_list,'malzemeler'=>$mlz_data];
    }

    // Sırala ve birleştir
    function sortSatir($a, $b) {
        if ($a['ilk_eksik']===null && $b['ilk_eksik']===null) return strcmp($a['kod'],$b['kod']);
        if ($a['ilk_eksik']===null) return 1;
        if ($b['ilk_eksik']===null) return -1;
        return strcmp($a['ilk_eksik'],$b['ilk_eksik']);
    }
    $sip_list = array_values($siparis_satirlari); usort($sip_list,'sortSatir');
    $mlz_list = array_values($malzeme_satirlari); usort($mlz_list,'sortSatir');
    $mlz2_list = array_values($malzeme2_satirlari); usort($mlz2_list,'sortSatir');
    $satirlar = array_merge($sip_list, $mlz_list, $mlz2_list);

    // Satınalma siparişleri
    try {
        $sa_stmt = $tigerdb_pdo->query("SELECT IT.CODE AS STOK_KODU, IT.STGRPCODE AS GRUP,
            FORMAT(OL.DUEDATE,'dd.MM.yyyy') AS TERMIN_TARIHI, OL.DUEDATE AS TERMIN_SORT,
            FORMAT(OL.AMOUNT,'N0','de-DE') AS SIPARIS_MIKTARI,
            FORMAT(OL.SHIPPEDAMOUNT,'N0','de-DE') AS GELEN_MIKTAR,
            FORMAT(CASE WHEN OL.SHIPPEDAMOUNT>=OL.AMOUNT THEN 0 ELSE OL.AMOUNT-OL.SHIPPEDAMOUNT END,'N0','de-DE') AS KALAN_MIKTAR,
            CL.DEFINITION_ AS FIRMA_ADI, CASE WHEN OL.DUEDATE<GETDATE() THEN 1 ELSE 0 END AS GECTI
            FROM dbo.LG_222_02_ORFLINE AS OL WITH(NOLOCK)
            LEFT OUTER JOIN dbo.LG_222_02_ORFICHE AS ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_ITEMS AS IT WITH(NOLOCK) ON OL.STOCKREF=IT.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_CLCARD AS CL WITH(NOLOCK) ON ORF.CLIENTREF=CL.LOGICALREF
            WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT<OL.AMOUNT AND IT.STGRPCODE NOT IN ('Mamül','Yarımamül')
            ORDER BY CASE WHEN OL.DUEDATE<GETDATE() THEN DATEDIFF(DAY,OL.DUEDATE,GETDATE()) ELSE 10000+DATEDIFF(DAY,GETDATE(),OL.DUEDATE) END ASC");
        foreach ($sa_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) { $satin_alma_map[$row['STOK_KODU']][] = $row; }
    } catch(Throwable $e) {}

    // Üretim emirleri (bu ay, devam eden ve başlamadı)
    $ue_map = []; // [mamul_kodu][] = ue bilgileri
    try {
        $ue_stmt = $tigerdb_pdo->query("SELECT
            IT.CODE AS mamul_kod,
            WS.CODE AS is_istasyonu,
            CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
            PRO.FICHENO AS emr_no,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT)) AS kalan
        FROM dbo.LG_222_PRODORD AS PRO
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON IT.LOGICALREF  = PRO.ITEMREF
        LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS ON DIS.PRODORDREF = PRO.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS  ON WS.LOGICALREF  = DIS.WSREF
        WHERE YEAR(PRO.DATE_) = YEAR(GETDATE())
          AND MONTH(PRO.DATE_) = MONTH(GETDATE())
          AND PRO.STATUS IN (0,1)
        GROUP BY IT.CODE, WS.CODE, PRO.FICHENO, PRO.PLNAMOUNT, PRO.STATUS
        ORDER BY PRO.STATUS DESC");
        foreach ($ue_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $ue_map[$row['mamul_kod']][] = $row;
        }
    } catch(Throwable $e) {}

} catch(Throwable $e) { $hata_mrp = $e->getMessage(); }
}

$bugun_str = date('Y-m-d');
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔄 MRP — Malzeme İhtiyaç Planlaması</h1>
    <div class="s-yol">Planlama / <b>MRP</b>
      <?php if ($form_gonderildi && !empty($satirlar)): ?>
        <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● <?php echo count($satirlar); ?> satır / <?php echo count($gun_kolonlari); ?> gün</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- CDN -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/4.3.0/css/fixedColumns.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">

<style>
/* ── ERP Tema Uyumu ── */
.mrp-card { background:var(--kart);border:1px solid var(--kenar);border-radius:12px;padding:16px 20px;margin-bottom:12px; }
.mrp-wrap { overflow-x:auto; }
.mrp-table { border-collapse:collapse;width:100%;white-space:nowrap;font-size:12px; }
.mrp-table th { background:#2d5986!important;color:#e0f0ff!important;padding:7px 10px;font-size:11px;letter-spacing:.04em;border-right:1px solid #3b6fa3!important; }
.mrp-table td { padding:5px 8px;border-bottom:1px solid #E2E8F0;border-right:1px solid #E2E8F0; }
.mrp-table tfoot th { background:#1e3a5f!important;color:#e0f0ff!important;padding:4px 6px!important; }
.dt-filtre { width:100%;font-size:11px;padding:2px 4px;border:1px solid var(--kenar);border-radius:3px;background:var(--bg);color:var(--t); }
/* Satır tipleri */
tr.row-sip td  { background:#EFF6FF!important; }
tr.row-mlz td  { background:#FAFAFA!important; }
tr.row-mlz2 td { background:#F0FDF4!important; }
table.dataTable tbody tr.row-sip td.dtfc-fixed-left  { background:#EFF6FF!important; }
table.dataTable tbody tr.row-mlz td.dtfc-fixed-left  { background:#FAFAFA!important; }
table.dataTable tbody tr.row-mlz2 td.dtfc-fixed-left { background:#F0FDF4!important; }
/* Hücre renkleri */
td.dg,table.dataTable tbody td.dg { background:#BBF7D0!important; }
td.dr,table.dataTable tbody td.dr { background:#FCA5A5!important; }
table.dataTable tbody tr.row-sip td.dg,table.dataTable tbody tr.row-mlz td.dg { background:#BBF7D0!important; }
table.dataTable tbody tr.row-sip td.dr,table.dataTable tbody tr.row-mlz td.dr { background:#FCA5A5!important; }
.today-col { border-left:2px solid #3B82F6!important;border-right:2px solid #3B82F6!important; }
table.dataTable thead th,table.dataTable thead td { background:#2d5986!important;color:#e0f0ff!important;border-bottom:2px solid #1e3a5f!important; }
table.dataTable tfoot th,table.dataTable tfoot td  { background:#1e3a5f!important;color:#e0f0ff!important; }
/* Badge */
.bs  { display:inline-block;background:#3B82F6;color:#fff;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700; }
.bm  { display:inline-block;background:#7C3AED;color:#fff;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700; }
.bm2 { display:inline-block;background:#D1FAE5;color:#065F46;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700; }
.t-eksik { display:inline-block;background:#EF4444;color:#fff;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700; }
.t-ok    { display:inline-block;background:#22C55E;color:#fff;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700; }
.acik-eksik { color:#DC2626;font-weight:600;font-size:11px; }
.acik-ok    { color:#16A34A;font-size:11px; }
.indent  { padding-left:20px!important;color:#475569; }
.indent::before { content:"↳ ";color:#94A3B8; }
.indent2 { padding-left:36px!important;color:#374151; }
.indent2::before { content:"↳↳ ";color:#6EE7B7; }
td.has-sa,td.has-kullanim,td.has-gantt { cursor:pointer; }
/* Tom Select beyaz arka plan */
.ts-wrapper.multi .ts-control,
.ts-wrapper.single .ts-control { background:#fff!important;border:1px solid var(--kenar)!important;border-radius:8px!important;color:#1e293b!important; }
.ts-dropdown { background:#fff!important;border:1px solid var(--kenar)!important;color:#1e293b!important; }
.ts-dropdown .option { background:#fff!important;color:#1e293b!important; }
.ts-dropdown .option:hover,.ts-dropdown .option.active { background:#EFF6FF!important;color:#1E40AF!important; }
.ts-control input { color:#1e293b!important; }
.ts-control .item { background:#DBEAFE!important;color:#1E40AF!important;border-radius:4px!important;font-weight:600; }
/* Modal */
.mrp-modal-overlay { display:none;position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9990;align-items:center;justify-content:center; }
.mrp-modal-overlay.open { display:flex; }
.mrp-modal { background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.3);width:94vw;max-width:1400px;max-height:88vh;display:flex;flex-direction:column;overflow:hidden; }
.mrp-modal-head { display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-bottom:1px solid #E2E8F0;flex-shrink:0;background:#fff; }
.mrp-modal-head h4 { margin:0;font-size:14px;font-weight:800;color:#0F172A; }
.mrp-modal-close { background:none;border:none;cursor:pointer;color:#64748B;font-size:22px;padding:2px 8px;border-radius:6px; }
.mrp-modal-close:hover { background:#F1F5F9; }
.mrp-modal-body { overflow-y:auto;overflow-x:hidden;padding:12px 16px;flex:1;background:#fff;color:#1E293B; }
.modal-badge { display:inline-block;border-radius:4px;padding:2px 9px;font-size:11px;font-weight:700; }
/* Gantt */
.gantt-wrap { overflow-x:auto;padding-bottom:6px;width:100%; }
.gantt-table { border-collapse:collapse;white-space:nowrap;font-size:12px;width:100%; }
.gantt-week-header th { background:#1e3a5f;color:#f0f7ff;padding:5px 10px;text-align:center;font-size:11px;font-weight:700;border:1px solid #2d5986; }
.gantt-day-header th  { background:#2d5986;color:#e0f0ff;padding:4px 6px;text-align:center;font-size:11px;border:1px solid #3b6fa3; }
.gantt-th-kod  { min-width:130px;position:sticky;left:0;z-index:3;background:#2d5986!important;text-align:left!important;padding-left:10px!important; }
.gantt-th-adi  { min-width:200px;background:#2d5986!important;text-align:left!important;padding-left:10px!important;white-space:normal;word-break:break-word; }
.gantt-th-stok { min-width:80px;background:#2d5986!important;text-align:right!important;padding-right:10px!important; }
.gantt-th-bak  { min-width:80px;background:#2d5986!important;text-align:right!important;padding-right:10px!important;border-right:2px solid #4a7fa5!important; }
.gantt-ana-row .gantt-kod-col { background:#EFF6FF;color:#1E40AF;font-weight:700; }
.gantt-mlz-row .gantt-kod-col { background:#F8FAFC;color:#334155; }
.gantt-kod-col { position:sticky;left:0;z-index:2;min-width:130px;padding:6px 10px;border-right:1px solid #E2E8F0;font-size:12px;vertical-align:middle;white-space:nowrap; }
.gantt-adi-col { min-width:200px;padding:6px 10px;border-right:1px solid #E2E8F0;font-size:12px;vertical-align:middle;white-space:normal;word-break:break-word; }
.gantt-ana-row .gantt-adi-col { font-weight:600;color:var(--t);background:#EFF6FF; }
.gantt-mlz-row .gantt-adi-col { background:#F8FAFC;color:#334155; }
.gantt-stok-col { min-width:80px;padding:6px 10px;text-align:right;font-size:12px;vertical-align:middle; }
.gantt-ana-row .gantt-stok-col { background:#EFF6FF;color:#0369A1;font-weight:700; }
.gantt-mlz-row .gantt-stok-col { background:#F8FAFC; }
.gantt-bak-col  { min-width:80px;padding:6px 10px;text-align:right;font-size:12px;vertical-align:middle;border-right:2px solid #CBD5E1;font-weight:700; }
.gantt-ana-row .gantt-bak-col { background:#EFF6FF; }
.gantt-mlz-row .gantt-bak-col { background:#F8FAFC;color:#94A3B8;font-weight:400; }
.gantt-cell { min-width:52px;text-align:center;padding:4px 3px;vertical-align:middle; }
.gantt-cell-val { display:block;font-weight:700;font-size:11px;line-height:1.4; }
.gc-red      { background:#FCA5A5; } .gc-red-lite { background:#FEE2E2; }
.gc-green    { background:#86EFAC; } .gc-ok       { background:#BAE6FD; }
.gc-empty    { background:#F8FAFC; } .gc-today    { outline:2px solid #3B82F6!important;outline-offset:-2px; }
.gantt-bak-neg { background:#FEE2E2;color:#991B1B; } .gantt-bak-pos { background:#F0FDF4;color:#166534; }
.gantt-bak-row td { border-top:2px dashed #E2E8F0; }
.gantt-dot { display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:3px;vertical-align:middle; }
.gantt-legend { display:flex;gap:14px;font-size:12px;color:#64748B;margin-bottom:12px;flex-wrap:wrap; }
/* SA Modal */
.sa-gantt-table .sa-th-kontrol { min-width:130px;position:sticky;left:0;z-index:3;background:#2d5986!important;text-align:left!important;padding-left:10px!important; }
.sa-gantt-table .sa-th-firma   { min-width:180px;background:#2d5986!important;text-align:left!important;padding-left:10px!important;white-space:normal; }
.sa-gantt-table .sa-th-bak     { min-width:80px;background:#2d5986!important;text-align:right!important;padding-right:10px!important;border-right:2px solid #4a7fa5!important; }
.sa-kontrol-col { position:sticky;left:0;z-index:2;min-width:130px;padding:6px 10px;font-weight:700;font-size:11px;color:#334155;border-right:1px solid #E2E8F0;vertical-align:middle;white-space:normal; }
.sa-row-acik .sa-kontrol-col { background:#EFF6FF; } .sa-row-oneri .sa-kontrol-col { background:#F0FDF4; } .sa-row-islem .sa-kontrol-col { background:#FAFAFA; }
.sa-firma-col { min-width:180px;padding:6px 10px;font-size:12px;color:#334155;vertical-align:middle;white-space:normal;word-break:break-word; }
.sa-row-acik .sa-firma-col { background:#EFF6FF; } .sa-row-oneri .sa-firma-col { background:#F0FDF4; } .sa-row-islem .sa-firma-col { background:#FAFAFA; }
.sa-bak-col { min-width:80px;padding:6px 10px;font-size:12px;font-weight:700;text-align:right;border-right:2px solid #CBD5E1;vertical-align:middle; }
.sa-row-acik .sa-bak-col { background:#EFF6FF;color:#0369A1; } .sa-row-oneri .sa-bak-col { background:#F0FDF4;color:#166534; } .sa-row-islem .sa-bak-col { background:#FAFAFA;color:#94A3B8; }
.sa-cell-acik  { background:#DBEAFE!important; } .sa-cell-oneri { background:#D1FAE5!important; }
.sa-islem-cell { height:90px;padding:0!important;vertical-align:top; }
.sa-islem-wrap { display:flex;flex-direction:row;height:100%;width:100%; }
.sa-islem-text { flex:1;display:flex;align-items:center;justify-content:center;writing-mode:vertical-rl;transform:rotate(180deg);font-size:10px;font-weight:700;white-space:nowrap;border-left:1px solid rgba(0,0,0,.08); }
.sa-islem-text:first-child { border-left:none; }
.sa-islem-one    { background:#FEF08A!important;color:#78350F!important; }
.sa-islem-ertele { background:#FED7AA!important;color:#7C2D12!important; }
.sa-islem-yeni   { background:#BAE6FD!important;color:#0C4A6E!important; }
.sa-islem-ok     { background:#BBF7D0!important;color:#14532D!important; }
.sa-islem-iptal  { background:#FCA5A5!important;color:#7F1D1D!important; }
.sa-row-acik td,.sa-row-oneri td,.sa-row-islem td { border-bottom:1px solid #E2E8F0; }
/* Butonlar */
.btn-dt { background:#2d5986!important;color:#fff!important;border:none!important;border-radius:4px!important;padding:5px 12px!important;font-size:12px!important;margin-right:4px!important; }
.btn-dt:hover { background:#1e3a5f!important; }
div.dt-buttons { margin-bottom:8px; }
</style>

<div class="s-body">
<?php if (isset($hata_mrp)): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata_mrp); ?></div>
<?php endif; ?>

<!-- Filtre Formu -->
<div class="mrp-card">
  <div style="font-size:13px;font-weight:800;color:var(--t);margin-bottom:12px;text-transform:uppercase;letter-spacing:.03em">🔍 MRP Filtresi</div>
  <form method="POST" id="mrpForm">
    <div style="display:flex;align-items:flex-end;gap:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:280px">
        <label class="form-etiket">Müşteri Filtresi <span style="color:var(--m2);font-weight:400">(Boş = tümü)</span></label>
        <select id="musteri_select" name="musteriler[]" multiple placeholder="Müşteri seçin..." autocomplete="off">
          <?php foreach ($musteri_listesi as $m): ?>
          <option value="<?php echo htmlspecialchars($m); ?>" <?php echo in_array($m,$secili_musteriler)?'selected':''; ?>><?php echo htmlspecialchars($m); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:8px;padding-bottom:2px">
        <button type="submit" name="mrp_calistir" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:10px 22px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">▶ Hesapla</button>
        <button type="button" onclick="tomSel.clear();document.getElementById('mrpForm').submit();" style="background:var(--bg);color:var(--m);border:1px solid var(--kenar);padding:10px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;font-size:13px">✕ Temizle</button>
      </div>
    </div>
  </form>
</div>

<?php if (!$form_gonderildi): ?>
<div style="padding:50px;text-align:center;color:var(--m2);background:var(--bg);border-radius:12px;border:2px dashed var(--kenar)">
  <div style="font-size:36px;margin-bottom:12px">🔄</div>
  <div style="font-size:15px;font-weight:700;color:var(--t)">Hesaplama Başlatılmadı</div>
  <div style="font-size:13px;margin-top:6px">Müşteri seçip <strong>Hesapla</strong> butonuna tıklayın.</div>
</div>
<?php elseif (empty($satirlar)): ?>
<div style="padding:40px;text-align:center;color:var(--m2)">Veri bulunamadı.</div>
<?php else: ?>

<div class="mrp-card" style="padding:0;overflow:hidden">
<div class="mrp-wrap">
<table id="mrpTable" class="mrp-table" style="width:100%">
<thead>
  <tr>
    <th style="min-width:90px">Durum</th>
    <th style="min-width:120px">Stok Kodu</th>
    <th style="min-width:200px">Stok Adı</th>
    <th style="min-width:90px">Grup</th>
    <th style="min-width:80px;text-align:right">Stok</th>
    <th style="min-width:90px;text-align:right">Toplam Sip.</th>
    <th style="min-width:100px;text-align:center">İlk Eksik</th>
    <th style="min-width:120px">Durum Açıkl.</th>
    <th style="min-width:80px;text-align:right">Geçmiş</th>
    <?php foreach ($gun_kolonlari as $tarih): $is_today=($tarih===$bugun_str); ?>
    <th class="<?php echo $is_today?'today-col':''; ?>" style="min-width:70px;text-align:center">
      <?php echo date('d.m',strtotime($tarih)); ?>
      <?php if($is_today): ?><br><span style="font-size:9px;color:#FCD34D">BUGÜN</span><?php endif; ?>
    </th>
    <?php endforeach; ?>
  </tr>
</thead>
<tfoot>
  <tr>
    <th>Durum</th><th>Stok Kodu</th><th>Stok Adı</th><th>Grup</th>
    <th>Stok</th><th>Toplam Sip.</th><th>İlk Eksik</th><th>Açıklama</th><th>Geçmiş</th>
    <?php foreach ($gun_kolonlari as $t): ?><th><?php echo date('d.m',strtotime($t)); ?></th><?php endforeach; ?>
  </tr>
</tfoot>
<tbody>
<?php foreach ($satirlar as $satir):
    $is_sip=$satir['tip']==='siparis'; $is_mlz2=$satir['tip']==='malzeme2';
    $row_cls=$is_sip?'row-sip':($is_mlz2?'row-mlz2':'row-mlz');
    // Kullanım popup
    $kullanim_popup_json='';
    if (!$is_sip) {
        $dk=$is_mlz2?$mlz2_kullanim_detay:$mlz_kullanim_detay;
        $kb=$satir['kod'];
        if (!empty($dk[$kb])) {
            $gs=[];
            foreach ($gun_kolonlari as $t) {
                $nm=$satir['gunluk'][$t]['net_ihtiyac']??0;
                $ko=$dk[$kb][$t]??[];
                if ($nm<=0&&empty($ko)) continue;
                $gs[]=['tarih'=>date('d.m.Y',strtotime($t)),'ts'=>$t,'t'=>date('d.m',strtotime($t)),'eksik'=>$nm>0,'net_mat'=>round($nm),'kullanim'=>$ko];
            }
            if (!empty($gs)) $kullanim_popup_json=json_encode(['kod'=>$satir['kod'],'adi'=>$satir['adi'],'tip'=>$is_mlz2?'Alt İhtiyaç 2':'Alt İhtiyaç','stok'=>round($satir['stok']),'bas_bakiye'=>round($satir['baslangic_bakiye']??$satir['stok']),'gunler'=>$gs],JSON_UNESCAPED_UNICODE|JSON_HEX_APOS|JSON_HEX_QUOT);
        }
    }
    // Satınalma popup
    $gecmis_toplam=$satir['stok']-($satir['baslangic_bakiye']??$satir['stok']);
    $grup_kd=strtolower(trim($satir['grup']??''));
    $is_uretim=in_array($grup_kd,['mamül','mamul','yarımamül','yarimamul']);
    $sa_satirlar=$satin_alma_map[$satir['kod']]??[];
    $has_sa=!$is_uretim&&$satir['ilk_eksik']!==null;
    $popup_json='';
    if ($has_sa) {
        $haftalik=[]; foreach ($gun_kolonlari as $gt) { $net=$satir['gunluk'][$gt]['net_ihtiyac']??0; if ($net<=0) continue; $gt_dt=new DateTime($gt); $dow=(int)$gt_dt->format('N'); $pzt=clone $gt_dt; $pzt->modify('-'.($dow==7?0:$dow-1).' days'); if($dow==7) $pzt->modify('+1 day'); $ps=$pzt->format('Y-m-d'); $haftalik[$ps]=($haftalik[$ps]??0)+$net; } ksort($haftalik);
        $acik_sp=[]; foreach ($sa_satirlar as $sa) { $td=DateTime::createFromFormat('d.m.Y',$sa['TERMIN_TARIHI']); $kf=floatval(str_replace('.','', $sa['KALAN_MIKTAR'])); $acik_sp[]=['sa'=>$sa,'termin_str'=>$td?$td->format('Y-m-d'):'9999-12-31','kalan_kalan'=>$kf]; } usort($acik_sp,function($a,$b){return strcmp($a['termin_str'],$b['termin_str']);});
        $oneri_satirlari=[];
        foreach ($haftalik as $pzt_str=>$hn) {
            $pzt_dt=new DateTime($pzt_str); $ideal=clone $pzt_dt; $ki=$hn; $ho=['hafta_sort'=>$pzt_str,'hafta_basi'=>$pzt_dt->format('d.m.Y'),'net_ihtiyac'=>round($hn),'eylemler'=>[]];
            foreach ($acik_sp as &$as) { if ($ki<=0||$as['kalan_kalan']<=0) continue; $kul=min($as['kalan_kalan'],$ki); $ki-=$kul; $as['kalan_kalan']-=$kul; $gf=(int)((new DateTime($as['termin_str']))->getTimestamp()-$ideal->getTimestamp())/86400; $hedef=clone $ideal; $bugun2=new DateTime($bugun_str_hesap??$bugun_str); if($hedef<$bugun2)$hedef=clone $bugun2; if($as['termin_str']<(clone $ideal)->modify('-7 days')->format('Y-m-d')){$d='ertele';$m='Ertele → '.$ideal->format('d.m.Y');} elseif($gf>2&&$as['termin_str']>$hedef->format('Y-m-d')){$d='one_cek';$m='Öne çek → '.$hedef->format('d.m.Y');} else{$d='ok';$m='Zamanında ('.$as['sa']['TERMIN_TARIHI'].')';} $ho['eylemler'][]=['firma'=>$as['sa']['FIRMA_ADI']??'—','termin'=>$as['sa']['TERMIN_TARIHI'],'kullan'=>round($kul),'durum'=>$d,'mesaj'=>$m,'hedef_iso'=>$hedef->format('Y-m-d'),'hedef_tr'=>$hedef->format('d.m.Y')]; } unset($as);
            if ($ki>0.5){$bugun2=new DateTime($bugun_str_hesap??$bugun_str);$yh=clone $ideal;if($yh<$bugun2)$yh=clone $bugun2;$ho['eylemler'][]=['firma'=>null,'termin'=>$yh->format('d.m.Y'),'kullan'=>round($ki),'durum'=>'yeni','mesaj'=>'Yeni sipariş aç → '.round($ki).' adet','hedef_iso'=>$yh->format('Y-m-d'),'hedef_tr'=>$yh->format('d.m.Y')];}
            $oneri_satirlari[]=$ho;
        }
        $popup_json=json_encode(['kod'=>$satir['kod'],'satirlar'=>$sa_satirlar,'oneriler'=>$oneri_satirlari],JSON_UNESCAPED_UNICODE|JSON_HEX_APOS|JSON_HEX_QUOT);
    }
    // Bakiye
    $bas_bak=$satir['baslangic_bakiye']??$satir['stok'];
    $gecmis_ihtiyac_var=$gecmis_toplam>0.01;
    $son_bak=$satir['son_bakiye']??0;
    $gelecek_net=0; foreach ($gun_kolonlari as $gt){$gelecek_net+=$satir['gunluk'][$gt]['net_ihtiyac']??0;}
    if (!$gelecek_net&&!$gecmis_ihtiyac_var){$acik_cls='acik-ok';$acik_txt='—';}
    elseif ($son_bak>=0){$acik_cls='acik-ok';$acik_txt='Stok yeterli';}
    else {$acik_cls='acik-eksik';$acik_txt='Açık: '.number_format(abs($son_bak),0,',','.').' adet eksik';}
?>
<tr class="<?php echo $row_cls; ?>" data-ilk-eksik="<?php echo htmlspecialchars($satir['ilk_eksik']??''); ?>">
  <td class="<?php echo $has_sa?'has-sa':''; ?> <?php echo isset($gantt_map[$satir['kod']])?'has-gantt':''; ?>"
      <?php if($has_sa):?>data-sa='<?php echo $popup_json;?>'<?php endif;?>
      <?php if(isset($gantt_map[$satir['kod']])):?>data-gantt-kod="<?php echo htmlspecialchars($satir['kod']);?>"<?php endif;?>
      style="text-align:center">
    <span class="<?php echo $is_sip?'bs':($is_mlz2?'bm2':'bm');?>">
      <?php echo $is_sip?'Sipariş':($is_mlz2?'Alt İhtiyaç 2':'Alt İhtiyaç');?>
      <?php if($has_sa):?><sup style="font-size:9px">🛒</sup><?php endif;?>
      <?php if(isset($gantt_map[$satir['kod']])):?><sup style="font-size:9px">📈</sup><?php endif;?>
    </span>
  </td>
  <td class="<?php echo (!$is_sip&&$kullanim_popup_json)?'has-kullanim':'';?>"
      style="font-weight:<?php echo $is_sip?'700':'500';?>;font-size:11px;"
      <?php if(!$is_sip&&$kullanim_popup_json):?>data-kullanim='<?php echo $kullanim_popup_json;?>'<?php endif;?>>
    <?php echo htmlspecialchars($satir['kod']);?>
    <?php if(!$is_sip&&$kullanim_popup_json):?><sup style="font-size:9px;color:#7C3AED">📋</sup><?php endif;?>
  </td>
  <td class="<?php echo $is_sip?'':($is_mlz2?'indent2':'indent');?>">
    <?php echo htmlspecialchars($satir['adi']);?>
  </td>
  <td style="color:var(--m2);font-size:11px"><?php echo htmlspecialchars($satir['grup']);?></td>
  <td style="text-align:right;font-weight:700"><?php echo number_format($satir['stok'],0,',','.');?></td>
  <td style="text-align:right;font-weight:700"><?php echo number_format($satir['toplam'],0,',','.');?></td>
  <td style="text-align:center" data-order="<?php echo $satir['ilk_eksik']??'ZZZZ';?>">
    <?php if($satir['ilk_eksik']):?><span class="t-eksik"><?php echo date('d.m.Y',strtotime($satir['ilk_eksik']));?></span>
    <?php else:?><span class="t-ok">—</span><?php endif;?>
  </td>
  <td><span class="<?php echo $acik_cls;?>"><?php echo htmlspecialchars($acik_txt);?></span></td>
  <td style="text-align:right;font-weight:700;color:<?php echo $bas_bak>=0?'#166534':'#DC2626';?>">
    <?php echo $gecmis_ihtiyac_var?number_format($gecmis_toplam,0,',','.'):0;?>
  </td>
  <?php foreach ($gun_kolonlari as $tarih):
    $g=$satir['gunluk'][$tarih]??['ihtiyac'=>0,'net_ihtiyac'=>0,'bakiye'=>$satir['stok']];
    $sip_m=$g['ihtiyac']; $net_m=$g['net_ihtiyac']; $is_today=($tarih===$bugun_str);
    $ilk_e=$satir['ilk_eksik'];
    $dcls=($ilk_e!==null&&$tarih>=$ilk_e)?'dr':'dg';
  ?>
  <td class="<?php echo $dcls;?> <?php echo $is_today?'today-col':'';?>" style="text-align:right;min-width:70px;font-size:12px" data-tarih="<?php echo $tarih;?>" data-ihtiyac="<?php echo $net_m;?>">
    <?php if($net_m>0):?><span style="color:#991B1B;font-weight:700"><?php echo number_format($net_m,0,',','.');?></span>
    <?php elseif($sip_m>0):?><span style="color:#166534"><?php echo number_format($sip_m,0,',','.');?></span>
    <?php endif;?>
  </td>
  <?php endforeach;?>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
</div>
<?php endif;?>
</div>

<!-- Modal -->
<div id="mrpModalOverlay" class="mrp-modal-overlay">
  <div class="mrp-modal">
    <div class="mrp-modal-head">
      <h4 id="mrpModalTitle">Detay</h4>
      <button class="mrp-modal-close" id="mrpModalClose">&#x2715;</button>
    </div>
    <div class="mrp-modal-body" id="mrpModalBody"></div>
  </div>
</div>

<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
<script>
var tomSel = new TomSelect('#musteri_select',{plugins:['remove_button'],placeholder:'Müşteri seçin...',maxOptions:500});
</script>

<?php if ($form_gonderildi && !empty($satirlar)): ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
var mrpGanttData = <?php echo json_encode($gantt_map, JSON_UNESCAPED_UNICODE|JSON_HEX_TAG); ?>;
var BUGUN = '<?php echo $bugun_str; ?>';
</script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/4.3.0/js/dataTables.fixedColumns.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script>
$(document).ready(function(){
  var table = $('#mrpTable').DataTable({
    scrollX:true,scrollY:'580px',scrollCollapse:true,paging:false,
    order:[[6,'asc']],
    fixedColumns:{left:9},
    drawCallback:function(){
      $('#mrpTable tbody tr').each(function(){
        var $tr=$(this),ie=$tr.data('ilk-eksik')||'';
        if($tr.hasClass('row-mlz2'))$tr.find('td').not('[data-tarih]').css('background','#F0FDF4');
        else if($tr.hasClass('row-mlz'))$tr.find('td').not('[data-tarih]').css('background','#FAFAFA');
        else if($tr.hasClass('row-sip'))$tr.find('td').not('[data-tarih]').css('background','#EFF6FF');
        $tr.find('td[data-tarih]').each(function(){
          var t=$(this).data('tarih');
          $(this).removeClass('dg dr today-col');
          $(this).addClass(ie&&t>=ie?'dr':'dg');
          if(t===BUGUN)$(this).addClass('today-col');
        });
      });
    },
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'MRP_Plan'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns([0,1,2,3,4,5,6,7,8]).every(function(){
        var col=this;
        var sel=$('<select class="dt-filtre"><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>30?v.substr(0,30)+'…':v)+'</option>');});
      });
    }
  });

  // Modal
  var $ov=$('#mrpModalOverlay'),$mb=$('#mrpModalBody'),$mt=$('#mrpModalTitle');
  function openM(t,b){$mt.html(t);$mb.html(b);$ov.addClass('open');$('body').css('overflow','hidden');}
  function closeM(){$ov.removeClass('open');$('body').css('overflow','');setTimeout(function(){$mb.html('');},250);}
  $('#mrpModalClose').on('click',closeM);
  $ov.on('click',function(e){if($(e.target).is($ov))closeM();});
  $(document).on('keydown',function(e){if(e.key==='Escape')closeM();});

  // Gantt builder
  function buildUeBilgisi(kod) {
    var ues = mrpUeData[kod];
    if(!ues||!ues.length) return '';
    var html='<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:6px;padding:8px 10px;margin-bottom:10px;font-size:11px">';
    html+='<div style="font-weight:700;color:#1E40AF;margin-bottom:5px">📋 Üretim Emri</div>';
    ues.forEach(function(e){
      var renk = e.durum==='Devam Ediyor'?'#065F46':'#1E40AF';
      var bg   = e.durum==='Devam Ediyor'?'#D1FAE5':'#DBEAFE';
      html+='<div style="display:flex;gap:10px;align-items:center;padding:4px 0;border-bottom:1px solid #E2E8F0">';
      html+='<span style="background:'+bg+';color:'+renk+';padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700">'+e.durum+'</span>';
      html+='<span style="font-weight:700;color:#0369A1">'+e.emr_no+'</span>';
      if(e.is_istasyonu) html+='<span style="color:#64748B">'+e.is_istasyonu+'</span>';
      html+='<span style="margin-left:auto">Planlanan: <b>'+parseInt(e.planlanan).toLocaleString('tr-TR')+'</b></span>';
      html+='<span>Üretilen: <b style="color:#059669">'+parseInt(e.uretilen).toLocaleString('tr-TR')+'</b></span>';
      html+='<span>Kalan: <b style="color:'+(parseInt(e.kalan)>0?'#DC2626':'#059669')+'">'+Math.max(0,parseInt(e.kalan)).toLocaleString('tr-TR')+'</b></span>';
      html+='</div>';
    });
    html+='</div>';
    return html;
  }

  function buildGantt(d){
    var g=d.gunler; if(!g||!g.length) return '<div style="padding:20px;text-align:center;color:var(--m2)">Talep yok.</div>';
    var weeks={};
    g.forEach(function(x){var dt=new Date(x.ts),dow=dt.getDay()||7,pzt=new Date(dt);pzt.setDate(dt.getDate()-(dow-1));var k=pzt.toISOString().slice(0,10);if(!weeks[k])weeks[k]=[];weeks[k].push(x);});
    var wk=Object.keys(weeks).sort();
    var h='<div class="gantt-legend"><span><i class="gantt-dot" style="background:#FCA5A5"></i>Eksik</span><span><i class="gantt-dot" style="background:#86EFAC"></i>Yeterli</span><span><i class="gantt-dot" style="background:#BAE6FD"></i>Malz. Yeterli</span></div>';
    h+='<div class="gantt-wrap"><table class="gantt-table"><thead><tr class="gantt-week-header"><th class="gantt-th-kod gwh-name" colspan="4">&nbsp;</th>';
    wk.forEach(function(w){var c=weeks[w].length,f=weeks[w][0].t,l=weeks[w][weeks[w].length-1].t;h+='<th colspan="'+c+'">'+f+' – '+l+'</th>';});
    h+='</tr><tr class="gantt-day-header"><th class="gantt-th-kod">Kod</th><th class="gantt-th-adi">Adı</th><th class="gantt-th-stok">Stok</th><th class="gantt-th-bak">Bakiye</th>';
    g.forEach(function(x){h+='<th'+(x.ts===BUGUN?' class="gantt-today"':'')+'>'+x.t+'</th>';});
    h+='</tr></thead><tbody><tr class="gantt-ana-row"><td class="gantt-kod-col">'+d.kod+'</td><td class="gantt-adi-col">'+d.adi+'</td><td class="gantt-stok-col">'+d.stok.toLocaleString('tr-TR')+'</td><td class="gantt-bak-col'+(d.bas_bakiye<0?' gantt-bak-neg':' gantt-bak-pos')+'">'+d.bas_bakiye.toLocaleString('tr-TR')+'</td>';
    g.forEach(function(x){var c=x.ts===BUGUN?' gc-today':'';if(x.n>0){h+='<td class="gantt-cell gc-red'+c+'"><span class="gantt-cell-val">'+x.n.toLocaleString('tr-TR')+'</span>';}else if(x.d>0){h+='<td class="gantt-cell gc-green'+c+'"><span class="gantt-cell-val">✓</span>';}else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});
    h+='</tr><tr class="gantt-bak-row"><td class="gantt-kod-col" style="font-size:11px;color:var(--m2)">Bakiye</td><td class="gantt-adi-col" style="font-size:11px;color:var(--m2)">Kümülatif</td><td class="gantt-stok-col" style="color:var(--m2)">—</td><td class="gantt-bak-col'+(d.bas_bakiye<0?' gantt-bak-neg':' gantt-bak-pos')+'">'+d.bas_bakiye.toLocaleString('tr-TR')+'</td>';
    g.forEach(function(x){h+='<td class="gantt-cell'+(x.b<0?' gantt-bak-neg':' gantt-bak-pos')+(x.ts===BUGUN?' gc-today':'')+'" ><span class="gantt-cell-val" style="font-size:10px">'+x.b.toLocaleString('tr-TR')+'</span></td>';});
    h+='</tr>';
    (d.malzemeler||[]).forEach(function(m){h+='<tr class="gantt-mlz-row"><td class="gantt-kod-col">↳ '+m.kod+'</td><td class="gantt-adi-col">'+m.adi+'</td><td class="gantt-stok-col">'+m.stok.toLocaleString('tr-TR')+'</td><td class="gantt-bak-col" style="color:var(--m2);font-weight:400">—</td>';g.forEach(function(x){var dm=m.days&&m.days[x.ts]?m.days[x.ts]:null,c=x.ts===BUGUN?' gc-today':'';if(dm&&dm.n>0){h+='<td class="gantt-cell gc-red-lite'+c+'" title="Eksik: '+dm.n+'"><span class="gantt-cell-val">'+dm.n.toLocaleString('tr-TR')+'</span>';}else if(dm&&dm.g>0){h+='<td class="gantt-cell gc-ok'+c+'"><span class="gantt-cell-val">✓</span>';}else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});h+='</tr>';});
    h+='</tbody></table></div>';
    return h;
  }

  // SA builder
  function buildSa(d){
    function pN(s){return parseFloat((s+'').replace(/\./g,'').replace(',','.'))||0;}
    var dMap={};
    (d.satirlar||[]).forEach(function(s){if(s.TERMIN_ISO||s.TERMIN_TARIHI){var iso=s.TERMIN_ISO||(function(){var p=s.TERMIN_TARIHI.split('.');return p[2]+'-'+p[1]+'-'+p[0];}());dMap[iso]=s.TERMIN_TARIHI.substr(0,5);}});
    (d.oneriler||[]).forEach(function(o){(o.eylemler||[]).forEach(function(e){if(e.hedef_iso)dMap[e.hedef_iso]=e.hedef_tr?e.hedef_tr.substr(0,5):e.hedef_iso.slice(5).split('-').reverse().join('.');});});
    var dates=Object.keys(dMap).sort();
    if(!dates.length) return '<div style="padding:20px;text-align:center;color:var(--m2)">Açık satınalma yok.</div>';
    var weeks={};dates.forEach(function(iso){var dt=new Date(iso),dow=dt.getDay()||7,pzt=new Date(dt);pzt.setDate(dt.getDate()-(dow-1));var k=pzt.toISOString().slice(0,10);if(!weeks[k])weeks[k]=[];weeks[k].push(iso);});
    var wk=Object.keys(weeks).sort();
    var h='<div class="gantt-wrap"><table class="gantt-table sa-gantt-table"><thead><tr class="gantt-week-header"><th class="gantt-th-kod gwh-name sa-th-kontrol">KONTROL</th><th class="sa-th-firma">FİRMA</th><th class="sa-th-bak">TOPLAM</th>';
    wk.forEach(function(w){var c=weeks[w].length,f=dMap[weeks[w][0]],l=dMap[weeks[w][weeks[w].length-1]];h+='<th colspan="'+c+'">'+f+' – '+l+'</th>';});
    h+='</tr><tr class="gantt-day-header"><th class="sa-th-kontrol"></th><th class="sa-th-firma"></th><th class="sa-th-bak"></th>';
    dates.forEach(function(iso){h+='<th'+(iso===BUGUN?' class="gantt-today"':'')+'>'+dMap[iso]+'</th>';});
    h+='</tr></thead><tbody>';
    // Açık siparişler
    var fAcik={};(d.satirlar||[]).forEach(function(s){var f=s.FIRMA_ADI||'—';if(!fAcik[f])fAcik[f]={};var iso=s.TERMIN_ISO||(function(){var p=s.TERMIN_TARIHI.split('.');return p[2]+'-'+p[1]+'-'+p[0];}());fAcik[f][iso]=(fAcik[f][iso]||0)+pN(s.KALAN_MIKTAR);});
    Object.keys(fAcik).forEach(function(f,i){var dd=fAcik[f],tot=Object.values(dd).reduce(function(a,b){return a+b;},0);h+='<tr class="sa-row-acik"><td class="sa-kontrol-col">'+(i===0?'AÇIK SİPARİŞLER':'')+'</td><td class="sa-firma-col">'+f+'</td><td class="sa-bak-col">'+tot.toLocaleString('tr-TR')+'</td>';dates.forEach(function(iso){var c=iso===BUGUN?' gc-today':'',m=dd[iso]||0;if(m>0)h+='<td class="gantt-cell sa-cell-acik'+c+'"><span class="gantt-cell-val">'+m.toLocaleString('tr-TR')+'</span>';else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});h+='</tr>';});
    // Öneri
    var fOn={};(d.oneriler||[]).forEach(function(o){(o.eylemler||[]).forEach(function(e){var f=e.firma||'YENİ SİPARİŞ';if(!fOn[f])fOn[f]={};if(e.hedef_iso)fOn[f][e.hedef_iso]=(fOn[f][e.hedef_iso]||0)+(e.kullan||0);});});
    Object.keys(fOn).forEach(function(f,i){var dd=fOn[f],tot=Object.values(dd).reduce(function(a,b){return a+b;},0);h+='<tr class="sa-row-oneri"><td class="sa-kontrol-col">'+(i===0?'TEDARİK ÖNERİSİ':'')+'</td><td class="sa-firma-col">'+f+'</td><td class="sa-bak-col">'+(tot>0?tot.toLocaleString('tr-TR'):'—')+'</td>';dates.forEach(function(iso){var c=iso===BUGUN?' gc-today':'',m=dd[iso]||0;if(m>0)h+='<td class="gantt-cell sa-cell-oneri'+c+'"><span class="gantt-cell-val">'+m.toLocaleString('tr-TR')+'</span>';else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});h+='</tr>';});
    // İşlem satırı
    var iMap={};var prio={'iptal':5,'one_cek':4,'yeni':3,'ertele':2,'ok':1};
    (d.oneriler||[]).forEach(function(o){(o.eylemler||[]).forEach(function(e){if(!e.hedef_iso)return;if(!iMap[e.hedef_iso])iMap[e.hedef_iso]=[];var grp=iMap[e.hedef_iso],fd=null;for(var k=0;k<grp.length;k++){if(grp[k].durum===e.durum){fd=grp[k];break;}}if(fd)fd.kullan+=(e.kullan||0);else grp.push({durum:e.durum,mesaj:e.mesaj,kullan:e.kullan||0});});});
    Object.keys(iMap).forEach(function(iso){iMap[iso].sort(function(a,b){return(prio[b.durum]||0)-(prio[a.durum]||0);});});
    h+='<tr class="sa-row-islem"><td class="sa-kontrol-col" style="line-height:1.6">YAPILMASI<br>GEREKEN<br>İŞLEM</td><td class="sa-firma-col"></td><td class="sa-bak-col"></td>';
    dates.forEach(function(iso){var il=iMap[iso];if(il&&il.length){var nonOk=il.filter(function(x){return x.durum!=='ok';});var show=nonOk.length?nonOk:[il[0]];var dc;switch(show[0].durum){case'one_cek':dc='sa-islem-one';break;case'ertele':dc='sa-islem-ertele';break;case'yeni':dc='sa-islem-yeni';break;case'iptal':dc='sa-islem-iptal';break;default:dc='sa-islem-ok';}h+='<td class="gantt-cell sa-islem-cell '+dc+'"><div class="sa-islem-wrap">';show.forEach(function(il2){var lbl;switch(il2.durum){case'one_cek':lbl='ÖNE ÇEKİLMELİ';break;case'ertele':lbl='ERTELENMELİ';break;case'yeni':lbl='YENİ SİPARİŞ';break;case'iptal':lbl='İPTAL';break;default:lbl='UYGUN';}h+='<span class="sa-islem-text">'+lbl+(il2.kullan>0?' '+il2.kullan.toLocaleString('tr-TR')+' ADET':'')+'</span>';});h+='</div>';}else h+='<td class="gantt-cell gc-empty">';h+='</td>';});
    h+='</tr></tbody></table></div>';
    return h;
  }

  // Kullanım detay
  function buildKullanim(d){
    if(!d.gunler||!d.gunler.length) return '<div style="padding:20px;text-align:center;color:var(--m2)">Kullanım yok.</div>';
    var pMap={};d.gunler.forEach(function(g){(g.kullanim||[]).forEach(function(k){if(!pMap[k.urun_kodu])pMap[k.urun_kodu]=k.urun_adi;});});var prods=Object.keys(pMap);
    var dpMap={};prods.forEach(function(pk){dpMap[pk]={};});d.gunler.forEach(function(g){(g.kullanim||[]).forEach(function(k){dpMap[k.urun_kodu][g.ts]=(dpMap[k.urun_kodu][g.ts]||0)+k.miktar;});});
    var weeks={};d.gunler.forEach(function(g){var dt=new Date(g.ts),dow=dt.getDay()||7,pzt=new Date(dt);pzt.setDate(dt.getDate()-(dow-1));var k=pzt.toISOString().slice(0,10);if(!weeks[k])weeks[k]=[];weeks[k].push(g);});
    var wk=Object.keys(weeks).sort();
    var h='<div class="gantt-legend"><span><i class="gantt-dot" style="background:#FCA5A5"></i>Eksik</span><span><i class="gantt-dot" style="background:#BAE6FD"></i>Yeterli</span></div>';
    h+='<div class="gantt-wrap"><table class="gantt-table"><thead><tr class="gantt-week-header"><th class="gantt-th-kod gwh-name" colspan="4">&nbsp;</th>';
    wk.forEach(function(w){var c=weeks[w].length,f=weeks[w][0].t,l=weeks[w][weeks[w].length-1].t;h+='<th colspan="'+c+'">'+f+' – '+l+'</th>';});
    h+='</tr><tr class="gantt-day-header"><th class="gantt-th-kod">Kod</th><th class="gantt-th-adi">Adı</th><th class="gantt-th-stok">Stok</th><th class="gantt-th-bak">Bakiye</th>';
    d.gunler.forEach(function(g){h+='<th'+(g.ts===BUGUN?' class="gantt-today"':'')+'>'+g.t+'</th>';});
    h+='</tr></thead><tbody><tr class="gantt-ana-row"><td class="gantt-kod-col">'+d.kod+'</td><td class="gantt-adi-col">'+d.adi+'</td><td class="gantt-stok-col">'+d.stok.toLocaleString('tr-TR')+'</td><td class="gantt-bak-col'+(d.bas_bakiye<0?' gantt-bak-neg':' gantt-bak-pos')+'">'+d.bas_bakiye.toLocaleString('tr-TR')+'</td>';
    d.gunler.forEach(function(g){var c=g.ts===BUGUN?' gc-today':'';if(g.net_mat>0)h+='<td class="gantt-cell gc-red'+c+'"><span class="gantt-cell-val">'+g.net_mat.toLocaleString('tr-TR')+'</span>';else if(g.kullanim&&g.kullanim.length){h+='<td class="gantt-cell gc-green'+c+'"><span class="gantt-cell-val">✓</span>';}else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});
    h+='</tr>';
    prods.forEach(function(pk){h+='<tr class="gantt-mlz-row"><td class="gantt-kod-col">↳ '+pk+'</td><td class="gantt-adi-col">'+pMap[pk]+'</td><td class="gantt-stok-col" style="color:var(--m2)">—</td><td class="gantt-bak-col" style="color:var(--m2)">—</td>';d.gunler.forEach(function(g){var c=g.ts===BUGUN?' gc-today':'',m=dpMap[pk][g.ts]||0;if(m>0&&g.eksik)h+='<td class="gantt-cell gc-red-lite'+c+'"><span class="gantt-cell-val">'+m.toLocaleString('tr-TR',{maximumFractionDigits:1})+'</span>';else if(m>0)h+='<td class="gantt-cell gc-ok'+c+'"><span class="gantt-cell-val">'+m.toLocaleString('tr-TR',{maximumFractionDigits:1})+'</span>';else h+='<td class="gantt-cell gc-empty'+c+'">';h+='</td>';});h+='</tr>';});
    h+='</tbody></table></div>';
    return h;
  }

  // Click handlers
  $(document).on('click','td.has-gantt',function(e){
    var k=$(this).data('gantt-kod');if(!k||!mrpGanttData[k])return;
    openM('📈 Günlük Plan &nbsp;<span class="modal-badge" style="background:#EFF6FF;color:#1E40AF">'+k+'</span>',buildGantt(mrpGanttData[k]));
    e.stopPropagation();
  });
  $(document).on('click','td.has-sa',function(e){
    if($(this).hasClass('has-gantt'))return;
    var raw=$(this).attr('data-sa');if(!raw)return;
    try{var d=JSON.parse(raw);openM('🛒 Satınalma &nbsp;<span class="modal-badge" style="background:#DBEAFE;color:#1E40AF">'+d.kod+'</span>',buildSa(d));}catch(err){}
  });
  $(document).on('click','td.has-kullanim',function(){
    var raw=$(this).attr('data-kullanim');if(!raw)return;
    try{var d=JSON.parse(raw);var bg=d.tip==='Alt İhtiyaç 2'?'#D1FAE5':'#EDE9FE';var fg=d.tip==='Alt İhtiyaç 2'?'#065F46':'#5B21B6';openM('📋 Kullanım Detayı &nbsp;<span class="modal-badge" style="background:#F1F5F9;color:#334155">'+d.kod+'</span>&nbsp;<span class="modal-badge" style="background:'+bg+';color:'+fg+'">'+d.tip+'</span>',buildKullanim(d));}catch(err){}
  });
});
</script>
<?php endif; ?>
