<?php
ob_start();
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$yil = (int)($_GET['yil'] ?? date('Y'));

$default_dongu = [
    'K-550'                        => 4.5,
    'KOLİ'                         => 10,
    'MAVİ + PP SEPERATÖR + BOYALI' => 9.5,
    'MAVİ KASA'                    => 4.5,
    'MAVİ KASA + PP SEPERATÖR'     => 4.5,
];


// ── Türkiye resmi tatilleri (pazar + resmi tatil hariç) ──────────
function resmi_tatiller_kasa(int $yil): array {
    $t = [
        "$yil-01-01","$yil-04-23","$yil-05-01","$yil-05-19",
        "$yil-07-15","$yil-08-30","$yil-10-28","$yil-10-29",
    ];
    $ramazan = [
        2024=>'2024-04-10',2025=>'2025-03-30',
        2026=>'2026-03-20',2027=>'2027-03-09',
        2028=>'2028-02-26',2029=>'2029-02-14',
    ];
    $kurban = [
        2024=>'2024-06-16',2025=>'2025-06-06',
        2026=>'2026-05-26',2027=>'2027-05-16',
        2028=>'2028-05-04',2029=>'2029-04-23',
    ];
    if (isset($ramazan[$yil])) {
        $b = new DateTime($ramazan[$yil]);
        $t[] = (clone $b)->modify('-1 day')->format('Y-m-d');
        for ($i=0;$i<3;$i++) $t[] = (clone $b)->modify("+$i days")->format('Y-m-d');
    }
    if (isset($kurban[$yil])) {
        $b = new DateTime($kurban[$yil]);
        $t[] = (clone $b)->modify('-1 day')->format('Y-m-d');
        for ($i=0;$i<4;$i++) $t[] = (clone $b)->modify("+$i days")->format('Y-m-d');
    }
    return array_unique($t);
}

function kasa_calisma_gun(int $yil, int $ay, array $tatiller): int {
    $toplam = 0;
    $gs = cal_days_in_month(CAL_GREGORIAN, $ay, $yil);
    for ($g=1;$g<=$gs;$g++) {
        $tarih = sprintf('%04d-%02d-%02d',$yil,$ay,$g);
        $hg    = (int)(new DateTime($tarih))->format('N');
        if ($hg===7) continue; // Pazar
        if (!in_array($tarih,$tatiller)) $toplam++;
    }
    return $toplam;
}

$tatiller_kasa = resmi_tatiller_kasa($yil);
$cal_gun = [];
$tatil_gun = [];
for ($m=1;$m<=12;$m++) {
    $cal_gun[$m]  = kasa_calisma_gun($yil, $m, $tatiller_kasa);
    // Tatil sayısı bilgi amaçlı
    $gs = cal_days_in_month(CAL_GREGORIAN,$m,$yil);
    $pazar=0; $resmi=0;
    for($g=1;$g<=$gs;$g++){
        $tarih=sprintf('%04d-%02d-%02d',$yil,$m,$g);
        $hg=(int)(new DateTime($tarih))->format('N');
        if($hg===7){$pazar++;continue;}
        if(in_array($tarih,$tatiller_kasa)) $resmi++;
    }
    $tatil_gun[$m]=['pazar'=>$pazar,'resmi'=>$resmi];
}

$kasa_ihti = []; $fc_map = []; $kasa_tip_top = []; $hata = null;
$mavi_keys = ['MAVİ + PP SEPERATÖR + BOYALI','MAVİ KASA','MAVİ KASA + PP SEPERATÖR'];
$pp_keys   = ['MAVİ + PP SEPERATÖR + BOYALI','MAVİ KASA + PP SEPERATÖR'];

try {
    $db->exec("CREATE TABLE IF NOT EXISTS jit_dahil_kodlar2 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        stok_kodu VARCHAR(100) NOT NULL,
        kasa_tipi VARCHAR(200) DEFAULT '',
        paket_miktari DECIMAL(10,2) DEFAULT 1.00,
        notlar VARCHAR(255) DEFAULT NULL,
        guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_stok (stok_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

    $s = $db->prepare("SELECT stok_kodu,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12 FROM forecast WHERE yil=?");
    $s->execute([$yil]);
    foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $f) $fc_map[trim($f['stok_kodu'])] = $f;

    $kasa_rows = $db->query("SELECT stok_kodu, kasa_tipi, paket_miktari FROM jit_dahil_kodlar2 ORDER BY kasa_tipi, stok_kodu")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($kasa_rows as $kr) {
        $kod   = trim($kr['stok_kodu']);
        $paket = max(0.001, (float)($kr['paket_miktari'] ?: 1));
        $tip   = trim($kr['kasa_tipi'] ?: 'Belirsiz');
        $row   = ['stok_kodu'=>$kod,'kasa_tipi'=>$tip,'paket_miktari'=>$paket];
        $top   = 0;
        for ($m=1;$m<=12;$m++) {
            $fc  = isset($fc_map[$kod]['ay'.$m]) ? (float)$fc_map[$kod]['ay'.$m] : 0;
            $ih  = $fc / $paket;
            $row['ay'.$m] = $ih;
            $top += $ih;
        }
        $row['toplam'] = $top;
        $kasa_ihti[] = $row;
        if (!isset($kasa_tip_top[$tip]))
            $kasa_tip_top[$tip] = array_fill_keys(['ay1','ay2','ay3','ay4','ay5','ay6','ay7','ay8','ay9','ay10','ay11','ay12','toplam'], 0);
        for ($m=1;$m<=12;$m++) $kasa_tip_top[$tip]['ay'.$m] += $row['ay'.$m];
        $kasa_tip_top[$tip]['toplam'] += $top;
    }
    ksort($kasa_tip_top);
} catch(Throwable $e) { $hata = $e->getMessage(); }

$dongu = [];
foreach (array_keys($kasa_tip_top) as $tip) {
    $fk = 'dongu_' . preg_replace('/[^a-zA-Z0-9]/', '_', $tip);
    $dongu[$tip] = !empty($_POST[$fk]) ? max(0.1,(float)$_POST[$fk]) : ($default_dongu[$tip] ?? '');
}

// Tablo 4 hesapla
$t4=[]; $gt4=array_fill(1,12,0);
$t4_mavi=array_fill(1,12,0); $t4_pp=array_fill(1,12,0);
$t4_mavi_maks=0; $t4_pp_maks=0;
foreach ($kasa_tip_top as $tip=>$deger) {
    $dg = $dongu[$tip]!=='' ? (float)$dongu[$tip] : null;
    $row=[]; $ymaks=0;
    for ($m=1;$m<=12;$m++) {
        if ($dg&&$dg>0&&$deger['ay'.$m]>0) {
            $ds=$cal_gun[$m]/$dg; $net=(int)ceil($deger['ay'.$m]/$ds);
            $gt4[$m]+=$net; if($net>$ymaks)$ymaks=$net;
            if(in_array($tip,$mavi_keys))$t4_mavi[$m]+=$net;
            if(in_array($tip,$pp_keys))$t4_pp[$m]+=$net;
        } else { $net=null; }
        $row[$m]=$net;
    }
    $row['ymaks']=$ymaks; $t4[$tip]=$row;
}
for ($m=1;$m<=12;$m++){
    if($t4_mavi[$m]>$t4_mavi_maks)$t4_mavi_maks=$t4_mavi[$m];
    if($t4_pp[$m]>$t4_pp_maks)$t4_pp_maks=$t4_pp[$m];
}

$ay_tam=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
ob_end_clean();
?>
<style>
.kf-wrap *{box-sizing:border-box}
.kf-sec{background:#fff;border-radius:10px;box-shadow:0 1px 8px rgba(0,0,0,.07);padding:20px;margin-bottom:20px}
.kf-ttl{display:block;font-size:14px;font-weight:700;color:#2c3e50;margin-bottom:3px;border-left:4px solid #3498db;padding-left:10px}
.kf-ttl-o{border-left-color:#e67e22}.kf-ttl-g{border-left-color:#27ae60}.kf-ttl-p{border-left-color:#8e44ad}
.kf-sub{display:block;color:#7f8c8d;font-size:11px;margin-bottom:10px;padding-left:14px}
.kf-ab{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap;align-items:center}
.kf-bx{display:inline-flex;align-items:center;gap:4px;padding:5px 11px;border:none;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;color:#fff}
.kf-bx-ex{background:#1d6f42}.kf-bx-cp{background:#2980b9}.kf-bx-cp.ok{background:#27ae60}
.kf-tw{overflow-x:auto;border-radius:6px}
.kf-tw.sy{max-height:420px;overflow-y:auto}
.kf-tw.sy thead th{position:sticky;top:0;z-index:2}
.kf-t{border-collapse:collapse;width:100%;min-width:900px;font-size:11px}
.kf-t thead tr{background:#2c3e50;color:#fff}
.kf-t thead th{padding:7px 6px;text-align:center;font-weight:600;white-space:nowrap;border:1px solid #3d5166}
.kf-t tbody tr:nth-child(even){background:#f8f9fa}
.kf-t tbody tr:hover{background:#eaf4fb!important}
.kf-t tbody td{padding:5px 6px;border:1px solid #e0e0e0;text-align:right;vertical-align:middle}
.kf-t td.c{text-align:center}.kf-t td.l{text-align:left}
.kf-t tfoot tr{background:#2c3e50!important;color:#fff!important;font-weight:700}
.kf-t tfoot td{padding:7px 6px;border:1px solid #3d5166;text-align:right}
.kf-top{background:#eaf4fb!important;font-weight:700;color:#1a5276}
.kf-t tfoot .kf-top{background:#1a5276!important;color:#fff}
.kf-z{color:#ccc}
.kf-t.og thead tr{background:#e67e22!important}.kf-t.og thead th{border-color:#cf6d17!important}.kf-t.og tfoot tr{background:#cf6d17!important}
.kf-t.gn thead tr{background:#27ae60!important}.kf-t.gn thead th{border-color:#1e8449!important}.kf-t.gn tfoot tr{background:#1e8449!important}
.kf-t.pr thead tr{background:#8e44ad!important}.kf-t.pr thead th{border-color:#6c3483!important}.kf-t.pr tfoot tr{background:#6c3483!important}
.kf-fgrid{display:flex;flex-wrap:wrap;gap:14px;margin-top:10px}
.kf-fi{display:flex;flex-direction:column;gap:3px}
.kf-fi label{font-size:10px;font-weight:700;color:#444;text-transform:uppercase}
.kf-fi input{padding:5px 9px;border:2px solid #dce1e7;border-radius:6px;font-size:13px;width:120px;outline:none;transition:border-color .2s}
.kf-fi input:focus{border-color:#27ae60}
.kf-fn{font-size:10px;color:#27ae60;font-weight:600}
.kf-sbtn{padding:8px 24px;background:#27ae60;color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;margin-top:14px}
.kf-pills{display:flex;flex-wrap:wrap;gap:5px;margin-top:5px}
.kf-pill{background:#f0f2f5;border:1px solid #dce1e7;border-radius:20px;padding:2px 9px;font-size:11px;color:#555}
.kf-pill b{color:#27ae60}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1">
    <h1 class="s-bas">📦 Kasa Hesaplama</h1>
    <div class="s-yol">Planlama / <b>Kasa İhtiyacı <?php echo $yil;?></b></div>
  </div>
  <form method="GET" style="display:flex;gap:6px;align-items:center">
    <input type="hidden" name="sayfa" value="planlama-kasa-hesap">
    <select name="yil" class="form-alan" style="padding:5px 8px;font-size:12px;width:80px" onchange="this.form.submit()">
      <?php foreach(range(date('Y')-1,date('Y')+2) as $y):?>
      <option value="<?php echo $y;?>"<?php echo $y==$yil?' selected':'';?>><?php echo $y;?></option>
      <?php endforeach;?>
    </select>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kapasite" style="background:#7C3AED;color:#fff;padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none">📈 Forecast</a>
  </form>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px;border-radius:8px;margin-bottom:12px;font-size:12px">
  <b>Hata:</b> <?php echo htmlspecialchars($hata);?>
</div>
<?php endif;?>

<?php if(empty($kasa_rows??[])):?>
<div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:10px;padding:24px;text-align:center">
  <div style="font-size:32px;margin-bottom:8px">📦</div>
  <div style="font-weight:700;color:#92400E">jit_dahil_kodlar2 tablosu boş</div>
  <div style="font-size:12px;color:#78350F;margin-top:4px">Stok kodu → kasa tipi → paket miktarı eşlemesi bu tabloya girilmelidir.</div>
</div>
<?php else:?>
<div class="kf-wrap">

<!-- SEKME BARI -->
<div style="display:flex;gap:2px;border-bottom:2px solid #E2E8F0;margin-bottom:0;flex-wrap:wrap">
  <?php foreach([
    ['kt0','⚙️ Ayarlar'],
    ['kt3','📅 Döngü Sayısı'],
    ['kt4','📦 Net Kasa'],
    ['kt2','📊 Tip Toplamı'],
    ['kt1','🔍 Stok Detay'],
    ['kt5','🐛 Debug'],
  ] as $i=>[$id,$et]):?>
  <button id="btn-<?php echo $id;?>" onclick="ktSekme('<?php echo $id;?>')"
    style="padding:8px 16px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:600;cursor:pointer;transition:background .15s;
    <?php echo $i===0?'background:#27ae60;color:#fff':'background:#F1F5F9;color:#64748B';?>">
    <?php echo $et;?>
  </button>
  <?php endforeach;?>
</div>

<!-- kt0: FORM -->
<div id="kt0">
<div class="kf-sec">
  <span class="kf-ttl kf-ttl-g">⚙️ Döngü Günü Ayarları</span>
  <span class="kf-sub">Çalışma günü ÷ Döngü günü = Aylık döngü sayısı</span>
  <strong style="font-size:11px;color:#555"><?php echo $yil;?> — Aylık Çalışma Günleri (Pazar hariç):</strong>
  <div class="kf-pills">
    <?php foreach($ay_tam as $idx=>$ad):
      $m=$idx+1; $ti=$tatil_gun[$m];?>
    <span class="kf-pill"><?php echo $ad;?>: <b><?php echo $cal_gun[$m];?></b>
      <span style="color:#94A3B8;font-size:10px">(<?php echo $ti['pazar'];?>P<?php echo $ti['resmi']?'+'.$ti['resmi'].'R':'';?>)</span>
    </span>
    <?php endforeach;?>
  </div>
  <form method="POST" action="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kasa-hesap&yil=<?php echo $yil;?>">
    <div class="kf-fgrid">
      <?php foreach(array_keys($kasa_tip_top) as $tip):
        $fk = 'dongu_'.preg_replace('/[^a-zA-Z0-9]/','_',$tip);
        $dg = $dongu[$tip];
        $isdef = isset($default_dongu[$tip]);
      ?>
      <div class="kf-fi">
        <label><?php echo htmlspecialchars($tip);?></label>
        <input type="number" name="<?php echo $fk;?>" value="<?php echo $dg!==''?$dg:'';?>" placeholder="Gün" min="0.5" step="0.5">
        <?php if($dg!==''):
          $ornek=round($cal_gun[1]/(float)$dg,2);
        ?><span class="kf-fn">Oca: <?php echo $cal_gun[1];?> ÷ <?php echo $dg;?> = <?php echo $ornek;?> döngü</span><?php
        if($isdef):?><span style="font-size:10px;color:#999">★ Varsayılan</span><?php endif;?>
        <?php endif;?>
      </div>
      <?php endforeach;?>
    </div>
    <button type="submit" class="kf-sbtn">▶ Hesapla</button>
  </form>
</div>
</div><!-- /kt0 -->

<!-- kt3: TABLO 3 -->
<div id="kt3" style="display:none">
<div class="kf-sec">
  <span class="kf-ttl kf-ttl-g">Tablo 3 — Aylık Döngü Sayısı</span>
  <span class="kf-sub">Çalışma günü ÷ Döngü günü</span>
  <div class="kf-ab">
    <button class="kf-bx kf-bx-ex" onclick="kfXls('tbl3','Dongu_Sayisi')">📥 Excel</button>
    <button class="kf-bx kf-bx-cp" onclick="kfCopy('tbl3',this)">📋 Kopyala</button>
  </div>
  <div class="kf-tw"><table class="kf-t gn" id="tbl3">
    <thead><tr>
      <th>#</th><th>KASA TİPİ</th><th>DÖNGÜ GÜNÜ</th>
      <?php foreach($ay_tam as $idx=>$ad):?><th><?php echo $ad;?><br><small style="font-weight:400;opacity:.85">(<?php echo $cal_gun[$idx+1];?>g)</small></th><?php endforeach;?>
    </tr></thead>
    <tbody><?php $k=1; foreach($kasa_tip_top as $tip=>$deg):
      $dg=$dongu[$tip]!==''?(float)$dongu[$tip]:null;
    ?><tr>
      <td class="c"><?php echo $k++;?></td>
      <td class="l"><strong><?php echo htmlspecialchars($tip);?></strong></td>
      <td class="c"><?php echo $dg?$dg.' gün':'<span class="kf-z">—</span>';?></td>
      <?php for($m=1;$m<=12;$m++): $ds=($dg&&$dg>0)?round($cal_gun[$m]/$dg,2):null;?>
      <td class="c"><?php echo $ds!==null?'<strong>'.$ds.'</strong>':'<span class="kf-z">—</span>';?></td>
      <?php endfor;?>
    </tr><?php endforeach;?></tbody>
    <tfoot><tr><td colspan="3" class="c">Aylık Çalışma Günü</td>
    <?php for($m=1;$m<=12;$m++):?><td class="c"><?php echo $cal_gun[$m];?>g</td><?php endfor;?>
    </tr></tfoot>
  </table></div>
</div>
</div><!-- /kt3 -->

<!-- kt4: TABLO 4 -->
<div id="kt4" style="display:none">
<div class="kf-sec">
  <span class="kf-ttl kf-ttl-p">Tablo 4 — Net Kasa İhtiyacı (Elde Bulunması Gereken)</span>
  <span class="kf-sub">Aylık toplam kasa ihtiyacı ÷ Döngü sayısı = O ayda elde bulunması gereken net kasa adedi</span>
  <div class="kf-ab">
    <button class="kf-bx kf-bx-ex" onclick="kfXls('tbl4','Net_Kasa')">📥 Excel</button>
    <button class="kf-bx kf-bx-cp" onclick="kfCopy('tbl4',this)">📋 Kopyala</button>
  </div>
  <div class="kf-tw"><table class="kf-t pr" id="tbl4">
    <thead><tr>
      <th>#</th><th>KASA TİPİ</th><th>DÖNGÜ GÜNÜ</th>
      <?php foreach($ay_tam as $ad):?><th><?php echo $ad;?></th><?php endforeach;?>
      <th>YILLIK MAKS.</th>
    </tr></thead>
    <tbody>
    <?php $l=1; foreach($kasa_tip_top as $tip=>$deg):
      $dg=$dongu[$tip]!==''?(float)$dongu[$tip]:null;
    ?><tr>
      <td class="c"><?php echo $l++;?></td>
      <td class="l"><strong><?php echo htmlspecialchars($tip);?></strong></td>
      <td class="c"><?php echo $dg?$dg.' gün':'<span class="kf-z">—</span>';?></td>
      <?php for($m=1;$m<=12;$m++): $net=$t4[$tip][$m];?>
      <td style="<?php echo $net?'font-weight:600;color:#4a235a':'';?>"><?php echo $net!==null?number_format($net,0).' <small style="color:#999">ad.</small>':'<span class="kf-z">—</span>';?></td>
      <?php endfor;?>
      <td class="kf-top"><?php echo $t4[$tip]['ymaks']>0?number_format($t4[$tip]['ymaks'],0).' ad.':'—';?></td>
    </tr><?php endforeach;?>
    <tr style="background:#e8f8f5!important;border-top:2px solid #27ae60">
      <td class="c" style="color:#27ae60;font-weight:700">★</td>
      <td class="l" style="color:#27ae60;font-weight:700">TOPLAM MAVİ</td>
      <td class="c" style="color:#999;font-size:10px">—</td>
      <?php for($m=1;$m<=12;$m++): $v=$t4_mavi[$m];?>
      <td style="font-weight:700;color:#1a6644"><?php echo $v>0?number_format($v,0).' <small style="color:#999">ad.</small>':'—';?></td>
      <?php endfor;?>
      <td style="font-weight:700;color:#1a6644;background:#d5f5e3!important"><?php echo $t4_mavi_maks>0?number_format($t4_mavi_maks,0).' ad.':'—';?></td>
    </tr>
    <tr style="background:#eaf2ff!important;border-top:2px solid #2980b9">
      <td class="c" style="color:#2980b9;font-weight:700">★</td>
      <td class="l" style="color:#2980b9;font-weight:700">TOPLAM PP SEPERATÖR</td>
      <td class="c" style="color:#999;font-size:10px">—</td>
      <?php for($m=1;$m<=12;$m++): $v=$t4_pp[$m];?>
      <td style="font-weight:700;color:#1a4a7a"><?php echo $v>0?number_format($v,0).' <small style="color:#999">ad.</small>':'—';?></td>
      <?php endfor;?>
      <td style="font-weight:700;color:#1a4a7a;background:#d6eaf8!important"><?php echo $t4_pp_maks>0?number_format($t4_pp_maks,0).' ad.':'—';?></td>
    </tr>
    </tbody>
    <tfoot><tr><td colspan="3" class="c">TOPLAM NET İHTİYAÇ</td>
    <?php for($m=1;$m<=12;$m++):?><td><?php echo $gt4[$m]>0?number_format($gt4[$m],0):'—';?></td><?php endfor;?>
    <td class="kf-top">—</td></tr></tfoot>
  </table></div>
</div>
</div><!-- /kt4 -->

<!-- kt2: TABLO 2 -->
<?php
$t2_mavi=array_fill(1,12,0); $t2_mavi_t=0;
$t2_pp=array_fill(1,12,0);   $t2_pp_t=0;
$gt2=array_fill(1,12,0);     $gt2_t=0;
?>
<div id="kt2" style="display:none">
<div class="kf-sec">
  <span class="kf-ttl kf-ttl-o">Tablo 2 — Kasa Tipine Göre Toplam Aylık İhtiyaç</span>
  <span class="kf-sub">Her kasa tipinin tüm stok kodları toplanmış &nbsp;|&nbsp; <span style="background:#e67e22;color:#fff;border-radius:4px;padding:1px 7px;font-size:11px"><?php echo count($kasa_tip_top);?> kasa tipi</span></span>
  <div class="kf-ab">
    <button class="kf-bx kf-bx-ex" onclick="kfXls('tbl2','Kasa_Tipi_Toplam')">📥 Excel</button>
    <button class="kf-bx kf-bx-cp" onclick="kfCopy('tbl2',this)">📋 Kopyala</button>
  </div>
  <div class="kf-tw"><table class="kf-t og" id="tbl2">
    <thead><tr><th>#</th><th>KASA TİPİ</th><?php foreach($ay_tam as $ad):?><th><?php echo $ad;?></th><?php endforeach;?><th>TOPLAM</th></tr></thead>
    <tbody>
    <?php $j=1; foreach($kasa_tip_top as $tip=>$deg):?>
    <tr>
      <td class="c"><?php echo $j++;?></td>
      <td class="l"><strong><?php echo htmlspecialchars($tip);?></strong></td>
      <?php for($m=1;$m<=12;$m++):
        $v=$deg['ay'.$m]; $gt2[$m]+=$v;
        if(in_array($tip,$mavi_keys)){$t2_mavi[$m]+=$v;}
        if(in_array($tip,$pp_keys)){$t2_pp[$m]+=$v;}
      ?><td class="<?php echo $v==0?'kf-z':'';?>"><?php echo $v>0?round($v,2):'—';?></td>
      <?php endfor;
      $gt2_t+=$deg['toplam'];
      if(in_array($tip,$mavi_keys)) $t2_mavi_t+=$deg['toplam'];
      if(in_array($tip,$pp_keys))   $t2_pp_t+=$deg['toplam'];
      ?>
      <td class="kf-top"><?php echo round($deg['toplam'],2);?></td>
    </tr>
    <?php endforeach;?>
    <tr style="background:#e8f8f5!important;border-top:2px solid #27ae60">
      <td class="c" style="color:#27ae60;font-weight:700">★</td><td class="l" style="color:#27ae60;font-weight:700">TOPLAM MAVİ</td>
      <?php for($m=1;$m<=12;$m++): $v=$t2_mavi[$m];?><td style="font-weight:700;color:#1a6644"><?php echo $v>0?round($v,2):'—';?></td><?php endfor;?>
      <td style="font-weight:700;color:#1a6644;background:#d5f5e3!important"><?php echo round($t2_mavi_t,2);?></td>
    </tr>
    <tr style="background:#eaf2ff!important;border-top:2px solid #2980b9">
      <td class="c" style="color:#2980b9;font-weight:700">★</td><td class="l" style="color:#2980b9;font-weight:700">TOPLAM PP SEPERATÖR</td>
      <?php for($m=1;$m<=12;$m++): $v=$t2_pp[$m];?><td style="font-weight:700;color:#1a4a7a"><?php echo $v>0?round($v,2):'—';?></td><?php endfor;?>
      <td style="font-weight:700;color:#1a4a7a;background:#d6eaf8!important"><?php echo round($t2_pp_t,2);?></td>
    </tr>
    </tbody>
    <tfoot><tr><td colspan="2" class="c">GENEL TOPLAM</td>
    <?php for($m=1;$m<=12;$m++):?><td><?php echo round($gt2[$m],2);?></td><?php endfor;?>
    <td class="kf-top"><?php echo round($gt2_t,2);?></td></tr></tfoot>
  </table></div>
</div>
</div><!-- /kt2 -->

<!-- kt1: TABLO 1 -->
<?php
$kf = array_values(array_filter($kasa_ihti, fn($r)=>(float)$r['toplam']>0));
$gt1=array_fill(1,12,0); $gt1_t=0;
?>
<div id="kt1" style="display:none">
<div class="kf-sec">
  <span class="kf-ttl">Tablo 1 — Stok Koduna Göre Detaylı Kasa İhtiyacı</span>
  <span class="kf-sub">Forecast ÷ Paket miktarı &nbsp;|&nbsp; <span style="background:#3498db;color:#fff;border-radius:4px;padding:1px 7px;font-size:11px"><?php echo count($kf);?> kayıt</span></span>
  <div class="kf-ab">
    <button class="kf-bx kf-bx-ex" onclick="kfXls('tbl1','Stok_Detay')">📥 Excel</button>
    <button class="kf-bx kf-bx-cp" onclick="kfCopy('tbl1',this)">📋 Kopyala</button>
  </div>
  <div class="kf-tw sy"><table class="kf-t" id="tbl1">
    <thead><tr><th>#</th><th>STOK KODU</th><th>KASA TİPİ</th><th>PAKET MİKT.</th><?php foreach($ay_tam as $ad):?><th><?php echo $ad;?></th><?php endforeach;?><th>TOPLAM</th></tr></thead>
    <tbody>
    <?php $i=1; foreach($kf as $kr):?>
    <tr>
      <td class="c"><?php echo $i++;?></td>
      <td class="c" style="font-weight:700"><?php echo htmlspecialchars($kr['stok_kodu']);?></td>
      <td class="l"><?php echo htmlspecialchars($kr['kasa_tipi']);?></td>
      <td class="c"><?php echo $kr['paket_miktari'];?></td>
      <?php for($m=1;$m<=12;$m++): $v=$kr['ay'.$m]; $gt1[$m]+=$v;?><td class="<?php echo $v==0?'kf-z':'';?>"><?php echo $v>0?round($v,2):'—';?></td><?php endfor;
      $gt1_t+=$kr['toplam'];?>
      <td class="kf-top"><?php echo round($kr['toplam'],2);?></td>
    </tr>
    <?php endforeach;?>
    </tbody>
    <tfoot><tr><td colspan="4" class="c">GENEL TOPLAM</td><?php for($m=1;$m<=12;$m++):?><td><?php echo round($gt1[$m],2);?></td><?php endfor;?><td class="kf-top"><?php echo round($gt1_t,2);?></td></tr></tfoot>
  </table></div>
</div>
</div><!-- /kt1 -->

<!-- kt5: DEBUG -->
<div id="kt5" style="display:none">
<div class="kf-sec">
  <span class="kf-ttl">🐛 Debug — Veri Kontrolü</span>
  <span class="kf-sub">Forecast eşleşmeleri, eksik/sıfır veriler, kasa tipi özeti</span>
</div>

<!-- Özet kartlar -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
  <?php
  $fc_eslesen  = 0; $fc_yok = 0; $sifir_toplam = 0;
  foreach($kasa_ihti as $r) {
    if((float)$r['toplam']>0) $fc_eslesen++;
    else $sifir_toplam++;
    if(!isset($fc_map[$r['stok_kodu']])) $fc_yok++;
  }
  foreach([
    ['📦','Toplam kayıt',count($kasa_ihti),'#EFF6FF','#1E40AF'],
    ['✅','Forecast eşleşen',$fc_eslesen,'#F0FDF4','#065F46'],
    ['⚠️','Forecast yok',$fc_yok,'#FFF7ED','#92400E'],
    ['🔲','Sıfır toplam',$sifir_toplam,'#F1F5F9','#64748B'],
    ['📊','Kasa tipi',count($kasa_tip_top),'#F3E8FF','#6B21A8'],
  ] as [$i,$e,$d,$bg,$fg]):?>
  <div style="background:<?php echo $bg;?>;border:1px solid <?php echo $fg;?>33;border-radius:8px;padding:7px 14px;min-width:110px">
    <div style="font-size:10px;color:<?php echo $fg;?>"><?php echo $i.' '.$e;?></div>
    <div style="font-size:17px;font-weight:800;color:<?php echo $fg;?>"><?php echo $d;?></div>
  </div>
  <?php endforeach;?>
</div>

<!-- Kasa tipi özeti -->
<div class="kf-sec" style="margin-bottom:12px">
  <strong style="font-size:12px;color:#2c3e50">Kasa Tipi Özeti</strong>
  <div style="overflow-x:auto;margin-top:8px">
  <table style="border-collapse:collapse;font-size:11px;width:100%">
    <thead><tr style="background:#1E3A5F;color:#e0f0ff">
      <th style="padding:5px 8px;border:1px solid #2d5986;text-align:left">Kasa Tipi</th>
      <th style="padding:5px 8px;border:1px solid #2d5986">Kayıt</th>
      <th style="padding:5px 8px;border:1px solid #2d5986">Forecast>0</th>
      <th style="padding:5px 8px;border:1px solid #2d5986">Döngü Günü</th>
      <th style="padding:5px 8px;border:1px solid #2d5986">Yıllık Toplam Kasa</th>
    </tr></thead>
    <tbody>
    <?php foreach($kasa_tip_top as $tip=>$deg):
      $tip_kayit = count(array_filter($kasa_ihti, fn($r)=>$r['kasa_tipi']===$tip));
      $tip_fc_pos = count(array_filter($kasa_ihti, fn($r)=>$r['kasa_tipi']===$tip&&(float)$r['toplam']>0));
      $dg = $dongu[$tip]!=='' ? $dongu[$tip] : '—';
    ?>
    <tr style="<?php echo $tip_fc_pos===0?'background:#FEF2F2':'';?>">
      <td style="padding:4px 8px;border:1px solid #E5E7EB;font-weight:700"><?php echo htmlspecialchars($tip);?></td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center"><?php echo $tip_kayit;?></td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center;color:<?php echo $tip_fc_pos>0?'#065F46':'#DC2626';?>;font-weight:700"><?php echo $tip_fc_pos;?></td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center"><?php echo $dg;?></td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:right;font-weight:700"><?php echo number_format($deg['toplam'],2);?></td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>

<!-- Stok detay debug tablosu -->
<div class="kf-sec">
  <strong style="font-size:12px;color:#2c3e50">Stok Kodu Eşleşme Durumu</strong>
  <div style="display:flex;gap:6px;margin:6px 0 8px;font-size:11px">
    <span style="background:#DCFCE7;color:#166534;padding:1px 8px;border-radius:4px">✅ Forecast var, >0</span>
    <span style="background:#FEF9C3;color:#854D0E;padding:1px 8px;border-radius:4px">⚠️ Forecast var, =0</span>
    <span style="background:#FEE2E2;color:#991B1B;padding:1px 8px;border-radius:4px">❌ Forecast yok</span>
  </div>
  <div style="overflow-x:auto;max-height:420px;overflow-y:auto">
  <table style="border-collapse:collapse;font-size:11px;width:100%;white-space:nowrap">
    <thead style="position:sticky;top:0;z-index:2">
    <tr style="background:#0F172A;color:#93C5FD">
      <th style="padding:5px 8px;border:1px solid #1E293B;text-align:left">Stok Kodu</th>
      <th style="padding:5px 8px;border:1px solid #1E293B;text-align:left">Kasa Tipi</th>
      <th style="padding:5px 8px;border:1px solid #1E293B">Paket Mikt.</th>
      <th style="padding:5px 8px;border:1px solid #1E293B">Forecast</th>
      <th style="padding:5px 8px;border:1px solid #1E293B">Yıllık Top.</th>
      <?php for($m=1;$m<=12;$m++) echo '<th style="padding:5px 4px;border:1px solid #1E293B">'.$ay_tam[$m-1].'</th>';?>
    </tr>
    </thead>
    <tbody>
    <?php foreach($kasa_ihti as $r):
      $fc_var = isset($fc_map[$r['stok_kodu']]);
      $top_p  = (float)$r['toplam'];
      if(!$fc_var) $bg='background:#1A0000';
      elseif($top_p==0) $bg='background:#1A1500';
      else $bg='';
    ?>
    <tr style="<?php echo $bg;?>">
      <td style="padding:3px 8px;border:1px solid #1E293B;color:#86EFAC;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']);?></td>
      <td style="padding:3px 8px;border:1px solid #1E293B;color:#CBD5E1"><?php echo htmlspecialchars($r['kasa_tipi']);?></td>
      <td style="padding:3px 8px;border:1px solid #1E293B;text-align:center;color:#E2E8F0"><?php echo $r['paket_miktari'];?></td>
      <td style="padding:3px 8px;border:1px solid #1E293B;text-align:center">
        <?php if(!$fc_var): ?><span style="color:#FCA5A5">❌ YOK</span>
        <?php elseif($top_p==0): ?><span style="color:#FCD34D">⚠️ =0</span>
        <?php else: ?><span style="color:#86EFAC">✅</span><?php endif;?>
      </td>
      <td style="padding:3px 8px;border:1px solid #1E293B;text-align:right;color:#FCD34D;font-weight:700"><?php echo number_format($top_p,2);?></td>
      <?php for($m=1;$m<=12;$m++): $v=(float)$r['ay'.$m];?>
      <td style="padding:3px 4px;border:1px solid #1E293B;text-align:right;color:<?php echo $v>0?'#E2E8F0':'#374151';?>"><?php echo $v>0?round($v,2):'·';?></td>
      <?php endfor;?>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div><!-- kf-sec son -->
</div><!-- /kt5 -->

</div><!-- .kf-wrap -->
<?php endif;?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
function ktSekme(id) {
  ['kt0','kt1','kt2','kt3','kt4','kt5'].forEach(function(t) {
    var el = document.getElementById(t);
    if(el) el.style.display = t===id ? '' : 'none';
    var btn = document.getElementById('btn-'+t);
    if(btn) {
      if(t===id) { btn.style.background='#27ae60'; btn.style.color='#fff'; }
      else       { btn.style.background='#F1F5F9'; btn.style.color='#64748B'; }
    }
  });
}
function kfXls(tid,fn){
  var t=document.getElementById(tid); if(!t)return;
  var wb=XLSX.utils.book_new(), ws=XLSX.utils.table_to_sheet(t);
  var r=XLSX.utils.decode_range(ws['!ref']), cols=[];
  for(var c=r.s.c;c<=r.e.c;c++) cols.push({wch:c<=1?6:c==2?26:12});
  ws['!cols']=cols;
  XLSX.utils.book_append_sheet(wb,ws,fn.substring(0,31));
  XLSX.writeFile(wb,fn+'_<?php echo $yil;?>_'+new Date().toISOString().slice(0,10)+'.xlsx');
}
function kfCopy(tid,btn){
  var rows=document.getElementById(tid).querySelectorAll('tr'), text='';
  rows.forEach(function(r){
    var cells=r.querySelectorAll('th,td'), line=[];
    cells.forEach(function(c){line.push(c.innerText.replace(/\n/g,' ').trim());});
    text+=line.join('\t')+'\n';
  });
  navigator.clipboard.writeText(text).then(function(){
    btn.textContent='✅ Kopyalandı!'; btn.classList.add('ok');
    setTimeout(function(){btn.textContent='📋 Kopyala'; btn.classList.remove('ok');},2000);
  }).catch(function(){
    var ta=document.createElement('textarea'); ta.value=text;
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
    btn.textContent='✅ Kopyalandı!'; btn.classList.add('ok');
    setTimeout(function(){btn.textContent='📋 Kopyala'; btn.classList.remove('ok');},2000);
  });
}
</script>
