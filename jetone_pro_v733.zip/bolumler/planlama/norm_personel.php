<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);

// ── Montaj hatları tanımları ─────────────────────────────────────
$assembly_lines = [
    'EL İŞÇİLİĞİ 1'  => ['name'=>'EL İŞÇİLİĞİ1-ABX',          'working_hours'=>21,'norm_personnel'=>4],
    'EL İŞÇİLİĞİ 2'  => ['name'=>'EL İŞÇİLİĞİ 2-GOLDMASTER',  'working_hours'=>7, 'norm_personnel'=>6],
    'EL İŞÇİLİĞİ 3'  => ['name'=>'EL İŞÇİLİĞİ 3-ESANJÖR',     'working_hours'=>7, 'norm_personnel'=>2],
    'EL İŞÇİLİĞİ 4'  => ['name'=>'EL İŞÇİLİĞİ 4-Ei',          'working_hours'=>7, 'norm_personnel'=>2],
    'EL İŞÇİLİĞİ 5'  => ['name'=>'EL İŞÇİLİĞİ 5-BX',          'working_hours'=>21,'norm_personnel'=>3],
    'EL İŞÇİLİĞİ 6'  => ['name'=>'EL İŞÇİLİĞİ 6-TKM',         'working_hours'=>7, 'norm_personnel'=>7],
    'EL İŞÇİLİĞİ 7'  => ['name'=>'EL İŞÇİLİĞİ 7-TKM ŞASE',   'working_hours'=>7, 'norm_personnel'=>9],
    'EL İŞÇİLİĞİ 8'  => ['name'=>'EL İŞÇİLİĞİ 8-BSH',         'working_hours'=>7, 'norm_personnel'=>6],
    'EL İŞÇİLİĞİ 9'  => ['name'=>'EL İŞÇİLİĞİ 9-ABM KKLI',   'working_hours'=>21,'norm_personnel'=>6],
    'EL İŞÇİLİĞİ 10' => ['name'=>'EL İŞÇİLİĞİ 10-ABM KKSIZ', 'working_hours'=>21,'norm_personnel'=>6],
    'MT-01'           => ['name'=>'Montaj',                      'working_hours'=>21,'norm_personnel'=>1],
    'SR-01'           => ['name'=>'Serigrafi',                   'working_hours'=>7, 'norm_personnel'=>2],
    'FSN-01'          => ['name'=>'Fason/Rework',                'working_hours'=>7, 'norm_personnel'=>1],
    'KRM-01'          => ['name'=>'Kırma',                       'working_hours'=>7, 'norm_personnel'=>1],
    'TERM-01'         => ['name'=>'Termoform',                   'working_hours'=>7, 'norm_personnel'=>1],
];
$makine_haric   = ['EN-421-01','FASON'];
$assembly_haric = ['TERM-01','KRM-01','EL İŞÇİLİĞİ 2','EL İŞÇİLİĞİ 4'];
$ay_adlari = [1=>'Ocak',2=>'Şubat',3=>'Mart',4=>'Nisan',5=>'Mayıs',6=>'Haziran',
              7=>'Temmuz',8=>'Ağustos',9=>'Eylül',10=>'Ekim',11=>'Kasım',12=>'Aralık'];

// ── Hat atamaları DB'den ─────────────────────────────────────────
$hat_atamalari = [];
try {
    $ha=$db->query("SELECT stok_kodu,ist_kodu,ist_turu FROM norm_hat_atamalari");
    foreach($ha->fetchAll(PDO::FETCH_ASSOC) as $r)
        $hat_atamalari[trim($r['stok_kodu'])]=['ist_kodu'=>$r['ist_kodu'],'ist_turu'=>$r['ist_turu']];
} catch(Throwable $e){}

// ── GET parametreleri ────────────────────────────────────────────
$sel_ay     = max(1,min(12,(int)($_GET['month'] ?? date('n'))));
$sel_yil    = (int)($_GET['year']  ?? date('Y'));
$other_hrs  = max(1, (int)($_GET['other_hours'] ?? 21));
$verim      = max(50,min(100,(int)($_GET['verim'] ?? 93)));
$verim_k    = $verim/100;
$dir_kadro  = max(0,(int)($_GET['direkt_kadro'] ?? 136));
$devamsiz   = max(0,(int)($_GET['devamsizlik']  ?? 12));
$dogum      = max(0,(int)($_GET['dogum_izni']   ?? 3));
$malzemeci  = max(0,(int)($_GET['malzemeci']    ?? 6));
$analiz     = isset($_GET['analiz_yap']);

// ── Kalan çalışma günü ──────────────────────────────────────────
$ay_bas  = sprintf('%04d-%02d-01',$sel_yil,$sel_ay);
$ay_bit  = date('Y-m-t',strtotime($ay_bas));
$bugun   = new DateTime(); $bugun->setTime(0,0,0);
$ay_ilk  = new DateTime($ay_bas);
$ay_son  = new DateTime($ay_bit);
$hesap_bas = ($bugun>=$ay_ilk&&$bugun<=$ay_son) ? clone $bugun : clone $ay_ilk;
$kcg = 0; $dt=clone $hesap_bas;
while($dt<=$ay_son){ if($dt->format('N')!=7) $kcg++; $dt->modify('+1 day'); }
if(isset($_GET['is_gunu'])&&(int)$_GET['is_gunu']>0) $kcg=max(1,(int)$_GET['is_gunu']);

// ── Tiger istasyonları ───────────────────────────────────────────
$tum_ist=[];
if($tiger_ok){try{
    $w=$tigerdb_pdo->query("SELECT WRK.CODE KOD,WRK.NAME AD,COUNT(DISTINCT OPR.LOGICALREF) OP_SAYISI
        FROM dbo.LG_222_WORKSTAT WRK LEFT JOIN dbo.LG_222_OPRTREQ OPR ON OPR.WSREF=WRK.LOGICALREF
        WHERE WRK.ACTIVE=0 GROUP BY WRK.CODE,WRK.NAME ORDER BY WRK.CODE");
    foreach($w->fetchAll(PDO::FETCH_ASSOC) as $r) $tum_ist[trim($r['KOD'])]=['ad'=>$r['AD'],'op'=>(int)$r['OP_SAYISI']];
}catch(Throwable $e){}}

// ── ANALİZ ──────────────────────────────────────────────────────
$sonuc_satirlari=$makine_satirlari=$urun_listesi=[];
$ist_yukleri=$mak_yukleri=[];
$ist_detay=$mak_detay=[];
$hatalar=[];

if($analiz && $tiger_ok){
    // 1. Siparişler
    $siparisler=[];
    try{
        $s=$db->prepare("SELECT s.sip_kodu, MAX(s.sip_baslik) stok_adi,
            SUM(s.sip_miktar-s.sip_sevk_miktari) kalan
            FROM siparis s WHERE s.sip_statu='Aktif'
            AND (s.sip_miktar-s.sip_sevk_miktari)>0
            GROUP BY s.sip_kodu HAVING kalan>0 ORDER BY s.sip_kodu");
        $s->execute([]);
        foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r)
            $siparisler[trim($r['sip_kodu'])]=['stok_adi'=>$r['stok_adi'],'kalan'=>(float)$r['kalan']];
    }catch(Throwable $e){$hatalar[]='Sipariş: '.$e->getMessage();}

    // 2. BOM
    $bom_map=[];
    try{
        $b=$tigerdb_pdo->query("SELECT URUN.CODE Urun, MLZ.CODE Malzeme, MLZ.NAME MalzAdi,
            MLZ.STGRPCODE Grup, BL.AMOUNT Miktar
            FROM dbo.LG_222_BOMLINE BL LEFT JOIN dbo.LG_222_BOMREVSN BR ON BL.BOMREVREF=BR.LOGICALREF
            LEFT JOIN dbo.LG_222_BOMASTER BM ON BR.BOMMASTERREF=BM.LOGICALREF
            LEFT JOIN dbo.LG_222_ITEMS URUN ON BM.MAINPRODREF=URUN.LOGICALREF
            LEFT JOIN dbo.LG_222_ITEMS MLZ ON BL.ITEMREF=MLZ.LOGICALREF
            WHERE BL.LINETYPE=0 AND BM.ACTIVE=0 AND URUN.ACTIVE=0 AND MLZ.ACTIVE=0");
        foreach($b->fetchAll(PDO::FETCH_ASSOC) as $r)
            $bom_map[$r['Urun']][]=['kod'=>$r['Malzeme'],'adi'=>$r['MalzAdi'],'grup'=>$r['Grup'],'birim'=>(float)$r['Miktar']];
    }catch(Throwable $e){$hatalar[]='BOM: '.$e->getMessage();}

    // 3. Stok
    $stok_map=[];
    try{
        $st=$tigerdb_pdo->query("SELECT IT.CODE Kod, IT.NAME Adi, IT.STGRPCODE Grup,
            ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) Stok
            FROM dbo.LG_222_ITEMS IT
            LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
            LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
            AND CAP.FIRMNR=222 AND LV.INVENNO IN(0,1,5,2,3,4,98)
            AND IT.STGRPCODE IN('Mamül','Yarımamül')
            GROUP BY IT.CODE,IT.NAME,IT.LOGICALREF,IT.STGRPCODE");
        foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r)
            $stok_map[$r['Kod']]=['adi'=>$r['Adi'],'grup'=>$r['Grup'],'stok'=>(float)$r['Stok']];
    }catch(Throwable $e){$hatalar[]='Stok: '.$e->getMessage();}

    // 4. Operasyonlar
    $ops=[];
    try{
        $o=$tigerdb_pdo->query("SELECT IT.CODE MKOD, WRK.CODE WKOD, WRK.NAME WADI,
            dbo.LG_INTTOTIME2(OPR.RUNTIME) CEVRIM,
            ISNULL(NULLIF(OPR.BATCHQUANTITY,0),1) PARTI
            FROM dbo.LG_222_OPRTREQ OPR
            LEFT JOIN dbo.LG_222_OPERTION OP ON OP.LOGICALREF=OPR.OPERATIONREF
            LEFT JOIN dbo.LG_222_WORKSTAT WRK ON WRK.LOGICALREF=OPR.WSREF
            LEFT JOIN dbo.LG_222_RTNGLINE RTL ON RTL.OPERATIONREF=OP.LOGICALREF
            LEFT JOIN dbo.LG_222_ROUTING RT ON RT.LOGICALREF=RTL.ROUTINGREF
            LEFT JOIN dbo.LG_222_BOMREVSN BMR ON BMR.ROUTINGREF=RT.LOGICALREF
            LEFT JOIN dbo.LG_222_BOMASTER BOM ON BOM.LOGICALREF=BMR.BOMMASTERREF
            LEFT JOIN dbo.LG_222_BOMLINE BML ON BMR.LOGICALREF=BML.BOMREVREF
            LEFT JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=BOM.MAINPRODREF
            WHERE OP.CODE<>'SKOP.001' AND IT.CODE IS NOT NULL AND IT.CODE NOT LIKE 'H-%'
            AND WRK.CODE IS NOT NULL AND BML.LINETYPE<>4 AND OPR.RUNTIME>0
            GROUP BY IT.CODE,WRK.CODE,WRK.NAME,OPR.RUNTIME,OPR.BATCHQUANTITY
            ORDER BY IT.CODE DESC,WRK.CODE DESC");
        foreach($o->fetchAll(PDO::FETCH_ASSOC) as $r){
            $k=trim($r['MKOD']); $w=trim($r['WKOD']);
            if(!isset($ops[$k][$w]))
                $ops[$k][$w]=['adi'=>trim($r['WADI']),'cevrim'=>(float)$r['CEVRIM'],'parti'=>max(1,(float)$r['PARTI'])];
        }
    }catch(Throwable $e){$hatalar[]='Operasyon: '.$e->getMessage();}

    // 5. Net ihtiyaç
    $net_map=[];
    foreach($siparisler as $kod=>$sip){
        $stok=$stok_map[$kod]['stok']??0;
        $net=max(0,$sip['kalan']-$stok);
        $net_map[$kod]=['stok_adi'=>$stok_map[$kod]['adi']??$sip['stok_adi'],'grup'=>$stok_map[$kod]['grup']??'','stok'=>$stok,'kalan'=>$sip['kalan'],'net'=>$net];
    }
    // BOM patlatma
    $alt_map=[];
    foreach($net_map as $urun=>$v){
        if($v['net']<=0||empty($bom_map[$urun])) continue;
        foreach($bom_map[$urun] as $m){
            $mk=$m['kod'];
            if(!isset($alt_map[$mk])) $alt_map[$mk]=['stok_adi'=>$stok_map[$mk]['adi']??$m['adi'],'grup'=>$stok_map[$mk]['grup']??$m['grup'],'stok'=>$stok_map[$mk]['stok']??0,'kalan'=>0,'net'=>0];
            $alt_map[$mk]['kalan']+=$v['net']*$m['birim'];
        }
    }
    foreach($alt_map as &$r2) $r2['net']=max(0,$r2['kalan']-$r2['stok']); unset($r2);

    $tum_net=[];
    $mamul_gruplari=['mamül','mamul','yarımamül','yarimamul'];
    // array_merge yerine + kullan — numeric string key'ler korunur
    $birlesik = $net_map + $alt_map;
    foreach($birlesik as $kod=>$v){
        if(!in_array(strtolower(trim($v['grup'])),$mamul_gruplari)||$v['net']<=0) continue;
        if(isset($tum_net[$kod])){ $tum_net[$kod]['kalan']+=$v['kalan']; $tum_net[$kod]['net']+=$v['net']; }
        else $tum_net[$kod]=$v;
    }

    // 6. Yük atama
    $asm_order=array_values(array_filter(array_keys($assembly_lines),fn($k)=>!in_array($k,$assembly_haric)));
    $ist_kap=[];
    foreach($asm_order as $k) $ist_kap[$k]=$kcg*$assembly_lines[$k]['working_hours'];
    $mak_kap=[];

    foreach($tum_net as $kod=>$bilgi){
        if($bilgi['net']<=0||empty($ops[$kod])) continue;
        $urun_asm=[];$urun_mak=[];
        foreach($ops[$kod] as $ist=>$op){
            $idx=array_search($ist,$asm_order);
            if($idx!==false) $urun_asm[$idx]=['ist'=>$ist,'op'=>$op];
            else $urun_mak[]=['ist'=>$ist,'op'=>$op];
        }
        ksort($urun_asm); $urun_asm=array_values($urun_asm);

        // Assembly
        if(!empty($urun_asm)){
            $tum_asm_kodlar=array_column($urun_asm,'ist');
            $db_asm=$hat_atamalari[$kod]['ist_kodu']??null;
            if($hat_atamalari[$kod]['ist_turu']??''!=='assembly') $db_asm=null;
            if($db_asm!==null){
                $op_k=null; foreach($urun_asm as $ua) if($ua['ist']===$db_asm){$op_k=$ua['op'];break;}
                if(!$op_k) $op_k=$urun_asm[0]['op'];
                $saat=$bilgi['net']*($op_k['cevrim']/$op_k['parti'])/3600;
                $vs=$saat/$verim_k;
                $ist_yukleri[$db_asm]=($ist_yukleri[$db_asm]??0)+$vs;
                $ist_kap[$db_asm]=max(0,($ist_kap[$db_asm]??0)-$vs);
                $ist_detay[$db_asm][]=['kod'=>$kod,'stok_adi'=>$bilgi['stok_adi'],'net'=>$bilgi['net'],
                    'cevrim'=>$op_k['cevrim'],'parti'=>$op_k['parti'],'saat'=>$saat,'vs'=>$vs,
                    'atanan'=>$db_asm,'db_atama'=>$db_asm,'tum'=>$tum_asm_kodlar,'tip'=>'assembly','sira'=>1,'toplam'=>count($urun_asm)];
            } else {
                for($si=0;$si<count($urun_asm);$si++){
                    $hi=$urun_asm[$si]['ist']; $ho=$urun_asm[$si]['op'];
                    $saat=$bilgi['net']*($ho['cevrim']/$ho['parti'])/3600;
                    $vs=$saat/$verim_k;
                    if(($ist_kap[$hi]??0)>=$vs||$si===count($urun_asm)-1){
                        $ist_yukleri[$hi]=($ist_yukleri[$hi]??0)+$vs;
                        $ist_kap[$hi]=max(0,($ist_kap[$hi]??0)-$vs);
                        $ist_detay[$hi][]=['kod'=>$kod,'stok_adi'=>$bilgi['stok_adi'],'net'=>$bilgi['net'],
                            'cevrim'=>$ho['cevrim'],'parti'=>$ho['parti'],'saat'=>$saat,'vs'=>$vs,
                            'atanan'=>$hi,'db_atama'=>null,'tum'=>$tum_asm_kodlar,'tip'=>'assembly','sira'=>$si+1,'toplam'=>count($urun_asm)];
                        break;
                    }
                }
            }
        }

        // Makine
        if(!empty($urun_mak)){
            usort($urun_mak,fn($a,$b)=>strcmp($a['ist'],$b['ist']));
            $urun_mak=array_values(array_filter($urun_mak,fn($u)=>!in_array($u['ist'],$makine_haric)));
            if(empty($urun_mak)) continue;
            $tum_mak=array_column($urun_mak,'ist');
            $db_mak=$hat_atamalari[$kod]['ist_kodu']??null;
            if(($hat_atamalari[$kod]['ist_turu']??'')!=='makine') $db_mak=null;
            if($db_mak!==null){
                $op_k=null; foreach($urun_mak as $um) if($um['ist']===$db_mak){$op_k=$um['op'];break;}
                if(!$op_k) $op_k=$urun_mak[0]['op'];
                $saat=$bilgi['net']*($op_k['cevrim']/$op_k['parti'])/3600;
                $vs=$saat/$verim_k;
                if(!isset($mak_kap[$db_mak])) $mak_kap[$db_mak]=$kcg*$other_hrs;
                $mak_yukleri[$db_mak]=($mak_yukleri[$db_mak]??0)+$vs;
                $mak_kap[$db_mak]=max(0,$mak_kap[$db_mak]-$vs);
                $mak_detay[$db_mak][]=['kod'=>$kod,'stok_adi'=>$bilgi['stok_adi'],'net'=>$bilgi['net'],
                    'cevrim'=>$op_k['cevrim'],'parti'=>$op_k['parti'],'saat'=>$saat,'vs'=>$vs,
                    'atanan'=>$db_mak,'db_atama'=>$db_mak,'tum'=>$tum_mak,'tip'=>'makine','sira'=>1,'toplam'=>count($urun_mak)];
            } else {
                for($mi=0;$mi<count($urun_mak);$mi++){
                    $hi=$urun_mak[$mi]['ist']; $ho=$urun_mak[$mi]['op'];
                    $saat=$bilgi['net']*($ho['cevrim']/$ho['parti'])/3600;
                    $vs=$saat/$verim_k;
                    if(!isset($mak_kap[$hi])) $mak_kap[$hi]=$kcg*$other_hrs;
                    if($mak_kap[$hi]>=$vs||$mi===count($urun_mak)-1){
                        $mak_yukleri[$hi]=($mak_yukleri[$hi]??0)+$vs;
                        $mak_kap[$hi]=max(0,$mak_kap[$hi]-$vs);
                        $mak_detay[$hi][]=['kod'=>$kod,'stok_adi'=>$bilgi['stok_adi'],'net'=>$bilgi['net'],
                            'cevrim'=>$ho['cevrim'],'parti'=>$ho['parti'],'saat'=>$saat,'vs'=>$vs,
                            'atanan'=>$hi,'db_atama'=>null,'tum'=>$tum_mak,'tip'=>'makine','sira'=>$mi+1,'toplam'=>count($urun_mak)];
                        break;
                    }
                }
            }
        }
    }

    // 7. Sonuç satırları — Assembly
    foreach($asm_order as $ik){
        if(in_array($ik,$assembly_haric)) continue;
        $al=$assembly_lines[$ik];
        $toplam_yuk=$ist_yukleri[$ik]??0;
        $norm_p=$al['norm_personnel'];
        $hat_kap=$kcg*$al['working_hours'];
        $kisi_basi=$norm_p>0?$toplam_yuk/$norm_p:0;
        $doluluk=$hat_kap>0?($kisi_basi/$hat_kap)*100:0;
        $gerekli=$hat_kap>0?$toplam_yuk/$hat_kap:0;
        $net_p=$kcg>0?($kisi_basi*$norm_p)/($kcg*7):0;
        $sonuc_satirlari[]=compact('ik')+['ist_adi'=>$al['name'],'ghr'=>$al['working_hours'],
            'norm_p'=>$norm_p,'toplam_yuk'=>$toplam_yuk,'kisi_basi'=>$kisi_basi,
            'hat_kap'=>$hat_kap,'doluluk'=>$doluluk,'gerekli'=>$gerekli,'net_p'=>$net_p,
            'tasma'=>max(0,$kisi_basi-$hat_kap)];
    }

    // 8. Makine istasyonları
    $mak_sira=['EN-110-01','EN-132-01','EN-80-01','EN-130-01','EN-160-01','EN-201-01','EN-202-01',
        'EN-301-01','EN-302-01','EN-350-01','EN-420-01','EN-500-01','EN-650-01','EN-162-01',
        'EN-131-01','EN-161-01','EN-530-01','EN-650-02','EN-450-01','EN-500-02','EN-260-01',
        'EN-410-01','EN-500-03','EN-700-01','EN-180-01','EN-280-01','EN-650-03','EN-650-04',
        'EN-650-05','EN-650-06','EN-850-01','EN-850-02'];
    $mak_idx=array_flip($mak_sira);
    $mak_kap2=$kcg*$other_hrs;
    $norm_kad=$other_hrs<=8?1:($other_hrs<=16?2:3);
    foreach($tum_ist as $ik=>$ibi){
        if(array_key_exists($ik,$assembly_lines)||in_array($ik,$makine_haric)) continue;
        $yuk=$mak_yukleri[$ik]??0;
        $dol=$mak_kap2>0?($yuk/$mak_kap2)*100:0;
        $grl=$mak_kap2>0?$yuk/$mak_kap2:0;
        $makine_satirlari[]=['ik'=>$ik,'ist_adi'=>$ibi['ad'],'ghr'=>$other_hrs,'norm_kad'=>$norm_kad,
            'yuk'=>$yuk,'kap'=>$mak_kap2,'doluluk'=>$dol,'gerekli'=>$grl,'net_p'=>$grl*$norm_kad];
    }
    usort($makine_satirlari,fn($a,$b)=>($mak_idx[$a['ik']]??9999)<=>($mak_idx[$b['ik']]??9999)?:strcmp($a['ik'],$b['ik']));

    // 9. Ürün listesi
    foreach(array_merge($ist_detay,$mak_detay) as $detaylar)
        foreach($detaylar as $d) $urun_listesi[]=$d;
    usort($urun_listesi,fn($a,$b)=>$b['vs']<=>$a['vs']);
}

// Hesaplanan toplamlar
$t_mont_net=array_sum(array_column($sonuc_satirlari,'net_p'));
$t_mak_net=array_sum(array_column($makine_satirlari,'net_p'));
$t_net=$t_mont_net+$t_mak_net;
$genel_top=$t_net+$devamsiz+$dogum+$malzemeci;
$fark=$genel_top-$dir_kadro;
?>
<style>
.np-tbl{width:100%;border-collapse:collapse;font-size:12px}
.np-tbl th{background:#1E3A5F !important;color:#fff !important;padding:7px 10px;white-space:nowrap;border:1px solid #2d5986}
.np-tbl td{padding:6px 10px;border:1px solid #E2E8F0;white-space:nowrap}
.np-tbl tbody tr:hover td{background:#F8FAFC}
.np-bar-wrap{height:18px;background:#E2E8F0;border-radius:5px;overflow:hidden;min-width:100px}
.np-bar-fill{height:100%;border-radius:5px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:10px;font-weight:700;transition:width .3s}
.np-ok{background:#D1FAE5;color:#065F46;border-radius:4px;padding:2px 7px;font-size:10px;font-weight:700}
.np-sin{background:#FEF9C3;color:#854D0E;border-radius:4px;padding:2px 7px;font-size:10px;font-weight:700}
.np-asi{background:#FEE2E2;color:#991B1B;border-radius:4px;padding:2px 7px;font-size:10px;font-weight:700}
.np-bos{background:#F1F5F9;color:#64748B;border-radius:4px;padding:2px 7px;font-size:10px}
.dt-btn{border:none;background:transparent;cursor:pointer;color:#94A3B8;padding:2px 6px;border-radius:3px;font-size:11px}
.dt-btn:hover{background:#EDE9FE;color:#667EEA}
.detail-row td{border-top:none!important;background:#F8F7FF!important}
.np-ozet-tbl{border-collapse:collapse;font-size:12px;min-width:200px}
.np-ozet-tbl td{padding:4px 12px;border:1px solid rgba(0,0,0,.1)}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">👥 Norm Personel Durumu</h1>
    <div class="s-yol">Planlama / Norm / <b>Personel Analizi</b> · <?php echo $ay_adlari[$sel_ay].' '.$sel_yil;?>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Hata mesajları -->
<?php foreach($hatalar as $h):?>
<div style="background:#FEE2E2;color:#991B1B;padding:8px 12px;border-radius:6px;font-size:11px;margin-bottom:6px">⚠️ <?php echo htmlspecialchars($h);?></div>
<?php endforeach;?>

<?php if($analiz && $tiger_ok):?>
<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:8px 14px;margin-bottom:10px;font-size:11px;display:flex;gap:16px;flex-wrap:wrap">
  <span>📦 Sipariş: <strong><?php echo count($siparisler??[]);?></strong></span>
  <span>🏗 BOM ürün: <strong><?php echo count($bom_map??[]);?></strong></span>
  <span>📊 Stok: <strong><?php echo count($stok_map??[]);?></strong></span>
  <span>⚙️ Operasyon: <strong><?php echo count($ops??[]);?></strong></span>
  <span>🎯 Net ihtiyaç: <strong><?php echo count($tum_net??[]);?></strong></span>
  <?php
  // Kaç net ihtiyaç ürünü için operasyon var?
  $ops_eslesme = 0; $ops_yok = [];
  foreach(($tum_net??[]) as $k=>$v) {
      if(!empty($ops[$k])) $ops_eslesme++;
      else $ops_yok[] = $k;
  }
  ?>
  <span style="color:#16A34A">✅ Ops eşleşen: <strong><?php echo $ops_eslesme;?></strong></span>
  <span style="color:#DC2626">❌ Ops yok: <strong><?php echo count($ops_yok);?></strong>
    <?php if(!empty($ops_yok)): ?>
    <span style="font-size:10px;color:#64748B">(<?php echo implode(', ', array_slice($ops_yok,0,5));?>...)</span>
    <?php endif;?>
  </span>
  <?php if($ops_eslesme>0): ?>
  <?php
  // İlk eşleşen ürünün assembly/makine dağılımı
  $ornek_kod = null; foreach(($tum_net??[]) as $k=>$v) { if(!empty($ops[$k])){$ornek_kod=$k;break;} }
  if($ornek_kod) {
      $asm_c=0;$mak_c=0;
      foreach($ops[$ornek_kod] as $ist=>$op) {
          if(array_search($ist,$asm_order)!==false) $asm_c++; else $mak_c++;
      }
      echo "<span>Örnek ($ornek_kod): <strong>{$asm_c} asm / {$mak_c} mak ist.</strong></span>";
  }
  ?>
  <?php endif;?>
</div>
<?php endif;?>

<!-- ── FORM ─────────────────────────────────────────────────────── -->
<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="GET" action="<?php echo BASE_URL;?>/panel.php" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <input type="hidden" name="sayfa" value="planlama-norm-personel">
    <div>
      <label class="form-etiket">Ay</label>
      <select name="month" class="form-alan" style="width:110px">
        <?php for($m=1;$m<=12;$m++) echo "<option value='$m'".($m==$sel_ay?' selected':'').">{$ay_adlari[$m]}</option>";?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Yıl</label>
      <select name="year" class="form-alan" style="width:80px">
        <?php for($y=date('Y')-1;$y<=date('Y')+2;$y++) echo "<option value='$y'".($y==$sel_yil?' selected':'').">$y</option>";?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Kalan İş Günü</label>
      <input type="number" name="is_gunu" class="form-alan" value="<?php echo $kcg;?>" min="1" max="31" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Diğer İst. Gün. Saat</label>
      <input type="number" name="other_hours" class="form-alan" value="<?php echo $other_hrs;?>" min="1" max="24" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Verimlilik %</label>
      <input type="number" name="verim" class="form-alan" value="<?php echo $verim;?>" min="50" max="100" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Devamsızlık (kişi)</label>
      <input type="number" name="devamsizlik" class="form-alan" value="<?php echo $devamsiz;?>" min="0" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Doğum İzni (kişi)</label>
      <input type="number" name="dogum_izni" class="form-alan" value="<?php echo $dogum;?>" min="0" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Malzemeci (kişi)</label>
      <input type="number" name="malzemeci" class="form-alan" value="<?php echo $malzemeci;?>" min="0" style="width:65px">
    </div>
    <div>
      <label class="form-etiket">Direkt Kadro (kişi)</label>
      <input type="number" name="direkt_kadro" class="form-alan" value="<?php echo $dir_kadro;?>" min="0" style="width:75px">
    </div>
    <button type="submit" name="analiz_yap" value="1"
      style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      📊 Analiz Et
    </button>
  </form>
</div>

<?php if(!$analiz):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">👥</div>
  <div style="font-weight:600">Parametreleri ayarlayıp "Analiz Et" butonuna basın.</div>
</div>
<?php elseif(empty($sonuc_satirlari)):?>
<div style="background:#FEF9C3;padding:20px;border-radius:10px;color:#92400E;font-weight:600">⚠️ <?php echo $ay_adlari[$sel_ay].' '.$sel_yil;?> için sipariş bulunamadı veya hesaplama yapılamadı.</div>
<?php else:?>

<!-- ── ÖZET TABLOLAR ─────────────────────────────────────────────── -->
<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px">

  <table class="np-ozet-tbl">
    <tr style="background:#16A34A"><td colspan="2" style="padding:6px 12px;color:#fff;font-weight:700;font-size:12px">GENEL TOPLAM</td></tr>
    <tr style="background:#4ADE80"><td style="font-weight:700;color:#14532D">ENJEKSİYON</td><td style="font-weight:700;color:#14532D;text-align:right"><?php echo number_format($t_mak_net,1,',','.');?></td></tr>
    <tr style="background:#86EFAC"><td style="color:#14532D">MONTAJ</td><td style="color:#14532D;text-align:right"><?php echo number_format($t_mont_net,1,',','.');?></td></tr>
    <?php if($devamsiz):?><tr><td style="color:#374151">DEVAMSIZLIK</td><td style="text-align:right"><?php echo $devamsiz;?></td></tr><?php endif;?>
    <?php if($dogum):?><tr><td style="color:#374151">DOĞUM İZNİ</td><td style="text-align:right"><?php echo $dogum;?></td></tr><?php endif;?>
    <?php if($malzemeci):?><tr><td style="color:#374151">MALZEMECİ</td><td style="text-align:right"><?php echo $malzemeci;?></td></tr><?php endif;?>
    <tr style="background:#16A34A"><td style="color:#fff;font-weight:700">GENEL TOPLAM</td><td style="color:#fff;font-weight:700;text-align:right"><?php echo number_format($genel_top,1,',','.');?></td></tr>
  </table>

  <table class="np-ozet-tbl">
    <tr style="background:#1E3A5F"><td colspan="2" style="padding:6px 12px;color:#fff;font-weight:700;font-size:12px">DEVAMSIZLIK DAHİL DURUM</td></tr>
    <tr style="background:#1E4976"><td style="color:#BFDBFE;font-weight:700">DİREKT KADRO</td><td style="color:#fff;text-align:right;font-weight:700"><?php echo $dir_kadro?:'-';?></td></tr>
    <tr style="background:#1E5A8A"><td style="color:#BFDBFE">İHTİYAÇ</td><td style="color:#fff;text-align:right"><?php echo number_format($genel_top,1,',','.');?></td></tr>
    <?php $fark_bg=$fark<0?'#FEE2E2':($fark==0?'#D1FAE5':'#FEF9C3');
    $fark_c=$fark<0?'#DC2626':($fark==0?'#16A34A':'#D97706');?>
    <tr style="background:<?php echo $fark_bg;?>">
      <td style="font-weight:700;color:<?php echo $fark_c;?>">FARK</td>
      <td style="font-weight:700;color:<?php echo $fark_c;?>;text-align:right">
        <?php echo $dir_kadro?($fark>0?'+':'').number_format($fark,1,',','.'):'-';?>
      </td>
    </tr>
  </table>

  <div style="display:flex;gap:6px;align-items:flex-start;flex-wrap:wrap">
    <?php
    $ozetler=[
      ['Montaj',count($sonuc_satirlari),count(array_filter($sonuc_satirlari,fn($r)=>$r['doluluk']>0)),count(array_filter($sonuc_satirlari,fn($r)=>$r['doluluk']>100)),'#4F46E5'],
      ['Makine',count($makine_satirlari),count(array_filter($makine_satirlari,fn($r)=>$r['yuk']>0)),count(array_filter($makine_satirlari,fn($r)=>$r['doluluk']>100)),'#475569'],
    ];
    foreach($ozetler as [$lbl,$top,$akt,$asi,$bg]):?>
    <table class="np-ozet-tbl">
      <tr style="background:<?php echo $bg;?>"><td colspan="2" style="padding:6px 12px;color:#fff;font-weight:700;font-size:12px"><?php echo strtoupper($lbl);?> İSTASYON</td></tr>
      <tr><td style="color:#374151">Toplam</td><td style="text-align:right;font-weight:700"><?php echo $top;?></td></tr>
      <tr><td style="color:#374151">Aktif</td><td style="text-align:right;font-weight:700;color:#16A34A"><?php echo $akt;?></td></tr>
      <tr><td style="color:#374151">Kapasite Aşan</td><td style="text-align:right;font-weight:700;color:#DC2626"><?php echo $asi;?></td></tr>
    </table>
    <?php endforeach;?>
  </div>
</div>

<!-- ── MONTAJ TABLO ──────────────────────────────────────────────── -->
<div style="font-size:12px;font-weight:700;color:#1E3A5F;margin-bottom:6px">🏭 Montaj Hatları — Personel & Doluluk Analizi</div>
<div class="kart" style="overflow:hidden;padding:0;margin-bottom:14px">
<div style="padding:8px 12px;background:#F8F7FF;border-bottom:1px solid #E2E8F0">
  <input type="text" id="srcAsm" oninput="npFilter('srcAsm','tblAsm')" placeholder="İstasyon ara..."
    style="width:100%;max-width:300px;padding:5px 10px;border:1px solid #C4B5FD;border-radius:6px;font-size:12px;outline:none">
</div>
<div style="overflow-x:auto">
<table class="np-tbl" id="tblAsm">
  <thead><tr>
    <th style="width:28px"></th><th>#</th><th>İstasyon</th><th>Adı</th>
    <th style="text-align:center">Gün.Saat</th><th style="text-align:center">Norm P.</th>
    <th style="text-align:right">Top.Yük (sa)</th><th style="text-align:right">Kişi Başı (sa)</th>
    <th style="text-align:right">Hat Kap. (sa)</th><th style="text-align:right">Net Personel</th>
    <th style="text-align:center">Gerekli Kişi</th><th style="min-width:140px">Doluluk</th>
    <th style="text-align:center">Durum</th><th style="text-align:right">Taşma (sa)</th>
  </tr></thead>
  <tfoot><tr><th colspan="14" id="tblAsmCount" style="text-align:left;font-size:11px;font-weight:400;color:rgba(255,255,255,.8)"></th></tr></tfoot>
  <tbody>
  <?php foreach($sonuc_satirlari as $i=>$r):
    $p=$r['doluluk'];
    if($p<=0){$bc='#94A3B8';$dc='np-bos';$dt='BOŞ';}
    elseif($p<=70){$bc='#22C55E';$dc='np-ok';$dt='YETERLİ';}
    elseif($p<=100){$bc='#F59E0B';$dc='np-sin';$dt='SINIRDA';}
    else{$bc='#EF4444';$dc='np-asi';$dt='AŞILDI';}
    $bw=min($p,100);
    $rdet=$ist_detay[$r['ik']]??[];
  ?>
  <tr class="np-ana-satir">
    <td style="text-align:center;padding:4px">
      <?php if(!empty($rdet)):?>
      <button class="dt-btn" onclick="npToggle('npd-asm-<?php echo $i;?>',this)">▶</button>
      <?php else:?><span style="color:#E2E8F0;font-size:11px">—</span><?php endif;?>
    </td>
    <td style="color:#94A3B8;font-size:11px"><?php echo $i+1;?></td>
    <td><code style="font-size:11px"><?php echo htmlspecialchars($r['ik']);?></code></td>
    <td style="font-weight:600;color:#1E293B"><?php echo htmlspecialchars($r['ist_adi']);?></td>
    <td style="text-align:center"><span style="background:#E0F2FE;color:#0369A1;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700"><?php echo $r['ghr'];?>h</span></td>
    <td style="text-align:center"><span style="background:#DBEAFE;color:#1E40AF;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700"><?php echo $r['norm_p'];?> kişi</span></td>
    <td style="text-align:right;font-weight:700;color:#7C3AED"><?php echo number_format($r['toplam_yuk'],1,',','.');?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format($r['kisi_basi'],1,',','.');?></td>
    <td style="text-align:right;color:#475569"><?php echo number_format($r['hat_kap'],0,',','.');?></td>
    <td style="text-align:right">
      <strong style="color:<?php echo $r['net_p']>$r['norm_p']?'#DC2626':'#16A34A';?>"><?php echo number_format($r['net_p'],1,',','.');?></strong>
      <span style="color:#94A3B8;font-size:10px"> kişi</span>
    </td>
    <td style="text-align:center">
      <strong style="color:<?php echo $r['gerekli']>$r['norm_p']?'#DC2626':'#16A34A';?>"><?php echo number_format($r['gerekli'],1,',','.');?></strong>
      <span style="color:#94A3B8;font-size:10px"> kişi</span>
    </td>
    <td>
      <div class="np-bar-wrap">
        <div class="np-bar-fill" style="width:<?php echo $bw;?>%;background:<?php echo $bc;?>">
          <?php if($p>=8) echo number_format($p,0).'%';?>
        </div>
      </div>
      <?php if($p>100):?><small style="color:#DC2626;font-size:10px">+<?php echo number_format($p-100,0);?>% taşma</small><?php endif;?>
    </td>
    <td style="text-align:center"><span class="<?php echo $dc;?>"><?php echo $dt;?></span></td>
    <td style="text-align:right">
      <?php if($r['tasma']>0):?>
      <span style="background:#FEF9C3;color:#92400E;border-radius:3px;padding:2px 6px;font-size:10px;font-weight:700">
        +<?php echo number_format($r['tasma'],1,',','.');?>
      </span>
      <?php else:?><span style="color:#CBD5E1">—</span><?php endif;?>
    </td>
  </tr>
  <?php if(!empty($rdet)):?>
  <tr class="detail-row" id="npd-asm-<?php echo $i;?>" style="display:none">
    <td colspan="14" style="padding:8px 16px 12px 40px">
      <div style="font-size:11px;font-weight:700;color:#7C3AED;margin-bottom:6px"><?php echo htmlspecialchars($r['ist_adi']);?> — <?php echo count($rdet);?> ürün</div>
      <table style="width:100%;font-size:11px;border-collapse:collapse">
        <thead><tr style="background:#EDE9FE">
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD">#</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD">Ürün Kodu</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD">Ürün Adı</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:right">Net Miktar</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:right">Çevrim (sn)</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:right">Parti</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:right">Net Saat</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:right">Verimli Saat</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:center">Sıra/DB</th>
          <th style="padding:4px 8px;color:#5B21B6;border:1px solid #C4B5FD;text-align:center">Hat Ata</th>
        </tr></thead>
        <tbody>
        <?php foreach($rdet as $di=>$d):?>
        <tr style="background:<?php echo $d['db_atama']?'#F0FDF4':($d['sira']>1?'#FFFBEB':'#FFF');?>">
          <td style="padding:3px 8px;color:#94A3B8;border-bottom:1px solid #F1F5F9"><?php echo $di+1;?></td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9"><code style="font-size:10px"><?php echo htmlspecialchars($d['kod']);?></code></td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9;color:#334155"><?php echo htmlspecialchars($d['stok_adi']);?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;font-weight:600"><?php echo number_format($d['net'],0,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#475569"><?php echo number_format($d['cevrim'],1,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#475569"><?php echo number_format($d['parti'],0,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#7C3AED"><?php echo number_format($d['saat'],2,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;font-weight:700;color:#0F766E"><?php echo number_format($d['vs'],2,',','.');?></td>
          <td style="padding:3px 8px;text-align:center;border-bottom:1px solid #F1F5F9">
            <span style="background:#E0E7FF;color:#3730A3;border-radius:3px;padding:1px 5px;font-size:10px"><?php echo $d['sira'];?>/<?php echo $d['toplam'];?></span>
            <?php if($d['db_atama']):?><span style="background:#D1FAE5;color:#065F46;border-radius:3px;padding:1px 5px;font-size:9px;margin-left:2px">DB</span><?php endif;?>
          </td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9">
            <div style="display:flex;gap:4px">
              <select class="np-hat-sel" data-kod="<?php echo htmlspecialchars($d['kod']);?>" data-tip="assembly"
                style="font-size:10px;padding:2px 4px;border:1px solid #C4B5FD;border-radius:4px;flex:1;min-width:120px">
                <?php foreach($d['tum'] as $opt) echo "<option value='".htmlspecialchars($opt)."'".($opt===$d['atanan']?' selected':'').">".htmlspecialchars($opt)."</option>";?>
              </select>
              <button onclick="npHatKaydet(this)" style="font-size:10px;padding:2px 8px;background:#7C3AED;color:#fff;border:none;border-radius:4px;cursor:pointer">💾</button>
              <?php if($d['db_atama']):?><button onclick="npHatSifirla('<?php echo htmlspecialchars($d['kod']);?>',this)" style="font-size:10px;padding:2px 6px;background:#F1F5F9;border:1px solid #E2E8F0;color:#64748B;border-radius:4px;cursor:pointer" title="DB atamasını sil">↩</button><?php endif;?>
            </div>
            <div class="np-hat-msg" style="font-size:9px;margin-top:2px;display:none"></div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </td>
  </tr>
  <?php endif;?>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<!-- ── MAKİNE TABLO ──────────────────────────────────────────────── -->
<?php if(!empty($makine_satirlari)):?>
<div style="font-size:12px;font-weight:700;color:#475569;margin-bottom:6px">⚙️ Makine İstasyonları</div>
<div class="kart" style="overflow:hidden;padding:0;margin-bottom:14px">
<div style="padding:8px 12px;background:#F8FAFC;border-bottom:1px solid #E2E8F0">
  <input type="text" id="srcMak" oninput="npFilter('srcMak','tblMak')" placeholder="İstasyon ara..."
    style="width:100%;max-width:300px;padding:5px 10px;border:1px solid #94A3B8;border-radius:6px;font-size:12px;outline:none">
</div>
<div style="overflow-x:auto">
<table class="np-tbl" id="tblMak">
  <thead><tr>
    <th style="width:28px"></th><th>#</th><th>İstasyon</th><th>Adı</th>
    <th style="text-align:center">Gün.Saat</th><th style="text-align:center">Norm Kad.</th>
    <th style="text-align:right">Yük (sa)</th><th style="text-align:right">Kapasite (sa)</th>
    <th style="text-align:right">Net Personel</th><th style="min-width:120px">Doluluk</th>
    <th style="text-align:center">Durum</th>
  </tr></thead>
  <tfoot><tr><th colspan="11"></th></tr></tfoot>
  <tbody>
  <?php foreach($makine_satirlari as $mi=>$mr):
    $mp=$mr['doluluk'];
    if($mp<=70){$mc='#22C55E';$mdc='np-ok';$mdt='YETERLİ';}
    elseif($mp<=100){$mc='#F59E0B';$mdc='np-sin';$mdt='SINIRDA';}
    else{$mc='#EF4444';$mdc='np-asi';$mdt='AŞILDI';}
    $mw=min($mp,100);
    $mrdet=$mak_detay[$mr['ik']]??[];
  ?>
  <tr>
    <td style="text-align:center;padding:4px">
      <?php if(!empty($mrdet)):?><button class="dt-btn" onclick="npToggle('npd-mak-<?php echo $mi;?>',this)">▶</button>
      <?php else:?><span style="color:#E2E8F0;font-size:11px">—</span><?php endif;?>
    </td>
    <td style="color:#94A3B8;font-size:11px"><?php echo $mi+1;?></td>
    <td><code style="font-size:11px"><?php echo htmlspecialchars($mr['ik']);?></code></td>
    <td style="font-weight:600;color:#1E293B"><?php echo htmlspecialchars($mr['ist_adi']);?></td>
    <td style="text-align:center"><span style="background:#E0F2FE;color:#0369A1;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700"><?php echo $mr['ghr'];?>h</span></td>
    <td style="text-align:center"><span style="background:#DBEAFE;color:#1E40AF;border-radius:3px;padding:1px 6px;font-size:10px;font-weight:700"><?php echo $mr['norm_kad'];?> kişi</span></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format($mr['yuk'],1,',','.');?></td>
    <td style="text-align:right;color:#475569"><?php echo number_format($mr['kap'],0,',','.');?></td>
    <td style="text-align:right">
      <strong style="color:<?php echo $mr['net_p']>$mr['norm_kad']?'#DC2626':'#16A34A';?>"><?php echo number_format($mr['net_p'],1,',','.');?></strong>
      <span style="color:#94A3B8;font-size:10px"> kişi</span>
    </td>
    <td><div class="np-bar-wrap"><div class="np-bar-fill" style="width:<?php echo $mw;?>%;background:<?php echo $mc;?>"><?php if($mp>=8) echo number_format($mp,0).'%';?></div></div>
      <?php if($mp>100):?><small style="color:#DC2626;font-size:10px">+<?php echo number_format($mp-100,0);?>% taşma</small><?php endif;?>
    </td>
    <td style="text-align:center"><span class="<?php echo $mdc;?>"><?php echo $mdt;?></span></td>
  </tr>
  <?php if(!empty($mrdet)):?>
  <tr class="detail-row" id="npd-mak-<?php echo $mi;?>" style="display:none">
    <td colspan="11" style="padding:8px 16px 12px 40px">
      <div style="font-size:11px;font-weight:700;color:#475569;margin-bottom:6px"><?php echo htmlspecialchars($mr['ist_adi']);?> — <?php echo count($mrdet);?> ürün</div>
      <table style="width:100%;font-size:11px;border-collapse:collapse">
        <thead><tr style="background:#F1F5F9">
          <?php foreach(['#','Ürün Kodu','Ürün Adı','Net Miktar','Çevrim (sn)','Parti','Net Saat','Verimli Saat','Sıra','Hat Ata'] as $h)
            echo "<th style='padding:4px 8px;color:#334155;border:1px solid #CBD5E1'>".htmlspecialchars($h)."</th>";?>
        </tr></thead>
        <tbody>
        <?php foreach($mrdet as $mdi=>$md2):?>
        <tr style="background:<?php echo $md2['db_atama']?'#F0FDF4':'#FFF';?>">
          <td style="padding:3px 8px;color:#94A3B8;border-bottom:1px solid #F1F5F9"><?php echo $mdi+1;?></td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9"><code style="font-size:10px"><?php echo htmlspecialchars($md2['kod']);?></code></td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9;color:#334155"><?php echo htmlspecialchars($md2['stok_adi']);?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;font-weight:600"><?php echo number_format($md2['net'],0,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#475569"><?php echo number_format($md2['cevrim'],1,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#475569"><?php echo number_format($md2['parti'],0,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;color:#7C3AED"><?php echo number_format($md2['saat'],2,',','.');?></td>
          <td style="padding:3px 8px;text-align:right;border-bottom:1px solid #F1F5F9;font-weight:700;color:#0F766E"><?php echo number_format($md2['vs'],2,',','.');?></td>
          <td style="padding:3px 8px;text-align:center;border-bottom:1px solid #F1F5F9">
            <span style="background:#E0E7FF;color:#3730A3;border-radius:3px;padding:1px 5px;font-size:10px"><?php echo $md2['sira'];?>/<?php echo $md2['toplam'];?></span>
            <?php if($md2['db_atama']):?><span style="background:#D1FAE5;color:#065F46;border-radius:3px;padding:1px 5px;font-size:9px;margin-left:2px">DB</span><?php endif;?>
          </td>
          <td style="padding:3px 8px;border-bottom:1px solid #F1F5F9">
            <div style="display:flex;gap:4px">
              <select class="np-hat-sel" data-kod="<?php echo htmlspecialchars($md2['kod']);?>" data-tip="makine"
                style="font-size:10px;padding:2px 4px;border:1px solid #94A3B8;border-radius:4px;flex:1;min-width:120px">
                <?php foreach($md2['tum'] as $opt) echo "<option value='".htmlspecialchars($opt)."'".($opt===$md2['atanan']?' selected':'').">".htmlspecialchars($opt)."</option>";?>
              </select>
              <button onclick="npHatKaydet(this)" style="font-size:10px;padding:2px 8px;background:#475569;color:#fff;border:none;border-radius:4px;cursor:pointer">💾</button>
              <?php if($md2['db_atama']):?><button onclick="npHatSifirla('<?php echo htmlspecialchars($md2['kod']);?>',this)" style="font-size:10px;padding:2px 6px;background:#F1F5F9;border:1px solid #E2E8F0;color:#64748B;border-radius:4px;cursor:pointer">↩</button><?php endif;?>
            </div>
            <div class="np-hat-msg" style="font-size:9px;margin-top:2px;display:none"></div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </td>
  </tr>
  <?php endif;?>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<?php endif;?>

<!-- ── ÜRÜN LİSTESİ ─────────────────────────────────────────────── -->
<?php if(!empty($urun_listesi)):?>
<div style="font-size:12px;font-weight:700;color:#0F766E;margin-bottom:6px">📦 Tüm Ürünler — Hat Atamaları (<?php echo count($urun_listesi);?> kalem)</div>
<div class="kart" style="overflow:hidden;padding:0;margin-bottom:14px">
<div style="padding:8px 12px;background:#F0FDF9;border-bottom:1px solid #E2E8F0">
  <input type="text" id="srcUrun" oninput="npFilter('srcUrun','tblUrun')" placeholder="Ürün kodu veya adı ara..."
    style="width:100%;max-width:300px;padding:5px 10px;border:1px solid #99F6E4;border-radius:6px;font-size:12px;outline:none">
</div>
<div style="overflow-x:auto">
<table class="np-tbl" id="tblUrun">
  <thead><tr style="background:#0F766E">
    <th>#</th><th>Ürün Kodu</th><th>Ürün Adı</th>
    <th style="text-align:right">Net Miktar</th><th style="text-align:right">Çevrim (sn)</th>
    <th style="text-align:right">Net Saat</th><th style="text-align:right">Verimli Saat</th>
    <th style="text-align:center">Tip</th><th style="text-align:center">Atanan Hat</th>
    <th style="text-align:center;min-width:240px">Hat Değiştir</th>
  </tr></thead>
  <tfoot><tr><th colspan="10"></th></tr></tfoot>
  <tbody>
  <?php foreach($urun_listesi as $ui=>$u):
    $utip=$u['tip']??'assembly';
    $tbg=$utip==='assembly'?'#EDE9FE':'#E0F2FE';
    $tc=$utip==='assembly'?'#5B21B6':'#0369A1';
    $tt=$utip==='assembly'?'Montaj':'Makine';
  ?>
  <tr style="background:<?php echo $u['db_atama']?'#F0FDF4':'#FFF';?>">
    <td style="color:#94A3B8;font-size:11px"><?php echo $ui+1;?></td>
    <td><code style="font-size:11px"><?php echo htmlspecialchars($u['kod']);?></code></td>
    <td style="color:#334155"><?php echo htmlspecialchars($u['stok_adi']);?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format($u['net'],0,',','.');?></td>
    <td style="text-align:right;color:#475569"><?php echo number_format($u['cevrim'],1,',','.');?></td>
    <td style="text-align:right;color:#0F766E"><?php echo number_format($u['saat'],2,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:#0F766E"><?php echo number_format($u['vs'],2,',','.');?></td>
    <td style="text-align:center"><span style="background:<?php echo $tbg;?>;color:<?php echo $tc;?>;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700"><?php echo $tt;?></span></td>
    <td style="text-align:center">
      <span style="background:#F1F5F9;color:#1E293B;border-radius:3px;padding:1px 7px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($u['atanan']);?></span>
      <?php if($u['db_atama']):?><span style="background:#D1FAE5;color:#065F46;border-radius:3px;padding:1px 5px;font-size:9px;margin-left:2px">DB</span><?php endif;?>
    </td>
    <td style="padding:4px 8px">
      <div style="display:flex;gap:4px;align-items:center">
        <select class="np-hat-sel" data-kod="<?php echo htmlspecialchars($u['kod']);?>" data-tip="<?php echo $utip;?>"
          style="font-size:10px;padding:2px 4px;border:1px solid #99F6E4;border-radius:4px;flex:1;min-width:130px">
          <?php foreach($u['tum'] as $opt) echo "<option value='".htmlspecialchars($opt)."'".($opt===$u['atanan']?' selected':'').">".htmlspecialchars($opt)."</option>";?>
        </select>
        <button onclick="npHatKaydet(this)" style="font-size:10px;padding:2px 8px;background:#0F766E;color:#fff;border:none;border-radius:4px;cursor:pointer">💾</button>
        <?php if($u['db_atama']):?><button onclick="npHatSifirla('<?php echo htmlspecialchars($u['kod']);?>',this)" style="font-size:10px;padding:2px 6px;background:#F1F5F9;border:1px solid #E2E8F0;color:#64748B;border-radius:4px;cursor:pointer">↩</button><?php endif;?>
      </div>
      <div class="np-hat-msg" style="font-size:9px;margin-top:2px;display:none"></div>
    </td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<?php endif;?>

<?php endif;?>
<?php endif;?>

<script>
var NP_AJAX = '<?php echo BASE_URL;?>/bolumler/planlama/ajax/norm_hat_ata.php';

function npToggle(id,btn){
    var r=document.getElementById(id);
    if(!r) return;
    var open=r.style.display!=='none';
    r.style.display=open?'none':'table-row';
    if(btn){btn.textContent=open?'▶':'▼';btn.style.color=open?'':'#7C3AED';btn.style.background=open?'':'#EDE9FE';}
}

function npFilter(inpId,tblId){
    var q=document.getElementById(inpId).value.toLowerCase().trim();
    var tbody=document.querySelector('#'+tblId+' tbody');
    if(!tbody) return;
    var rows=Array.from(tbody.querySelectorAll('tr'));
    rows.forEach(function(row){
        if(row.classList.contains('detail-row')){ if(q) row.style.display='none'; return; }
        row.style.display=(!q||row.textContent.toLowerCase().includes(q))?'':'none';
    });
}

function npHatKaydet(btn){
    var td=btn.closest('td');
    var sel=td.querySelector('.np-hat-sel');
    var msg=td.querySelector('.np-hat-msg');
    btn.disabled=true; btn.textContent='...';
    fetch(NP_AJAX,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
        body:'action=hat_ata&stok_kodu='+encodeURIComponent(sel.dataset.kod)+'&ist_kodu='+encodeURIComponent(sel.value)+'&ist_turu='+encodeURIComponent(sel.dataset.tip)})
    .then(function(r){return r.json();})
    .then(function(d){
        btn.disabled=false; btn.textContent='💾';
        msg.style.display='block';
        msg.style.color=d.ok?'#16A34A':'#DC2626';
        msg.textContent=(d.ok?'✅ ':'❌ ')+(d.msg||'');
        if(d.ok) setTimeout(function(){msg.style.display='none';},3000);
    }).catch(function(){btn.disabled=false;btn.textContent='💾';});
}

function npHatSifirla(kod,btn){
    if(!confirm('DB ataması silinsin mi? ('+kod+')')) return;
    btn.disabled=true;
    fetch(NP_AJAX,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
        body:'action=hat_sil&stok_kodu='+encodeURIComponent(kod)})
    .then(function(r){return r.json();})
    .then(function(d){
        btn.disabled=false;
        var msg=btn.closest('td').querySelector('.np-hat-msg');
        msg.style.display='block';
        msg.style.color=d.ok?'#16A34A':'#DC2626';
        msg.textContent=(d.ok?'✅ ':'❌ ')+(d.msg||'')+(d.ok?' — Sayfayı yenileyin.':'');
    }).catch(function(){btn.disabled=false;});
}
</script>
