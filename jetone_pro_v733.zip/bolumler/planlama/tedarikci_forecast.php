<?php
ob_start();
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(60);

$debug = isset($_GET['debug']);
$sel_yil = (int)($_GET['yil'] ?? date('Y'));

// ── 1. FORECAST VERİLERİ ─────────────────────────────────────────
$forecast_data = [];
$forecast_refs = []; // stok_kodu => LOGICALREF

try {
    $s = $db->prepare("SELECT stok_kodu, stok_adi, ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12 FROM forecast WHERE yil=?");
    $s->execute([$sel_yil]);
    $fc_raw = $s->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($fc_raw) && $tigerdb_pdo) {
        $codes = array_column($fc_raw, 'stok_kodu');
        $ph = implode(',', array_fill(0, count($codes), '?'));
        $st = $tigerdb_pdo->prepare("SELECT LOGICALREF, CODE, NAME, CARDTYPE FROM dbo.LG_222_ITEMS WHERE CODE IN ($ph) AND ACTIVE=0");
        $st->execute($codes);
        $tiger_map = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $ti) $tiger_map[$ti['CODE']] = $ti;

        foreach ($fc_raw as $fp) {
            $sk = trim($fp['stok_kodu']);
            if (isset($tiger_map[$sk])) {
                $fp['LOGICALREF'] = $tiger_map[$sk]['LOGICALREF'];
                $fp['CARDTYPE']   = $tiger_map[$sk]['CARDTYPE'];
                $forecast_data[]  = $fp;
                $forecast_refs[$sk] = $tiger_map[$sk]['LOGICALREF'];
            }
        }
    }
} catch(Throwable $e) { if($debug) echo "Forecast hatası: ".$e->getMessage()."<br>"; }

// ── 2. MALZEME STOK BİLGİLERİ ────────────────────────────────────
$material_types = []; // code => STGRPCODE
$stock_info     = []; // code => {Merkez, Uretim, BSH}

if ($tigerdb_pdo) {
    try {
        $st = $tigerdb_pdo->query("
            SELECT IT.CODE, IT.STGRPCODE,
                ISNULL(SUM(CASE WHEN CAP.NR=0 THEN LV.ONHAND ELSE 0 END),0) AS Merkez,
                ISNULL(SUM(CASE WHEN CAP.NR=1 THEN LV.ONHAND ELSE 0 END),0) AS Uretim,
                ISNULL(SUM(CASE WHEN CAP.NR=5 THEN LV.ONHAND ELSE 0 END),0) AS BSH
            FROM dbo.LG_222_ITEMS IT
            LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
            LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO AND CAP.FIRMNR=222
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
            GROUP BY IT.CODE, IT.STGRPCODE");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $material_types[$r['CODE']] = $r['STGRPCODE'];
            $stock_info[$r['CODE']]     = $r;
        }
    } catch(Throwable $e) {}
}

// ── 3. BOM LEVEL 1 ───────────────────────────────────────────────
$bom_data = [];
if ($tigerdb_pdo && !empty($forecast_refs)) {
    try {
        $ref_list = implode(',', array_values($forecast_refs));
        $bom_data = $tigerdb_pdo->query("
            SELECT BOM.MAINPRODREF MAMUL_REF, IT.CODE MAMUL_KODU,
                   BML.ITEMREF ALT_REF, IT2.CODE ALT_KODU, IT2.NAME ALT_ADI,
                   BML.AMOUNT MIKTAR, IT2.STGRPCODE GRUP
            FROM dbo.LG_222_BOMLINE BML WITH(NOLOCK)
            JOIN dbo.LG_222_BOMREVSN BMR WITH(NOLOCK) ON BML.BOMREVREF=BMR.LOGICALREF
            JOIN dbo.LG_222_BOMASTER BOM WITH(NOLOCK) ON BMR.BOMMASTERREF=BOM.LOGICALREF
            JOIN dbo.LG_222_ITEMS IT  WITH(NOLOCK) ON BOM.MAINPRODREF=IT.LOGICALREF
            JOIN dbo.LG_222_ITEMS IT2 WITH(NOLOCK) ON BML.ITEMREF=IT2.LOGICALREF
            WHERE BML.LINETYPE=0 AND BMR.ACTIVE=1 AND BOM.ACTIVE=0
              AND BOM.MAINPRODREF IN ($ref_list)
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// ── 4. TEDARİKÇİ BİLGİLERİ ───────────────────────────────────────
$suppliers       = []; // tedarikci_adi => [{mail,ilgili_kisi,...}]
$supplier_mapping = []; // stok_kodu => {tedarikci_adi,...}

try {
    $rows = $db->query("SELECT * FROM tedarikci_bilgileri ORDER BY tedarikci_adi, id")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $suppliers[$r['tedarikci_adi']][] = $r;
    }
    $rows2 = $db->query("SELECT * FROM tedarikci_listesi ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows2 as $r) $supplier_mapping[trim($r['stok_kodu'])] = $r;
} catch(Throwable $e) {}

// ── 5. BOM PATLAMA (2 seviye) ─────────────────────────────────────
$all_req = []; // stok_kodu => {miktarlar...}
$level2_queue = []; // LOGICALREF => {ay1..ay12}

// Level 1
foreach ($forecast_data as $fp) {
    if (!isset($fp['LOGICALREF'])) continue;
    $pref = $fp['LOGICALREF'];
    foreach ($bom_data as $bl) {
        if ($bl['MAMUL_REF'] != $pref) continue;
        $ak = $bl['ALT_KODU']; $ar = $bl['ALT_REF']; $mik = (float)$bl['MIKTAR'];
        if (!isset($all_req[$ak])) {
            $all_req[$ak] = ['stok_kodu'=>$ak,'stok_adi'=>$bl['ALT_ADI'],
                'grup_kodu'=>$material_types[$ak]??$bl['GRUP'],'LOGICALREF'=>$ar,'level'=>1];
            for($m=1;$m<=12;$m++) $all_req[$ak]['ay'.$m]=0;
        }
        for($m=1;$m<=12;$m++) $all_req[$ak]['ay'.$m]+=(float)$fp['ay'.$m]*$mik;

        // Mamül/Yarımamül → level 2 kuyruğu
        $grp = $material_types[$ak]??$bl['GRUP'];
        if (in_array($grp, ['Mamül','Yarımamül'])) {
            if (!isset($level2_queue[$ar])) {
                $level2_queue[$ar] = ['stok_kodu'=>$ak];
                for($m=1;$m<=12;$m++) $level2_queue[$ar]['ay'.$m]=0;
            }
            for($m=1;$m<=12;$m++) $level2_queue[$ar]['ay'.$m]+=(float)$fp['ay'.$m]*$mik;
        }
    }
}

// Level 2
if ($tigerdb_pdo && !empty($level2_queue)) {
    try {
        $ref2 = implode(',', array_keys($level2_queue));
        $bom2 = $tigerdb_pdo->query("
            SELECT BOM.MAINPRODREF MAMUL_REF, BML.ITEMREF ALT_REF,
                   IT2.CODE ALT_KODU, IT2.NAME ALT_ADI, BML.AMOUNT MIKTAR, IT2.STGRPCODE GRUP
            FROM dbo.LG_222_BOMLINE BML WITH(NOLOCK)
            JOIN dbo.LG_222_BOMREVSN BMR WITH(NOLOCK) ON BML.BOMREVREF=BMR.LOGICALREF
            JOIN dbo.LG_222_BOMASTER BOM WITH(NOLOCK) ON BMR.BOMMASTERREF=BOM.LOGICALREF
            JOIN dbo.LG_222_ITEMS IT2 WITH(NOLOCK) ON BML.ITEMREF=IT2.LOGICALREF
            WHERE BML.LINETYPE=0 AND BMR.ACTIVE=1 AND BOM.ACTIVE=0
              AND BOM.MAINPRODREF IN ($ref2)
        ")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($level2_queue as $pref=>$pdata) {
            foreach ($bom2 as $bl) {
                if ($bl['MAMUL_REF'] != $pref) continue;
                $ak = $bl['ALT_KODU']; $ar = $bl['ALT_REF']; $mik=(float)$bl['MIKTAR'];
                if (!isset($all_req[$ak])) {
                    $all_req[$ak] = ['stok_kodu'=>$ak,'stok_adi'=>$bl['ALT_ADI'],
                        'grup_kodu'=>$material_types[$ak]??$bl['GRUP'],'LOGICALREF'=>$ar,'level'=>2];
                    for($m=1;$m<=12;$m++) $all_req[$ak]['ay'.$m]=0;
                }
                for($m=1;$m<=12;$m++) $all_req[$ak]['ay'.$m]+=(float)$pdata['ay'.$m]*$mik;
            }
        }
    } catch(Throwable $e) {}
}

// ── 6. TEDARİKÇİ EŞLEŞTİRME ──────────────────────────────────────
foreach ($all_req as &$req) {
    $sk = $req['stok_kodu'];
    $sm = $supplier_mapping[$sk] ?? null;
    if ($sm) {
        $req['tedarikci_adi'] = $sm['tedarikci_adi'];
        $contact = $suppliers[$sm['tedarikci_adi']][0] ?? null;
        $req['ilgili_kisi'] = $contact['ilgili_kisi_ad']   ?? '—';
        $req['mail']        = $contact['ilgili_kisi_mail'] ?? '—';
        $req['tel']         = $contact['ilgili_kisi_tel']  ?? '—';
    } elseif (in_array($req['grup_kodu']??'', ['Mamül','Yarımamül'])) {
        $req['tedarikci_adi'] = 'POLİZA ENDÜSTRİ A.Ş.';
        $req['ilgili_kisi']   = 'Yavuz BEKEM';
        $req['mail']          = 'planlama@poliza.com.tr';
        $req['tel']           = '05393054428';
    } else {
        $req['tedarikci_adi'] = 'Tedarikçi Bilgisi Yok';
        $req['ilgili_kisi']   = '—';
        $req['mail']          = '—';
        $req['tel']           = '—';
    }
}
unset($req);

// Tedarikçi bazlı unique liste (mail için)
$unique_suppliers = [];
foreach ($all_req as $r) {
    $n = $r['tedarikci_adi'];
    if ($n !== 'Tedarikçi Bilgisi Yok' && !isset($unique_suppliers[$n])) {
        // Tüm iletişim kişilerini topla
        $contacts = $suppliers[$n] ?? [];
        $mails = array_filter(array_column($contacts,'ilgili_kisi_mail'));
        $unique_suppliers[$n] = ['mails'=>implode(';',$mails)];
    }
}
ksort($unique_suppliers);

$ay_tam = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$api_url = BASE_URL . '/bolumler/satinalma/ajax/tedarikci_api.php';

ob_end_clean();
?>
<style>
.tf-tbl { border-collapse:collapse; font-size:11px; width:100%; white-space:nowrap; }
.tf-tbl thead th { background:#1E3A5F; color:#e0f0ff; padding:6px 7px; border:1px solid #2d5986; position:sticky; top:0; z-index:3; text-align:center; }
.tf-tbl tbody td { padding:4px 6px; border:1px solid #E5E7EB; vertical-align:middle; }
.tf-tbl tbody tr:nth-child(even) { background:#F8FAFC; }
.tf-tbl tbody tr:hover { background:#EFF6FF!important; }
.tf-tbl tfoot td { background:#1E3A5F; color:#e0f0ff; padding:5px 6px; border:1px solid #2d5986; font-weight:700; text-align:right; }
.tf-tbl tfoot td.l { text-align:left; }
.badge-grp { background:#EFF6FF; color:#1D4ED8; border-radius:4px; padding:1px 6px; font-size:10px; font-weight:600; }
.badge-yok { background:#FEE2E2; color:#991B1B; border-radius:4px; padding:1px 6px; font-size:10px; }
</style>

<!-- S-BAR -->
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1">
    <h1 class="s-bas">🚚 Tedarikçi Forecast</h1>
    <div class="s-yol">Planlama / <b>Tedarikçi Malzeme İhtiyacı <?php echo $sel_yil;?></b></div>
  </div>
  <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <form method="GET" style="display:flex;gap:6px;align-items:center">
      <input type="hidden" name="sayfa" value="planlama-tedarikci-forecast">
      <select name="yil" class="form-alan" style="padding:5px 8px;font-size:12px;width:80px" onchange="this.form.submit()">
        <?php foreach(range(date('Y')-1,date('Y')+2) as $y):?>
        <option value="<?php echo $y;?>"<?php echo $y==$sel_yil?' selected':'';?>><?php echo $y;?></option>
        <?php endforeach;?>
      </select>
      <?php if(!$debug):?><a href="?sayfa=planlama-tedarikci-forecast&yil=<?php echo $sel_yil;?>&debug=1" style="background:#94A3B8;color:#fff;padding:5px 9px;border-radius:6px;font-size:11px;text-decoration:none">🐛 Debug</a><?php endif;?>
    </form>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kapasite" style="background:#7C3AED;color:#fff;padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none">📈 Forecast</a>
  </div>
</div>

<?php if($debug):?>
<div style="background:#1E293B;color:#E2E8F0;padding:12px 16px;border-radius:8px;margin-bottom:12px;font-size:11px;font-family:monospace">
  <strong style="color:#FCD34D">DEBUG:</strong>
  Forecast: <?php echo count($forecast_data);?> ürün |
  BOM satır: <?php echo count($bom_data);?> |
  Level2 kuyruk: <?php echo count($level2_queue);?> |
  Toplam ihtiyaç: <?php echo count($all_req);?> kalem |
  Tedarikçi: <?php echo count($unique_suppliers);?>
</div>
<?php endif;?>

<!-- Özet kartlar -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
  <?php
  $tec_yok = count(array_filter($all_req, fn($r)=>$r['tedarikci_adi']==='Tedarikçi Bilgisi Yok'));
  foreach([
    ['🏭','Forecast',count($forecast_data),'#EFF6FF','#1E40AF'],
    ['🔗','Toplam İhtiyaç',count($all_req),'#F0FDF4','#065F46'],
    ['🚚','Tedarikçi',count($unique_suppliers),'#F3E8FF','#6B21A8'],
    ['⚠️','Tedarikçisiz',$tec_yok,'#FEF2F2','#991B1B'],
  ] as [$i,$e,$d,$bg,$fg]):?>
  <div style="background:<?php echo $bg;?>;border:1px solid <?php echo $fg;?>33;border-radius:8px;padding:7px 14px;min-width:100px">
    <div style="font-size:10px;color:<?php echo $fg;?>"><?php echo $i.' '.$e;?></div>
    <div style="font-size:17px;font-weight:800;color:<?php echo $fg;?>"><?php echo $d;?></div>
  </div>
  <?php endforeach;?>
</div>

<!-- MAİL GÖNDERME PANELİ -->
<div class="kart" style="padding:16px;margin-bottom:16px">
  <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:12px;display:flex;align-items:center;gap:8px">
    <span>📧 Tedarikçiye Mail Gönder</span>
    <small style="font-weight:400;color:#64748B;font-size:11px">İçerik HTML tablo olarak panoya kopyalanır → Outlook'a yapıştırın</small>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div style="min-width:220px">
      <label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px">Tedarikçi Firma</label>
      <select id="tfSupplier" class="form-alan" style="padding:7px 10px;font-size:12px;width:100%">
        <option value="">— Seçiniz —</option>
        <?php foreach(array_keys($unique_suppliers) as $sn):?>
        <option value="<?php echo htmlspecialchars($sn);?>"><?php echo htmlspecialchars($sn);?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="min-width:80px">
      <label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px">Kalem</label>
      <input type="text" id="tfItemCount" readonly value="—"
        style="border:1px solid #E2E8F0;border-radius:6px;padding:7px 10px;font-size:13px;font-weight:700;width:70px;text-align:center;background:#F8FAFC">
    </div>
    <div style="flex:1;min-width:250px">
      <label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px">CC (noktalı virgülle ayır — boş bırakınca POLİZA adresleri eklenir)</label>
      <input type="text" id="tfCC" class="form-alan" style="padding:7px 10px;font-size:12px;width:100%" placeholder="ornek@firma.com; ornek2@firma.com">
    </div>
    <button id="tfMailBtn" onclick="tfMail()" disabled
      style="background:#1E3A5F;color:#fff;border:none;padding:9px 20px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap">
      📨 Mail Hazırla & Kopyala
    </button>
  </div>
  <div id="tfMailDurum" style="display:none;margin-top:10px;padding:8px 12px;border-radius:6px;font-size:12px"></div>
</div>

<!-- TABLO -->
<div class="kart" style="padding:0;overflow:hidden">
  <!-- Filtre bar -->
  <div style="padding:10px 12px;background:#F8FAFC;border-bottom:1px solid #E2E8F0;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <input type="text" id="tfSearch" oninput="tfFilter()" placeholder="Stok kodu, ad veya tedarikçi ara..."
      style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 10px;font-size:12px;width:220px">
    <select id="tfSupFilter" onchange="tfFilter()" style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 9px;font-size:12px">
      <option value="">Tüm tedarikçiler</option>
      <?php foreach(array_keys($unique_suppliers) as $sn):?>
      <option value="<?php echo htmlspecialchars($sn);?>"><?php echo htmlspecialchars($sn);?></option>
      <?php endforeach;?>
      <option value="Tedarikçi Bilgisi Yok">⚠️ Tedarikçisiz</option>
    </select>
    <select id="tfGrupFilter" onchange="tfFilter()" style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 9px;font-size:12px">
      <option value="">Tüm gruplar</option>
      <?php foreach(array_unique(array_column($all_req,'grup_kodu')) as $g):?>
      <option value="<?php echo htmlspecialchars($g);?>"><?php echo htmlspecialchars($g);?></option>
      <?php endforeach;?>
    </select>
    <span id="tfCount" style="font-size:11px;color:#64748B;margin-left:auto"></span>
  </div>

  <div style="overflow-x:auto;max-height:calc(100vh - 340px);overflow-y:auto">
  <table class="tf-tbl">
    <thead>
      <tr>
        <th style="min-width:30px">#</th>
        <th style="min-width:110px;text-align:left">Stok Kodu</th>
        <th style="min-width:220px;text-align:left">Malzeme Adı</th>
        <th style="min-width:80px">Grup</th>
        <th style="min-width:65px">Stok</th>
        <th style="min-width:150px;text-align:left">Tedarikçi</th>
        <th style="min-width:100px;text-align:left">İlgili Kişi</th>
        <th style="min-width:60px">Lv.</th>
        <?php foreach($ay_tam as $idx=>$a): $ay_su=(int)date('n'); ?>
        <th style="min-width:48px;<?php echo ($idx+1==$ay_su)?'background:#1D4ED8':'';?>"><?php echo mb_substr($a,0,3);?></th>
        <?php endforeach;?>
        <th style="min-width:65px">Toplam</th>
      </tr>
    </thead>
    <tbody id="tfBody">
    <?php
    $row=1;
    // Tedarikçi adına göre sırala
    uasort($all_req, fn($a,$b)=>strcmp($a['tedarikci_adi'],$b['tedarikci_adi'])?:strcmp($a['stok_kodu'],$b['stok_kodu']));
    foreach ($all_req as $r):
      $sk = $r['stok_kodu'];
      $st = $stock_info[$sk] ?? null;
      $stok_top = $st ? (float)$st['Merkez']+(float)$st['Uretim']+(float)$st['BSH'] : 0;
      $top = 0; for($m=1;$m<=12;$m++) $top+=(float)$r['ay'.$m];
      $tec_yok2 = $r['tedarikci_adi']==='Tedarikçi Bilgisi Yok';
    ?>
    <tr data-tec="<?php echo htmlspecialchars($r['tedarikci_adi']);?>"
        data-grp="<?php echo htmlspecialchars($r['grup_kodu']??'');?>"
        data-kod="<?php echo strtolower(htmlspecialchars($sk));?>"
        data-ad="<?php echo strtolower(htmlspecialchars($r['stok_adi']));?>">
      <td style="text-align:center;color:#94A3B8"><?php echo $row++;?></td>
      <td style="font-weight:700;color:#1E3A5F"><?php echo htmlspecialchars($sk);?></td>
      <td style="color:#374151;max-width:260px;overflow:hidden;text-overflow:ellipsis" title="<?php echo htmlspecialchars($r['stok_adi']);?>"><?php echo htmlspecialchars(mb_substr($r['stok_adi'],0,45));?></td>
      <td style="text-align:center"><span class="badge-grp"><?php echo htmlspecialchars($r['grup_kodu']??'?');?></span></td>
      <td style="text-align:right;color:<?php echo $stok_top>0?'#065F46':'#94A3B8';?>"><?php echo $stok_top>0?round($stok_top):'—';?></td>
      <td><?php if($tec_yok2):?><span class="badge-yok">⚠️ Yok</span><?php else:?><strong style="color:#1E3A5F;font-size:11px"><?php echo htmlspecialchars($r['tedarikci_adi']);?></strong><?php endif;?></td>
      <td style="font-size:11px;color:#475569"><?php echo htmlspecialchars($r['ilgili_kisi']);?></td>
      <td style="text-align:center;color:#94A3B8;font-size:10px"><?php echo $r['level']??1;?></td>
      <?php for($m=1;$m<=12;$m++): $v=(float)$r['ay'.$m];?>
      <td style="<?php echo $v>0?'':'color:#CBD5E1';?>"><?php echo $v>0?round($v):'·';?></td>
      <?php endfor;?>
      <td style="font-weight:700;color:#1E3A5F"><?php echo round($top);?></td>
    </tr>
    <?php endforeach;?>
    </tbody>
    <tfoot>
      <tr>
        <td class="l" colspan="8">TOPLAM (<?php echo count($all_req);?> kalem)</td>
        <?php
        $gtop = array_fill(1,12,0);
        foreach($all_req as $r) for($m=1;$m<=12;$m++) $gtop[$m]+=(float)$r['ay'.$m];
        $gtoptop=0;
        for($m=1;$m<=12;$m++): $gtoptop+=$gtop[$m];?>
        <td><?php echo round($gtop[$m]);?></td>
        <?php endfor;?>
        <td><?php echo round($gtoptop);?></td>
      </tr>
    </tfoot>
  </table>
  </div>
</div>

<script>
var TF_API    = '<?php echo $api_url;?>';
var TF_YIL   = <?php echo $sel_yil;?>;
var TF_MAILS = <?php echo json_encode(array_map(fn($v)=>$v['mails'], $unique_suppliers), JSON_UNESCAPED_UNICODE);?>;

// Filtre
function tfFilter() {
  var metin  = document.getElementById('tfSearch').value.toLowerCase();
  var tec    = document.getElementById('tfSupFilter').value;
  var grp    = document.getElementById('tfGrupFilter').value;
  var rows   = document.querySelectorAll('#tfBody tr');
  var n = 0;
  rows.forEach(function(tr) {
    var ok = true;
    if (metin && tr.dataset.kod.indexOf(metin)===-1 && tr.dataset.ad.indexOf(metin)===-1 && tr.dataset.tec.toLowerCase().indexOf(metin)===-1) ok=false;
    if (tec && tr.dataset.tec !== tec) ok=false;
    if (grp && tr.dataset.grp !== grp) ok=false;
    tr.style.display = ok ? '' : 'none';
    if (ok) n++;
  });
  document.getElementById('tfCount').textContent = n + ' / ' + rows.length + ' kalem';
}
document.addEventListener('DOMContentLoaded', function() { tfFilter(); });

// Tedarikçi seçince kalem sayısı güncelle
document.getElementById('tfSupplier').addEventListener('change', function() {
  var sec = this.value;
  if (sec) {
    var n = document.querySelectorAll('#tfBody tr[data-tec="'+sec+'"]').length;
    document.getElementById('tfItemCount').value = n + ' kalem';
    document.getElementById('tfMailBtn').disabled = false;
  } else {
    document.getElementById('tfItemCount').value = '—';
    document.getElementById('tfMailBtn').disabled = true;
  }
});

// Mail hazırla
async function tfMail() {
  var firma  = document.getElementById('tfSupplier').value;
  var ccInp  = document.getElementById('tfCC').value.trim();
  var durum  = document.getElementById('tfMailDurum');
  if (!firma) return;

  durum.style.display='block'; durum.style.background='#FFF7ED'; durum.style.color='#92400E';
  durum.textContent = '⏳ Mail içeriği hazırlanıyor...';

  // TO: API'den mail al
  var toMails = TF_MAILS[firma] || '';
  if (!toMails) {
    try {
      var res = await fetch(TF_API + '?firma=' + encodeURIComponent(firma));
      var data = await res.json();
      if (data.ok && data.mails && data.mails.length) toMails = data.mails.join(';');
    } catch(e) {}
  }

  // CC: boşsa POLİZA'dan çek
  var cc = ccInp;
  if (!cc) {
    try {
      var res2 = await fetch(TF_API + '?firma=POL%C4%B0ZA');
      var d2 = await res2.json();
      if (d2.ok && d2.mails) cc = d2.mails.join(';');
    } catch(e) {}
  }

  // Satırları topla
  var rows = document.querySelectorAll('#tfBody tr[data-tec="'+firma+'"]');
  var items = [];
  rows.forEach(function(tr) {
    if (tr.style.display === 'none') return;
    var c = tr.cells;
    var ay = [];
    for (var i=8;i<=19;i++) ay.push(c[i].textContent.trim());
    items.push({
      kod: c[1].textContent.trim(),
      ad:  c[2].textContent.trim(),
      grp: c[3].textContent.trim(),
      ay:  ay,
      top: c[20].textContent.trim()
    });
  });

  var aylar = ['Ocak','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
  var yil = TF_YIL;

  // HTML içerik
  var html = '<div style="font-family:Arial,sans-serif;line-height:1.6">'
    + '<p>Sayın İlgili,</p>'
    + '<p>' + yil + ' yılı güncel forecast miktarlarımız aşağıda bilginize sunulmuştur.<br>'
    + 'Kesin sipariş değildir; ±%10 sapma olabilir. Kısıtınız varsa lütfen en kısa sürede bildiriniz.</p>'
    + '<table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;font-size:11px;width:100%">'
    + '<thead><tr style="background:#1E3A5F;color:#fff">'
    + '<th>Stok Kodu</th><th>Malzeme Adı</th><th>Grup</th>';
  aylar.forEach(function(a){ html += '<th>' + a + '</th>'; });
  html += '<th>TOPLAM</th></tr></thead><tbody>';
  items.forEach(function(it, idx) {
    var bg = idx%2===0 ? '#fff' : '#F8FAFC';
    html += '<tr style="background:'+bg+'">'
      + '<td><strong>'+it.kod+'</strong></td>'
      + '<td>'+it.ad+'</td>'
      + '<td style="text-align:center">'+it.grp+'</td>';
    it.ay.forEach(function(v){ html += '<td style="text-align:right">'+(v&&v!=='·'?v:'—')+'</td>'; });
    html += '<td style="text-align:right"><strong>'+it.top+'</strong></td></tr>';
  });
  html += '</tbody></table>'
    + '<br><p>Toplam <strong>' + items.length + '</strong> kalem</p>'
    + '</div>';

  // Panoya kopyala
  var copied = false;
  try {
    var blob = new Blob([html], {type:'text/html'});
    var txtBlob = new Blob([firma + ' - ' + yil + ' Forecast\n' + items.map(it=>it.kod+'\t'+it.ad+'\t'+it.top).join('\n')], {type:'text/plain'});
    await navigator.clipboard.write([new ClipboardItem({'text/html':blob,'text/plain':txtBlob})]);
    copied = true;
  } catch(e) {
    // Legacy
    try {
      var tmp = document.createElement('div');
      tmp.innerHTML = html;
      tmp.style.cssText = 'position:fixed;left:-9999px;top:0;background:#fff;padding:10px';
      document.body.appendChild(tmp);
      var rng = document.createRange(); rng.selectNodeContents(tmp);
      var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rng);
      copied = document.execCommand('copy');
      sel.removeAllRanges(); document.body.removeChild(tmp);
    } catch(e2) {}
  }

  // Outlook aç
  var subject = encodeURIComponent(yil + ' Forecast - ' + firma);
  var mailto  = 'mailto:' + toMails + '?cc=' + encodeURIComponent(cc) + '&subject=' + subject;

  durum.style.background = copied ? '#F0FDF4' : '#FFF7ED';
  durum.style.color      = copied ? '#065F46' : '#92400E';
  durum.innerHTML = (copied ? '✅ HTML tablo <strong>panoya kopyalandı</strong>.' : '⚠️ Kopyalama başarısız.')
    + ' Outlook açılıyor — mail gövdesine <strong>Ctrl+V</strong> ile yapıştırın.'
    + '<br><small>TO: '+toMails+' | CC: '+(cc||'—')+'</small>';

  setTimeout(function() { window.location.href = mailto; }, 400);
}

document.addEventListener('keydown', function(e){ if(e.key==='Escape'){ /* nothing */ }});
</script>
