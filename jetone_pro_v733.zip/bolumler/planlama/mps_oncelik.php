<?php
// JSON POST isteği - herşeyden önce yakala, output olmadan
if (!empty($_POST['json_action'])) {
    require_once dirname(dirname(__DIR__)) . '/core/config.php';
    require_once dirname(dirname(__DIR__)) . '/core/db.php';
    require_once dirname(dirname(__DIR__)) . '/core/auth.php';
    require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
    ob_end_clean();
    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['json_action'];
    if ($action === 'is_ata') {
        $hat   = trim($_POST['hat_kodu']??'');
        $mk    = trim($_POST['urun_kodu']??'');
        $miktar= (int)($_POST['planlanan_miktar']??0);
        $kap   = max(1,(int)($_POST['kapasite_vardiya']??1));
        $cycle = floatval($_POST['cycle_sn']??0);
        $parti = max(1,(int)($_POST['parti']??1));
        $adi   = trim($_POST['urun_adi']??'');
        $ue    = trim($_POST['uretim_emri_no']??'');
        $not_  = trim($_POST['notlar']??'');
        if (!$hat||!$mk||$miktar<1){ echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }


require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

set_time_limit(0);
ini_set('memory_limit','256M');

/* ══════════════════════════════════════════════════
   FORM POST İŞLEMLERİ (AJAX yok - form submit)
══════════════════════════════════════════════════ */
        try {
            $s=$db->prepare("SELECT COALESCE(MAX(hat_sira_no),0)+1 FROM mps_plan WHERE hat_kodu=? AND durum NOT IN('Tamamlandı','İptal')");
            $s->execute([$hat]); $sira=(int)$s->fetchColumn();
            $tv=max(1,(int)ceil($miktar/$kap));
            $pers  = max(1,(int)($_POST['personel_sayisi']??1));
        $db->prepare("INSERT INTO mps_plan(hat_kodu,urun_kodu,urun_adi,uretim_emri_no,planlanan_miktar,kalan_miktar,kapasite_vardiya,cycle_sn,parti,toplam_vardiya,kalan_vardiya,hat_sira_no,baslangic_tarih,bitis_tarih,baslangic_vardiya,toplam_gun,notlar,olusturan,personel_sayisi) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURDATE(),CURDATE(),'S',?,?,?,?)")
            ->execute([$hat,$mk,$adi,$ue?:null,$miktar,$miktar,$kap,$cycle,$parti,$tv,$tv,$sira,(int)ceil($tv/3),$not_,$_SESSION['kullanici_id']??0,$pers]);
            // Güncel plan listesini döndür
            $planlar = $db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'sira'=>$sira,'planlar'=>$planlar]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'is_sil') {
        $id=(int)($_POST['sil_id']??0);
        if(!$id){ echo json_encode(['ok'=>false]); exit; }
        try {
            $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
            $planlar = $db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'planlar'=>$planlar]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'durus_ekle') {
        $hat      = trim($_POST['hat']??'');
        $tur      = trim($_POST['durus_turu']??'');
        $vardiya  = max(1,(int)($_POST['vardiya_sayisi']??1));
        $vrd_bas  = trim($_POST['baslangic_vardiya']??'S');
        $aciklama = trim($_POST['aciklama']??'');
        if (!$hat||!$tur) { echo json_encode(['ok'=>false,'hata'=>'Hat ve duruş türü zorunlu']); exit; }
        try {
            $sira=$db->prepare("SELECT COALESCE(MAX(hat_sira_no),0)+1 FROM mps_plan WHERE hat_kodu=? AND durum NOT IN('Tamamlandı','İptal')");
            $sira->execute([$hat]); $sira=(int)$sira->fetchColumn();
            $gun=max(1,(int)ceil($vardiya/3));
            $db->prepare("INSERT INTO mps_plan(hat_kodu,urun_kodu,urun_adi,uretim_emri_no,planlanan_miktar,kalan_miktar,kapasite_vardiya,cycle_sn,parti,toplam_vardiya,kalan_vardiya,hat_sira_no,baslangic_tarih,bitis_tarih,baslangic_vardiya,toplam_gun,notlar,olusturan,personel_sayisi,durum)
                VALUES(?,?,?,NULL,0,0,0,0,1,?,?,?,CURDATE(),CURDATE(),?,?,?,?,0,'Planlandı')")
                ->execute([$hat,'__DURUS__',$tur,$vardiya,$vardiya,$sira,$vrd_bas,$gun,$aciklama,$_SESSION['kullanici_id']??0]);
            $planlar=$db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'planlar'=>$planlar]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen eylem']); exit;
}

/* ══════════════════════════════════════════════════
   SAYFA VERİLERİ
══════════════════════════════════════════════════ */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);
ini_set('memory_limit','256M');
$hata = '';
$liste = [];
$secili_musteriler = array_filter((array)($_POST['musteriler']??[]));
$form_gonderildi   = isset($_POST['analiz_calistir']);
$bugun             = date('Y-m-d');
$bu_ay_son         = date('Y-m-t');

$hat_renkleri = [
    'EN-110-01'=>'#FEE2E2',
    'EN-132-01'=>'#DBEAFE',
    'EN-80-01'=>'#D1FAE5',
    'EN-130-01'=>'#FEF3C7',
    'EN-160-01'=>'#EDE9FE',
    'EN-201-01'=>'#CFFAFE',
    'EN-202-01'=>'#FCE7F3',
    'EN-301-01'=>'#E0F2FE',
    'EN-302-01'=>'#ECFDF5',
    'EN-350-01'=>'#FEF9C3',
    'EN-420-01'=>'#FFEDD5',
    'EN-500-01'=>'#F1F5F9',
    'EN-650-01'=>'#F3E8FF',
    'EN-162-01'=>'#E0F7FA',
    'EN-131-01'=>'#FFF3CD',
    'EN-161-01'=>'#FEF08A',
    'EN-530-01'=>'#FED7AA',
    'EN-650-02'=>'#C7D2FE',
    'EN-450-01'=>'#CCFBF1',
    'EN-500-02'=>'#FFE4E6',
    'EN-260-01'=>'#BFDBFE',
    'EN-410-01'=>'#FDE68A',
    'EN-500-03'=>'#BBF7D0',
    'EN-700-01'=>'#FECACA',
    'EN-180-01'=>'#A7F3D0',
    'EN-280-01'=>'#BAE6FD',
    'EN-650-03'=>'#FDE68A',
    'EN-650-04'=>'#FBCFE8',
    'EN-650-05'=>'#FED7AA',
    'EN-650-06'=>'#DDD6FE',
    'EN-850-01'=>'#FECDD3',
    'EN-850-02'=>'#FEF08A',
];
// Müşteri listesi
$musteri_listesi = [];
try { $musteri_listesi = $db->query("SELECT DISTINCT musteri_firma_adi FROM siparis WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL AND musteri_firma_adi!='' ORDER BY musteri_firma_adi")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e){}

// Analiz
if ($form_gonderildi && $tigerdb_pdo) {
try {
    // 1. Siparişler
    $mu_par = ['Aktif'];
    $mu_wh  = '';
    if (!empty($secili_musteriler)) {
        $ph = implode(',', array_fill(0,count($secili_musteriler),'?'));
        $mu_wh = "AND musteri_firma_adi IN($ph)";
        $mu_par = array_merge($mu_par,$secili_musteriler);
    }
    $s = $db->prepare("SELECT sip_kodu, DATE(sip_teslim_tarihi) AS tarih, SUM(sip_miktar-sip_sevk_miktari) AS kalan
        FROM siparis WHERE sip_statu=? AND (sip_miktar-sip_sevk_miktari)>0 AND sip_teslim_tarihi IS NOT NULL
        AND sip_teslim_tarihi<=DATE_ADD(CURDATE(),INTERVAL 3 MONTH) $mu_wh
        GROUP BY sip_kodu,DATE(sip_teslim_tarihi) ORDER BY tarih");
    $s->execute($mu_par);
    $mamul_sip = [];
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $k=trim($r['sip_kodu']); if(!$k) continue;
        $mamul_sip[$k][$r['tarih']] = ($mamul_sip[$k][$r['tarih']]??0)+floatval($r['kalan']);
    }
    if (empty($mamul_sip)) { $hata='Aktif sipariş bulunamadı.'; goto son; }

    // 2. Mamül stokları
    $ml = array_keys($mamul_sip);
    $ph = implode(',',array_fill(0,count($ml),'?'));
    $mamul_stok = [];
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS k, ISNULL(SUM(CASE WHEN S.INVENNO IN(0,1,5) THEN S.ONHAND ELSE 0 END),0) AS stok
        FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
        LEFT JOIN dbo.LV_222_02_STINVTOT S WITH(NOLOCK) ON S.STOCKREF=IT.LOGICALREF AND S.INVENNO IN(0,1,5)
        WHERE IT.CODE IN($ph) GROUP BY IT.CODE");
    $r->execute($ml);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) $mamul_stok[$x['k']]=floatval($x['stok']);

    // 3. Operasyon - tüm hatlar ve hat bazlı parti/kapasite
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS urun_kod, IT.NAME AS urun_adi,
        WRK.CODE AS hat_kodu,
        dbo.LG_INTTOTIME2(OPR.RUNTIME) AS proses_cevrimi,
        OPR.BATCHQUANTITY AS parti
        FROM dbo.LG_222_OPRTREQ AS OPR WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_OPERTION AS OP  WITH(NOLOCK) ON OP.LOGICALREF  = OPR.OPERATIONREF
        LEFT JOIN dbo.LG_222_WORKSTAT AS WRK WITH(NOLOCK) ON WRK.LOGICALREF = OPR.WSREF
        LEFT JOIN dbo.LG_222_RTNGLINE AS RTL WITH(NOLOCK) ON RTL.OPERATIONREF= OP.LOGICALREF
        LEFT JOIN dbo.LG_222_ROUTING  AS RT  WITH(NOLOCK) ON RT.LOGICALREF  = RTL.ROUTINGREF
        LEFT JOIN dbo.LG_222_BOMREVSN AS BMR WITH(NOLOCK) ON BMR.ROUTINGREF = RT.LOGICALREF
        LEFT JOIN dbo.LG_222_BOMASTER AS BOM WITH(NOLOCK) ON BOM.LOGICALREF = BMR.BOMMASTERREF
        LEFT JOIN dbo.LG_222_BOMLINE  AS BML WITH(NOLOCK) ON BMR.LOGICALREF = BML.BOMREVREF AND BML.LINETYPE<>4
        LEFT JOIN dbo.LG_222_ITEMS    AS IT  WITH(NOLOCK) ON IT.LOGICALREF  = BOM.MAINPRODREF
        WHERE IT.CODE IN($ph) AND WRK.CODE LIKE 'EN-%' AND OP.CODE<>'SKOP.001'
          AND IT.CODE IS NOT NULL AND IT.CODE NOT LIKE 'H-%' AND OPR.RUNTIME>0
        GROUP BY IT.CODE,IT.NAME,WRK.CODE,OPR.RUNTIME,OPR.BATCHQUANTITY
        ORDER BY IT.CODE,WRK.CODE");
    $r->execute($ml);

    // op_map[urun_kod] = {adi, ana_hat, hatlar:[{hat,cycle_sn,parti,kapasite}]}
    $op_map = [];
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) {
        if (!isset($hat_renkleri[$x['hat_kodu']])) continue;
        $parti    = max(1, floatval($x['parti']));
        $cycle_sn = floatval($x['proses_cevrimi']);
        if ($cycle_sn <= 0) continue;
        $kapasite = (int)floor((3600 / $cycle_sn) * $parti * 7);

        if (!isset($op_map[$x['urun_kod']])) {
            $op_map[$x['urun_kod']] = [
                'adi'     => $x['urun_adi'],
                'ana_hat' => $x['hat_kodu'], // ilk hat = ana hat
                'hatlar'  => [],
            ];
        }
        $op_map[$x['urun_kod']]['hatlar'][$x['hat_kodu']] = [
            'hat'      => $x['hat_kodu'],
            'cycle_sn' => $cycle_sn,
            'parti'    => (int)$parti,
            'kapasite' => max(1, $kapasite),
        ];
    }

    // Geriye dönük uyumluluk için ana hat bilgisini düzleştir
    foreach($op_map as $mk => &$op) {
        $ana = $op['hatlar'][$op['ana_hat']] ?? reset($op['hatlar']);
        $op['hat']      = $op['ana_hat'];
        $op['kapasite'] = $ana['kapasite'];
        $op['cycle_sn'] = $ana['cycle_sn'];
        $op['parti']    = $ana['parti'];
    }
    unset($op);

    // 4. Net ihtiyaç + aciliyet
    foreach($mamul_sip as $mk => $tarih_map) {
        if (!isset($op_map[$mk])) continue;
        $stok=$mamul_stok[$mk]??0; $kum=0; $ilk_eksik=null;
        ksort($tarih_map);
        foreach($tarih_map as $tarih=>$sip) {
            $kum+=$sip;
            if ($stok-$kum<0 && !$ilk_eksik) $ilk_eksik=$tarih;
        }
        $toplam_net = max(0,$kum-$stok);
        if ($toplam_net<=0) continue;
        $op  = $op_map[$mk];
        $gun = $ilk_eksik ? (int)ceil((strtotime($ilk_eksik)-strtotime($bugun))/86400) : 999;
        $sev = (!$ilk_eksik||$gun<0) ? 0 : ($gun<=7?1:($ilk_eksik<=$bu_ay_son?2:3));
        $liste[] = [
            'mk'=>$mk,'adi'=>$op['adi'],'hat'=>$op['hat'],
            'ilk_eksik'=>$ilk_eksik??'9999-12-31','gun_kalan'=>$gun,
            'toplam_net'=>$toplam_net,'stok'=>$stok,'toplam_sip'=>$kum,
            'kapasite'=>$op['kapasite'],'cycle_sn'=>$op['cycle_sn'],'parti'=>$op['parti'],
            'vardiya_gerek'=>(int)ceil($toplam_net/max(1,$op['kapasite'])),
            'seviye'=>$sev,
        ];
    }
    usort($liste,function($a,$b){ return $a['seviye']!==$b['seviye']?$a['seviye']-$b['seviye']:strcmp($a['ilk_eksik'],$b['ilk_eksik']); });

    // 5. Üretim emirleri (bu ay açık) - liste oluştuğunda çek
    $ue_map = []; // [mamul_kodu] = [{emr_no,durum,planlanan,uretilen,kalan,is_ist}]
    if (!empty($liste)) {
        try {
            $urun_kodlari = array_column($liste,'mk');
            $ph2 = implode(',',array_fill(0,count($urun_kodlari),'?'));
            $ue_stmt = $tigerdb_pdo->prepare("SELECT IT.CODE AS mk,
                WS.CODE AS is_ist,
                CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
                PRO.FICHENO AS emr_no,
                CONVERT(decimal(18,0),PRO.PLNAMOUNT) AS planlanan,
                CONVERT(decimal(18,0),SUM(PRO.ACTAMOUNT)) AS uretilen,
                CONVERT(decimal(18,0),PRO.PLNAMOUNT-SUM(PRO.ACTAMOUNT)) AS kalan
            FROM dbo.LG_222_PRODORD PRO
            LEFT JOIN dbo.LG_222_ITEMS    IT  ON IT.LOGICALREF =PRO.ITEMREF
            LEFT JOIN dbo.LG_222_DISPLINE DIS ON DIS.PRODORDREF=PRO.LOGICALREF
            LEFT JOIN dbo.LG_222_WORKSTAT WS  ON WS.LOGICALREF =DIS.WSREF
            WHERE IT.CODE IN($ph2) AND PRO.STATUS IN(0,1)
            GROUP BY IT.CODE,WS.CODE,PRO.FICHENO,PRO.PLNAMOUNT,PRO.STATUS
            ORDER BY PRO.STATUS DESC");
            $ue_stmt->execute($urun_kodlari);
            foreach($ue_stmt->fetchAll(PDO::FETCH_ASSOC) as $ue) {
                $ue_map[$ue['mk']][] = [
                    'emr_no'  =>$ue['emr_no'],
                    'is_ist'  =>$ue['is_ist']??'',
                    'durum'   =>$ue['durum'],
                    'planlanan'=>(int)$ue['planlanan'],
                    'uretilen' =>(int)$ue['uretilen'],
                    'kalan'    =>max(0,(int)$ue['kalan']),
                ];
            }
        } catch(Throwable $e2) {}
    }

} catch(Throwable $e){ $hata=$e->getMessage(); }
son:;
}
$ue_map = $ue_map ?? [];

// Planlı işler + Gantt hesaplama
$planli_isler   = [];
$hat_kuyruk_map = [];
$gantt_hatlar   = []; // [hat_kodu][gun_str] = {urun_kodu, vardiya_listesi[]}

$resmi_tatiller_gantt = [
    '2025-01-01','2025-04-23','2025-05-01','2025-05-19',
    '2025-03-30','2025-03-31','2025-04-01',
    '2025-06-06','2025-06-07','2025-06-08',
    '2025-07-15','2025-08-30','2025-10-29',
    '2026-01-01','2026-04-23','2026-05-01','2026-05-19',
    '2026-03-20','2026-03-21','2026-03-22',
    '2026-05-27','2026-05-28','2026-05-29',
    '2026-07-15','2026-08-30','2026-10-29',
];

// Takvim günleri (bugünden 30 gün)
$gantt_gun_sayisi = 28;
$gantt_gunler = []; // tüm günler (tatil dahil)
$gantt_tatil  = []; // [gun_str] = 'Tatil'|'Pazar'
$dt = new DateTime($bugun);
for($gi=0; $gi<$gantt_gun_sayisi*2 && count($gantt_gunler)<$gantt_gun_sayisi*2; $gi++) {
    $gs = $dt->format('Y-m-d');
    $gantt_gunler[] = $gs;
    $dow = (int)$dt->format('N');
    if ($dow===7) $gantt_tatil[$gs]='Pazar';
    elseif (in_array($gs,$resmi_tatiller_gantt)) $gantt_tatil[$gs]='Tatil';
    $dt->modify('+1 day');
    if (count($gantt_gunler)>=$gantt_gun_sayisi*2) break;
}
// Sadece ilk 30 gün
$gantt_gunler = array_slice($gantt_gunler, 0, $gantt_gun_sayisi);

// Çalışma günleri listesi (tatil hariç)
$calisma_gunleri_gantt = array_values(array_filter($gantt_gunler, function($g) use($gantt_tatil){ return !isset($gantt_tatil[$g]); }));

try {
    $planli_isler = $db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);

    // Hat bazlı gruplama ve Gantt hesaplama
    $hat_planlar = []; // [hat_kodu] = [is1, is2, ...]
    foreach($planli_isler as $pi) {
        $hk = $pi['hat_kodu'];
        $hat_planlar[$hk][] = $pi;
        $hat_kuyruk_map[$hk][] = [
            'id'             => (int)$pi['id'],
            'hat_sira_no'    => (int)($pi['hat_sira_no']??0),
            'urun_kodu'      => $pi['urun_kodu'],
            'urun_adi'       => $pi['urun_adi']??'',
            'planlanan_miktar'=> (int)$pi['planlanan_miktar'],
            'kalan_miktar'   => (int)($pi['kalan_miktar']??$pi['planlanan_miktar']),
            'kalan_vardiya'  => (int)($pi['kalan_vardiya']??$pi['toplam_vardiya']??0),
            'toplam_vardiya' => (int)($pi['toplam_vardiya']??0),
            'uretim_emri_no' => $pi['uretim_emri_no']??'',
            'durum'          => $pi['durum'],
        ];
    }

    // Her hat için vardiya bazlı Gantt hesapla
    // 1 gün = 3 vardiya (S=08-16, O=16-24, G=00-08)
    // Kalan vardiya sayısına göre kaç gün sürdüğünü hesapla
    foreach($hat_planlar as $hk => $isler) {
        $gantt_hatlar[$hk] = ['isler'=>[], 'gun_map'=>[]]; // gun_map[gun_str] = [is_idx, ...]
        $vardiya_ptr = 0; // toplam vardiyadaki pozisyon (0'dan başlar)

        foreach($isler as $is_idx => $is) {
            $kalan_vrd = max(0,(int)($is['kalan_vardiya']??$is['toplam_vardiya']??0));
            $is_vrd_baslangic = $vardiya_ptr;
            $is_vrd_bitis     = $vardiya_ptr + $kalan_vrd - 1;

            // Vardiya → gün eşleştirmesi
            // Çalışma günü = floor(vardiya / 3), vardiya içi = vardiya % 3
            $gun_baslangic_idx = (int)floor($is_vrd_baslangic / 3);
            $gun_bitis_idx     = (int)floor($is_vrd_bitis / 3);

            $gantt_hatlar[$hk]['isler'][] = [
                'id'          => (int)$is['id'],
                'urun_kodu'   => $is['urun_kodu'],
                'urun_adi'    => $is['urun_adi']??'',
                'ue_no'       => $is['uretim_emri_no']??'',
                'kalan_miktar'=> (int)($is['kalan_miktar']??$is['planlanan_miktar']),
                'kalan_vrd'   => $kalan_vrd,
                'cycle_sn'    => floatval($is['cycle_sn']??0),
                'gun_bas_idx' => $gun_baslangic_idx,
                'gun_bit_idx' => $gun_bitis_idx,
                'sira'        => (int)($is['hat_sira_no']??0),
                'durum'       => $is['durum'],
            ];
            $vardiya_ptr += $kalan_vrd;
        }
    }
} catch(Throwable $e){ $hata_plan = $e->getMessage(); }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🎯 MPS Öncelik Analizi</h1>
    <div class="s-yol">Planlama / <b>Öncelik Analizi</b>
      <?php if(!empty($liste)): ?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● <?php echo count($liste);?> ürün</span><?php endif;?>
    </div>
  </div>
</div>

<style>
.onc-kart{background:var(--kart);border:1px solid var(--kenar);border-radius:12px;padding:14px 18px;margin-bottom:10px}
.s0 td{background:#FEE2E2!important;border-left:3px solid #DC2626!important}
.s1 td{background:#FEF3C7!important;border-left:3px solid #F59E0B!important}
.s2 td{background:#DBEAFE!important;border-left:3px solid #3B82F6!important}
.s3 td{background:#F0FDF4!important;border-left:3px solid #22C55E!important}
.sev-badge{display:inline-block;border-radius:4px;padding:2px 8px;font-size:10px;font-weight:700;white-space:nowrap}
</style>

<div class="s-body">
<?php if($hata): ?><div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata);?></div><?php endif;?>

<div class="onc-kart">
  <div style="font-size:13px;font-weight:800;color:var(--t);margin-bottom:12px">🎯 Öncelik Analizi Filtresi</div>
  <form method="POST">
    <div style="display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap">
      <div style="flex:1;min-width:240px">
        <label class="form-etiket">Müşteri <span style="color:var(--m2);font-weight:400">(Boş = tümü)</span></label>
        <select id="onc_musteri" name="musteriler[]" multiple autocomplete="off">
          <?php foreach($musteri_listesi as $m): ?>
          <option value="<?php echo htmlspecialchars($m);?>" <?php echo in_array($m,$secili_musteriler)?'selected':'';?>><?php echo htmlspecialchars($m);?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div style="padding-bottom:2px">
        <button type="submit" name="analiz_calistir" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:10px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">▶ Analiz Et</button>
      </div>
    </div>
  </form>
</div>

<?php if(!$form_gonderildi): ?>
<div style="padding:50px;text-align:center;color:var(--m2);background:var(--bg);border-radius:12px;border:2px dashed var(--kenar)">
  <div style="font-size:36px;margin-bottom:10px">🎯</div>
  <div style="font-size:15px;font-weight:700;color:var(--t)">Analiz Et butonuna tıklayın.</div>
</div>

<?php elseif(empty($liste)&&!$hata): ?>
<div style="padding:40px;text-align:center;color:var(--m2)">Üretilmesi gereken ürün bulunamadı.</div>

<?php else:
$s_say=[0=>0,1=>0,2=>0,3=>0]; foreach($liste as $l) $s_say[$l['seviye']]++;
?>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px">
<?php foreach([[0,'🚨 Gecikmiş','#FEE2E2','#991B1B'],[1,'⚡ Bu Hafta','#FEF3C7','#92400E'],[2,'📅 Bu Ay','#DBEAFE','#1E40AF'],[3,'🟢 Sonraki Ay+','#D1FAE5','#065F46']] as [$si,$lbl,$bg,$fg]):?>
<div style="background:<?php echo $bg;?>;border-radius:8px;padding:10px 12px;text-align:center">
  <div style="font-size:11px;color:<?php echo $fg;?>;font-weight:600;margin-bottom:2px"><?php echo $lbl;?></div>
  <div style="font-size:22px;font-weight:800;color:<?php echo $fg;?>"><?php echo $s_say[$si];?></div>
</div>
<?php endforeach;?>
</div>

<div class="onc-kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 320px)">
<table id="oncTbl" class="tablo" style="width:100%">
<thead style="position:sticky;top:0;z-index:2">
<tr>
  <th>Aciliyet</th><th>Ürün Kodu</th><th>Ürün Adı</th><th>Hat</th>
  <th>İlk İhtiyaç</th><th style="text-align:right">Kalan Gün</th>
  <th style="text-align:right">Stok</th><th style="text-align:right">Sipariş</th>
  <th style="text-align:right">Net İhtiyaç</th><th style="text-align:right">Kapasite/Vrd</th>
  <th style="text-align:right">Gereken Vrd</th><th style="text-align:center">İş Ata</th>
</tr>
</thead>
<tfoot><tr>
  <th>Aciliyet</th><th>Ürün Kodu</th><th>Ürün Adı</th><th>Hat</th>
  <th>İlk İhtiyaç</th><th>Kalan Gün</th><th>Stok</th><th>Sipariş</th>
  <th>Net İhtiyaç</th><th>Kapasite/Vrd</th><th>Gereken Vrd</th><th></th>
</tr></tfoot>
<tbody>
<?php
$sev_map=[0=>['🚨 Gecikmiş','#991B1B','#FEE2E2'],1=>['⚡ Bu Hafta','#92400E','#FEF3C7'],2=>['📅 Bu Ay','#1E40AF','#DBEAFE'],3=>['🟢 Sonraki Ay','#065F46','#D1FAE5']];
foreach($liste as $l):
  [$slbl,$sfg,$sbg]=$sev_map[$l['seviye']];
  $hr=$hat_renkleri[$l['hat']]??'#F3F4F6';
  $gk=$l['gun_kalan'];
  $gt=$gk>=999?'—':($gk<0?abs($gk).' gün geçti':$gk.' gün');
  $gc=$gk<0?'#DC2626':($gk<=7?'#D97706':($gk<=30?'#2563EB':'#166534'));
  $op_hatlar = $op_map[$l['mk']]['hatlar'] ?? [];
  $jd=htmlspecialchars(json_encode([
      'mk'=>$l['mk'],'adi'=>$l['adi'],'hat'=>$l['hat'],
      'kapasite'=>(int)$l['kapasite'],'cycle_sn'=>floatval($l['cycle_sn']),'parti'=>(int)$l['parti'],
      'net'=>(int)$l['toplam_net'],'ilk_eksik'=>$l['ilk_eksik'],
      'hatlar'=>array_values($op_hatlar), // [{hat,cycle_sn,parti,kapasite}]
  ],JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE));
?>
<tr class="s<?php echo $l['seviye'];?>">
  <td style="text-align:center"><span class="sev-badge" style="background:<?php echo $sbg;?>;color:<?php echo $sfg;?>"><?php echo $slbl;?></span></td>
  <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($l['mk']);?></code></td>
  <td style="font-size:12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo htmlspecialchars($l['adi']);?></td>
  <td><span style="background:<?php echo $hr;?>;padding:2px 7px;border-radius:4px;font-weight:700;font-size:11px"><?php echo htmlspecialchars($l['hat']);?></span></td>
  <td style="text-align:center;font-weight:700;font-size:12px" data-order="<?php echo $l['ilk_eksik'];?>"><?php echo $l['ilk_eksik']==='9999-12-31'?'—':date('d.m.Y',strtotime($l['ilk_eksik']));?></td>
  <td style="text-align:right;font-weight:700;color:<?php echo $gc;?>"><?php echo $gt;?></td>
  <td style="text-align:right;color:var(--m2)"><?php echo number_format($l['stok'],0,',','.');?></td>
  <td style="text-align:right"><?php echo number_format($l['toplam_sip'],0,',','.');?></td>
  <td style="text-align:right;font-weight:700;color:#DC2626"><?php echo number_format($l['toplam_net'],0,',','.');?></td>
  <td style="text-align:right;color:var(--m2)"><?php echo number_format($l['kapasite'],0,',','.');?></td>
  <td style="text-align:right;font-weight:700"><?php echo $l['vardiya_gerek'];?></td>
  <td style="text-align:center">
    <button onclick="isAtaAc(<?php echo $jd;?>)" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">➕ İş Ata</button>
  </td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
</div>

<?php endif;?>
</div>

<!-- İş Atama Modal -->

<!-- Duruş Modalı -->
<div id="durusModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#FFF5F5;border-radius:14px 14px 0 0">
    <div style="font-size:14px;font-weight:800;color:#991B1B">⛔ Duruş Kaydı</div>
    <button onclick="durusKapat()" style="background:#F1F5F9;border:none;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:18px">
    <div style="margin-bottom:12px">
      <label class="form-etiket">Hat</label>
      <select id="durusHat" class="form-alan">
        <option value="">Hat seçin...</option>
        <?php foreach(array_keys($hat_renkleri) as $hk): ?>
        <option value="<?php echo htmlspecialchars($hk);?>"><?php echo htmlspecialchars($hk);?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="margin-bottom:12px">
      <label class="form-etiket">Duruş Türü</label>
      <select id="durusTur" class="form-alan">
        <option value="">Tür seçin...</option>
        <option value="Planlı Duruş">🔧 Planlı Duruş</option>
        <option value="Makine Arıza">⚠️ Makine Arıza</option>
        <option value="Kalıp Arıza">🔩 Kalıp Arıza</option>
        <option value="Malzeme Bekleme">📦 Malzeme Bekleme</option>
        <option value="HM Bekleme">🧱 HM Bekleme</option>
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Vardiya Sayısı</label>
        <input type="number" id="durusVardiya" class="form-alan" min="1" max="99" value="1" style="text-align:center;font-weight:700">
      </div>
      <div>
        <label class="form-etiket">Başlangıç Vardiyası</label>
        <select id="durusBas" class="form-alan">
          <option value="S">Sabah (08-16)</option>
          <option value="O">Öğleden Sonra (16-24)</option>
          <option value="G">Gece (00-08)</option>
        </select>
      </div>
    </div>
    <div style="margin-bottom:16px">
      <label class="form-etiket">Açıklama</label>
      <input type="text" id="durusAciklama" class="form-alan" placeholder="Duruş açıklaması...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="durusKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="durusKaydet()" id="durusKaydetBtn" style="background:linear-gradient(135deg,#DC2626,#991B1B);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">⛔ Duruş Ekle</button>
    </div>
  </div>
</div>
</div>

<div id="isAtaModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:680px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#f8fafc;border-radius:14px 14px 0 0;position:sticky;top:0;z-index:2">
    <div>
      <div style="font-size:14px;font-weight:800;color:#0F172A" id="mBaslik">İş Atama</div>
      <div style="font-size:11px;color:#64748B;margin-top:2px" id="mAlt"></div>
    </div>
    <button onclick="mKapat()" style="background:#F1F5F9;border:none;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:18px">
    <!-- ÜE -->
    <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:12px;margin-bottom:14px;font-size:12px">
      <div style="font-weight:700;color:#1E40AF;margin-bottom:6px">📋 Üretim Emri</div>
      <div id="mUe">⏳ Kontrol ediliyor...</div>
    </div>
    <!-- Hat - sadece operasyonda tanımlı hatlar -->
    <div style="margin-bottom:12px">
      <label class="form-etiket">Hat <span id="mHatKapBilgi" style="font-weight:400;color:#065F46;font-size:11px"></span></label>
      <select id="mHat" class="form-alan" onchange="mHatDegisti()">
        <option value="">Hat seçin...</option>
      </select>
      <div id="mHatInfo" style="font-size:11px;color:#64748B;margin-top:4px"></div>
    </div>
    <!-- Kuyruk -->
    <div id="mKuyruk" style="margin-bottom:12px;display:none">
      <div style="font-size:12px;font-weight:700;color:#374151;margin-bottom:5px">📋 Hat Kuyruğu</div>
      <div id="mKuyrukListe"></div>
    </div>
    <!-- Miktar + ÜE No -->
    <div style="display:grid;grid-template-columns:1fr 1fr 80px;gap:12px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Miktar (adet)</label>
        <input type="number" id="mMiktar" class="form-alan" min="1" oninput="mHesapla()" placeholder="Miktar...">
      </div>
      <div>
        <label class="form-etiket">ÜE No</label>
        <input type="text" id="mUeNo" class="form-alan" placeholder="Otomatik..." readonly style="background:#F8FAFC">
      </div>
      <div>
        <label class="form-etiket">👤 Personel</label>
        <input type="number" id="mPersonel" class="form-alan" min="1" max="20" value="1" style="text-align:center;font-weight:700">
      </div>
    </div>
    <!-- Hesap -->
    <div id="mHesap" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:12px;margin-bottom:12px;display:none">
      <div style="font-weight:700;color:#065F46;margin-bottom:6px;font-size:12px">⚙️ Kapasite Hesabı</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:8px" id="mHesapKartlar"></div>
      <div id="mSiraBilgi" style="font-size:11px;color:#374151;background:#fff;border-radius:6px;padding:8px;border:1px solid #BBF7D0"></div>
    </div>
    <!-- Notlar -->
    <div style="margin-bottom:14px">
      <label class="form-etiket">Notlar</label>
      <input type="text" id="mNot" class="form-alan" placeholder="Açıklama...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="mKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="mKaydet()" id="mKaydetBtn" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">✅ Kuyruğa Al</button>
    </div>
  </div>
</div>
</div>

<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
<script>
window.oncSel=new TomSelect('#onc_musteri',{plugins:['remove_button'],placeholder:'Müşteri seçin...',maxOptions:500});
</script>
<style>
.ts-wrapper.multi .ts-control,.ts-wrapper.single .ts-control{background:#fff!important;border:1px solid var(--kenar)!important;border-radius:8px!important}
.ts-dropdown{background:#fff!important;border:1px solid var(--kenar)!important;color:#1e293b!important}
.ts-dropdown .option{background:#fff!important;color:#1e293b!important}
.ts-dropdown .option:hover,.ts-dropdown .option.active{background:#EFF6FF!important;color:#1E40AF!important}
.ts-control .item{background:#DBEAFE!important;color:#1E40AF!important;border-radius:4px!important;font-weight:600}
</style>

<?php if(!empty($liste)):?>
<script>
$(document).ready(function(){
  if(!$.fn.DataTable||$.fn.DataTable.isDataTable('#oncTbl'))return;
  $('#oncTbl').DataTable({
    paging:false,autoWidth:false,scrollY:'500px',scrollCollapse:true,
    order:[[0,'asc'],[4,'asc']],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'MPS_Oncelik'}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this,th=$(col.footer());
        if(!th||!th.length)return;
        var lbl=th.text().trim();
        if(!lbl||lbl==='İşlem'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>25?v.substr(0,25)+'…':v)+'</option>');});
      });
    }
  });
});
</script>
<?php endif;?>

<script>
var _d={}, _ue=[], _hs={};
var BASE='<?php echo BASE_URL;?>';
var UE_MAP=<?php echo json_encode($ue_map??[], JSON_UNESCAPED_UNICODE);?>;
var HAT_KUYRUK=<?php echo json_encode($hat_kuyruk_map??[], JSON_UNESCAPED_UNICODE);?>;
var HAT_RENKLERI=<?php echo json_encode($hat_renkleri, JSON_UNESCAPED_UNICODE);?>;

var HAT_RENKLERI_JS=<?php echo json_encode($hat_renkleri,JSON_UNESCAPED_UNICODE);?>;


function durusAc(){document.getElementById('durusModal').style.display='flex';}
function durusKapat(){document.getElementById('durusModal').style.display='none';}
function durusKaydet(){
  var hat=document.getElementById('durusHat').value;
  var tur=document.getElementById('durusTur').value;
  var vrd=document.getElementById('durusVardiya').value;
  var bas=document.getElementById('durusBas').value;
  var acl=document.getElementById('durusAciklama').value;
  if(!hat||!tur){alert('Hat ve duruş türü seçiniz.');return;}
  var btn=document.getElementById('durusKaydetBtn');
  btn.disabled=true;btn.textContent='Kaydediliyor...';
  var fd=new FormData();
  fd.append('json_action','durus_ekle');
  fd.append('hat',hat);fd.append('durus_turu',tur);
  fd.append('vardiya_sayisi',vrd);fd.append('baslangic_vardiya',bas);
  fd.append('aciklama',acl);
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    btn.disabled=false;btn.textContent='Duruş Ekle';
    if(d.ok){durusKapat();alert('Duruş kaydedildi.');location.reload();}
    else alert('Hata: '+(d.hata||''));
  }).catch(function(e){btn.disabled=false;btn.textContent='Duruş Ekle';alert('Hata:'+e);});
}

function isAtaAc(d){
  _d=d; _ue=[]; _hs={};
  document.getElementById('mBaslik').textContent='➕ İş Atama — '+d.mk;
  document.getElementById('mAlt').textContent=d.adi+' | Ana Hat: '+d.hat;
  document.getElementById('mMiktar').value=d.net||'';
  document.getElementById('mUeNo').value='';
  document.getElementById('mPersonel').value=1;
  document.getElementById('mNot').value='';
  document.getElementById('mHesap').style.display='none';
  document.getElementById('mKuyruk').style.display='none';

  // Hat select'i tanımlı hatlarla doldur
  var sel=document.getElementById('mHat');
  sel.innerHTML='';
  var hatlar=d.hatlar||[];
  if(hatlar.length===0){
    // Operasyon tanımı yoksa tüm hatları göster
    Object.keys(HAT_RENKLERI_JS).forEach(function(h){
      var opt=document.createElement('option');
      opt.value=h; opt.textContent=h;
      opt.style.background=HAT_RENKLERI_JS[h];
      if(h===d.hat) opt.selected=true;
      sel.appendChild(opt);
    });
  } else {
    hatlar.forEach(function(h){
      var opt=document.createElement('option');
      opt.value=h.hat;
      opt.textContent=h.hat+' — '+h.kapasite.toLocaleString('tr-TR')+' ad/vrd (Parti:'+h.parti+')';
      opt.dataset.kapasite=h.kapasite;
      opt.dataset.cycle=h.cycle_sn;
      opt.dataset.parti=h.parti;
      opt.style.background=HAT_RENKLERI_JS[h.hat]||'#fff';
      if(h.hat===d.hat) opt.selected=true;
      sel.appendChild(opt);
    });
  }

  document.getElementById('isAtaModal').style.display='flex';
  ueKontrol(d.mk);
  mHatDegisti();
}
function mKapat(){document.getElementById('isAtaModal').style.display='none';}

function ueKontrol(mk){
  _ue = UE_MAP[mk] || [];
  if(_ue.length){
    var html='';
    _ue.forEach(function(e,i){
      var ak=i===0;
      html+='<div onclick="ueSecildi('+i+')" id="ue_'+i+'" style="display:flex;align-items:center;gap:8px;padding:6px 8px;background:'+(ak?'#DBEAFE':'#F1F5F9')+';border-radius:6px;margin-bottom:4px;cursor:pointer;border:1px solid '+(ak?'#93C5FD':'#E2E8F0')+'">';
      html+='<div style="flex:1"><div style="font-weight:700;font-size:12px;color:#1E40AF">'+e.emr_no+'</div>';
      html+='<div style="font-size:11px;color:#374151">'+e.durum+(e.is_ist?' | '+e.is_ist:'')+'</div></div>';
      html+='<div style="text-align:right"><div style="font-size:13px;font-weight:800;color:'+(e.kalan>0?'#DC2626':'#059669')+'">'+e.kalan.toLocaleString('tr-TR')+'</div><div style="font-size:9px;color:#64748B">kalan</div></div></div>';
    });
    document.getElementById('mUe').innerHTML=html;
    if(_ue[0]){document.getElementById('mUeNo').value=_ue[0].emr_no;document.getElementById('mMiktar').value=_ue[0].kalan||_d.net;}
  } else {
    document.getElementById('mUe').innerHTML='<span style="color:#92400E">⚠️ Bu ürün için açık ÜE bulunamadı</span>';
  }
  mHesapla();
}

function ueSecildi(i){
  _ue.forEach(function(e,j){
    var el=document.getElementById('ue_'+j);
    if(el){el.style.background=j===i?'#DBEAFE':'#F1F5F9';el.style.borderColor=j===i?'#93C5FD':'#E2E8F0';}
  });
  if(_ue[i]){document.getElementById('mUeNo').value=_ue[i].emr_no;document.getElementById('mMiktar').value=_ue[i].kalan||_d.net;mHesapla();}
}

function mHatDegisti(){
  var hat=document.getElementById('mHat').value;
  // Seçili hattın kapasite bilgisini al ve _d'ye uygula
  var sel=document.getElementById('mHat');
  var opt=sel.options[sel.selectedIndex];
  if(opt && opt.dataset.kapasite){
    _d.kapasite=parseInt(opt.dataset.kapasite);
    _d.cycle_sn=parseFloat(opt.dataset.cycle);
    _d.parti=parseInt(opt.dataset.parti);
    document.getElementById('mHatKapBilgi').textContent=
      '→ '+_d.kapasite.toLocaleString('tr-TR')+' ad/vrd | Parti: '+_d.parti+' | Çevrim: '+_d.cycle_sn+'sn';
  } else {
    document.getElementById('mHatKapBilgi').textContent='';
  }
  var isler=HAT_KUYRUK[hat]||[];
  var bekleme=0;
  isler.forEach(function(i){bekleme+=(i.kalan_vardiya||i.toplam_vardiya||0);});
  _hs={siradaki_no:isler.length+1, onceki_isler:isler, bekleme_vardiya:bekleme};
  var kb=document.getElementById('mKuyruk'),kl=document.getElementById('mKuyrukListe');
  if(isler.length){
    kb.style.display='block';
    var html='';
    isler.forEach(function(is,i){
      var kv=is.kalan_vardiya||is.toplam_vardiya||0;
      html+='<div style="display:flex;align-items:center;gap:8px;padding:5px 8px;background:#FFF7ED;border-radius:6px;margin-bottom:3px;font-size:11px">';
      html+='<span style="background:#F97316;color:#fff;border-radius:3px;padding:1px 5px;font-weight:700;font-size:10px">'+(i+1)+'.</span>';
      html+='<span style="font-weight:700">'+is.urun_kodu+'</span>';
      html+='<span style="color:#64748B">'+is.planlanan_miktar.toLocaleString('tr-TR')+' ad</span>';
      html+='<span style="margin-left:auto;color:#DC2626;font-weight:700">'+kv+' vrd kalan</span></div>';
    });
    kl.innerHTML=html;
  } else kb.style.display='none';
  mHesapla();
}

function mHesapla(){
  var mik=parseInt(document.getElementById('mMiktar').value)||0;
  var kap=_d.kapasite||1;
  if(mik<=0){document.getElementById('mHesap').style.display='none';return;}
  var tv=Math.max(1,Math.ceil(mik/kap));
  var bk=(_hs.bekleme_vardiya||0);
  document.getElementById('mHesap').style.display='block';
  document.getElementById('mHesapKartlar').innerHTML=
    krt('Üretilecek',mik.toLocaleString('tr-TR')+' adet','#1E40AF')+
    krt('Bu iş için',tv+' vardiya','#065F46')+
    krt('Kapasite',kap.toLocaleString('tr-TR')+' ad/vrd','#374151');
  document.getElementById('mSiraBilgi').innerHTML=bk>0
    ?'<b>Önünüzde</b> '+bk+' vardiya iş var. Bu iş '+(bk+1)+'. vardiyadaki boşluktan başlar. Toplam <b>'+tv+' vardiya</b> (≈'+Math.ceil(tv/3)+' gün).'
    :'<b>Hat boş.</b> 1. vardiyadan itibaren başlar. Toplam <b>'+tv+' vardiya</b> (≈'+Math.ceil(tv/3)+' gün).';
}

function krt(l,v,c){return '<div style="background:#fff;border:1px solid #E2E8F0;border-radius:6px;padding:8px;text-align:center"><div style="font-size:10px;color:#64748B;margin-bottom:2px">'+l+'</div><div style="font-size:13px;font-weight:800;color:'+c+'">'+v+'</div></div>';}

function jsonPost(fields, callback) {
  var fd = new FormData();
  Object.entries(fields).forEach(function([k,v]){ fd.append(k, v||''); });
  fetch(window.location.href, {method:'POST', body:fd, credentials:'same-origin'})
  .then(function(r){ return r.json(); })
  .then(callback)
  .catch(function(e){ alert('Hata: '+e); });
}

function planTablosunuGuncelle(planlar) {
  if(!planlar||!planlar.length){
    var bl=document.getElementById('planBlok');
    if(bl) bl.style.display='none';
    return;
  }
  var hr=HAT_RENKLERI;
  var vmap={'S':'Sabah','O':'Öğleden','G':'Gece'};
  var dbg={'Planlandı':['#DBEAFE','#1E40AF'],'Devam Ediyor':['#D1FAE5','#065F46'],'Tamamlandı':['#E5E7EB','#374151'],'İptal':['#FEE2E2','#991B1B']};
  var tbody=document.getElementById('planTbody');
  if(!tbody) return;
  var html='';
  planlar.forEach(function(p){
    var hk=hr[p.hat_kodu]||'#F3F4F6';
    var kv=parseInt(p.kalan_vardiya||p.toplam_vardiya||0);
    var km=parseInt(p.kalan_miktar||p.planlanan_miktar||0);
    var tv=parseInt(p.toplam_vardiya||1);
    var dol=tv>0?Math.round((1-kv/Math.max(1,tv))*100):0;
    var d=dbg[p.durum]||['#F3F4F6','#374151'];
    html+='<tr>';
    html+='<td style="text-align:center;font-weight:800;font-size:13px">'+(parseInt(p.hat_sira_no)||0)+'</td>';
    html+='<td><span style="background:'+hk+';padding:2px 7px;border-radius:4px;font-weight:700;font-size:11px">'+p.hat_kodu+'</span></td>';
    html+='<td><code style="background:#F8FAFC;padding:1px 4px;border-radius:3px;font-size:11px;font-weight:700">'+p.urun_kodu+'</code></td>';
    html+='<td style="font-size:11px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+p.urun_adi+'</td>';
    html+='<td style="font-size:11px;color:#0369A1">'+(p.uretim_emri_no||'—')+'</td>';
    html+='<td style="text-align:right;font-weight:700">'+parseInt(p.planlanan_miktar).toLocaleString('tr-TR')+'</td>';
    html+='<td style="text-align:right;font-weight:700;color:'+(km>0?'#DC2626':'#059669')+'">'+km.toLocaleString('tr-TR')+'<div style="height:3px;background:#E2E8F0;border-radius:2px;margin-top:2px"><div style="height:3px;width:'+dol+'%;background:linear-gradient(90deg,#22C55E,#F97316 80%,#EF4444);border-radius:2px"></div></div></td>';
    html+='<td style="text-align:right;color:#64748B">'+tv+'</td>';
    html+='<td style="text-align:right;font-weight:700;color:'+(kv>0?'#1E40AF':'#059669')+'">'+kv+'</td>';
    html+='<td><span style="background:'+d[0]+';color:'+d[1]+';padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700">'+p.durum+'</span></td>';
    html+='<td style="font-size:11px;color:#64748B">'+(p.notlar||'')+'</td>';
    html+='<td style="text-align:center"><button onclick="planSil('+p.id+')" style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:11px;font-weight:700">🗑</button></td>';
    html+='</tr>';
  });
  tbody.innerHTML=html;
  // HAT_KUYRUK güncelle
  HAT_KUYRUK={};
  planlar.forEach(function(p){
    if(!HAT_KUYRUK[p.hat_kodu]) HAT_KUYRUK[p.hat_kodu]=[];
    HAT_KUYRUK[p.hat_kodu].push({
      hat_sira_no:parseInt(p.hat_sira_no)||0, urun_kodu:p.urun_kodu,
      planlanan_miktar:parseInt(p.planlanan_miktar)||0,
      kalan_vardiya:parseInt(p.kalan_vardiya||p.toplam_vardiya||0),
      toplam_vardiya:parseInt(p.toplam_vardiya||0)
    });
  });
}

function mKaydet(){
  var mik=parseInt(document.getElementById('mMiktar').value)||0;
  if(mik<1){alert('Miktar giriniz.');return;}
  var btn=document.getElementById('mKaydetBtn');
  btn.disabled=true; btn.textContent='Kaydediliyor...';
  jsonPost({
    json_action:'is_ata',
    hat_kodu:document.getElementById('mHat').value,
    urun_kodu:_d.mk, urun_adi:_d.adi,
    uretim_emri_no:document.getElementById('mUeNo').value,
    planlanan_miktar:mik,
    kapasite_vardiya:_d.kapasite,
    cycle_sn:_d.cycle_sn,
    parti:_d.parti,
    personel_sayisi:document.getElementById('mPersonel').value||1,
    notlar:document.getElementById('mNot').value
  }, function(d){
    btn.disabled=false; btn.textContent='✅ Kuyruğa Al';
    if(d.ok){ mKapat(); planTablosunuGuncelle(d.planlar); }
    else alert('Hata: '+(d.hata||'Bilinmeyen'));
  });
}

function planSil(id){
  if(!confirm('Bu planı silmek istediğinize emin misiniz?'))return;
  jsonPost({json_action:'is_sil', sil_id:id}, function(d){
    if(d.ok) planTablosunuGuncelle(d.planlar);
    else alert('Silinemedi');
  });
}
document.addEventListener('keydown',e=>{if(e.key==='Escape')mKapat();});
</script>
