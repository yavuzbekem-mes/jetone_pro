<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$mes_ok   = ($mes_pdo !== null);

function norm_tarih($t){
    if(preg_match('/^(\d{2})\.(\d{2})\.(\d{4})$/',$t,$m)) return "{$m[3]}-{$m[2]}-{$m[1]}";
    return $t;
}

$formGeldi  = !empty($_POST);
$startDate  = norm_tarih(trim($_POST['start_date'] ?? date('Y-m-d', strtotime('-30 days'))));
$endDate    = norm_tarih(trim($_POST['end_date']   ?? date('Y-m-d')));
$stokFil    = trim($_POST['stok_kodu'] ?? '');
$calisanFil = trim($_POST['calisan'] ?? '');

$rows      = [];
$hata      = '';
$tiger_map = []; // üretim emri no → iş istasyonu

// 1. Tiger'dan iş istasyonu map'i çek
if ($tiger_ok) {
    try {
        $yil = date('Y', strtotime($startDate));
        $st  = $tigerdb_pdo->query("
            SELECT PRO.FICHENO AS UE, WS.CODE AS IS_IST
            FROM dbo.LG_222_PRODORD PRO WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_DISPLINE DIS WITH(NOLOCK) ON DIS.PRODORDREF = PRO.LOGICALREF
            LEFT JOIN dbo.LG_222_WORKSTAT WS  WITH(NOLOCK) ON WS.LOGICALREF  = DIS.WSREF
            WHERE YEAR(PRO.DATE_) >= " . intval($yil-1) . "
              AND PRO.STATUS IN (0,1,2,3,4)
        ");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r)
            $tiger_map[$r['UE']] = $r['IS_IST'];
    } catch(Throwable $e) {}
}

// 2. MES'ten ikinci kalite verisi çek
if ($mes_ok) {
    try {
        $sql = "SELECT
            YEAR(URETIM_TARIHI)                                         AS YIL,
            MONTH(URETIM_TARIHI)                                        AS AY,
            CONVERT(DATE,URETIM_TARIHI)                                 AS URETIM_TARIHI,
            CASE
                WHEN DATEPART(HOUR,URETIM_TARIHI) >= 0  AND DATEPART(HOUR,URETIM_TARIHI) < 8  THEN '3. VARDİYA'
                WHEN DATEPART(HOUR,URETIM_TARIHI) >= 8  AND DATEPART(HOUR,URETIM_TARIHI) < 16 THEN '1. VARDİYA'
                ELSE '2. VARDİYA'
            END                                                         AS VARDIYA,
            URETIM_EMRI_NO,
            STOK_KODU,
            STOK_ADI,
            CALISAN,
            ISNULL(SUM(CONVERT(int,TOPLAM)),0)                          AS TOPLAM,
            ISNULL(SUM(CONVERT(int,AYAR_FIRESİ)),0)                    AS AYAR_FIRESİ,
            ISNULL(SUM(CONVERT(int,HAMMADDE_LEKESI)),0)                 AS HAMMADDE_LEKESI,
            ISNULL(SUM(CONVERT(int,CIZIK)),0)                           AS CIZIK,
            ISNULL(SUM(CONVERT(int,EKSIK_ENJEKSIYON)),0)                AS EKSIK_ENJEKSIYON,
            ISNULL(SUM(CONVERT(int,CATLAK)),0)                          AS CATLAK,
            ISNULL(SUM(CONVERT(int,GAZLANMA)),0)                        AS GAZLANMA,
            ISNULL(SUM(CONVERT(int,COKUNTU)),0)                         AS COKUNTU,
            ISNULL(SUM(CONVERT(int,YAG_LEKESI)),0)                      AS YAG_LEKESI,
            ISNULL(SUM(CONVERT(int,SERPME)),0)                          AS SERPME,
            ISNULL(SUM(CONVERT(int,YANMA)),0)                           AS YANMA
        FROM dbo.IKINCI_KALITE
        WHERE CONVERT(DATE,URETIM_TARIHI) BETWEEN ? AND ?";

        $params = [$startDate, $endDate];
        if ($stokFil !== '') { $sql .= " AND STOK_KODU = ?"; $params[] = $stokFil; }
        if ($calisanFil !== '') { $sql .= " AND CALISAN LIKE ?"; $params[] = '%'.$calisanFil.'%'; }

        $sql .= " GROUP BY
            YEAR(URETIM_TARIHI), MONTH(URETIM_TARIHI),
            CONVERT(DATE,URETIM_TARIHI),
            CASE
                WHEN DATEPART(HOUR,URETIM_TARIHI) >= 0  AND DATEPART(HOUR,URETIM_TARIHI) < 8  THEN '3. VARDİYA'
                WHEN DATEPART(HOUR,URETIM_TARIHI) >= 8  AND DATEPART(HOUR,URETIM_TARIHI) < 16 THEN '1. VARDİYA'
                ELSE '2. VARDİYA'
            END,
            URETIM_EMRI_NO, STOK_KODU, STOK_ADI, CALISAN
            ORDER BY URETIM_TARIHI DESC, URETIM_EMRI_NO";

        $st = $mes_pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// İstatistikler
$toplam_ik = array_sum(array_column($rows,'TOPLAM'));
$hata_cols = ['AYAR_FIRESİ','HAMMADDE_LEKESI','CIZIK','EKSIK_ENJEKSIYON',
              'CATLAK','GAZLANMA','COKUNTU','YAG_LEKESI','SERPME','YANMA'];
$hata_toplamlari = [];
foreach ($hata_cols as $hc)
    $hata_toplamlari[$hc] = array_sum(array_column($rows, $hc));
arsort($hata_toplamlari);
?>
<style>
#tblIK2 th{background:#1E3A5F !important;color:#fff !important;}
#tblIK2 td,#tblIK2 th{border:1px solid #CBD5E1 !important;white-space:nowrap !important;font-size:11px !important;}
.ik-hata-bar{height:14px;border-radius:3px;background:#DC2626;transition:width .4s}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">⚠️ Üretim İkinci Kalite</h1>
    <div class="s-yol">Planlama / <b>İkinci Kalite Raporu</b>
      <?php if($mes_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● MES DB Yok</span><?php endif;?>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:6px">● Tiger DB</span><?php endif;?>
    </div>
  </div>
  <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:5px 12px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px;font-size:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if(!$mes_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ MES veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Filtre -->
<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Başlangıç Tarihi</label>
      <input type="date" name="start_date" class="form-alan" value="<?php echo $startDate;?>">
    </div>
    <div>
      <label class="form-etiket">Bitiş Tarihi</label>
      <input type="date" name="end_date" class="form-alan" value="<?php echo $endDate;?>">
    </div>
    <div>
      <label class="form-etiket">Stok Kodu <span style="font-weight:400;color:#94A3B8">(tam eşleşme)</span></label>
      <input type="text" name="stok_kodu" class="form-alan" value="<?php echo htmlspecialchars($stokFil);?>" placeholder="Ör: 3587460100">
    </div>
    <div>
      <label class="form-etiket">Çalışan <span style="font-weight:400;color:#94A3B8">(içerir)</span></label>
      <input type="text" name="calisan" class="form-alan" value="<?php echo htmlspecialchars($calisanFil);?>" placeholder="Adı...">
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Veri Çek</button>
    <?php if($formGeldi):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-ikinci-kalite-rapor"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
    <?php endif;?>
  </form>
</div>

<?php if(!empty($rows)):?>

<!-- Özet KPI + Hata Dağılımı -->
<div style="display:grid;grid-template-columns:1fr 2fr;gap:12px;margin-bottom:14px">

  <!-- KPI kartları -->
  <div style="display:flex;flex-direction:column;gap:8px">
    <div style="background:linear-gradient(135deg,#991B1B,#DC2626);border-radius:10px;padding:14px;color:#fff">
      <div style="font-size:11px;font-weight:700;opacity:.8;margin-bottom:4px">⚠️ Toplam İkinci Kalite</div>
      <div style="font-size:32px;font-weight:900"><?php echo number_format($toplam_ik,0,'','.');?></div>
      <div style="font-size:11px;opacity:.75;margin-top:2px"><?php echo date('d.m.Y',strtotime($startDate));?> — <?php echo date('d.m.Y',strtotime($endDate));?></div>
    </div>
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px">
      <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:6px">KAYIT SAYISI</div>
      <div style="font-size:24px;font-weight:900;color:#1E3A5F"><?php echo count($rows);?></div>
      <div style="font-size:11px;color:#64748B">Vardiya+Emri+Stok+Çalışan</div>
    </div>
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px">
      <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:6px">İŞ İSTASYONU EŞLEŞMESİ</div>
      <div style="font-size:24px;font-weight:900;color:<?php echo $tiger_ok?'#16A34A':'#94A3B8';?>">
        <?php
        if($tiger_ok){
          $eslesme=count(array_filter($rows,fn($r)=>isset($tiger_map[$r['URETIM_EMRI_NO']])));
          echo $eslesme.'/'.count($rows);
        } else echo '—';?>
      </div>
      <div style="font-size:11px;color:#64748B">Tiger iş istasyonu</div>
    </div>
  </div>

  <!-- Hata türü dağılımı -->
  <div class="kart" style="padding:14px">
    <div style="font-size:12px;font-weight:700;color:#1E3A5F;margin-bottom:12px">📊 Hata Türü Dağılımı</div>
    <?php
    $max_val = max(array_values($hata_toplamlari)) ?: 1;
    $hata_adlari = [
        'AYAR_FIRESİ'=>'Ayar Firesi','HAMMADDE_LEKESI'=>'Hammadde Lekesi',
        'CIZIK'=>'Çizik','EKSIK_ENJEKSIYON'=>'Eksik Enjeksiyon',
        'CATLAK'=>'Çatlak','GAZLANMA'=>'Gazlanma','COKUNTU'=>'Çöküntü',
        'YAG_LEKESI'=>'Yağ Lekesi','SERPME'=>'Serpme','YANMA'=>'Yanma',
    ];
    foreach($hata_toplamlari as $hk=>$hv):
      if($hv==0) continue;
      $pct = round($hv/$max_val*100);
      $pct_total = $toplam_ik>0?round($hv/$toplam_ik*100,1):0;
    ?>
    <div style="margin-bottom:8px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
        <span style="font-weight:600;color:#374151"><?php echo $hata_adlari[$hk]??$hk;?></span>
        <span style="color:#DC2626;font-weight:700"><?php echo number_format($hv,0,'','.');?> <span style="color:#64748B;font-weight:400">(<?php echo $pct_total;?>%)</span></span>
      </div>
      <div style="height:10px;border-radius:5px;background:#F1F5F9;overflow:hidden">
        <div class="ik-hata-bar" style="width:<?php echo $pct;?>%"></div>
      </div>
    </div>
    <?php endforeach;?>
  </div>
</div>

<!-- Ana Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblIK2" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Tarih</th><th>Vardiya</th><th>Üretim Emri</th>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Çalışan</th>
      <th>İş İstasyonu</th>
      <th style="background:#991B1B !important;text-align:right">TOPLAM</th>
      <th style="text-align:right">Ayar Firesi</th>
      <th style="text-align:right">HM Lekesi</th>
      <th style="text-align:right">Çizik</th>
      <th style="text-align:right">Eksik Enj.</th>
      <th style="text-align:right">Çatlak</th>
      <th style="text-align:right">Gazlanma</th>
      <th style="text-align:right">Çöküntü</th>
      <th style="text-align:right">Yağ Lekesi</th>
      <th style="text-align:right">Serpme</th>
      <th style="text-align:right">Yanma</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th colspan="7" style="text-align:right">TOPLAM →</th>
      <th style="text-align:right;background:#991B1B !important;color:#fff !important"><?php echo number_format($toplam_ik,0,'','.');?></th>
      <?php foreach($hata_cols as $hc):?>
      <th style="text-align:right"><?php echo number_format($hata_toplamlari[$hc]??0,0,'','.');?></th>
      <?php endforeach;?>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($rows as $r):
    $toplam = (int)($r['TOPLAM']??0);
    $is_ist = $tiger_map[$r['URETIM_EMRI_NO']] ?? '—';
    $row_bg = $toplam >= 50 ? 'background:#FFF5F5' : ($toplam >= 20 ? 'background:#FFFBEB' : '');
  ?>
  <tr style="<?php echo $row_bg;?>">
    <td><?php echo $r['URETIM_TARIHI']?date('d.m.Y',strtotime($r['URETIM_TARIHI'])):'-';?></td>
    <td><span style="background:<?php echo $r['VARDIYA']==='1. VARDİYA'?'#DBEAFE':($r['VARDIYA']==='2. VARDİYA'?'#D1FAE5':'#EDE9FE');?>;padding:2px 7px;border-radius:8px;font-size:10px;font-weight:700"><?php echo $r['VARDIYA'];?></span></td>
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['URETIM_EMRI_NO']??'');?></code></td>
    <td><code style="background:#EFF6FF;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700;color:#1D4ED8"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($r['CALISAN']??'');?></td>
    <td style="font-weight:600;color:#7C3AED"><?php echo htmlspecialchars($is_ist);?></td>
    <td style="text-align:right;font-weight:900;color:<?php echo $toplam>=50?'#DC2626':($toplam>=20?'#D97706':'#374151');?>"><?php echo number_format($toplam,0,'','.');?></td>
    <?php foreach($hata_cols as $hc):
      $v=(int)($r[$hc]??0);?>
    <td style="text-align:right<?php echo $v>0?';color:#DC2626;font-weight:700':';color:#CBD5E1';?>"><?php echo $v>0?$v:'—';?></td>
    <?php endforeach;?>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<script>
$(document).ready(function(){
    $('#tblIK2').DataTable({
        initComplete:function(){
            this.api().columns([0,1,2,3,4,5,6]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'550px',paging:false,scrollX:true,
        order:[[7,'desc']],
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',
             filename:'Ikinci_Kalite_<?php echo date("Ymd");?>',
             exportOptions:{format:{body:function(data,r,c,node){
                 if(c<7) return $('<div/>').html(data).text().trim();
                 var v=$('<div/>').html(data).text().trim();
                 if(v==='—') return 0;
                 var n=parseFloat(v.replace(/\./g,''));
                 return isNaN(n)?v:n;
             }}}
            },'print'
        ]
    });
});
</script>

<?php elseif($formGeldi&&!$hata):?>
<div style="background:#D1FAE5;padding:20px;text-align:center;color:#065F46;border-radius:10px;font-weight:700">
  ✅ Seçilen aralıkta ikinci kalite kaydı bulunamadı.
</div>
<?php else:?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">⚠️</div>
  <div style="font-weight:600">Tarih aralığı seçip "Veri Çek" butonuna basın.</div>
  <div style="font-size:12px;margin-top:4px">Varsayılan: Son 30 gün</div>
</div>
<?php endif; endif;?>
