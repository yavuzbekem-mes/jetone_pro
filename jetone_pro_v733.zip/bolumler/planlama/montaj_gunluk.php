<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok  = ($tigerdb_pdo !== null);
$bugun     = date('Y-m-d');
$dun       = date('Y-m-d', strtotime('-1 day'));

$startDate  = trim($_POST['start_date'] ?? $dun);
$endDate    = trim($_POST['end_date']   ?? $bugun);
$mamulKodu  = trim($_POST['mamul_kodu'] ?? '');
$formGeldi  = !empty($_POST);

// Tarih formatı normalize (gün.ay.yıl → yıl-ay-gün)
function norm_tarih($t) {
    if (preg_match('/^(\d{2})\.(\d{2})\.(\d{4})$/', $t, $m)) return "{$m[3]}-{$m[2]}-{$m[1]}";
    return $t;
}
$startDate = norm_tarih($startDate);
$endDate   = norm_tarih($endDate);

$tableContent = '';
$dates        = [];
$groupedResults = [];
$hata         = '';

if ($tiger_ok && $formGeldi) {
    $sql = "SELECT
        WS.CODE                             AS MakineKodu,
        IT.CODE                             AS MamulKodu,
        IT.NAME                             AS MamulAdi,
        CONVERT(VARCHAR,ST.DATE_,104)       AS Tarih,
        PRO.FICHENO                         AS UretimEmriNo,
        SUM(ST.AMOUNT) - ISNULL((
            SELECT SUM(CONVERT(decimal,TOPLAM))
            FROM MES.dbo.IKINCI_KALITE IK
            WHERE PRO.FICHENO = IK.URETIM_EMRI_NO
              AND YEAR(IK.URETIM_TARIHI) >= 2024
              AND CONVERT(VARCHAR,ST.DATE_,104) = CONVERT(VARCHAR,IK.URETIM_TARIHI,104)
              AND IK.URETIM_TARIHI BETWEEN DATEADD(SECOND,-1,IK.URETIM_TARIHI)
                                       AND DATEADD(SECOND,3,IK.URETIM_TARIHI)
        ),0)                                AS HatasizMiktar
    FROM dbo.LG_222_02_STLINE ST WITH(NOLOCK)
    LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK)      ON ST.STOCKREF      = IT.LOGICALREF
    LEFT JOIN dbo.LG_222_PRODORD PRO WITH(NOLOCK)   ON ST.PRODORDERREF  = PRO.LOGICALREF
    LEFT JOIN dbo.LG_222_DISPLINE DISP WITH(NOLOCK) ON PRO.LOGICALREF   = DISP.PRODORDREF
    LEFT JOIN dbo.LG_222_WORKSTAT WS WITH(NOLOCK)   ON DISP.WSREF       = WS.LOGICALREF
    WHERE ST.TRCODE   = 13
      AND ST.LPRODSTAT = 0
      AND ST.DATE_ BETWEEN ? AND ?
      AND WS.CODE IN (
          'SR-01','MT-01',
          'EL İŞÇİLİĞİ 1','EL İŞÇİLİĞİ 2','EL İŞÇİLİĞİ 3',
          'EL İŞÇİLİĞİ 4','EL İŞÇİLİĞİ 5','EL İŞÇİLİĞİ 6',
          'EL İŞÇİLİĞİ 7','EL İŞÇİLİĞİ 8','EL İŞÇİLİĞİ 9',
          'EL İŞÇİLİĞİ 10'
      )";

    $params = [$startDate, $endDate];
    if ($mamulKodu !== '') {
        $sql .= " AND IT.CODE = ?";
        $params[] = $mamulKodu;
    }

    $sql .= " GROUP BY WS.CODE, IT.CODE, IT.NAME,
              CONVERT(VARCHAR,ST.DATE_,104), PRO.FICHENO
              ORDER BY WS.CODE, IT.CODE, CONVERT(VARCHAR,ST.DATE_,104)";

    try {
        $st = $tigerdb_pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($rows)) {
            $dates = array_values(array_unique(array_column($rows,'Tarih')));
            sort($dates);

            foreach ($rows as $r) {
                $key = $r['MakineKodu'].'|||'.$r['MamulKodu'].'|||'.$r['MamulAdi'];
                $groupedResults[$key][$r['Tarih']] = isset($groupedResults[$key][$r['Tarih']])
                    ? $groupedResults[$key][$r['Tarih']] + floatval($r['HatasizMiktar'])
                    : floatval($r['HatasizMiktar']);
            }
        }
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblMontaj th { background:#1E3A5F !important; color:#fff !important; }
#tblMontaj td, #tblMontaj th { border:1px solid #CBD5E1 !important; white-space:nowrap !important; }
#tblMontaj tfoot th { background:#1E3A5F !important; color:#fff !important; font-weight:700; }
#tblMontaj td.sayi { text-align:right; font-weight:700; color:#1D4ED8; }
#tblMontaj td.sifir { color:#CBD5E1; text-align:right; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">🔧 Montaj Günlük Üretim Girişleri</h1>
    <div class="s-yol">Planlama / Montaj / <b>Günlük Girişler</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-size:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Filtre formu -->
<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Başlangıç Tarihi</label>
      <input type="date" name="start_date" class="form-alan"
        value="<?php echo htmlspecialchars($startDate);?>">
    </div>
    <div>
      <label class="form-etiket">Bitiş Tarihi</label>
      <input type="date" name="end_date" class="form-alan"
        value="<?php echo htmlspecialchars($endDate);?>">
    </div>
    <div>
      <label class="form-etiket">Mamul Kodu <span style="font-weight:400;color:#94A3B8">(boş = tümü)</span></label>
      <input type="text" name="mamul_kodu" class="form-alan"
        value="<?php echo htmlspecialchars($mamulKodu);?>"
        placeholder="Ör: 2988080600" style="text-transform:uppercase">
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      🔍 Veri Çek
    </button>
    <?php if($formGeldi):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-montaj-gunluk"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">
      ✕ Temizle
    </a>
    <?php endif;?>
  </form>
</div>

<?php if(!$formGeldi):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">🔧</div>
  <div style="font-weight:600">Tarih aralığı seçip "Veri Çek" butonuna basın.</div>
</div>

<?php elseif(empty($groupedResults)&&!$hata):?>
<div style="background:#F1F5F9;padding:30px;text-align:center;color:#94A3B8;border-radius:10px">
  Seçilen tarih aralığında kayıt bulunamadı.
</div>

<?php else:?>

<!-- İstatistik özet -->
<div style="display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap">
  <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:8px 16px;font-size:12px">
    <span style="font-weight:700;color:#1D4ED8"><?php echo count($groupedResults);?></span>
    <span style="color:#374151"> makine/mamul kombinasyonu</span>
  </div>
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:8px 16px;font-size:12px">
    <span style="font-weight:700;color:#16A34A"><?php echo count($dates);?></span>
    <span style="color:#374151"> farklı tarih</span>
  </div>
  <div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:8px;padding:8px 16px;font-size:12px">
    <span style="font-size:11px;color:#92400E">
      <?php echo date('d.m.Y',strtotime($startDate));?> — <?php echo date('d.m.Y',strtotime($endDate));?>
    </span>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblMontaj" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Makine Kodu</th>
      <th>Mamul Kodu</th>
      <th>Mamul Adı</th>
      <?php foreach($dates as $d):?>
      <th style="text-align:right"><?php echo htmlspecialchars($d);?></th>
      <?php endforeach;?>
      <th style="text-align:right;background:#0F2942 !important">TOPLAM</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th colspan="3" style="text-align:right">GÜNLÜK TOPLAM →</th>
      <?php
      $gun_toplamlari = array_fill_keys($dates, 0);
      foreach($groupedResults as $key=>$tarihler)
          foreach($tarihler as $t=>$v) $gun_toplamlari[$t] = ($gun_toplamlari[$t]??0)+$v;
      $genel_toplam = array_sum($gun_toplamlari);
      foreach($dates as $d):?>
      <th style="text-align:right"><?php echo number_format($gun_toplamlari[$d],0,'','.');?></th>
      <?php endforeach;?>
      <th style="text-align:right"><?php echo number_format($genel_toplam,0,'','.');?></th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($groupedResults as $key=>$tarihler):
    [$mak,$mam,$mam_adi] = explode('|||',$key,3);
    $satir_toplam = array_sum($tarihler);
  ?>
  <tr>
    <td style="font-weight:700;color:#1E3A5F"><?php echo htmlspecialchars($mak);?></td>
    <td><code style="background:#EFF6FF;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700;color:#1D4ED8"><?php echo htmlspecialchars($mam);?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($mam_adi);?></td>
    <?php foreach($dates as $d):
      $v = $tarihler[$d] ?? null;
    ?>
    <?php if($v===null||$v==0):?>
    <td class="sifir">—</td>
    <?php else:?>
    <td class="sayi"><?php echo number_format($v,0,'','.');?></td>
    <?php endif;?>
    <?php endforeach;?>
    <td style="text-align:right;font-weight:900;background:#F0FDF4;color:#16A34A"><?php echo number_format($satir_toplam,0,'','.');?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<script>
$(document).ready(function(){
    var tbl = $('#tblMontaj');
    var colCount = tbl.find('thead tr th').length;
    // Sabit kolonlar: Makine, Mamul Kodu, Mamul Adı, Toplam (son)
    var fixedCols = [0,1,2,colCount-1];
    var dateCols = [];
    for(var i=3;i<colCount-1;i++) dateCols.push(i);

    tbl.DataTable({
        initComplete: function(){
            this.api().columns([0,1]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'550px',paging:false,scrollX:true,
        columnDefs:[
            {orderable:false,targets:dateCols},
            {className:'dt-right',targets:dateCols.concat([colCount-1])}
        ],
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',
             filename:'Montaj_Gunluk_<?php echo date("Ymd");?>',
             exportOptions:{format:{body:function(data,r,c,node){
                 var v=$('<div/>').html(data).text().trim();
                 if(v==='—') return 0;
                 var n=parseFloat(v.replace(/\./g,'').replace(',','.'));
                 return isNaN(n)?v:n;
             }}}
            },
            'copyHtml5','print'
        ]
    });
});
</script>
<?php endif;?>
<?php endif;?>
