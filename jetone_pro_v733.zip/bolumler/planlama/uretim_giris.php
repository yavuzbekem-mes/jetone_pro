<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok  = ($tigerdb_pdo !== null);
$startDate = trim($_POST['start_date'] ?? date('Y-m-d', strtotime('-6 days')));
$endDate   = trim($_POST['end_date']   ?? date('Y-m-d'));
$mamulKodu = trim($_POST['mamul_kodu'] ?? '');
$submitted = isset($_POST['start_date']);

// Tarih doğrulama
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) $startDate = date('Y-m-d', strtotime('-6 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate))   $endDate   = date('Y-m-d');

$tableContent = '';
$dates        = [];
$has_data     = false;
$hata         = '';

if ($tiger_ok) {
    try {
        $sql = "SELECT
            WS.CODE AS Makine_Kodu,
            IT.CODE AS Mamul_Kodu,
            IT.NAME AS Mamul_Adi,
            CONVERT(VARCHAR(10), ST.DATE_, 120) AS Tarih,
            PRO.FICHENO AS Uretim_Emri_No,
            SUM(ST.AMOUNT) - ISNULL((
                SELECT SUM(CONVERT(DECIMAL(18,2), TOPLAM))
                FROM MES..IKINCI_KALITE IK
                WHERE IK.URETIM_EMRI_NO = PRO.FICHENO
                  AND YEAR(IK.URETIM_TARIHI) >= 2024
                  AND CONVERT(VARCHAR(10), ST.DATE_, 120) = CONVERT(VARCHAR(10), IK.URETIM_TARIHI, 120)
                  AND IK.URETIM_TARIHI BETWEEN DATEADD(SECOND,-1,IK.URETIM_TARIHI) AND DATEADD(SECOND,3,IK.URETIM_TARIHI)
            ), 0) AS Hatasiz_Miktar
        FROM dbo.LG_222_02_STLINE ST WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON ST.STOCKREF = IT.LOGICALREF
        LEFT JOIN dbo.LG_222_PRODORD PRO WITH(NOLOCK) ON ST.PRODORDERREF = PRO.LOGICALREF
        LEFT JOIN dbo.LG_222_DISPLINE DISP WITH(NOLOCK) ON PRO.LOGICALREF = DISP.PRODORDREF
        LEFT JOIN dbo.LG_222_WORKSTAT WS WITH(NOLOCK) ON DISP.WSREF = WS.LOGICALREF
        WHERE ST.TRCODE = 13
          AND ST.LPRODSTAT = 0
          AND ST.DATE_ BETWEEN :start_date AND DATEADD(DAY,1,:end_date)
          AND ISNULL(WS.CODE,'') NOT IN (
            'SR-01','MT-01','EL İŞÇİLİĞİ 1','EL İŞÇİLİĞİ 2','EL İŞÇİLİĞİ 3',
            'EL İŞÇİLİĞİ 4','EL İŞÇİLİĞİ 5','EL İŞÇİLİĞİ 6','EL İŞÇİLİĞİ 7',
            'EL İŞÇİLİĞİ 8','EL İŞÇİLİĞİ 9','EL İŞÇİLİĞİ 10')";

        if ($mamulKodu !== '') $sql .= " AND IT.CODE = :mamul_kodu";

        $sql .= " GROUP BY WS.CODE, IT.CODE, IT.NAME,
            CONVERT(VARCHAR(10), ST.DATE_, 120), PRO.FICHENO
          ORDER BY WS.CODE, IT.CODE, CONVERT(VARCHAR(10), ST.DATE_, 120)";

        $st = $tigerdb_pdo->prepare($sql);
        $st->bindValue(':start_date', $startDate);
        $st->bindValue(':end_date',   $endDate);
        if ($mamulKodu !== '') $st->bindValue(':mamul_kodu', $mamulKodu);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($rows)) {
            $has_data = true;
            $dates    = array_values(array_unique(array_column($rows, 'Tarih')));
            sort($dates);

            // Grupla
            $grouped = [];
            foreach ($rows as $r) {
                $k = $r['Makine_Kodu'].'||'.$r['Mamul_Kodu'].'||'.$r['Mamul_Adi'];
                $grouped[$k][$r['Tarih']] = ($grouped[$k][$r['Tarih']] ?? 0) + (float)$r['Hatasiz_Miktar'];
            }

            // Başlık
            $th = '<th>Makine Kodu</th><th>Mamul Kodu</th><th>Mamul Adı</th>';
            foreach ($dates as $d) {
                $th .= '<th style="text-align:right">'.date('d.m', strtotime($d)).'</th>';
            }
            $th .= '<th style="text-align:right">Toplam</th>';
            $tableContent .= "<thead><tr>$th</tr></thead><tfoot><tr>$th</tr></tfoot><tbody>";

            foreach ($grouped as $k => $dateData) {
                [$mak, $kod, $ad] = explode('||', $k, 3);
                $satir_top = 0;
                $tableContent .= '<tr>';
                $tableContent .= '<td style="font-weight:700;font-size:11px">'.htmlspecialchars($mak).'</td>';
                $tableContent .= '<td><code style="background:#EFF6FF;padding:1px 4px;border-radius:3px;font-size:11px;font-weight:700;color:#1D4ED8">'.htmlspecialchars($kod).'</code></td>';
                $tableContent .= '<td style="font-size:11px">'.htmlspecialchars($ad).'</td>';
                foreach ($dates as $d) {
                    $val = $dateData[$d] ?? null;
                    if ($val !== null && $val > 0) {
                        $satir_top += $val;
                        $tableContent .= '<td style="text-align:right;font-weight:700">'.number_format($val,0,'','.').'</td>';
                    } else {
                        $tableContent .= '<td style="text-align:right;color:#CBD5E1">—</td>';
                    }
                }
                $tableContent .= '<td style="text-align:right;font-weight:900;color:#1E3A5F;background:#EFF6FF">'.number_format($satir_top,0,'','.').'</td>';
                $tableContent .= '</tr>';
            }
            $tableContent .= '</tbody>';
        }
    } catch(Throwable $e) {
        $hata = $e->getMessage();
    }
}
?>
<style>
#tblUretim th { background:#1E3A5F !important; color:#fff !important; }
#tblUretim td, #tblUretim th { border:1px solid #CBD5E1 !important; white-space:nowrap !important; }
#tblUretim tfoot th { background:#0F2942 !important; }
.ug-filtre { padding:3px 6px;border:1px solid #E2E8F0;border-radius:4px;font-size:11px;width:100% }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">🏭 Enjeksiyon Günlük Üretim Girişleri</h1>
    <div class="s-yol">Planlama / <b>Üretim Girişleri</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Filtre Kartı -->
<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Başlangıç Tarihi</label>
      <input type="date" name="start_date" class="form-alan"
        value="<?php echo htmlspecialchars($startDate);?>" max="<?php echo date('Y-m-d');?>">
    </div>
    <div>
      <label class="form-etiket">Bitiş Tarihi</label>
      <input type="date" name="end_date" class="form-alan"
        value="<?php echo htmlspecialchars($endDate);?>" max="<?php echo date('Y-m-d');?>">
    </div>
    <div>
      <label class="form-etiket">Mamul Kodu (opsiyonel)</label>
      <input type="text" name="mamul_kodu" class="form-alan"
        value="<?php echo htmlspecialchars($mamulKodu);?>" placeholder="Ör: 2988080600">
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      🔍 Veri Çek
    </button>
    <?php if($submitted):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-uretim-giris"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">
      ✕ Temizle
    </a>
    <?php endif;?>
    <!-- Hızlı tarih seçimleri -->
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-left:4px">
      <?php
      $hizli = [
        ['Bugün', date('Y-m-d'), date('Y-m-d')],
        ['Dün',   date('Y-m-d',strtotime('-1 day')), date('Y-m-d',strtotime('-1 day'))],
        ['7 Gün', date('Y-m-d',strtotime('-6 days')), date('Y-m-d')],
        ['Bu Ay', date('Y-m-01'), date('Y-m-d')],
      ];
      foreach($hizli as [$lbl,$s,$e]):?>
      <button type="button"
        onclick="document.querySelector('[name=start_date]').value='<?php echo $s;?>';document.querySelector('[name=end_date]').value='<?php echo $e;?>'"
        style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
        <?php echo $lbl;?>
      </button>
      <?php endforeach;?>
    </div>
  </form>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">
  ❌ <code style="font-size:12px"><?php echo htmlspecialchars($hata);?></code>
</div>
<?php endif;?>

<?php if($submitted && !$has_data && !$hata):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#888;border-radius:10px">
  <div style="font-size:32px;margin-bottom:8px">🔍</div>
  <div style="font-weight:600">Seçilen tarih aralığında üretim verisi bulunamadı.</div>
</div>
<?php endif;?>

<?php if($has_data):?>
<!-- Özet -->
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;font-size:12px;color:#374151">
  <span style="background:#EFF6FF;border:1px solid #BFDBFE;padding:4px 12px;border-radius:8px;font-weight:700">
    📅 <?php echo date('d.m.Y',strtotime($startDate));?> — <?php echo date('d.m.Y',strtotime($endDate));?>
  </span>
  <span style="background:#D1FAE5;border:1px solid #86EFAC;padding:4px 12px;border-radius:8px;font-weight:700">
    <?php echo count($dates);?> gün · <?php echo substr_count($tableContent,'<tr>')-1;?> satır
    <?php if($mamulKodu):?> · Mamul: <?php echo htmlspecialchars($mamulKodu);?><?php endif;?>
  </span>
</div>

<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblUretim" style="width:100%;border-collapse:collapse">
  <?php echo $tableContent;?>
</table>
</div>
</div>
<?php endif;?>

<?php if(!$submitted):?>
<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:40px;text-align:center;color:#94A3B8">
  <div style="font-size:40px;margin-bottom:10px">🏭</div>
  <div style="font-weight:600;font-size:14px">Tarih aralığı seçerek üretim verilerini görüntüleyin.</div>
  <div style="font-size:12px;margin-top:4px">Tiger SQL Server'dan LG_222_02_STLINE tablosu sorgulanır.</div>
</div>
<?php endif;?>

<?php endif;?>

<script>
$(document).ready(function(){
    <?php if($has_data):?>
    var tbl = $('#tblUretim').DataTable({
        initComplete: function(){
            this.api().columns([0,1]).every(function(){
                var col=this, th=$(col.footer());
                if(!th||!th.length) return;
                var sel=$('<select class="ug-filtre"><option value=""></option></select>')
                    .appendTo(th.empty())
                    .on('change',function(){
                        var v=$.fn.dataTable.util.escapeRegex($(this).val());
                        col.search(v?'^'+v+'$':'',true,false).draw();
                    });
                col.data().unique().sort().each(function(d){
                    var v=$('<div/>').html(d).text();
                    sel.append('<option value="'+v+'">'+v+'</option>');
                });
            });
            hesaplaToplamlar();
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'550px', paging:false, scrollX:true,
        dom:'Bfrtip',
        columnDefs:[{type:'num-fmt', targets:'_all'}],
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',
             filename:'Uretim_Giris_<?php echo str_replace('-','',$startDate).'_'.str_replace('-','',$endDate);?>',
             exportOptions:{format:{body:function(data,r,c,node){
                 var v=$('<div/>').html(data).text().trim().replace(/\./g,'').replace(',','.');
                 var n=parseFloat(v); return isNaN(n)?$('<div/>').html(data).text().trim():n;
             }}}
            },
            'copyHtml5','print'
        ]
    });

    function hesaplaToplamlar(){
        var api = tbl.api ? tbl : $('#tblUretim').DataTable();
        var cols = api.columns().count();
        var toplamlar = new Array(cols).fill(0);
        api.rows({search:'applied'}).every(function(){
            var data = this.node().querySelectorAll('td');
            data.forEach(function(td, i){
                var v = parseFloat(td.textContent.replace(/\./g,'').replace(',','.'));
                if(!isNaN(v)) toplamlar[i] += v;
            });
        });
        var tfoot = document.querySelector('#tblUretim tfoot tr');
        if(tfoot){
            var ths = tfoot.querySelectorAll('th');
            ths.forEach(function(th, i){
                if(i >= 3 && toplamlar[i] > 0){
                    th.textContent = toplamlar[i].toLocaleString('tr-TR',{maximumFractionDigits:0});
                    th.style.textAlign = 'right';
                }
            });
        }
    }

    $('#tblUretim').on('draw.dt', function(){ hesaplaToplamlar(); });
    <?php endif;?>
});
</script>
