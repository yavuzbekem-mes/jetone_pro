<?php
ob_start();
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$kul     = Auth::kullanici();
$kul_adi = ($kul['ad_soyad'] ?? $kul['email'] ?? '');

// ── POST ────────────────────────────────────────────────────────
if (!empty($_POST['fc_action'])) {
    ob_end_clean();
    ini_set('display_errors', 0);
    error_reporting(0);
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['fc_action'];

    if ($action === 'kaydet') {
        $data = json_decode($_POST['forecast_json'] ?? '[]', true) ?: [];
        if (empty($data)) { echo json_encode(['ok'=>false,'msg'=>'Veri yok']); exit; }
        try {
            $db->exec("CREATE TABLE IF NOT EXISTS forecast (
                id INT AUTO_INCREMENT PRIMARY KEY,
                firma VARCHAR(255) NOT NULL, stok_kodu VARCHAR(100) NOT NULL,
                stok_adi VARCHAR(500) DEFAULT '', tur VARCHAR(100) DEFAULT 'Mamul',
                yil YEAR NOT NULL, ekleyen VARCHAR(100) DEFAULT '',
                ay1 DECIMAL(12,2) DEFAULT 0, ay2 DECIMAL(12,2) DEFAULT 0,
                ay3 DECIMAL(12,2) DEFAULT 0, ay4 DECIMAL(12,2) DEFAULT 0,
                ay5 DECIMAL(12,2) DEFAULT 0, ay6 DECIMAL(12,2) DEFAULT 0,
                ay7 DECIMAL(12,2) DEFAULT 0, ay8 DECIMAL(12,2) DEFAULT 0,
                ay9 DECIMAL(12,2) DEFAULT 0, ay10 DECIMAL(12,2) DEFAULT 0,
                ay11 DECIMAL(12,2) DEFAULT 0, ay12 DECIMAL(12,2) DEFAULT 0,
                olusturma DATETIME DEFAULT CURRENT_TIMESTAMP,
                guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
            $stmt = $db->prepare("INSERT INTO forecast
                (firma,stok_kodu,stok_adi,tur,yil,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12,ekleyen)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $eklendi = 0;
            foreach ($data as $r) {
                $stmt->execute([$r['firma'],$r['stok_kodu'],$r['stok_adi'],$r['tur'],$r['yil']??date('Y'),
                    $r['ay1']??0,$r['ay2']??0,$r['ay3']??0,$r['ay4']??0,$r['ay5']??0,$r['ay6']??0,
                    $r['ay7']??0,$r['ay8']??0,$r['ay9']??0,$r['ay10']??0,$r['ay11']??0,$r['ay12']??0,$kul_adi]);
                $eklendi++;
            }
            echo json_encode(['ok'=>true,'eklendi'=>$eklendi]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }
    if ($action === 'guncelle') {
        $id=$_POST['id']??0; $kol=trim($_POST['kolon']??''); $val=trim($_POST['deger']??'');
        $izinli=['firma','stok_kodu','stok_adi','tur','yil','ay1','ay2','ay3','ay4','ay5','ay6','ay7','ay8','ay9','ay10','ay11','ay12'];
        if (!$id||!in_array($kol,$izinli,true)){echo json_encode(['ok'=>false]);exit;}
        try{$db->prepare("UPDATE forecast SET `$kol`=? WHERE id=?")->execute([$val,$id]);echo json_encode(['ok'=>true]);}
        catch(Throwable $e){echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);}
        exit;
    }
    if ($action === 'sil') {
        $ids=array_filter(array_map('intval',explode(',',$_POST['ids']??'')));
        if(empty($ids)){echo json_encode(['ok'=>false]);exit;}
        try{$ph=implode(',',array_fill(0,count($ids),'?'));$db->prepare("DELETE FROM forecast WHERE id IN($ph)")->execute(array_values($ids));echo json_encode(['ok'=>true]);}
        catch(Throwable $e){echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);}
        exit;
    }
    if ($action === 'excel_yukle') {
        if (empty($_FILES['excel']['tmp_name'])) { echo json_encode(['ok'=>false,'msg'=>'Dosya yüklenemedi']); exit; }
        try {
            require_once dirname(dirname(__DIR__)) . '/core/SimpleXLSX.php';
            $xlsx = new SimpleXLSX($_FILES['excel']['tmp_name']);
            if (!$xlsx->success()) { echo json_encode(['ok'=>false,'msg'=>'Excel okunamadı: '.$xlsx->error()]); exit; }
            $firma  = trim($_POST['excel_firma'] ?? '');
            $yil    = (int)($_POST['excel_yil']  ?? date('Y'));
            if (!$firma) { echo json_encode(['ok'=>false,'msg'=>'Firma boş']); exit; }

            $stmt = $db->prepare("INSERT INTO forecast
                (firma,stok_kodu,stok_adi,tur,yil,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12,ekleyen)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

            $eklendi = 0; $atlandi = 0;
            foreach ($xlsx->rows() as $ri => $row) {
                if ($ri === 0) continue; // başlık satırı atla
                $stok_kodu = trim($row[0] ?? '');
                $stok_adi  = trim($row[1] ?? '');
                $tur       = trim($row[2] ?? '') ?: 'Mamül';
                if (!$stok_kodu) { $atlandi++; continue; }
                $aylar_v = [];
                for ($i = 3; $i <= 14; $i++)
                    $aylar_v[] = (float)str_replace(['.',',' ],['' ,'.'], $row[$i] ?? 0);
                while (count($aylar_v) < 12) $aylar_v[] = 0;
                $stmt->execute(array_merge(
                    [$firma, $stok_kodu, $stok_adi, $tur, $yil],
                    array_slice($aylar_v, 0, 12),
                    [$kul_adi]
                ));
                $eklendi++;
            }
            echo json_encode(['ok'=>true,'eklendi'=>$eklendi,'atlandi'=>$atlandi]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }
}

// ── TABLO YOKSA OLUŞTUR ─────────────────────────────────────────
try { $db->exec("CREATE TABLE IF NOT EXISTS forecast (
    id INT AUTO_INCREMENT PRIMARY KEY, firma VARCHAR(255) NOT NULL,
    stok_kodu VARCHAR(100) NOT NULL, stok_adi VARCHAR(500) DEFAULT '', tur VARCHAR(100) DEFAULT 'Mamul',
    yil YEAR NOT NULL, ekleyen VARCHAR(100) DEFAULT '',
    ay1 DECIMAL(12,2) DEFAULT 0, ay2 DECIMAL(12,2) DEFAULT 0, ay3 DECIMAL(12,2) DEFAULT 0,
    ay4 DECIMAL(12,2) DEFAULT 0, ay5 DECIMAL(12,2) DEFAULT 0, ay6 DECIMAL(12,2) DEFAULT 0,
    ay7 DECIMAL(12,2) DEFAULT 0, ay8 DECIMAL(12,2) DEFAULT 0, ay9 DECIMAL(12,2) DEFAULT 0,
    ay10 DECIMAL(12,2) DEFAULT 0, ay11 DECIMAL(12,2) DEFAULT 0, ay12 DECIMAL(12,2) DEFAULT 0,
    olusturma DATETIME DEFAULT CURRENT_TIMESTAMP,
    guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci"); } catch(Throwable $e){}

// ── VERİ ────────────────────────────────────────────────────────
$yil_f = (int)($_GET['yil'] ?? date('Y'));
$forecasts = [];
try { $s=$db->prepare("SELECT * FROM forecast WHERE yil=? ORDER BY firma,stok_kodu"); $s->execute([$yil_f]); $forecasts=$s->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e){}

// Tiger
$t_urunler=[];$t_cariler=[];
if($tigerdb_pdo){
    try{$s=$tigerdb_pdo->query("SELECT DISTINCT IT.CODE,IT.NAME,IT.STGRPCODE FROM dbo.LG_222_ITEMS IT WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 AND IT.ACTIVE=0 AND IT.STGRPCODE IN('Mamül','Yarımamül') ORDER BY IT.CODE");$t_urunler=$s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$s=$tigerdb_pdo->query("SELECT DISTINCT CLCARD.CODE Ck, CLCARD.DEFINITION_ Cu FROM dbo.LG_222_CLCARD CLCARD WITH(NOLOCK) WHERE CLCARD.DEFINITION_ IS NOT NULL ORDER BY CLCARD.DEFINITION_ ASC");$t_cariler=$s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
}

$aylar=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$yillar=range(date('Y')-1,date('Y')+2);
$ay_su=(int)date('n');
?>
<style>
#fc-tbl{border-collapse:collapse;font-size:12px;white-space:nowrap;width:100%}
#fc-tbl thead th{background:#1E3A5F;color:#e0f0ff;padding:6px 8px;border:1px solid #2d5986;font-size:11px;font-weight:600}
#fc-tbl tbody td{padding:3px 6px;border:1px solid #E5E7EB;vertical-align:middle}
#fc-tbl tbody tr:hover td{filter:brightness(.96)}
#fc-tbl td[contenteditable=true]:focus{outline:2px solid #667EEA;background:#F0F4FF!important}
.fc-saved{background:#D1FAE5!important;transition:background .6s}.fc-err{background:#FEE2E2!important}
#fc-wrap{overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 290px)}
#fc-tbl thead{position:sticky;top:0;z-index:5}
.fc-ay{text-align:right;min-width:72px}
.fc-cb{width:16px;height:16px;cursor:pointer}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1;min-width:0">
    <h1 class="s-bas">📈 Kapasite &amp; Forecast</h1>
    <div class="s-yol">Planlama / <b>Forecast <?php echo $yil_f;?></b></div>
  </div>
  <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
    <select onchange="location.href=location.pathname+'?yil='+this.value"
      style="border:1px solid var(--kenar);border-radius:6px;padding:5px 9px;font-size:12px;font-family:inherit">
      <?php foreach($yillar as $y):?><option value="<?php echo $y;?>"<?php echo $y==$yil_f?' selected':'';?>><?php echo $y;?></option><?php endforeach;?>
    </select>
    <button onclick="fcAc()" style="background:#1E3A5F;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">➕ Forecast Ekle</button>
    <button onclick="fcExcelYukleAc()" style="background:#0369A1;color:#fff;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer">📥 Excel Yükle</button>
    <button onclick="fcExcel()" style="background:#1D6F42;color:#fff;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer">📊 Excel İndir</button>
    <button onclick="fcTopluSil()" id="fcBulkBtn" disabled style="background:#DC2626;color:#fff;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;opacity:.5">🗑 Seçilenleri Sil</button>
  </div>
</div>

<!-- Özet -->
<?php
$top=count($forecasts);$fir=count(array_unique(array_column($forecasts,'firma')));
$urn=count(array_unique(array_column($forecasts,'stok_kodu')));
$tot=0;foreach($forecasts as $f)for($i=1;$i<=12;$i++)$tot+=(float)$f['ay'.$i];
?>
<div style="display:flex;gap:8px;padding:0 0 10px;flex-wrap:wrap">
<?php foreach([['📋','Kayıt',$top,'#EFF6FF','#1E40AF'],['🏢','Firma',$fir,'#F0FDF4','#065F46'],['📦','Ürün',$urn,'#FFF7ED','#92400E'],['📊','Toplam',number_format($tot,0,',','.'),'#F3E8FF','#6B21A8']] as [$i,$e,$d,$bg,$fg]):?>
<div style="background:<?php echo $bg;?>;border:1px solid <?php echo $fg;?>33;border-radius:8px;padding:8px 14px;min-width:110px">
  <div style="font-size:10px;color:<?php echo $fg;?>"><?php echo $i.' '.$e;?></div>
  <div style="font-size:18px;font-weight:800;color:<?php echo $fg;?>"><?php echo $d;?></div>
</div>
<?php endforeach;?>
</div>

<div class="kart" style="overflow:hidden;padding:0">
<div id="fc-wrap">
<table id="fc-tbl">
  <thead><tr>
    <th style="width:28px"><input type="checkbox" class="fc-cb" id="fcSelAll"></th>
    <th style="width:28px">No</th>
    <th style="min-width:130px">Firma</th>
    <th style="min-width:100px">Stok Kodu</th>
    <th style="min-width:170px">Stok Adı</th>
    <th style="min-width:80px">Tür</th>
    <?php foreach($aylar as $ai=>$ay):?>
    <th class="fc-ay" style="background:<?php echo ($ay_su-1)===$ai?'#1D4ED8':'#1E3A5F';?>"><?php echo $ay;?></th>
    <?php endforeach;?>
    <th style="min-width:75px">Ekleyen</th>
    <th style="width:40px">Sil</th>
  </tr></thead>
  <tbody id="fc-body">
  <?php if(empty($forecasts)):?>
  <tr><td colspan="21" style="text-align:center;padding:30px;color:#94A3B8">
    <?php echo $yil_f;?> yılına ait forecast kaydı yok.
  </td></tr>
  <?php else:foreach($forecasts as $i=>$f):?>
  <tr data-id="<?php echo $f['id'];?>">
    <td><input type="checkbox" class="fc-cb fc-row-cb" value="<?php echo $f['id'];?>" onchange="fcCbDeg()"></td>
    <td style="color:#94A3B8;font-size:11px"><?php echo $i+1;?></td>
    <?php foreach(['firma','stok_kodu','stok_adi','tur'] as $kol):?>
    <td contenteditable="true" onblur="fcGuncelle(this,<?php echo $f['id'];?>,'<?php echo $kol;?>')"><?php echo htmlspecialchars($f[$kol]??'');?></td>
    <?php endforeach;?>
    <?php for($ay=1;$ay<=12;$ay++):?>
    <td class="fc-ay" contenteditable="true" onblur="fcGuncelle(this,<?php echo $f['id'];?>,'ay<?php echo $ay;?>')"><?php echo number_format((float)$f['ay'.$ay],0,',','.');?></td>
    <?php endfor;?>
    <td style="color:#64748B;font-size:11px"><?php echo htmlspecialchars($f['ekleyen']??'');?></td>
    <td style="text-align:center"><button onclick="fcSilTek(<?php echo $f['id'];?>)" style="background:#FEE2E2;color:#991B1B;border:none;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button></td>
  </tr>
  <?php endforeach;endif;?>
  </tbody>
</table>
</div></div>

<!-- ── MODAL ─────────────────────────────────────────────────── -->
<div id="fcModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:flex-start;justify-content:center;padding:16px;overflow-y:auto">
<div style="background:#fff;border-radius:14px;width:100%;max-width:1100px;box-shadow:0 20px 60px rgba(0,0,0,.25);margin:auto">
  <div style="background:linear-gradient(135deg,#1E3A5F,#2d5986);border-radius:14px 14px 0 0;padding:14px 20px;display:flex;align-items:center;justify-content:space-between">
    <div>
      <div style="color:#fff;font-size:15px;font-weight:800">📈 Yeni Forecast Girişi</div>
      <div style="color:rgba(255,255,255,.7);font-size:11px">Ürün bazlı aylık tahmin verileri</div>
    </div>
    <button onclick="fcKapat()" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:20px">
    <!-- Firma + Yıl -->
    <div style="display:grid;grid-template-columns:1fr 1fr 120px;gap:12px;margin-bottom:14px">
      <div>
        <label class="form-etiket">Firma (Tiger'dan seç)</label>
        <select id="fcFirma" class="form-alan" onchange="document.getElementById('fcFirmaYaz').value=''">
          <option value="">Seçin...</option>
          <?php foreach($t_cariler as $c):?><option value="<?php echo htmlspecialchars($c['Cu']);?>"><?php echo htmlspecialchars($c['Cu']);?></option><?php endforeach;?>
          <?php if(empty($t_cariler)):?><option value="">Tiger bağlantısı yok</option><?php endif;?>
        </select>
      </div>
      <div>
        <label class="form-etiket">veya Firma Adı Yaz</label>
        <input type="text" id="fcFirmaYaz" class="form-alan" placeholder="Firma adı..." oninput="document.getElementById('fcFirma').value=''">
      </div>
      <div>
        <label class="form-etiket">Yıl</label>
        <select id="fcYil" class="form-alan">
          <?php foreach($yillar as $y):?><option value="<?php echo $y;?>"<?php echo $y==date('Y')?' selected':'';?>><?php echo $y;?></option><?php endforeach;?>
        </select>
      </div>
    </div>

    <!-- Ürün Ekle Bölümü -->
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:10px 12px;margin-bottom:12px">
      <div style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap">
        <div style="flex:1;min-width:200px">
          <label class="form-etiket">Ürün Seç (Tiger)</label>
          <select id="fcUrun" class="form-alan">
            <option value="">Ürün seçin...</option>
            <?php foreach($t_urunler as $u):?>
            <option value="<?php echo htmlspecialchars($u['CODE']);?>" data-ad="<?php echo htmlspecialchars($u['NAME']);?>" data-tur="<?php echo htmlspecialchars($u['STGRPCODE']);?>">
              <?php echo htmlspecialchars($u['CODE']);?> — <?php echo mb_substr($u['NAME'],0,50);?>
            </option>
            <?php endforeach;?>
          </select>
        </div>
        <button onclick="fcSatirEkle()" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">➕ Ekle</button>
        <button onclick="fcManuel()" style="background:#7C3AED;color:#fff;border:none;padding:8px 14px;border-radius:6px;font-size:12px;cursor:pointer">✏ Manuel Satır</button>
      </div>
    </div>

    <!-- Giriş Tablosu -->
    <div style="overflow-x:auto;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:16px">
    <table style="border-collapse:collapse;font-size:12px;width:100%;white-space:nowrap">
      <thead><tr style="background:#1E3A5F">
        <th style="color:#e0f0ff;padding:7px 10px;border:1px solid #2d5986;min-width:110px">Stok Kodu</th>
        <th style="color:#e0f0ff;padding:7px 10px;border:1px solid #2d5986;min-width:175px">Stok Adı</th>
        <th style="color:#e0f0ff;padding:7px 10px;border:1px solid #2d5986;min-width:80px">Tür</th>
        <?php foreach($aylar as $ay):?><th style="color:#e0f0ff;padding:7px 8px;border:1px solid #2d5986;min-width:68px;text-align:center"><?php echo $ay;?></th><?php endforeach;?>
        <th style="color:#e0f0ff;padding:7px 10px;border:1px solid #2d5986;width:45px">Sil</th>
      </tr></thead>
      <tbody id="fcGBody">
        <tr id="fcEmpty"><td colspan="16" style="text-align:center;padding:20px;color:#94A3B8">Ürün ekleyin</td></tr>
      </tbody>
    </table>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="fcKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 20px;border-radius:8px;font-size:12px;cursor:pointer">İptal</button>
      <button onclick="fcKaydet()" id="fcKBtn" style="background:linear-gradient(135deg,#1E3A5F,#2d5986);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
    </div>
  </div>
</div>
</div>

<script>
var _fcN=0;
// Checkbox
document.getElementById('fcSelAll').addEventListener('change',function(){
  document.querySelectorAll('.fc-row-cb').forEach(cb=>cb.checked=this.checked);fcCbDeg();
});
function fcCbDeg(){
  var n=document.querySelectorAll('.fc-row-cb:checked').length;
  var b=document.getElementById('fcBulkBtn');b.disabled=!n;b.style.opacity=n?'1':'.5';
}
// Inline güncelle
function fcGuncelle(el,id,kol){
  var val=el.textContent.trim();
  if(kol.startsWith('ay'))val=val.replace(/\./g,'').replace(/,/g,'');
  var fd=new FormData();fd.append('fc_action','guncelle');fd.append('id',id);fd.append('kolon',kol);fd.append('deger',val);
  fetch(BASE_URL+'/bolumler/planlama/ajax/forecast_ajax.php',{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(r=>r.json()).then(d=>{
    el.classList.remove('fc-err');
    if(d.ok){el.classList.add('fc-saved');setTimeout(()=>el.classList.remove('fc-saved'),1500);}
    else el.classList.add('fc-err');
  });
}
// Sil
function fcSilTek(id){if(!confirm('Silinsin mi?'))return;fcSilIstek(id+'');}
function fcTopluSil(){
  var ids=[...document.querySelectorAll('.fc-row-cb:checked')].map(c=>c.value).join(',');
  if(!ids)return;if(!confirm(ids.split(',').length+' kayıt silinsin mi?'))return;
  fcSilIstek(ids);
}
function fcSilIstek(ids){
  var fd=new FormData();fd.append('fc_action','sil');fd.append('ids',ids);
  fetch(BASE_URL+'/bolumler/planlama/ajax/forecast_ajax.php',{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(r=>r.json()).then(d=>{if(d.ok)location.reload();else alert('Hata:'+(d.msg||''));});
}
// Excel
function fcExcel(){
  var rows=[],hdr=[];
  document.querySelectorAll('#fc-tbl thead th').forEach((th,i)=>{if(i!==0&&i!==document.querySelectorAll('#fc-tbl thead th').length-1)hdr.push('"'+th.textContent.trim()+'"');});
  rows.push(hdr.join(';'));
  document.querySelectorAll('#fc-body tr').forEach(tr=>{
    var cells=[];tr.querySelectorAll('td').forEach((td,i)=>{if(i!==0&&i!==tr.querySelectorAll('td').length-1)cells.push('"'+td.textContent.trim().replace(/\n/g,' ').replace(/"/g,'""')+'"');});
    if(cells.length)rows.push(cells.join(';'));
  });
  var blob=new Blob(['\uFEFF'+rows.join('\n')],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='Forecast_<?php echo $yil_f;?>_'+new Date().toISOString().slice(0,10)+'.csv';a.click();
}
// Modal
function fcAc(){document.getElementById('fcModal').style.display='flex';document.getElementById('fcGBody').innerHTML='<tr id="fcEmpty"><td colspan="16" style="text-align:center;padding:20px;color:#94A3B8">Ürün ekleyin</td></tr>';_fcN=0;}
function fcKapat(){document.getElementById('fcModal').style.display='none';}
// Satır Ekle
function fcSatirEkle(){
  var sel=document.getElementById('fcUrun');
  var opt=sel.selectedOptions[0];
  if(!sel.value){alert('Ürün seçin');return;}
  if(document.querySelector('#fcGBody tr[data-kod="'+sel.value+'"]')){alert('Bu ürün zaten var');return;}
  _fcSatirOlustur(sel.value,opt.dataset.ad||'',opt.dataset.tur||'Mamül');
  sel.value='';
}
function fcManuel(){_fcSatirOlustur('','','Mamül');}
function _fcSatirOlustur(kod,ad,tur){
  _fcN++;var n=_fcN;
  var em=document.getElementById('fcEmpty');if(em)em.remove();
  var ayInp='';
  for(var i=1;i<=12;i++){
    ayInp+='<td style="padding:2px"><input type="number" id="fc_a'+i+'_'+n+'" min="0" value="0" '+
      'style="width:66px;text-align:right;border:1px solid #E2E8F0;border-radius:4px;padding:3px 5px;font-size:12px"></td>';
  }
  var tr=document.createElement('tr');tr.dataset.n=n;tr.dataset.kod=kod;
  tr.innerHTML='<td><input type="text" id="fc_k_'+n+'" value="'+esc(kod)+'" placeholder="Kod" style="width:100px;border:1px solid #E2E8F0;border-radius:4px;padding:4px;font-size:12px"></td>'+
    '<td><input type="text" id="fc_a_'+n+'" value="'+esc(ad)+'" placeholder="Ad" style="width:170px;border:1px solid #E2E8F0;border-radius:4px;padding:4px;font-size:12px"></td>'+
    '<td><input type="text" id="fc_t_'+n+'" value="'+esc(tur)+'" placeholder="Tür" style="width:75px;border:1px solid #E2E8F0;border-radius:4px;padding:4px;font-size:12px"></td>'+
    ayInp+'<td style="text-align:center"><button onclick="this.closest(\'tr\').remove()" style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 7px;border-radius:4px;cursor:pointer">🗑</button></td>';
  document.getElementById('fcGBody').appendChild(tr);
}
// Kaydet
function fcKaydet(){
  var firma=document.getElementById('fcFirmaYaz').value.trim()||document.getElementById('fcFirma').value;
  var yil=document.getElementById('fcYil').value;
  if(!firma){alert('Firma seçin veya yazın');return;}
  var satirlar=document.querySelectorAll('#fcGBody tr[data-n]');
  if(!satirlar.length){alert('En az bir ürün ekleyin');return;}
  var data=[];var hata=false;
  satirlar.forEach(tr=>{
    var n=tr.dataset.n;
    var kod=document.getElementById('fc_k_'+n).value.trim();
    if(!kod){alert('Stok kodu boş olamaz');hata=true;return;}
    var r={firma:firma,stok_kodu:kod,stok_adi:document.getElementById('fc_a_'+n).value.trim(),
           tur:document.getElementById('fc_t_'+n).value.trim()||'Mamül',yil:yil};
    for(var i=1;i<=12;i++)r['ay'+i]=parseInt(document.getElementById('fc_a'+i+'_'+n).value)||0;
    data.push(r);
  });
  if(hata||!data.length)return;
  var btn=document.getElementById('fcKBtn');btn.disabled=true;btn.textContent='Kaydediliyor...';
  var fd=new FormData();fd.append('fc_action','kaydet');fd.append('forecast_json',JSON.stringify(data));
  fetch(BASE_URL+'/bolumler/planlama/ajax/forecast_ajax.php',{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(r=>r.json()).then(d=>{
    btn.disabled=false;btn.textContent='💾 Kaydet';
    if(d.ok){fcKapat();location.reload();}else alert('Hata:'+(d.msg||''));
  }).catch(e=>{btn.disabled=false;btn.textContent='💾 Kaydet';alert('Hata:'+e.message);});
}
function esc(t){return(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){fcKapat();fcExcelKapat();}});
</script>

<!-- ── EXCEL YÜKLEME MODALİ ───────────────────────────────────── -->
<div id="fcExcelModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1002;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:560px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="background:linear-gradient(135deg,#0369A1,#0284C7);border-radius:14px 14px 0 0;padding:14px 20px;display:flex;align-items:center;justify-content:space-between">
    <div>
      <div style="color:#fff;font-size:15px;font-weight:800">📥 Excel ile Forecast Yükle</div>
      <div style="color:rgba(255,255,255,.75);font-size:11px">Toplu veri yükleme</div>
    </div>
    <button onclick="fcExcelKapat()" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:20px">

    <!-- Format bilgisi -->
    <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:12px;margin-bottom:16px;font-size:12px;color:#1E40AF">
      <strong>📋 Excel Dosya Formatı:</strong><br><br>
      <table style="border-collapse:collapse;width:100%;font-size:11px">
        <tr style="background:#DBEAFE">
          <th style="padding:4px 8px;border:1px solid #BFDBFE;text-align:left">Sütun</th>
          <th style="padding:4px 8px;border:1px solid #BFDBFE;text-align:left">İçerik</th>
        </tr>
        <tr><td style="padding:3px 8px;border:1px solid #BFDBFE">A</td><td style="padding:3px 8px;border:1px solid #BFDBFE">Stok Kodu</td></tr>
        <tr><td style="padding:3px 8px;border:1px solid #BFDBFE">B</td><td style="padding:3px 8px;border:1px solid #BFDBFE">Stok Adı</td></tr>
        <tr><td style="padding:3px 8px;border:1px solid #BFDBFE">C</td><td style="padding:3px 8px;border:1px solid #BFDBFE">Tür (Mamül, Yarımamül...)</td></tr>
        <tr><td style="padding:3px 8px;border:1px solid #BFDBFE">D–O</td><td style="padding:3px 8px;border:1px solid #BFDBFE">Ocak – Aralık (sayısal)</td></tr>
      </table>
      <div style="margin-top:6px;font-size:10px;color:#3B82F6">* 1. satır başlık olarak atlanır. Firma ve yıl aşağıdan seçilir.</div>
    </div>

    <form id="fcExcelForm">
      <div style="display:grid;grid-template-columns:1fr 120px;gap:10px;margin-bottom:12px">
        <div>
          <label class="form-etiket">Firma *</label>
          <select id="fcExcelFirma" class="form-alan">
            <option value="">Seçin veya yazın...</option>
            <?php foreach($t_cariler as $c):?><option value="<?php echo htmlspecialchars($c['Cu']);?>"><?php echo htmlspecialchars($c['Cu']);?></option><?php endforeach;?>
          </select>
          <input type="text" id="fcExcelFirmaYaz" class="form-alan" placeholder="veya firma adı yazın..." style="margin-top:4px">
        </div>
        <div>
          <label class="form-etiket">Yıl</label>
          <select id="fcExcelYil" class="form-alan">
            <?php foreach($yillar as $y):?><option value="<?php echo $y;?>"<?php echo $y==date('Y')?' selected':'';?>><?php echo $y;?></option><?php endforeach;?>
          </select>
        </div>
      </div>

      <div style="margin-bottom:16px">
        <label class="form-etiket">Excel Dosyası (.xlsx) *</label>
        <input type="file" id="fcExcelDosya" accept=".xlsx,.xls"
          style="display:block;width:100%;border:2px dashed #CBD5E1;border-radius:8px;padding:12px;font-size:12px;cursor:pointer;background:#F8FAFC"
          onchange="this.style.borderColor='#667EEA'">
      </div>

      <div id="fcExcelSonuc" style="display:none;padding:10px 12px;border-radius:8px;font-size:12px;margin-bottom:12px"></div>

      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" onclick="fcExcelKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 20px;border-radius:8px;font-size:12px;cursor:pointer">İptal</button>
        <button type="button" onclick="fcExcelYukle()" id="fcExcelBtn"
          style="background:linear-gradient(135deg,#0369A1,#0284C7);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">
          📥 Yükle
        </button>
      </div>
    </form>
  </div>
</div>
</div>

<script>
function fcExcelYukleAc(){ document.getElementById('fcExcelModal').style.display='flex'; }
function fcExcelKapat(){ document.getElementById('fcExcelModal').style.display='none'; }
function fcExcelYukle(){
  var firma = document.getElementById('fcExcelFirmaYaz').value.trim() ||
              document.getElementById('fcExcelFirma').value;
  var yil   = document.getElementById('fcExcelYil').value;
  var dosya = document.getElementById('fcExcelDosya').files[0];
  if (!firma){ alert('Firma seçin veya yazın'); return; }
  if (!dosya){ alert('Excel dosyası seçin'); return; }

  var btn = document.getElementById('fcExcelBtn');
  btn.disabled = true; btn.textContent = 'Yükleniyor...';

  var fd = new FormData();
  fd.append('fc_action', 'excel_yukle');
  fd.append('excel', dosya);
  fd.append('excel_firma', firma);
  fd.append('excel_yil', yil);

  fetch(BASE_URL+'/bolumler/planlama/ajax/forecast_ajax.php', {method:'POST', body:fd, credentials:'same-origin', headers:{'X-Requested-With':'XMLHttpRequest'}})
  .then(r => r.json())
  .then(d => {
    btn.disabled = false; btn.textContent = '📥 Yükle';
    var sonuc = document.getElementById('fcExcelSonuc');
    sonuc.style.display = 'block';
    if (d.ok) {
      sonuc.style.background = '#D1FAE5'; sonuc.style.color = '#065F46';
      sonuc.textContent = '✅ ' + d.eklendi + ' kayıt eklendi.' + (d.atlandi ? ' ' + d.atlandi + ' satır atlandı (boş kod).' : '');
      setTimeout(() => { fcExcelKapat(); location.reload(); }, 1500);
    } else {
      sonuc.style.background = '#FEE2E2'; sonuc.style.color = '#991B1B';
      sonuc.textContent = '❌ Hata: ' + (d.msg || 'Bilinmeyen hata');
    }
  })
  .catch(e => {
    btn.disabled = false; btn.textContent = '📥 Yükle';
    alert('Hata: ' + e.message);
  });
}
</script>
