<?php
ob_start();
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(60);

// ── PARAMETRELER ──────────────────────────────────────────────────
$verimlilik  = max(1, min(100, (int)($_GET['verim'] ?? 100)));
$sel_yil     = (int)($_GET['yil'] ?? date('Y'));
$ay_su       = (int)date('n');

// ── TÜRKİYE RESMİ TATİLLERİ ──────────────────────────────────────
// Kural: Pazar = tatil, Cumartesi = çalışma, resmi tatil Pazar'a denk gelirse sayılmaz
// Yıla göre resmi tatil tarihleri (sabit + değişken)
function resmi_tatiller(int $yil): array {
    $tatiller = [
        // Sabit tatiller
        "$yil-01-01", // Yılbaşı
        "$yil-04-23", // Ulusal Egemenlik ve Çocuk Bayramı
        "$yil-05-01", // İşçi Bayramı
        "$yil-05-19", // Atatürk'ü Anma, Gençlik ve Spor Bayramı
        "$yil-07-15", // Demokrasi ve Millî Birlik Günü
        "$yil-08-30", // Zafer Bayramı
        "$yil-10-28", // Cumhuriyet Bayramı (yarım gün — tam gün sayıyoruz)
        "$yil-10-29", // Cumhuriyet Bayramı
    ];

    // Ramazan Bayramı (Arefe 0.5 + 3 gün) — yaklaşık hesap
    // 2024: 10 Nisan, 2025: 30 Mart, 2026: 20 Mart, 2027: 9 Mart
    $ramazan = [
        2024 => '2024-04-10', 2025 => '2025-03-30',
        2026 => '2026-03-20', 2027 => '2027-03-09',
        2028 => '2028-02-26', 2029 => '2029-02-14',
    ];
    // Kurban Bayramı (Arefe 0.5 + 4 gün)
    // 2024: 16 Haziran, 2025: 6 Haziran, 2026: 26 Mayıs, 2027: 16 Mayıs
    $kurban = [
        2024 => '2024-06-16', 2025 => '2025-06-06',
        2026 => '2026-05-26', 2027 => '2027-05-16',
        2028 => '2028-05-04', 2029 => '2029-04-23',
    ];

    // Ramazan Bayramı: arefe dahil 3.5 gün → arefe + 3 gün tam tatil ekle
    if (isset($ramazan[$yil])) {
        $base = new DateTime($ramazan[$yil]);
        $arefe = (clone $base)->modify('-1 day');
        $tatiller[] = $arefe->format('Y-m-d'); // arefe (yarım gün → tam ekle)
        for ($i = 0; $i < 3; $i++) {
            $tatiller[] = (clone $base)->modify("+$i days")->format('Y-m-d');
        }
    }

    // Kurban Bayramı: arefe dahil 4.5 gün
    if (isset($kurban[$yil])) {
        $base = new DateTime($kurban[$yil]);
        $arefe = (clone $base)->modify('-1 day');
        $tatiller[] = $arefe->format('Y-m-d');
        for ($i = 0; $i < 4; $i++) {
            $tatiller[] = (clone $base)->modify("+$i days")->format('Y-m-d');
        }
    }

    return array_unique($tatiller);
}

// Her ay için gerçek çalışma günü hesapla
// Çalışma: Pazartesi–Cumartesi, Pazar ve resmi tatiller hariç
function ay_calisma_gun(int $yil, int $ay, array $tatiller): array {
    $toplam = 0;
    $tatil_gun = 0;
    $gun_sayisi = cal_days_in_month(CAL_GREGORIAN, $ay, $yil);
    for ($g = 1; $g <= $gun_sayisi; $g++) {
        $tarih = sprintf('%04d-%02d-%02d', $yil, $ay, $g);
        $dt    = new DateTime($tarih);
        $hafta = (int)$dt->format('N'); // 1=Pzt, 7=Paz
        if ($hafta === 7) continue; // Pazar — çalışılmıyor
        $toplam++;
        if (in_array($tarih, $tatiller)) $tatil_gun++;
    }
    return ['toplam' => $toplam, 'tatil' => $tatil_gun, 'calisma' => $toplam - $tatil_gun];
}

$tatiller_listesi = resmi_tatiller($sel_yil);

// ay_gun_bilgi[ay] = ['calisma'=>N, 'tatil'=>N, 'etkin'=>N]
$ay_gun_bilgi = [];
for ($ay = 1; $ay <= 12; $ay++) {
    $b = ay_calisma_gun($sel_yil, $ay, $tatiller_listesi);
    $ay_gun_bilgi[$ay] = [
        'calisma' => $b['calisma'],
        'tatil'   => $b['tatil'],
        'etkin'   => $b['calisma'] * $verimlilik / 100,
    ];
}

// Ortalama etkin kapasite (bilgi amaçlı)
$etkin_kap_ort = array_sum(array_column($ay_gun_bilgi, 'etkin')) / 12;
$etkin_kap = $etkin_kap_ort; // geriye dönük uyumluluk için

// ── HAT LİSTESİ sabit sıralı 32 hat ──────────────────────────────
$hat_sirasi = [
    'EL İŞÇİLİĞİ 1','EL İŞÇİLİĞİ 2','EL İŞÇİLİĞİ 3','EL İŞÇİLİĞİ 4',
    'EL İŞÇİLİĞİ 5',
    'EL İŞÇİLİĞİ 6','EL İŞÇİLİĞİ 6.1','EL İŞÇİLİĞİ 6.2','EL İŞÇİLİĞİ 6.3',
    'EL İŞÇİLİĞİ 7','EL İŞÇİLİĞİ 7.1',
    'EL İŞÇİLİĞİ 8','EL İŞÇİLİĞİ 8.1','EL İŞÇİLİĞİ 8.2',
    'EL İŞÇİLİĞİ 9','EL İŞÇİLİĞİ 10',
    'MT-01','SR-01','FSN-01','KRM-01','TERM-01',
];

// Norm personel sayısı — toplam ihtiyaç bu kişi sayısına bölünür
// Tanımlanmayan hatlar için varsayılan: 1 (tek kişilik hat)
$hat_personel = [
    'EL İŞÇİLİĞİ 1'   => 3,  // BX-ABX grubu
    'EL İŞÇİLİĞİ 5'   => 3,  // BX-ABX grubu
    'EL İŞÇİLİĞİ 6'   => 4,  // HAZNE
    'EL İŞÇİLİĞİ 6.1' => 6,  // ÇAY
    'EL İŞÇİLİĞİ 6.2' => 8,  // DEMLEME
    'EL İŞÇİLİĞİ 6.3' => 4,  // PROYO
    'EL İŞÇİLİĞİ 7'   => 9,  // ŞASE
    'EL İŞÇİLİĞİ 7.1' => 2,  // ÇİFTLİ
    'EL İŞÇİLİĞİ 8'   => 4,  //
    'EL İŞÇİLİĞİ 8.1' => 4,  //
    'EL İŞÇİLİĞİ 8.2' => 2,  //
    'EL İŞÇİLİĞİ 9'   => 6,  // ABM KKLI
    'EL İŞÇİLİĞİ 10'  => 5,  // ABM KKLI
];

// Hat çalışma saati/gün ve vardiya sayısı
// 3 vardiya = 21 saat/gün, 1 vardiya = 7 saat/gün
$hat_3vardiya = [
    'EL İŞÇİLİĞİ 1', 'EL İŞÇİLİĞİ 5',
    'EL İŞÇİLİĞİ 9', 'EL İŞÇİLİĞİ 10',
    'MT-01',
];
// Hat başına günlük çalışma saati
$hat_saat = []; // hat => saat/gün
foreach ($hat_sirasi as $h) {
    $hat_saat[$h] = in_array($h, $hat_3vardiya) ? 21 : 7;
}
// 3 vardiya hatlarda toplam personel = norm_personel × 3 vardiya
$hat_personel_toplam = []; // personel sekmesi için
foreach ($hat_sirasi as $h) {
    $norm = $hat_personel[$h] ?? 1;
    $hat_personel_toplam[$h] = in_array($h, $hat_3vardiya) ? $norm * 3 : $norm;
}

// Hat → Tonaj grubu eşlemesi (montajda kullanılmıyor ama enjeksiyon uyumluluğu için)
$hat_tonaj = [];

// ── DB: HAT ATAMALARI ─────────────────────────────────────────────
$hat_atamalari = [];
try {
    $rows = $db->query("SELECT stok_kodu, ist_kodu FROM norm_hat_atamalari WHERE ist_turu='montaj'")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) $hat_atamalari[trim($r['stok_kodu'])] = trim($r['ist_kodu']);
} catch(Throwable $e) {}

// ── DB: MONTAJ HAT PERSONEL ───────────────────────────────────────
// DB'den norm personel ve vardiya oku, yoksa PHP sabitlerini kullan
try {
    $db->exec("CREATE TABLE IF NOT EXISTS montaj_hat_personel (
        id INT AUTO_INCREMENT PRIMARY KEY, hat_kodu VARCHAR(100) NOT NULL,
        norm_pers TINYINT UNSIGNED NOT NULL DEFAULT 1, vardiya TINYINT UNSIGNED NOT NULL DEFAULT 1,
        notlar VARCHAR(255) DEFAULT NULL, guncelleyen VARCHAR(100) DEFAULT NULL,
        guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_hat (hat_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    $mhp_rows = $db->query("SELECT hat_kodu, norm_pers, vardiya FROM montaj_hat_personel")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($mhp_rows as $r) {
        $hk = trim($r['hat_kodu']);
        $hat_personel[$hk] = (int)$r['norm_pers'];
        if ((int)$r['vardiya'] === 3) {
            if (!in_array($hk, $hat_3vardiya)) $hat_3vardiya[] = $hk;
        } else {
            $hat_3vardiya = array_values(array_diff($hat_3vardiya, [$hk]));
        }
    }
} catch(Throwable $e) {}
// Güncel saatleri ve toplam personeli yeniden hesapla
foreach ($hat_sirasi as $h) {
    $hat_saat[$h] = in_array($h, $hat_3vardiya) ? 21 : 7;
    $norm = $hat_personel[$h] ?? 1;
    $hat_personel_toplam[$h] = in_array($h, $hat_3vardiya) ? $norm * 3 : $norm;
}

// ── DB: HAT BÖLME (ürün bazlı %oran) ─────────────────────────────
// stok_kodu => ['hat1'=>..., 'oran1'=>..., 'hat2'=>..., 'oran2'=>...]
$hat_bolme = [];
try {
    $db->exec("CREATE TABLE IF NOT EXISTS hat_bolme (
        id INT AUTO_INCREMENT PRIMARY KEY, stok_kodu VARCHAR(100) NOT NULL,
        hat1_kodu VARCHAR(50) NOT NULL, hat1_oran DECIMAL(5,2) NOT NULL DEFAULT 50.00,
        hat2_kodu VARCHAR(50) NOT NULL, hat2_oran DECIMAL(5,2) NOT NULL DEFAULT 50.00,
        notlar VARCHAR(255) DEFAULT NULL, guncelleyen VARCHAR(100) DEFAULT NULL,
        guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_stok (stok_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    $rows = $db->query("SELECT * FROM hat_bolme")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $hat_bolme[trim($r['stok_kodu'])] = [
            'hat1' => trim($r['hat1_kodu']), 'oran1' => (float)$r['hat1_oran'],
            'hat2' => trim($r['hat2_kodu']), 'oran2' => (float)$r['hat2_oran'],
        ];
    }
} catch(Throwable $e) {}

// ── DB: MANUEL BOM (Tiger BOM'u olmayan ürünler için) ─────────────
$manuel_bom_data = []; // mamul_kodu => [alt_kodu => miktar]
try {
    $db->exec("CREATE TABLE IF NOT EXISTS manuel_bom (
        id INT AUTO_INCREMENT PRIMARY KEY,
        mamul_kodu VARCHAR(100) NOT NULL, mamul_adi VARCHAR(500) DEFAULT '',
        alt_kodu VARCHAR(100) NOT NULL, alt_adi VARCHAR(500) DEFAULT '',
        miktar DECIMAL(10,4) NOT NULL DEFAULT 1.0000, birim VARCHAR(20) DEFAULT 'ADET',
        notlar VARCHAR(255) DEFAULT NULL, guncelleyen VARCHAR(100) DEFAULT NULL,
        guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_mamul (mamul_kodu), INDEX idx_alt (alt_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    $rows = $db->query("SELECT mamul_kodu, alt_kodu, miktar FROM manuel_bom")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $mk = trim($r['mamul_kodu']); $ak = trim($r['alt_kodu']);
        if (!isset($manuel_bom_data[$mk])) $manuel_bom_data[$mk] = [];
        $manuel_bom_data[$mk][$ak] = (float)$r['miktar'];
    }
} catch(Throwable $e) {}

// ── DB: FORECAST VERİLERİ ─────────────────────────────────────────
$forecast = []; // stok_kodu => [ay1..ay12]
try {
    $s = $db->prepare("SELECT stok_kodu,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12 FROM forecast WHERE yil=?");
    $s->execute([$sel_yil]);
    foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r)
        $forecast[trim($r['stok_kodu'])] = $r;
} catch(Throwable $e) {}

// ── TIGER: BOM VERİSİ (mamul → alt malzeme miktarı) ──────────────
// bom[mamul_kodu][alt_kodu] = miktar
$bom = [];
if ($tigerdb_pdo) {
    try {
        $stmt = $tigerdb_pdo->query("
            SELECT IT.CODE MAMUL, IT2.CODE ALT, BML.AMOUNT MIKTAR
            FROM dbo.LG_222_BOMLINE BML WITH(NOLOCK)
            JOIN dbo.LG_222_BOMREVSN BMR WITH(NOLOCK) ON BML.BOMREVREF=BMR.LOGICALREF AND BMR.ACTIVE=1
            JOIN dbo.LG_222_BOMASTER BOM WITH(NOLOCK) ON BMR.BOMMASTERREF=BOM.LOGICALREF AND BOM.ACTIVE=0
            JOIN dbo.LG_222_ITEMS IT  WITH(NOLOCK) ON BOM.MAINPRODREF=IT.LOGICALREF
            JOIN dbo.LG_222_ITEMS IT2 WITH(NOLOCK) ON BML.ITEMREF=IT2.LOGICALREF
            WHERE BML.LINETYPE=0 AND IT.ACTIVE=0 AND IT2.ACTIVE=0");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $mamul = trim($r['MAMUL']); $alt = trim($r['ALT']);
            if (!isset($bom[$mamul])) $bom[$mamul] = [];
            $bom[$mamul][$alt] = (float)$r['MIKTAR'];
        }
    } catch(Throwable $e) {}
}

// ── BOM PATLAMA: forecast ürünlerinden alt malzeme ihtiyacı ───────
// Forecast ürün kodu doğrudan op_data'da yoksa BOM'dan patlat
// hesap_forecast[stok_kodu][ay] = toplam ihtiyaç (direkt + BOM türetilmiş)
$hesap_forecast = []; // stok_kodu => [1..12 => miktar]

foreach ($forecast as $mamul_kodu => $fc) {
    // Direkt forecast ürünü EN- hattı var mı?
    $mamul_en_op = isset($op_data[$mamul_kodu]);

    if ($mamul_en_op) {
        // Mamulün kendisi EN- hattında — direkt ekle
        for ($ay=1;$ay<=12;$ay++) {
            $m = (float)($fc['ay'.$ay] ?? 0);
            if ($m > 0) $hesap_forecast[$mamul_kodu][$ay] = ($hesap_forecast[$mamul_kodu][$ay] ?? 0) + $m;
        }
    }

    // BOM patlama: mamulün alt malzemelerini bul
    if (!empty($bom[$mamul_kodu])) {
        foreach ($bom[$mamul_kodu] as $alt_kodu => $bom_miktar) {
            // Alt malzemenin EN- operasyonu var mı?
            if (!isset($op_data[$alt_kodu])) continue;
            for ($ay=1;$ay<=12;$ay++) {
                $mamul_m = (float)($fc['ay'.$ay] ?? 0);
                if ($mamul_m <= 0) continue;
                $ihtiyac = $mamul_m * $bom_miktar;
                $hesap_forecast[$alt_kodu][$ay] = ($hesap_forecast[$alt_kodu][$ay] ?? 0) + $ihtiyac;
            }
        }
    }
}

// ── TIGER: OPERASYON (sadece EN-% hatlar) ─────────────────────────
// stok_kodu => ['ist_kodu'=>..., 'cevrim_sn'=>..., 'parti'=>...]
$op_data = [];
if ($tigerdb_pdo) {
    try {
        $stmt = $tigerdb_pdo->query("
            SELECT IT.CODE STOK_KODU, IT.NAME STOK_ADI, WRK.CODE IST_KODU,
                   dbo.LG_INTTOTIME2(OPR.RUNTIME) CEVRIM_SN, OPR.BATCHQUANTITY PARTI
            FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
            INNER JOIN dbo.LG_222_BOMASTER BOM WITH(NOLOCK) ON BOM.MAINPRODREF=IT.LOGICALREF AND BOM.ACTIVE=0
            INNER JOIN dbo.LG_222_BOMREVSN BMR WITH(NOLOCK) ON BMR.BOMMASTERREF=BOM.LOGICALREF AND BMR.ACTIVE=1
            INNER JOIN dbo.LG_222_ROUTING RT WITH(NOLOCK) ON RT.LOGICALREF=BMR.ROUTINGREF
            INNER JOIN dbo.LG_222_RTNGLINE RTL WITH(NOLOCK) ON RTL.ROUTINGREF=RT.LOGICALREF
            INNER JOIN dbo.LG_222_OPERTION OP WITH(NOLOCK) ON OP.LOGICALREF=RTL.OPERATIONREF
            LEFT JOIN dbo.LG_222_OPRTREQ OPR WITH(NOLOCK) ON OPR.OPERATIONREF=OP.LOGICALREF
            LEFT JOIN dbo.LG_222_WORKSTAT WRK WITH(NOLOCK) ON WRK.LOGICALREF=OPR.WSREF
            WHERE OP.CODE<>'SKOP.001' AND IT.ACTIVE=0
              AND WRK.CODE NOT LIKE 'EN-%' AND WRK.CODE IS NOT NULL AND OPR.RUNTIME>0
            ORDER BY IT.CODE, WRK.CODE");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $kod = trim($r['STOK_KODU']);
            $hat = trim($r['IST_KODU']);
            $cevrim_sn = (float)$r['CEVRIM_SN'];
            if ($cevrim_sn <= 0) continue;
            // Her ürün için tüm EN- hatlarını sakla: op_data[stok][hat] = [...]
            if (!isset($op_data[$kod])) {
                $op_data[$kod] = [
                    '_adi'  => trim($r['STOK_ADI'] ?? ''),
                    '_ilk'  => $hat, // ilk hat (fallback)
                    'hatlar'=> [],
                ];
            }
            $op_data[$kod]['hatlar'][$hat] = [
                'cevrim_sn' => $cevrim_sn,
                'parti'     => max(1, (float)($r['PARTI'] ?? 1)),
            ];
        }
    } catch(Throwable $e) {}
}

// BOM patlama için op_data artık hazır — hesap_forecast'ı güncelle
// (BOM patlama yukarıda op_data öncesi yazıldı — şimdi tekrar düzelt)
$hesap_forecast = [];
foreach ($forecast as $mamul_kodu => $fc) {
    $mamul_en_op = isset($op_data[$mamul_kodu]);
    if ($mamul_en_op) {
        for ($ay=1;$ay<=12;$ay++) {
            $m=(float)($fc['ay'.$ay]??0);
            if($m>0) $hesap_forecast[$mamul_kodu][$ay]=($hesap_forecast[$mamul_kodu][$ay]??0)+$m;
        }
    }
    // 1. Seviye: Tiger BOM patlama
    if (!empty($bom[$mamul_kodu])) {
        foreach ($bom[$mamul_kodu] as $alt_kodu=>$bom_miktar) {
            // 1a. Alt malzemenin kendisi EN- hattında mı?
            if (isset($op_data[$alt_kodu])) {
                for ($ay=1;$ay<=12;$ay++) {
                    $mamul_m=(float)($fc['ay'.$ay]??0);
                    if($mamul_m<=0) continue;
                    $hesap_forecast[$alt_kodu][$ay]=($hesap_forecast[$alt_kodu][$ay]??0)+$mamul_m*$bom_miktar;
                }
            }
            // 1b. Alt malzemenin Tiger BOM'u yok ama Manuel BOM'da var? → 2. seviye patlama
            if (!empty($manuel_bom_data[$alt_kodu])) {
                foreach ($manuel_bom_data[$alt_kodu] as $alt2_kodu=>$bom2_miktar) {
                    for ($ay=1;$ay<=12;$ay++) {
                        $mamul_m=(float)($fc['ay'.$ay]??0);
                        if($mamul_m<=0) continue;
                        $ihtiyac2 = $mamul_m * $bom_miktar * $bom2_miktar;
                        $hesap_forecast[$alt2_kodu][$ay]=($hesap_forecast[$alt2_kodu][$ay]??0)+$ihtiyac2;
                    }
                    // op_data'da yoksa ekle
                    if (!isset($op_data[$alt2_kodu])) {
                        try {
                            $r2 = $db->prepare("SELECT alt_adi FROM manuel_bom WHERE alt_kodu=? LIMIT 1");
                            $r2->execute([$alt2_kodu]);
                            $adi2 = $r2->fetchColumn() ?: '';
                        } catch(Throwable $e) { $adi2=''; }
                        $op_data[$alt2_kodu] = ['_adi'=>$adi2,'_ilk'=>$hat_atamalari[$alt2_kodu]??'','hatlar'=>[]];
                    }
                }
            }
        }
    }
    // 1. Seviye: Manuel BOM (forecast mamulünün direkt manuel reçetesi)
    if (!empty($manuel_bom_data[$mamul_kodu])) {
        foreach ($manuel_bom_data[$mamul_kodu] as $alt_kodu=>$bom_miktar) {
            for ($ay=1;$ay<=12;$ay++) {
                $mamul_m=(float)($fc['ay'.$ay]??0);
                if($mamul_m<=0) continue;
                $hesap_forecast[$alt_kodu][$ay]=($hesap_forecast[$alt_kodu][$ay]??0)+$mamul_m*$bom_miktar;
            }
            if (!isset($op_data[$alt_kodu])) {
                try {
                    $r_adi = $db->prepare("SELECT alt_adi FROM manuel_bom WHERE alt_kodu=? LIMIT 1");
                    $r_adi->execute([$alt_kodu]);
                    $alt_adi_str = $r_adi->fetchColumn() ?: '';
                } catch(Throwable $e) { $alt_adi_str=''; }
                $op_data[$alt_kodu] = ['_adi'=>$alt_adi_str,'_ilk'=>$hat_atamalari[$alt_kodu]??'','hatlar'=>[]];
            }
        }
    }
}

// ── HESAPLAMA ─────────────────────────────────────────────────────
$hat_yuklem = [];
foreach ($hat_sirasi as $h) $hat_yuklem[$h] = array_fill(1, 12, 0.0);
$hat_urunler = array_fill_keys($hat_sirasi, []);

$eslesen = 0; $eslesmez = 0; $op_yok = 0;
$bom_eslesen = 0; // BOM'dan gelen alt malzeme eşleşmeleri
$bolme_eslesen = 0; // Hat bölme uygulanan ürün sayısı

// ── Yardımcı: ürün + hat için çevrim/parti al ────────────────────
// Alt hat → üst hat eşlemesi (Tiger'da üst hat adıyla tanımlı)
$alt_hat_parent = [
    'EL İŞÇİLİĞİ 6.1' => 'EL İŞÇİLİĞİ 6',
    'EL İŞÇİLİĞİ 6.2' => 'EL İŞÇİLİĞİ 6',
    'EL İŞÇİLİĞİ 6.3' => 'EL İŞÇİLİĞİ 6',
    'EL İŞÇİLİĞİ 7.1' => 'EL İŞÇİLİĞİ 7',
    'EL İŞÇİLİĞİ 8.1' => 'EL İŞÇİLİĞİ 8',
    'EL İŞÇİLİĞİ 8.2' => 'EL İŞÇİLİĞİ 8',
];

function op_al($op_data, $stok_kodu, $hat) {
    global $alt_hat_parent;
    if (!isset($op_data[$stok_kodu])) return null;
    $hatlar = $op_data[$stok_kodu]['hatlar'] ?? [];
    // 1. Tam eşleşme
    if (isset($hatlar[$hat])) return $hatlar[$hat];
    // 2. Alt hat ise üst hattaki çevrim süresini kullan
    $parent = $alt_hat_parent[$hat] ?? null;
    if ($parent && isset($hatlar[$parent])) return $hatlar[$parent];
    // 3. Fallback: ilk hat
    if (!empty($hatlar)) return reset($hatlar);
    return null;
}

foreach ($hesap_forecast as $stok_kodu => $ay_miktarlar) {
    // 1. DB hat ataması
    $hat = $hat_atamalari[$stok_kodu] ?? null;
    // 2. Tiger'dan ilk hat
    if (!$hat && isset($op_data[$stok_kodu]))
        $hat = $op_data[$stok_kodu]['_ilk'];
    if (!$hat || !isset($hat_yuklem[$hat])) { $eslesmez++; continue; }
    if (!isset($op_data[$stok_kodu]))        { $op_yok++;   continue; }

    $is_bom_item = !isset($forecast[$stok_kodu]);
    if ($is_bom_item) $bom_eslesen++;

    // Hat bölme var mı?
    $bolme = $hat_bolme[$stok_kodu] ?? null;

    if ($bolme && isset($hat_yuklem[$bolme['hat1']]) && isset($hat_yuklem[$bolme['hat2']])) {
        // ── Bölmeli hesaplama ──────────────────────────────────
        $bolme_eslesen++;
        $oran1 = $bolme['oran1'] / 100;
        $oran2 = $bolme['oran2'] / 100;

        $op1 = op_al($op_data, $stok_kodu, $bolme['hat1']);
        $op2 = op_al($op_data, $stok_kodu, $bolme['hat2']);
        $pers1 = max(1, $hat_personel[$bolme['hat1']] ?? 1);
        $pers2 = max(1, $hat_personel[$bolme['hat2']] ?? 1);

        $hat_urunler[$bolme['hat1']][] = $stok_kodu . ($is_bom_item?'*':'') . '(' . $bolme['oran1'] . '%)';
        $hat_urunler[$bolme['hat2']][] = $stok_kodu . ($is_bom_item?'*':'') . '(' . $bolme['oran2'] . '%)';
        $eslesen++;

        for ($ay = 1; $ay <= 12; $ay++) {
            $miktar = (float)($ay_miktarlar[$ay] ?? 0);
            if ($miktar <= 0) continue;
            $ay_verim = ($hat_saat[$bolme['hat1']] ?? 7) * $verimlilik / 100;
            if ($op1 && $op1['cevrim_sn'] > 0) {
                $sk1 = (3600 / $op1['cevrim_sn']) * $op1['parti'];
                $hat_yuklem[$bolme['hat1']][$ay] += ($miktar * $oran1 / $sk1) / $ay_verim;
            }
            $ay_verim2 = ($hat_saat[$bolme['hat2']] ?? 7) * $verimlilik / 100;
            if ($op2 && $op2['cevrim_sn'] > 0) {
                $sk2 = (3600 / $op2['cevrim_sn']) * $op2['parti'];
                $hat_yuklem[$bolme['hat2']][$ay] += ($miktar * $oran2 / $sk2) / $ay_verim2;
            }
        }
    } else {
        // ── Tekli hat ─────────────────────────────────────────
        $op = op_al($op_data, $stok_kodu, $hat);
        if (!$op || $op['cevrim_sn'] <= 0) { $op_yok++; continue; }

        $saatlik_kap = (3600 / $op['cevrim_sn']) * $op['parti'];
        $pers = max(1, $hat_personel[$hat] ?? 1);
        $eslesen++;
        $hat_urunler[$hat][] = $stok_kodu . ($is_bom_item ? '*' : '');
        $gun_saat = $hat_saat[$hat] ?? 7; // hat günlük çalışma saati

        for ($ay = 1; $ay <= 12; $ay++) {
            $miktar = (float)($ay_miktarlar[$ay] ?? 0);
            if ($miktar <= 0) continue;
            $hat_yuklem[$hat][$ay] += ($miktar / $saatlik_kap) / ($gun_saat * $verimlilik / 100);
        }
    }
}

// Toplam forecast ürün sayısı için (direkt + BOM)
$toplam_hesaplanan = count($hesap_forecast);

// Tonaj grubu özetleri
$grup_yuklem  = [];
$grup_hat_say = [];
foreach ($hat_sirasi as $h) {
    $t = $hat_tonaj[$h] ?? 0;
    if (!isset($grup_yuklem[$t])) { $grup_yuklem[$t] = array_fill(1,12,0.0); $grup_hat_say[$t] = 0; }
    $grup_hat_say[$t]++;
    for ($ay=1;$ay<=12;$ay++) $grup_yuklem[$t][$ay] += $hat_yuklem[$h][$ay];
}
ksort($grup_yuklem);

$ay_adlari = [1=>'Oca',2=>'Şub',3=>'Mar',4=>'Nis',5=>'May',6=>'Haz',7=>'Tem',8=>'Ağu',9=>'Eyl',10=>'Eki',11=>'Kas',12=>'Ara'];
ob_end_clean();
?>
<style>
/* sticky thead z-index sınırla - sidebar stacking context sorunu */
.enj-wrap thead th, .enj-wrap thead tr { z-index: 2 !important; }

.enj-wrap { overflow-x:auto; }
.enj-tbl  { border-collapse:collapse; font-size:11px; white-space:nowrap; width:100%; }
.enj-tbl thead { position:sticky; top:0; z-index:5; }
.enj-tbl thead th { background:#065F46; color:#e0f0ff; padding:5px 7px; border:1px solid #047857; font-size:10px; font-weight:600; text-align:center; }
.enj-tbl tbody td { padding:3px 6px; border:1px solid #E5E7EB; text-align:right; }
.enj-tbl td.nm    { text-align:left; font-weight:700; color:#065F46; }
.enj-tbl td.nm small { font-weight:400; color:#94A3B8; }
.d0  { color:#C4CACC; }
.dlo { background:#DCFCE7; color:#166534; }              /* 0–30%   yeşil */
.dmd { background:#FEF9C3; color:#854D0E; }              /* 30–65%  sarı */
.dhi { background:#FED7AA; color:#C2410C; }              /* 65–90%  turuncu */
.dvhi{ background:#FECACA; color:#B91C1C; font-weight:700; } /* 90–100% kırmızı */
.dov { background:#7F1D1D; color:#FCA5A5; font-weight:800; } /* >100%  koyu kırmızı */
.grup-hdr td { background:#E2E8F0 !important; font-weight:800; font-size:11px; color:#065F46; border-top:2px solid #94A3B8; text-align:left; padding-left:10px; }
.hat-edit { background:none; border:none; cursor:pointer; color:#667EEA; font-size:10px; padding:0 2px; }
.kart-baslik { background:linear-gradient(135deg,#065F46,#047857); color:#fff; padding:10px 16px; border-radius:8px 8px 0 0; font-weight:700; font-size:13px; }
.kart-baslik small { font-size:10px; font-weight:400; opacity:.8; margin-left:8px; }
</style>

<!-- S-BAR -->
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1;min-width:0">
    <h1 class="s-bas">🔧 Montaj Kapasite</h1>
    <div class="s-yol">Planlama / <b>Montaj <?php echo $sel_yil;?></b></div>
  </div>
  <form method="GET" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="planlama-kapasite-montaj">
    <select name="yil" class="form-alan" style="padding:4px 8px;font-size:12px;width:80px" onchange="this.form.submit()">
      <?php foreach(range(date('Y')-1,date('Y')+2) as $y):?><option value="<?php echo $y;?>"<?php echo $y==$sel_yil?' selected':'';?>><?php echo $y;?></option><?php endforeach;?>
    </select>
    <button type="submit" style="background:#065F46;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
  </form>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kapasite-enj" style="background:#1E3A5F;color:#fff;padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none">🏭 Enjeksiyon</a>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kapasite" style="background:#7C3AED;color:#fff;padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none">📈 Forecast</a>
</div>

<!-- Özet -->
<?php
$toplam_ay = array_fill(1,12,0.0);
foreach($hat_yuklem as $h=>$a) for($ay=1;$ay<=12;$ay++) $toplam_ay[$ay]+=$a[$ay];
$maks_pct=0;
foreach($hat_yuklem as $h=>$a) for($ay=1;$ay<=12;$ay++) {
    $ay_etkin=$ay_gun_bilgi[$ay]['etkin'];
    if($ay_etkin>0) $maks_pct=max($maks_pct,$a[$ay]/$ay_etkin*100);
}
?>
<div style="display:flex;gap:8px;padding:0 0 10px;flex-wrap:wrap;font-size:11px">
  <?php foreach([
    ['🏭','Hat',count($hat_sirasi),'#EFF6FF','#1E40AF'],
    ['📋','Forecast',count($forecast),'#F0FDF4','#065F46'],
    ['🔗','BOM alt',$bom_eslesen,'#F3E8FF','#6B21A8'],
    ['✅','Eşleşen',$eslesen,'#F0FDF4','#065F46'],
    ['⚖️','Bölmeli',$bolme_eslesen,'#ECFDF5','#065F46'],
    ['⚠️','Op.yok',$op_yok,'#FFF7ED','#92400E'],
    ['❌','Hatsız',$eslesmez,'#FEF2F2','#991B1B'],
    ['📅','Ort.etkin kap.',number_format($etkin_kap_ort,1).' g','#F3E8FF','#6B21A8'],
    ['🔥','Maks.dol.',number_format($maks_pct,0).'%',$maks_pct>100?'#FEF2F2':'#F0FDF4',$maks_pct>100?'#991B1B':'#065F46'],
  ] as [$i,$e,$d,$bg,$fg]):?>
  <div style="background:<?php echo $bg;?>;border:1px solid <?php echo $fg;?>33;border-radius:8px;padding:6px 12px;min-width:80px">
    <div style="font-size:9px;color:<?php echo $fg;?>"><?php echo $i.' '.$e;?></div>
    <div style="font-size:15px;font-weight:800;color:<?php echo $fg;?>"><?php echo $d;?></div>
  </div>
  <?php endforeach;?>
  <div style="margin-left:auto;display:flex;align-items:center;gap:5px;font-size:10px;flex-wrap:wrap">
    <span style="background:#BBF7D0;color:#166534;padding:2px 7px;border-radius:4px">0–30%</span>
    <span style="background:#FEF08A;color:#854D0E;padding:2px 7px;border-radius:4px">30–65%</span>
    <span style="background:#FED7AA;color:#C2410C;padding:2px 7px;border-radius:4px">65–90%</span>
    <span style="background:#FECACA;color:#B91C1C;padding:2px 7px;border-radius:4px">90–100%</span>
    <span style="background:#F87171;color:#7F1D1D;padding:2px 7px;border-radius:4px">&gt;100%</span>
  </div>
</div>

<!-- Aylık çalışma günü özeti -->
<div style="display:flex;gap:4px;flex-wrap:wrap;padding:0 0 10px;font-size:10px">
  <?php for($ay=1;$ay<=12;$ay++):
    $b=$ay_gun_bilgi[$ay]; $aktif=$ay==$ay_su;?>
  <div style="background:<?php echo $aktif?'#EFF6FF':'#F8FAFC';?>;border:1px solid <?php echo $aktif?'#BFDBFE':'#E2E8F0';?>;border-radius:6px;padding:4px 8px;text-align:center;min-width:52px">
    <div style="font-weight:700;color:<?php echo $aktif?'#1E40AF':'#374151';?>"><?php echo $ay_adlari[$ay];?></div>
    <div style="color:#065F46;font-weight:700"><?php echo $b['calisma'];?>g</div>
    <?php if($b['tatil']>0):?><div style="color:#991B1B">-<?php echo $b['tatil'];?>🏖</div><?php endif;?>
    <div style="color:#6B21A8;font-size:9px"><?php echo number_format($b['etkin'],1);?>g etkin</div>
  </div>
  <?php endfor;?>
</div>

<?php
// Ay başlık satırı helper
function ayBaslik($ay_adlari, $ay_su, $ay_gun_bilgi, $gun_lbl=true) {
    $html = '';
    for($ay=1;$ay<=12;$ay++) {
        $aktif = $ay==$ay_su ? 'style="background:#047857"' : '';
        $etkin = $ay_gun_bilgi[$ay]['etkin'];
        $calisma = $ay_gun_bilgi[$ay]['calisma'];
        $tatil   = $ay_gun_bilgi[$ay]['tatil'];
        $alt = $gun_lbl
            ? '<br><span style="font-size:8px;opacity:.75" title="'.$calisma.' çalışma - '.$tatil.' tatil">'.number_format($etkin,1).'g</span>'
            : '';
        $html .= "<th $aktif style=\"min-width:46px\">{$ay_adlari[$ay]}$alt</th>";
    }
    return $html;
}

// Renk sınıfı helper
function dCls($pct) {
    if ($pct <= 0)   return 'd0';
    if ($pct < 30)   return 'dlo';
    if ($pct < 65)   return 'dmd';
    if ($pct < 90)   return 'dhi';
    if ($pct < 100)  return 'dvhi';
    return 'dov';
}

// Montaj hat grupları
$tonaj_gruplari = [
    'EL İŞÇİLİĞİ' => [
        'EL İŞÇİLİĞİ 1','EL İŞÇİLİĞİ 2','EL İŞÇİLİĞİ 3','EL İŞÇİLİĞİ 4',
        'EL İŞÇİLİĞİ 5',
        'EL İŞÇİLİĞİ 6','EL İŞÇİLİĞİ 6.1','EL İŞÇİLİĞİ 6.2','EL İŞÇİLİĞİ 6.3',
        'EL İŞÇİLİĞİ 7','EL İŞÇİLİĞİ 7.1',
        'EL İŞÇİLİĞİ 8','EL İŞÇİLİĞİ 8.1','EL İŞÇİLİĞİ 8.2',
        'EL İŞÇİLİĞİ 9','EL İŞÇİLİĞİ 10',
    ],
    'OTOMATİK'     => ['MT-01','SR-01'],
    'DİĞER'        => ['FSN-01','KRM-01','TERM-01'],
];
?>

<!-- SEKME BARI -->
<div style="display:flex;gap:2px;border-bottom:2px solid #E2E8F0;margin-bottom:0;flex-wrap:wrap">
  <?php foreach([
    ['mtab1','📅 Gereken Gün'],
    ['mtab2','📊 % Doluluk'],
    ['mtab3','🏭 Tonaj Özeti'],
    ['mtab4','📦 Ürün Listesi'],
    ['mtab5','🔍 Debug'],
    ['mtab6','⚙️ Hat Personel'],
  ] as $i=>[$id,$etiket]):?>
  <button id="btn-<?php echo $id;?>" onclick="sekmeAc('<?php echo $id;?>')"
    style="padding:8px 18px;border:none;border-radius:6px 6px 0 0;font-size:12px;font-weight:600;cursor:pointer;transition:background .15s;
    <?php echo $i===0?'background:#065F46;color:#fff':'background:#F1F5F9;color:#64748B';?>">
    <?php echo $etiket;?>
  </button>
  <?php endforeach;?>
</div>

<!-- ══════════════════════════════════════════════════════════
     TABLO 1: GEREKEN GÜN (hat bazlı + grup satırı)
════════════════════════════════════════════════════════════ -->
<div id="mtab1">
  <div class="kart-baslik">📅 Hat Bazlı — Gereken Gün (iş yükü)
    <small>Her hat için aylık gereken gün sayısı &nbsp;|&nbsp; Etkin kap. (ort.): <?php echo number_format($etkin_kap_ort,1);?> gün/hat &nbsp;|&nbsp; Verimlilik: <?php echo $verimlilik;?>%</small>
  </div>
  <div class="kart" style="padding:0;border-radius:0 0 8px 8px;overflow:visible">
  <div class="enj-wrap" style="max-height:440px;overflow-y:auto">
  <table class="enj-tbl">
    <thead><tr>
      <th style="min-width:90px;text-align:left">Hat</th>
      <th style="width:28px">⚙️</th>
      <?php echo ayBaslik($ay_adlari,$ay_su,$ay_gun_bilgi,true);?>
      <th style="min-width:55px">Toplam</th>
    </tr></thead>
    <tbody>
    <?php foreach($tonaj_gruplari as $tonaj => $hatlar):
      // Grup başlık satırı
      $g = $grup_yuklem[$tonaj]??array_fill(1,12,0);
      $hc = count($hatlar);
      $g_toplam = array_sum($g);
    ?>
    <tr class="grup-hdr">
      <td colspan="<?php echo 14+1;?>"><?php echo $tonaj;?>T grubu — <?php echo $hc;?> hat &nbsp;
        <span style="font-weight:400;font-size:10px;color:#475569">Toplam yük: <?php echo number_format($g_toplam,1);?> gün</span>
      </td>
    </tr>
    <?php foreach($hatlar as $hat):
      $aylar = $hat_yuklem[$hat];
      $toplam_hat = array_sum($aylar);
      $urunler = $hat_urunler[$hat]??[];
    ?>
    <tr data-hat="<?php echo $hat;?>">
      <td class="nm" title="<?php echo count($urunler);?> ürün: <?php echo htmlspecialchars(implode(', ',array_slice($urunler,0,6)));?><?php echo count($urunler)>6?'...':'';?>">
        <?php echo $hat;?> <small>(<?php echo count($urunler);?>)</small>
        <?php if(($p=$hat_personel[$hat]??0)>1): ?><small style="background:#D1FAE5;color:#065F46;padding:0 4px;border-radius:3px;margin-left:2px"><?php echo $p;?>K</small><?php endif;?>
      </td>
      <td style="text-align:center"><button class="hat-edit" onclick="mntHatAtaAc('<?php echo htmlspecialchars($hat);?>')" title="Hat atamasını düzenle">⚙️</button></td>
      <?php for($ay=1;$ay<=12;$ay++):
        $gun=$aylar[$ay]; $p=$hat_personel[$hat]??1; $ay_e=$ay_gun_bilgi[$ay]['etkin']*$p; $pct=$ay_e>0?$gun/$ay_e*100:0; $cls=dCls($pct);?>
      <td class="<?php echo $cls;?>" title="<?php echo number_format($pct,0);?>% | <?php echo number_format($gun,1);?> / <?php echo number_format($ay_e,1);?> gün">
        <?php echo $gun>0?number_format($gun,1):'·';?>
      </td>
      <?php endfor;?>
      <td style="font-weight:700;color:#065F46"><?php echo $toplam_hat>0?number_format($toplam_hat,1):'·';?></td>
    </tr>
    <?php endforeach;?>
    <?php endforeach;?>
    <tr style="background:#065F46">
      <td colspan="2" style="color:#e0f0ff;font-weight:800;text-align:left;padding-left:8px">TOPLAM</td>
      <?php for($ay=1;$ay<=12;$ay++): $g=$toplam_ay[$ay];?>
      <td style="color:<?php echo $g>0?'#FCD34D':'#475569';?>;font-weight:700"><?php echo $g>0?number_format($g,1):'·';?></td>
      <?php endfor;?>
      <td style="color:#FCD34D;font-weight:800"><?php echo number_format(array_sum($toplam_ay),1);?></td>
    </tr>
    </tbody>
  </table>
  </div></div>
</div>
</div><!-- /tab1 -->

<!-- ══════════════════════════════════════════════════════════
     TABLO 2: % DOLULUK (hat bazlı + grup satırı)
════════════════════════════════════════════════════════════ -->
<div id="mtab2" style="display:none">
<div style="margin-bottom:16px">
  <div class="kart-baslik" style="display:flex;align-items:center;justify-content:space-between">
    <div>
      📊 Hat Bazlı — % Doluluk
      <small>Etkin kapasiteye (<?php echo number_format($etkin_kap,1);?> gün) göre doluluk oranı</small>
    </div>
    <button onclick="mntMailOlustur()" style="background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.4);color:#fff;padding:5px 14px;border-radius:6px;font-size:12px;cursor:pointer;font-weight:600">
      📧 Mail Hazırla
    </button>
  </div>
  <div class="kart" style="padding:0;border-radius:0 0 8px 8px;overflow:visible">
  <div class="enj-wrap" style="max-height:440px;overflow-y:auto">
  <table class="enj-tbl">
    <thead><tr>
      <th style="min-width:90px;text-align:left">Hat</th>
      <th style="width:28px"></th>
      <?php echo ayBaslik($ay_adlari,$ay_su,$ay_gun_bilgi,false);?>
      <th style="min-width:55px">Ort.%</th>
    </tr></thead>
    <tbody>
    <?php foreach($tonaj_gruplari as $tonaj => $hatlar):
      $g=$grup_yuklem[$tonaj]??array_fill(1,12,0); $hc=count($hatlar);
      // Grup toplam personel
      $g_toplam_pers = 0;
      foreach($hatlar as $ph) $g_toplam_pers += ($hat_personel[$ph] ?? 1);
      // Grup için ortalama doluluk (toplam yük / toplam_personel*etkin_kap)
      $g_ort = 0; for($ay=1;$ay<=12;$ay++) $g_ort += $etkin_kap>0?$g[$ay]/$etkin_kap*100:0; $g_ort/=12;
    ?>
    <tr class="grup-hdr">
      <td colspan="14"><?php echo htmlspecialchars($tonaj);?> grubu &nbsp;
        <span style="font-weight:400;font-size:10px">Yıllık ort. doluluk: <?php echo number_format($g_ort,0);?>%</span>
      </td>
    </tr>
    <?php foreach($hatlar as $hat):
      $aylar=$hat_yuklem[$hat];
      $ort_pct=0; for($ay=1;$ay<=12;$ay++) $ort_pct+=($etkin_kap>0?$aylar[$ay]/$etkin_kap*100:0); $ort_pct/=12;
    ?>
    <tr>
      <td class="nm"><?php echo $hat;?><?php if(($p=$hat_personel[$hat]??0)>1): ?> <small style="background:#D1FAE5;color:#065F46;padding:0 4px;border-radius:3px"><?php echo $p;?>K</small><?php endif;?></td>
      <td style="text-align:center"><button class="hat-edit" onclick="mntHatAtaAc('<?php echo htmlspecialchars($hat);?>')" title="Hat atamasını düzenle">⚙️</button></td>
      <?php for($ay=1;$ay<=12;$ay++):
        $gun=$aylar[$ay]; $p=$hat_personel[$hat]??1; $ay_e=$ay_gun_bilgi[$ay]['etkin']*$p; $pct=$ay_e>0?$gun/$ay_e*100:0; $cls=dCls($pct);?>
      <td class="<?php echo $cls;?>" title="<?php echo number_format($gun,1);?> gün / <?php echo number_format($ay_e,1);?> etkin">
        <?php echo $pct>0?number_format($pct,0).'%':'·';?>
      </td>
      <?php endfor;?>
      <td class="<?php echo dCls($ort_pct);?>" style="font-weight:700"><?php echo $ort_pct>0?number_format($ort_pct,0).'%':'·';?></td>
    </tr>
    <?php endforeach;?>
    <!-- Grup ortalaması satırı -->
    <tr style="background:#E0E7FF;border-top:1px dashed #94A3B8">
      <td colspan="2" style="text-align:left;padding-left:16px;font-size:10px;color:#4338CA;font-style:italic">
        ↳ <?php echo htmlspecialchars($tonaj);?> ort. (<?php echo $g_toplam_pers;?>K)
      </td>
      <?php for($ay=1;$ay<=12;$ay++):
        $g_ay=$g[$ay]; $ay_e=$ay_gun_bilgi[$ay]['etkin']; $p=$ay_e>0?$g_ay/$ay_e*100:0; $cls=dCls($p);?>
      <td class="<?php echo $cls;?>" style="font-size:10px;font-style:italic">
        <?php echo $p>0?number_format($p,0).'%':'·';?>
      </td>
      <?php endfor;?>
      <td style="background:#E0E7FF;font-weight:700;font-size:10px;color:#4338CA;font-style:italic"><?php echo $g_ort>0?number_format($g_ort,0).'%':'·';?></td>
    </tr>
    <?php endforeach;?>
    <?php
    $toplam_personel_tab2 = 0;
    foreach($hat_sirasi as $h) $toplam_personel_tab2 += ($hat_personel[$h] ?? 1);
    ?>
    <tr style="background:#065F46">
      <td colspan="2" style="color:#e0f0ff;font-weight:800;text-align:left;padding-left:8px">ORTALAMA (<?php echo $toplam_personel_tab2;?>K)</td>
      <?php for($ay=1;$ay<=12;$ay++):
        $top_kap=$ay_gun_bilgi[$ay]['etkin']*$toplam_personel_tab2;
        $pct=$top_kap>0?$toplam_ay[$ay]/$top_kap*100:0; $cls=dCls($pct);?>
      <td class="<?php echo $cls;?>" style="font-weight:700"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
      <?php endfor;?>
      <?php $yillik_ort=0; for($ay=1;$ay<=12;$ay++) $yillik_ort+=($etkin_kap*$toplam_personel_tab2>0?$toplam_ay[$ay]/($etkin_kap*$toplam_personel_tab2)*100:0); $yillik_ort/=12;?>
      <td style="color:#FCD34D;font-weight:800"><?php echo number_format($yillik_ort,0);?>%</td>
    </tr>
    </tbody>
  </table>
  </div></div>
</div>
</div><!-- /tab2 -->

<!-- ══════════════════════════════════════════════════════════
     TABLO 3: TONAJ GRUBU ÖZETİ
════════════════════════════════════════════════════════════ -->
<div id="mtab3" style="display:none">
<div style="margin-bottom:16px">
  <div class="kart-baslik">🔧 Montaj Grup Özeti — % Doluluk
    <small>Personel bazlı kapasite — alt hatlı gruplar toplu gösterilir</small>
  </div>
  <div class="kart" style="padding:0;border-radius:0 0 8px 8px;overflow:visible">
  <div class="enj-wrap">
  <table class="enj-tbl">
    <thead><tr>
      <th style="min-width:180px;text-align:left">Grup / Hat</th>
      <th style="width:40px">Hat</th>
      <th style="width:45px">Pers.</th>
      <th style="min-width:65px">Kap.(gün)</th>
      <?php echo ayBaslik($ay_adlari,$ay_su,$ay_gun_bilgi,false);?>
    </tr></thead>
    <tbody>
    <?php
    // Alt grup tanımları (6, 7, 8 altındaki hatlar)
    $alt_gruplar = [
        'EL İŞÇİLİĞİ 6' => ['EL İŞÇİLİĞİ 6','EL İŞÇİLİĞİ 6.1','EL İŞÇİLİĞİ 6.2','EL İŞÇİLİĞİ 6.3'],
        'EL İŞÇİLİĞİ 7' => ['EL İŞÇİLİĞİ 7','EL İŞÇİLİĞİ 7.1'],
        'EL İŞÇİLİĞİ 8' => ['EL İŞÇİLİĞİ 8','EL İŞÇİLİĞİ 8.1','EL İŞÇİLİĞİ 8.2'],
    ];
    $alt_hat_uyeleri = [];
    foreach($alt_gruplar as $ana=>$uyeler) foreach($uyeler as $h) $alt_hat_uyeleri[$h]=true;

    foreach($tonaj_gruplari as $tonaj => $hatlar):
        $g_tp=0; foreach($hatlar as $ph) $g_tp+=($hat_personel[$ph]??1);
        $g_yuklem=$grup_yuklem[$tonaj]??array_fill(1,12,0);
        $g_kap=$etkin_kap*$g_tp;
    ?>
    <tr class="grup-hdr">
      <td colspan="17" style="padding-left:8px">
        <?php echo htmlspecialchars($tonaj);?>
        <span style="font-weight:400;font-size:10px;color:#047857"> — <?php echo count($hatlar);?> hat / <?php echo $g_tp;?>K personel</span>
      </td>
    </tr>
    <?php if($tonaj === 'EL İŞÇİLİĞİ'):
        // Tekli hatlar (alt gruba dahil değil)
        foreach(array_filter($hatlar, fn($h)=>!isset($alt_hat_uyeleri[$h])) as $hat):
            $p=$hat_personel[$hat]??1; $yuk=$hat_yuklem[$hat]??array_fill(1,12,0); $kap=$etkin_kap*$p; ?>
        <tr>
          <td class="nm" style="padding-left:16px"><?php echo htmlspecialchars($hat);?> <small style="background:#D1FAE5;color:#065F46;padding:0 4px;border-radius:3px"><?php echo $p;?>K</small></td>
          <td style="text-align:center;color:#94A3B8">1</td>
          <td style="text-align:center;color:#065F46;font-size:10px"><?php echo $p;?>K</td>
          <td style="text-align:right;color:#064E3B;font-weight:700"><?php echo number_format($kap,1);?></td>
          <?php for($ay=1;$ay<=12;$ay++): $g=$yuk[$ay]; $ae=$ay_gun_bilgi[$ay]['etkin']; $pct=$ae*$p>0?$g/($ae*$p)*100:0; $cls=dCls($pct);?>
          <td class="<?php echo $cls;?>" title="<?php echo number_format($pct,0);?>%"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
          <?php endfor;?>
        </tr>
        <?php endforeach;
        // Alt gruplar
        foreach($alt_gruplar as $ana_hat => $alt_uyeler):
            $ag_tp=0; foreach($alt_uyeler as $h) $ag_tp+=($hat_personel[$h]??1);
            $ag_yuk=array_fill(1,12,0.0);
            foreach($alt_uyeler as $h) for($ay=1;$ay<=12;$ay++) $ag_yuk[$ay]+=($hat_yuklem[$h][$ay]??0);
            $ag_kap=$etkin_kap*$ag_tp;
        ?>
        <tr style="background:#ECFDF5;border-top:1px solid #6EE7B7">
          <td class="nm" style="color:#065F46;padding-left:16px;font-weight:800">
            ┌ <?php echo htmlspecialchars($ana_hat);?> grubu
            <small style="background:#059669;color:#fff;padding:0 5px;border-radius:3px;margin-left:4px"><?php echo $ag_tp;?>K toplam</small>
          </td>
          <td style="text-align:center;color:#064E3B;font-size:10px"><?php echo count($alt_uyeler);?></td>
          <td style="text-align:center;color:#065F46;font-weight:700;font-size:10px"><?php echo $ag_tp;?>K</td>
          <td style="text-align:right;color:#064E3B;font-weight:700"><?php echo number_format($ag_kap,1);?></td>
          <?php for($ay=1;$ay<=12;$ay++): $g=$ag_yuk[$ay]; $ae=$ay_gun_bilgi[$ay]['etkin']*$ag_tp; $pct=$ae>0?$g/$ae*100:0; $cls=dCls($pct);?>
          <td class="<?php echo $cls;?>" style="font-weight:700" title="<?php echo number_format($pct,0);?>%"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
          <?php endfor;?>
        </tr>
        <?php foreach($alt_uyeler as $hat):
            $p=$hat_personel[$hat]??1; $yuk=$hat_yuklem[$hat]??array_fill(1,12,0); $kap=$etkin_kap*$p; ?>
        <tr style="opacity:.85">
          <td class="nm" style="padding-left:28px;font-size:11px">└ <?php echo htmlspecialchars($hat);?> <small style="background:#D1FAE5;color:#065F46;padding:0 4px;border-radius:3px"><?php echo $p;?>K</small></td>
          <td style="text-align:center;color:#94A3B8">1</td>
          <td style="text-align:center;color:#065F46;font-size:10px"><?php echo $p;?>K</td>
          <td style="text-align:right;color:#064E3B"><?php echo number_format($kap,1);?></td>
          <?php for($ay=1;$ay<=12;$ay++): $g=$yuk[$ay]; $ae=$ay_gun_bilgi[$ay]['etkin']; $pct=$ae*$p>0?$g/($ae*$p)*100:0; $cls=dCls($pct);?>
          <td class="<?php echo $cls;?>" title="<?php echo number_format($pct,0);?>%"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
          <?php endfor;?>
        </tr>
        <?php endforeach; endforeach; ?>
    <?php else:
        foreach($hatlar as $hat):
            $p=$hat_personel[$hat]??1; $yuk=$hat_yuklem[$hat]??array_fill(1,12,0); $kap=$etkin_kap*$p; ?>
        <tr>
          <td class="nm" style="padding-left:16px"><?php echo htmlspecialchars($hat);?><?php if($p>1):?> <small style="background:#D1FAE5;color:#065F46;padding:0 4px;border-radius:3px"><?php echo $p;?>K</small><?php endif;?></td>
          <td style="text-align:center;color:#94A3B8">1</td>
          <td style="text-align:center;color:#065F46;font-size:10px"><?php echo $p;?>K</td>
          <td style="text-align:right;color:#064E3B;font-weight:700"><?php echo number_format($kap,1);?></td>
          <?php for($ay=1;$ay<=12;$ay++): $g=$yuk[$ay]; $ae=$ay_gun_bilgi[$ay]['etkin']; $pct=$ae*$p>0?$g/($ae*$p)*100:0; $cls=dCls($pct);?>
          <td class="<?php echo $cls;?>" title="<?php echo number_format($pct,0);?>%"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
          <?php endfor;?>
        </tr>
        <?php endforeach; endif;?>
    <tr style="background:#D1FAE5;border-top:2px solid #6EE7B7">
      <td style="color:#065F46;font-weight:800;padding-left:8px;font-size:11px">↳ <?php echo htmlspecialchars($tonaj);?> TOPLAM</td>
      <td style="text-align:center;color:#047857;font-size:10px"><?php echo count($hatlar);?></td>
      <td style="text-align:center;color:#065F46;font-weight:700;font-size:10px"><?php echo $g_tp;?>K</td>
      <td style="text-align:right;color:#064E3B;font-weight:700"><?php echo number_format($g_kap,1);?></td>
      <?php for($ay=1;$ay<=12;$ay++): $g=$g_yuklem[$ay]; $ae=$ay_gun_bilgi[$ay]['etkin']*$g_tp; $pct=$ae>0?$g/$ae*100:0; $cls=dCls($pct);?>
      <td class="<?php echo $cls;?>" style="font-weight:700"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
      <?php endfor;?>
    </tr>
    <?php endforeach;?>
    <?php
    $toplam_personel_genel=0;
    foreach($hat_sirasi as $h) $toplam_personel_genel+=($hat_personel[$h]??1);
    ?>
    <tr style="background:#065F46;border-top:2px solid #475569">
      <td style="color:#e0f0ff;font-weight:800;text-align:left;padding-left:8px">GENEL TOPLAM</td>
      <td style="color:#94A3B8;text-align:center"><?php echo count($hat_sirasi);?></td>
      <td style="color:#6EE7B7;text-align:center;font-size:10px"><?php echo $toplam_personel_genel;?>K</td>
      <td style="color:#6EE7B7;font-weight:700;text-align:right"><?php echo number_format($etkin_kap*$toplam_personel_genel,1);?></td>
      <?php for($ay=1;$ay<=12;$ay++): $ae=$ay_gun_bilgi[$ay]['etkin']; $top=$ae*$toplam_personel_genel; $pct=$top>0?$toplam_ay[$ay]/$top*100:0; $cls=dCls($pct);?>
      <td class="<?php echo $cls;?>" style="font-weight:700"><?php echo $pct>0?number_format($pct,0).'%':'·';?></td>
      <?php endfor;?>
    </tr>
    </tbody>
  </table>
  </div></div>
</div>
</div><!-- /tab3 -->

<!-- ══════════════════════════════════════════════════════════
     TABLO 4: ÜRÜN LİSTESİ (hat atamalı)
════════════════════════════════════════════════════════════ -->
<div id="mtab4" style="display:none">
  <!-- Verim Ayarı -->
  <form method="GET" style="display:flex;gap:6px;align-items:center;padding:8px 12px;background:#F0FDF4;border-bottom:1px solid #BBF7D0">
    <input type="hidden" name="sayfa" value="planlama-kapasite-montaj">
    <input type="hidden" name="yil" value="<?php echo $sel_yil;?>">
    <span style="font-size:12px;font-weight:600;color:#065F46">⚙️ Verimlilik:</span>
    <input type="number" name="verim" value="<?php echo $verimlilik;?>" min="1" max="100"
      style="width:60px;border:2px solid #6EE7B7;border-radius:6px;padding:4px 8px;font-size:14px;font-weight:700;text-align:center">
    <span style="font-size:12px;color:#065F46">%</span>
    <button type="submit" style="background:#065F46;color:#fff;border:none;padding:5px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">🔄 Uygula</button>
    <span style="font-size:11px;color:#6B7280">Şu an: <strong><?php echo $verimlilik;?>%</strong> verimlilik ile hesaplanıyor</span>
  </form>

<div style="margin-bottom:16px">
  <div class="kart-baslik">📦 Ürün Listesi — Hat Atamaları
    <small><?php echo count($hesap_forecast);?> ürün &nbsp;|&nbsp; <?php echo count($forecast);?> direkt forecast + <?php echo $bom_eslesen;?> BOM alt malzeme</small>
  </div>
  <div class="kart" style="padding:0;border-radius:0 0 8px 8px;overflow:visible">

  <!-- Filtre -->
  <div style="padding:10px 12px;background:#F8FAFC;border-bottom:1px solid #E2E8F0;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <input type="text" id="mntFiltre" oninput="mntFiltreUygula()" placeholder="Stok kodu veya ad ara..."
      style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 10px;font-size:12px;width:220px">
    <select id="mntHatFiltre" onchange="mntFiltreUygula()"
      style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 9px;font-size:12px">
      <option value="">Tüm hatlar</option>
      <?php foreach($hat_sirasi as $h): echo '<option value="'.$h.'">'.$h.'</option>'; endforeach;?>
    </select>
    <select id="mntKaynakFiltre" onchange="mntFiltreUygula()"
      style="border:1px solid #E2E8F0;border-radius:6px;padding:5px 9px;font-size:12px">
      <option value="">Tüm kaynaklar</option>
      <option value="forecast">Direkt Forecast</option>
      <option value="bom">BOM Alt Malzeme</option>
      <option value="db">DB Atamalı</option>
    </select>
    <span id="mntSayac" style="font-size:11px;color:#64748B;margin-left:auto"></span>
  </div>

  <div style="overflow-x:auto;max-height:500px;overflow-y:auto">
  <table id="urunListeTbl" style="border-collapse:collapse;font-size:11px;width:100%;white-space:nowrap">
    <thead style="position:sticky;top:0;z-index:3">
    <tr style="background:#065F46">
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;text-align:left;min-width:120px">Stok Kodu</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;text-align:left;min-width:200px">Stok Adı</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:90px">Atanan Hat</th>
      
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:65px">Kaynak</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:65px">Çevrim(sn)</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:50px">Parti</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:70px">Saatlik kap.</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:110px">Hat Değiştir</th>
      <th style="color:#e0f0ff;padding:6px 8px;border:1px solid #047857;min-width:200px">⚖️ Hat Bölme (%)</th>
      <?php for($ay=1;$ay<=12;$ay++): echo '<th style="color:#e0f0ff;padding:5px 4px;border:1px solid #047857;min-width:44px;'.($ay==$ay_su?'background:#047857':'').'">'.$ay_adlari[$ay].'</th>'; endfor;?>
    </tr>
    </thead>
    <tbody id="mntListeBody">
    <?php
    foreach($hesap_forecast as $stok_kodu => $ay_miktarlar):
      $hat = $hat_atamalari[$stok_kodu] ?? ($op_data[$stok_kodu]['_ilk'] ?? null);
      if (!$hat) continue;
      $tonaj   = $hat_tonaj[$hat] ?? 0;
      $op_ent  = $op_data[$stok_kodu] ?? null;
      $is_bom  = !isset($forecast[$stok_kodu]);
      $is_db   = isset($hat_atamalari[$stok_kodu]);
      // Hat bazlı çevrim/parti
      $op_hat  = $op_ent ? ($op_ent['hatlar'][$hat] ?? reset($op_ent['hatlar'])) : null;
      $cevrim  = $op_hat ? $op_hat['cevrim_sn'] : 0;
      $parti   = $op_hat ? $op_hat['parti']     : 0;
      $saatlik = ($cevrim > 0) ? (3600/$cevrim)*$parti : 0;
      $stok_adi = $op_ent['_adi'] ?? '';

      if ($is_db)       $kaynak_html = '<span style="background:#DBEAFE;color:#1E40AF;padding:1px 6px;border-radius:4px">DB</span>';
      elseif ($is_bom)  $kaynak_html = '<span style="background:#F3E8FF;color:#6B21A8;padding:1px 6px;border-radius:4px">BOM</span>';
      else              $kaynak_html = '<span style="background:#FEF9C3;color:#854D0E;padding:1px 6px;border-radius:4px">Forecast</span>';

      $kaynak_val = $is_db ? 'db' : ($is_bom ? 'bom' : 'forecast');
      $toplam_urun = array_sum($ay_miktarlar);
    ?>
    <tr data-hat="<?php echo $hat;?>" data-kaynak="<?php echo $kaynak_val;?>"
        data-kod="<?php echo strtolower(htmlspecialchars($stok_kodu));?>"
        data-ad="<?php echo strtolower(htmlspecialchars($stok_adi));?>"
        style="<?php echo $is_bom?'background:#FAFAFA':'';?>">
      <td style="padding:3px 8px;border:1px solid #E5E7EB;font-weight:700"><?php echo htmlspecialchars($stok_kodu);?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;color:#475569;max-width:200px;overflow:hidden;text-overflow:ellipsis" title="<?php echo htmlspecialchars($stok_adi);?>"><?php echo htmlspecialchars(mb_substr($stok_adi,0,40));?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:center;font-weight:700;color:#065F46"><?php echo $hat;?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:center"><?php echo htmlspecialchars($tonaj);?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:center"><?php echo $kaynak_html;?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:right;color:#64748B"><?php echo $cevrim>0?number_format($cevrim,2):'—';?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:right"><?php echo $parti>0?$parti:'—';?></td>
      <td style="padding:3px 8px;border:1px solid #E5E7EB;text-align:right;color:#065F46;font-weight:600"><?php echo $saatlik>0?number_format($saatlik,1):'—';?></td>
      <td style="padding:3px 6px;border:1px solid #E5E7EB">
        <div style="display:flex;gap:4px;align-items:center">
          <select id="ulhat_<?php echo htmlspecialchars($stok_kodu);?>"
            style="border:1px solid #E2E8F0;border-radius:4px;padding:2px 4px;font-size:11px;flex:1;min-width:90px"
            data-mevcut="<?php echo htmlspecialchars($hat);?>"
            title="<?php echo $is_db?'DB atamalı':'Operasyondan';?>">
            <!-- JS ile doldurulacak -->
          </select>
          <button onclick="mntUlHatKaydet('<?php echo htmlspecialchars($stok_kodu);?>')"
            id="ulbtn_<?php echo htmlspecialchars($stok_kodu);?>"
            title="<?php echo $is_db?'DB atamalı — değiştirilebilir':'Operasyondan — DB ataması oluşturulacak';?>"
            style="background:#065F46;color:#fff;border:none;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:11px;white-space:nowrap">💾</button>
        </div>
        <div style="font-size:9px;color:#94A3B8;margin-top:1px"><?php echo $is_db?'🔵 DB':'⚡ Operasyon';?></div>
      </td>
      <?php
      // Hat bölme mevcut değerleri
      $b = $hat_bolme[$stok_kodu] ?? null;
      $b_hat1 = $b ? $b['hat1'] : $hat;
      $b_oran1 = $b ? $b['oran1'] : 100;
      $b_hat2 = $b ? $b['hat2'] : '';
      $b_oran2 = $b ? $b['oran2'] : 0;
      ?>
      <td style="padding:3px 6px;border:1px solid #E5E7EB;min-width:200px">
        <div style="display:flex;gap:3px;align-items:center;flex-wrap:wrap">
          <select id="bolme_hat1_<?php echo htmlspecialchars($stok_kodu);?>"
            style="border:1px solid #E2E8F0;border-radius:4px;padding:2px 3px;font-size:10px;width:90px"
            data-mevcut="<?php echo htmlspecialchars($b_hat1);?>"><!-- JS doldurur --></select>
          <input type="number" id="bolme_oran1_<?php echo htmlspecialchars($stok_kodu);?>"
            value="<?php echo $b_oran1;?>" min="0" max="100" step="5"
            style="width:38px;border:1px solid #E2E8F0;border-radius:4px;padding:2px 3px;font-size:10px;text-align:right">
          <span style="font-size:10px;color:#94A3B8">%+</span>
          <select id="bolme_hat2_<?php echo htmlspecialchars($stok_kodu);?>"
            style="border:1px solid #E2E8F0;border-radius:4px;padding:2px 3px;font-size:10px;width:90px"
            data-mevcut="<?php echo htmlspecialchars($b_hat2);?>"><!-- JS doldurur --></select>
          <input type="number" id="bolme_oran2_<?php echo htmlspecialchars($stok_kodu);?>"
            value="<?php echo $b_oran2;?>" min="0" max="100" step="5"
            style="width:38px;border:1px solid #E2E8F0;border-radius:4px;padding:2px 3px;font-size:10px;text-align:right">
          <span style="font-size:10px;color:#94A3B8">%</span>
          <button onclick="mntBolmeKaydetUl('<?php echo htmlspecialchars($stok_kodu);?>')"
            id="bolmebtn_<?php echo htmlspecialchars($stok_kodu);?>"
            style="background:#7C3AED;color:#fff;border:none;padding:2px 6px;border-radius:4px;cursor:pointer;font-size:10px">💾</button>
          <?php if($b):?>
          <button onclick="mntBolmeSilUl('<?php echo htmlspecialchars($stok_kodu);?>')"
            style="background:#FEE2E2;color:#991B1B;border:none;padding:2px 5px;border-radius:4px;cursor:pointer;font-size:10px">✕</button>
          <?php endif;?>
        </div>
        <?php if($b):?>
        <div style="font-size:9px;color:#7C3AED;margin-top:1px">
          ⚖️ <?php echo $b['hat1'];?> <?php echo $b['oran1'];?>% + <?php echo $b['hat2'];?> <?php echo $b['oran2'];?>%
        </div>
        <?php endif;?>
      </td>
      <?php for($ay=1;$ay<=12;$ay++):
        $m = (float)($ay_miktarlar[$ay]??0);
      ?>
      <td style="padding:3px 4px;border:1px solid #E5E7EB;text-align:right;<?php echo $m>0?'':'color:#CBD5E1';?>">
        <?php echo $m>0?number_format($m,0):'·';?>
      </td>
      <?php endfor;?>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  </div>
</div>
</div><!-- /tab4 -->

<!-- ══ TAB 5: DEBUG ════════════════════════════════════════════════ -->
<div id="mtab5" style="display:none">
<div class="kart" style="padding:0;border-radius:8px;overflow:hidden">
<div style="background:#1E293B;padding:10px 14px;display:flex;align-items:center;justify-content:space-between">
  <span style="color:#FCD34D;font-weight:700;font-size:12px">🔍 Debug — Operasyon Verileri</span>
  <span style="color:#94A3B8;font-size:11px">Toplam op: <?php echo count($op_data);?> | Eşleşen: <?php echo $eslesen;?> | BOM: <?php echo $bom_eslesen;?> | Bölmeli: <?php echo $bolme_eslesen;?> | Op.yok: <?php echo $op_yok;?> | Hatsız: <?php echo $eslesmez;?></span>
</div>
<div style="overflow-x:auto;max-height:500px;overflow-y:auto">
<table style="border-collapse:collapse;font-size:11px;width:100%;white-space:nowrap">
  <thead style="position:sticky;top:0">
  <tr style="background:#0F172A">
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B;text-align:left">Stok Kodu</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B;text-align:left">Stok Adı</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Hat</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Çevrim(sn)</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Parti</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Saatlik kap.</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Kaynak</th>
    <th style="color:#93C5FD;padding:6px 8px;border:1px solid #1E293B">Hat Bölme</th>
  </tr>
  </thead>
  <tbody>
  <?php
  $dbg_say = 0;
  foreach ($op_data as $sk => $op):
    // Her hat için ayrı satır göster
    foreach ($op['hatlar'] as $dbg_hat => $dbg_op):
    $dbg_say++;
    $saatlik = $dbg_op['cevrim_sn']>0 ? (3600/$dbg_op['cevrim_sn'])*$dbg_op['parti'] : 0;
    $kaynak = isset($hat_atamalari[$sk]) ? '<span style="color:#60A5FA">DB</span>' : '<span style="color:#FCD34D">Op.</span>';
    $bolme_bilgi = isset($hat_bolme[$sk])
      ? '<span style="color:#86EFAC">'.$hat_bolme[$sk]['hat1'].' %'.number_format($hat_bolme[$sk]['oran1'],0).' + '.$hat_bolme[$sk]['hat2'].' %'.number_format($hat_bolme[$sk]['oran2'],0).'</span>'
      : '<span style="color:#475569">—</span>';
    $row_bg = $dbg_say % 2 === 0 ? 'background:#1E293B' : 'background:#0F172A';
  ?>
  <tr style="<?php echo $row_bg;?>">
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#86EFAC;font-weight:700"><?php echo htmlspecialchars($sk);?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#CBD5E1;max-width:220px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_substr($op['_adi']??'',0,40));?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#93C5FD;text-align:center"><?php echo htmlspecialchars($dbg_hat);?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#FCA5A5;text-align:right"><?php echo number_format($dbg_op['cevrim_sn'],2);?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#E2E8F0;text-align:right"><?php echo $dbg_op['parti'];?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B;color:#FCD34D;text-align:right;font-weight:600"><?php echo number_format($saatlik,1);?>/sa</td>
    <td style="padding:3px 8px;border:1px solid #1E293B;text-align:center"><?php echo $kaynak;?></td>
    <td style="padding:3px 8px;border:1px solid #1E293B"><?php echo $bolme_bilgi;?></td>
  </tr>
  <?php endforeach; endforeach;?>
  </tbody>
</table>
</div>
<div style="background:#0F172A;padding:8px 14px;font-size:11px;color:#64748B">
  Hat yüklemleri (sıfır hariç):
  <?php foreach($hat_yuklem as $h=>$aylar): $t=array_sum($aylar); if($t<=0) continue;?>
  <span style="color:#93C5FD;margin-right:8px"><?php echo $h;?>: <?php echo number_format($t,1);?>g</span>
  <?php endforeach;?>
</div>
<div style="background:#0F172A;padding:8px 14px;font-size:11px;color:#64748B;border-top:1px solid #1E293B">
  Manuel BOM kayıtları:
  <?php foreach($manuel_bom_data as $mk=>$altlar):
    $fc_mamul = $forecast[$mk] ?? null;
    $fc_toplam = 0;
    if($fc_mamul) for($i=1;$i<=12;$i++) $fc_toplam+=(float)($fc_mamul['ay'.$i]??0);
    // Bu mamul Tiger BOM'da üst mamulün alt malzemesi olarak geçiyor mu?
    $bom_kaynak = [];
    foreach($bom as $ust=>$altlarBom) {
        if(isset($altlarBom[$mk])) $bom_kaynak[] = $ust.'×'.number_format($altlarBom[$mk],2);
    }
  ?>
  <br><span style="color:#FCD34D"><?php echo $mk;?></span>
  <span style="color:<?php echo $fc_mamul?'#86EFAC':'#FCA5A5';?>">[fc:<?php echo $fc_mamul?number_format($fc_toplam,0):'YOK';?>]</span>
  <?php if($bom_kaynak): ?>
  <span style="color:#93C5FD">[2.seviye üstü:<?php echo implode(' | ',$bom_kaynak);?>]</span>
  <?php endif; ?> →
  <?php foreach($altlar as $ak=>$mik): ?>
  <span style="color:<?php echo isset($op_data[$ak])?'#86EFAC':'#FCA5A5';?>;margin-right:4px">
    <?php echo $ak;?>(<?php echo $mik;?>)
    <?php echo isset($op_data[$ak])?'✓op':'✗op';?>
    [_ilk:<?php echo htmlspecialchars($op_data[$ak]['_ilk']??'BOŞ');?>]
    <?php echo isset($hat_atamalari[$ak])?'✓hat':'✗hat';?>
    <?php echo isset($hesap_forecast[$ak])?'✓fc['.number_format(array_sum($hesap_forecast[$ak]),0).']':'✗fc';?>
  </span>
  <?php endforeach; ?>
  <?php endforeach;?>
</div>
</div>
</div><!-- /tab5 -->

<!-- ══ MTAB6: HAT PERSONEL ═══════════════════════════════════════ -->
<div id="mtab6" style="display:none">
<div class="kart" style="padding:16px;margin-bottom:12px">
  <div style="font-weight:700;font-size:13px;color:#1E3A5F;margin-bottom:4px">⚙️ Montaj Hat Personel Ayarları</div>
  <div style="font-size:11px;color:#64748B;margin-bottom:12px">
    Her hat için norm personel (1 vardiya) ve vardiya sayısını düzenleyin.
    3 vardiya hatlarda toplam personel = norm × 3.
    Değişiklikler sayfayı yenileyince hesaplamalara yansır.
  </div>
  <div style="overflow-x:auto">
  <table style="border-collapse:collapse;font-size:12px;width:100%">
    <thead>
      <tr style="background:#1E3A5F;color:#e0f0ff">
        <th style="padding:7px 10px;border:1px solid #2d5986;text-align:left;min-width:180px">Hat</th>
        <th style="padding:7px 10px;border:1px solid #2d5986;width:80px">Norm P.</th>
        <th style="padding:7px 10px;border:1px solid #2d5986;width:90px">Vardiya</th>
        <th style="padding:7px 10px;border:1px solid #2d5986;width:80px">Toplam P.</th>
        <th style="padding:7px 10px;border:1px solid #2d5986;width:80px">Saat/gün</th>
        <th style="padding:7px 10px;border:1px solid #2d5986;width:70px">Kaydet</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($tonaj_gruplari as $grp=>$hatlar):?>
    <tr style="background:#E2E8F0"><td colspan="6" style="padding:5px 10px;font-weight:800;font-size:11px;color:#1E3A5F;border:1px solid #CBD5E1"><?php echo $grp;?></td></tr>
    <?php foreach($hatlar as $hat):
      $norm  = $hat_personel[$hat]??1;
      $is3v  = in_array($hat,$hat_3vardiya);
      $vard  = $is3v ? 3 : 1;
      $top   = $hat_personel_toplam[$hat]??$norm;
      $saat  = $hat_saat[$hat]??7;
    ?>
    <tr style="<?php echo $is3v?'background:#FFFBEB':'';?>">
      <td style="padding:5px 10px;border:1px solid #E5E7EB;font-weight:700;color:#1E3A5F">
        <?php echo htmlspecialchars($hat);?>
        <?php if($is3v):?><small style="background:#FEF9C3;color:#854D0E;padding:0 4px;border-radius:3px;margin-left:4px">3 vardiya</small><?php endif;?>
      </td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center">
        <input type="number" id="mhp_norm_<?php echo md5($hat);?>"
          value="<?php echo $norm;?>" min="1" max="20"
          style="width:50px;border:1px solid #E2E8F0;border-radius:4px;padding:3px 5px;font-size:13px;font-weight:700;text-align:center">
      </td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center">
        <select id="mhp_vard_<?php echo md5($hat);?>"
          style="width:65px;border:1px solid #E2E8F0;border-radius:4px;padding:3px 4px;font-size:12px">
          <option value="1"<?php echo !$is3v?' selected':'';?>>1 vardiya</option>
          <option value="3"<?php echo $is3v?' selected':'';?>>3 vardiya</option>
        </select>
      </td>
      <td style="padding:5px 8px;border:1px solid #E5E7EB;text-align:center;font-weight:700;color:#065F46" id="mhp_top_<?php echo md5($hat);?>"><?php echo $top;?>K</td>
      <td style="padding:5px 8px;border:1px solid #E5E7EB;text-align:center;color:#64748B"><?php echo $saat;?> saat</td>
      <td style="padding:4px 8px;border:1px solid #E5E7EB;text-align:center">
        <button onclick="mhpKaydet('<?php echo htmlspecialchars($hat,ENT_QUOTES);?>','<?php echo md5($hat);?>')"
          id="mhp_btn_<?php echo md5($hat);?>"
          style="background:#1E3A5F;color:#fff;border:none;padding:4px 10px;border-radius:5px;cursor:pointer;font-size:11px;font-weight:600">
          💾
        </button>
      </td>
    </tr>
    <?php endforeach; endforeach;?>
    </tbody>
  </table>
  </div>
</div>
</div><!-- /mtab6 -->

<script>
function sekmeAc(id) {
  ['mtab1','mtab2','mtab3','mtab4','mtab5','mtab6'].forEach(function(t) {
    document.getElementById(t).style.display = t===id ? '' : 'none';
    var btn = document.getElementById('btn-'+t);
    if (t===id) { btn.style.background='#1E3A5F'; btn.style.color='#fff'; }
    else        { btn.style.background='#F1F5F9'; btn.style.color='#64748B'; }
  });
  if (id==='mtab4') setTimeout(urunFiltreUygula, 50);
}

function mntFiltreUygula() {
  var metin  = document.getElementById('mntFiltre').value.toLowerCase();
  var hat    = document.getElementById('mntHatFiltre').value;
  var kaynak = document.getElementById('mntKaynakFiltre').value;
  var satirlar = document.querySelectorAll('#mntListeBody tr');
  var gorunen = 0;
  satirlar.forEach(function(tr) {
    var goster = true;
    if (metin && tr.dataset.kod.indexOf(metin)===-1 && tr.dataset.ad.indexOf(metin)===-1) goster=false;
    if (hat    && tr.dataset.hat !== hat)    goster=false;
    if (kaynak && tr.dataset.kaynak !== kaynak) goster=false;
    tr.style.display = goster ? '' : 'none';
    if (goster) gorunen++;
  });
  document.getElementById('mntSayac').textContent = gorunen + ' / ' + satirlar.length + ' ürün';
}
document.addEventListener('DOMContentLoaded', function() {
  mntFiltreUygula();

  // Hat seçim dropdownlarını doldur (hat değiştir + hat bölme)
  var hatOpts = _mntData.hat_sirasi.map(function(h) {
    return '<option value="' + h + '">' + h + '</option>';
  }).join('');
  var hatOptsWithEmpty = '<option value="">— seçin —</option>' + hatOpts;

  // Hat değiştir selects
  document.querySelectorAll('select[id^="ulhat_"]').forEach(function(sel) {
    var mevcut = sel.dataset.mevcut || '';
    sel.innerHTML = hatOpts;
    for (var i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value === mevcut) { sel.selectedIndex = i; break; }
    }
  });

  // Hat bölme selects (hat1 ve hat2)
  document.querySelectorAll('select[id^="bolme_hat1_"], select[id^="bolme_hat2_"]').forEach(function(sel) {
    var mevcut = sel.dataset.mevcut || '';
    sel.innerHTML = sel.id.startsWith('bolme_hat2_') ? hatOptsWithEmpty : hatOpts;
    for (var i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value === mevcut) { sel.selectedIndex = i; break; }
    }
  });

  // Oran1 değişince oran2'yi otomatik tamamla
  document.querySelectorAll('input[id^="bolme_oran1_"]').forEach(function(inp) {
    inp.addEventListener('input', function() {
      var sk = this.id.replace('bolme_oran1_', '');
      var inp2 = document.getElementById('bolme_oran2_' + sk);
      if (inp2) inp2.value = Math.max(0, 100 - parseFloat(this.value || 0));
    });
  });
});

function mntBolmeKaydetUl(sk) {
  var hat1  = document.getElementById('bolme_hat1_'+sk)?.value;
  var oran1 = parseFloat(document.getElementById('bolme_oran1_'+sk)?.value||0);
  var hat2  = document.getElementById('bolme_hat2_'+sk)?.value;
  var oran2 = parseFloat(document.getElementById('bolme_oran2_'+sk)?.value||0);
  var btn   = document.getElementById('bolmebtn_'+sk);

  if (!hat1 || !hat2) { alert('Her iki hattı da seçin'); return; }
  if (hat1 === hat2)  { alert('Aynı hat seçilemez'); return; }
  if (Math.abs(oran1+oran2-100) > 0.5) { alert('Oranlar toplamı 100 olmalı (şu an: '+(oran1+oran2)+')'); return; }

  btn.disabled=true; btn.textContent='...';
  var fd=new FormData();
  fd.append('action','kaydet'); fd.append('stok_kodu',sk);
  fd.append('hat1',hat1); fd.append('oran1',oran1);
  fd.append('hat2',hat2); fd.append('oran2',oran2);
  fetch(BASE_URL+'/bolumler/planlama/ajax/hat_bolme_kaydet.php',{
    method:'POST',body:fd,credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{
    btn.disabled=false;
    if(d.ok){ btn.textContent='✅'; btn.style.background='#059669'; setTimeout(()=>location.reload(),700); }
    else { btn.textContent='💾'; alert('Hata: '+(d.msg||'')); }
  }).catch(e=>{btn.disabled=false;btn.textContent='💾';alert(e.message);});
}

function mntBolmeSilUl(sk) {
  if(!confirm('Hat bölmesi silinsin mi?')) return;
  var fd=new FormData();
  fd.append('action','sil'); fd.append('stok_kodu',sk);
  fetch(BASE_URL+'/bolumler/planlama/ajax/hat_bolme_kaydet.php',{
    method:'POST',body:fd,credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{ if(d.ok) location.reload(); else alert('Hata: '+(d.msg||'')); });
}
</script>


<!-- HAT DEĞİŞTİR MODALİ -->
<div id="mntHatModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:1100px;box-shadow:0 20px 60px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">
  <div style="background:linear-gradient(135deg,#065F46,#047857);border-radius:14px 14px 0 0;padding:13px 18px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:2">
    <div>
      <div style="color:#fff;font-size:14px;font-weight:800">⚙️ Hat Ataması Değiştir</div>
      <div id="mntHatModalBaslik" style="color:rgba(255,255,255,.75);font-size:11px"></div>
    </div>
    <button onclick="mntHatKapat()" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:30px;height:30px;border-radius:8px;cursor:pointer">✕</button>
  </div>
  <div style="padding:16px">
    <div style="font-size:11px;color:#64748B;margin-bottom:12px;background:#F8FAFC;padding:8px 10px;border-radius:6px">
      DB ataması Tiger operasyon bilgisine göre önceliklidir. &nbsp;|&nbsp; <span style="color:#6B21A8">Mor = BOM alt malzeme</span>
    </div>
    <div id="mntHatModalIcerik"></div>
    <div style="text-align:right;margin-top:12px">
      <button onclick="mntHatKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:7px 16px;border-radius:6px;font-size:12px;cursor:pointer">Kapat</button>
    </div>
  </div>
</div>
</div>

<script>
var _mntData = {
  hat_sirasi:   <?php echo json_encode($hat_sirasi,   JSON_UNESCAPED_UNICODE);?>,
  hat_atamalari:<?php echo json_encode($hat_atamalari,JSON_UNESCAPED_UNICODE);?>,
  op_hatlar:    <?php echo json_encode(array_map(fn($v)=>$v['_ilk']??'',$op_data),JSON_UNESCAPED_UNICODE);?>,
  stok_adlari:  <?php
    // op_data'dan + forecast tablosundaki stok_adi
    $tum_adlar = array_map(fn($v)=>$v['_adi']??'', $op_data);
    foreach($forecast as $sk=>$fc) {
        if (!isset($tum_adlar[$sk]) || $tum_adlar[$sk]==='') {
            $tum_adlar[$sk] = $fc['stok_adi'] ?? '';
        }
    }
    echo json_encode($tum_adlar, JSON_UNESCAPED_UNICODE);
  ?>,
  hat_urunler:  <?php echo json_encode($hat_urunler,  JSON_UNESCAPED_UNICODE);?>,
  op_hat_listesi: <?php
    // Operasyonda gerçekten tanımlı olan unique EN- hatları
    $op_hat_unique = array_values(array_unique(array_map(fn($v)=>$v['_ilk']??'', $op_data)));
    sort($op_hat_unique);
    echo json_encode($op_hat_unique, JSON_UNESCAPED_UNICODE);
  ?>,
  hat_bolme: <?php echo json_encode(
    array_map(fn($v)=>['hat1'=>$v['hat1'],'oran1'=>$v['oran1'],'hat2'=>$v['hat2'],'oran2'=>$v['oran2']], $hat_bolme),
    JSON_UNESCAPED_UNICODE
  );?>
};

function mntHatAtaAc(hat) {
  document.getElementById('mntHatModal').style.display='flex';
  document.getElementById('mntHatModalBaslik').textContent = hat+' hattına bağlı ürünler';
  var urunler = _mntData.hat_urunler[hat]||[];
  if (!urunler.length) {
    document.getElementById('mntHatModalIcerik').innerHTML='<div style="text-align:center;padding:20px;color:#94A3B8">Bu hatta atanmış ürün yok.</div>';
    return;
  }

  // Güvenli option oluşturucu
  function makeOpts(secili, withEmpty) {
    var html = withEmpty ? '<option value="">— seçin —</option>' : '';
    _mntData.hat_sirasi.forEach(function(h) {
      html += '<option value="'+h+'"'+(h===secili?' selected':'')+'>'+h+'</option>';
    });
    return html;
  }

  var html='<table style="width:100%;border-collapse:collapse;font-size:12px">';
  html+='<thead><tr style="background:#F1F5F9">';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0">Stok Kodu</th>';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0">Stok Adı</th>';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0;width:60px">Kaynak</th>';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0">Tek Hat</th>';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0;min-width:260px">⚖️ Hat Bölme (oran1+oran2=100)</th>';
  html+='<th style="padding:6px 8px;border:1px solid #E2E8F0;width:50px">Kaydet</th>';
  html+='</tr></thead><tbody>';

  urunler.forEach(function(sk) {
    var sk_t   = sk.replace('*','');
    var is_bom = sk.endsWith('*');
    var ad     = _mntData.stok_adlari[sk_t] || '';
    var mevcut = _mntData.hat_atamalari[sk_t]||_mntData.op_hatlar[sk_t]||hat;
    var bolme  = _mntData.hat_bolme[sk_t]||null;

    var b_hat1  = bolme ? bolme.hat1  : mevcut;
    var b_oran1 = bolme ? bolme.oran1 : 100;
    var b_hat2  = bolme ? bolme.hat2  : '';
    var b_oran2 = bolme ? bolme.oran2 : 0;

    var opts  = makeOpts(mevcut, false);
    var opts1 = makeOpts(b_hat1, false);
    var opts2 = makeOpts(b_hat2, true);

    var badge = _mntData.hat_atamalari[sk_t]
      ? '<span style="background:#DBEAFE;color:#1E40AF;padding:1px 6px;border-radius:4px;font-size:10px">DB</span>'
      : (is_bom
          ? '<span style="background:#F3E8FF;color:#6B21A8;padding:1px 6px;border-radius:4px;font-size:10px">BOM</span>'
          : '<span style="background:#FEF9C3;color:#854D0E;padding:1px 6px;border-radius:4px;font-size:10px">Op.</span>');

    html+='<tr id="row_'+sk_t+'" style="'+(bolme?'background:#FAF5FF':'')+(is_bom?';opacity:.85':'')+'">';
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;font-weight:700;white-space:nowrap;color:#065F46">'+sk_t+'</td>';
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;font-size:11px;color:#475569;min-width:180px">'+(ad||'<span style="color:#CBD5E1;font-style:italic">—</span>')+'</td>';
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;text-align:center">'+badge+'</td>';

    // Tek hat
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;white-space:nowrap">';
    html+='<select id="nh_'+sk_t+'" style="width:110px;border:1px solid #E2E8F0;border-radius:4px;padding:3px;font-size:11px">'+opts+'</select>';
    html+='</td>';

    // Hat bölme — dikey
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;min-width:240px">';
    html+='<div style="display:flex;gap:4px;align-items:center;margin-bottom:4px">';
    html+='<span style="font-size:10px;color:#6B21A8;width:14px;font-weight:700">1.</span>';
    html+='<select id="mnh1_'+sk_t+'" onchange="mntOran2Guncelle(\''+sk_t+'\')" style="flex:1;border:1px solid #DDD6FE;border-radius:4px;padding:2px 4px;font-size:11px">'+opts1+'</select>';
    html+='<input type="number" id="mo1_'+sk_t+'" value="'+b_oran1+'" min="0" max="100" step="5" oninput="mntOran2Guncelle(\''+sk_t+'\')" style="width:42px;border:1px solid #DDD6FE;border-radius:4px;padding:2px 4px;font-size:11px;text-align:right">';
    html+='<span style="font-size:10px;color:#94A3B8">%</span>';
    html+='</div>';
    html+='<div style="display:flex;gap:4px;align-items:center">';
    html+='<span style="font-size:10px;color:#6B21A8;width:14px;font-weight:700">2.</span>';
    html+='<select id="mnh2_'+sk_t+'" style="flex:1;border:1px solid #DDD6FE;border-radius:4px;padding:2px 4px;font-size:11px">'+opts2+'</select>';
    html+='<input type="number" id="mo2_'+sk_t+'" value="'+b_oran2+'" min="0" max="100" step="5" style="width:42px;border:1px solid #DDD6FE;border-radius:4px;padding:2px 4px;font-size:11px;text-align:right">';
    html+='<span style="font-size:10px;color:#94A3B8">%</span>';
    if (bolme) html+='<button onclick="mntBolmeSil(\''+sk_t+'\')" style="background:#FEE2E2;color:#991B1B;border:none;padding:2px 6px;border-radius:4px;cursor:pointer;font-size:10px;margin-left:2px" title="Bölmeyi sil">✕</button>';
    html+='</div>';
    if (bolme) html+='<div style="font-size:9px;color:#7C3AED;margin-top:3px;background:#F3E8FF;padding:2px 6px;border-radius:4px">⚖️ '+bolme.hat1+' '+bolme.oran1+'% + '+bolme.hat2+' '+bolme.oran2+'%</div>';
    html+='</td>';

    // Kaydet
    html+='<td style="padding:5px 8px;border:1px solid #E2E8F0;text-align:center;white-space:nowrap">';
    html+='<div style="display:flex;flex-direction:column;gap:3px">';
    html+='<button onclick="mntHatKaydet(\''+sk_t+'\')" id="btn_'+sk_t+'" style="background:#065F46;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px">💾 Hat</button>';
    html+='<button onclick="mntBolmeKaydet(\''+sk_t+'\')" id="bbtn_'+sk_t+'" style="background:#7C3AED;color:#fff;border:none;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:11px">⚖️ Böl</button>';
    html+='</div>';
    html+='</td>';
    html+='</tr>';
  });
  html+='</tbody></table>';
  document.getElementById('mntHatModalIcerik').innerHTML=html;
}

// Oran2'yi otomatik tamamla
function mntOran2Guncelle(sk) {
  var o1 = parseFloat(document.getElementById('mo1_'+sk)?.value||0);
  var el2 = document.getElementById('mo2_'+sk);
  if (el2) el2.value = Math.max(0, 100 - o1);
}

// Modaldan hat bölme kaydet
function mntBolmeKaydet(sk) {
  var hat1  = document.getElementById('mnh1_'+sk)?.value;
  var oran1 = parseFloat(document.getElementById('mo1_'+sk)?.value||0);
  var hat2  = document.getElementById('mnh2_'+sk)?.value;
  var oran2 = parseFloat(document.getElementById('mo2_'+sk)?.value||0);
  var btn   = document.getElementById('bbtn_'+sk);

  if (!hat1 || !hat2) { alert('Her iki hattı seçin'); return; }
  if (hat1===hat2)    { alert('Aynı hat seçilemez'); return; }
  if (Math.abs(oran1+oran2-100)>0.5) { alert('Oranlar toplamı 100 olmalı (şu an: '+(oran1+oran2)+')'); return; }

  btn.disabled=true; btn.textContent='...';
  var fd=new FormData();
  fd.append('action','kaydet'); fd.append('stok_kodu',sk);
  fd.append('hat1',hat1); fd.append('oran1',oran1);
  fd.append('hat2',hat2); fd.append('oran2',oran2);
  fetch(BASE_URL+'/bolumler/planlama/ajax/hat_bolme_kaydet.php',{
    method:'POST',body:fd,credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{
    btn.disabled=false;
    if(d.ok){
      btn.textContent='✅'; btn.style.background='#059669';
      _mntData.hat_bolme[sk]={hat1:hat1,oran1:oran1,hat2:hat2,oran2:oran2};
      setTimeout(()=>location.reload(),600);
    } else { btn.textContent='⚖️Böl'; alert('Hata: '+(d.msg||'')); }
  }).catch(e=>{btn.disabled=false;btn.textContent='⚖️Böl';alert(e.message);});
}

// Modaldan hat bölme sil
function mntBolmeSil(sk) {
  if(!confirm('Hat bölmesi silinsin mi?')) return;
  var fd=new FormData();
  fd.append('action','sil'); fd.append('stok_kodu',sk);
  fetch(BASE_URL+'/bolumler/planlama/ajax/hat_bolme_kaydet.php',{
    method:'POST',body:fd,credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{ if(d.ok) location.reload(); else alert('Hata: '+(d.msg||'')); });
}

function mntHatKapat(){ document.getElementById('mntHatModal').style.display='none'; }

function mntHatKaydet(sk) {
  var yeni=document.getElementById('nh_'+sk).value;
  var btn=document.getElementById('btn_'+sk);
  btn.disabled=true; btn.textContent='...';
  var fd=new FormData();
  fd.append('action','hat_ata'); fd.append('stok_kodu',sk);
  fd.append('ist_kodu',yeni); fd.append('ist_turu','montaj');
  fetch(BASE_URL+'/bolumler/planlama/ajax/norm_hat_ata.php',{
    method:'POST',body:fd,credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{
    if(d.ok||d.success){btn.textContent='✅';btn.style.background='#059669';setTimeout(()=>location.reload(),600);}
    else{btn.disabled=false;btn.textContent='💾';alert('Hata:'+(d.hata||d.msg||''));}
  }).catch(e=>{btn.disabled=false;btn.textContent='💾';alert(e.message);});
}
function mntUlHatKaydet(sk) {
  var sel = document.getElementById('ulhat_' + sk);
  var btn = document.getElementById('ulbtn_' + sk);
  if (!sel) return;
  var yeni_hat = sel.value;
  var eski_hat = sel.dataset.mevcut;
  if (yeni_hat === eski_hat) { alert('Hat değişmedi.'); return; }

  btn.disabled = true; btn.textContent = '...';

  var fd = new FormData();
  fd.append('action',    'hat_ata');
  fd.append('stok_kodu', sk);
  fd.append('ist_kodu',  yeni_hat);
  fd.append('ist_turu',  'enjeksiyon');

  fetch(BASE_URL + '/bolumler/planlama/ajax/norm_hat_ata.php', {
    method: 'POST', body: fd, credentials: 'same-origin',
    headers: { 'X-Requested-With': 'XMLHttpRequest' }
  })
  .then(r => r.json())
  .then(d => {
    if (d.ok || d.success) {
      btn.textContent = '✅'; btn.style.background = '#059669';
      sel.dataset.mevcut = yeni_hat;
      _mntData.hat_atamalari[sk] = yeni_hat;
      // Satırdaki hat hücresini güncelle
      var tr = btn.closest('tr');
      if (tr) {
        tr.dataset.hat = yeni_hat;
        var hatTd = tr.querySelector('td:nth-child(3)');
        if (hatTd) hatTd.textContent = yeni_hat;
      }
      setTimeout(function() { btn.textContent = '💾'; btn.style.background = '#1E3A5F'; btn.disabled = false; }, 1500);
    } else {
      btn.disabled = false; btn.textContent = '💾';
      alert('Hata: ' + (d.hata || d.msg || ''));
    }
  })
  .catch(function(e) { btn.disabled = false; btn.textContent = '💾'; alert(e.message); });
}

// ── MAIL OLUŞTUR ──────────────────────────────────────────────────
function mntMailOlustur() {
  document.getElementById('mntMailModal').style.display = 'flex';
  var html = mntOlusturMailHTML();
  document.getElementById('mntMailOnizleme').innerHTML = html;
  document.getElementById('mailIcerik').value = html;
}
function mntMailKapat() {
  document.getElementById('mntMailModal').style.display = 'none';
}

function mntOlusturMailHTML() {
  var sel_yil = '<?php echo $sel_yil;?>';
  var etkin   = '<?php echo number_format($etkin_kap,1);?>';
  var tarih   = new Date().toLocaleDateString('tr-TR',{day:'2-digit',month:'long',year:'numeric'});

  // Ay adları
  var aylar = ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara];
  var ayBugun = new Date().getMonth(); // 0-indexed

  // Renk fonksiyonu (inline stil için)
  function renk(pct) {
    if (!pct || pct === '·') return {bg:'#F8FAFC',fg:'#94A3B8'};
    var p = parseFloat(pct);
    if (p < 30)  return {bg:'#DCFCE7',fg:'#166534'};
    if (p < 65)  return {bg:'#FEF9C3',fg:'#854D0E'};
    if (p < 90)  return {bg:'#FED7AA',fg:'#C2410C'};
    if (p < 100) return {bg:'#FECACA',fg:'#B91C1C'};
    return {bg:'#7F1D1D',fg:'#FCA5A5'};
  }

  var h = '';
  h += '<div style="font-family:Calibri,Arial,sans-serif;max-width:900px">';
  h += '<h2 style="color:#065F46;margin:0 0 4px">🔧 Montaj Kapasite Doluluk — '+sel_yil+'</h2>';
  h += '<p style="color:#64748B;font-size:13px;margin:0 0 16px">'+tarih+' &nbsp;|&nbsp; Etkin kapasite: '+etkin+' gün/hat</p>';

  // Renk açıklaması
  h += '<p style="font-size:12px;margin:0 0 12px">';
  h += '<span style="background:#DCFCE7;color:#166534;padding:2px 8px;border-radius:3px;margin-right:4px">0–30% düşük</span>';
  h += '<span style="background:#FEF9C3;color:#854D0E;padding:2px 8px;border-radius:3px;margin-right:4px">30–65% orta</span>';
  h += '<span style="background:#FED7AA;color:#C2410C;padding:2px 8px;border-radius:3px;margin-right:4px">65–90% yüksek</span>';
  h += '<span style="background:#FECACA;color:#B91C1C;padding:2px 8px;border-radius:3px;margin-right:4px">90–100% kritik</span>';
  h += '<span style="background:#7F1D1D;color:#FCA5A5;padding:2px 8px;border-radius:3px">&gt;100% aşım</span>';
  h += '</p>';

  // Tablo
  h += '<table style="border-collapse:collapse;font-size:12px;width:100%">';
  h += '<thead><tr>';
  h += '<th style="background:#065F46;color:#e0f0ff;padding:6px 8px;border:1px solid #047857;text-align:left;min-width:90px">Hat</th>';
  aylar.forEach(function(ay, i) {
    var bg = i === ayBugun ? '#1D4ED8' : '#1E3A5F';
    h += '<th style="background:'+bg+';color:#e0f0ff;padding:6px 6px;border:1px solid #047857;text-align:center;min-width:40px">'+ay+'</th>';
  });
  h += '<th style="background:#065F46;color:#e0f0ff;padding:6px 8px;border:1px solid #047857;text-align:center">Ort.%</th>';
  h += '</tr></thead><tbody>';

  // Tab2 tablosundaki satırları oku
  var satirlar = document.querySelectorAll('#mtab2 .enj-tbl tbody tr');
  satirlar.forEach(function(tr) {
    if (tr.classList.contains('grup-hdr')) {
      // Grup başlık
      var baslik = tr.querySelector('td') ? tr.querySelector('td').textContent.trim() : '';
      h += '<tr><td colspan="14" style="background:#E2E8F0;font-weight:700;font-size:11px;color:#065F46;padding:5px 8px;border:1px solid #CBD5E1">'+baslik+'</td></tr>';
    } else if (tr.style.background && tr.style.background.includes('E0E7FF')) {
      // Grup ortalaması satırı (italik, mavi)
      var cells = tr.querySelectorAll('td');
      if (!cells.length) return;
      h += '<tr>';
      cells.forEach(function(td, i) {
        if (i === 0) {
          h += '<td style="background:#EEF2FF;color:#4338CA;font-size:10px;font-style:italic;padding:3px 8px;border:1px solid #E2E8F0" colspan="2">'+td.textContent.trim()+'</td>';
        } else if (i > 1) {
          var pct = td.textContent.trim();
          var c = renk(pct);
          h += '<td style="background:'+c.bg+';color:'+c.fg+';padding:3px 4px;border:1px solid #E2E8F0;text-align:center;font-size:10px;font-style:italic">'+pct+'</td>';
        }
      });
      h += '</tr>';
    } else {
      var cells = tr.querySelectorAll('td');
      if (!cells.length) return;
      h += '<tr>';
      cells.forEach(function(td, i) {
        if (i === 0) {
          // Hat adı
          h += '<td style="padding:4px 8px;border:1px solid #E5E7EB;font-weight:700;color:#065F46">'+td.textContent.trim()+'</td>';
        } else if (i === 1) {
          // ⚙️ sütunu — atla
        } else {
          var pct = td.textContent.trim();
          var c = renk(pct);
          h += '<td style="background:'+c.bg+';color:'+c.fg+';padding:4px 4px;border:1px solid #E5E7EB;text-align:center">'+pct+'</td>';
        }
      });
      h += '</tr>';
    }
  });

  h += '</tbody></table>';
  h += '<p style="color:#94A3B8;font-size:11px;margin-top:10px">Bu rapor Jetone ERP sisteminden otomatik oluşturulmuştur.</p>';
  h += '</div>';
  return h;
}

function mntMailKopyala() {
  var onizleme = document.getElementById('mntMailOnizleme');
  var range = document.createRange();
  range.selectNodeContents(onizleme);
  var sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
  document.execCommand('copy');
  sel.removeAllRanges();
  var btn = document.getElementById('mntMailKopyalaBtn');
  btn.textContent = '✅ Kopyalandı!'; btn.style.background = '#059669';
  setTimeout(function(){ btn.textContent = '📋 Kopyala (Outlook\'a yapıştır)'; btn.style.background = '#1D4ED8'; }, 2500);
}

function mhpKaydet(hat, hid) {
  var norm = parseInt(document.getElementById('mhp_norm_'+hid)?.value||1)||1;
  var vard = parseInt(document.getElementById('mhp_vard_'+hid)?.value||1)||1;
  var btn  = document.getElementById('mhp_btn_'+hid);
  var topEl= document.getElementById('mhp_top_'+hid);
  btn.disabled=true; btn.textContent='⏳';
  var fd=new FormData();
  fd.append('action','kaydet');
  fd.append('hat_kodu', hat);
  fd.append('norm_pers', norm);
  fd.append('vardiya', vard);
  fetch(BASE_URL+'/bolumler/planlama/ajax/montaj_hat_pers_kaydet.php',{
    method:'POST', body:fd, credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'}
  }).then(r=>r.json()).then(d=>{
    btn.disabled=false;
    if(d.ok){
      btn.textContent='✅'; btn.style.background='#059669';
      if(topEl) topEl.textContent=(vard===3?norm*3:norm)+'K';
      setTimeout(()=>{ btn.textContent='💾'; btn.style.background='#1E3A5F'; },2000);
    } else {
      btn.textContent='💾'; alert('Hata: '+(d.msg||''));
    }
  }).catch(e=>{btn.disabled=false;btn.textContent='💾';alert(e.message);});
}

</script>

<!-- MAIL MODALİ -->
<div id="mntMailModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:1002;align-items:flex-start;justify-content:center;padding:16px;overflow-y:auto">
<div style="background:#fff;border-radius:14px;width:100%;max-width:980px;box-shadow:0 20px 60px rgba(0,0,0,.3);margin:auto">
  <div style="background:linear-gradient(135deg,#1D4ED8,#2563EB);border-radius:14px 14px 0 0;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:2">
    <div>
      <div style="color:#fff;font-size:15px;font-weight:800">📧 Mail İçeriği Hazır</div>
      <div style="color:rgba(255,255,255,.75);font-size:11px">Aşağıdaki içeriği kopyalayıp Outlook'a yapıştırın</div>
    </div>
    <div style="display:flex;gap:8px">
      <button id="mntMailKopyalaBtn" onclick="mntMailKopyala()"
        style="background:#047857;color:#fff;border:2px solid rgba(255,255,255,.5);padding:6px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
        📋 Kopyala (Outlook'a yapıştır)
      </button>
      <button onclick="mntMailKapat()" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:30px;height:30px;border-radius:8px;cursor:pointer">✕</button>
    </div>
  </div>
  <div style="padding:16px">
    <div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;padding:10px 14px;font-size:12px;color:#92400E;margin-bottom:14px">
      <strong>📌 Nasıl kullanılır:</strong> "📋 Kopyala" butonuna tıklayın → Outlook'ta yeni mail açın → Mail gövdesine <strong>Ctrl+V</strong> ile yapıştırın. Tablo ve renkler korunur.
    </div>
    <div id="mntMailOnizleme" style="border:1px solid #E2E8F0;border-radius:8px;padding:16px;background:#fff;overflow-x:auto"></div>
  </div>
</div>
</div>

