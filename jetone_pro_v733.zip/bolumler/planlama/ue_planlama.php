<?php
ob_start();
if (!empty($_POST['json_action'])) {
    ob_end_clean();
    error_reporting(0); ini_set('display_errors',0);
    require_once dirname(dirname(__DIR__)) . '/core/config.php';
    require_once dirname(dirname(__DIR__)) . '/core/db.php';
    require_once dirname(dirname(__DIR__)) . '/core/auth.php';
    require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
    header('Content-Type: application/json; charset=utf-8');

    $action = $_POST['json_action'];

    if ($action === 'durus_ekle') {
        $hat      = trim($_POST['hat']??'');
        $tur      = trim($_POST['durus_turu']??'');
        $vardiya  = max(1,(int)($_POST['vardiya_sayisi']??1));
        $vrd_bas  = trim($_POST['baslangic_vardiya']??'S');
        $aciklama = trim($_POST['aciklama']??'');
        if (!$hat||!$tur) { echo json_encode(['ok'=>false,'hata'=>'Hat ve duruş türü zorunlu']); exit; }
        try {
            $sira=$db->prepare("SELECT COALESCE(MAX(hat_sira_no),0)+1 FROM mps_plan WHERE hat_kodu=? AND durum NOT IN('Tamamlandı','İptal')");
            $sira->execute([$hat]); $sira=(int)$sira->fetchColumn();
            $gun=max(1,(int)ceil($vardiya/3));
            $db->prepare("INSERT INTO mps_plan(hat_kodu,urun_kodu,urun_adi,uretim_emri_no,planlanan_miktar,kalan_miktar,kapasite_vardiya,cycle_sn,parti,toplam_vardiya,kalan_vardiya,hat_sira_no,baslangic_tarih,bitis_tarih,baslangic_vardiya,toplam_gun,notlar,olusturan,personel_sayisi,durum)
                VALUES(?,?,?,NULL,0,0,0,0,1,?,?,?,CURDATE(),CURDATE(),?,?,?,?,0,'Planlandı')")
                ->execute([$hat,'__DURUS__',$tur,$vardiya,$vardiya,$sira,$vrd_bas,$gun,$aciklama,$_SESSION['kullanici_id']??0]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'is_ata') {
        $hat   = trim($_POST['hat_kodu']??'');
        $mk    = trim($_POST['urun_kodu']??'');
        $miktar= (int)($_POST['planlanan_miktar']??0);
        $kap   = max(1,(int)($_POST['kapasite_vardiya']??1));
        $cycle = floatval($_POST['cycle_sn']??0);
        $parti = max(1,(int)($_POST['parti']??1));
        $adi   = trim($_POST['urun_adi']??'');
        $ue    = trim($_POST['uretim_emri_no']??'');
        $not_  = trim($_POST['notlar']??'');
        $pers  = max(1,(int)($_POST['personel_sayisi']??1));
        if (!$hat||!$mk||$miktar<1){ echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }
        try {
            $s=$db->prepare("SELECT COALESCE(MAX(hat_sira_no),0)+1 FROM mps_plan WHERE hat_kodu=? AND durum NOT IN('Tamamlandı','İptal')");
            $s->execute([$hat]); $sira=(int)$s->fetchColumn();
            $tv=max(1,(int)ceil($miktar/$kap));
            $db->prepare("INSERT INTO mps_plan(hat_kodu,urun_kodu,urun_adi,uretim_emri_no,planlanan_miktar,kalan_miktar,kapasite_vardiya,cycle_sn,parti,toplam_vardiya,kalan_vardiya,hat_sira_no,baslangic_tarih,bitis_tarih,baslangic_vardiya,toplam_gun,notlar,olusturan,personel_sayisi) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURDATE(),CURDATE(),'S',?,?,?,?)")
                ->execute([$hat,$mk,$adi,$ue?:null,$miktar,$miktar,$kap,$cycle,$parti,$tv,$tv,$sira,(int)ceil($tv/3),$not_,$_SESSION['kullanici_id']??0,$pers]);
            $planlar=$db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'planlar'=>$planlar]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'is_sil') {
        $id=(int)($_POST['sil_id']??0);
        if(!$id){ echo json_encode(['ok'=>false]); exit; }
        try {
            $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
            $planlar=$db->query("SELECT * FROM mps_plan WHERE durum!='İptal' ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'planlar'=>$planlar]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen eylem']); exit;
}

require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$kayitlar = [];

$hat_renkleri = [
    'EN-110-01'=>'#FEE2E2','EN-132-01'=>'#DBEAFE','EN-80-01' =>'#D1FAE5',
    'EN-130-01'=>'#FEF3C7','EN-160-01'=>'#EDE9FE','EN-201-01'=>'#CFFAFE',
    'EN-202-01'=>'#FCE7F3','EN-301-01'=>'#E0F2FE','EN-302-01'=>'#ECFDF5',
    'EN-350-01'=>'#FEF9C3','EN-420-01'=>'#FFEDD5','EN-500-01'=>'#F1F5F9',
    'EN-650-01'=>'#F3E8FF','EN-162-01'=>'#E0F7FA','EN-131-01'=>'#FFF3CD',
    'EN-161-01'=>'#FEF08A','EN-530-01'=>'#FED7AA','EN-650-02'=>'#C7D2FE',
    'EN-450-01'=>'#CCFBF1','EN-500-02'=>'#FFE4E6','EN-260-01'=>'#BFDBFE',
    'EN-410-01'=>'#FDE68A','EN-500-03'=>'#BBF7D0','EN-700-01'=>'#FECACA',
    'EN-180-01'=>'#A7F3D0','EN-280-01'=>'#BAE6FD','EN-650-03'=>'#FDE68A',
    'EN-650-04'=>'#FBCFE8','EN-650-05'=>'#FED7AA','EN-650-06'=>'#DDD6FE',
    'EN-850-01'=>'#FECDD3','EN-850-02'=>'#FEF08A',
];

// Tiger'dan üretim emirleri
if ($tiger_ok) {
    try {
        $sql = "SELECT
            WS.CODE AS is_istasyonu,
            CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
            CONVERT(date, PRO.DATE_) AS uretim_tarihi,
            PRO.FICHENO AS emr_no,
            IT.CODE  AS mamul_kod,
            IT.NAME  AS mamul_adi,
            CONVERT(decimal(18,0),(SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN(0,1))) AS stok,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT)) AS kalan
        FROM dbo.LG_222_PRODORD AS PRO
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT   ON IT.LOGICALREF   = PRO.ITEMREF
        LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS  ON DIS.PRODORDREF  = PRO.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS   ON WS.LOGICALREF   = DIS.WSREF
        WHERE YEAR(PRO.DATE_) = YEAR(GETDATE())
          AND MONTH(PRO.DATE_) = MONTH(GETDATE())
          AND PRO.STATUS IN (0,1)
        GROUP BY YEAR(PRO.DATE_), MONTH(PRO.DATE_), WS.CODE,
            CONVERT(date,PRO.DATE_), PRO.FICHENO, IT.CODE, IT.NAME,
            PRO.PLNAMOUNT, PRO.STATUS, IT.LOGICALREF
        ORDER BY WS.CODE, PRO.STATUS DESC";
        $kayitlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// Operasyon haritası - öncelik sayfası ile aynı mantık
$op_map = [];
if ($tiger_ok && !empty($kayitlar)) {
    $kodlar = array_unique(array_column($kayitlar, 'mamul_kod'));
    $kodlar = array_values(array_filter($kodlar));
    if (!empty($kodlar)) {
        try {
            $ph = implode(',', array_fill(0, count($kodlar), '?'));
            $s = $tigerdb_pdo->prepare("SELECT IT.CODE AS urun_kod, IT.NAME AS urun_adi,
                WRK.CODE AS hat_kodu,
                dbo.LG_INTTOTIME2(OPR.RUNTIME) AS proses_cevrimi,
                OPR.BATCHQUANTITY AS parti
                FROM dbo.LG_222_OPRTREQ AS OPR WITH(NOLOCK)
                LEFT JOIN dbo.LG_222_OPERTION AS OP  WITH(NOLOCK) ON OP.LOGICALREF  = OPR.OPERATIONREF
                LEFT JOIN dbo.LG_222_WORKSTAT AS WRK WITH(NOLOCK) ON WRK.LOGICALREF = OPR.WSREF
                LEFT JOIN dbo.LG_222_RTNGLINE AS RTL WITH(NOLOCK) ON RTL.OPERATIONREF= OP.LOGICALREF
                LEFT JOIN dbo.LG_222_ROUTING  AS RT  WITH(NOLOCK) ON RT.LOGICALREF  = RTL.ROUTINGREF
                LEFT JOIN dbo.LG_222_BOMREVSN AS BMR WITH(NOLOCK) ON BMR.ROUTINGREF = RT.LOGICALREF
                LEFT JOIN dbo.LG_222_BOMASTER AS BOM WITH(NOLOCK) ON BOM.LOGICALREF = BMR.BOMMASTERREF
                LEFT JOIN dbo.LG_222_BOMLINE  AS BML WITH(NOLOCK) ON BMR.LOGICALREF = BML.BOMREVREF AND BML.LINETYPE<>4
                LEFT JOIN dbo.LG_222_ITEMS    AS IT  WITH(NOLOCK) ON IT.LOGICALREF  = BOM.MAINPRODREF
                WHERE IT.CODE IN($ph) AND OP.CODE<>'SKOP.001'
                  AND IT.CODE IS NOT NULL AND IT.CODE NOT LIKE 'H-%' AND OPR.RUNTIME>0
                  AND WRK.CODE IS NOT NULL AND WRK.CODE <> ''
                GROUP BY IT.CODE,IT.NAME,WRK.CODE,OPR.RUNTIME,OPR.BATCHQUANTITY
                ORDER BY IT.CODE,WRK.CODE");
            $s->execute($kodlar);
            foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $x) {
                // Tüm istasyonlar - filtre yok
                $parti    = max(1, floatval($x['parti']));
                $cycle_sn = floatval($x['proses_cevrimi']);
                if ($cycle_sn <= 0) continue;
                $kapasite = (int)floor((3600 / $cycle_sn) * $parti * 7);
                if (!isset($op_map[$x['urun_kod']])) {
                    $op_map[$x['urun_kod']] = [
                        'adi'     => $x['urun_adi'],
                        'ana_hat' => $x['hat_kodu'],
                        'hatlar'  => [],
                    ];
                }
                $op_map[$x['urun_kod']]['hatlar'][$x['hat_kodu']] = [
                    'hat'      => $x['hat_kodu'],
                    'cycle_sn' => $cycle_sn,
                    'parti'    => (int)$parti,
                    'kapasite' => max(1, $kapasite),
                ];
            }
            // Ana hat bilgisini düzleştir
            foreach ($op_map as $mk => &$op) {
                $ana = $op['hatlar'][$op['ana_hat']] ?? reset($op['hatlar']);
                $op['hat']      = $op['ana_hat'];
                $op['kapasite'] = $ana['kapasite'];
                $op['cycle_sn'] = $ana['cycle_sn'];
                $op['parti']    = $ana['parti'];
            }
            unset($op);
        } catch(Throwable $e) {}
    }
}

// Hat kuyruk haritası
$hat_kuyruk_map = [];
try {
    $planlar_db = $db->query("SELECT * FROM mps_plan WHERE durum NOT IN('Tamamlandı','İptal') ORDER BY hat_kodu,hat_sira_no")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($planlar_db as $p) {
        $hat_kuyruk_map[$p['hat_kodu']][] = [
            'hat_sira_no'     => (int)$p['hat_sira_no'],
            'urun_kodu'       => $p['urun_kodu'],
            'planlanan_miktar'=> (int)$p['planlanan_miktar'],
            'kalan_miktar'    => (int)($p['kalan_miktar']??$p['planlanan_miktar']??0),
            'kapasite_vardiya'=> (int)($p['kapasite_vardiya']??1),
            'kalan_vardiya'   => (int)($p['kalan_vardiya']??$p['toplam_vardiya']??0),
            'toplam_vardiya'  => (int)($p['toplam_vardiya']??0),
        ];
    }
} catch(Throwable $e) {}

// UE haritası: mamul_kod => [emr_no, kalan, durum, is_ist]
$ue_map = [];
foreach ($kayitlar as $r) {
    $mk = $r['mamul_kod'];
    if (!isset($ue_map[$mk])) $ue_map[$mk] = [];
    $ue_map[$mk][] = [
        'emr_no' => $r['emr_no'],
        'kalan'  => (float)($r['kalan']??0),
        'durum'  => $r['durum'],
        'is_ist' => $r['is_istasyonu']??'',
    ];
}
?>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🏭 Üretim Emri Planlama</h1>
    <div class="s-yol">Planlama / <b>ÜE Planlama</b>
      <?php if($tiger_ok && !$hata): ?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo count($kayitlar); ?> kayıt)</span>
      <?php else: ?>
      <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:6px">
    <button onclick="ueDurusAc()"
      style="background:#DC2626;color:#fff;border:none;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      ⛔ Duruş Ekle
    </button>
  </div>
</div>

<div class="s-body">

<?php if($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<?php if(!$tiger_ok): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px">
  ⚠️ Tiger DB bağlantısı yok. <a href="?sayfa=ayarlar-enteg" style="color:#991B1B;font-weight:700">Entegrasyon ayarlarına git →</a>
</div>
<?php else: ?>

<div class="kart" style="overflow:hidden">
  <table class="tablo" id="tbl-uep" style="width:100%">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th>İş İstasyonu</th><th>Durum</th><th>Tarih</th><th>Emr No</th>
        <th>Mamul Kodu</th><th>Mamul Adı</th>
        <th style="text-align:right">Stok</th>
        <th style="text-align:right">Planlanan</th>
        <th style="text-align:right">Üretilen</th>
        <th style="text-align:right">Kalan</th>
        <th style="text-align:center">İş Ata</th>
      </tr>
    </thead>
    <tfoot>
      <tr>
        <th>İş İstasyonu</th><th>Durum</th><th>Tarih</th><th>Emr No</th>
        <th>Mamul Kodu</th><th>Mamul Adı</th>
        <th>Stok</th><th>Planlanan</th><th>Üretilen</th><th>Kalan</th><th></th>
      </tr>
    </tfoot>
    <tbody>
    <?php foreach($kayitlar as $r):
      $dur_bg = $r['durum']==='Devam Ediyor' ? '#D1FAE5' : '#DBEAFE';
      $dur_fg = $r['durum']==='Devam Ediyor' ? '#065F46' : '#1E40AF';
      $kalan  = (float)($r['kalan']??0);
      $kalan_renk = $kalan<=0 ? '#059669' : ($kalan<100 ? '#D97706' : '#DC2626');
      $mk     = $r['mamul_kod']??'';
      // Hat listesi ve operasyon bilgisi JS için
      $op_hatlar = array_values($op_map[$mk]['hatlar'] ?? []);
      $ana_hat   = $op_map[$mk] ?? [];
      $jd = htmlspecialchars(json_encode([
          'mk'          => $mk,
          'adi'         => $r['mamul_adi']??'',
          'emr_no'      => $r['emr_no']??'',
          'kalan'       => $kalan,
          'is_istasyonu'=> $r['is_istasyonu']??'',
          'hat'         => $ana_hat['hat'] ?? ($op_hatlar[0]['hat'] ?? ''),
          'kapasite'    => (int)($ana_hat['kapasite'] ?? ($op_hatlar[0]['kapasite'] ?? 0)),
          'cycle_sn'    => floatval($ana_hat['cycle_sn'] ?? ($op_hatlar[0]['cycle_sn'] ?? 0)),
          'parti'       => (int)($ana_hat['parti'] ?? ($op_hatlar[0]['parti'] ?? 1)),
          'hatlar'      => $op_hatlar,
      ], JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE));
    ?>
    <tr>
      <td style="font-weight:700;font-size:11px"><?php echo htmlspecialchars($r['is_istasyonu']??'—');?></td>
      <td><span style="background:<?php echo $dur_bg;?>;color:<?php echo $dur_fg;?>;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['durum']);?></span></td>
      <td style="font-size:11px"><?php echo $r['uretim_tarihi'] ? date('d.m.Y',strtotime($r['uretim_tarihi'])) : '—';?></td>
      <td style="font-size:11px;font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['emr_no']??'');?></td>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($mk);?></code></td>
      <td style="font-size:12px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo htmlspecialchars($r['mamul_adi']??'');?>"><?php echo htmlspecialchars($r['mamul_adi']??'');?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo number_format((float)($r['stok']??0),0,',','.');?></td>
      <td style="text-align:right"><?php echo number_format((float)($r['planlanan']??0),0,',','.');?></td>
      <td style="text-align:right;color:#065F46;font-weight:600"><?php echo number_format((float)($r['uretilen']??0),0,',','.');?></td>
      <td style="text-align:right;font-weight:700;color:<?php echo $kalan_renk;?>"><?php echo number_format($kalan,0,',','.');?></td>
      <td style="text-align:center">
        <button onclick="isAtaAc(<?php echo $jd;?>)"
          style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
          ➕ İş Ata
        </button>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(empty($kayitlar)): ?>
    <tr><td colspan="11" style="text-align:center;padding:30px;color:var(--m2)">Bu ay açık üretim emri bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php endif; ?>
</div>

<!-- İş Atama Modal -->
<div id="isAtaModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:680px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#f8fafc;border-radius:14px 14px 0 0;position:sticky;top:0;z-index:2">
    <div>
      <div style="font-size:14px;font-weight:800;color:#0F172A" id="mBaslik">İş Atama</div>
      <div style="font-size:11px;color:#64748B;margin-top:2px" id="mAlt"></div>
    </div>
    <button onclick="mKapat()" style="background:#F1F5F9;border:none;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:18px">
    <!-- ÜE Bilgisi -->
    <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:12px;margin-bottom:14px;font-size:12px">
      <div style="font-weight:700;color:#1E40AF;margin-bottom:6px">📋 Üretim Emri</div>
      <div id="mUe">⏳ Yükleniyor...</div>
    </div>
    <!-- Hat seçimi -->
    <div style="margin-bottom:12px">
      <label class="form-etiket">Hat <span id="mHatKapBilgi" style="font-weight:400;color:#065F46;font-size:11px"></span></label>
      <select id="mHat" class="form-alan" onchange="mHatDegisti()">
        <option value="">Hat seçin...</option>
      </select>
      <div id="mHatInfo" style="font-size:11px;color:#64748B;margin-top:4px"></div>
    </div>
    <!-- Kuyruk -->
    <div id="mKuyruk" style="margin-bottom:12px;display:none">
      <div style="font-size:12px;font-weight:700;color:#374151;margin-bottom:5px">📋 Hat Kuyruğu</div>
      <div id="mKuyrukListe"></div>
    </div>
    <!-- Miktar + ÜE No + Personel -->
    <div style="display:grid;grid-template-columns:1fr 1fr 80px;gap:12px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Miktar (adet)</label>
        <input type="number" id="mMiktar" class="form-alan" min="1" oninput="mHesapla()" placeholder="Miktar...">
      </div>
      <div>
        <label class="form-etiket">ÜE No</label>
        <input type="text" id="mUeNo" class="form-alan" placeholder="Otomatik..." readonly style="background:#F8FAFC">
      </div>
      <div>
        <label class="form-etiket">👤 Personel</label>
        <input type="number" id="mPersonel" class="form-alan" min="1" max="20" value="1" style="text-align:center;font-weight:700" oninput="mHesapla()">
      </div>
    </div>
    <!-- Kapasite hesap -->
    <div id="mHesap" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:12px;margin-bottom:12px;display:none">
      <div style="font-weight:700;color:#065F46;margin-bottom:6px;font-size:12px">⚙️ Kapasite Hesabı</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:8px" id="mHesapKartlar"></div>
      <div id="mSiraBilgi" style="font-size:11px;color:#374151;background:#fff;border-radius:6px;padding:8px;border:1px solid #BBF7D0"></div>
    </div>
    <!-- Notlar -->
    <div style="margin-bottom:14px">
      <label class="form-etiket">Notlar</label>
      <input type="text" id="mNot" class="form-alan" placeholder="Açıklama...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="mKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="mKaydet()" id="mKaydetBtn" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">✅ Kuyruğa Al</button>
    </div>
  </div>
</div>
</div>

<!-- ÜE Planlama Duruş Modalı -->
<div id="ueDurusModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#FFF5F5;border-radius:14px 14px 0 0">
    <div style="font-size:14px;font-weight:800;color:#991B1B">⛔ Duruş Kaydı</div>
    <button onclick="ueDurusKapat()" style="background:#F1F5F9;border:none;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:18px">
    <div style="margin-bottom:12px">
      <label class="form-etiket">Hat</label>
      <select id="ueDurusHat" class="form-alan">
        <option value="">Hat seçin...</option>
      </select>
    </div>
    <div style="margin-bottom:12px">
      <label class="form-etiket">Duruş Türü</label>
      <select id="ueDurusTur" class="form-alan">
        <option value="">Tür seçin...</option>
        <option value="Planlı Duruş">🔧 Planlı Duruş</option>
        <option value="Makine Arıza">⚠️ Makine Arıza</option>
        <option value="Kalıp Arıza">🔩 Kalıp Arıza</option>
        <option value="Malzeme Bekleme">📦 Malzeme Bekleme</option>
        <option value="HM Bekleme">🧱 HM Bekleme</option>
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Vardiya Sayısı</label>
        <input type="number" id="ueDurusVardiya" class="form-alan" min="1" max="99" value="1" style="text-align:center;font-weight:700">
      </div>
      <div>
        <label class="form-etiket">Başlangıç Vardiyası</label>
        <select id="ueDurusBas" class="form-alan">
          <option value="S">Sabah (08-16)</option>
          <option value="O">Öğleden Sonra (16-24)</option>
          <option value="G">Gece (00-08)</option>
        </select>
      </div>
    </div>
    <div style="margin-bottom:16px">
      <label class="form-etiket">Açıklama</label>
      <input type="text" id="ueDurusAciklama" class="form-alan" placeholder="Duruş açıklaması...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="ueDurusKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="ueDurusKaydet()" id="ueDurusKaydetBtn" style="background:linear-gradient(135deg,#DC2626,#991B1B);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">⛔ Duruş Ekle</button>
    </div>
  </div>
</div>
</div>
<script>
var _d={}, _ue=[], _hs={};
var UE_HAT_LISTESI=<?php
$ue_hatlar=[];
foreach($kayitlar as $kr){
    $ist=$kr['is_istasyonu']??'';
    if($ist&&!in_array($ist,$ue_hatlar)) $ue_hatlar[]=$ist;
}
// Ayrıca hat_renkleri'ndeki EN- hatlarını da ekle
foreach(array_keys($hat_renkleri) as $hk){ if(!in_array($hk,$ue_hatlar)) $ue_hatlar[]=$hk; }
sort($ue_hatlar);
echo json_encode($ue_hatlar, JSON_UNESCAPED_UNICODE);
?>;
var HAT_RENKLERI_JS=<?php echo json_encode($hat_renkleri, JSON_UNESCAPED_UNICODE);?>;
var HAT_KUYRUK=<?php echo json_encode($hat_kuyruk_map, JSON_UNESCAPED_UNICODE);?>;
var UE_MAP=<?php echo json_encode($ue_map, JSON_UNESCAPED_UNICODE);?>;
// EN- olmayan istasyonlar
var DIGER_ISTASYONLAR=<?php
$diger = array_values(array_unique(array_filter(
    array_column($kayitlar, 'is_istasyonu'),
    function($v){ return $v && stripos($v,'EN-') !== 0; }
)));
sort($diger);
echo json_encode($diger, JSON_UNESCAPED_UNICODE);
?>;

function isAtaAc(d){
  _d=d; _ue=[]; _hs={};
  document.getElementById('mBaslik').textContent='➕ İş Atama — '+d.mk;
  document.getElementById('mAlt').textContent=d.adi+(d.emr_no?' | ÜE: '+d.emr_no:'');
  document.getElementById('mMiktar').value=d.kalan>0?Math.round(d.kalan):'';
  document.getElementById('mUeNo').value=d.emr_no||'';
  document.getElementById('mPersonel').value=1;
  document.getElementById('mNot').value='';
  document.getElementById('mHesap').style.display='none';
  document.getElementById('mKuyruk').style.display='none';

  var sel=document.getElementById('mHat');
  sel.innerHTML='';
  var hatlar=d.hatlar||[];
  var istasyon=d.is_istasyonu||d.hat||''; // is emrinin Tiger istasyonu

  if(istasyon.toUpperCase().startsWith('EN-')){
    // EN- istasyonu: operasyondaki EN- hatlarını göster
    if(hatlar.length===0){
      // Operasyon tanımı yoksa tüm EN- hatlarını göster
      Object.keys(HAT_RENKLERI_JS).forEach(function(h){
        var opt=document.createElement('option');
        opt.value=h; opt.textContent=h;
        opt.style.background=HAT_RENKLERI_JS[h];
        if(h===istasyon) opt.selected=true;
        sel.appendChild(opt);
      });
    } else {
      hatlar.forEach(function(h){
        var opt=document.createElement('option');
        opt.value=h.hat;
        opt.textContent=h.hat+(h.kapasite?' — '+h.kapasite.toLocaleString('tr-TR')+' ad/vrd':'')+(h.parti?' (Parti:'+h.parti+')':'');
        opt.dataset.kapasite=h.kapasite;
        opt.dataset.cycle=h.cycle_sn;
        opt.dataset.parti=h.parti;
        opt.style.background=HAT_RENKLERI_JS[h.hat]||'#fff';
        if(h.hat===istasyon) opt.selected=true;
        sel.appendChild(opt);
      });
    }
  } else {
    // EN- olmayan istasyon: tablodaki diğer EN- olmayan is_istasyonlarını göster
    var digerHatlar=DIGER_ISTASYONLAR||[];
    if(digerHatlar.length===0){
      // Fallback: sadece mevcut istasyonu göster
      var opt=document.createElement('option');
      opt.value=istasyon; opt.textContent=istasyon; opt.selected=true;
      sel.appendChild(opt);
    } else {
      digerHatlar.forEach(function(h){
        var opt=document.createElement('option');
        opt.value=h; opt.textContent=h;
        if(h===istasyon) opt.selected=true;
        sel.appendChild(opt);
      });
    }
  }

  // ÜE bilgisi
  var ueList=UE_MAP[d.mk]||[];
  if(ueList.length){
    var html='';
    ueList.forEach(function(e,i){
      var ak=i===0;
      html+='<div onclick="ueSecildi('+i+')" id="ue_'+i+'" style="display:flex;align-items:center;gap:8px;padding:6px 8px;background:'+(ak?'#DBEAFE':'#F1F5F9')+';border-radius:6px;margin-bottom:4px;cursor:pointer;border:1px solid '+(ak?'#93C5FD':'#E2E8F0')+'">';
      html+='<div style="flex:1"><div style="font-weight:700;font-size:12px;color:#1E40AF">'+e.emr_no+'</div>';
      html+='<div style="font-size:11px;color:#374151">'+e.durum+(e.is_ist?' | '+e.is_ist:'')+'</div></div>';
      html+='<div style="text-align:right"><div style="font-size:13px;font-weight:800;color:'+(e.kalan>0?'#DC2626':'#059669')+'">'+e.kalan.toLocaleString('tr-TR')+'</div><div style="font-size:9px;color:#64748B">kalan</div></div></div>';
    });
    document.getElementById('mUe').innerHTML=html;
    if(ueList[0]){ document.getElementById('mUeNo').value=ueList[0].emr_no; if(ueList[0].kalan>0) document.getElementById('mMiktar').value=Math.round(ueList[0].kalan); }
    _ue=ueList;
  } else {
    document.getElementById('mUe').innerHTML='<span style="color:#92400E">⚠️ Bu ürün için açık ÜE bulunamadı</span>';
  }

  document.getElementById('isAtaModal').style.display='flex';
  mHatDegisti();
}

function ueSecildi(i){
  _ue.forEach(function(e,j){
    var el=document.getElementById('ue_'+j);
    if(el){el.style.background=j===i?'#DBEAFE':'#F1F5F9';el.style.borderColor=j===i?'#93C5FD':'#E2E8F0';}
  });
  if(_ue[i]){document.getElementById('mUeNo').value=_ue[i].emr_no;if(_ue[i].kalan>0)document.getElementById('mMiktar').value=Math.round(_ue[i].kalan);mHesapla();}
}

function mKapat(){document.getElementById('isAtaModal').style.display='none';}

function mHatDegisti(){
  var sel=document.getElementById('mHat');
  var opt=sel.options[sel.selectedIndex];
  if(opt && opt.dataset.kapasite && parseInt(opt.dataset.kapasite)>0){
    _d.kapasite=parseInt(opt.dataset.kapasite);
    _d.cycle_sn=parseFloat(opt.dataset.cycle)||0;
    _d.parti=parseInt(opt.dataset.parti)||1;
    document.getElementById('mHatKapBilgi').textContent=
      '→ '+_d.kapasite.toLocaleString('tr-TR')+' ad/vrd | Parti: '+_d.parti+' | Çevrim: '+_d.cycle_sn+'sn';
  } else {
    document.getElementById('mHatKapBilgi').textContent='';
  }
  var hat=sel.value;
  var isler=HAT_KUYRUK[hat]||[];
  var bekleme=0;
  var bekleme_dakika_oran=0; // 0-1 arası: bu vardiyanın ne kadarı dolu
  isler.forEach(function(is,i){
    var kv=is.kalan_vardiya||is.toplam_vardiya||0;
    var km=is.kalan_miktar||is.planlanan_miktar||0;
    var kap_is=is.kapasite_vardiya||1;
    var kesir=km/kap_is; // bu işin tam vardiya değeri
    bekleme+=kv;
    // Aktif vardiyadaki doluluk: son işin kesir kısmı
    if(i===isler.length-1 && kesir<1) bekleme_dakika_oran=kesir;
  });
  _hs={siradaki_no:isler.length+1, bekleme_vardiya:bekleme, bekleme_dakika_oran:bekleme_dakika_oran};
  var kb=document.getElementById('mKuyruk');
  var kl=document.getElementById('mKuyrukListe');
  if(isler.length){
    kb.style.display='block';
    var html='';
    isler.forEach(function(is,i){
      var kv=is.kalan_vardiya||is.toplam_vardiya||0;
      html+='<div style="display:flex;align-items:center;gap:8px;padding:5px 8px;background:#FFF7ED;border-radius:6px;margin-bottom:3px;font-size:11px">';
      html+='<span style="background:#F97316;color:#fff;border-radius:3px;padding:1px 5px;font-weight:700;font-size:10px">'+(i+1)+'.</span>';
      html+='<span style="font-weight:700">'+is.urun_kodu+'</span>';
      html+='<span style="color:#64748B">'+is.planlanan_miktar.toLocaleString('tr-TR')+' ad</span>';
      html+='<span style="margin-left:auto;color:#DC2626;font-weight:700">'+kv+' vrd kalan</span></div>';
    });
    kl.innerHTML=html;
  } else kb.style.display='none';
  mHesapla();
}

function mHesapla(){
  var mik=parseInt(document.getElementById('mMiktar').value)||0;
  var hatVal=(document.getElementById('mHat').value||'').toUpperCase();
  var isEN=hatVal.startsWith('EN-');
  var pers=parseInt(document.getElementById('mPersonel').value)||1;
  var kapBaz=_d.kapasite||1;
  // EN- olmayan hatlar: kapasite * personel sayisi
  var kap=isEN ? kapBaz : kapBaz*pers;
  _d.efektif_kapasite=kap;
  if(mik<=0){document.getElementById('mHesap').style.display='none';return;}

  // Kesirli vardiya: 60 adet / 420 kap = 0.143 vardiya
  var tvKesir=mik/kap;
  var tv=Math.max(1,Math.ceil(tvKesir));
  var bk=_hs.bekleme_vardiya||0; // kalan bekleme (kesirli olabilir)
  var doluluk=Math.min(100,Math.round(tvKesir*100));

  document.getElementById('mHesap').style.display='block';

  // Sıra bilgisi: aynı vardiyaya sığar mı?
  var siraBilgi='';
  if(!isEN && tvKesir<1){
    // 1 vardiyadan az - paylaşımlı vardiya
    var bkKesir=_hs.bekleme_dakika_oran||0; // önceki işlerin bu vardiyada kullandığı oran
    var kalanVrd=1-bkKesir;
    if(kalanVrd>=tvKesir){
      siraBilgi='<span style="color:#065F46;font-weight:700">✅ Aynı vardiyaya sığar</span> — mevcut vardiyanın %'+doluluk+' ini kullanır. '
        +'<b>'+Math.round(tvKesir*100)+'%</b> doluluk.';
    } else {
      siraBilgi='⚡ Mevcut vardiyaya kısmen sığar, kalan iş sonraki vardiyaya taşar.';
    }
  } else if(bk>0){
    siraBilgi='<b>Önünüzde</b> '+Math.ceil(bk)+' vardiya iş var. Bu iş '+(Math.ceil(bk)+1)+'. vardiyadaki boşluktan başlar. Toplam <b>'+tv+' vardiya</b> (≈'+Math.ceil(tv/3)+' gün).';
  } else {
    siraBilgi='<b>Hat boş.</b> 1. vardiyadan itibaren başlar. Toplam <b>'+tv+' vardiya</b> (≈'+Math.ceil(tv/3)+' gün).';
  }

  var kapLabel=kap.toLocaleString('tr-TR')+' ad/vrd'+(isEN?'':'<br><span style="font-size:9px;color:#64748B">'+kapBaz+' x '+pers+'👤</span>');
  var tvLabel=tvKesir<1?('~%'+doluluk+' vardiya'):tv+' vardiya';

  document.getElementById('mHesapKartlar').innerHTML=
    krt('Üretilecek',mik.toLocaleString('tr-TR')+' adet','#1E40AF')+
    krt('Bu iş için',tvLabel,'#065F46')+
    krt('Kapasite',kapLabel,'#374151');
  document.getElementById('mSiraBilgi').innerHTML=siraBilgi;
}

function krt(l,v,c){
  return '<div style="background:#fff;border:1px solid #E2E8F0;border-radius:6px;padding:8px;text-align:center"><div style="font-size:10px;color:#64748B;margin-bottom:2px">'+l+'</div><div style="font-size:13px;font-weight:800;color:'+c+'">'+v+'</div></div>';
}

function jsonPost(fields, callback){
  var fd=new FormData();
  Object.entries(fields).forEach(function(e){fd.append(e[0],e[1]||'');});
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(callback).catch(function(e){alert('Hata: '+e);});
}

function mKaydet(){
  var mik=parseInt(document.getElementById('mMiktar').value)||0;
  if(mik<1){alert('Miktar giriniz.');return;}
  var hat=document.getElementById('mHat').value;
  if(!hat){alert('Hat seçiniz.');return;}
  var btn=document.getElementById('mKaydetBtn');
  btn.disabled=true; btn.textContent='Kaydediliyor...';
  jsonPost({
    json_action:'is_ata',
    hat_kodu:hat,
    urun_kodu:_d.mk,
    urun_adi:_d.adi,
    uretim_emri_no:document.getElementById('mUeNo').value,
    planlanan_miktar:mik,
    kapasite_vardiya:_d.efektif_kapasite||_d.kapasite||1,
    cycle_sn:_d.cycle_sn||0,
    parti:_d.parti||1,
    personel_sayisi:document.getElementById('mPersonel').value||1,
    notlar:document.getElementById('mNot').value
  }, function(d){
    btn.disabled=false; btn.textContent='✅ Kuyruğa Al';
    if(d.ok){
      mKapat();
      alert('İş kuyruğa alındı!');
      // HAT_KUYRUK güncelle
      HAT_KUYRUK={};
      (d.planlar||[]).forEach(function(p){
        if(!HAT_KUYRUK[p.hat_kodu]) HAT_KUYRUK[p.hat_kodu]=[];
        HAT_KUYRUK[p.hat_kodu].push({
          hat_sira_no:parseInt(p.hat_sira_no)||0,
          urun_kodu:p.urun_kodu,
          planlanan_miktar:parseInt(p.planlanan_miktar)||0,
          kalan_vardiya:parseInt(p.kalan_vardiya||p.toplam_vardiya||0),
          toplam_vardiya:parseInt(p.toplam_vardiya||0)
        });
      });
    } else alert('Hata: '+(d.hata||'Bilinmeyen'));
  });
}

document.addEventListener('keydown',function(e){if(e.key==='Escape')mKapat();});
// ── DURUŞ FONKSİYONLARI ──
function ueDurusAc(){
  // Hat selectini doldur
  var sel=document.getElementById('ueDurusHat');
  sel.innerHTML='<option value="">Hat seçin...</option>';
  (UE_HAT_LISTESI||[]).forEach(function(h){
    var opt=document.createElement('option');
    opt.value=h; opt.textContent=h;
    sel.appendChild(opt);
  });
  document.getElementById('ueDurusModal').style.display='flex';
}
function ueDurusKapat(){document.getElementById('ueDurusModal').style.display='none';}
function ueDurusKaydet(){
  var hat=document.getElementById('ueDurusHat').value;
  var tur=document.getElementById('ueDurusTur').value;
  var vrd=document.getElementById('ueDurusVardiya').value||1;
  var bas=document.getElementById('ueDurusBas').value;
  var acl=document.getElementById('ueDurusAciklama').value;
  if(!hat||!tur){alert('Hat ve duruş türü seçiniz.');return;}
  var btn=document.getElementById('ueDurusKaydetBtn');
  btn.disabled=true; btn.textContent='Kaydediliyor...';
  var fd=new FormData();
  fd.append('json_action','durus_ekle');
  fd.append('hat',hat);
  fd.append('durus_turu',tur);
  fd.append('vardiya_sayisi',vrd);
  fd.append('baslangic_vardiya',bas);
  fd.append('aciklama',acl);
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    btn.disabled=false; btn.textContent='⛔ Duruş Ekle';
    if(d.ok){ueDurusKapat();location.reload();}
    else alert('Hata: '+(d.hata||''));
  }).catch(function(e){btn.disabled=false;btn.textContent='⛔ Duruş Ekle';alert('Hata:'+e);});
}
</script>

<script>
$(document).ready(function(){
  if(!$.fn.DataTable||$.fn.DataTable.isDataTable('#tbl-uep')) return;
  $('#tbl-uep').DataTable({
    paging:false,
    autoWidth:false,
    scrollY:'560px',
    scrollCollapse:true,
    order:[[1,'desc'],[0,'asc']],
    columnDefs:[{orderable:false,targets:10}],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'UE_Planlama',exportOptions:{columns:':not(:last-child)'}},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt',exportOptions:{columns:':not(:last-child)'}}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(idx){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>
