<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok  = ($tigerdb_pdo !== null);
$formGeldi = !empty($_POST);
$ue_no     = trim($_POST['ue_no'] ?? '');
$yil       = (int)($_POST['yil'] ?? date('Y'));
$ay        = (int)($_POST['ay']  ?? date('n'));

$rows = []; $hata = '';

if ($tiger_ok && $formGeldi) {
    try {
        if ($ue_no !== '') {
            $sql = "SELECT * FROM MES.dbo.IKINCI_KALITE WHERE URETIM_EMRI_NO=? ORDER BY ID";
            $st=$tigerdb_pdo->prepare($sql); $st->execute([$ue_no]);
        } else {
            $sql = "SELECT URETIM_EMRI_NO AS [Üretim Emri No],
                    CONVERT(VARCHAR,URETIM_TARIHI,104) AS [Tarih],
                    SUM(CONVERT(decimal,TOPLAM)) AS [IK Toplam]
                    FROM MES.dbo.IKINCI_KALITE
                    WHERE YEAR(URETIM_TARIHI)=? AND MONTH(URETIM_TARIHI)=?
                    GROUP BY URETIM_EMRI_NO,CONVERT(VARCHAR,URETIM_TARIHI,104)
                    ORDER BY [Üretim Emri No],[Tarih]";
            $st=$tigerdb_pdo->prepare($sql); $st->execute([$yil,$ay]);
        }
        $rows=$st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){ $hata=$e->getMessage(); }
}

$aylar_tr=['1'=>'Ocak','2'=>'Şubat','3'=>'Mart','4'=>'Nisan','5'=>'Mayıs','6'=>'Haziran',
           '7'=>'Temmuz','8'=>'Ağustos','9'=>'Eylül','10'=>'Ekim','11'=>'Kasım','12'=>'Aralık'];
?>
<style>
#tblIK th{background:#1E3A5F !important;color:#fff !important;}
#tblIK td,#tblIK th{border:1px solid #CBD5E1 !important;white-space:nowrap !important;}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">⚠️ İkinci Kalite Detay</h1>
    <div class="s-yol">Planlama / <b>İkinci Kalite Kayıtları</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● MES DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px;font-size:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<div class="kart" style="padding:14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div style="border-left:3px solid #1E3A5F;padding-left:12px">
      <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:6px;text-transform:uppercase">Üretim Emri ile Ara</div>
      <div style="display:flex;gap:8px;align-items:flex-end">
        <div><label class="form-etiket">Üretim Emri No</label>
          <input type="text" name="ue_no" class="form-alan" value="<?php echo htmlspecialchars($ue_no);?>" placeholder="Ör: UE-22014151" style="min-width:180px"></div>
      </div>
    </div>
    <div style="border-left:3px solid #E2E8F0;padding-left:12px">
      <div style="font-size:11px;font-weight:700;color:#64748B;margin-bottom:6px;text-transform:uppercase">ya da Dönem ile Ara</div>
      <div style="display:flex;gap:8px;align-items:flex-end">
        <div><label class="form-etiket">Yıl</label>
          <input type="number" name="yil" class="form-alan" value="<?php echo $yil;?>" style="width:80px" min="2020" max="2030"></div>
        <div><label class="form-etiket">Ay</label>
          <select name="ay" class="form-alan" style="width:120px">
            <?php foreach($aylar_tr as $n=>$ad): ?>
            <option value="<?php echo $n;?>" <?php echo $n==$ay?'selected':'';?>><?php echo $ad;?></option>
            <?php endforeach;?>
          </select></div>
      </div>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:9px 22px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Sorgula</button>
    <?php if($formGeldi):?><a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-ikinci-kalite"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:9px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a><?php endif;?>
  </form>
</div>

<?php if(!$formGeldi):?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:36px;margin-bottom:8px">⚠️</div>
  <div style="font-weight:600">Üretim emri no girin veya dönem seçin.</div>
</div>
<?php elseif(empty($rows)&&!$hata):?>
<div style="background:#F1F5F9;padding:30px;text-align:center;color:#94A3B8;border-radius:10px">Kayıt bulunamadı.</div>
<?php else:?>
<div style="margin-bottom:8px;display:flex;gap:8px;align-items:center">
  <span style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:6px 14px;font-size:12px;font-weight:700;color:#92400E">
    <?php echo $ue_no?'📋 '.$ue_no:$aylar_tr[$ay].' '.$yil;?> — <?php echo count($rows);?> kayıt
  </span>
</div>
<div class="kart" style="overflow:hidden;padding:0"><div style="overflow-x:auto">
<table id="tblIK" style="width:100%;border-collapse:collapse">
  <thead><tr><?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></thead>
  <tfoot><tr><?php foreach(array_keys($rows[0]) as $c) echo "<th>".htmlspecialchars($c)."</th>";?></tr></tfoot>
  <tbody>
  <?php foreach($rows as $r):?>
  <tr><?php foreach($r as $v) echo '<td>'.htmlspecialchars((string)($v??'')).'</td>';?></tr>
  <?php endforeach;?>
  </tbody>
</table>
</div></div>
<script>
$(document).ready(function(){
    $('#tblIK').DataTable({
        initComplete:function(){
            this.api().columns().every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'550px',paging:false,scrollX:true,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'IK_Detay_<?php echo date("Ymd");?>'},'print']
    });
});
</script>
<?php endif; endif;?>
