<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

set_time_limit(0);
ini_set('memory_limit','512M');

$tiger_ok        = ($tigerdb_pdo !== null);
$form_gonderildi = isset($_POST['mih_calistir']);
$hata            = '';
$liste_satirlar  = [];   // flat liste: her malzeme × tarih = 1 satır
$ozet            = [];
$execution_time  = 0;

$f_grup    = trim($_POST['material_group'] ?? '');
$grp_list  = ['Ambalaj','Plastik HM','Masterbatch','Yardımcı Malz.'];

// Müşteri listesi
$musteri_listesi = [];
try {
    $musteri_listesi = $db->query("SELECT DISTINCT musteri_firma_adi FROM siparis
        WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL AND musteri_firma_adi!=''
        ORDER BY musteri_firma_adi")->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e) {}
$secili_musteriler = array_filter((array)($_POST['musteriler'] ?? []));

/* ─────────────────────────────────────────────────────────────
   HESAPLAMA
───────────────────────────────────────────────────────────── */
if ($form_gonderildi && $tiger_ok) {
try {
    $t0 = microtime(true);

    /* 1 ── Sipariş tablosundan bekleyen mamül siparişleri (MySQL) */
    $mu_where = ''; $mu_par = ['Aktif'];
    if (!empty($secili_musteriler)) {
        $ph = implode(',', array_fill(0, count($secili_musteriler), '?'));
        $mu_where = "AND musteri_firma_adi IN ($ph)";
        $mu_par   = array_merge($mu_par, $secili_musteriler);
    }
    $s = $db->prepare("SELECT sip_kodu, DATE(sip_teslim_tarihi) AS tarih,
                        SUM(sip_miktar - sip_sevk_miktari) AS kalan
                       FROM siparis
                       WHERE sip_statu=?
                         AND (sip_miktar-sip_sevk_miktari)>0
                         AND sip_teslim_tarihi IS NOT NULL
                         AND sip_teslim_tarihi <= DATE_ADD(CURDATE(), INTERVAL 2 MONTH)
                         $mu_where
                       GROUP BY sip_kodu, DATE(sip_teslim_tarihi)
                       ORDER BY tarih");
    $s->execute($mu_par);
    // mamul_sip[kod][tarih] = miktar
    $mamul_sip = [];
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $k = trim($r['sip_kodu']); if(!$k) continue;
        $mamul_sip[$k][$r['tarih']] = ($mamul_sip[$k][$r['tarih']]??0) + floatval($r['kalan']);
    }
    if (empty($mamul_sip)) { $hata='Aktif sipariş bulunamadı.'; goto son; }

    /* 2 ── Tiger: Mamül stokları */
    $ml = array_keys($mamul_sip);
    $ph = implode(',', array_fill(0, count($ml), '?'));
    $mamul_stok = [];
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS k,
            ISNULL(SUM(CASE WHEN S.INVENNO IN(0,1,5) THEN S.ONHAND ELSE 0 END),0) AS stok
            FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
            LEFT JOIN dbo.LV_222_02_STINVTOT S WITH(NOLOCK) ON S.STOCKREF=IT.LOGICALREF AND S.INVENNO IN(0,1,5)
            WHERE IT.CODE IN ($ph) GROUP BY IT.CODE");
    $r->execute($ml);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) $mamul_stok[$x['k']] = floatval($x['stok']);

    /* 3 ── Tiger: BOM (mamül → girdi) */
    $bom_map = [];
    $r = $tigerdb_pdo->prepare("SELECT IT2.CODE AS mamul, IT1.CODE AS girdi,
            IT1.NAME AS girdi_adi, IT1.STGRPCODE AS girdi_grup, BML.AMOUNT AS birim
            FROM dbo.LG_222_BOMLINE BML WITH(NOLOCK)
            INNER JOIN dbo.LG_222_ITEMS    IT1  WITH(NOLOCK) ON IT1.LOGICALREF = BML.ITEMREF
            INNER JOIN dbo.LG_222_BOMREVSN BMR  WITH(NOLOCK) ON BMR.LOGICALREF = BML.BOMREVREF
            INNER JOIN dbo.LG_222_BOMASTER BOM  WITH(NOLOCK) ON BOM.LOGICALREF = BMR.BOMMASTERREF
            INNER JOIN dbo.LG_222_ITEMS    IT2  WITH(NOLOCK) ON BOM.MAINPRODREF= IT2.LOGICALREF
            WHERE IT2.CODE IN ($ph) AND BML.LINETYPE=0
              AND BOM.ACTIVE=0 AND IT1.ACTIVE=0 AND IT2.ACTIVE=0");
    $r->execute($ml);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) {
        $bom_map[$x['mamul']][] = ['kod'=>$x['girdi'],'adi'=>$x['girdi_adi'],'grup'=>$x['girdi_grup'],'birim'=>floatval($x['birim'])];
    }

    /* 4 ── Mamül net üretim ihtiyacı: kümülatif stok - kümülatif sipariş */
    // mamul_uretim[kod][tarih] = üretilmesi gereken miktar
    $bugun = date('Y-m-d');
    $mamul_uretim = [];
    foreach($mamul_sip as $mk => $tarih_map) {
        $stok = $mamul_stok[$mk] ?? 0;
        $bakiye = $stok; $kum_sip = 0;
        ksort($tarih_map);
        foreach($tarih_map as $tarih => $sip) {
            $kum_sip += $sip;
            $net = $stok - $kum_sip;
            $once = $net + $sip; // bir önceki bakiye
            if      ($net < 0 && $once >= 0) $uretim = abs($net);
            elseif  ($net < 0 && $once <  0) $uretim = $sip;
            else                              $uretim = 0;
            if ($uretim > 0) $mamul_uretim[$mk][$tarih] = $uretim;
        }
    }

    /* 5 ── BOM patlat: malzeme günlük ihtiyaç
       BOM'u olan ürünler → BOM üzerinden malzeme ihtiyacı
       BOM'u olmayan ürünler → kendisi direkt malzeme ihtiyacı */
    $mlz_ihtiyac = [];
    $mlz_bilgi   = [];

    // BOM'u olan ürünler: üretim miktarı × BOM birim = malzeme ihtiyacı
    foreach($mamul_uretim as $mk => $tarih_uretim) {
        if (!isset($bom_map[$mk])) continue;
        foreach($bom_map[$mk] as $mlz) {
            if ($f_grup && $mlz['grup'] !== $f_grup) continue;
            if (in_array($mlz['grup'], ['Mamül','Yarımamül'])) continue;
            foreach($tarih_uretim as $tarih => $uretim) {
                $gerek = $uretim * $mlz['birim'];
                $mlz_ihtiyac[$mlz['kod']][$tarih] = ($mlz_ihtiyac[$mlz['kod']][$tarih]??0) + $gerek;
                $mlz_bilgi[$mlz['kod']] = ['adi'=>$mlz['adi'],'grup'=>$mlz['grup']];
            }
        }
    }

    // BOM'u olmayan ürünler: sipariş miktarını direkt malzeme ihtiyacı say
    foreach($mamul_sip as $mk => $tarih_map) {
        if (isset($bom_map[$mk])) continue; // BOM'u varsa zaten yukarıda işlendi
        // Tiger stok bilgisi mlz_stok'tan alınacak (sonraki adımda)
        foreach($tarih_map as $tarih => $sip) {
            if ($f_grup) continue; // Grup filtresi seçilmişse BOM'suz ürünleri atla
            $mlz_ihtiyac[$mk][$tarih] = ($mlz_ihtiyac[$mk][$tarih]??0) + $sip;
            if (!isset($mlz_bilgi[$mk])) {
                $mlz_bilgi[$mk] = ['adi'=>$mk,'grup'=>''];
            }
        }
    }

    if (empty($mlz_ihtiyac)) { $hata='Malzeme ihtiyacı hesaplanamadı (BOM eksik olabilir).'; goto son; }

    /* 6 ── Tiger: Malzeme başlangıç stokları */
    $mlz_list = array_keys($mlz_ihtiyac);
    $ph2 = implode(',', array_fill(0, count($mlz_list), '?'));
    $mlz_stok = [];
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS k, IT.NAME AS adi, IT.STGRPCODE AS grup,
            ISNULL(SUM(CASE WHEN S.INVENNO IN(0,1,5) THEN S.ONHAND ELSE 0 END),0) AS stok
            FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
            LEFT JOIN dbo.LV_222_02_STINVTOT S WITH(NOLOCK) ON S.STOCKREF=IT.LOGICALREF AND S.INVENNO IN(0,1,5)
            WHERE IT.CODE IN ($ph2) GROUP BY IT.CODE, IT.NAME, IT.STGRPCODE");
    $r->execute($mlz_list);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) {
        $mlz_stok[$x['k']] = floatval($x['stok']);
        // BOM'suz ürünlerin adı/grubunu güncelle
        if (isset($mlz_bilgi[$x['k']]) && $mlz_bilgi[$x['k']]['adi']===$x['k']) {
            $mlz_bilgi[$x['k']] = ['adi'=>$x['adi'],'grup'=>$x['grup']];
        }
    }

    /* 7 ── Tiger: Açık satınalma siparişleri (termin bazlı) */
    $sa_map = []; // [mlz_kod][tarih] = miktar
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS k, CAST(ORL.DUEDATE AS DATE) AS termin,
            SUM(ORL.AMOUNT-ORL.SHIPPEDAMOUNT) AS kalan
            FROM dbo.LG_222_02_ORFLINE ORL WITH(NOLOCK)
            INNER JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON ORF.LOGICALREF=ORL.ORDFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON ORL.STOCKREF=IT.LOGICALREF
            WHERE IT.CODE IN ($ph2) AND ORL.TRCODE=2 AND ORL.CANCELLED=0
              AND (ORL.AMOUNT-ORL.SHIPPEDAMOUNT)>0
            GROUP BY IT.CODE, CAST(ORL.DUEDATE AS DATE)
            HAVING SUM(ORL.AMOUNT-ORL.SHIPPEDAMOUNT)>0.1");
    $r->execute($mlz_list);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) {
        $sa_map[$x['k']][$x['termin']] = floatval($x['kalan']);
    }

    /* 8 ── Malzeme kümülatif hesap → düz liste satırları oluştur */
    // Referans koddaki mantıkla aynı: kümülatif ihtiyaç vs (stok + kümülatif sipariş)
    foreach($mlz_ihtiyac as $mlz_kod => $tarih_ihtiyac) {
        $info      = $mlz_bilgi[$mlz_kod];
        $stok      = $mlz_stok[$mlz_kod] ?? 0;
        $sa_dates  = $sa_map[$mlz_kod] ?? [];

        // Tüm tarihleri birleştir (ihtiyaç + SA)
        $all_t = array_unique(array_merge(array_keys($tarih_ihtiyac), array_keys($sa_dates)));
        sort($all_t);

        $kum_ihtiyac = 0; $kum_sa = 0;
        $once_net    = $stok; // ilk bakiye = başlangıç stok
        $ilk_eksik   = null;
        $son_net     = $stok;

        foreach($all_t as $tarih) {
            $gun_ihtiyac = $tarih_ihtiyac[$tarih] ?? 0;
            $gun_sa      = $sa_dates[$tarih] ?? 0;
            $kum_ihtiyac += $gun_ihtiyac;
            $kum_sa      += $gun_sa;
            $net_stok     = $stok + $kum_sa - $kum_ihtiyac;

            // Net günlük ihtiyaç (stoktan karşılanamayan)
            if      ($net_stok < 0 && $once_net >= 0) $net_gun = abs($net_stok);
            elseif  ($net_stok < 0 && $once_net <  0) $net_gun = $gun_ihtiyac;
            else                                       $net_gun = 0;

            // Tedarik miktarı (toplam eksik)
            $tedarik = $net_stok < 0 ? abs($net_stok) : 0;

            // Durum
            if      ($net_stok < 0 && $once_net >= 0) { $durum='İlk Yetersizlik'; if(!$ilk_eksik) $ilk_eksik=$tarih; }
            elseif  ($net_stok < 0)                   { $durum='Eksiklik Devam'; }
            elseif  ($gun_sa > 0 && $gun_ihtiyac==0)  { $durum='SA Girişi'; }
            else                                       { $durum='Yeterli'; }

            // Sipariş önerisi
            $siparis_onerisi = null;
            $siparis_oneri_tip = null; // 'yeni' | 'one_cek' | 'ertele'

            if ($net_stok < 0 && $once_net >= 0) {
                // İlk yetersizlik: 2 hafta öncesi idealdir, geçmişe düşerse bugün
                $ideal = date('Y-m-d', strtotime($tarih) - 14*86400);
                $hedef = $ideal < $bugun ? $bugun : $ideal;
                $gun_kalan = (int)round((strtotime($tarih) - strtotime($bugun)) / 86400);

                if ($gun_kalan <= 0) {
                    $siparis_onerisi = '🚨 BUGÜN sipariş aç ('.date('d.m.Y', strtotime($bugun)).')';
                } elseif ($gun_kalan <= 14) {
                    $siparis_onerisi = '⚡ Acil — '.date('d.m.Y', strtotime($bugun)).' sipariş aç ('.$gun_kalan.' gün kaldı)';
                } else {
                    $siparis_onerisi = '📋 '.date('d.m.Y', strtotime($hedef)).' tarihinde sipariş aç';
                }
                $siparis_oneri_tip = 'yeni';
            }

            // Açık SA öteleme önerisi: SA tarihi ihtiyaç tarihinden 14 günden fazla önce ise öteleme öner
            if ($gun_sa > 0 && !$siparis_onerisi) {
                foreach($sa_dates as $sa_t => $sa_m) {
                    if ($sa_t !== $tarih) continue;
                    // SA bu tarihte geliyor — ihtiyaç var mı kontrol
                    if ($gun_ihtiyac == 0 && $net_stok > 0) {
                        // Stok zaten yeterliyken SA geliyor — ötele
                        // En yakın ihtiyaç tarihini bul
                        $yakin_ihtiyac = null;
                        foreach($tarih_ihtiyac as $ti => $ti_m) {
                            if ($ti >= $tarih) { $yakin_ihtiyac = $ti; break; }
                        }
                        if ($yakin_ihtiyac) {
                            $ideal_sa = date('Y-m-d', strtotime($yakin_ihtiyac) - 7*86400);
                            if ($ideal_sa > $tarih) {
                                $siparis_onerisi = '⏩ Ötele → '.date('d.m.Y', strtotime($ideal_sa));
                                $siparis_oneri_tip = 'ertele';
                            }
                        }
                    }
                }
            }

            $liste_satirlar[] = [
                'mlz_kod'       => $mlz_kod,
                'mlz_adi'       => $info['adi'],
                'mlz_grup'      => $info['grup'],
                'stok'          => $stok,
                'tarih'         => $tarih,
                'gun_ihtiyac'   => $gun_ihtiyac,
                'gun_sa'        => $gun_sa,
                'kum_ihtiyac'   => $kum_ihtiyac,
                'kum_sa'        => $kum_sa,
                'net_stok'      => $net_stok,
                'net_gun'       => $net_gun,
                'tedarik'       => $tedarik,
                'durum'         => $durum,
                'sip_oneri'     => $siparis_onerisi,
                'sip_oneri_tip' => $siparis_oneri_tip,
                'ilk_eksik'     => $ilk_eksik,
            ];

            $once_net = $net_stok;
            $son_net  = $net_stok;
        }

        // Fazla hesap (son tarih)
        $kum_ihtiyac_toplam = array_sum($tarih_ihtiyac);
        $fazla_miktar = ($son_net > 0 && $kum_ihtiyac_toplam > 0 && ($son_net/$kum_ihtiyac_toplam)>0.15) ? $son_net : 0;
        $fazla_yuzde  = ($fazla_miktar > 0 && $kum_ihtiyac_toplam > 0) ? round(($son_net/$kum_ihtiyac_toplam)*100,1) : 0;

        if ($fazla_miktar > 0) {
            // Son satırın fazla bilgisini güncelle
            $last = &$liste_satirlar[count($liste_satirlar)-1];
            $last['fazla_miktar'] = $fazla_miktar;
            $last['fazla_yuzde']  = $fazla_yuzde;
            $last['durum'] = array_sum($sa_dates)>0 ? 'Sipariş Fazlası' : 'Fazla Stok';
            unset($last);
        }

        // Özet
        if ($ilk_eksik) $ozet['eksik'] = ($ozet['eksik']??0)+1;
        elseif($fazla_miktar > 0 && array_sum($sa_dates)>0) $ozet['fazla_sip'] = ($ozet['fazla_sip']??0)+1;
        elseif($fazla_miktar > 0) $ozet['fazla_stok'] = ($ozet['fazla_stok']??0)+1;
        else $ozet['ok'] = ($ozet['ok']??0)+1;
    }

    // Sıralama: ilk eksik olanlar öne (boş/ZZZZ en sona), sonra kod, sonra tarih ASC
    usort($liste_satirlar, function($a,$b){
        $ie_a = $a['ilk_eksik'] ?? 'ZZZZ';
        $ie_b = $b['ilk_eksik'] ?? 'ZZZZ';
        $cmp  = strcmp($ie_a, $ie_b);
        if ($cmp !== 0) return $cmp;
        $cmp2 = strcmp($a['mlz_kod'], $b['mlz_kod']);
        if ($cmp2 !== 0) return $cmp2;
        return strcmp($a['tarih'], $b['tarih']); // tarih ASC (eskiden yeniye)
    });

    $execution_time = round(microtime(true)-$t0, 2);

} catch(Throwable $e) { $hata = $e->getMessage(); }
son:;
}
$bugun_str = date('Y-m-d');
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Malzeme İhtiyaç Hesaplama</h1>
    <div class="s-yol">Planlama / <b>MİH</b>
      <?php if(!empty($liste_satirlar)): ?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● <?php echo count($liste_satirlar); ?> satır / <?php echo $execution_time; ?>s</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<style>
.mih-kart { background:var(--kart);border:1px solid var(--kenar);border-radius:12px;padding:16px 20px;margin-bottom:12px; }
/* Thead */
table.dataTable thead th,table.dataTable thead td { background:#2d5986!important;color:#e0f0ff!important;border-bottom:2px solid #1e3a5f!important; }
table.dataTable tfoot th { background:var(--bg)!important;color:var(--m2)!important;border-top:2px solid var(--kenar)!important;padding:5px 8px!important; }
/* Satır renkleri */
tr.ri td  { background:#FFF1F2!important; }  /* eksik */
tr.rw td  { background:#FFF7ED!important; }  /* uyarı/devam */
tr.rs td  { background:#EFF6FF!important; }  /* SA girişi */
tr.rf td  { background:#FEF3C7!important; }  /* fazla sipariş */
tr.rfst td{ background:#DBEAFE!important; }  /* fazla stok */
tr.rok td { background:#F0FDF4!important; }  /* yeterli */
/* Badge */
.bi  { background:#FEE2E2;color:#991B1B;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
.bw  { background:#FEF3C7;color:#92400E;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
.bsa { background:#DBEAFE;color:#1E40AF;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
.bf  { background:#FEF3C7;color:#92400E;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
.bfs { background:#EFF6FF;color:#1E40AF;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
.bok { background:#D1FAE5;color:#065F46;border-radius:3px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap; }
/* Btn */
.btn-dt { background:#2d5986!important;color:#fff!important;border:none!important;border-radius:4px!important;padding:5px 12px!important;font-size:12px!important;margin-right:4px!important; }
.btn-dt:hover { background:#1e3a5f!important; }
div.dt-buttons { margin-bottom:8px; }
/* MIH tablo kompakt + dikey border */
#mihTable td,#mihTable th { padding:3px 8px!important;font-size:11px!important;border-right:1px solid var(--kenar)!important;white-space:nowrap; }
#mihTable thead th { padding:5px 8px!important;font-size:11px!important;background:#2d5986;color:#e0f0ff; }
#mihTable tfoot th { padding:4px 6px!important;background:var(--bg);color:var(--m2); }
#mihTable tbody tr { height:26px; }
#mihTable tbody td { line-height:1.3; }
/* Today */
.today-row td { border-top:2px solid #3B82F6!important;border-bottom:2px solid #3B82F6!important; }
td.today-tarih { color:#2563EB;font-weight:700; }
</style>

<div class="s-body">
<?php if(!empty($hata)): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<!-- Filtre -->
<div class="mih-kart">
  <div style="font-size:13px;font-weight:800;color:var(--t);margin-bottom:12px;text-transform:uppercase;letter-spacing:.03em">📦 MİH Filtresi</div>
  <form method="POST" id="mihForm">
    <div style="display:flex;align-items:flex-end;gap:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:260px">
        <label class="form-etiket">Müşteri <span style="color:var(--m2);font-weight:400">(Boş = tümü)</span></label>
        <select id="mih_musteri" name="musteriler[]" multiple placeholder="Müşteri seçin..." autocomplete="off">
          <?php foreach($musteri_listesi as $m): ?>
          <option value="<?php echo htmlspecialchars($m); ?>" <?php echo in_array($m,$secili_musteriler)?'selected':''; ?>><?php echo htmlspecialchars($m); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="min-width:160px">
        <label class="form-etiket">Malzeme Grubu</label>
        <select name="material_group" class="form-alan" id="mihGrup">
          <option value="">Tüm Gruplar</option>
          <?php foreach($grp_list as $g): ?>
          <option value="<?php echo htmlspecialchars($g); ?>" <?php echo $f_grup===$g?'selected':''; ?>><?php echo htmlspecialchars($g); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:8px;padding-bottom:2px">
        <button type="submit" name="mih_calistir" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:10px 22px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">▶ Hesapla</button>
        <button type="button" onclick="mihSel.clear();document.getElementById('mihGrup').value='';document.getElementById('mihForm').submit();" style="background:var(--bg);color:var(--m);border:1px solid var(--kenar);padding:10px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;font-size:13px">✕ Temizle</button>
      </div>
    </div>
  </form>
</div>

<?php if(!$form_gonderildi): ?>
<div style="padding:50px;text-align:center;color:var(--m2);background:var(--bg);border-radius:12px;border:2px dashed var(--kenar)">
  <div style="font-size:36px;margin-bottom:12px">📦</div>
  <div style="font-size:15px;font-weight:700;color:var(--t)">Hesaplama Başlatılmadı</div>
  <div style="font-size:13px;margin-top:6px">Filtre seçip <strong>Hesapla</strong> butonuna tıklayın.</div>
</div>

<?php elseif(empty($liste_satirlar) && empty($hata)): ?>
<div style="padding:40px;text-align:center;color:var(--m2)">Hesaplanacak veri bulunamadı.</div>

<?php else: ?>

<!-- Özet kartları -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:12px">
<?php foreach([
  ['🔴 Eksik Stok',     $ozet['eksik']??0,     '#FEE2E2','#991B1B'],
  ['🟠 Sipariş Fazlası',$ozet['fazla_sip']??0,  '#FEF3C7','#92400E'],
  ['🔵 Fazla Stok',     $ozet['fazla_stok']??0, '#DBEAFE','#1E40AF'],
  ['🟢 Yeterli',        $ozet['ok']??0,         '#D1FAE5','#065F46'],
] as [$lbl,$cnt,$bg,$fg]): ?>
<div style="background:<?php echo $bg;?>;border-radius:10px;padding:12px 14px;text-align:center">
  <div style="font-size:11px;color:<?php echo $fg;?>;font-weight:600;margin-bottom:4px"><?php echo $lbl;?></div>
  <div style="font-size:24px;font-weight:800;color:<?php echo $fg;?>"><?php echo $cnt;?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="mih-kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto;overflow-y:auto;max-height:520px">
<table id="mihTable" class="tablo" style="width:100%;border-collapse:collapse">
<thead style="position:sticky;top:0;z-index:3;background:var(--yuzey)">
<tr>
  <th>Durum</th>
  <th>Malzeme Kodu</th>
  <th>Malzeme Adı</th>
  <th>Grup</th>
  <th>Tarih</th>
  <th style="text-align:right">Başl. Stok</th>
  <th style="text-align:right">Günlük İhtiyaç</th>
  <th style="text-align:right">Açık SA (Gün)</th>
  <th style="text-align:right">Küm. İhtiyaç</th>
  <th style="text-align:right">Küm. SA</th>
  <th style="text-align:right">Net Stok</th>
  <th style="text-align:right">Net İhtiyaç</th>
  <th style="text-align:right">Tedarik</th>
  <th>Sipariş Önerisi</th>
</tr>
</thead>
<tfoot style="position:sticky;bottom:0;z-index:3;background:var(--bg)">
<tr>
  <th>Durum</th><th>Malzeme Kodu</th><th>Malzeme Adı</th><th>Grup</th>
  <th>Tarih</th><th>Başl. Stok</th><th>Günlük İhtiyaç</th><th>Açık SA (Gün)</th>
  <th>Küm. İhtiyaç</th><th>Küm. SA</th><th>Net Stok</th><th>Net İhtiyaç</th>
  <th>Tedarik</th><th>Sipariş Önerisi</th>
</tr>
</tfoot>
<tbody>
<?php
$prev_kod = null;
foreach($liste_satirlar as $s):
  $is_today = ($s['tarih'] === $bugun_str);
  $is_first = ($s['mlz_kod'] !== $prev_kod);
  $prev_kod = $s['mlz_kod'];

  // Satır renk sınıfı
  switch($s['durum']) {
    case 'İlk Yetersizlik': $rc='ri'; break;
    case 'Eksiklik Devam':  $rc='rw'; break;
    case 'SA Girişi':       $rc='rs'; break;
    case 'Sipariş Fazlası': $rc='rf'; break;
    case 'Fazla Stok':      $rc='rfst'; break;
    default:                $rc='rok';
  }

  // Badge
  $badge_map = [
    'İlk Yetersizlik'=> ['bi','İlk Yetersizlik'],
    'Eksiklik Devam' => ['bw','Eksiklik Devam'],
    'SA Girişi'      => ['bsa','SA Girişi'],
    'Sipariş Fazlası'=> ['bf','Sipariş Fazlası'],
    'Fazla Stok'     => ['bfs','Fazla Stok'],
    'Yeterli'        => ['bok','Yeterli'],
  ];
  [$bc,$bl] = $badge_map[$s['durum']] ?? ['bok','Yeterli'];

  // Net stok rengi
  $ns_color = $s['net_stok'] < 0 ? '#991B1B' : ($s['net_stok'] > 0 ? '#166534' : '#64748B');
?>
<tr class="<?php echo $rc; ?><?php echo $is_today?' today-row':''; ?>">
  <td><span class="<?php echo $bc;?>"><?php echo $bl;?></span></td>
  <td style="font-weight:700;font-size:11px">
    <code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-weight:700;font-size:11px;color:var(--t)"><?php echo htmlspecialchars($s['mlz_kod']);?></code>
  </td>
  <td style="font-size:12px"><?php echo htmlspecialchars($s['mlz_adi']); ?></td>
  <td style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($s['mlz_grup']); ?></td>
  <td class="<?php echo $is_today?'today-tarih':''; ?>" style="font-size:12px;font-weight:600;white-space:nowrap" data-order="<?php echo $s['tarih']; ?>">
    <?php echo date('d.m.Y', strtotime($s['tarih']));?>
    <?php if($is_today): ?><span style="font-size:9px;background:#3B82F6;color:#fff;border-radius:3px;padding:1px 4px;margin-left:3px">BUGÜN</span><?php endif;?>
  </td>
  <td style="text-align:right;color:var(--m2)"><?php echo number_format($s['stok'],0,',','.'); ?></td>
  <td style="text-align:right;font-weight:<?php echo $s['gun_ihtiyac']>0?'700':'400';?>">
    <?php echo $s['gun_ihtiyac']>0 ? number_format($s['gun_ihtiyac'],0,',','.') : '—';?>
  </td>
  <td style="text-align:right;color:#0369A1;font-weight:<?php echo $s['gun_sa']>0?'700':'400';?>">
    <?php echo $s['gun_sa']>0 ? '<span style="color:#0369A1;font-weight:700">+'.number_format($s['gun_sa'],0,',','.').'</span>' : '—';?>
  </td>
  <td style="text-align:right;color:var(--m2)"><?php echo number_format($s['kum_ihtiyac'],0,',','.');?></td>
  <td style="text-align:right;color:<?php echo $s['kum_sa']>0?'#0369A1':'var(--m2)';?>"><?php echo $s['kum_sa']>0?number_format($s['kum_sa'],0,',','.'):'—';?></td>
  <td style="text-align:right;font-weight:700;color:<?php echo $ns_color;?>"><?php echo number_format($s['net_stok'],0,',','.');?></td>
  <td style="text-align:right;font-weight:700;color:<?php echo $s['net_gun']>0?'#991B1B':'#94A3B8';?>">
    <?php echo $s['net_gun']>0 ? number_format($s['net_gun'],0,',','.') : '—';?>
  </td>
  <td style="text-align:right;font-weight:700;color:<?php echo $s['tedarik']>0?'#DC2626':'#94A3B8';?>">
    <?php echo $s['tedarik']>0 ? number_format($s['tedarik'],0,',','.') : '—';?>
  </td>
  <td style="font-size:11px;color:#92400E">
    <?php if(!empty($s['sip_oneri'])):
      $tip = $s['sip_oneri_tip'] ?? 'yeni';
      $o_bg = $tip==='ertele' ? '#EDE9FE' : ($tip==='yeni' && strpos($s['sip_oneri'],'🚨')!==false ? '#FEE2E2' : ($tip==='yeni' && strpos($s['sip_oneri'],'⚡')!==false ? '#FEF3C7' : '#DCFCE7'));
      $o_fg = $tip==='ertele' ? '#5B21B6' : ($tip==='yeni' && strpos($s['sip_oneri'],'🚨')!==false ? '#991B1B' : ($tip==='yeni' && strpos($s['sip_oneri'],'⚡')!==false ? '#92400E' : '#166534'));
    ?><span style="background:<?php echo $o_bg;?>;color:<?php echo $o_fg;?>;padding:2px 8px;border-radius:4px;font-weight:700;font-size:11px;white-space:nowrap"><?php echo htmlspecialchars($s['sip_oneri']);?></span><?php endif;?>
    <?php if(!empty($s['fazla_miktar'])): ?><span style="background:#DBEAFE;color:#1E40AF;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700">+%<?php echo $s['fazla_yuzde'];?> fazla</span><?php endif;?>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php endif; ?>
</div>

<!-- Tom Select -->
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
<script>var mihSel = new TomSelect('#mih_musteri',{plugins:['remove_button'],placeholder:'Müşteri seçin...',maxOptions:500});</script>
<style>
.ts-wrapper.multi .ts-control,.ts-wrapper.single .ts-control { background:#fff!important;border:1px solid var(--kenar)!important;border-radius:8px!important; }
.ts-dropdown { background:#fff!important;border:1px solid var(--kenar)!important;color:#1e293b!important; }
.ts-dropdown .option { background:#fff!important;color:#1e293b!important; }
.ts-dropdown .option:hover,.ts-dropdown .option.active { background:#EFF6FF!important;color:#1E40AF!important; }
.ts-control .item { background:#DBEAFE!important;color:#1E40AF!important;border-radius:4px!important;font-weight:600; }
</style>

<?php if(!empty($liste_satirlar)): ?>
<script>
$(document).ready(function(){
  $('#mihTable').DataTable({
    paging:false,
    autoWidth:true,
    order:[[1,'asc'],[4,'asc']],
    columnDefs:[{targets:4, type:'string'}],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'MIH_Malzeme_Ihtiyac'}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns([0,1,2,3,13]).every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>
<?php endif; ?>
