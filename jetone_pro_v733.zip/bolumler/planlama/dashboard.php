<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$bugun    = date('Y-m-d');
$bugun_ay_n = (int)date('n');
$selYil   = (int)date('Y');
$aylar_tr = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$bugun_ay = $aylar_tr[$bugun_ay_n-1];

function p_val($db,$sql,$p=[],$d=0){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetchColumn()??$d;}catch(Throwable $e){return $d;}}
function p_rows($db,$sql,$p=[]){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return[];}}
function t_val($db,$sql,$d=0){try{return $db->query($sql)->fetchColumn()??$d;}catch(Throwable $e){return $d;}}

// ── STOK SAYIM KPI ──────────────────────────────────────────────
$kpi_data = p_rows($db,"SELECT * FROM aylik_kpi_stok WHERE yil=? ORDER BY
    CASE ay WHEN 'Ocak' THEN 1 WHEN 'Şubat' THEN 2 WHEN 'Mart' THEN 3 WHEN 'Nisan' THEN 4
    WHEN 'Mayıs' THEN 5 WHEN 'Haziran' THEN 6 WHEN 'Temmuz' THEN 7 WHEN 'Ağustos' THEN 8
    WHEN 'Eylül' THEN 9 WHEN 'Ekim' THEN 10 WHEN 'Kasım' THEN 11 WHEN 'Aralık' THEN 12 END",
    [$selYil]);
$kpi_map  = array_column($kpi_data, null, 'ay');
$bu_ay_kpi= $kpi_map[$bugun_ay] ?? null;
$sayim_gercek = (int)($bu_ay_kpi['gerceklesen_sayim']??0);
$sayim_hedef  = (int)($bu_ay_kpi['hedef_sayim_adedi']??50);
$sayim_uyum   = floatval($bu_ay_kpi['hedefe_uyum']??0);
$sayim_gerceklesme = floatval($bu_ay_kpi['gerceklesme']??0);

// Son 3 ay sayım özeti
$son_sayimlar_aylik = [];
for ($i=2;$i>=0;$i--) {
    $ay_n = $bugun_ay_n - $i;
    $yil  = $selYil;
    if ($ay_n <= 0) { $ay_n += 12; $yil--; }
    $ay_adi = $aylar_tr[$ay_n-1];
    $row = $kpi_map[$ay_adi] ?? null;
    $son_sayimlar_aylik[] = [
        'ay'    => $ay_adi,
        'gercek'=> (int)($row['gerceklesen_sayim']??0),
        'hedef' => (int)($row['hedef_sayim_adedi']??50),
        'uyum'  => floatval($row['hedefe_uyum']??0),
    ];
}

// Son sayımlar listesi
$son_sayimlar = p_rows($db,"SELECT stok_kodu,stok_adi,kayitli_stok,sayim_miktari,oran,puan,donem,sayim_tarihi FROM sayimlar WHERE yil=? ORDER BY sayim_tarihi DESC LIMIT 8",[$selYil]);

// ── TEDARİKÇİ PERFORMANS (Tiger CROSS APPLY) ────────────────────
$ted_aylik = []; // ay => [zamaninda,gec,toplam,puan]
foreach ($aylar_tr as $ay) $ted_aylik[$ay]=['zamaninda'=>0,'gec'=>0,'toplam'=>0,'puan'=>0];

if ($tiger_ok) {
    try {
        $sql = "SELECT MONTH(OL.DUEDATE) ay,
            DATEDIFF(DAY,OL.DUEDATE,nearest.irs_tarihi) gecikme_gun
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
        CROSS APPLY (
            SELECT TOP 1 F.DATE_ irs_tarihi
            FROM dbo.LG_222_02_STLINE SL WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_02_STFICHE F WITH(NOLOCK) ON SL.STFICHEREF=F.LOGICALREF
            WHERE SL.STOCKREF=OL.STOCKREF AND SL.TRCODE=1 AND SL.CANCELLED=0 AND F.TRCODE=1 AND SL.AMOUNT>0
            ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,F.DATE_)) ASC, F.DATE_ ASC
        ) nearest
        WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT>0
          AND YEAR(OL.DUEDATE)=".intval($selYil)."
          AND OL.DUEDATE IS NOT NULL";
        $rows = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $ay_n=(int)($r['ay']??0);
            if ($ay_n<1||$ay_n>12) continue;
            $ay=$aylar_tr[$ay_n-1];
            $gec=(int)($r['gecikme_gun']??0);
            $ted_aylik[$ay]['toplam']++;
            if ($gec<=2) $ted_aylik[$ay]['zamaninda']++;
            else         $ted_aylik[$ay]['gec']++;
        }
        foreach ($ted_aylik as $ay=>&$v)
            $v['puan']=$v['toplam']>0?round($v['zamaninda']/$v['toplam']*100,1):0;
        unset($v);
    } catch(Throwable $e) {}
}

// Genel tedarikçi performans
$ted_genel_toplam    = array_sum(array_column($ted_aylik,'toplam'));
$ted_genel_zamaninda = array_sum(array_column($ted_aylik,'zamaninda'));
$ted_genel_puan      = $ted_genel_toplam>0?round($ted_genel_zamaninda/$ted_genel_toplam*100,1):0;
$bu_ay_ted_puan      = $ted_aylik[$bugun_ay]['puan']??0;

// ── ARÇELİK SİPARİŞLERİ (Ortel İhtiyaç) ────────────────────────
$arclik_acik    = p_val($db,"SELECT COUNT(*) FROM siparis WHERE musteri_firma_adi LIKE '%ARÇELİK%' AND sip_statu='Aktif' AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0");
$arclik_geciken = p_val($db,"SELECT COUNT(*) FROM siparis WHERE musteri_firma_adi LIKE '%ARÇELİK%' AND sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$arclik_bugun   = p_val($db,"SELECT COUNT(*) FROM siparis WHERE musteri_firma_adi LIKE '%ARÇELİK%' AND sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);

// ── MRP / STOK DURUMU (Tiger) ────────────────────────────────────
$mrp_kritik = 0; $mrp_stok_toplam = 0;
if ($tiger_ok) {
    try {
        $mrp_kritik = t_val($tigerdb_pdo,"SELECT COUNT(*) FROM LG_222_ITEMS IT WITH(NOLOCK)
            LEFT JOIN LV_222_02_STINVTOT LV WITH(NOLOCK) ON LV.STOCKREF=IT.LOGICALREF AND LV.INVENNO IN(0,1)
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
            AND IT.STGRPCODE IN('Mamül','ambalaj','Plastik HM','Yarımamül')
            GROUP BY IT.CODE HAVING SUM(ISNULL(LV.ONHAND,0)) <= 0");
        $mrp_stok_toplam = t_val($tigerdb_pdo,"SELECT COUNT(DISTINCT IT.CODE) FROM LG_222_ITEMS IT WITH(NOLOCK)
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
            AND IT.STGRPCODE IN('Mamül','ambalaj','Plastik HM','Yarımamül')");
    } catch(Throwable $e) {}
}

// Grafik verileri
$grafik_sayim_gercek = array_map(fn($k)=>$kpi_map[$k]['gerceklesen_sayim']??0, $aylar_tr);
$grafik_sayim_hedef  = array_map(fn($k)=>$kpi_map[$k]['hedef_sayim_adedi']??50, $aylar_tr);
$grafik_ted_puan     = array_map(fn($k)=>$ted_aylik[$k]['puan']??0, $aylar_tr);
$grafik_ay_kisa      = ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];

function puan_renk_css($p,$hedef=85){
    if($p>=$hedef) return '#16A34A';
    if($p>=$hedef*0.7) return '#D97706';
    return '#DC2626';
}
?>
<style>
.pl-grid{display:grid;gap:12px;margin-bottom:14px}
.pl-g4{grid-template-columns:repeat(4,1fr)}
.pl-g3{grid-template-columns:repeat(3,1fr)}
.pl-g2{grid-template-columns:1fr 1fr}
@media(max-width:1100px){.pl-g4{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.pl-g4,.pl-g3,.pl-g2{grid-template-columns:1fr}}
.pl-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;overflow:hidden}
.pl-kart-bas{padding:10px 14px;font-size:12px;font-weight:800;letter-spacing:.4px;display:flex;align-items:center;justify-content:space-between}
.pl-kart-ic{padding:12px 14px}
.pl-stat{border-radius:8px;padding:10px 12px;text-align:center}
.pl-stat .v{font-size:24px;font-weight:900;line-height:1}
.pl-stat .l{font-size:10px;font-weight:700;margin-top:3px;text-transform:uppercase;letter-spacing:.4px;opacity:.8}
.pl-mini-tbl{width:100%;border-collapse:collapse;font-size:11px}
.pl-mini-tbl th{background:#1E3A5F;color:#fff;padding:5px 8px;text-align:left;white-space:nowrap;border:1px solid #2d5986}
.pl-mini-tbl td{padding:5px 8px;border:1px solid #F1F5F9;white-space:nowrap}
.pl-pbar{height:8px;border-radius:4px;background:#E2E8F0;overflow:hidden;margin-top:4px}
.pl-pbar-fill{height:100%;border-radius:4px;transition:width .5s}
.pl-link{display:block;text-align:right;font-size:11px;font-weight:700;color:#1E3A5F;text-decoration:none;margin-top:8px;opacity:.7}
.pl-link:hover{opacity:1}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">🗂 Planlama Dashboard</h1>
    <div class="s-yol">Planlama / <b>Genel Durum · <?php echo date('d.m.Y H:i');?></b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php endif;?>
    </div>
  </div>
  <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:6px 14px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
</div>

<!-- ── 4 ANA KPI KARTI ──────────────────────────────────────────── -->
<div class="pl-grid pl-g4" style="margin-bottom:14px">

  <div style="background:linear-gradient(135deg,#1E3A5F,#2563EB);border-radius:12px;padding:16px;color:#fff;position:relative;overflow:hidden">
    <div style="position:absolute;right:-10px;bottom:-10px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.1)"></div>
    <div style="font-size:11px;font-weight:700;opacity:.8;margin-bottom:6px">📦 Bu Ay Sayım</div>
    <div style="font-size:32px;font-weight:900;line-height:1"><?php echo $sayim_gercek;?><span style="font-size:16px;opacity:.7"> / <?php echo $sayim_hedef;?></span></div>
    <div style="font-size:11px;opacity:.75;margin-top:4px"><?php echo $bugun_ay;?> Gerçekleşen / Hedef</div>
    <div style="background:rgba(255,255,255,.15);border-radius:4px;height:6px;margin-top:10px;overflow:hidden">
      <div style="height:100%;background:#fff;border-radius:4px;width:<?php echo $sayim_hedef>0?min(100,round($sayim_gercek/$sayim_hedef*100)):0;?>%"></div>
    </div>
  </div>

  <div style="background:linear-gradient(135deg,<?php echo $sayim_uyum>=85?'#065F46,#16A34A':'#991B1B,#DC2626';?>);border-radius:12px;padding:16px;color:#fff;position:relative;overflow:hidden">
    <div style="position:absolute;right:-10px;bottom:-10px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.1)"></div>
    <div style="font-size:11px;font-weight:700;opacity:.8;margin-bottom:6px">🎯 Sayım Hedefe Uyum</div>
    <div style="font-size:32px;font-weight:900;line-height:1"><?php echo number_format($sayim_uyum,0);?>%</div>
    <div style="font-size:11px;opacity:.75;margin-top:4px"><?php echo $bugun_ay;?> · Hedef %85</div>
    <div style="background:rgba(255,255,255,.15);border-radius:4px;height:6px;margin-top:10px;overflow:hidden">
      <div style="height:100%;background:#fff;border-radius:4px;width:<?php echo min(100,$sayim_uyum);?>%"></div>
    </div>
  </div>

  <div style="background:linear-gradient(135deg,<?php echo $bu_ay_ted_puan>=87?'#064E3B,#059669':'#92400E,#D97706';?>);border-radius:12px;padding:16px;color:#fff;position:relative;overflow:hidden">
    <div style="position:absolute;right:-10px;bottom:-10px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.1)"></div>
    <div style="font-size:11px;font-weight:700;opacity:.8;margin-bottom:6px">🏭 Tedarikçi Performans</div>
    <div style="font-size:32px;font-weight:900;line-height:1"><?php echo $bu_ay_ted_puan>0?$bu_ay_ted_puan.'%':'—';?></div>
    <div style="font-size:11px;opacity:.75;margin-top:4px"><?php echo $bugun_ay;?> · Hedef %87</div>
    <div style="background:rgba(255,255,255,.15);border-radius:4px;height:6px;margin-top:10px;overflow:hidden">
      <div style="height:100%;background:#fff;border-radius:4px;width:<?php echo min(100,$bu_ay_ted_puan);?>%"></div>
    </div>
  </div>

  <div style="background:linear-gradient(135deg,#4C1D95,#7C3AED);border-radius:12px;padding:16px;color:#fff;position:relative;overflow:hidden">
    <div style="position:absolute;right:-10px;bottom:-10px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.1)"></div>
    <div style="font-size:11px;font-weight:700;opacity:.8;margin-bottom:6px">⚡ ARÇELİK Siparişler</div>
    <div style="font-size:32px;font-weight:900;line-height:1"><?php echo $arclik_acik;?><span style="font-size:14px;opacity:.7"> açık</span></div>
    <div style="font-size:11px;opacity:.75;margin-top:4px">
      <?php if($arclik_geciken>0):?><span style="background:rgba(220,38,38,.4);padding:2px 6px;border-radius:4px">🔴 <?php echo $arclik_geciken;?> geciken</span><?php endif;?>
      <?php if($arclik_bugun>0):?><span style="background:rgba(251,191,36,.3);padding:2px 6px;border-radius:4px;margin-left:4px">🟡 bugün <?php echo $arclik_bugun;?></span><?php endif;?>
    </div>
  </div>

</div>

<!-- ── SATIR 1: Grafikler ──────────────────────────────────────── -->
<div class="pl-grid pl-g2" style="margin-bottom:14px">

  <div class="pl-kart">
    <div class="pl-kart-bas" style="background:#1E3A5F;color:#fff">
      <span>📊 Stok Sayım Gerçekleşme (<?php echo $selYil;?>)</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=raporlar-sayim" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="pl-kart-ic">
      <div style="position:relative;height:160px"><canvas id="plSayimChart"></canvas></div>
    </div>
  </div>

  <div class="pl-kart">
    <div class="pl-kart-bas" style="background:#1E3A5F;color:#fff">
      <span>🏭 Tedarikçi Performans (<?php echo $selYil;?>)</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-performans" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="pl-kart-ic">
      <div style="position:relative;height:160px"><canvas id="plTedChart"></canvas></div>
    </div>
  </div>

</div>

<!-- ── SATIR 2: Son Sayımlar + KPI Özet + ARÇELİK ────────────── -->
<div class="pl-grid pl-g3">

  <!-- Son Sayımlar -->
  <div class="pl-kart">
    <div class="pl-kart-bas" style="background:#1E3A5F;color:#fff">
      <span>🔢 Son Sayımlar</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=raporlar-sayim" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Tümü →</a>
    </div>
    <div style="overflow-x:auto">
    <table class="pl-mini-tbl">
      <thead><tr><th>Stok Kodu</th><th>Dönem</th><th style="text-align:right">Oran</th><th style="text-align:center">Puan</th></tr></thead>
      <tbody>
      <?php if(empty($son_sayimlar)):?>
      <tr><td colspan="4" style="text-align:center;padding:20px;color:#94A3B8">Kayıt yok</td></tr>
      <?php else: foreach($son_sayimlar as $s):
        $oran=floatval($s['oran']); $puan=(int)$s['puan'];
      ?>
      <tr>
        <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px"><?php echo htmlspecialchars($s['stok_kodu']);?></code></td>
        <td style="font-size:10px;color:#64748B"><?php echo $s['donem'];?></td>
        <td style="text-align:right;font-weight:700;color:<?php echo ($oran>=85&&$oran<=115)?'#16A34A':($oran>=70?'#D97706':'#DC2626');?>"><?php echo number_format($oran,0);?>%</td>
        <td style="text-align:center"><span style="background:<?php echo $puan?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $puan?'#065F46':'#991B1B';?>;padding:1px 6px;border-radius:8px;font-size:10px;font-weight:700"><?php echo $puan?'✅':'❌';?></span></td>
      </tr>
      <?php endforeach; endif;?>
      </tbody>
    </table>
    </div>
  </div>

  <!-- KPI Özet 3 Ay -->
  <div class="pl-kart">
    <div class="pl-kart-bas" style="background:#1E3A5F;color:#fff">
      <span>📈 KPI Özet — Son 3 Ay</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kpi-ozet" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="pl-kart-ic">
      <!-- 3 aylık karşılaştırma -->
      <?php foreach($son_sayimlar_aylik as $ay_row):
        $pct = $ay_row['hedef']>0?min(100,round($ay_row['gercek']/$ay_row['hedef']*100)):0;
        $uyum_renk = puan_renk_css($ay_row['uyum']);
      ?>
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <span style="font-size:12px;font-weight:700"><?php echo $ay_row['ay'];?></span>
          <div style="display:flex;gap:8px;font-size:11px">
            <span style="color:#64748B"><?php echo $ay_row['gercek'];?>/<?php echo $ay_row['hedef'];?> sayım</span>
            <span style="font-weight:700;color:<?php echo $uyum_renk;?>"><?php echo $ay_row['uyum']>0?number_format($ay_row['uyum'],0).'%':'—';?></span>
          </div>
        </div>
        <div class="pl-pbar">
          <div class="pl-pbar-fill" style="width:<?php echo $pct;?>%;background:<?php echo $uyum_renk;?>"></div>
        </div>
      </div>
      <?php endforeach;?>

      <div style="border-top:1px solid #E2E8F0;margin-top:10px;padding-top:10px">
        <div style="font-size:11px;font-weight:700;color:#374151;margin-bottom:8px">🏭 Tedarikçi Performans Özeti</div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="text-align:center">
            <div style="font-size:20px;font-weight:900;color:<?php echo puan_renk_css($ted_genel_puan,87);?>"><?php echo $ted_genel_puan>0?$ted_genel_puan.'%':'—';?></div>
            <div style="font-size:10px;color:#64748B"><?php echo $selYil;?> Ortalama</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:20px;font-weight:900;color:#16A34A"><?php echo number_format($ted_genel_zamaninda);?></div>
            <div style="font-size:10px;color:#64748B">Zamanında</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:20px;font-weight:900;color:#DC2626"><?php echo number_format($ted_genel_toplam-$ted_genel_zamaninda);?></div>
            <div style="font-size:10px;color:#64748B">Geç</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ARÇELİK + Hızlı Erişim -->
  <div class="pl-kart">
    <div class="pl-kart-bas" style="background:#4C1D95;color:#fff">
      <span>⚡ ARÇELİK & Ortel</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-ortel-ihtiyac" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">İhtiyaç →</a>
    </div>
    <div class="pl-kart-ic">
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:12px">
        <div class="pl-stat" style="background:#EDE9FE;color:#7C3AED">
          <div class="v"><?php echo $arclik_acik;?></div><div class="l">Açık Sipariş</div>
        </div>
        <div class="pl-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $arclik_geciken;?></div><div class="l">Geciken</div>
        </div>
        <div class="pl-stat" style="background:#FEF9C3;color:#92400E">
          <div class="v"><?php echo $arclik_bugun;?></div><div class="l">Bugün</div>
        </div>
      </div>

      <?php if($tiger_ok&&$mrp_stok_toplam>0):?>
      <div style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:10px;margin-bottom:10px">
        <div style="font-size:11px;font-weight:700;color:#92400E;margin-bottom:4px">⚠️ Sıfır Stok Uyarısı</div>
        <div style="font-size:20px;font-weight:900;color:#DC2626"><?php echo $mrp_kritik;?> <span style="font-size:12px;color:#64748B">/ <?php echo $mrp_stok_toplam;?> malzeme sıfır stok</span></div>
      </div>
      <?php endif;?>

      <div style="font-size:11px;font-weight:700;color:#374151;margin-bottom:8px">🔗 Hızlı Erişim</div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <?php $linkler=[
          ['satinalma-ortel-recete','🔧','Ortel Reçeteler','#EDE9FE','#7C3AED'],
          ['satinalma-ortel-ihtiyac','📊','Ortel İhtiyaç','#DBEAFE','#1D4ED8'],
          ['satinalma-performans','📈','Tedarikçi Performans','#D1FAE5','#065F46'],
          ['raporlar-sayim','🔢','Sayım Performansı','#FEF0C7','#92400E'],
          ['planlama-kpi-ozet','📊','KPI Özet Tablo','#EDE9FE','#7C3AED'],
        ];
        foreach($linkler as [$link,$ikon,$ad,$bg,$color]):?>
        <a href="<?php echo BASE_URL;?>/panel.php?sayfa=<?php echo $link;?>"
          style="background:<?php echo $bg;?>;color:<?php echo $color;?>;border-radius:6px;padding:6px 10px;text-decoration:none;font-size:11px;font-weight:700;display:flex;align-items:center;gap:6px">
          <?php echo $ikon;?> <?php echo $ad;?>
        </a>
        <?php endforeach;?>
      </div>
    </div>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
var AY_KISA = <?php echo json_encode($grafik_ay_kisa, JSON_UNESCAPED_UNICODE);?>;
var SAYIM_GERCEK = <?php echo json_encode($grafik_sayim_gercek);?>;
var SAYIM_HEDEF  = <?php echo json_encode($grafik_sayim_hedef);?>;
var TED_PUAN     = <?php echo json_encode($grafik_ted_puan);?>;

(function(){
    if(window._plChart1){window._plChart1.destroy();}
    if(window._plChart2){window._plChart2.destroy();}

    var c1 = document.getElementById('plSayimChart');
    if(c1) window._plChart1 = new Chart(c1, {
        type:'bar',
        data:{
            labels: AY_KISA,
            datasets:[
                {label:'Gerçekleşen',data:SAYIM_GERCEK,backgroundColor:'rgba(37,99,235,.7)',borderRadius:3},
                {label:'Hedef',data:SAYIM_HEDEF,type:'line',borderColor:'#F59E0B',borderWidth:2,
                 borderDash:[4,3],pointRadius:0,fill:false}
            ]
        },
        options:{responsive:true,maintainAspectRatio:false,animation:false,
            plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:12}}},
            scales:{y:{beginAtZero:true,ticks:{font:{size:10}},grid:{color:'rgba(0,0,0,.05)'}},
                    x:{ticks:{font:{size:10}},grid:{display:false}}}}
    });

    var c2 = document.getElementById('plTedChart');
    if(c2) window._plChart2 = new Chart(c2, {
        type:'line',
        data:{
            labels: AY_KISA,
            datasets:[
                {label:'Tedarikçi %',data:TED_PUAN,borderColor:'#1E3A5F',backgroundColor:'rgba(30,58,95,.1)',
                 borderWidth:2,fill:true,tension:.4,pointRadius:3,pointBackgroundColor:'#1E3A5F'},
                {label:'Hedef %87',data:Array(12).fill(87),borderColor:'#DC2626',borderWidth:1,
                 borderDash:[4,3],pointRadius:0,fill:false}
            ]
        },
        options:{responsive:true,maintainAspectRatio:false,animation:false,
            plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:12}}},
            scales:{y:{beginAtZero:true,max:110,ticks:{font:{size:10},callback:function(v){return v+'%'}},
                       grid:{color:'rgba(0,0,0,.05)'}},
                    x:{ticks:{font:{size:10}},grid:{display:false}}}}
    });
})();
</script>
