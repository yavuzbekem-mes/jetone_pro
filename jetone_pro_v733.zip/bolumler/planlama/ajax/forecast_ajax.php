<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);

$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
require_once $root . '/core/baglanlogo.php';

ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'msg'=>'Oturum sona erdi']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['ok'=>false,'msg'=>'POST gerekli']); exit; }

$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';
$action  = $_POST['fc_action'] ?? '';

// ── KAYDET ──────────────────────────────────────────────────────
if ($action === 'kaydet') {
    $data = json_decode($_POST['forecast_json'] ?? '[]', true) ?: [];
    if (empty($data)) { echo json_encode(['ok'=>false,'msg'=>'Veri yok']); exit; }
    try {
        $stmt = $db->prepare("INSERT INTO forecast
            (firma,stok_kodu,stok_adi,tur,yil,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12,ekleyen)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $eklendi = 0;
        foreach ($data as $r) {
            $stmt->execute([$r['firma'],$r['stok_kodu'],$r['stok_adi'],$r['tur'],$r['yil']??date('Y'),
                $r['ay1']??0,$r['ay2']??0,$r['ay3']??0,$r['ay4']??0,$r['ay5']??0,$r['ay6']??0,
                $r['ay7']??0,$r['ay8']??0,$r['ay9']??0,$r['ay10']??0,$r['ay11']??0,$r['ay12']??0,$kul_adi]);
            $eklendi++;
        }
        echo json_encode(['ok'=>true,'eklendi'=>$eklendi]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

// ── GÜNCELLE ────────────────────────────────────────────────────
if ($action === 'guncelle') {
    $id  = (int)($_POST['id']     ?? 0);
    $kol = trim($_POST['kolon']   ?? '');
    $val = trim($_POST['deger']   ?? '');
    $izinli = ['firma','stok_kodu','stok_adi','tur','yil',
               'ay1','ay2','ay3','ay4','ay5','ay6','ay7','ay8','ay9','ay10','ay11','ay12'];
    if (!$id || !in_array($kol,$izinli,true)) { echo json_encode(['ok'=>false]); exit; }
    try {
        $db->prepare("UPDATE forecast SET `$kol`=? WHERE id=?")->execute([$val,$id]);
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

// ── SİL ─────────────────────────────────────────────────────────
if ($action === 'sil') {
    $ids = array_filter(array_map('intval', explode(',', $_POST['ids'] ?? '')));
    if (empty($ids)) { echo json_encode(['ok'=>false]); exit; }
    try {
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $db->prepare("DELETE FROM forecast WHERE id IN ($ph)")->execute(array_values($ids));
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

// ── EXCEL YÜKLE ─────────────────────────────────────────────────
if ($action === 'excel_yukle') {
    if (empty($_FILES['excel']['tmp_name'])) { echo json_encode(['ok'=>false,'msg'=>'Dosya yüklenemedi']); exit; }
    try {
        require_once $root . '/core/SimpleXLSX.php';
        $xlsx = new SimpleXLSX($_FILES['excel']['tmp_name']);
        if (!$xlsx->success()) { echo json_encode(['ok'=>false,'msg'=>'Excel okunamadı: '.$xlsx->error()]); exit; }
        $firma = trim($_POST['excel_firma'] ?? '');
        $yil   = (int)($_POST['excel_yil']  ?? date('Y'));
        if (!$firma) { echo json_encode(['ok'=>false,'msg'=>'Firma boş']); exit; }
        $stmt = $db->prepare("INSERT INTO forecast
            (firma,stok_kodu,stok_adi,tur,yil,ay1,ay2,ay3,ay4,ay5,ay6,ay7,ay8,ay9,ay10,ay11,ay12,ekleyen)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $eklendi = 0; $atlandi = 0;
        foreach ($xlsx->rows() as $ri => $row) {
            if ($ri === 0) continue;
            $stok_kodu = trim($row[0] ?? '');
            $stok_adi  = trim($row[1] ?? '');
            $tur       = trim($row[2] ?? '') ?: 'Mamül';
            if (!$stok_kodu) { $atlandi++; continue; }
            $aylar_v = [];
            for ($i = 3; $i <= 14; $i++)
                $aylar_v[] = (float)str_replace(['.',',' ],['' ,'.'], $row[$i] ?? 0);
            while (count($aylar_v) < 12) $aylar_v[] = 0;
            $stmt->execute(array_merge(
                [$firma, $stok_kodu, $stok_adi, $tur, $yil],
                array_slice($aylar_v, 0, 12),
                [$kul_adi]
            ));
            $eklendi++;
        }
        echo json_encode(['ok'=>true,'eklendi'=>$eklendi,'atlandi'=>$atlandi]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

echo json_encode(['ok'=>false,'msg'=>'Bilinmeyen işlem: '.$action]);
