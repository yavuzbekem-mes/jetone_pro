<?php
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

// Bu dosya: bolumler/planlama/ajax/norm_hat_ata.php
// 3 kez dirname ile proje root'una ulaşıyoruz (ajax -> planlama -> bolumler -> root)
$root = dirname(dirname(dirname(__DIR__)));

if (!file_exists($root . '/core/config.php')) {
    echo json_encode(['ok'=>false,'msg'=>'Root bulunamadı: '.$root,'dir'=>__DIR__]);
    exit;
}

require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['kullanici'])) {
    echo json_encode(['ok'=>false,'msg'=>'Oturum sona erdi.']);
    exit;
}

$action    = trim($_POST['action']    ?? '');
$stok_kodu = trim($_POST['stok_kodu'] ?? '');
$ist_kodu  = trim($_POST['ist_kodu']  ?? '');
$ist_turu  = trim($_POST['ist_turu']  ?? 'assembly');
$personel  = max(1, (int)($_POST['personel'] ?? 1));
$kul       = $_SESSION['kullanici'];
$guncelleyen = $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem';

if (!$stok_kodu) { echo json_encode(['ok'=>false,'msg'=>'Stok kodu boş.']); exit; }
if (!isset($db) || !$db) { echo json_encode(['ok'=>false,'msg'=>'DB bağlantısı yok.']); exit; }

try {
    if ($action === 'hat_ata') {
        if (!$ist_kodu) { echo json_encode(['ok'=>false,'msg'=>'İstasyon kodu boş.']); exit; }

        $chk = $db->prepare("SELECT COUNT(*) FROM norm_hat_atamalari WHERE stok_kodu=?");
        $chk->execute([$stok_kodu]);
        $varmi = (int)$chk->fetchColumn();

        if ($varmi > 0) {
            try {
                $db->prepare("UPDATE norm_hat_atamalari SET ist_kodu=?,ist_turu=?,personel=?,guncelleyen=?,guncelleme_tarihi=NOW() WHERE stok_kodu=?")
                   ->execute([$ist_kodu,$ist_turu,$personel,$guncelleyen,$stok_kodu]);
            } catch(Throwable $e1) {
                $db->prepare("UPDATE norm_hat_atamalari SET ist_kodu=?,ist_turu=?,personel=? WHERE stok_kodu=?")
                   ->execute([$ist_kodu,$ist_turu,$personel,$stok_kodu]);
            }
        } else {
            try {
                $db->prepare("INSERT INTO norm_hat_atamalari (stok_kodu,ist_kodu,ist_turu,personel,guncelleyen,guncelleme_tarihi) VALUES (?,?,?,?,?,NOW())")
                   ->execute([$stok_kodu,$ist_kodu,$ist_turu,$personel,$guncelleyen]);
            } catch(Throwable $e2) {
                $db->prepare("INSERT INTO norm_hat_atamalari (stok_kodu,ist_kodu,ist_turu,personel) VALUES (?,?,?,?)")
                   ->execute([$stok_kodu,$ist_kodu,$ist_turu,$personel]);
            }
        }
        echo json_encode(['ok'=>true,'msg'=>"$stok_kodu → $ist_kodu ({$personel}K) kaydedildi."]);

    } elseif ($action === 'hat_sil') {
        $db->prepare("DELETE FROM norm_hat_atamalari WHERE stok_kodu=?")->execute([$stok_kodu]);
        echo json_encode(['ok'=>true,'msg'=>"$stok_kodu ataması silindi."]);

    } else {
        echo json_encode(['ok'=>false,'msg'=>'Bilinmeyen action: '.$action]);
    }
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'msg'=>'Hata: '.$e->getMessage()]);
}
