<?php
header('Content-Type: application/json; charset=utf-8');
$d=json_decode(file_get_contents('php://input'),true);
$id=(int)($d['id']??0);
if(!$id){echo json_encode(['ok'=>false]);exit;}
try {
    $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
    echo json_encode(['ok'=>true]);
} catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
