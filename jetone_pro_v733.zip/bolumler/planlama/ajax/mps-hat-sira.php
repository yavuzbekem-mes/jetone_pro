<?php
header('Content-Type: application/json; charset=utf-8');
$hat = trim($_GET['hat'] ?? '');
if (!$hat) { echo json_encode(['siradaki_no'=>1,'onceki_isler',[]]); exit; }
try {
    $s = $db->prepare("SELECT id, hat_sira_no, urun_kodu, urun_adi,
        planlanan_miktar, kalan_miktar, kalan_vardiya, toplam_vardiya,
        kapasite_vardiya, uretim_emri_no, durum, notlar
        FROM mps_plan WHERE hat_kodu=? AND durum NOT IN ('Tamamlandı','İptal')
        ORDER BY hat_sira_no ASC");
    $s->execute([$hat]);
    $isler = $s->fetchAll(PDO::FETCH_ASSOC);
    $son_sira = 0; $toplam_kalan_v = 0;
    foreach ($isler as $i) {
        $son_sira = max($son_sira,(int)$i['hat_sira_no']);
        $toplam_kalan_v += (int)($i['kalan_vardiya'] ?? $i['toplam_vardiya'] ?? 0);
    }
    echo json_encode(['siradaki_no'=>$son_sira+1,'onceki_isler'=>$isler,'bekleme_vardiya'=>$toplam_kalan_v]);
} catch (Throwable $e) {
    echo json_encode(['siradaki_no'=>1,'onceki_isler'=>[],'hata'=>$e->getMessage()]);
}
