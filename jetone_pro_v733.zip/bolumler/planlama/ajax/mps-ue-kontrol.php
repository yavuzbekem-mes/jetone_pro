<?php
// panel.php üzerinden çağrılır: ?sayfa=ajax-ue-kontrol&mk=XXXXX
header('Content-Type: application/json; charset=utf-8');

$mk = trim($_GET['mk'] ?? '');
if (!$mk || !$tigerdb_pdo) {
    echo json_encode(['var' => false, 'hata' => 'Parametre veya Tiger bağlantısı yok']);
    exit;
}

try {
    $sql = "SELECT
        WS.CODE AS is_istasyonu,
        CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
        PRO.FICHENO AS emr_no,
        IT.CODE AS mamul_kod,
        CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
        CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
        CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT)) AS kalan
    FROM dbo.LG_222_PRODORD AS PRO
    LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON IT.LOGICALREF  = PRO.ITEMREF
    LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS ON DIS.PRODORDREF = PRO.LOGICALREF
    LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS  ON WS.LOGICALREF  = DIS.WSREF
    WHERE IT.CODE = ?
      AND YEAR(PRO.DATE_) = YEAR(GETDATE())
      AND MONTH(PRO.DATE_) = MONTH(GETDATE())
      AND PRO.STATUS IN (0,1)
    GROUP BY WS.CODE, PRO.FICHENO, IT.CODE, PRO.PLNAMOUNT, PRO.STATUS
    ORDER BY PRO.STATUS DESC";

    $s = $tigerdb_pdo->prepare($sql);
    $s->execute([$mk]);
    $rows = $s->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        $sql2 = "SELECT
            WS.CODE AS is_istasyonu,
            CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
            PRO.FICHENO AS emr_no,
            IT.CODE AS mamul_kod,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT)) AS kalan
        FROM dbo.LG_222_PRODORD AS PRO
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON IT.LOGICALREF  = PRO.ITEMREF
        LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS ON DIS.PRODORDREF = PRO.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS  ON WS.LOGICALREF  = DIS.WSREF
        WHERE IT.CODE = ? AND PRO.STATUS IN (0,1)
        GROUP BY WS.CODE, PRO.FICHENO, IT.CODE, PRO.PLNAMOUNT, PRO.STATUS
        ORDER BY PRO.STATUS DESC";
        $s2 = $tigerdb_pdo->prepare($sql2);
        $s2->execute([$mk]);
        $rows = $s2->fetchAll(PDO::FETCH_ASSOC);
    }

    if (empty($rows)) { echo json_encode(['var' => false]); exit; }

    $emirler = [];
    foreach ($rows as $r) {
        $emirler[] = [
            'emr_no'    => $r['emr_no'],
            'is_ist'    => $r['is_istasyonu'] ?? '',
            'durum'     => $r['durum'],
            'planlanan' => (int)$r['planlanan'],
            'uretilen'  => (int)$r['uretilen'],
            'kalan'     => max(0, (int)$r['kalan']),
        ];
    }
    echo json_encode(['var' => true, 'emirler' => $emirler]);

} catch (Throwable $e) {
    echo json_encode(['var' => false, 'hata' => $e->getMessage()]);
}
