<?php
ob_start();
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
if (session_status()===PHP_SESSION_NONE) session_start();
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false,'msg'=>'Oturum']); exit; }
if ($_SERVER['REQUEST_METHOD']!=='POST') { echo json_encode(['ok'=>false]); exit; }

$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';
$action  = $_POST['action'] ?? '';

if ($action === 'kaydet') {
    $sk    = trim($_POST['stok_kodu'] ?? '');
    $hat1  = trim($_POST['hat1']  ?? '');
    $oran1 = (float)($_POST['oran1'] ?? 50);
    $hat2  = trim($_POST['hat2']  ?? '');
    $oran2 = (float)($_POST['oran2'] ?? 50);

    if (!$sk || !$hat1 || !$hat2) { echo json_encode(['ok'=>false,'msg'=>'Eksik alan']); exit; }
    if ($hat1 === $hat2)           { echo json_encode(['ok'=>false,'msg'=>'Aynı hat seçilemez']); exit; }
    if (abs(($oran1+$oran2)-100) > 0.1) { echo json_encode(['ok'=>false,'msg'=>'Oranlar toplamı 100 olmalı ('.($oran1+$oran2).')']); exit; }

    try {
        $db->exec("CREATE TABLE IF NOT EXISTS hat_bolme (
            id INT AUTO_INCREMENT PRIMARY KEY, stok_kodu VARCHAR(100) NOT NULL,
            hat1_kodu VARCHAR(50) NOT NULL, hat1_oran DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            hat2_kodu VARCHAR(50) NOT NULL, hat2_oran DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            notlar VARCHAR(255) DEFAULT NULL, guncelleyen VARCHAR(100) DEFAULT NULL,
            guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_stok (stok_kodu)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

        $db->prepare("INSERT INTO hat_bolme (stok_kodu, hat1_kodu, hat1_oran, hat2_kodu, hat2_oran, guncelleyen)
            VALUES (?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE hat1_kodu=VALUES(hat1_kodu), hat1_oran=VALUES(hat1_oran),
            hat2_kodu=VALUES(hat2_kodu), hat2_oran=VALUES(hat2_oran), guncelleyen=VALUES(guncelleyen)")
            ->execute([$sk, $hat1, $oran1, $hat2, $oran2, $kul_adi]);
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

if ($action === 'sil') {
    $sk = trim($_POST['stok_kodu'] ?? '');
    if (!$sk) { echo json_encode(['ok'=>false]); exit; }
    try {
        $db->prepare("DELETE FROM hat_bolme WHERE stok_kodu=?")->execute([$sk]);
        echo json_encode(['ok'=>true]);
    } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
    exit;
}

echo json_encode(['ok'=>false,'msg'=>'Bilinmeyen işlem']);
