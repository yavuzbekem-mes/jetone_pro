<?php
ini_set('display_errors',0); error_reporting(0);
$root = dirname(dirname(dirname(__DIR__)));
require_once $root.'/core/config.php';
require_once $root.'/core/db.php';
require_once $root.'/core/auth.php';
require_once $root.'/core/baglanlogo.php';

if(!Auth::girisYapilmisMi()){
    die('<b>Oturum gerekli.</b>');
}

$emir_no = trim($_GET['yazdir']??'');
if(!$emir_no){ die('Geçerli bir emir numarası gönderilmedi.'); }

// TCPDF yolu bul
$tcpdf_paths = [
    $root.'/vendor/TCPDF/tcpdf.php',
    $root.'/uretim/TCPDF/tcpdf.php',
    $root.'/lib/tcpdf/tcpdf.php',
    $root.'/TCPDF/tcpdf.php',
];
$tcpdf_path = null;
foreach($tcpdf_paths as $p) if(file_exists($p)){ $tcpdf_path=$p; break; }

if(!$tcpdf_path){
    // TCPDF yoksa basit HTML çıktısı ver
    header('Content-Type: text/html; charset=utf-8');
    // Tiger'dan veri çek
    if(!$tigerdb_pdo){ die('Tiger DB bağlantısı yok.'); }
    try{
        $stmt = $tigerdb_pdo->prepare("SELECT TOP 1
            WS.CODE IS_ISTASYONU, PRO.FICHENO URETIM_NO,
            CONVERT(varchar,PRO.DATE_,104) URETIM_TARIHI,
            IT.CODE URUN_KODU, IT.NAME URUN_ADI, IT.NAME2 MUSTERI_ADI,
            CONVERT(decimal(18,0),PRO.PLNAMOUNT) PLANLANAN,
            CONVERT(decimal(18,0),PRO.ACTAMOUNT)  URETILEN,
            CONVERT(decimal(18,0),ISNULL((SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE IK WHERE PRO.FICHENO=IK.URETIM_EMRI_NO),0)) IKINCI_KALITE
        FROM dbo.LG_222_PRODORD PRO
        LEFT JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=PRO.ITEMREF
        LEFT JOIN dbo.LG_222_DISPLINE DIS ON DIS.PRODORDREF=PRO.LOGICALREF
        LEFT JOIN dbo.LG_222_WORKSTAT WS ON WS.LOGICALREF=DIS.WSREF
        WHERE PRO.FICHENO=?
        GROUP BY WS.CODE,PRO.FICHENO,PRO.DATE_,IT.CODE,IT.NAME,IT.NAME2,PRO.PLNAMOUNT,PRO.ACTAMOUNT,PRO.STATUS,IT.LOGICALREF,PRO.LOGICALREF");
        $stmt->execute([$emir_no]);
        $o = $stmt->fetch(PDO::FETCH_ASSOC);
        if(!$o){ die('Üretim emri bulunamadı: '.htmlspecialchars($emir_no)); }

        // Reçete
        $stmt2=$tigerdb_pdo->prepare("SELECT PL.LINENO_ SIRA, IT.CODE PARCA_KODU, IT.NAME PARCA_ADI,
            CONVERT(decimal(18,2),PL.AMOUNT) MIKTAR, ISNULL(UNI.CODE,'ADET') BIRIM
            FROM dbo.LG_222_POLINE PL
            LEFT JOIN dbo.LG_222_PRODORD PRO ON PL.PRODORDREF=PRO.LOGICALREF
            LEFT JOIN dbo.LG_222_ITEMS IT ON PL.ITEMREF=IT.LOGICALREF
            LEFT JOIN dbo.LG_222_UNITSETL UNI ON PL.UOMREF=UNI.LOGICALREF
            WHERE PRO.FICHENO=? ORDER BY PL.LINENO_");
        $stmt2->execute([$emir_no]);
        $recete=$stmt2->fetchAll(PDO::FETCH_ASSOC);

        // Malzeme
        $mlz=[];
        try{ $ms=$db->prepare("SELECT * FROM malzemeler WHERE malzeme_kod=?"); $ms->execute([$o['URUN_KODU']]); $mlz=$ms->fetch(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){}
    }catch(Throwable $e){ die('Sorgu hatası: '.htmlspecialchars($e->getMessage())); }
    
    $cevrim=$mlz['map_cevrim']??'';
    $gramaj=$mlz['map_gramaj']??'';
    $tonaj=$mlz['map_makina_tonaj']??'';
    $kalan = (float)$o['PLANLANAN'] - (float)$o['URETILEN'];
    $birinci_kalite = (float)$o['URETILEN'] - (float)$o['IKINCI_KALITE'];

    echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>İş Emri - '.htmlspecialchars($emir_no).'</title>
    <style>
    body{font-family:Arial,sans-serif;font-size:11px;margin:10px}
    table{width:100%;border-collapse:collapse;margin-bottom:8px}
    th,td{border:1px solid #000;padding:5px 8px}
    th{background:#E2E8F0;font-weight:700}
    .title{text-align:center;font-size:18px;font-weight:700;padding:10px}
    @media print{.no-print{display:none}}
    </style>
    </head><body>
    <div class="no-print" style="margin-bottom:10px">
      <button onclick="window.print()" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;cursor:pointer;font-size:13px">🖨 Yazdır</button>
      <button onclick="window.close()" style="background:#6B7280;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:13px;margin-left:8px">✕ Kapat</button>
    </div>
    <table><tr><td class="title" colspan="4">İŞ EMRİ FORMU</td></tr>
    <tr><th>İŞ EMRİ NO</th><td><b>'.htmlspecialchars($o['URETIM_NO']).'</b></td>
        <th>TARİH</th><td>'.htmlspecialchars($o['URETIM_TARIHI']).'</td></tr>
    <tr><th>ÜRÜN KODU</th><td colspan="3"><b>'.htmlspecialchars($o['URUN_KODU']).'</b></td></tr>
    <tr><th>ÜRÜN ADI</th><td colspan="3">'.htmlspecialchars($o['URUN_ADI']).'</td></tr>
    <tr><th>MAKİNA</th><td>'.htmlspecialchars($o['IS_ISTASYONU']).'</td>
        <th>PLANLANAN</th><td><b>'.number_format($o['PLANLANAN'],0,',','.').'</b></td></tr>
    <tr><th>ÇEVRİM</th><td>'.htmlspecialchars($cevrim).($cevrim?' sn':'').'</td>
        <th>GRAMAJ</th><td>'.htmlspecialchars($gramaj).($gramaj?' gr':'').'</td></tr>
    <tr><th>ÜRETİLEN</th><td>'.number_format($o['URETILEN'],0,',','.').'</td>
        <th>KALAN</th><td>'.number_format($kalan,0,',','.').'</td></tr>
    <tr><th>1.KALİTE</th><td>'.number_format($birinci_kalite,0,',','.').'</td>
        <th>2.KALİTE</th><td>'.number_format($o['IKINCI_KALITE'],0,',','.').'</td></tr>
    </table>';

    if(!empty($recete)){
        echo '<table><tr><th>SIRA</th><th>PARÇA KODU</th><th>PARÇA ADI</th><th>MİKTAR</th><th>BİRİM</th></tr>';
        foreach($recete as $r){
            echo '<tr><td>'.htmlspecialchars($r['SIRA']).'</td>
            <td><b>'.htmlspecialchars($r['PARCA_KODU']).'</b></td>
            <td>'.htmlspecialchars($r['PARCA_ADI']).'</td>
            <td style="text-align:right">'.number_format((float)$r['MIKTAR'],2,',','.').'</td>
            <td>'.htmlspecialchars($r['BIRIM']).'</td></tr>';
        }
        echo '</table>';
    }
    
    echo '<table style="margin-top:20px">
    <tr><td style="padding:30px;text-align:center"><b>ÜRETİM MONTAJ SORUMLUSU</b></td>
        <td style="padding:30px;text-align:center"><b>PROSES KONTROL</b></td></tr>
    <tr><td style="padding:30px;text-align:center"><b>ÜRETİM PLANLAMA MÜDÜRÜ</b></td>
        <td style="padding:30px;text-align:center"><b>FABRİKA MÜDÜRÜ</b></td></tr>
    </table>';
    echo '<p style="font-size:8px;text-align:center;color:#666;margin-top:15px">DÖKÜMAN NO: FR.20 | REVİZYON: 00</p>';
    echo '</body></html>';
    exit;
}

// TCPDF varsa kullan
while(ob_get_level()) ob_end_clean();
ob_start();
require_once($tcpdf_path);
// ... (TCPDF kodu buraya — şimdilik HTML fallback kullanılıyor)
