<?php
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_start(); error_reporting(0); ini_set('display_errors',0);
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$action   = trim($_POST['action']   ?? '');
$hat_kodu = trim($_POST['hat_kodu'] ?? '');
$norm     = max(1, (int)($_POST['norm_pers'] ?? 1));
$vardiya  = in_array((int)($_POST['vardiya']??1),[1,3]) ? (int)$_POST['vardiya'] : 1;
$kul      = $_SESSION['kullanici'];
$gun      = $kul['ad_soyad'] ?? $kul['email'] ?? 'sistem';

if (!$hat_kodu) { echo json_encode(['ok'=>false,'msg'=>'Hat kodu boş']); exit; }

try {
    // Tabloyu oluştur yoksa
    $db->exec("CREATE TABLE IF NOT EXISTS montaj_hat_personel (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        hat_kodu    VARCHAR(100) NOT NULL,
        norm_pers   TINYINT UNSIGNED NOT NULL DEFAULT 1,
        vardiya     TINYINT UNSIGNED NOT NULL DEFAULT 1,
        notlar      VARCHAR(255) DEFAULT NULL,
        guncelleyen VARCHAR(100) DEFAULT NULL,
        guncelleme  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_hat (hat_kodu)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

    if ($action === 'kaydet') {
        $db->prepare("INSERT INTO montaj_hat_personel (hat_kodu,norm_pers,vardiya,guncelleyen) VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE norm_pers=VALUES(norm_pers), vardiya=VALUES(vardiya), guncelleyen=VALUES(guncelleyen), guncelleme=NOW()")
           ->execute([$hat_kodu, $norm, $vardiya, $gun]);
        echo json_encode(['ok'=>true,'msg'=>"$hat_kodu: {$norm}K × {$vardiya} vardiya kaydedildi."]);
    } else {
        echo json_encode(['ok'=>false,'msg'=>'Bilinmeyen action']);
    }
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
