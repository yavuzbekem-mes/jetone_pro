<?php
ini_set('display_errors',0); error_reporting(0);
header('Content-Type: application/json; charset=utf-8');
$root = dirname(dirname(dirname(__DIR__)));
require_once $root.'/core/config.php';
require_once $root.'/core/db.php';
require_once $root.'/core/auth.php';
if(!Auth::girisYapilmisMi()){ echo json_encode(['ok'=>false,'hata'=>'Oturum sona erdi.']); exit; }

$id    = (int)($_POST['id']??0);
$kolon = trim($_POST['kolon']??'');
$deger = trim($_POST['deger']??'');

if(!$id){ echo json_encode(['ok'=>false,'hata'=>'ID boş.']); exit; }

if($kolon==='_sil'){
    try{
        $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]);
    }catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
    exit;
}

$izinli = ['hat_kodu','uretim_emri_no','urun_kodu','urun_adi','personel_sayisi','durum','notlar'];
if(!in_array($kolon,$izinli,true)){
    echo json_encode(['ok'=>false,'hata'=>'Gecersiz kolon: '.$kolon]);
    exit;
}

try{
    $db->prepare("UPDATE mps_plan SET `{$kolon}`=? WHERE id=?")->execute([$deger,$id]);
    echo json_encode(['ok'=>true]);
}catch(Throwable $e){
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
