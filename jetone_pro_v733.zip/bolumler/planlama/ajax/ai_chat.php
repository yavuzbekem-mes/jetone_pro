<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);

$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';

$tigerdb_pdo = null;
$mes_pdo     = null;
try { require_once $root . '/core/baglanlogo.php'; } catch(Throwable $e) {}

ob_clean();
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['kullanici'])) { echo json_encode(['ok'=>false,'msg'=>'Oturum sona erdi.']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['ok'=>false,'msg'=>'POST gerekli.']); exit; }

$soru    = trim($_POST['soru']    ?? '');
$gecmis  = json_decode($_POST['gecmis'] ?? '[]', true) ?: [];
$sql_run = json_decode($_POST['sql_run'] ?? 'null', true);

if (!$soru) { echo json_encode(['ok'=>false,'msg'=>'Soru boş.']); exit; }

// ── GROQ API KEY ─────────────────────────────────────────────────
$api_key    = '';
$groq_model = 'llama-3.3-70b-versatile';
try {
    $rows = $db->query("SELECT anahtar, deger FROM sistem_ayarlari WHERE anahtar IN ('groq_api_key','groq_model')")->fetchAll(PDO::FETCH_KEY_PAIR);
    $api_key    = trim($rows['groq_api_key'] ?? '');
    $groq_model = trim($rows['groq_model']   ?? 'llama-3.3-70b-versatile');
} catch(Throwable $e) {}
if (empty($api_key)) {
    echo json_encode(['ok'=>false,'msg'=>'Groq API anahtarı yok. panel.php?sayfa=ayarlar-ai adresinden ekleyin.']);
    exit;
}

// ── GÜVENLİ SQL ÇALIŞTIRICI ──────────────────────────────────────
function guvenli_sql_calistir($sql, $params, $db, $tigerdb_pdo, $mes_pdo, $veritabani = 'mysql') {
    $sql_temiz = trim($sql);

    // SADECE SELECT izni
    $ilk_kelime = strtoupper(strtok($sql_temiz, " \t\n\r"));
    if ($ilk_kelime !== 'SELECT') {
        return ['hata' => '⛔ Güvenlik: Yalnızca SELECT sorguları çalıştırılabilir. INSERT/UPDATE/DELETE/DROP yasak.'];
    }

    // Tehlikeli komutları kontrol et
    $yasakli = ['INSERT','UPDATE','DELETE','DROP','TRUNCATE','ALTER','CREATE','EXEC','EXECUTE','xp_','sp_','DECLARE','CAST(','CONVERT('];
    $sql_upper = strtoupper($sql_temiz);
    foreach ($yasakli as $y) {
        // SELECT içinde geçse bile (örn: UPDATE sorgusunun adı) yakalamak için
        // sadece bağımsız kelime olarak ara
        if (preg_match('/\b' . preg_quote($y, '/') . '\b/i', $sql_temiz)) {
            // SELECT içinde CONVERT/CAST kullanımı Tiger için gerekli — sadece başta olan zararlıları engelle
            if (in_array($y, ['CONVERT(','CAST('])) continue;
            if (!in_array($ilk_kelime, ['SELECT'])) {
                return ['hata' => "⛔ Güvenlik: '$y' komutu yasak."];
            }
        }
    }

    try {
        $pdo = match(strtolower($veritabani)) {
            'tiger' => $tigerdb_pdo,
            'mes'   => $mes_pdo,
            default => $db,
        };
        if (!$pdo) return ['hata' => "$veritabani veritabanı bağlantısı yok."];

        $stmt = $pdo->prepare($sql_temiz);
        $stmt->execute($params ?: []);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return ['rows' => $rows, 'sayi' => count($rows)];
    } catch(Throwable $e) {
        return ['hata' => $e->getMessage()];
    }
}

// ── TUR 2: sql_run geldiyse ÖNCE sorguları çalıştır, sonra Groq'a gönder ─
$sorgu_sonuclari_metni = '';
if ($sql_run && is_array($sql_run)) {
    $parcalar = [];
    foreach ($sql_run as $s) {
        $sonuc = guvenli_sql_calistir(
            $s['sql']    ?? '',
            $s['params'] ?? [],
            $db, $tigerdb_pdo, $mes_pdo,
            $s['db']     ?? 'mysql'
        );
        $aciklama = $s['aciklama'] ?? 'Sorgu';

        if (isset($sonuc['hata'])) {
            $parcalar[] = "[$aciklama] HATA: {$sonuc['hata']}";
        } elseif (empty($sonuc['rows'])) {
            $parcalar[] = "[$aciklama] Sonuç bulunamadı (0 kayıt).";
        } else {
            $rows   = $sonuc['rows'];
            $header = implode(' | ', array_keys($rows[0]));
            $data   = [];
            foreach (array_slice($rows, 0, 100) as $r) {
                $data[] = implode(' | ', array_map(fn($v) => $v ?? '0', array_values($r)));
            }
            $parcalar[] = "[$aciklama] ({$sonuc['sayi']} kayıt):\n$header\n" . implode("\n", $data);
        }
    }
    $sorgu_sonuclari_metni = "\n\n=== SORGU SONUÇLARI ===\n" . implode("\n\n", $parcalar) . "\n=== SONUÇ SONU ===";
}

// ── TEMEL CONTEXT ────────────────────────────────────────────────
$ctx = [];
$kul = $_SESSION['kullanici'];
$ctx[] = "Kullanıcı: " . ($kul['ad_soyad'] ?? $kul['email'] ?? '?');
$ctx[] = "Tarih: " . date('d.m.Y H:i') . " " . ['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'][date('w')];

try {
    $r = $db->query("SELECT
        (SELECT COUNT(*) FROM siparis WHERE sip_statu='Aktif') sip,
        (SELECT COUNT(*) FROM mps_plan WHERE durum='Devam Ediyor') urt,
        (SELECT COUNT(*) FROM devam_kayitlari WHERE tarih=CURDATE()) devam,
        (SELECT COUNT(*) FROM personeller WHERE durum='aktif') per")->fetch(PDO::FETCH_ASSOC);
    if ($r) $ctx[] = "ÖZET: Aktif sipariş={$r['sip']}, Devam eden üretim={$r['urt']}, Bugün gelen={$r['devam']}, Aktif personel={$r['per']}";
} catch(Throwable $e) {}

$temel_ctx = implode("\n", $ctx);

// ── VERİTABANI ŞEMASI ────────────────────────────────────────────
$schema = <<<'SCHEMA'
MySQL (jetone_pro):
- personeller: id, ad, soyad, sicil_no, departman_id, durum(aktif/pasif/izinli)
- departmanlar: id, ad
- devam_kayitlari: id, personel_id, tarih(DATE), giris_saati(TIME), cikis_saati(TIME), calisma_suresi, durum(geldi/gelmedi/izinli/gecikti)
- izinler: id, personel_id, baslangic_tarihi, bitis_tarihi, izin_turu, durum(onaylandi/bekliyor)
- siparis: id, sip_no, sip_kodu, sip_baslik, musteri_firma_adi, sip_miktar, sip_sevk_miktari, sip_statu(Aktif/Tamamlandi), sip_teslim_tarihi
- mps_plan: id, hat_kodu, urun_kodu, urun_adi, uretim_emri_no, planlanan_miktar, kalan_miktar, personel_sayisi, durum, hat_sira_no

Tiger SQL Server (tigerdb_pdo) — db:"tiger":
- LG_222_ITEMS: LOGICALREF, CODE, NAME, STGRPCODE, ACTIVE(0=aktif), CARDTYPE, CANCONFIGURE
- LV_222_02_STINVTOT: STOCKREF, ONHAND, INVENNO(ambar:0=Merkez,1=Uretim,5=BSH,2=Karantina,3=Kirma,4=Emanet,98=TakimBoz)
- L_CAPIWHOUSE: NR(ambar no), NAME(ambar adi), FIRMNR(222)
- LG_222_CLCARD: LOGICALREF, DEFINITION_(firma adi), CODE
- LG_222_02_ORFICHE: LOGICALREF, DATE_, CLIENTREF
- LG_222_02_ORFLINE: LOGICALREF, ORDFICHEREF, STOCKREF, AMOUNT, SHIPPEDAMOUNT, DUEDATE, TRCODE(2=satinalma)

STOK SORGU KALIBI (daima kullan):
SELECT TOP 50 IT.CODE,IT.NAME,IT.STGRPCODE,
  ISNULL([Merkez],0)+ISNULL([Uretim],0)+ISNULL([BSH],0) Toplam,
  ISNULL([Merkez],0) Merkez, ISNULL([Uretim],0) Uretim, ISNULL([BSH],0) BSH
FROM (
  SELECT IT.CODE,IT.NAME,IT.STGRPCODE,CAP.NAME AMBAR,SUM(LV.ONHAND) MIK
  FROM dbo.LG_222_ITEMS IT
  LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
  LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO
  WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
    AND CAP.FIRMNR=222 AND LV.INVENNO IN(0,1,5) AND IT.ACTIVE=0
    AND (__KOSUL__)
  GROUP BY IT.CODE,IT.NAME,IT.STGRPCODE,CAP.NR,CAP.NAME
) src
PIVOT(SUM(MIK) FOR AMBAR IN([Merkez],[Uretim],[BSH])) piv
ORDER BY Toplam DESC

ARAMA KURALI: "OEM tekmelik" için:
  (IT.NAME LIKE '%OEM%' OR IT.CODE LIKE '%OEM%') AND (IT.NAME LIKE '%TEKMEL%' OR IT.CODE LIKE '%TEKMEL%')

SATINALMA GECİKME:
SELECT IT.CODE,IT.NAME,CL.DEFINITION_ firma,OL.AMOUNT-OL.SHIPPEDAMOUNT kalan,
  CONVERT(date,OL.DUEDATE) termin, DATEDIFF(DAY,OL.DUEDATE,GETDATE()) gecikme_gun
FROM dbo.LG_222_02_ORFLINE OL
LEFT JOIN dbo.LG_222_02_ORFICHE ORF ON OL.ORDFICHEREF=ORF.LOGICALREF
LEFT JOIN dbo.LG_222_ITEMS IT ON OL.STOCKREF=IT.LOGICALREF
LEFT JOIN dbo.LG_222_CLCARD CL ON ORF.CLIENTREF=CL.LOGICALREF
WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT<OL.AMOUNT AND OL.DUEDATE<GETDATE()
ORDER BY OL.DUEDATE ASC
SCHEMA;

// ── MESAJLAR ─────────────────────────────────────────────────────
$msgs = [];
foreach (array_slice($gecmis, -8) as $g)
    if (!empty($g['role']) && !empty($g['content']))
        $msgs[] = ['role'=>$g['role'],'content'=>$g['content']];

// Tur 2'de sorgu sonuçlarını kullanıcı mesajı olarak ekle
if ($sorgu_sonuclari_metni) {
    $msgs[] = ['role'=>'user','content'=>$soru . $sorgu_sonuclari_metni . "\n\nYukarıdaki sonuçları Türkçe yorumla, tablo halinde göster."];
} else {
    $msgs[] = ['role'=>'user','content'=>$soru];
}

// ── SYSTEM PROMPT ─────────────────────────────────────────────────
$sayfa_listesi = "dashboard,ik-personeller,ik-devam,ik-devam-ozet,ik-izinler,ik-bordro,
satis-dashboard,satis-siparisler,satis-irsaliye,
satinalma-dashboard,satinalma-mrp,satinalma-acik-sip,
uretim-is-emirleri,planlama-dashboard,planlama-gunluk,planlama-gunluk-montaj,
planlama-mps,planlama-norm-personel,kalite-kontrol,
depo-sevkiyat-dashboard,depo-stok,depo-paketler,
raporlar-genel,ayarlar-ai,ai-chat";

$tur_bilgisi = $sorgu_sonuclari_metni
    ? "BU TUR 2'DIR: Sorgu sonuçları sana verildi. SADECE normal Türkçe cevap ver, kesinlikle JSON veya action döndürme."
    : "BU TUR 1'DIR: Veri gerekiyorsa JSON action döndür.";

$system = <<<PROMPT
Sen Jetone ERP'nin Türkçe AI asistanısın. Üretim, sipariş, stok, satınalma, personel uzmansın.

$tur_bilgisi

GÜNCEL VERİLER:
$temel_ctx

VERİTABANI ŞEMASI:
$schema

KURALLAR:
1. SADECE SELECT sorguları üret — INSERT/UPDATE/DELETE/DROP kesinlikle yasak
2. Tür 1: Veri lazımsa JSON action döndür (BAŞKA HİÇBİR METIN YAZMA):
   {"action":"query","sorgular":[{"aciklama":"açıklama","db":"tiger","sql":"SELECT...","params":[]}],"msg":"kısa mesaj"}
3. Tür 2: Sonuçları Türkçe yorumla, tablo kullan, JSON döndürme
4. Sayfa yönlendirme: {"action":"navigate","sayfa":"SAYFA_ID","msg":"açıklama"}
5. Parametre sor: {"action":"ask","soru":"soru?","ipucu":"örnek"}
6. Geçerli sayfalar: $sayfa_listesi
PROMPT;

// ── GROQ API ─────────────────────────────────────────────────────
$groq_msgs = array_merge(
    [['role'=>'system','content'=>$system]],
    $msgs
);

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_POSTFIELDS     => json_encode([
        'model'       => $groq_model,
        'max_tokens'  => 2048,
        'temperature' => 0.1,
        'messages'    => $groq_msgs,
    ]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key,
    ],
    CURLOPT_SSL_VERIFYPEER => false,
]);

$raw  = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($err) { echo json_encode(['ok'=>false,'msg'=>'CURL: '.$err]); exit; }
$resp = json_decode($raw, true);
if ($code !== 200) {
    echo json_encode(['ok'=>false,'msg'=>"Groq ($code): ".($resp['error']['message']??substr($raw,0,300))]);
    exit;
}

$cevap = trim($resp['choices'][0]['message']['content'] ?? '');

// ── JSON ACTION PARSE ─────────────────────────────────────────────
// Tur 2'de parse etme — zaten normal cevap bekliyoruz
$action=$navigate_id=$ask_soru=$ask_ipucu=$query_list=null;
$final_msg = $cevap;

if (!$sql_run) { // sadece Tur 1'de action parse et
    $clean = preg_replace('/```json\s*/i','', $cevap);
    $clean = preg_replace('/```\s*/','', $clean);
    $clean = trim($clean);

    // 3 yöntemle JSON bul
    $jp = null;
    $try1 = json_decode($clean, true);
    if ($try1 && isset($try1['action'])) $jp = $try1;

    if (!$jp) {
        $bs = strpos($clean,'{'); $be = strrpos($clean,'}');
        if ($bs!==false && $be!==false && $be>$bs) {
            $try2 = json_decode(substr($clean,$bs,$be-$bs+1), true);
            if ($try2 && isset($try2['action'])) $jp = $try2;
        }
    }
    if (!$jp && preg_match('/\{[\s\S]*?"action"[\s\S]*?\}/s',$clean,$mx)) {
        $try3 = json_decode($mx[0], true);
        if ($try3 && isset($try3['action'])) $jp = $try3;
    }

    if ($jp) {
        $action    = $jp['action'];
        $final_msg = $jp['msg'] ?? $cevap;
        if ($action==='navigate') $navigate_id = $jp['sayfa']     ?? null;
        if ($action==='ask')      { $ask_soru=$jp['soru']??null; $ask_ipucu=$jp['ipucu']??null; }
        if ($action==='query')    $query_list  = $jp['sorgular']  ?? null;
    }
}

echo json_encode([
    'ok'        => true,
    'cevap'     => $final_msg,
    'action'    => $action,
    'navigate'  => $navigate_id,
    'ask'       => $ask_soru,
    'ask_ipucu' => $ask_ipucu,
    'sql_run'   => $query_list,
    'debug_ctx' => mb_strlen($system).' karakter, tur='.($sql_run?'2':'1'),
]);
