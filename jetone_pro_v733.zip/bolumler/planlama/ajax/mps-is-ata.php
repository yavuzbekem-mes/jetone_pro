<?php
header('Content-Type: application/json; charset=utf-8');
$d = json_decode(file_get_contents('php://input'), true);
if (!$d) { echo json_encode(['ok'=>false,'hata'=>'Veri yok']); exit; }
$hat=$d['hat_kodu']??''; $mk=$d['urun_kodu']??''; $miktar=(int)($d['planlanan_miktar']??0);
$kapasite=max(1,(int)($d['kapasite_vardiya']??1)); $cycle_sn=floatval($d['cycle_sn']??0);
$parti=max(1,(int)($d['parti']??1)); $adi=$d['urun_adi']??'';
$ue_no=$d['uretim_emri_no']??''; $notlar=$d['notlar']??'';
if (!$hat||!$mk||$miktar<1) { echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }
try {
    $s=$db->prepare("SELECT COALESCE(MAX(hat_sira_no),0)+1 AS sira FROM mps_plan WHERE hat_kodu=? AND durum NOT IN ('Tamamlandı','İptal')");
    $s->execute([$hat]); $sira_no=(int)$s->fetchColumn();
    $toplam_v=max(1,(int)ceil($miktar/$kapasite));
    $db->prepare("INSERT INTO mps_plan (hat_kodu,urun_kodu,urun_adi,uretim_emri_no,planlanan_miktar,kalan_miktar,kapasite_vardiya,cycle_sn,parti,toplam_vardiya,kalan_vardiya,hat_sira_no,baslangic_tarih,bitis_tarih,baslangic_vardiya,toplam_gun,notlar,olusturan) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,CURDATE(),CURDATE(),'S',?,?,?)")
    ->execute([$hat,$mk,$adi,$ue_no?:null,$miktar,$miktar,$kapasite,$cycle_sn,$parti,$toplam_v,$toplam_v,$sira_no,(int)ceil($toplam_v/3),$notlar,$_SESSION['kullanici_id']??0]);
    echo json_encode(['ok'=>true,'id'=>$db->lastInsertId(),'sira'=>$sira_no]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
