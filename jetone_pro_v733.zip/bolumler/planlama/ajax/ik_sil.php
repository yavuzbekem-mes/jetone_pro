<?php
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

$root = dirname(dirname(dirname(__DIR__)));
require_once $root.'/core/config.php';
require_once $root.'/core/db.php';
require_once $root.'/core/auth.php';
require_once $root.'/core/baglanlogo.php';

Auth::zorunlu();

$delete_id = (int)($_POST['delete_id'] ?? 0);

if (!$delete_id) {
    echo json_encode(['ok'=>false,'msg'=>'Geçersiz ID.']);
    exit;
}

if (!isset($tigerdb_pdo) || !$tigerdb_pdo) {
    echo json_encode(['ok'=>false,'msg'=>'Tiger/MES DB bağlantısı kurulamadı.']);
    exit;
}

try {
    $chk = $tigerdb_pdo->prepare("SELECT ID FROM MES.dbo.IKINCI_KALITE WHERE ID=?");
    $chk->execute([$delete_id]);
    if (!$chk->fetch()) {
        echo json_encode(['ok'=>false,'msg'=>"ID=$delete_id bulunamadı."]);
        exit;
    }
    $tigerdb_pdo->prepare("DELETE FROM MES.dbo.IKINCI_KALITE WHERE ID=?")->execute([$delete_id]);
    echo json_encode(['ok'=>true,'msg'=>"ID=$delete_id silindi.",'deleted_id'=>$delete_id]);
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'msg'=>'Hata: '.$e->getMessage()]);
}
