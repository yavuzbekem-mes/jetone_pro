<?php
ob_start();
// POST işlemleri
if (!empty($_POST['gp_action'])) {
    ob_end_clean(); // Önceki tüm output'u temizle
    error_reporting(0); // PHP uyarılarını JSON'a karıştırma
    ini_set('display_errors', 0);
    require_once dirname(dirname(__DIR__)) . '/core/config.php';
    require_once dirname(dirname(__DIR__)) . '/core/db.php';
    require_once dirname(dirname(__DIR__)) . '/core/auth.php';
    require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['gp_action'];
    $id = (int)($_POST['id']??0);

    if ($action === 'sil' && $id) {
        try {
            $db->prepare("UPDATE mps_plan SET durum='İptal' WHERE id=?")->execute([$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'duzenle' && $id) {
        $miktar = (int)($_POST['planlanan_miktar']??0);
        $kap    = max(1,(int)($_POST['kapasite_vardiya']??1));
        $not_   = trim($_POST['notlar']??'');
        $ue     = trim($_POST['uretim_emri_no']??'');
        $pers   = max(1,(int)($_POST['personel_sayisi']??1));
        $tv     = max(1,(int)ceil($miktar/$kap));
        try {
            $db->prepare("UPDATE mps_plan SET planlanan_miktar=?, kalan_miktar=?, kapasite_vardiya=?,
                toplam_vardiya=?, kalan_vardiya=?, uretim_emri_no=?, notlar=?, personel_sayisi=?, guncelleme=NOW()
                WHERE id=?")
               ->execute([$miktar,$miktar,$kap,$tv,$tv,$ue?:null,$not_,$pers,$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'detay' && $id) {
        try {
            $r = $db->prepare("SELECT * FROM mps_plan WHERE id=?");
            $r->execute([$id]);
            $row = $r->fetch(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'data'=>$row]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Anlık Tiger'dan kalan güncelle
    if ($action === 'tiger_sync') {
        try {
            require_once dirname(dirname(__DIR__)) . '/core/config.php';
            require_once dirname(dirname(__DIR__)) . '/core/db.php';
            require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';

            // mps_plan'daki aktif işlerin ÜE no'larını çek
            $aktif = $db->query("SELECT id, urun_kodu, uretim_emri_no, planlanan_miktar, kapasite_vardiya
                FROM mps_plan WHERE durum NOT IN('Tamamlandı','İptal') AND uretim_emri_no IS NOT NULL AND uretim_emri_no != ''"
            )->fetchAll(PDO::FETCH_ASSOC);

            $guncellenen = 0;
            foreach($aktif as $row) {
                try {
                    $stmt = $tigerdb_pdo->prepare("SELECT
                        PRO.PLNAMOUNT AS planlanan,
                        ISNULL(SUM(PRO.ACTAMOUNT),0) AS uretilen
                        FROM dbo.LG_222_PRODORD PRO
                        WHERE PRO.FICHENO=?
                        GROUP BY PRO.PLNAMOUNT");
                    $stmt->execute([$row['uretim_emri_no']]);
                    $tiger = $stmt->fetch(PDO::FETCH_ASSOC);
                    if($tiger) {
                        $kalan = max(0, (int)$tiger['planlanan'] - (int)$tiger['uretilen']);
                        $kap   = max(1,(int)$row['kapasite_vardiya']);
                        $tv    = max(0,(int)ceil($kalan/$kap));
                        $durum = $kalan<=0 ? 'Tamamlandı' : 'Devam Ediyor';
                        $db->prepare("UPDATE mps_plan SET kalan_miktar=?, kalan_vardiya=?, durum=?, guncelleme=NOW() WHERE id=?")
                           ->execute([$kalan,$tv,$durum,$row['id']]);
                        $guncellenen++;
                    }
                } catch(Throwable $e2){}
            }
            echo json_encode(['ok'=>true,'guncellenen'=>$guncellenen]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Mail gönder
    if ($action === 'mail_gonder') {
        try {
            // Satınalma ile aynı SMTP yapısı
            $smtp_ent = null;
            try {
                $smtp_ent = $db->query(
                    "SELECT host, port, kullanici, sifre, ek_parametreler
                     FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1"
                )->fetch(PDO::FETCH_ASSOC);
            } catch(Throwable $e2){}

            if (!$smtp_ent) {
                echo json_encode(['ok'=>false,'hata'=>'SMTP entegrasyonu tanımlanmamış veya aktif değil.']);
                exit;
            }

            // Şifreyi AES decrypt et (satınalma ile aynı yöntem)
            $key = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
            $sifre = '';
            if (!empty($smtp_ent['sifre'])) {
                $enc_raw = trim($smtp_ent['sifre']);
                $dec1 = @openssl_decrypt($enc_raw, 'AES-256-CBC', $key, 0, '1234567890123456');
                $dec2 = @openssl_decrypt($enc_raw, 'AES-256-CBC', 'jetone2024secretkey!!', 0, '1234567890123456');
                if ($dec1 !== false && strlen($dec1) > 0 && ctype_print($dec1)) {
                    $sifre = $dec1;
                } elseif ($dec2 !== false && strlen($dec2) > 0 && ctype_print($dec2)) {
                    $sifre = $dec2;
                } else {
                    $b64 = @base64_decode($enc_raw, true);
                    $sifre = ($b64 && ctype_print($b64)) ? $b64 : $enc_raw;
                }
            }

            $ekPar  = json_decode($smtp_ent['ek_parametreler'] ?? '{}', true) ?: [];
            $host   = $smtp_ent['host'] ?: 'localhost';
            $port   = (int)($smtp_ent['port'] ?: 587);
            $user   = $smtp_ent['kullanici'] ?? '';
            $enc    = $ekPar['smtp_secure'] ?? ($port == 465 ? 'ssl' : 'tls');
            $fromAd = $ekPar['smtp_from_name'] ?? 'Jetone ERP';

            // Tüm aktif kullanıcıların emaillerini çek (beyaz yaka = tüm kullanıcılar)
            // Beyaz yaka personellerin emaillerini al
            $email_set = [];
            try {
                $beyazlar = $db->query(
                    "SELECT ad, soyad, email FROM personeller
                     WHERE durum='aktif' AND kadro='beyaz_yaka'
                       AND email IS NOT NULL AND email != '' AND email LIKE '%@%'"
                )->fetchAll(PDO::FETCH_ASSOC);
                foreach($beyazlar as $u) {
                    $mail = trim(strtolower($u['email']));
                    if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                        $email_set[$mail] = trim($u['ad'].' '.$u['soyad']);
                    }
                }
            } catch(Throwable $e4){}

            // Manuel adres(ler) varsa ekle - virgülle ayrılmış olabilir
            $ekstra_mail = trim($_POST['ekstra_mail'] ?? '');
            if($ekstra_mail) {
                foreach(explode(',', $ekstra_mail) as $em) {
                    $em = trim($em);
                    if(filter_var($em, FILTER_VALIDATE_EMAIL)) {
                        $email_set[$em] = 'Manuel';
                    }
                }
            }

            if(empty($email_set)) {
                echo json_encode(['ok'=>false,'hata'=>'bos','mesaj'=>'Beyaz yaka personel email adresi bulunamadı. Lütfen göndermek istediğiniz adresi girin.']);
                exit;
            }

            $tarih = date('d.m.Y');
            $konu  = "Günlük Enjeksiyon Planı - $tarih";

            // HTML mail içeriği
            $html = '<!DOCTYPE html><html><head><meta charset="utf-8">
            <style>
            body{font-family:Arial,sans-serif;font-size:12px;color:#1E293B}
            h2{color:#2d5986;margin:0 0 10px 0}
            .ozet{display:flex;gap:10px;margin-bottom:15px}
            .ozet-kart{flex:1;border-radius:8px;padding:10px;text-align:center}
            table{border-collapse:collapse;width:100%;font-size:11px}
            th{background:#2d5986;color:#fff;padding:5px 8px;border:1px solid #3b6fa3}
            td{padding:4px 7px;border:1px solid #E2E8F0;vertical-align:middle}
            tr:nth-child(even) td{background:#F8FAFC}
            .devam{background:#DBEAFE;color:#1E40AF;padding:2px 6px;border-radius:4px;font-weight:700;font-size:10px}
            .degis{background:#D1FAE5;color:#065F46;padding:2px 6px;border-radius:4px;font-weight:700;font-size:10px}
            .siradaki{background:#FEF9C3;color:#92400E;padding:2px 6px;border-radius:4px;font-weight:700;font-size:10px}
            </style></head><body>';
            $html .= "<h2>📋 Günlük Enjeksiyon Planı — $tarih</h2>";

            // Özet bilgiler
            $ozet_json = json_decode($_POST['ozet_json'] ?? '{}', true);
            $html .= '<table style="width:auto;margin-bottom:15px">';
            $html .= '<tr><th>Vardiya</th><th>👤 Personel</th><th>🏭 Hat</th><th>🔄 Değişim</th></tr>';
            foreach(['S'=>'08:00-16:00','O'=>'16:00-24:00','G'=>'00:00-08:00'] as $vk=>$vl) {
                $o = $ozet_json[$vk] ?? ['personel'=>0,'hat'=>0,'degisim'=>0];
                $html .= "<tr><td><b>$vl</b></td><td style='text-align:center'>{$o['personel']}</td><td style='text-align:center'>{$o['hat']}</td><td style='text-align:center'>{$o['degisim']}</td></tr>";
            }
            $html .= '</table>';

            // Plan tablosu
            $plan_html = $_POST['plan_html'] ?? '';
            $html .= $plan_html;
            $html .= '<p style="color:#64748B;font-size:10px;margin-top:15px">Bu mail otomatik gönderilmiştir — '.date('d.m.Y H:i').'</p>';
            $html .= '</body></html>';

            // SMTP gönder
            require_once dirname(__DIR__) . '/idari/ajax/satin-smtp-send.php';
            $email_list = array_keys($email_set);
            $result = satinSmtpSend(
                $host, $port, $enc, $user, $sifre, $fromAd,
                $email_list, $konu, $html
            );
            if($result['ok']) {
                $alici_ozet = array_map(function($m) use($email_set){ return $email_set[$m].' <'.$m.'>'; }, $email_list);
                echo json_encode(['ok'=>true,'sayi'=>count($email_list),'alicilar'=>$alici_ozet]);
            } else {
                echo json_encode(['ok'=>false,'hata'=>$result['hata']??'SMTP hatası']);
            }
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen eylem']); exit;
}



require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$bugun   = date('Y-m-d');
$saat    = (int)date('H');
$dakika  = (int)date('i');

// Montaj hatları = EN- ile BAŞLAMAYAN iş istasyonları
// Önce Tiger'dan mevcut istasyonları çek
$montaj_renkleri_base = [
    '#FEE2E2','#DBEAFE','#D1FAE5','#FEF3C7','#EDE9FE','#CFFAFE',
    '#FCE7F3','#E0F2FE','#ECFDF5','#FEF9C3','#FFEDD5','#F1F5F9',
    '#F3E8FF','#E0F7FA','#FFF3CD','#FEF08A','#FED7AA','#C7D2FE',
    '#CCFBF1','#FFE4E6','#BFDBFE','#FDE68A','#BBF7D0','#FECACA',
];

// Tiger'dan EN- olmayan aktif istasyonları çek
$montaj_hatlar = [];
$montaj_renkleri = [];
if ($tigerdb_pdo) {
    try {
        $ist_rows = $tigerdb_pdo->query(
            "SELECT DISTINCT WS.CODE FROM dbo.LG_222_WORKSTAT WS
             INNER JOIN dbo.LG_222_DISPLINE DIS ON DIS.WSREF=WS.LOGICALREF
             INNER JOIN dbo.LG_222_PRODORD PRO ON PRO.LOGICALREF=DIS.PRODORDREF
             WHERE WS.CODE NOT LIKE 'EN-%' AND WS.CODE IS NOT NULL AND WS.CODE<>''
               AND PRO.STATUS IN(0,1)
             ORDER BY WS.CODE"
        )->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ist_rows as $i => $hat) {
            $montaj_hatlar[] = $hat;
            $montaj_renkleri[$hat] = $montaj_renkleri_base[$i % count($montaj_renkleri_base)];
        }
    } catch(Throwable $e) {}
}

// Fallback: mps_plan'dan EN- olmayan hatları çek
if (empty($montaj_hatlar)) {
    try {
        $rows = $db->query(
            "SELECT DISTINCT hat_kodu FROM mps_plan
             WHERE hat_kodu NOT LIKE 'EN-%' AND durum NOT IN('Tamamlandı','İptal')
             ORDER BY hat_kodu"
        )->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $i => $hat) {
            $montaj_hatlar[] = $hat;
            $montaj_renkleri[$hat] = $montaj_renkleri_base[$i % count($montaj_renkleri_base)];
        }
    } catch(Throwable $e) {}
}

$hat_sirasi = $montaj_hatlar;
$vrd_etiket = ['S'=>'08-16','O'=>'16-24','G'=>'00-08'];

if($saat>=8&&$saat<16){$aktif_vrd='S';$kalan_dk=(16-$saat)*60-$dakika;}
elseif($saat>=16&&$saat<24){$aktif_vrd='O';$kalan_dk=(24-$saat)*60-$dakika;}
else{$aktif_vrd='G';$kalan_dk=(8-$saat)*60-$dakika;if($kalan_dk<0)$kalan_dk+=480;}

// Planlanmış işler - montaj hatları
$hat_planlar=[];
if (!empty($hat_sirasi)) {
    try {
        $ph = implode(',', array_fill(0, count($hat_sirasi), '?'));
        $rows=$db->prepare(
            "SELECT *,COALESCE(personel_sayisi,1) AS personel_sayisi
             FROM mps_plan WHERE durum NOT IN('Tamamlandı','İptal')
               AND hat_kodu IN($ph)
             ORDER BY hat_kodu,hat_sira_no"
        );
        $rows->execute($hat_sirasi);
        foreach($rows->fetchAll(PDO::FETCH_ASSOC) as $r) $hat_planlar[$r['hat_kodu']][]=$r;
    }catch(Throwable $e){}
}

// Vardiya hesabı - MONTAJ: aynı vardiyaya birden fazla iş sığabilir
// Her hat için vardiya bazında kalan kapasite havuzu tutarız
$gunluk=[];
$vrd_sirasi=['S','O','G'];

foreach($hat_planlar as $hk=>$isler){
    // Her vardiyanın kalan kapasitesi (dakika cinsinden 480 = tam vardiya)
    // Aktif vardiya kalan_dk kadar dolu
    $vrd_kalan_dk = [];
    foreach($vrd_sirasi as $vi=>$vk){
        if($vk===$aktif_vrd) $vrd_kalan_dk[$vk]=$kalan_dk;
        else $vrd_kalan_dk[$vk]=480; // tam vardiya
    }

    foreach($isler as $ii=>$is){
        $km  = (int)($is['kalan_miktar']??$is['planlanan_miktar']??0);
        $cs  = floatval($is['cycle_sn']??0);
        $kap = (int)($is['kapasite_vardiya']??0);
        if($kap<1&&$cs>0)$kap=(int)floor(25200/$cs);
        if($kap<1)$kap=1;
        $pers=(int)($is['personel_sayisi']??1);

        // Bu işin toplam süresi dakika cinsinden
        $is_dk_toplam = ($km / $kap) * 480;

        // Aktif vardiyanın pointer'ı - aktif vardiyadan başla
        $lp = array_search($aktif_vrd, $vrd_sirasi);

        $km_kalan = $km;
        for($vi=0; $vi<3 && $km_kalan>0; $vi++){
            if($lp>=3)break;
            $vk = $vrd_sirasi[$lp];
            $ia = ($vk===$aktif_vrd);

            $kapasite_dk = $vrd_kalan_dk[$vk]; // bu vardiyanın kalan dakikası
            if($kapasite_dk<=0){$lp++;continue;}

            // Bu vardiyadaki maks üretim
            $bm = (int)round($kap * $kapasite_dk / 480);
            $bm = max(0, min($km_kalan, $bm));

            if($bm>0){
                // Bu işin bu vardiyadaki süresi (dakika)
                $kullanilan_dk = ($bm / $kap) * 480;
                $dol = (int)round($bm / $kap * 100); // doluluk %

                // Offset: vardiyanın kaçıncı dakikasından başlıyor
                $vrd_kullanilan_dk = 480 - $vrd_kalan_dk[$vk]; // bu ana kadar kullanılan dk
                $offset_pct = (int)round($vrd_kullanilan_dk / 480 * 100);

                $gunluk[$hk][$ii][$vk]=[
                    'miktar'   =>$bm,
                    'doluluk'  =>min(100,$dol),
                    'offset'   =>$offset_pct,
                    'cycle_sn' =>$cs,
                    'personel' =>$pers,
                    'aktif'    =>$ia,
                    'dk'       =>(int)round($kullanilan_dk),
                ];

                // Vardiyanın kalan kapasitesini düş
                $vrd_kalan_dk[$vk] -= $kullanilan_dk;

                $km_kalan -= $bm;
            }
            // Eğer iş bu vardiyaya sığdıysa (km_kalan=0) aynı pointer'da kal (sonraki iş de buraya)
            // Sığmadıysa bir sonraki vardiyaya geç
            if($km_kalan>0) $lp++;
        }
    }
}

// Özet
$ozet=['S'=>['p'=>0,'h'=>0,'d'=>0],'O'=>['p'=>0,'h'=>0,'d'=>0],'G'=>['p'=>0,'h'=>0,'d'=>0]];
foreach($gunluk as $hk=>$isler){
    foreach(['S','O','G'] as $vk){
        foreach($isler as $ii=>$vd){
            if(isset($vd[$vk])){$ozet[$vk]['p']+=$vd[$vk]['personel'];$ozet[$vk]['h']++;}
        }
    }
}
foreach($hat_planlar as $hk=>$isler){
    if(count($isler)>1){
        foreach(['S','O','G'] as $vk){
            if(isset($gunluk[$hk][1][$vk]))$ozet[$vk]['d']++;
        }
    }
}
?>
<style>
#mp-wrap{overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 240px)}
#mp-tbl{border-collapse:collapse;width:100%;font-size:12px;white-space:nowrap}
#mp-tbl thead{position:sticky;top:0;z-index:10}
#mp-tbl thead tr{background:#1e4d2b}
#mp-tbl thead th{
  background:#1e4d2b;color:#d1fae5;padding:6px 9px;
  border:1px solid #2d6b3f;border-bottom:2px solid #134020;
  font-size:11px;font-weight:600;white-space:nowrap;text-transform:none;letter-spacing:0
}
#mp-tbl tbody td{padding:3px 7px;border-right:1px solid #E5E7EB;border-bottom:2px solid #9CA3AF;vertical-align:middle;font-size:12px}
#mp-tbl tbody tr:hover td{filter:brightness(.91)}
#mp-tbl tfoot tr{background:#F1F5F9}
#mp-tbl tfoot th{background:#F1F5F9;color:#374151;padding:5px 7px;border:1px solid #CBD5E1;font-size:11px;font-weight:600;white-space:nowrap;text-transform:none;letter-spacing:0}
#mp-tbl tfoot select{width:100%;font-size:10px;padding:2px 4px;border:1px solid #CBD5E1;border-radius:4px;background:#fff;font-family:inherit;cursor:pointer}
@media print{
  .ana-sb,.ust-bar,.s-bar,#mpSyncBtn,#mpMailBtn,#mpExcelBtn{display:none!important}
  .panel-icerik{margin-left:0!important}
  #mp-wrap{max-height:none!important;overflow:visible!important}
}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🔧 Montaj Planı</h1>
    <div class="s-yol" style="display:flex;align-items:center;flex-wrap:wrap;gap:6px">
      <span>Planlama / <b><?php echo date('d.m.Y');?></b></span>
      <span style="font-size:11px;color:#065F46;font-weight:700;background:#D1FAE5;padding:2px 8px;border-radius:4px">
        <?php echo $vrd_etiket[$aktif_vrd];?> · <?php echo $kalan_dk;?>dk kalan
      </span>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:4px 0">
    <input type="text" id="mpFiltre" placeholder="🔍 Hat / stok ara" oninput="mpFiltrele(this.value)"
      style="border:1px solid var(--kenar);border-radius:6px;padding:5px 9px;font-size:12px;width:150px;font-family:inherit">
    <button onclick="mpSync()" id="mpSyncBtn" title="Tiger'dan güncelle"
      style="background:#7C3AED;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:13px;cursor:pointer">🔄</button>
    <button onclick="window.print()" title="Yazdır"
      style="background:#374151;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:13px;cursor:pointer">🖨</button>
    <button onclick="mpExcel()" id="mpExcelBtn" title="Excel"
      style="background:#1D6F42;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:13px;cursor:pointer">📊</button>
    <button onclick="mpMail()" id="mpMailBtn" title="Mail Gönder"
      style="background:#0369A1;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:13px;cursor:pointer">✉</button>
    <button onclick="mpDurusAc()"
      style="background:#DC2626;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:13px;cursor:pointer">⛔ Duruş Ekle</button>
  </div>
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 0 10px 0">
<?php foreach(['S'=>['08:00-16:00','#EFF6FF','#1E40AF'],'O'=>['16:00-24:00','#F0FDF4','#065F46'],'G'=>['00:00-08:00','#FFF7ED','#92400E']] as $vk=>[$vl,$vbg,$vfg]):
  $o=$ozet[$vk];$iav=($vk===$aktif_vrd);?>
<div style="background:<?php echo $vbg;?>;border:1px solid <?php echo $iav?$vfg:'#E2E8F0';?>;border-radius:10px;padding:10px 14px"
     data-vrd="<?php echo $vk;?>" data-p="<?php echo $o['p'];?>" data-h="<?php echo $o['h'];?>" data-d="<?php echo $o['d'];?>">
  <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
    <span style="font-size:12px;font-weight:800;color:<?php echo $vfg;?>"><?php echo $vl;?></span>
    <?php if($iav):?><span style="background:<?php echo $vfg;?>;color:#fff;font-size:9px;padding:1px 5px;border-radius:3px;font-weight:700">AKTİF</span><?php endif;?>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;text-align:center">
    <div><div style="font-size:18px;font-weight:800;color:<?php echo $vfg;?>"><?php echo $o['p'];?></div><div style="font-size:9px;color:#64748B">👤 Personel</div></div>
    <div><div style="font-size:18px;font-weight:800;color:<?php echo $vfg;?>"><?php echo $o['h'];?></div><div style="font-size:9px;color:#64748B">🏭 Hat</div></div>
    <div><div style="font-size:18px;font-weight:800;color:<?php echo $o['d']>0?'#DC2626':$vfg;?>"><?php echo $o['d'];?></div><div style="font-size:9px;color:#64748B">🔄 Değişim</div></div>
  </div>
</div>
<?php endforeach;?>
</div>

<?php if(empty($montaj_hatlar)): ?>
<div style="background:#FEF3C7;border:1px solid #FCD34D;border-radius:8px;padding:16px;text-align:center;color:#92400E">
  ⚠️ Montaj hattı bulunamadı. Tiger DB'de EN- dışı iş istasyonu olan aktif üretim emri olmalıdır.
</div>
<?php else: ?>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
<div id="mp-wrap">
<table id="mp-tbl">
  <thead>
    <tr>
      <th>Hat</th><th>İşlem</th><th>ÜE No</th><th>Stok Kodu</th><th>Stok Adı</th>
      <th>Durum</th><th style="text-align:right">Kalan</th>
      <?php foreach(['S'=>'08-16','O'=>'16-24','G'=>'00-08'] as $vk=>$vl):$iav=($vk===$aktif_vrd);?>
      <th style="background:<?php echo $iav?'#14532D':'#166534';?>;color:#d1fae5;border:1px solid #15803d;min-width:90px">
        <?php echo $vl;?><?php if($iav):?><br><span style="font-size:8px;background:#FCD34D;color:#166534;border-radius:2px;padding:0 3px"><?php echo $kalan_dk;?>dk</span><?php endif;?>
      </th>
      <?php endforeach;?>
      <th>Notlar</th><th style="text-align:right">Kap/Vrd</th><th>HM Kodu</th>
    </tr>
  </thead>
<?php
$bar_renkler = ['#22C55E','#3B82F6','#F97316','#8B5CF6','#EC4899','#14B8A6','#EAB308','#DC2626'];
?>
  <tbody id="mp-body">
  <?php foreach($hat_sirasi as $hk):
    $hr=$montaj_renkleri[$hk]??'#F8FAFC';
    $isler=$hat_planlar[$hk]??[];
    if(empty($isler)):?>
  <tr data-hat="<?php echo $hk;?>" data-kod="" style="background:<?php echo $hr;?>;opacity:.45">
    <td style="font-weight:700"><?php echo $hk;?></td>
    <td></td><td>—</td><td>—</td><td>—</td>
    <td style="text-align:center"><span style="background:#FEE2E2;color:#991B1B;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700">Kapalı</span></td>
    <td>—</td><td>·</td><td>·</td><td>·</td><td></td><td></td><td></td>
  </tr>
  <?php else:foreach($isler as $ii=>$is):
    $km=(int)($is['kalan_miktar']??$is['planlanan_miktar']??0);
    $ue=$is['uretim_emri_no']??'—';
    $kod=$is['urun_kodu'];
    $adi=$is['urun_adi']??'';
    $pers=(int)($is['personel_sayisi']??1);
    $not=$is['notlar']??'';
    $kap_vrd=(int)($is['kapasite_vardiya']??0);
    // Duruş kontrolü
    $is_durus = ($kod==='__DURUS__');
    $durus_renkler = [
        'Planlı Duruş'   =>['bg'=>'#E5E7EB','sol'=>'#6B7280','etiket'=>'🔧 Planlı Duruş'],
        'Kalıp Arıza'    =>['bg'=>'#FEE2E2','sol'=>'#DC2626','etiket'=>'🔩 Kalıp Arıza'],
        'Makine Arıza'   =>['bg'=>'#FEE2E2','sol'=>'#DC2626','etiket'=>'⚙️ Makine Arıza'],
        'Makina Arıza'   =>['bg'=>'#FEE2E2','sol'=>'#DC2626','etiket'=>'⚙️ Makina Arıza'],
        'Malzeme Bekleme'=>['bg'=>'#FEF9C3','sol'=>'#CA8A04','etiket'=>'📦 Malzeme Bekleme'],
        'HM Bekleme'     =>['bg'=>'#FEF9C3','sol'=>'#CA8A04','etiket'=>'🧱 HM Bekleme'],
    ];
    $durus_stil = $is_durus ? ($durus_renkler[$adi] ?? ['bg'=>'#E5E7EB','sol'=>'#6B7280','etiket'=>('⛔ '.$adi)]) : null;
    $satir_bg = $is_durus ? $durus_stil['bg'] : $hr;
    $topbrd=$ii===0?'border-top:2px solid #94A3B8;':'';
    $nxt=$isler[$ii+1]??null;
    $ivrd=array_keys($gunluk[$hk][$ii]??[]);
    $kvi=(int)($is['kalan_vardiya']??$is['toplam_vardiya']??0);
    $bvs=count($ivrd);
    $vm=['S'=>1,'O'=>2,'G'=>3];
    if($is_durus){$dlbl=$durus_stil['etiket'];$dbg=$durus_stil['bg'];$dfg=$durus_stil['sol'];}
    elseif(empty($ivrd)){$dlbl='Sıradaki İş';$dbg='#FEF9C3';$dfg='#92400E';}
    elseif($ii===0&&!$nxt){$dlbl='Devam Edecek';$dbg='#DBEAFE';$dfg='#1E40AF';}
    elseif($ii===0&&$nxt){
      if($kvi>$bvs){$dlbl='Devam Edecek';$dbg='#DBEAFE';$dfg='#1E40AF';}
      else{$sv=end($ivrd);$dlbl=$vm[$sv].'. var. değiş';$dbg='#D1FAE5';$dfg='#065F46';}
    }elseif($ii>0&&!empty($ivrd)){$fv=reset($ivrd);$dlbl=$vm[$fv].'. var. değiş';$dbg='#D1FAE5';$dfg='#065F46';}
    else{$dlbl='Sıradaki İş';$dbg='#FEF9C3';$dfg='#92400E';}
  ?>
  <tr data-hat="<?php echo $hk;?>" data-kod="<?php echo htmlspecialchars($kod);?>" style="background:<?php echo $satir_bg;?>;<?php echo $is_durus?'border-left:4px solid '.$durus_stil['sol'].';':'';?><?php echo $topbrd;?>">
    <td style="font-weight:700;white-space:nowrap"><?php echo htmlspecialchars($hk);?></td>
    <td style="text-align:center;padding:2px;white-space:nowrap">
      <button onclick="mpDuzenle(<?php echo $is['id'];?>)" style="background:#EFF6FF;color:#1E40AF;border:none;padding:3px 6px;border-radius:4px;cursor:pointer;font-size:11px">✏</button>
      <button onclick="mpSil(<?php echo $is['id'];?>,<?php echo htmlspecialchars(json_encode($kod));?>)" style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 6px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button>
    </td>
    <td style="font-size:10px;color:#0369A1;white-space:nowrap"><?php echo htmlspecialchars($ue);?></td>
    <td><?php if($is_durus):?><span style="font-size:15px">⛔</span><?php else:?><code style="background:rgba(0,0,0,.05);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($kod);?></code><?php endif;?></td>
    <td style="min-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px"><?php echo $is_durus?'<span style="font-weight:700;color:'.htmlspecialchars($durus_stil['sol']).'">'.htmlspecialchars($durus_stil['etiket']).'</span>':htmlspecialchars($adi);?></td>
    <td style="text-align:center;white-space:nowrap"><span style="background:<?php echo $dbg;?>;color:<?php echo $dfg;?>;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700"><?php echo $dlbl;?></span></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $km>0?'#DC2626':'#059669';?>"><?php echo $is_durus?'—':($km>0?number_format($km,0,',','.'):'✓');?></td>
    <?php foreach(['S','O','G'] as $vk):$g=$gunluk[$hk][$ii][$vk]??null;$iav=($vk===$aktif_vrd);?>
    <?php
    $off = $g ? ($g['offset']??0) : 0;
    $w   = $g ? ($g['doluluk']??0) : 0;
    $col = $bar_renkler[$ii % count($bar_renkler)];
    // td arka planı: offset'e kadar transparan, offset'ten offset+w'ye kadar renkli (hafif), sonrası transparan
    $td_bg = '';
    if($g && $w>0){
        $col_rgba = $col.'22'; // hex rengi yok, inline rgba kullan
        // Renk hex → rgba dönüşümü
        $r = hexdec(substr($col,1,2));
        $g2= hexdec(substr($col,3,2));
        $b = hexdec(substr($col,5,2));
        $td_bg = 'background:linear-gradient(90deg, transparent '.$off.'%, rgba('.$r.','.$g2.','.$b.',.45) '.$off.'%, rgba('.$r.','.$g2.','.$b.',.45) '.($off+$w).'%, transparent '.($off+$w).'%)';
    }
    $outline = $iav ? 'outline:2px solid #16A34A;outline-offset:-2px;' : '';
    ?>
    <td style="position:relative;<?php echo $outline.$td_bg;?>">
      <?php if(!$is_durus && $g):?>
      <div style="position:relative;z-index:1;border-radius:3px;padding:2px 5px;font-size:10px;border-left:3px solid rgba(0,0,0,.15);<?php echo $g['aktif']?'border-left-color:#16A34A':'';?>">
        <div style="white-space:nowrap"><b><?php echo number_format($g['miktar'],0,',','.');?> ad</b><?php if($pers>0):?> | <?php echo $pers;?>👤<?php endif;?></div>
      </div>
      <?php else:?><span style="color:#CBD5E1;font-size:9px">·</span><?php endif;?>
    </td>
    <?php endforeach;?>
    <td style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px"><?php echo htmlspecialchars($not);?></td>
    <td style="text-align:right;font-size:11px;color:#065F46"><?php echo $kap_vrd>0?number_format($kap_vrd,0,',','.'):'—';?></td>
    <td style="font-size:10px;color:#0369A1"></td>
  </tr>
  <?php endforeach;endif;endforeach;?>
  </tbody>
  <tfoot>
    <tr>
      <th>Hat</th><th></th><th>ÜE No</th><th>Stok Kodu</th><th>Stok Adı</th>
      <th>Durum</th><th>Kalan</th><th>08-16</th><th>16-24</th><th>00-08</th>
      <th>Notlar</th><th>Kap/Vrd</th><th>HM Kodu</th>
    </tr>
  </tfoot>
</table>
</div>
</div>

<?php endif; ?>

<!-- Düzenleme Modal -->
<div id="mpDuzModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:12px;width:100%;max-width:500px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid #E2E8F0;background:#f8fafc;border-radius:12px 12px 0 0">
    <div style="font-size:13px;font-weight:800;color:#0F172A" id="mpDuzBaslik">İş Düzenle</div>
    <button onclick="mpDuzKapat()" style="background:#F1F5F9;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer">✕</button>
  </div>
  <div style="padding:18px">
    <input type="hidden" id="mpDuzId">
    <div style="display:grid;grid-template-columns:1fr 1fr 80px;gap:10px;margin-bottom:12px">
      <div><label class="form-etiket">Miktar</label><input type="number" id="mpDuzMiktar" class="form-alan" min="1" oninput="mpDuzHesapla()"></div>
      <div><label class="form-etiket">Kapasite/Vrd</label><input type="number" id="mpDuzKap" class="form-alan" min="1"></div>
      <div><label class="form-etiket">👤 Personel</label><input type="number" id="mpDuzPers" class="form-alan" min="1" max="20" value="1" style="text-align:center"></div>
    </div>
    <div id="mpDuzHesap" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:6px;padding:8px 12px;margin-bottom:12px;font-size:11px;display:none"><span id="mpDuzHesapTxt"></span></div>
    <div style="margin-bottom:12px"><label class="form-etiket">ÜE No</label><input type="text" id="mpDuzUe" class="form-alan"></div>
    <div style="margin-bottom:16px"><label class="form-etiket">Notlar</label><input type="text" id="mpDuzNot" class="form-alan"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="mpDuzKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">İptal</button>
      <button onclick="mpDuzKaydet()" id="mpDuzBtn" style="background:linear-gradient(135deg,#1e4d2b,#134020);color:#fff;border:none;padding:8px 18px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✅ Kaydet</button>
    </div>
  </div>
</div>
</div>

<!-- Duruş Modalı -->
<div id="mpDurusModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #E2E8F0;background:#FFF5F5;border-radius:14px 14px 0 0">
    <div style="font-size:14px;font-weight:800;color:#991B1B">⛔ Duruş Kaydı (Montaj)</div>
    <button onclick="mpDurusKapat()" style="background:#F1F5F9;border:none;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div style="padding:18px">
    <div style="margin-bottom:12px">
      <label class="form-etiket">Hat (EN- dışı)</label>
      <select id="mpDurusHat" class="form-alan">
        <option value="">Hat seçin...</option>
        <?php foreach($montaj_hatlar as $mh): ?>
        <option value="<?php echo htmlspecialchars($mh);?>"><?php echo htmlspecialchars($mh);?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="margin-bottom:12px">
      <label class="form-etiket">Duruş Türü</label>
      <select id="mpDurusTur" class="form-alan">
        <option value="">Tür seçin...</option>
        <option value="Planlı Duruş">🔧 Planlı Duruş</option>
        <option value="Makine Arıza">⚠️ Makine Arıza</option>
        <option value="Kalıp Arıza">🔩 Kalıp Arıza</option>
        <option value="Malzeme Bekleme">📦 Malzeme Bekleme</option>
        <option value="HM Bekleme">🧱 HM Bekleme</option>
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Vardiya Sayısı</label>
        <input type="number" id="mpDurusVardiya" class="form-alan" min="1" max="99" value="1" style="text-align:center;font-weight:700">
      </div>
      <div>
        <label class="form-etiket">Başlangıç Vardiyası</label>
        <select id="mpDurusBas" class="form-alan">
          <option value="S">Sabah (08-16)</option>
          <option value="O">Öğleden Sonra (16-24)</option>
          <option value="G">Gece (00-08)</option>
        </select>
      </div>
    </div>
    <div style="margin-bottom:16px">
      <label class="form-etiket">Açıklama</label>
      <input type="text" id="mpDurusAciklama" class="form-alan" placeholder="Duruş açıklaması...">
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="mpDurusKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">İptal</button>
      <button onclick="mpDurusKaydet()" id="mpDurusKaydetBtn" style="background:linear-gradient(135deg,#DC2626,#991B1B);color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">⛔ Duruş Ekle</button>
    </div>
  </div>
</div>
</div>

<script>
function mpPost(d,cb){
  var fd=new FormData();
  Object.entries(d).forEach(function(e){fd.append(e[0],e[1]||'');});
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb).catch(function(e){alert('Hata:'+e);});
}
function mpSil(id,kod){
  if(!confirm(kod+' isini silmek istediginize emin misiniz?'))return;
  mpPost({gp_action:'sil',id:id},function(d){if(d.ok)location.reload();else alert('Silinemedi:'+(d.hata||''));});
}
function mpDuzenle(id){
  mpPost({gp_action:'detay',id:id},function(d){
    if(!d.ok){alert('Veri alinamadi');return;}
    var r=d.data;
    document.getElementById('mpDuzId').value=id;
    document.getElementById('mpDuzBaslik').textContent='Duzenle: '+r.urun_kodu;
    document.getElementById('mpDuzMiktar').value=r.kalan_miktar||r.planlanan_miktar;
    document.getElementById('mpDuzKap').value=r.kapasite_vardiya||1;
    document.getElementById('mpDuzPers').value=r.personel_sayisi||1;
    document.getElementById('mpDuzUe').value=r.uretim_emri_no||'';
    document.getElementById('mpDuzNot').value=r.notlar||'';
    mpDuzHesapla();
    document.getElementById('mpDuzModal').style.display='flex';
  });
}
function mpDuzHesapla(){
  var mik=parseInt(document.getElementById('mpDuzMiktar').value)||0;
  var kap=parseInt(document.getElementById('mpDuzKap').value)||1;
  var el=document.getElementById('mpDuzHesap');
  if(mik<1){el.style.display='none';return;}
  el.style.display='block';
  document.getElementById('mpDuzHesapTxt').innerHTML=mik.toLocaleString('tr-TR')+' adet &rarr; '+Math.max(1,Math.ceil(mik/kap))+' vardiya';
}
function mpDuzKapat(){document.getElementById('mpDuzModal').style.display='none';}
function mpDuzKaydet(){
  var id=document.getElementById('mpDuzId').value;
  var mik=parseInt(document.getElementById('mpDuzMiktar').value)||0;
  if(!id||mik<1){alert('Miktar giriniz.');return;}
  var btn=document.getElementById('mpDuzBtn');
  btn.disabled=true;btn.textContent='Kaydediliyor...';
  mpPost({gp_action:'duzenle',id:id,planlanan_miktar:mik,
    kapasite_vardiya:document.getElementById('mpDuzKap').value||1,
    personel_sayisi:document.getElementById('mpDuzPers').value||1,
    uretim_emri_no:document.getElementById('mpDuzUe').value,
    notlar:document.getElementById('mpDuzNot').value},
  function(d){btn.disabled=false;btn.textContent='Kaydet';
    if(d.ok){mpDuzKapat();location.reload();}else alert('Hata:'+(d.hata||''));});
}
function mpDurusAc(){document.getElementById('mpDurusModal').style.display='flex';}
function mpDurusKapat(){document.getElementById('mpDurusModal').style.display='none';}
function mpDurusKaydet(){
  var hat=document.getElementById('mpDurusHat').value;
  var tur=document.getElementById('mpDurusTur').value;
  var vrd=document.getElementById('mpDurusVardiya').value||1;
  var bas=document.getElementById('mpDurusBas').value;
  var acl=document.getElementById('mpDurusAciklama').value;
  if(!hat||!tur){alert('Hat ve duruş türü seçiniz.');return;}
  var btn=document.getElementById('mpDurusKaydetBtn');
  btn.disabled=true; btn.textContent='Kaydediliyor...';
  var fd=new FormData();
  fd.append('gp_action','durus_ekle');
  fd.append('hat',hat);
  fd.append('durus_turu',tur);
  fd.append('vardiya_sayisi',vrd);
  fd.append('baslangic_vardiya',bas);
  fd.append('aciklama',acl);
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    btn.disabled=false; btn.textContent='⛔ Duruş Ekle';
    if(d.ok){mpDurusKapat();location.reload();}
    else alert('Hata: '+(d.hata||''));
  }).catch(function(e){btn.disabled=false;btn.textContent='⛔ Duruş Ekle';alert('Hata:'+e);});
}

function mpSync(){
  var btn=document.getElementById('mpSyncBtn');
  btn.disabled=true;btn.textContent='...';
  mpPost({gp_action:'tiger_sync'},function(d){
    btn.disabled=false;btn.textContent='🔄';
    if(d.ok){alert(d.guncellenen+' is guncellendi.');location.reload();}
    else alert('Hata:'+(d.hata||''));
  });
}
function mpFiltrele(q){
  q=q.toLowerCase().trim();
  document.querySelectorAll('#mp-body tr').forEach(function(tr){
    if(!q){tr.style.display='';return;}
    tr.style.display=((tr.dataset.hat||'').toLowerCase().includes(q)||(tr.dataset.kod||'').toLowerCase().includes(q))?'':'none';
  });
}
function mpExcel(){
  var rows=[],hdr=[];
  document.querySelectorAll('#mp-tbl thead tr:first-child th').forEach(function(th,i){
    if(i===1)return;
    hdr.push('"'+th.textContent.trim().split('\n').join(' ').replace(/"/g,'""')+'"');
  });
  rows.push(hdr.join(';'));
  document.querySelectorAll('#mp-body tr').forEach(function(tr){
    if(tr.style.display==='none')return;
    var cells=[];
    tr.querySelectorAll('td').forEach(function(td,i){
      if(i===1)return;
      cells.push('"'+td.textContent.trim().split('\n').join(' ').replace(/"/g,'""')+'"');
    });
    if(cells.length)rows.push(cells.join(';'));
  });
  var csv=rows.join('\n');
  var blob=new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='Montaj_Plan_'+new Date().toISOString().slice(0,10)+'.csv';
  a.click();
}
function mpMail(ekstra){
  var btn=document.getElementById('mpMailBtn');
  btn.disabled=true;btn.textContent='...';
  var ozet={};
  document.querySelectorAll('[data-vrd]').forEach(function(el){
    ozet[el.dataset.vrd]={personel:parseInt(el.dataset.p||0),hat:parseInt(el.dataset.h||0),degisim:parseInt(el.dataset.d||0)};
  });
  var totalP=0,totalH=0,totalD=0;
  var ozStr='<table style="border-collapse:collapse;margin-bottom:16px;font-size:12px"><tr style="background:#1e4d2b;color:#d1fae5"><th style="padding:5px 10px;border:1px solid #2d6b3f">Vardiya</th><th style="padding:5px 10px;border:1px solid #2d6b3f">👤 Personel</th><th style="padding:5px 10px;border:1px solid #2d6b3f">🏭 Hat</th><th style="padding:5px 10px;border:1px solid #2d6b3f">🔄 Değişim</th></tr>';
  [['S','08:00-16:00'],['O','16:00-24:00'],['G','00:00-08:00']].forEach(function(vr){
    var o=ozet[vr[0]]||{personel:0,hat:0,degisim:0};
    totalP+=o.personel;totalH+=o.hat;totalD+=o.degisim;
    ozStr+='<tr><td style="padding:4px 10px;border:1px solid #E2E8F0"><b>'+vr[1]+'</b></td><td style="padding:4px 10px;border:1px solid #E2E8F0;text-align:center">'+o.personel+'</td><td style="padding:4px 10px;border:1px solid #E2E8F0;text-align:center">'+o.hat+'</td><td style="padding:4px 10px;border:1px solid #E2E8F0;text-align:center">'+o.degisim+'</td></tr>';
  });
  ozStr+='<tr style="background:#F1F5F9;font-weight:700"><td style="padding:4px 10px;border:1px solid #CBD5E1">Toplam</td><td style="padding:4px 10px;border:1px solid #CBD5E1;text-align:center">'+totalP+'</td><td style="padding:4px 10px;border:1px solid #CBD5E1;text-align:center">'+totalH+'</td><td style="padding:4px 10px;border:1px solid #CBD5E1;text-align:center">'+totalD+'</td></tr></table>';
  var th='<table style="border-collapse:collapse;width:100%;font-size:11px"><thead><tr>';
  document.querySelectorAll('#mp-tbl thead tr:first-child th').forEach(function(t,i){
    if(i===1)return;
    th+='<th style="background:#1e4d2b;color:#d1fae5;padding:4px 7px;border:1px solid #2d6b3f;white-space:nowrap">'+t.textContent.trim().split('\n').join(' ')+'</th>';
  });
  th+='</tr></thead>';
  var tb='<tbody>';
  document.querySelectorAll('#mp-body tr').forEach(function(tr){
    if(tr.style.display==='none')return;
    var bg=tr.style.background||'';
    var cells=[];
    tr.querySelectorAll('td').forEach(function(td,i){
      if(i===1)return;
      cells.push('<td style="padding:3px 6px;border:1px solid #D1D5DB;background:'+bg+'">'+td.textContent.trim()+'</td>');
    });
    if(cells.length)tb+='<tr>'+cells.join('')+'</tr>';
  });
  tb+='</tbody></table>';
  var fd=new FormData();
  fd.append('gp_action','mail_gonder');
  fd.append('ozet_json',JSON.stringify(ozet));
  fd.append('plan_html',ozStr+th+tb);
  if(ekstra)fd.append('ekstra_mail',ekstra);
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    btn.disabled=false;btn.textContent='✉';
    if(d.ok){alert('Mail gonderildi: '+d.sayi+' alici');}
    else if(d.hata==='bos'){
      var adres=prompt(d.mesaj+' Mail adresi:','');
      if(adres&&adres.trim())mpMail(adres.trim());
      else alert('Mail gonderilmedi.');
    }else{alert('Hata: '+d.hata);}
  }).catch(function(e){btn.disabled=false;btn.textContent='✉';alert('Hata:'+e);});
}
document.addEventListener('keydown',function(e){if(e.key==='Escape')mpDuzKapat();});

// tfoot filtre
document.addEventListener('DOMContentLoaded',function(){
  var tbl=document.getElementById('mp-tbl');
  var tbody=document.getElementById('mp-body');
  if(!tbl||!tbody)return;
  var colFilters={};
  tbl.querySelectorAll('tfoot th').forEach(function(th,idx){
    if(idx===1){return;}
    var lbl=th.textContent.trim();
    if(!lbl){return;}
    var vals={};
    tbody.querySelectorAll('tr').forEach(function(tr){
      var tds=tr.querySelectorAll('td');
      if(!tds[idx])return;
      var v=tds[idx].textContent.trim().replace(/\s+/g,' ');
      if(v&&v!=='—'&&v!=='·')vals[v]=1;
    });
    var keys=Object.keys(vals).sort();
    if(keys.length<1){th.innerHTML='<span style="font-size:10px;color:#9CA3AF">'+lbl+'</span>';return;}
    var sel=document.createElement('select');
    sel.innerHTML='<option value="">'+lbl+'</option>';
    keys.forEach(function(k){var opt=document.createElement('option');opt.value=k;opt.textContent=k.length>18?k.substr(0,18)+'…':k;sel.appendChild(opt);});
    sel.addEventListener('change',function(){colFilters[idx]=this.value.toLowerCase();applyFilters();});
    th.innerHTML='';th.appendChild(sel);
  });
  function applyFilters(){
    var gq=(document.getElementById('mpFiltre').value||'').toLowerCase().trim();
    tbody.querySelectorAll('tr').forEach(function(tr){
      var tds=tr.querySelectorAll('td');
      var show=true;
      if(gq){var h=(tr.dataset.hat||'').toLowerCase();var k=(tr.dataset.kod||'').toLowerCase();if(!h.includes(gq)&&!k.includes(gq))show=false;}
      if(show){Object.keys(colFilters).forEach(function(idx){var q=colFilters[idx];if(!q)return;var td=tds[parseInt(idx)];if(!td)return;if(!td.textContent.trim().toLowerCase().includes(q))show=false;});}
      tr.style.display=show?'':'none';
    });
  }
  window.mpFiltrele=function(){applyFilters();};
});
</script>
