<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok   = ($tigerdb_pdo !== null);
$selYil     = isset($_GET['yil']) ? (int)$_GET['yil'] : (int)date('Y');
$bugun_yil  = (int)date('Y');
$bugun_ay_n = (int)date('n');

$aylar_tr = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
             'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];

function ay_kisa($ad) {
    $k=['Ocak'=>'Oca','Şubat'=>'Şub','Mart'=>'Mar','Nisan'=>'Nis','Mayıs'=>'May',
        'Haziran'=>'Haz','Temmuz'=>'Tem','Ağustos'=>'Ağu','Eylül'=>'Eyl',
        'Ekim'=>'Eki','Kasım'=>'Kas','Aralık'=>'Ara'];
    return $k[$ad]??$ad;
}

// ─── VERİ: STOK SAYIM KPI ───────────────────────────────────────────────────
$stok_rows = $db->prepare("SELECT * FROM aylik_kpi_stok WHERE yil=? ORDER BY
    CASE ay WHEN 'Ocak' THEN 1 WHEN 'Şubat' THEN 2 WHEN 'Mart' THEN 3 WHEN 'Nisan' THEN 4
    WHEN 'Mayıs' THEN 5 WHEN 'Haziran' THEN 6 WHEN 'Temmuz' THEN 7 WHEN 'Ağustos' THEN 8
    WHEN 'Eylül' THEN 9 WHEN 'Ekim' THEN 10 WHEN 'Kasım' THEN 11 WHEN 'Aralık' THEN 12 END");
$stok_rows->execute([$selYil]);
$stok_data = $stok_rows->fetchAll(PDO::FETCH_ASSOC);
$stok_map  = array_column($stok_data, null, 'ay');

// Sayım istatistikleri aylik
$sayim_ay = [];
foreach ($aylar_tr as $i=>$ay) {
    $p = $db->prepare("SELECT COUNT(*) FROM sayimlar WHERE donem=? AND yil=? AND ((sayim_miktari*100.0)/kayitli_stok BETWEEN 85 AND 115)");
    $p->execute([$ay,$selYil]); $puan = (int)$p->fetchColumn();
    $t = $db->prepare("SELECT COUNT(*) FROM sayimlar WHERE donem=? AND yil=?");
    $t->execute([$ay,$selYil]); $toplam = (int)$t->fetchColumn();
    $hedef   = isset($stok_map[$ay]) ? floatval($stok_map[$ay]['hedef_yuzde']) : 85;
    $grc_pct = $toplam > 0 ? round($puan*100/$toplam,1) : 0;
    $uyum    = $hedef > 0 ? round($grc_pct/$hedef*100,1) : 0;
    $sayim_ay[$ay] = ['puan'=>$puan,'toplam'=>$toplam,'hedef'=>$hedef,'gerceklesme'=>$grc_pct,'uyum'=>$uyum];
}

// ─── VERİ: TEDARİKÇİ PERFORMANS (Tiger CROSS APPLY) ─────────────────────────
// Ay bazlı: her ORFLINE için terminle en yakın irsaliyeyi bul
$ted_ay = []; // ay => [zamaninda,gec,toplam]
foreach ($aylar_tr as $i=>$ay) { $ted_ay[$ay]=['zamaninda'=>0,'gec'=>0,'toplam'=>0,'puan'=>0]; }

if ($tiger_ok) {
    try {
        $sql = "SELECT MONTH(OL.DUEDATE) AS ay,
            DATEDIFF(DAY, OL.DUEDATE, nearest.irs_tarihi) AS gecikme_gun
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
        CROSS APPLY (
            SELECT TOP 1 F.DATE_ AS irs_tarihi
            FROM dbo.LG_222_02_STLINE SL WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_02_STFICHE F WITH(NOLOCK) ON SL.STFICHEREF=F.LOGICALREF
            WHERE SL.STOCKREF=OL.STOCKREF AND SL.TRCODE=1 AND SL.CANCELLED=0 AND F.TRCODE=1 AND SL.AMOUNT>0
            ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,F.DATE_)) ASC, F.DATE_ ASC
        ) nearest
        WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT>0
          AND YEAR(OL.DUEDATE)=".intval($selYil)."
          AND OL.DUEDATE IS NOT NULL";
        $rows = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $ay_n = (int)($r['ay']??0);
            if ($ay_n<1||$ay_n>12) continue;
            $ay = $aylar_tr[$ay_n-1];
            $gec = (int)($r['gecikme_gun']??0);
            $ted_ay[$ay]['toplam']++;
            if ($gec<=2) $ted_ay[$ay]['zamaninda']++;
            else         $ted_ay[$ay]['gec']++;
        }
        foreach ($ted_ay as $ay=>$v) {
            $ted_ay[$ay]['puan'] = $v['toplam']>0 ? round($v['zamaninda']/$v['toplam']*100,1) : 0;
        }
    } catch(Throwable $e) {}
}

// ─── SEVKİYAT: geçmiş aylar %100, cari ay ve sonrası 0 ─────────────────────
$sevk_ay = [];
foreach ($aylar_tr as $i=>$ay) {
    $ay_n   = $i+1;
    $gecmis = ($selYil < $bugun_yil) || ($selYil==$bugun_yil && $ay_n < $bugun_ay_n);
    $sevk_ay[$ay] = $gecmis ? 100 : 0;
}

// ─── HESAPLA ─────────────────────────────────────────────────────────────────
// Stok ortalama
$s_grc_list = array_filter(array_column($sayim_ay,'gerceklesme'), fn($v)=>$v>0);
$s_uyum_list= array_filter(array_column($sayim_ay,'uyum'),        fn($v)=>$v>0);
$s_ort_grc  = count($s_grc_list)>0 ? round(array_sum($s_grc_list)/count($s_grc_list),1) : 0;
$s_ort_uyum = count($s_uyum_list)>0? round(array_sum($s_uyum_list)/count($s_uyum_list),1): 0;

// Tedarikçi ortalama
$t_puan_list = array_filter(array_column($ted_ay,'puan'), fn($v)=>$v>0);
$t_ort = count($t_puan_list)>0 ? round(array_sum($t_puan_list)/count($t_puan_list),1) : 0;

// Sevkiyat ortalama
$sv_list = array_filter($sevk_ay, fn($v)=>$v>0);
$sv_ort  = count($sv_list)>0 ? round(array_sum($sv_list)/count($sv_list),1) : 0;

function renk_class($val, $hedef=85) {
    if ($val <= 0) return '';
    if ($val >= $hedef) return 'background:#D1FAE5;color:#065F46';
    if ($val >= $hedef*0.7) return 'background:#FEF9C3;color:#854D0E';
    return 'background:#FEE2E2;color:#991B1B';
}
?>
<style>
.kpi-tablo { width:100%;border-collapse:collapse;font-size:11px }
.kpi-tablo th { background:#1E3A5F;color:#fff;padding:7px 10px;white-space:nowrap;border:1px solid #2d5986 }
.kpi-tablo td { padding:6px 10px;border:1px solid #E2E8F0;white-space:nowrap;text-align:center }
.kpi-tablo td:first-child { text-align:left;font-weight:600;background:#F8FAFC }
.kpi-tablo .ort-cell { font-weight:900;background:#FEF9C3 }
.kpi-blok { background:#fff;border:1px solid #E2E8F0;border-radius:10px;overflow:hidden;margin-bottom:14px }
.kpi-blok-baslik { background:#1E3A5F;color:#fff;padding:8px 14px;font-weight:700;font-size:12px;display:flex;align-items:center;gap:8px }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📊 KPI Özet</h1>
    <div class="s-yol">Planlama / <b>KPI Gösterge Paneli</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <form method="GET" style="display:flex;gap:6px;align-items:center">
      <input type="hidden" name="sayfa" value="planlama-kpi-ozet">
      <select name="yil" class="form-alan" onchange="this.form.submit()">
        <?php for($y=$bugun_yil;$y>=$bugun_yil-3;$y--):?>
        <option value="<?php echo $y;?>" <?php echo $y==$selYil?'selected':'';?>><?php echo $y;?></option>
        <?php endfor;?>
      </select>
    </form>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=raporlar-sayim"
      style="background:#1E3A5F;color:#fff;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">📋 Stok Sayım</a>
    <button onclick="window.print()"
      style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🖨️ Yazdır</button>
  </div>
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:14px">
  <?php
  $ozet_kartlar = [
    ['14 - Sevkiyat Planına Uyum', $sv_ort.'%', '#2563EB', '🚛'],
    ['17 - Stok Sayım Gerçekleşme', $s_ort_grc.'%', '#16A34A', '🔢'],
    ['17 - Stok Sayım Hedefe Uyum', $s_ort_uyum.'%', '#D97706', '🎯'],
    ['25 - Tedarikçi Performansı', $t_ort.'%', '#7C3AED', '🏭'],
  ];
  foreach ($ozet_kartlar as [$lbl,$val,$renk,$ikon]):?>
  <div style="background:#fff;border:1px solid #E2E8F0;border-left:4px solid <?php echo $renk;?>;border-radius:8px;padding:12px 16px">
    <div style="font-size:26px;font-weight:900;color:<?php echo $renk;?>"><?php echo $val;?></div>
    <div style="font-size:11px;color:#374151;font-weight:600"><?php echo $ikon;?> <?php echo $lbl;?></div>
    <div style="font-size:10px;color:#94A3B8"><?php echo $selYil;?> Yıl Ortalaması</div>
  </div>
  <?php endforeach;?>
</div>

<!-- 14 - SEVKİYAT PLANINA UYUM -->
<div class="kpi-blok">
  <div class="kpi-blok-baslik">🚛 14 — SEVKİYAT PLANINA UYUM TAKİBİ %
    <span style="font-size:10px;font-weight:400;opacity:.8">(Geçmiş aylar %100 — online hesaplama yakında)</span>
  </div>
  <div style="overflow-x:auto;padding:12px">
    <table class="kpi-tablo">
      <thead><tr>
        <th style="text-align:left;min-width:160px">TANIM</th>
        <?php foreach($aylar_tr as $ay):?><th><?php echo ay_kisa($ay);?></th><?php endforeach;?>
        <th style="background:#F59E0B">ORT.</th>
      </tr></thead>
      <tbody>
        <tr>
          <td>HEDEF (%)</td>
          <?php foreach($aylar_tr as $ay):?><td>90%</td><?php endforeach;?>
          <td class="ort-cell">90%</td>
        </tr>
        <tr>
          <td>GERÇEKLEŞME (%)</td>
          <?php foreach($aylar_tr as $i=>$ay):
            $v=$sevk_ay[$ay]; $st=renk_class($v,90);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $v>0?$v.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $sv_ort>0?$sv_ort.'%':'—';?></td>
        </tr>
        <tr>
          <td>HEDEFE UYUM (%)</td>
          <?php foreach($aylar_tr as $ay):
            $v=$sevk_ay[$ay]; $u=$v>0?round($v/90*100,1):0; $st=renk_class($u,100);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $u>0?$u.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $sv_ort>0?round($sv_ort/90*100,1).'%':'—';?></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!-- 17 - FİLİ STOK - KAYITLI STOK TUTARLILIĞI -->
<div class="kpi-blok">
  <div class="kpi-blok-baslik">🔢 17 — FİLİ STOK — KAYITLI STOK TUTARLILIĞI %</div>
  <div style="overflow-x:auto;padding:12px">
    <table class="kpi-tablo">
      <thead><tr>
        <th style="text-align:left;min-width:180px">TANIM</th>
        <?php foreach($aylar_tr as $ay):?><th><?php echo ay_kisa($ay);?></th><?php endforeach;?>
        <th style="background:#F59E0B">ORT.</th>
      </tr></thead>
      <tbody>
        <tr>
          <td>HEDEF (%)</td>
          <?php foreach($aylar_tr as $ay):$h=isset($stok_map[$ay])?floatval($stok_map[$ay]['hedef_yuzde']):85;?>
          <td><?php echo $h;?>%</td><?php endforeach;?>
          <td class="ort-cell">85%</td>
        </tr>
        <tr>
          <td>GERÇEKLEŞME (%)</td>
          <?php foreach($aylar_tr as $ay):$v=$sayim_ay[$ay]['gerceklesme'];$st=renk_class($v);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $v>0?$v.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $s_ort_grc>0?$s_ort_grc.'%':'—';?></td>
        </tr>
        <tr>
          <td>HEDEFE UYUM (%)</td>
          <?php foreach($aylar_tr as $ay):$v=$sayim_ay[$ay]['uyum'];$st=renk_class($v,100);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $v>0?$v.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $s_ort_uyum>0?$s_ort_uyum.'%':'—';?></td>
        </tr>
        <tr>
          <td>SAYIM ADEDİ</td>
          <?php foreach($aylar_tr as $ay):?><td><?php echo $sayim_ay[$ay]['toplam']?:0;?></td><?php endforeach;?>
          <td class="ort-cell"><?php echo array_sum(array_column($sayim_ay,'toplam'));?></td>
        </tr>
        <tr>
          <td>GERÇEKLEŞME (ADET)</td>
          <?php foreach($aylar_tr as $ay):?><td style="color:#16A34A;font-weight:700"><?php echo $sayim_ay[$ay]['puan']?:0;?></td><?php endforeach;?>
          <td class="ort-cell" style="color:#16A34A"><?php echo array_sum(array_column($sayim_ay,'puan'));?></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!-- 25 - TEDARİKÇİ PERFORMANS -->
<div class="kpi-blok">
  <div class="kpi-blok-baslik">🏭 25 — TEDARİKÇİ PERFORMANS TAKİBİ %
    <?php if(!$tiger_ok):?><span style="font-size:10px;color:#FCA5A5">● Tiger DB Yok</span><?php endif;?>
    <span style="font-size:10px;font-weight:400;opacity:.8">(≤+2 gün = zamanında)</span>
  </div>
  <div style="overflow-x:auto;padding:12px">
    <table class="kpi-tablo">
      <thead><tr>
        <th style="text-align:left;min-width:180px">TANIM</th>
        <?php foreach($aylar_tr as $ay):?><th><?php echo ay_kisa($ay);?></th><?php endforeach;?>
        <th style="background:#F59E0B">ORT.</th>
      </tr></thead>
      <tbody>
        <tr>
          <td>HEDEF (%)</td>
          <?php foreach($aylar_tr as $ay):?><td>87%</td><?php endforeach;?>
          <td class="ort-cell">87%</td>
        </tr>
        <tr>
          <td>GERÇEKLEŞME (%)</td>
          <?php foreach($aylar_tr as $ay):$v=$ted_ay[$ay]['puan'];$st=renk_class($v,87);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $v>0?$v.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $t_ort>0?$t_ort.'%':'—';?></td>
        </tr>
        <tr>
          <td>HEDEFE UYUM (%)</td>
          <?php foreach($aylar_tr as $ay):$v=$ted_ay[$ay]['puan'];$u=$v>0?round($v/87*100,1):0;$st=renk_class($u,100);?>
          <td style="<?php echo $st;?>;font-weight:700"><?php echo $u>0?$u.'%':'—';?></td>
          <?php endforeach;?>
          <td class="ort-cell"><?php echo $t_ort>0?round($t_ort/87*100,1).'%':'—';?></td>
        </tr>
        <tr>
          <td>ZAMANINDA TESLİMAT</td>
          <?php foreach($aylar_tr as $ay):?><td style="color:#16A34A;font-weight:600"><?php echo $ted_ay[$ay]['zamaninda']?:0;?></td><?php endforeach;?>
          <td class="ort-cell" style="color:#16A34A"><?php echo array_sum(array_column($ted_ay,'zamaninda'));?></td>
        </tr>
        <tr>
          <td>GEÇ TESLİMAT</td>
          <?php foreach($aylar_tr as $ay):?><td style="color:#DC2626;font-weight:600"><?php echo $ted_ay[$ay]['gec']?:0;?></td><?php endforeach;?>
          <td class="ort-cell" style="color:#DC2626"><?php echo array_sum(array_column($ted_ay,'gec'));?></td>
        </tr>
        <tr>
          <td>TOPLAM TESLİMAT</td>
          <?php foreach($aylar_tr as $ay):?><td><?php echo $ted_ay[$ay]['toplam']?:0;?></td><?php endforeach;?>
          <td class="ort-cell"><?php echo array_sum(array_column($ted_ay,'toplam'));?></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
