<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

set_time_limit(0);
ini_set('memory_limit','512M');

$tiger_ok        = ($tigerdb_pdo !== null);
$form_gonderildi = isset($_POST['mps_calistir']);
$hata            = '';
$plan_gunler     = [];   // [tarih][hat_kodu][vardiya] = {urun_kodu, urun_adi, miktar, kapasite}
$execution_time  = 0;

/* ─── Türkiye resmi tatilleri 2025-2026 ─── */
$resmi_tatiller = [
    '2025-01-01','2025-04-23','2025-05-01','2025-05-19',
    '2025-03-30','2025-03-31','2025-04-01', // Ramazan Bayramı 2025
    '2025-06-06','2025-06-07','2025-06-08', // Kurban Bayramı 2025
    '2025-07-15','2025-08-30','2025-10-29',
    '2026-01-01','2026-04-23','2026-05-01','2026-05-19',
    '2026-03-20','2026-03-21','2026-03-22', // Ramazan Bayramı 2026
    '2026-05-27','2026-05-28','2026-05-29', // Kurban Bayramı 2026
    '2026-07-15','2026-08-30','2026-10-29',
];

/* ─── EN- hat sırası ve renkleri ─── */
$hat_renkleri = [
    'EN-110-01'=>'#FAFAD2','EN-132-01'=>'#FFEB99','EN-80-01' =>'#CCFFCC',
    'EN-130-01'=>'#FFDAB9','EN-160-01'=>'#FFCCFF','EN-201-01'=>'#E0FFFF',
    'EN-202-01'=>'#FFE4E1','EN-301-01'=>'#E6E6FA','EN-302-01'=>'#F0FFF0',
    'EN-350-01'=>'#FFFACD','EN-420-01'=>'#FFF5E6','EN-500-01'=>'#F5F5DC',
    'EN-650-01'=>'#D8BFD8','EN-162-01'=>'#B0E0E6','EN-131-01'=>'#FFDEAD',
    'EN-161-01'=>'#F0E68C','EN-530-01'=>'#FFEFD5','EN-650-02'=>'#E6E6FA',
    'EN-450-01'=>'#F5FFFA','EN-500-02'=>'#FFF0F5','EN-260-01'=>'#CCE5FF',
    'EN-410-01'=>'#FDF5E6','EN-500-03'=>'#FFD700','EN-700-01'=>'#FFE4B5',
    'EN-180-01'=>'#F0FFF0','EN-280-01'=>'#FFFAF0','EN-650-03'=>'#FFFACD',
    'EN-650-04'=>'#FFCCCB','EN-650-05'=>'#FFE4C4','EN-650-06'=>'#F8F8FF',
    'EN-850-01'=>'#FFE4C4','EN-850-02'=>'#FFD700',
];
$hat_sirasi = array_keys($hat_renkleri);

$vardiyalar = [
    'S' => ['etiket'=>'Sabah',    'baslangic'=>'08:00','bitis'=>'16:00','sure_sn'=>25200],
    'O' => ['etiket'=>'Öğleden', 'baslangic'=>'16:00','bitis'=>'24:00','sure_sn'=>25200],
    'G' => ['etiket'=>'Gece',    'baslangic'=>'00:00','bitis'=>'08:00','sure_sn'=>25200],
];

$f_gun_sayisi     = (int)($_POST['gun_sayisi']??21);
$f_vardiya_goster = $_POST['vardiya_goster'] ?? 'gun';
$secili_musteriler = array_filter((array)($_POST['musteriler']??[]));
// Devre dışı hatlar: checkbox ile seçilir, seçilmeyenler planlanmaz
$devre_disi_hatlar = array_filter((array)($_POST['devre_disi']??[]));
// Aktif hatlar = tüm hatlar - devre dışı
$aktif_plan_hatlari = array_diff($hat_sirasi, $devre_disi_hatlar);

// Müşteri listesi
$musteri_listesi = [];
try {
    $musteri_listesi = $db->query("SELECT DISTINCT musteri_firma_adi FROM siparis WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL AND musteri_firma_adi!='' ORDER BY musteri_firma_adi")->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e) {}

/* ═══════════════════════════════════════════════════
   PLANLAMA HESABI
═══════════════════════════════════════════════════ */
if ($form_gonderildi && $tiger_ok) {
try {
    $t0   = microtime(true);
    $bugun = date('Y-m-d');

    /* 1 ── Günleri oluştur: çalışma + tatil/pazar (gantt'ta gösterim için) */
    $calisma_gunleri = []; // plan yapılan günler
    $tum_gunler      = []; // gantt'ta görünen TÜM günler (tatil + pazar dahil)
    $tatil_gunleri   = []; // [tarih] = true (kırmızı arka plan için)
    $dt = new DateTime($bugun);
    $toplam_takvim = 0;
    while (count($calisma_gunleri) < $f_gun_sayisi) {
        $t_str = $dt->format('Y-m-d');
        $dow   = (int)$dt->format('N');
        $is_tatil = ($dow === 7 || in_array($t_str, $resmi_tatiller));
        $tum_gunler[] = $t_str;
        if ($is_tatil) {
            $tatil_gunleri[$t_str] = ($dow === 7) ? 'Pazar' : 'Tatil';
        } else {
            $calisma_gunleri[] = $t_str;
        }
        $dt->modify('+1 day');
        if (++$toplam_takvim > 60) break; // güvenlik limiti
    }

    /* 2 ── Sipariş → MRP → net üretim ihtiyacı */
    $mu_where = ''; $mu_par = ['Aktif'];
    if (!empty($secili_musteriler)) {
        $ph = implode(',', array_fill(0, count($secili_musteriler), '?'));
        $mu_where = "AND musteri_firma_adi IN ($ph)";
        $mu_par   = array_merge($mu_par, $secili_musteriler);
    }
    $s = $db->prepare("SELECT sip_kodu, DATE(sip_teslim_tarihi) AS tarih, SUM(sip_miktar-sip_sevk_miktari) AS kalan
        FROM siparis WHERE sip_statu=? AND (sip_miktar-sip_sevk_miktari)>0 AND sip_teslim_tarihi IS NOT NULL
        AND sip_teslim_tarihi<=DATE_ADD(CURDATE(),INTERVAL 3 MONTH) $mu_where
        GROUP BY sip_kodu,DATE(sip_teslim_tarihi) ORDER BY tarih");
    $s->execute($mu_par);
    $mamul_sip = [];
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $k = trim($r['sip_kodu']); if(!$k) continue;
        $mamul_sip[$k][$r['tarih']] = ($mamul_sip[$k][$r['tarih']]??0) + floatval($r['kalan']);
    }
    if (empty($mamul_sip)) { $hata='Aktif sipariş bulunamadı.'; goto son; }

    /* 3 ── Tiger: Mamül stokları */
    $ml = array_keys($mamul_sip);
    $ph = implode(',', array_fill(0, count($ml), '?'));
    $mamul_stok = [];
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS k,
        ISNULL(SUM(CASE WHEN S.INVENNO IN(0,1,5) THEN S.ONHAND ELSE 0 END),0) AS stok
        FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
        LEFT JOIN dbo.LV_222_02_STINVTOT S WITH(NOLOCK) ON S.STOCKREF=IT.LOGICALREF AND S.INVENNO IN(0,1,5)
        WHERE IT.CODE IN ($ph) GROUP BY IT.CODE");
    $r->execute($ml);
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) $mamul_stok[$x['k']] = floatval($x['stok']);

    /* 4 ── Tiger: Operasyon / cycle time / hat */
    // RUNTIME saniye/adet, is_ist_kodu EN- ile başlıyorsa enjeksiyon
    $r = $tigerdb_pdo->prepare("SELECT IT.CODE AS urun_kod, IT.NAME AS urun_adi,
        WRK.CODE AS hat_kodu,
        dbo.LG_INTTOTIME2(OPR.RUNTIME) AS proses_cevrimi,
        OPR.BATCHQUANTITY AS parti
        FROM dbo.LG_222_OPRTREQ AS OPR WITH(NOLOCK)
        LEFT OUTER JOIN dbo.LG_222_OPERTION AS OP  WITH(NOLOCK) ON OP.LOGICALREF  = OPR.OPERATIONREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WRK WITH(NOLOCK) ON WRK.LOGICALREF = OPR.WSREF
        LEFT OUTER JOIN dbo.LG_222_RTNGLINE AS RTL WITH(NOLOCK) ON RTL.OPERATIONREF = OP.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_ROUTING  AS RT  WITH(NOLOCK) ON RT.LOGICALREF  = RTL.ROUTINGREF
        LEFT OUTER JOIN dbo.LG_222_BOMREVSN AS BMR WITH(NOLOCK) ON BMR.ROUTINGREF = RT.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_BOMASTER AS BOM WITH(NOLOCK) ON BOM.LOGICALREF = BMR.BOMMASTERREF
        LEFT OUTER JOIN dbo.LG_222_BOMLINE  AS BML WITH(NOLOCK) ON BMR.LOGICALREF = BML.BOMREVREF AND BML.LINETYPE <> 4
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  WITH(NOLOCK) ON IT.LOGICALREF  = BOM.MAINPRODREF
        WHERE IT.CODE IN ($ph)
          AND WRK.CODE LIKE 'EN-%'
          AND OP.CODE <> 'SKOP.001'
          AND IT.CODE IS NOT NULL
          AND IT.CODE NOT LIKE 'H-%'
          AND OPR.RUNTIME > 0
        GROUP BY IT.CODE, IT.NAME, WRK.CODE, OPR.RUNTIME, OPR.BATCHQUANTITY
        ORDER BY IT.CODE, WRK.CODE");
    $r->execute($ml);

    // operasyon_map[urun_kod] = ['ana_hat'=>hat, 'hatlar'=>[hat1,hat2,...], 'runtime'=>sn, 'parti'=>n, 'kapasite'=>adet/vardiya]
    // Kapasite: 25200 sn / (RUNTIME / BATCHQUANTITY) = kaç BATCH/vardiya × BATCHQUANTITY = adet/vardiya
    $operasyon_map = [];
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $x) {
        if (!isset($hat_renkleri[$x['hat_kodu']])) continue;
        $parti    = max(1, floatval($x['parti']));
        $cycle_sn = floatval($x['proses_cevrimi']);  // saniye - direkt kullan
        if ($cycle_sn <= 0) continue;


        // (3600 / cycle_sn) × parti × 7
        $kapasite = (int)floor((3600.0 / $cycle_sn) * $parti * 7);
        if ($kapasite < 1) $kapasite = 1;
        $cycle_time_sn = $cycle_sn / max(1, $parti);

        if (!isset($operasyon_map[$x['urun_kod']])) {
            $operasyon_map[$x['urun_kod']] = [
                'ana_hat'    => $x['hat_kodu'],
                'hatlar'     => [$x['hat_kodu']],
                'adi'        => $x['urun_adi'],
                'parti'      => $parti,
                'cycle_sn'   => $cycle_time_sn,
                'kapasite'   => $kapasite,
            ];
        } else {
            // Alternatif hat ekle
            if (!in_array($x['hat_kodu'], $operasyon_map[$x['urun_kod']]['hatlar'])) {
                $operasyon_map[$x['urun_kod']]['hatlar'][] = $x['hat_kodu'];
            }
        }
    }

    /* 5 ── Net üretim ihtiyacı (MRP mantığı) */
    // net_ihtiyac[urun_kod] = toplam üretilmesi gereken (stok düşülmüş)
    // ── Net ihtiyacı haftalık dilimlere böl ──────────────────────────
    // Her ürün için: hangi hafta ne kadar üretilmeli?
    // Hafta: Pazartesi bazlı (ISO week)
    function haftaBasi($tarih_str) {
        $dt = new DateTime($tarih_str);
        $dow = (int)$dt->format('N'); // 1=Pzt...7=Paz
        $dt->modify('-'.($dow-1).' days');
        return $dt->format('Y-m-d');
    }

    $net_ihtiyac = []; // [mk] = {adi, hat, hatlar, kapasite, cycle_sn, haftalik_ihtiyac[], ilk_eksik, kalan_net}

    foreach($mamul_sip as $mk => $tarih_map) {
        if (!isset($operasyon_map[$mk])) continue;
        $stok    = $mamul_stok[$mk] ?? 0;
        $kum_sip = 0;
        $ilk_eksik_tarih = null;
        $haftalik = []; // [hafta_basi] = net_miktar

        ksort($tarih_map);
        foreach($tarih_map as $tarih => $sip) {
            $kum_sip += $sip;
            $net_stok = $stok - $kum_sip;
            // Net ihtiyaç bu sipariş için
            if ($net_stok < 0) {
                $once = $net_stok + $sip;
                $net_gun = ($once >= 0) ? abs($net_stok) : $sip;
            } else {
                $net_gun = 0;
            }
            if ($net_gun > 0) {
                if (!$ilk_eksik_tarih) $ilk_eksik_tarih = $tarih;
                $hb = haftaBasi($tarih);
                $haftalik[$hb] = ($haftalik[$hb] ?? 0) + $net_gun;
            }
        }
        if (empty($haftalik)) continue;
        ksort($haftalik);

        $net_ihtiyac[$mk] = [
            'adi'      => $operasyon_map[$mk]['adi'],
            'hat'      => $operasyon_map[$mk]['ana_hat'],
            'hatlar'   => $operasyon_map[$mk]['hatlar'],
            'kapasite' => $operasyon_map[$mk]['kapasite'],
            'cycle_sn' => $operasyon_map[$mk]['cycle_sn'],
            'parti'    => $operasyon_map[$mk]['parti'],
            'haftalik' => $haftalik,                         // [hafta_basi => miktar]
            'ilk_eksik'=> $ilk_eksik_tarih ?? $bugun,
            'toplam_net'=> array_sum($haftalik),
            'kalan_net' => array_sum($haftalik),
        ];
    }

    /* 6 ── Planlama kuyruğu: haftalık dilimler önceliğe göre sıralanır
       Her hafta dilimi bağımsız bir iş = {mk, hafta, miktar}
       İlk eksik tarihi en yakın olan önce planlanır
       Bir haftalık iş bittikten sonra aynı hattaki sonraki hafta yerine
       daha acil başka ürünün haftasına geçilir ─────────────────────── */
    $is_kuyrugu = []; // [{mk, hafta, miktar, ilk_eksik, kapasite, cycle_sn, hatlar, adi}]
    foreach($net_ihtiyac as $mk => $ih) {
        foreach($ih['haftalik'] as $hafta => $miktar) {
            $is_kuyrugu[] = [
                'mk'       => $mk,
                'adi'      => $ih['adi'],
                'hafta'    => $hafta,               // bu işin teslim haftası
                'miktar'   => $miktar,
                'kalan'    => $miktar,
                'ilk_eksik'=> $ih['ilk_eksik'],     // ürünün ilk eksik tarihi (öncelik için)
                'kapasite' => $ih['kapasite'],
                'cycle_sn' => $ih['cycle_sn'],
                'hatlar'   => $ih['hatlar'],
                'ana_hat'  => $ih['hat'],
            ];
        }
    }
    // Öncelik sıralaması:
    // 1. Bu ay veya geçmiş ilk_eksik → en önce (acil)
    // 2. Aynı ay içinde: ilk_eksik ASC, hafta ASC
    // 3. Sonraki ay işleri araya sıkıştırılmadan önce bu ay bitirilir
    $bu_ay_son = date('Y-m-t'); // bu ayın son günü

    usort($is_kuyrugu, function($a,$b) use ($bu_ay_son){
        // Bu ay bitirilmesi gereken mi?
        $a_acil = ($a['ilk_eksik'] <= $bu_ay_son) ? 0 : 1;
        $b_acil = ($b['ilk_eksik'] <= $bu_ay_son) ? 0 : 1;
        if ($a_acil !== $b_acil) return $a_acil - $b_acil;
        // Aynı öncelik grubunda: ilk_eksik ASC
        $cmp = strcmp($a['ilk_eksik'], $b['ilk_eksik']);
        return $cmp !== 0 ? $cmp : strcmp($a['hafta'], $b['hafta']);
    });

    // İki aşamalı plan:
    // AŞAMA 1: Sadece bu aya ait (acil) işleri planla
    // AŞAMA 2: Planda boş kalan yerlere sonraki ay işlerini yerleştir
    // Bu mantık kuyruk sıralamasıyla otomatik çalışır - acil işler önce atanır

    /* 7 ── Gantt planla: her çalışma günü için hatları doldur */
    // hat_doluluk[hat_kodu][tarih][vardiya] = kalan_kapasite (adet)
    $plan_gunler = []; // [tarih][hat][vardiya] = görev listesi
    $plan_liste  = []; // düz liste

    // Hat kuyruğu: her hat için kalan saniye kapasitesi (vardiya bazlı sıralı kuyruk)
    // hat_kuyruk[hat] = sıradaki boş konum (gun_idx, vardiya_idx, kalan_sn)
    $hat_kuyruk = [];
    foreach($aktif_plan_hatlari as $hat) {
        $hat_kuyruk[$hat] = [
            'gun_idx'  => 0,   // $calisma_gunleri dizisindeki index
            'var_idx'  => 0,   // 0=S, 1=O, 2=G
            'kalan_sn' => 25200, // bu vardiyadaki kalan saniye
        ];
    }
    $var_keys = array_keys($vardiyalar); // ['S','O','G']

    // Bir hattaki bir sonraki boş vardiyaya ilerle
    function hatIlerle(&$kuyruk, $hat, $calisma_gunleri, $var_keys) {
        $kuyruk[$hat]['var_idx']++;
        if ($kuyruk[$hat]['var_idx'] >= count($var_keys)) {
            $kuyruk[$hat]['var_idx'] = 0;
            $kuyruk[$hat]['gun_idx']++;
        }
        $kuyruk[$hat]['kalan_sn'] = 25200;
    }

    foreach($is_kuyrugu as &$is) {
        $mk       = $is['mk'];
        $hatlar   = $is['hatlar'];
        $kapasite = $is['kapasite'];
        $cycle_sn = $is['cycle_sn'];
        $kalan    = &$is['kalan'];

        // Min 1 vardiya: az miktarlı işi en az 1 tam vardiya üret
        $uretilecek = max($kalan, $kapasite);

        // En erken boş vardiyanın hattını seç (önce ana hat)
        $seçilen_hat = null;
        $en_erken_gun = PHP_INT_MAX;
        $en_erken_var = PHP_INT_MAX;
        foreach($hatlar as $h) {
            if (!isset($hat_kuyruk[$h])) continue;
            $gi = $hat_kuyruk[$h]['gun_idx'];
            $vi = $hat_kuyruk[$h]['var_idx'];
            if ($gi >= count($calisma_gunleri)) continue;
            if ($gi < $en_erken_gun || ($gi === $en_erken_gun && $vi < $en_erken_var)) {
                $en_erken_gun = $gi;
                $en_erken_var = $vi;
                $seçilen_hat = $h;
            }
        }
        if (!$seçilen_hat) { continue; }

        // Ürünü seçilen hatta, vardiyanın kalan süresi boyunca üret
        // Ardışık vardiyalara devam et, bitmeden diğer ürüne geçme
        while ($uretilecek > 0) {
            $gun_idx = $hat_kuyruk[$seçilen_hat]['gun_idx'];
            $var_idx = $hat_kuyruk[$seçilen_hat]['var_idx'];
            if ($gun_idx >= count($calisma_gunleri)) break;

            $gun       = $calisma_gunleri[$gun_idx];
            $v         = $var_keys[$var_idx];
            $kalan_sn  = $hat_kuyruk[$seçilen_hat]['kalan_sn'];

            // Bu vardiyada üretilebilecek adet
            $vardiya_adet = (int)floor($kalan_sn / $cycle_sn);
            if ($vardiya_adet < 1) {
                // Bu vardiya doldu, bir sonrakine geç
                hatIlerle($hat_kuyruk, $seçilen_hat, $calisma_gunleri, $var_keys);
                continue;
            }

            $bu_uretim     = min($uretilecek, $vardiya_adet);
            $kullanilan_sn = (int)ceil($bu_uretim * $cycle_sn);
            $hat_kuyruk[$seçilen_hat]['kalan_sn'] -= $kullanilan_sn;
            $uretilecek   -= $bu_uretim;
            $kalan        -= $bu_uretim;
            if ($kalan < 0) $kalan = 0;

            $doluluk_pct = round(($kullanilan_sn / 25200) * 100);
            if (!isset($plan_gunler[$gun][$seçilen_hat][$v])) {
                $plan_gunler[$gun][$seçilen_hat][$v] = [];
            }
            $plan_gunler[$gun][$seçilen_hat][$v][] = [
                'urun_kodu'  => $mk,
                'urun_adi'   => $is['adi'],
                'miktar'     => $bu_uretim,
                'kapasite'   => $kapasite,
                'cycle_sn'   => $cycle_sn,
                'doluluk'    => $doluluk_pct,
                'alternatif' => ($seçilen_hat !== $is['ana_hat']),
            ];
            $plan_liste[] = [
                'tarih'      => $gun,
                'hat'        => $seçilen_hat,
                'vardiya'    => $v,
                'urun_kodu'  => $mk,
                'urun_adi'   => $is['adi'],
                'miktar'     => $bu_uretim,
                'kapasite'   => $kapasite,
                'ilk_eksik'  => $is['ilk_eksik'],
                'alternatif' => ($seçilen_hat !== $is['ana_hat']),
            ];

            // Vardiya doldu mu? Bir sonrakine geç
            if ($hat_kuyruk[$seçilen_hat]['kalan_sn'] < $cycle_sn) {
                hatIlerle($hat_kuyruk, $seçilen_hat, $calisma_gunleri, $var_keys);
            }
        }

    }
    unset($is);

    // net_ihtiyac kalan_net güncelle (kalan listesi için)
    foreach($is_kuyrugu as $is) {
        if (isset($net_ihtiyac[$is['mk']])) {
            $net_ihtiyac[$is['mk']]['kalan_net'] -= ($is['miktar'] - $is['kalan']);
        }
    }

    $execution_time = round(microtime(true)-$t0, 2);

} catch(Throwable $e) { $hata = $e->getMessage(); }
son:;
}
$bugun_str = date('Y-m-d');
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 Ana Üretim Planı (MPS)</h1>
    <div class="s-yol">Planlama / <b>MPS — Enjeksiyon Hatları</b>
      <?php if(!empty($plan_gunler)): ?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● <?php echo count($calisma_gunleri??[]); ?> gün / <?php echo $execution_time; ?>s</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<style>
.mps-kart { background:var(--kart);border:1px solid var(--kenar);border-radius:12px;padding:16px 20px;margin-bottom:10px; }
/* Gantt */
.mps-wrap { overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 280px); }
.mps-table { border-collapse:collapse;font-size:11px;white-space:nowrap; }
.mps-table th { background:#2d5986;color:#e0f0ff;padding:5px 8px;border:1px solid #3b6fa3;position:sticky;top:0;z-index:3;font-size:10px; }
.mps-table th.hat-th { position:sticky;left:0;z-index:4;min-width:100px;text-align:left; }
.mps-table td { padding:2px 4px;border:1px solid #E2E8F0;vertical-align:top;min-width:90px; }
.mps-table td.hat-td { position:sticky;left:0;z-index:2;font-weight:700;font-size:11px;padding:4px 8px;border-right:2px solid #CBD5E1; }
.mps-table tbody tr:hover td { filter:brightness(0.96); }
/* Görev kartı */
.gorev-kart { border-radius:4px;padding:2px 5px;margin:1px 0;font-size:10px;line-height:1.4;border-left:3px solid rgba(0,0,0,.15); }
.gorev-kart .gk-kod { font-weight:700;font-size:10px; }
.gorev-kart .gk-adet { font-size:9px;opacity:.85; }
/* Merdiven (waterfall) düzeni */
.mps-hat-satirlari { display:flex;flex-direction:column;gap:0; }
.mps-gun-satiri { display:flex;align-items:stretch; }
.mps-is-hucre { min-width:90px;padding:2px 3px;border-right:1px solid #E2E8F0;flex-shrink:0; }
.mps-is-bos   { min-width:90px;padding:2px 3px;border-right:1px solid #E2E8F0;flex-shrink:0;background:#FAFAFA; }
/* Vardiya şeridi */
.v-serit { display:flex;gap:1px;margin-bottom:1px; }
.v-badge { font-size:8px;font-weight:700;padding:1px 3px;border-radius:2px;background:rgba(0,0,0,.08); }
/* Boş hat */
.bos-hat td { opacity:.5; }
/* Doluluk bar */
.doluluk-bar { height:3px;background:#E2E8F0;border-radius:2px;margin-top:2px; }
.doluluk-fill { height:3px;border-radius:2px;background:linear-gradient(90deg,#22C55E,#F97316 80%,#EF4444); }
/* Btn */
.btn-dt { background:#2d5986!important;color:#fff!important;border:none!important;border-radius:4px!important;padding:5px 12px!important;font-size:12px!important;margin-right:4px!important;cursor:pointer; }
.btn-dt:hover { background:#1e3a5f!important; }
/* Bugün kolonu */
.bugun-kol { border-left:2px solid #3B82F6!important;border-right:2px solid #3B82F6!important; }
</style>

<div class="s-body">
<?php if(!empty($hata)): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<!-- Filtre -->
<div class="mps-kart">
  <div style="font-size:13px;font-weight:800;color:var(--t);margin-bottom:12px;text-transform:uppercase;letter-spacing:.03em">🏭 MPS Filtresi — Enjeksiyon Hatları</div>
  <form method="POST" id="mpsForm" action="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-mps">
    <div style="display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap">
      <div style="flex:1;min-width:220px">
        <label class="form-etiket">Müşteri <span style="color:var(--m2);font-weight:400">(Boş = tümü)</span></label>
        <select id="mps_musteri" name="musteriler[]" multiple placeholder="Müşteri seçin..." autocomplete="off">
          <?php foreach($musteri_listesi as $m): ?>
          <option value="<?php echo htmlspecialchars($m); ?>" <?php echo in_array($m,$secili_musteriler)?'selected':''; ?>><?php echo htmlspecialchars($m); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="min-width:120px">
        <label class="form-etiket">Plan Süresi</label>
        <select name="gun_sayisi" class="form-alan">
          <?php foreach([7=>'1 Hafta',14=>'2 Hafta',21=>'3 Hafta',30=>'1 Ay'] as $v=>$l): ?>
          <option value="<?php echo $v;?>" <?php echo $f_gun_sayisi==$v?'selected':'';?>><?php echo $l;?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="min-width:130px">
        <label class="form-etiket">Görünüm</label>
        <select name="vardiya_goster" class="form-alan">
          <option value="gun" <?php echo $f_vardiya_goster==='gun'?'selected':'';?>>Günlük Özet</option>
          <option value="vardiya" <?php echo $f_vardiya_goster==='vardiya'?'selected':'';?>>Vardiya Detay</option>
        </select>
      </div>
      <div style="display:flex;gap:8px;padding-bottom:2px">
        <button type="submit" name="mps_calistir" style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:10px 22px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">▶ Plan Oluştur</button>
        <button type="button" onclick="mpsSel.clear();document.getElementById('mpsForm').submit();" style="background:var(--bg);color:var(--m);border:1px solid var(--kenar);padding:10px 14px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;font-size:13px">✕</button>
      </div>
    </div>
    <!-- Hat seçimi -->
    <div style="margin-top:14px;border-top:1px solid var(--kenar);padding-top:12px">
      <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px">⚙️ Devre Dışı Hatlar <span style="font-weight:400">(işaretlenenler plana dahil edilmez)</span></div>
      <div style="display:flex;flex-wrap:wrap;gap:4px">
        <?php foreach($hat_sirasi as $hat): ?>
        <label style="display:flex;align-items:center;gap:4px;padding:3px 8px;border-radius:5px;border:1px solid var(--kenar);cursor:pointer;font-size:11px;background:<?php echo $hat_renkleri[$hat]??'#F8FAFC';?>;user-select:none"
               title="<?php echo $hat;?>">
          <input type="checkbox" name="devre_disi[]" value="<?php echo $hat;?>"
                 <?php echo in_array($hat,$devre_disi_hatlar)?'checked':'';?>
                 style="width:12px;height:12px;cursor:pointer">
          <?php echo $hat;?>
        </label>
        <?php endforeach;?>
      </div>
      <div style="margin-top:6px;font-size:11px;color:var(--m2)">
        <button type="button" onclick="document.querySelectorAll('[name='devre_disi[]']').forEach(c=>c.checked=false)" style="font-size:11px;background:none;border:none;color:#3B82F6;cursor:pointer;padding:0">Tümünü seç</button>
        &nbsp;|&nbsp;
        <button type="button" onclick="document.querySelectorAll('[name='devre_disi[]']').forEach(c=>c.checked=true)" style="font-size:11px;background:none;border:none;color:#EF4444;cursor:pointer;padding:0">Tümünü devre dışı</button>
      </div>
    </div>
  </form>
</div>

<?php if(!$form_gonderildi): ?>
<div style="padding:50px;text-align:center;color:var(--m2);background:var(--bg);border-radius:12px;border:2px dashed var(--kenar)">
  <div style="font-size:36px;margin-bottom:12px">🏭</div>
  <div style="font-size:15px;font-weight:700;color:var(--t)">Plan Oluşturulmadı</div>
  <div style="font-size:13px;margin-top:6px">Filtre seçip <strong>Plan Oluştur</strong> butonuna tıklayın.</div>
</div>

<?php elseif(empty($plan_gunler) && empty($hata)): ?>
<div style="padding:40px;text-align:center;color:var(--m2)">Planlanacak üretim bulunamadı.</div>

<?php else:

// Aktif hatları belirle (en az 1 görevi olan)
$aktif_hatlar = [];
foreach($hat_sirasi as $hat) {
    foreach(($calisma_gunleri??[]) as $gun) {
        if (!empty($plan_gunler[$gun][$hat])) { $aktif_hatlar[$hat]=true; break; }
    }
}

// Özet
$toplam_gorev = 0; $toplam_hat = count($aktif_hatlar);
foreach($plan_gunler as $pg) foreach($pg as $ph) foreach($ph as $pv) $toplam_gorev += count($pv);
?>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-bottom:10px">
<?php foreach([
  ['🏭 Aktif Hat',$toplam_hat,'#DBEAFE','#1E40AF'],
  ['📋 Toplam Görev',$toplam_gorev,'#D1FAE5','#065F46'],
  ['📅 Plan Günü',count($calisma_gunleri??[]),'#FEF3C7','#92400E'],
  ['⏱ Süre',$execution_time.'s','#F3F4F6','#374151'],
] as [$l,$v,$bg,$fg]): ?>
<div style="background:<?php echo $bg;?>;border-radius:8px;padding:10px 12px;text-align:center">
  <div style="font-size:11px;color:<?php echo $fg;?>;font-weight:600;margin-bottom:2px"><?php echo $l;?></div>
  <div style="font-size:20px;font-weight:800;color:<?php echo $fg;?>"><?php echo $v;?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Gantt -->
<div class="mps-kart" style="padding:0;overflow:hidden">
<div class="mps-wrap">
<table class="mps-table">
<thead>
  <tr>
    <th class="hat-th" rowspan="2">Hat</th>
    <?php foreach(($tum_gunler??[]) as $gun):
      $is_today = ($gun===$bugun_str);
      $is_tatil_gun = isset($tatil_gunleri[$gun]);
      $span = $f_vardiya_goster==='vardiya' ? 3 : 1;
      $gun_dt = new DateTime($gun);
      $gun_label = $gun_dt->format('d.m').PHP_EOL.'('.['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$gun_dt->format('N')-1].')';
    ?>
    <?php
      $th_bg = $is_today ? 'background:#1E40AF;' : ($is_tatil_gun ? 'background:#DC2626;' : '');
    ?>
    <th colspan="<?php echo $span;?>" class="<?php echo $is_today?'bugun-kol':'';?>" style="text-align:center;<?php echo $th_bg;?>">
      <?php echo date('d.m',strtotime($gun));?><br>
      <?php $dow_lbl = ['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][(int)(new DateTime($gun))->format('N')-1]; ?>
      <span style="font-size:9px;opacity:.85"><?php echo $dow_lbl;?></span>
      <?php if($is_today): ?><br><span style="font-size:8px;background:#FCD34D;color:#1E40AF;border-radius:2px;padding:0 3px">BUGÜN</span><?php endif;?>
      <?php if($is_tatil_gun): ?><br><span style="font-size:8px;background:rgba(255,255,255,.3);border-radius:2px;padding:0 3px"><?php echo $tatil_gunleri[$gun];?></span><?php endif;?>
    </th>
    <?php endforeach; ?>
  </tr>
  <?php if($f_vardiya_goster==='vardiya'): ?>
  <tr>
    <th class="hat-th" style="background:transparent;top:auto"></th>
    <?php foreach(($tum_gunler??[]) as $gun): foreach(['S'=>'08-16','O'=>'16-24','G'=>'00-08'] as $v=>$vl): ?>
    <th style="font-size:9px;font-weight:600;min-width:70px"><?php echo $vl;?></th>
    <?php endforeach; endforeach; ?>
  </tr>
  <?php endif; ?>
</thead>
<tbody>
<?php
// ─── Merdiven (waterfall) düzeni ───────────────────────────────────────
// Her hat için işleri günlere göre sıralı "iş sıraları" oluştur
// Aynı ürün ardışık günlerde devam ediyorsa → aynı satır
// Farklı ürün başlayınca → yeni satır (bir kademe aşağı)

foreach($hat_sirasi as $hat):
  $hat_renk  = $hat_renkleri[$hat] ?? '#F8FAFC';
  $hat_aktif = isset($aktif_hatlar[$hat]);

  // Bu hat için gün başına aktif ürün listesi
  // [gun][siralama_index] = {urun_kodu, miktar, alt, cycle_sn, doluluk}
  // "siralama_index": 0 = ana iş, 1 = devam eden ikinci iş, vb.
  $hat_gun_isler = []; // [gun] = [urun_kodu => {miktar, alt, ...}] sıralı
  foreach(($tum_gunler??[]) as $gun) {
    $gun_isler = [];
    foreach(['S','O','G'] as $v) {
      foreach(($plan_gunler[$gun][$hat][$v]??[]) as $g) {
        $uk = $g['urun_kodu'];
        if (!isset($gun_isler[$uk])) $gun_isler[$uk] = ['miktar'=>0,'alt'=>$g['alternatif'],'cycle_sn'=>$g['cycle_sn']??0,'doluluk'=>0];
        $gun_isler[$uk]['miktar']  += floatval($g['miktar']);
        $gun_isler[$uk]['doluluk'] += $g['doluluk'];
      }
    }
    $hat_gun_isler[$gun] = $gun_isler;
  }

  // Merdiven sıraları: her ürün bir önceki ürünün başladığı satırın BİR ALTINA iner
  // Algoritma: her ürün başladığında o ana kadar hangi sıra en erken boş olmuş?
  // "Boş" = o ürünün son çalıştığı günden sonra başka iş yok
  // Yeni ürün → önceki ürünün sırasının bir altı = yeni sıra
  $sira_map     = []; // [urun_kodu] = sira_index
  $sira_bitis   = []; // [sira_index] = son_gun_index (o sıranın son dolu günü)
  $uk_baslangic = []; // [urun_kodu] = ilk_gun_index

  // Önce her ürünün hangi günlerde çalıştığını bul
  $uk_gunler = []; // [urun_kodu] = [gun_index, ...]
  foreach(($tum_gunler??[]) as $gi => $gun) {
    foreach($hat_gun_isler[$gun] as $uk => $d) {
      $uk_gunler[$uk][] = $gi;
    }
  }

  // Ürünleri ilk göründükleri güne göre sırala
  $uk_sirali = array_keys($uk_gunler);
  usort($uk_sirali, function($a,$b) use ($uk_gunler) {
    return ($uk_gunler[$a][0]??0) - ($uk_gunler[$b][0]??0);
  });

  $mevcut_sira = -1;
  foreach($uk_sirali as $uk) {
    $mevcut_sira++;
    $sira_map[$uk]   = $mevcut_sira;
    $son_gun         = max($uk_gunler[$uk]);
    $sira_bitis[$mevcut_sira] = $son_gun;
  }

  $toplam_sira = $mevcut_sira + 1;
  if (!$hat_aktif) $toplam_sira = 0;

  // Hat başlık satırı
  echo '<tr>';
  echo '<td class="hat-td" style="background:'.$hat_renk.';vertical-align:top;'.( $toplam_sira > 1 ? 'border-bottom:2px solid #94A3B8;' : '').'" rowspan="'.max(1,$toplam_sira).'">';
  echo '<div style="font-size:11px;font-weight:800;color:#1E293B">'.$hat.'</div>';
  if ($toplam_sira > 1) echo '<div style="font-size:9px;color:#64748B;margin-top:2px">'.$toplam_sira.' iş sırası</div>';
  echo '</td>';

  if ($toplam_sira == 0) {
    // Boş hat - tum_gunler üzerinden (tatil dahil)
    foreach(($tum_gunler??[]) as $gun) {
      $is_today   = ($gun===$bugun_str);
      $is_tatil_g = isset($tatil_gunleri[$gun]);
      $brd = $is_today ? 'border-left:2px solid #3B82F6;border-right:2px solid #3B82F6;' : '';
      if ($is_tatil_g) {
        echo '<td style="'.$brd.'background:#FEE2E2;text-align:center;color:#DC2626;font-size:9px">'.htmlspecialchars($tatil_gunleri[$gun]).'</td>';
      } else {
        echo '<td style="'.$brd.'text-align:center;color:#CBD5E1;font-size:9px">—</td>';
      }
    }
    echo '</tr>';
    continue;
  }

  // Her sıra için bir tr satırı
  for ($sira=0; $sira < $toplam_sira; $sira++) {
    // İlk sıra: hat-td zaten echo edildi, diğerleri için yeni tr
    if ($sira > 0) echo '<tr>';

    foreach(($tum_gunler??[]) as $gun) {
      $is_today   = ($gun===$bugun_str);
      $brd        = $is_today ? 'border-left:2px solid #3B82F6;border-right:2px solid #3B82F6;' : '';
      $is_tatil_g = isset($tatil_gunleri[$gun]);

      if ($is_tatil_g && $sira==0) {
        $rs = max(1, $toplam_sira);
        echo '<td style="'.$brd.'background:#FEE2E2;text-align:center;color:#DC2626;font-size:10px;font-weight:700;vertical-align:middle;border-top:2px solid #FCA5A5;border-bottom:2px solid #FCA5A5;" rowspan="'.$rs.'">'.htmlspecialchars($tatil_gunleri[$gun]).'</td>';
      } elseif ($is_tatil_g) {
        // rowspan ile kapsandı - atla
      } else {
        // Bu sıradaki ürün bu günde var mı?
        $bu_sira_uk = null;
        foreach($sira_map as $uk=>$si) {
          if ($si === $sira && isset($hat_gun_isler[$gun][$uk])) {
            $bu_sira_uk = $uk; break;
          }
        }
        $bot_brd = ($sira < $toplam_sira-1) ? 'border-bottom:1px dashed #CBD5E1;' : '';
        echo '<td style="'.$brd.$bot_brd.'">';
        if ($bu_sira_uk) {
          $d = $hat_gun_isler[$gun][$bu_sira_uk];
          $alt_badge = $d['alt'] ? '<span style="font-size:8px;background:#FEF3C7;color:#92400E;border-radius:2px;padding:0 3px">ALT</span> ' : '';
          echo '<div class="gorev-kart" style="background:'.$hat_renk.($d['alt']?';border-left-color:#F97316':'').'">';
          echo '<div class="gk-kod">'.$alt_badge.htmlspecialchars(substr($bu_sira_uk,0,13)).'</div>';
          echo '<div class="gk-adet">'.number_format($d['miktar'],0,',','.').' ad | '.round($d['cycle_sn'],1).'sn</div>';
          $dol = min(100, $d['doluluk']);
          if ($dol>0) echo '<div class="doluluk-bar"><div class="doluluk-fill" style="width:'.$dol.'%"></div></div>';
          echo '</div>';
        } else {
          echo '<div style="color:#E2E8F0;font-size:9px;text-align:center;padding:3px">·</div>';
        }
        echo '</td>';
      }
    }
    echo '</tr>';
  }

endforeach; ?>
</tbody>
</table>
</div>
</div>

<!-- Planlama özeti: kalanlar -->
<?php
$kalan_var = false;
foreach(($net_ihtiyac??[]) as $mk=>$ih) { if($ih['kalan_net']>0){$kalan_var=true;break;} }
if($kalan_var): ?>
<div class="mps-kart" style="margin-top:10px">
  <div style="font-size:12px;font-weight:700;color:#991B1B;margin-bottom:8px">⚠️ Plan dönemine sığmayan üretimler
    <span style="font-weight:400;color:var(--m2);font-size:11px"> — Bu ay bitirilmesi gerekenler 🔴 ile işaretlidir</span>
  </div>
  <table class="tablo" style="width:100%">
    <thead><tr><th>Ürün Kodu</th><th>Ürün Adı</th><th>Hat</th><th>İlk İhtiyaç</th><th style="text-align:right">Kalan Miktar</th><th style="text-align:right">Kapasite/Vardiya</th></tr></thead>
    <tbody>
    <?php foreach(($net_ihtiyac??[]) as $mk=>$ih): if($ih['kalan_net']<=0) continue; ?>
    <tr>
      <td><code style="font-size:11px;background:var(--bg);padding:1px 5px;border-radius:3px"><?php echo htmlspecialchars($mk);?></code></td>
      <td style="font-size:12px"><?php echo htmlspecialchars($ih['adi']);?></td>
      <td><span style="background:<?php echo $hat_renkleri[$ih['hat']]??'#F3F4F6';?>;padding:2px 7px;border-radius:4px;font-weight:700;font-size:11px"><?php echo htmlspecialchars($ih['hat']);?></span></td>
      <td style="white-space:nowrap;font-weight:700;color:#EF4444"><?php echo $ih['ilk_eksik'] ? date('d.m.Y',strtotime($ih['ilk_eksik'])) : '—';?></td>
      <td style="text-align:right;font-weight:700;color:#991B1B"><?php echo number_format(floatval($ih['kalan_net']),0,',','.');?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo number_format(floatval($ih['kapasite']),0,',','.');?> ad/vardiya</td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php endif; ?>
</div>

<!-- Tom Select -->
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
<script>
var mpsSel = new TomSelect('#mps_musteri',{plugins:['remove_button'],placeholder:'Müşteri seçin...',maxOptions:500});
</script>
<style>
.ts-wrapper.multi .ts-control,.ts-wrapper.single .ts-control { background:#fff!important;border:1px solid var(--kenar)!important;border-radius:8px!important; }
.ts-dropdown { background:#fff!important;border:1px solid var(--kenar)!important;color:#1e293b!important; }
.ts-dropdown .option { background:#fff!important;color:#1e293b!important; }
.ts-dropdown .option:hover,.ts-dropdown .option.active { background:#EFF6FF!important;color:#1E40AF!important; }
.ts-control .item { background:#DBEAFE!important;color:#1E40AF!important;border-radius:4px!important;font-weight:600; }
</style>
