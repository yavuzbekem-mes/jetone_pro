<?php
ob_start();
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$kul     = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

// ── TABLO OLUŞTUR ────────────────────────────────────────────────
try { $db->exec("CREATE TABLE IF NOT EXISTS manuel_bom (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mamul_kodu VARCHAR(100) NOT NULL, mamul_adi VARCHAR(500) DEFAULT '',
    alt_kodu VARCHAR(100) NOT NULL, alt_adi VARCHAR(500) DEFAULT '',
    miktar DECIMAL(10,4) NOT NULL DEFAULT 1.0000, birim VARCHAR(20) DEFAULT 'ADET',
    notlar VARCHAR(255) DEFAULT NULL, guncelleyen VARCHAR(100) DEFAULT NULL,
    guncelleme DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_mamul (mamul_kodu), INDEX idx_alt (alt_kodu)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci"); } catch(Throwable $e) {}

// ── AJAX POST ────────────────────────────────────────────────────
if (!empty($_POST['mb_action'])) {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['mb_action'];

    if ($action === 'ekle') {
        $mamul_kodu = trim($_POST['mamul_kodu'] ?? '');
        $mamul_adi  = trim($_POST['mamul_adi']  ?? '');
        $alt_kodu   = trim($_POST['alt_kodu']   ?? '');
        $alt_adi    = trim($_POST['alt_adi']    ?? '');
        $miktar     = (float)str_replace(',', '.', $_POST['miktar'] ?? 1);
        $birim      = trim($_POST['birim'] ?? 'ADET');
        $notlar     = trim($_POST['notlar'] ?? '');
        if (!$mamul_kodu || !$alt_kodu) { echo json_encode(['ok'=>false,'msg'=>'Mamul ve alt malzeme kodu zorunlu']); exit; }
        if ($miktar <= 0) { echo json_encode(['ok'=>false,'msg'=>'Miktar 0\'dan büyük olmalı']); exit; }
        try {
            $db->prepare("INSERT INTO manuel_bom (mamul_kodu,mamul_adi,alt_kodu,alt_adi,miktar,birim,notlar,guncelleyen)
                VALUES (?,?,?,?,?,?,?,?)")
                ->execute([$mamul_kodu,$mamul_adi,$alt_kodu,$alt_adi,$miktar,$birim,$notlar,$kul_adi]);
            echo json_encode(['ok'=>true,'id'=>$db->lastInsertId()]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'guncelle') {
        $id     = (int)($_POST['id'] ?? 0);
        $alan   = trim($_POST['alan'] ?? '');
        $deger  = trim($_POST['deger'] ?? '');
        $izinli = ['mamul_kodu','mamul_adi','alt_kodu','alt_adi','miktar','birim','notlar'];
        if (!$id || !in_array($alan,$izinli,true)) { echo json_encode(['ok'=>false]); exit; }
        if ($alan === 'miktar') $deger = (float)str_replace(',','.',$deger);
        try {
            $db->prepare("UPDATE manuel_bom SET `$alan`=?, guncelleyen=? WHERE id=?")
               ->execute([$deger,$kul_adi,$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'sil') {
        $ids = array_filter(array_map('intval', explode(',', $_POST['ids'] ?? '')));
        if (empty($ids)) { echo json_encode(['ok'=>false]); exit; }
        try {
            $ph = implode(',', array_fill(0,count($ids),'?'));
            $db->prepare("DELETE FROM manuel_bom WHERE id IN($ph)")->execute(array_values($ids));
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }

    if ($action === 'tiger_ara') {
        // Tiger'dan stok kodu ara
        $q = trim($_POST['q'] ?? '');
        if (strlen($q) < 2) { echo json_encode(['ok'=>true,'sonuclar',[]]); exit; }
        try {
            if ($tigerdb_pdo) {
                $stmt = $tigerdb_pdo->prepare("SELECT TOP 20 IT.CODE, IT.NAME, IT.STGRPCODE
                    FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
                    WHERE IT.ACTIVE=0 AND IT.CARDTYPE NOT IN(4,22)
                      AND (IT.CODE LIKE ? OR IT.NAME LIKE ?)
                    ORDER BY IT.CODE");
                $stmt->execute(["%$q%","%$q%"]);
                $r = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['ok'=>true,'sonuclar'=>$r]);
            } else {
                echo json_encode(['ok'=>true,'sonuclar'=>[],'msg'=>'Tiger bağlantısı yok']);
            }
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'msg'=>'Bilinmeyen işlem']); exit;
}

// ── VERİ YÜKLE ──────────────────────────────────────────────────
$ara       = trim($_GET['ara'] ?? '');
$mamul_fil = trim($_GET['mamul'] ?? '');
$satirlar  = [];
try {
    $where = ''; $params = [];
    if ($ara) {
        $where .= " AND (mamul_kodu LIKE ? OR mamul_adi LIKE ? OR alt_kodu LIKE ? OR alt_adi LIKE ?)";
        $p = "%$ara%";
        $params = array_merge($params, [$p,$p,$p,$p]);
    }
    if ($mamul_fil) {
        $where .= " AND mamul_kodu=?";
        $params[] = $mamul_fil;
    }
    $s = $db->prepare("SELECT * FROM manuel_bom WHERE 1=1 $where ORDER BY mamul_kodu, alt_kodu");
    $s->execute($params);
    $satirlar = $s->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

// Mamul listesi (filtre dropdown için)
$mamul_listesi = [];
try {
    $mamul_listesi = $db->query("SELECT DISTINCT mamul_kodu, mamul_adi FROM manuel_bom ORDER BY mamul_kodu")
        ->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

ob_end_clean();
$endpoint = BASE_URL . '/bolumler/planlama/kapasite_manuel_bom.php';
?>
<style>
#mb-tbl { border-collapse:collapse; font-size:12px; width:100%; }
#mb-tbl thead th { background:#1E3A5F; color:#e0f0ff; padding:6px 8px; border:1px solid #2d5986; font-size:11px; font-weight:600; }
#mb-tbl tbody td { padding:4px 8px; border:1px solid #E5E7EB; vertical-align:middle; }
#mb-tbl tbody tr:hover td { background:rgba(0,0,0,.03); }
#mb-tbl td[contenteditable=true]:focus { outline:2px solid #667EEA; background:#F0F4FF!important; border-radius:2px; }
.mb-saved { background:#D1FAE5!important; transition:background .6s; }
.mb-err   { background:#FEE2E2!important; }
.mb-cb    { width:16px; height:16px; cursor:pointer; }
.tiger-dropdown { position:absolute; background:#fff; border:1px solid #E2E8F0; border-radius:6px; box-shadow:0 8px 24px rgba(0,0,0,.12); z-index:200; max-height:220px; overflow-y:auto; min-width:300px; }
.tiger-item { padding:7px 12px; cursor:pointer; font-size:12px; border-bottom:1px solid #F1F5F9; }
.tiger-item:hover { background:#EEF2FF; }
.tiger-item span { color:#94A3B8; font-size:10px; margin-left:6px; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="flex:1">
    <h1 class="s-bas">🔩 Manuel BOM</h1>
    <div class="s-yol">Planlama / <b>Manuel Reçete</b></div>
  </div>
  <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
    <form method="GET" style="display:flex;gap:6px;align-items:center">
      <input type="hidden" name="sayfa" value="planlama-manuel-bom">
      <input type="text" name="ara" value="<?php echo htmlspecialchars($ara);?>" placeholder="Kod veya ad ara..."
        style="border:1px solid var(--kenar);border-radius:6px;padding:5px 10px;font-size:12px;width:180px">
      <select name="mamul" style="border:1px solid var(--kenar);border-radius:6px;padding:5px 9px;font-size:12px">
        <option value="">Tüm mamuller</option>
        <?php foreach($mamul_listesi as $m): ?>
        <option value="<?php echo htmlspecialchars($m['mamul_kodu']);?>"
          <?php echo $m['mamul_kodu']===$mamul_fil?'selected':'';?>>
          <?php echo htmlspecialchars($m['mamul_kodu']);?>
          <?php if($m['mamul_adi']): echo ' — '.htmlspecialchars(mb_substr($m['mamul_adi'],0,25)); endif;?>
        </option>
        <?php endforeach;?>
      </select>
      <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:12px;cursor:pointer">🔍</button>
      <?php if($ara||$mamul_fil):?>
      <a href="?sayfa=planlama-manuel-bom" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none">✕ Temizle</a>
      <?php endif;?>
    </form>
    <button onclick="mbEkleAc()" style="background:#7C3AED;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">➕ BOM Satırı Ekle</button>
    <button onclick="mbTopluSil()" id="mbBulkBtn" disabled style="background:#DC2626;color:#fff;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;opacity:.5">🗑 Seçilenleri Sil</button>
  </div>
</div>

<!-- Özet -->
<?php
$toplam = count($satirlar);
$mamul_say = count(array_unique(array_column($satirlar,'mamul_kodu')));
$alt_say   = count(array_unique(array_column($satirlar,'alt_kodu')));
?>
<div style="display:flex;gap:8px;padding:0 0 10px;flex-wrap:wrap">
  <?php foreach([
    ['🔩','Kayıt',$toplam,'#EFF6FF','#1E40AF'],
    ['📦','Mamul',$mamul_say,'#F3E8FF','#6B21A8'],
    ['🔧','Alt Malzeme',$alt_say,'#F0FDF4','#065F46'],
  ] as [$i,$e,$d,$bg,$fg]):?>
  <div style="background:<?php echo $bg;?>;border:1px solid <?php echo $fg;?>33;border-radius:8px;padding:7px 14px;min-width:100px">
    <div style="font-size:10px;color:<?php echo $fg;?>"><?php echo $i.' '.$e;?></div>
    <div style="font-size:17px;font-weight:800;color:<?php echo $fg;?>"><?php echo $d;?></div>
  </div>
  <?php endforeach;?>
  <div style="margin-left:auto;background:#FFFBEB;border:1px solid #FCD34D;border-radius:8px;padding:7px 14px;font-size:11px;color:#92400E;max-width:400px">
    ⚠️ Bu tablodaki reçeteler Tiger'da tanımı olmayan ürünler için. Kapasite hesabında Tiger BOM'uyla <strong>birlikte</strong> kullanılır.
  </div>
</div>

<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 290px)">
<table id="mb-tbl">
  <thead>
    <tr>
      <th style="width:28px"><input type="checkbox" class="mb-cb" id="mbSelAll"></th>
      <th style="width:28px">No</th>
      <th style="min-width:110px">Mamul Kodu</th>
      <th style="min-width:180px">Mamul Adı</th>
      <th style="min-width:110px">Alt Malzeme Kodu</th>
      <th style="min-width:180px">Alt Malzeme Adı</th>
      <th style="min-width:80px">Miktar</th>
      <th style="min-width:65px">Birim</th>
      <th style="min-width:120px">Notlar</th>
      <th style="min-width:80px">Güncelleyen</th>
      <th style="width:50px">Sil</th>
    </tr>
  </thead>
  <tbody>
  <?php if(empty($satirlar)): ?>
  <tr><td colspan="11" style="text-align:center;padding:30px;color:#94A3B8">
    <?php echo $ara||$mamul_fil ? 'Arama sonucu bulunamadı.' : 'Henüz manuel BOM kaydı yok. ➕ BOM Satırı Ekle butonuyla ekleyin.'; ?>
  </td></tr>
  <?php else: foreach($satirlar as $i=>$r): ?>
  <tr data-id="<?php echo $r['id'];?>">
    <td><input type="checkbox" class="mb-cb mb-row-cb" value="<?php echo $r['id'];?>" onchange="mbCbDeg()"></td>
    <td style="color:#94A3B8;font-size:11px"><?php echo $i+1;?></td>
    <?php foreach(['mamul_kodu','mamul_adi','alt_kodu','alt_adi','miktar','birim','notlar'] as $alan): ?>
    <td contenteditable="true" data-alan="<?php echo $alan;?>"
        onblur="mbGuncelle(this,<?php echo $r['id'];?>,'<?php echo $alan;?>')"
        style="<?php echo in_array($alan,['mamul_kodu','alt_kodu'])?'font-weight:700;color:#1E3A5F':''; echo $alan==='miktar'?';text-align:right':'';?>"
    ><?php echo htmlspecialchars($r[$alan]??'');?></td>
    <?php endforeach; ?>
    <td style="color:#64748B;font-size:11px"><?php echo htmlspecialchars($r['guncelleyen']??'');?></td>
    <td style="text-align:center">
      <button onclick="mbSilTek(<?php echo $r['id'];?>)"
        style="background:#FEE2E2;color:#991B1B;border:none;padding:2px 7px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button>
    </td>
  </tr>
  <?php endforeach; endif; ?>
  </tbody>
</table>
</div>
</div>

<!-- ── EKLE MODALİ ─────────────────────────────────────────────── -->
<div id="mbModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1001;align-items:center;justify-content:center;padding:16px">
<div style="background:#fff;border-radius:14px;width:100%;max-width:700px;box-shadow:0 20px 60px rgba(0,0,0,.25)">
  <div style="background:linear-gradient(135deg,#6B21A8,#7C3AED);border-radius:14px 14px 0 0;padding:14px 20px;display:flex;align-items:center;justify-content:space-between">
    <div>
      <div style="color:#fff;font-size:15px;font-weight:800">🔩 Manuel BOM Satırı Ekle</div>
      <div style="color:rgba(255,255,255,.75);font-size:11px">Tiger'da reçetesi olmayan ürün–malzeme bağlantısı tanımlayın</div>
    </div>
    <button onclick="mbKapat()" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:30px;height:30px;border-radius:8px;cursor:pointer">✕</button>
  </div>
  <div style="padding:20px">

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">

      <!-- Mamul -->
      <div>
        <label class="form-etiket">Mamul Kodu *</label>
        <div style="position:relative">
          <input type="text" id="mb_mamul_kodu" class="form-alan" placeholder="Kod girin veya Tiger'dan ara..."
            oninput="tigerAra(this.value,'mb_mamul_kodu','mb_mamul_adi','mb_mamul_drop')">
          <div id="mb_mamul_drop" class="tiger-dropdown" style="display:none"></div>
        </div>
      </div>
      <div>
        <label class="form-etiket">Mamul Adı</label>
        <input type="text" id="mb_mamul_adi" class="form-alan" placeholder="Otomatik veya manuel girin">
      </div>

      <!-- Alt Malzeme -->
      <div>
        <label class="form-etiket">Alt Malzeme Kodu *</label>
        <div style="position:relative">
          <input type="text" id="mb_alt_kodu" class="form-alan" placeholder="Kod girin veya Tiger'dan ara..."
            oninput="tigerAra(this.value,'mb_alt_kodu','mb_alt_adi','mb_alt_drop')">
          <div id="mb_alt_drop" class="tiger-dropdown" style="display:none"></div>
        </div>
      </div>
      <div>
        <label class="form-etiket">Alt Malzeme Adı</label>
        <input type="text" id="mb_alt_adi" class="form-alan" placeholder="Otomatik veya manuel girin">
      </div>

      <!-- Miktar + Birim -->
      <div>
        <label class="form-etiket">Miktar *</label>
        <input type="number" id="mb_miktar" class="form-alan" value="1" min="0.0001" step="0.0001">
      </div>
      <div>
        <label class="form-etiket">Birim</label>
        <select id="mb_birim" class="form-alan">
          <option>ADET</option><option>KG</option><option>GR</option>
          <option>MT</option><option>M2</option><option>LT</option><option>TAKIM</option>
        </select>
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label class="form-etiket">Notlar</label>
      <input type="text" id="mb_notlar" class="form-alan" placeholder="Opsiyonel açıklama...">
    </div>

    <div id="mbHata" style="display:none;background:#FEE2E2;color:#991B1B;padding:8px 12px;border-radius:6px;font-size:12px;margin-bottom:12px"></div>

    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button onclick="mbKapat()" style="background:#F1F5F9;color:#374151;border:1px solid #CBD5E1;padding:9px 20px;border-radius:8px;font-size:12px;cursor:pointer">İptal</button>
      <button onclick="mbEkle(false)" id="mbEkleBtn"
        style="background:#7C3AED;color:#fff;border:none;padding:9px 20px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
      <button onclick="mbEkle(true)" id="mbEkleDevamBtn"
        style="background:#6B21A8;color:#fff;border:none;padding:9px 20px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet & Devam</button>
    </div>
  </div>
</div>
</div>

<script>
var _mbEndpoint = '<?php echo $endpoint;?>';

// Checkbox
document.getElementById('mbSelAll').addEventListener('change', function() {
  document.querySelectorAll('.mb-row-cb').forEach(cb=>cb.checked=this.checked);
  mbCbDeg();
});
function mbCbDeg() {
  var n=document.querySelectorAll('.mb-row-cb:checked').length;
  var btn=document.getElementById('mbBulkBtn');
  btn.disabled=!n; btn.style.opacity=n?'1':'.5';
}

// Inline güncelle
function mbGuncelle(el, id, alan) {
  var val=el.textContent.trim();
  if(alan==='miktar') val=val.replace(/\./g,'').replace(/,/g,'.');
  var fd=new FormData();
  fd.append('mb_action','guncelle');fd.append('id',id);fd.append('alan',alan);fd.append('deger',val);
  fetch(_mbEndpoint,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}})
  .then(r=>r.json()).then(d=>{
    el.classList.remove('mb-err');
    if(d.ok){el.classList.add('mb-saved');setTimeout(()=>el.classList.remove('mb-saved'),1500);}
    else el.classList.add('mb-err');
  });
}

// Sil
function mbSilTek(id){if(!confirm('Silinsin mi?'))return;mbSilIstek(id+'');}
function mbTopluSil(){
  var ids=[...document.querySelectorAll('.mb-row-cb:checked')].map(c=>c.value).join(',');
  if(!ids)return;if(!confirm(ids.split(',').length+' kayıt silinsin mi?'))return;
  mbSilIstek(ids);
}
function mbSilIstek(ids){
  var fd=new FormData();fd.append('mb_action','sil');fd.append('ids',ids);
  fetch(_mbEndpoint,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}})
  .then(r=>r.json()).then(d=>{if(d.ok)location.reload();else alert('Hata:'+(d.msg||''));});
}

// Modal
function mbEkleAc(){
  document.getElementById('mbModal').style.display='flex';
  document.getElementById('mbHata').style.display='none';
  ['mb_mamul_kodu','mb_mamul_adi','mb_alt_kodu','mb_alt_adi','mb_notlar'].forEach(id=>{document.getElementById(id).value='';});
  document.getElementById('mb_miktar').value='1';
  document.getElementById('mb_birim').value='ADET';
}
function mbKapat(){document.getElementById('mbModal').style.display='none';}

function mbEkle(devam) {
  var mamul_kodu=document.getElementById('mb_mamul_kodu').value.trim();
  var mamul_adi =document.getElementById('mb_mamul_adi').value.trim();
  var alt_kodu  =document.getElementById('mb_alt_kodu').value.trim();
  var alt_adi   =document.getElementById('mb_alt_adi').value.trim();
  var miktar    =document.getElementById('mb_miktar').value;
  var birim     =document.getElementById('mb_birim').value;
  var notlar    =document.getElementById('mb_notlar').value.trim();
  var hataDiv   =document.getElementById('mbHata');
  if(!mamul_kodu||!alt_kodu){hataDiv.style.display='block';hataDiv.textContent='Mamul kodu ve alt malzeme kodu zorunludur.';return;}
  var btn=document.getElementById('mbEkleBtn');
  btn.disabled=true;btn.textContent='Kaydediliyor...';
  var fd=new FormData();
  fd.append('mb_action','ekle');fd.append('mamul_kodu',mamul_kodu);fd.append('mamul_adi',mamul_adi);
  fd.append('alt_kodu',alt_kodu);fd.append('alt_adi',alt_adi);fd.append('miktar',miktar);
  fd.append('birim',birim);fd.append('notlar',notlar);
  fetch(_mbEndpoint,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}})
  .then(r=>r.json()).then(d=>{
    btn.disabled=false;btn.textContent='💾 Kaydet';
    if(d.ok){
      if(devam){
        // Devam — sadece alt malzeme temizle, mamul kalsın
        hataDiv.style.display='none';
        document.getElementById('mb_alt_kodu').value='';
        document.getElementById('mb_alt_adi').value='';
        document.getElementById('mb_miktar').value='1';
        document.getElementById('mb_notlar').value='';
        document.getElementById('mb_alt_kodu').focus();
        // Tabloya eklendiğini göster
        btn.textContent='✅ Kaydedildi'; btn.style.background='#059669';
        setTimeout(()=>{btn.textContent='💾 Kaydet';btn.style.background='#7C3AED';},1200);
      } else {
        mbKapat(); location.reload();
      }
    } else {
      hataDiv.style.display='block';hataDiv.textContent='Hata: '+(d.msg||'');
    }
  }).catch(e=>{btn.disabled=false;btn.textContent='💾 Kaydet';hataDiv.style.display='block';hataDiv.textContent=e.message;});
}

// Tiger stok arama
var _tigerTimer = {};
function tigerAra(q, kodId, adId, dropId) {
  var drop=document.getElementById(dropId);
  if(q.length<2){drop.style.display='none';return;}
  clearTimeout(_tigerTimer[dropId]);
  _timerTimer = setTimeout(function(){}, 0); // reset
  _tigerTimer[dropId] = setTimeout(function(){
    var fd=new FormData();fd.append('mb_action','tiger_ara');fd.append('q',q);
    fetch(_mbEndpoint,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}})
    .then(r=>r.json()).then(d=>{
      if(!d.ok||!d.sonuclar.length){drop.style.display='none';return;}
      drop.innerHTML='';
      d.sonuclar.forEach(function(s){
        var item=document.createElement('div');
        item.className='tiger-item';
        item.innerHTML='<strong>'+s.CODE+'</strong><span>'+s.NAME+'</span>';
        item.onclick=function(){
          document.getElementById(kodId).value=s.CODE;
          document.getElementById(adId).value=s.NAME;
          drop.style.display='none';
        };
        drop.appendChild(item);
      });
      drop.style.display='block';
    });
  },300);
}

// Dışarı tıklayınca dropdown kapat
document.addEventListener('click',function(e){
  document.querySelectorAll('.tiger-dropdown').forEach(d=>{
    if(!d.contains(e.target)) d.style.display='none';
  });
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')mbKapat();});
</script>
