<?php
/**
 * Satınalma İrsaliyesi — Etiket Alma Listesi
 * Route: satinalma-etiket
 * Mantık: Tiger'dan TRCODE=1 satınalma irsaliyeleri çek
 *         MES PAKETLER tablosunda URETIM_EMRI_NO=irsaliye_no AND STOK_KODU=stok_kodu kontrolü
 */
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();
set_time_limit(60);

$tiger_ok = ($tigerdb_pdo !== null);
$mes_ok   = ($mes_pdo    !== null);
$hata     = '';
$satirlar = [];

// Filtreler
$f_basl    = trim($_GET['basl']    ?? date('Y-m-01'));
$f_bitis   = trim($_GET['bitis']   ?? date('Y-m-d'));
$f_irsno   = trim($_GET['irsno']   ?? '');
$f_stok    = trim($_GET['stok']    ?? '');
$f_tedarik = trim($_GET['tedarik'] ?? '');
$f_durum   = trim($_GET['durum']   ?? ''); // '' | 'bekliyor' | 'alindi'

if ($tiger_ok) {
    try {
        // Tiger satınalma irsaliye satırları — TRCODE=1
        $w = ["L.LINETYPE IN(0,1) AND L.CANCELLED=0 AND F.TRCODE=1",
              "CONVERT(date,F.DATE_) BETWEEN ? AND ?"];
        $p = [$f_basl, $f_bitis];

        if ($f_irsno)   { $w[] = "F.FICHENO LIKE ?";       $p[] = "%$f_irsno%"; }
        if ($f_stok)    { $w[] = "I.CODE    LIKE ?";        $p[] = "%$f_stok%"; }
        if ($f_tedarik) { $w[] = "C.DEFINITION_ LIKE ?";   $p[] = "%$f_tedarik%"; }

        $ws = implode(' AND ', $w);

        // Ambar 01 ve 02 UNION
        $sql = "SELECT TOP 3000
            F.FICHENO                           AS irsaliye_no,
            CONVERT(date,F.DATE_)               AS tarih,
            C.CODE                              AS cari_kodu,
            C.DEFINITION_                       AS tedarikci,
            I.CODE                              AS stok_kodu,
            I.NAME                              AS stok_adi,
            SUM(L.AMOUNT)                       AS miktar,
            U.CODE                              AS birim,
            MAX(ISNULL(MS.LOT_NO, ISNULL(L.SPECODE2,''))) AS lot_no,
            MAX(L.SOURCEINDEX)                      AS ambar_no
        FROM LG_222_01_STLINE L WITH(NOLOCK)
        JOIN LG_222_01_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
        LEFT JOIN LG_222_ITEMS  I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF
        LEFT JOIN LG_222_UNITSETL U WITH(NOLOCK) ON U.LOGICALREF=L.UOMREF
        LEFT JOIN MES_SATINALMA MS WITH(NOLOCK) ON MS.IRSALIYE_NO=F.FICHENO AND MS.STOK_KODU=I.CODE
        WHERE $ws
        GROUP BY F.FICHENO,F.DATE_,C.CODE,C.DEFINITION_,I.CODE,I.NAME,U.CODE

        UNION ALL

        SELECT TOP 3000
            F.FICHENO,CONVERT(date,F.DATE_),C.CODE,C.DEFINITION_,
            I.CODE,I.NAME,SUM(L.AMOUNT),U.CODE,MAX(ISNULL(MS.LOT_NO, ISNULL(L.SPECODE2,''))),MAX(L.SOURCEINDEX)
        FROM LG_222_02_STLINE L WITH(NOLOCK)
        JOIN LG_222_02_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
        LEFT JOIN LG_222_ITEMS  I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF
        LEFT JOIN LG_222_UNITSETL U WITH(NOLOCK) ON U.LOGICALREF=L.UOMREF
        LEFT JOIN MES_SATINALMA MS WITH(NOLOCK) ON MS.IRSALIYE_NO=F.FICHENO AND MS.STOK_KODU=I.CODE
        WHERE $ws
        GROUP BY F.FICHENO,F.DATE_,C.CODE,C.DEFINITION_,I.CODE,I.NAME,U.CODE";

        // UNION için parametreyi iki kez gönder
        $p_final = array_merge($p, $p);

        $st = $tigerdb_pdo->prepare($sql);
        $st->execute($p_final);
        $satirlar_raw = $st->fetchAll(PDO::FETCH_ASSOC);

        // Aynı irsaliye_no + stok_kodu çiftlerini birleştir (UNION çakışması)
        $uniq = [];
        foreach ($satirlar_raw as $r) {
            $key = $r['irsaliye_no'].'|||'.$r['stok_kodu'];
            if (!isset($uniq[$key])) {
                $uniq[$key] = $r;
            } else {
                $uniq[$key]['miktar'] = (float)$uniq[$key]['miktar'] + (float)$r['miktar'];
            }
        }
        $satirlar = array_values($uniq);

        // Tarihe göre sırala
        usort($satirlar, function($a,$b){
            return strcmp($b['tarih'].$b['irsaliye_no'], $a['tarih'].$a['irsaliye_no']);
        });

        // Hariç tutulan kodları filtrele
        global $db;
        if($db) {
            try {
                $haric = $db->query("SELECT stok_kodu FROM etiket_haric_kodlar")
                            ->fetchAll(PDO::FETCH_COLUMN);
                if(!empty($haric)) {
                    $haric_set = array_flip(array_map('strtoupper', $haric));
                    $satirlar = array_values(array_filter($satirlar, function($r) use($haric_set){
                        return !isset($haric_set[strtoupper($r['stok_kodu']??'')]);
                    }));
                }
            } catch(Throwable $e) {}
        }

    } catch (Throwable $e) { $hata = $e->getMessage(); }
}

// ── Etiket durumunu MES PAKETLER'den çek ──────────────────────────────────
// Anahtar: URETIM_EMRI_NO = irsaliye_no, STOK_KODU = stok_kodu
$etiket_map = []; // 'irsaliye_no|||stok_kodu' => ['paket_sayisi'=>N,'toplam_miktar'=>M]
if ($mes_ok && !empty($satirlar)) {
    try {
        // Tüm irsaliye no'larını topla
        $irsaliye_nolar = array_unique(array_column($satirlar, 'irsaliye_no'));
        if (!empty($irsaliye_nolar)) {
            $in = implode(',', array_fill(0, count($irsaliye_nolar), '?'));
            $st2 = $mes_pdo->prepare(
                "SELECT URETIM_EMRI_NO, STOK_KODU,
                        COUNT(*) AS paket_sayisi,
                        SUM(MIKTAR) AS toplam_miktar
                 FROM dbo.PAKETLER
                 WHERE URETIM_EMRI_NO IN ($in) AND AKTIF=0
                 GROUP BY URETIM_EMRI_NO, STOK_KODU"
            );
            $st2->execute(array_values($irsaliye_nolar));
            foreach ($st2->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $key = $row['URETIM_EMRI_NO'].'|||'.$row['STOK_KODU'];
                $etiket_map[$key] = [
                    'paket_sayisi'  => (int)$row['paket_sayisi'],
                    'toplam_miktar' => (float)$row['toplam_miktar'],
                ];
            }
        }
    } catch (Throwable $e) {}
}

// Durum filtresi uygula
if ($f_durum === 'bekliyor') {
    $satirlar = array_values(array_filter($satirlar, fn($r) =>
        !isset($etiket_map[$r['irsaliye_no'].'|||'.$r['stok_kodu']])));
} elseif ($f_durum === 'alindi') {
    $satirlar = array_values(array_filter($satirlar, fn($r) =>
        isset($etiket_map[$r['irsaliye_no'].'|||'.$r['stok_kodu']])));
}

// Özet
$toplam       = count($satirlar);
$alinan_sayisi = count(array_filter($satirlar, fn($r) =>
    isset($etiket_map[$r['irsaliye_no'].'|||'.$r['stok_kodu']])));
$bekleyen = $toplam - $alinan_sayisi;
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🏷️ Satınalma Etiket Alma</h1>
    <div class="s-yol">Satınalma / <b>İrsaliye Etiket</b>
      <span style="font-size:11px;color:<?=$tiger_ok?'#065F46':'#EF4444'?>;font-weight:700;margin-left:8px">
        ● Tiger DB <?=$tiger_ok?'':'Yok'?>
      </span>
    </div>
  </div>
</div>
<div class="s-body">

<?php if ($hata): ?>
<div style="padding:12px;background:#FEF2F2;color:#7F1D1D;border:1px solid #FECACA;border-radius:var(--r);margin-bottom:14px;font-size:13px">
  ⚠️ <?=htmlspecialchars($hata)?>
</div>
<?php endif; ?>

<!-- Filtre -->
<div class="kart" style="padding:18px;margin-bottom:14px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="satinalma-etiket">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;align-items:flex-end">
      <div>
        <label class="form-et" style="font-size:11px">Başlangıç</label>
        <input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Bitiş</label>
        <input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">İrsaliye No</label>
        <input type="text" name="irsno" class="form-alan" value="<?=htmlspecialchars($f_irsno)?>" placeholder="İRS...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Stok Kodu</label>
        <input type="text" name="stok" class="form-alan" value="<?=htmlspecialchars($f_stok)?>" placeholder="2961...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Tedarikçi</label>
        <input type="text" name="tedarik" class="form-alan" value="<?=htmlspecialchars($f_tedarik)?>" placeholder="Firma...">
      </div>
      <div>
        <label class="form-et" style="font-size:11px">Durum</label>
        <select name="durum" class="form-alan">
          <option value="">Tümü</option>
          <option value="bekliyor" <?=$f_durum==='bekliyor'?'selected':''?>>⏳ Bekliyor</option>
          <option value="alindi"   <?=$f_durum==='alindi'  ?'selected':''?>>✅ Alındı</option>
        </select>
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-t" style="flex:1;padding:10px">🔍 Ara</button>
        <a href="?sayfa=satinalma-etiket" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">↺</a>
      </div>
    </div>
  </form>
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:14px">
  <?php foreach([
    ['Toplam Kalem',  $toplam,        '#6B7280'],
    ['Etiket Alındı', $alinan_sayisi, '#16A34A'],
    ['Bekleyen',      $bekleyen,      '#F59E0B'],
  ] as [$lbl,$val,$renk]):?>
  <div style="background:var(--yuzey);border-radius:var(--r);padding:14px 18px;border-top:3px solid <?=$renk?>;box-shadow:var(--shadow);text-align:center">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:4px"><?=$lbl?></div>
    <div style="font-size:26px;font-weight:900;color:<?=$renk?>"><?=$val?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;justify-content:space-between">
    <span style="font-weight:800;font-size:14px">📋 İrsaliye Kalemleri</span>
    <span style="font-size:12px;color:var(--m3)"><?=$toplam?> kalem</span>
  </div>
  <?php if (empty($satirlar)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">
    <div style="font-size:36px;margin-bottom:10px">📭</div>
    <div>Kayıt bulunamadı.</div>
  </div>
  <?php else: ?>
  <div style="overflow:auto;max-height:640px">
  <table style="width:100%;border-collapse:collapse;font-size:12px;min-width:860px">
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E293B;color:#fff">
        <th style="padding:9px 12px;text-align:left;white-space:nowrap">İrsaliye No</th>
        <th style="padding:9px 12px;text-align:left">Tarih</th>
        <th style="padding:9px 12px;text-align:left;max-width:130px">Tedarikçi</th>
        <th style="padding:9px 12px;text-align:left">Stok Kodu</th>
        <th style="padding:9px 12px;text-align:left;max-width:160px">Stok Adı</th>
        <th style="padding:9px 12px;text-align:right">Miktar</th>
        <th style="padding:9px 12px">Birim</th>
        <th style="padding:9px 12px">LOT</th>
        <th style="padding:9px 12px;text-align:center">Etiket Durumu</th>
        <th style="padding:9px 12px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($satirlar as $i => $r):
      $key     = $r['irsaliye_no'].'|||'.$r['stok_kodu'];
      $alinan  = $etiket_map[$key] ?? null;
      $ir_mik  = (float)$r['miktar'];
      $al_mik  = $alinan ? (float)$alinan['toplam_miktar'] : 0;
      $bg      = $i%2===0 ? '#fff' : 'var(--kenar-a)';

      // Durum belirle
      if (!$alinan) {
          $durum_bg  = '#FEF3C7'; $durum_fg='#92400E';
          $durum_txt = '⏳ Bekliyor';
      } elseif (abs($al_mik - $ir_mik) <= 0.01) {
          $durum_bg  = '#D1FAE5'; $durum_fg='#065F46';
          $durum_txt = '✅ Tam ('.$alinan['paket_sayisi'].' paket)';
      } else {
          $durum_bg  = '#DBEAFE'; $durum_fg='#1E40AF';
          $durum_txt = '🔄 Kısmi ('.$alinan['paket_sayisi'].' paket / '.number_format($al_mik,2).')';
      }

      $eq = http_build_query([
        'sayfa'       => 'satinalma-etiket-al',
        'irsaliye_no' => $r['irsaliye_no'],
        'stok_kodu'   => $r['stok_kodu'],
        'stok_adi'    => $r['stok_adi']??'',
        'miktar'      => $ir_mik,
        'birim'       => $r['birim']??'',
        'tedarikci'   => $r['tedarikci']??'',
        'cari_kodu'   => $r['cari_kodu']??'',
        'lot_no'      => $r['lot_no']??'',
        'tarih'       => $r['tarih']??'',
        'ambar_no'    => $r['ambar_no']??'1',
      ]);
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:8px 12px;font-weight:700;font-family:monospace;font-size:11px"><?=htmlspecialchars($r['irsaliye_no']??'')?></td>
      <td style="padding:8px 12px;font-size:11px;color:var(--m2)"><?=htmlspecialchars($r['tarih']??'')?></td>
      <td style="padding:8px 12px;font-size:11px;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['tedarikci']??'')?>"><?=htmlspecialchars($r['tedarikci']??'')?></td>
      <td style="padding:8px 12px;font-weight:700;font-size:11px"><?=htmlspecialchars($r['stok_kodu']??'')?></td>
      <td style="padding:8px 12px;font-size:11px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['stok_adi']??'')?>"><?=htmlspecialchars($r['stok_adi']??'')?></td>
      <td style="padding:8px 12px;text-align:right;font-weight:700;color:#16A34A"><?=number_format($ir_mik,2)?></td>
      <td style="padding:8px 12px;font-size:11px;color:var(--m3)"><?=htmlspecialchars($r['birim']??'')?></td>
      <td style="padding:8px 12px;font-family:monospace;font-size:10px;color:var(--m3)"><?=htmlspecialchars($r['lot_no']??'')?></td>
      <td style="padding:8px 12px;text-align:center">
        <span style="background:<?=$durum_bg?>;color:<?=$durum_fg?>;padding:3px 10px;border-radius:12px;font-size:10px;font-weight:700;white-space:nowrap">
          <?=$durum_txt?>
        </span>
      </td>
      <td style="padding:8px 12px;text-align:center;white-space:nowrap">
        <a href="?<?=$eq?>"
           style="padding:4px 10px;background:<?=$alinan?'#DBEAFE':'#D1FAE5'?>;color:<?=$alinan?'#1E40AF':'#065F46'?>;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none">
          <?=$alinan?'➕ Paket Ekle':'🏷️ Etiket Al'?>
        </a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

</div><!-- /s-body -->
