<?php
/**
 * GKK Red Planlama — Satinalma (Takip + Surec birlesik)
 * Route: satinalma-gkk-red
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();
global $db;

// Tablolar
foreach([
"CREATE TABLE IF NOT EXISTS gkk_red_surec (id INT AUTO_INCREMENT PRIMARY KEY, gkk_id INT NOT NULL UNIQUE, irsaliye_no VARCHAR(50), stok_kodu VARCHAR(50), stok_adi VARCHAR(255) DEFAULT '', miktar DECIMAL(15,4) DEFAULT 0, birim VARCHAR(20) DEFAULT 'ADET', red_tarihi DATETIME, red_aciklama TEXT, kontrol_eden VARCHAR(100) DEFAULT '', aksiyon_tipi ENUM('BEKLIYOR','IADE','AYIKLAMA','SART_ONAY','YENI_SEVKIYAT','DIGER') DEFAULT 'BEKLIYOR', asama ENUM('RED','TEDARIKCI_BILDIRIMI','TEDARIKCI_YANITI','AKSIYON_SECIMI','GERCEKLESMIS','KAPANDI') DEFAULT 'RED', bildirim_tarihi DATETIME, bildirim_yapan VARCHAR(100) DEFAULT '', tedarikci_yanit_tarihi DATETIME, tedarikci_yanit_notu TEXT, yeni_sevkiyat_tarihi DATE, gerceklesme_tarihi DATE, gerceklesme_notu TEXT, olusturan VARCHAR(100) DEFAULT '', olusturma_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP, guncelleme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_gkk(gkk_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS gkk_red_log (id INT AUTO_INCREMENT PRIMARY KEY, surec_id INT NOT NULL, islem_tipi VARCHAR(50), eski_asama VARCHAR(50) DEFAULT '', yeni_asama VARCHAR(50) DEFAULT '', aciklama TEXT, dosya_yolu VARCHAR(500) DEFAULT '', dosya_adi VARCHAR(255) DEFAULT '', yapan VARCHAR(100) DEFAULT '', tarih DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_surec(surec_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
] as $sql) { try{$db->exec($sql);}catch(Throwable $e){} }

// Filtreler
$f_basl  = trim($_GET['basl']  ?? date('Y-m-d', strtotime('-3 months')));
$f_bitis = trim($_GET['bitis'] ?? date('Y-m-d'));
$f_asama = trim($_GET['asama'] ?? '');
$f_stok  = trim($_GET['stok']  ?? '');

// Liste
$liste = [];
try {
    $w = ["g.sonuc='RED'"]; $p = [];
    if($f_basl && $f_bitis){ $w[]="DATE(g.kontrol_tarihi) BETWEEN ? AND ?"; $p[]=$f_basl; $p[]=$f_bitis; }
    if($f_stok){ $w[]="(g.stok_kodu LIKE ? OR g.irsaliye_no LIKE ?)"; $p[]="%$f_stok%"; $p[]="%$f_stok%"; }
    if($f_asama){ $w[]="COALESCE(s.asama,'RED')=?"; $p[]=$f_asama; }
    $st = $db->prepare("
        SELECT g.id AS gkk_id, g.irsaliye_no, g.stok_kodu, g.stok_adi,
               g.miktar, g.birim, g.kontrol_tarihi, g.kontrol_eden,
               g.aciklama AS red_aciklama, g.hata_adet, g.kontrol_adet,
               COALESCE(s.id,0) AS surec_id,
               COALESCE(s.asama,'RED') AS asama,
               COALESCE(s.aksiyon_tipi,'BEKLIYOR') AS aksiyon_tipi,
               s.bildirim_tarihi, s.bildirim_yapan,
               s.tedarikci_yanit_notu, s.yeni_sevkiyat_tarihi,
               s.gerceklesme_tarihi, s.gerceklesme_notu
        FROM gkk_kontrol_sonuclari g
        LEFT JOIN gkk_red_surec s ON s.gkk_id=g.id
        WHERE ".implode(' AND ',$w)."
        ORDER BY g.kontrol_tarihi DESC
    ");
    $st->execute($p);
    $liste = $st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){}

// Tedarikci bilgisi Tiger'dan
$ted_map = [];
if(!empty($liste) && isset($tigerdb_pdo) && $tigerdb_pdo) {
    try {
        $irsno_list = array_unique(array_column($liste,'irsaliye_no'));
        $in = implode(',',array_fill(0,count($irsno_list),'?'));
        $tst = $tigerdb_pdo->prepare(
            "SELECT F.FICHENO, C.DEFINITION_ AS CARI, C.CODE AS CARI_KODU
             FROM (SELECT FICHENO,CLIENTREF FROM LG_222_01_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1
                   UNION ALL SELECT FICHENO,CLIENTREF FROM LG_222_02_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1) F
             LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF"
        );
        $tst->execute(array_merge($irsno_list,$irsno_list));
        foreach($tst->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $ted_map[$r['FICHENO']] = ['cari'=>$r['CARI']??'', 'kod'=>$r['CARI_KODU']??''];
        }
    } catch(Throwable $e){}
}

// Asama tanimlari
$asama_def = [
    'RED'                  => ['label'=>'Red Edildi',        'bg'=>'#FEE2E2','fg'=>'#7F1D1D'],
    'TEDARIKCI_BILDIRIMI'  => ['label'=>'Bildirim Yapildi',  'bg'=>'#FEF3C7','fg'=>'#92400E'],
    'TEDARIKCI_YANITI'     => ['label'=>'Tedarikci Yaniti',  'bg'=>'#DBEAFE','fg'=>'#1E40AF'],
    'AKSIYON_SECIMI'       => ['label'=>'Aksiyon Secildi',   'bg'=>'#EDE9FE','fg'=>'#5B21B6'],
    'GERCEKLESMIS'         => ['label'=>'Gerceklesti',       'bg'=>'#D1FAE5','fg'=>'#065F46'],
    'KAPANDI'              => ['label'=>'Kapandi',           'bg'=>'#F3F4F6','fg'=>'#6B7280'],
];
$aksiyon_def = [
    'BEKLIYOR'=>'Bekleniyor','IADE'=>'Iade','AYIKLAMA'=>'Ayiklama',
    'SART_ONAY'=>'Sartli Onay','YENI_SEVKIYAT'=>'Yeni Sevkiyat','DIGER'=>'Diger'
];

// Ozet
$ozet = array_fill_keys(array_keys($asama_def),0);
foreach($liste as $r) { $k=$r['asama']??'RED'; $ozet[$k]=($ozet[$k]??0)+1; }
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">GKK Red Planlama</h1>
    <div class="s-yol">Satinalma / <b>GKK Red Planlama</b></div>
  </div>
</div>
<div class="s-body">

<!-- Ozet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-bottom:14px">
<?php foreach($asama_def as $k=>$a):
    $sayi = $ozet[$k]??0;
    $aktif = ($f_asama===$k) ? 'box-shadow:0 0 0 3px '.$a['fg'].';' : '';
    $href = '?sayfa=satinalma-gkk-red&asama='.urlencode($k).'&basl='.urlencode($f_basl).'&bitis='.urlencode($f_bitis);
?>
<a href="<?=$href?>" style="background:<?=$a['bg']?>;border-radius:var(--r);padding:10px 12px;border-left:4px solid <?=$a['fg']?>;text-decoration:none;display:block;<?=$aktif?>">
  <div style="font-size:10px;font-weight:700;color:<?=$a['fg']?>"><?=htmlspecialchars($a['label'])?></div>
  <div style="font-size:24px;font-weight:900;color:<?=$a['fg']?>"><?=$sayi?></div>
</a>
<?php endforeach;?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="GET" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="satinalma-gkk-red">
    <div><label class="form-et" style="font-size:11px">Baslangic</label><input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
    <div><label class="form-et" style="font-size:11px">Bitis</label><input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
    <div><label class="form-et" style="font-size:11px">Stok / Irsaliye</label><input type="text" name="stok" class="form-alan" value="<?=htmlspecialchars($f_stok)?>" placeholder="Ara..."></div>
    <div>
      <label class="form-et" style="font-size:11px">Asama</label>
      <select name="asama" class="form-alan">
        <option value="">Tumu</option>
        <?php foreach($asama_def as $k=>$a):?>
        <option value="<?=htmlspecialchars($k)?>" <?=$f_asama===$k?'selected':''?>><?=htmlspecialchars($a['label'])?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="display:flex;gap:6px">
      <button type="submit" class="btn btn-t" style="padding:10px 16px">Ara</button>
      <a href="?sayfa=satinalma-gkk-red" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">Sifirla</a>
    </div>
  </form>
</div>

<!-- Tablo -->
<?php if(empty($liste)):?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">Kayit bulunamadi.</div>
<?php else:?>
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <span style="font-weight:800;font-size:13px">Red Edilen Kalemler</span>
    <span style="font-size:12px;color:var(--m3)"><?=count($liste)?> kayit</span>
  </div>
  <div style="overflow:auto">
  <table style="width:100%;border-collapse:collapse;font-size:12px">
    <thead>
      <tr style="background:#1E293B;color:#fff;font-size:11px;white-space:nowrap">
        <th style="padding:9px 12px;text-align:left;border-right:1px solid #334155">Irsaliye No</th>
        <th style="padding:9px 12px;text-align:left;border-right:1px solid #334155">Tarih</th>
        <th style="padding:9px 12px;text-align:left;border-right:1px solid #334155">Tedarikci</th>
        <th style="padding:9px 12px;text-align:left;border-right:1px solid #334155">Stok Kodu / Adi</th>
        <th style="padding:9px 12px;text-align:right;border-right:1px solid #334155">Miktar</th>
        <th style="padding:9px 12px;text-align:center;border-right:1px solid #334155">Kontrol</th>
        <th style="padding:9px 12px;text-align:center;border-right:1px solid #334155">Hata %</th>
        <th style="padding:9px 12px;text-align:center;border-right:1px solid #334155">Asama</th>
        <th style="padding:9px 12px;text-align:center;border-right:1px solid #334155">Aksiyon</th>
        <th style="padding:9px 12px;text-align:center">Surec</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($liste as $i=>$r):
        $bg  = $i%2===0 ? '#fff' : 'var(--kenar-a)';
        $ad  = $asama_def[$r['asama']??'RED'] ?? $asama_def['RED'];
        $ted = $ted_map[$r['irsaliye_no']] ?? ['cari'=>'','kod'=>''];
        $ka  = (int)($r['kontrol_adet']??0);
        $ha  = (int)($r['hata_adet']??0);
        $oran = $ka>0 ? round(($ha/$ka)*100,1) : null;
        $oran_renk = $oran===null?'#6B7280':($oran>=50?'#DC2626':($oran>=20?'#F59E0B':'#16A34A'));
        $gkk_id   = (int)$r['gkk_id'];
        $surec_id = (int)$r['surec_id'];
        $ted_esc  = htmlspecialchars($ted['cari'],ENT_QUOTES);
        $kod_esc  = htmlspecialchars($ted['kod'],ENT_QUOTES);
        $irsno_esc= htmlspecialchars($r['irsaliye_no'],ENT_QUOTES);
        $stok_esc = htmlspecialchars($r['stok_kodu'],ENT_QUOTES);
        $tarih_esc= htmlspecialchars(substr($r['kontrol_tarihi']??'',0,10),ENT_QUOTES);
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:7px 12px;border-right:1px solid var(--kenar)">
        <a href="?sayfa=kalite-gkk-detay&fis_id=<?=$gkk_id?>&irsaliye_no=<?=$irsno_esc?>&cari=<?=$ted_esc?>&cari_kodu=<?=$kod_esc?>&tarih=<?=$tarih_esc?>"
           style="color:#4F46E5;font-weight:700;font-family:monospace;font-size:11px"><?=htmlspecialchars($r['irsaliye_no'])?></a>
      </td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);white-space:nowrap;color:var(--m3);font-size:11px"><?=htmlspecialchars(substr($r['kontrol_tarihi']??'',0,10))?></td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=$ted_esc?>"><?=htmlspecialchars($ted['cari'])?></td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar)">
        <div style="font-family:monospace;font-size:11px;font-weight:700"><?=htmlspecialchars($r['stok_kodu']??'')?></div>
        <div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars(mb_substr($r['stok_adi']??'',0,28))?></div>
      </td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);text-align:right;font-weight:700;white-space:nowrap"><?=number_format((float)($r['miktar']??0),0)?> <span style="color:var(--m3);font-weight:400"><?=htmlspecialchars($r['birim']??'')?></span></td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);text-align:center;font-size:11px">
        <?php if($ka>0):?><?=$ka?> / <span style="color:#DC2626;font-weight:700"><?=$ha?></span><?php else:?><span style="color:var(--m3)">--</span><?php endif;?>
      </td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);text-align:center">
        <?php if($oran!==null):?><b style="color:<?=$oran_renk?>">%<?=$oran?></b><?php else:?><span style="color:var(--m3)">--</span><?php endif;?>
      </td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);text-align:center">
        <span style="background:<?=$ad['bg']?>;color:<?=$ad['fg']?>;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;white-space:nowrap"><?=htmlspecialchars($ad['label'])?></span>
        <?php if(!empty($r['yeni_sevkiyat_tarihi'])):?>
        <div style="font-size:10px;color:#16A34A;margin-top:2px">Sevk: <?=htmlspecialchars($r['yeni_sevkiyat_tarihi'])?></div>
        <?php endif;?>
      </td>
      <td style="padding:7px 12px;border-right:1px solid var(--kenar);text-align:center;font-size:11px">
        <?=htmlspecialchars($aksiyon_def[$r['aksiyon_tipi']??'BEKLIYOR']??'--')?>
        <?php if(!empty($r['tedarikci_yanit_notu'])):?>
        <div style="font-size:10px;color:var(--m3);max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['tedarikci_yanit_notu'],ENT_QUOTES)?>"><?=htmlspecialchars(mb_substr($r['tedarikci_yanit_notu'],0,20))?></div>
        <?php endif;?>
      </td>
      <td style="padding:7px 12px;text-align:center">
        <button type="button"
                data-gkk="<?=$gkk_id?>"
                data-surec="<?=$surec_id?>"
                data-irsno="<?=$irsno_esc?>"
                data-stok="<?=$stok_esc?>"
                onclick="surec_ac(this)"
                style="padding:4px 10px;background:#4F46E5;color:#fff;border:none;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer">
          Surec
        </button>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>
<?php endif;?>
</div>

<!-- Surec Modal -->
<div id="surec-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.5);z-index:99000;align-items:flex-start;justify-content:center;padding-top:50px">
  <div style="background:#fff;border-radius:12px;width:680px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.3);max-height:90vh;overflow-y:auto">
    <div style="padding:16px 20px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1">
      <div>
        <div style="font-weight:800;font-size:15px" id="sm-baslik">Surec</div>
        <div style="font-size:11px;color:var(--m3)" id="sm-alt"></div>
      </div>
      <button onclick="document.getElementById('surec-modal').style.display='none'" style="background:none;border:none;font-size:18px;cursor:pointer;color:var(--m3);padding:4px 8px">X</button>
    </div>
    <div style="padding:12px 20px;border-bottom:1px solid var(--kenar);display:flex;gap:6px;flex-wrap:wrap" id="sm-adimlar"></div>
    <div style="padding:16px 20px;min-height:60px" id="sm-form"></div>
    <div style="border-top:1px solid var(--kenar)">
      <div style="padding:8px 20px;font-size:11px;font-weight:700;color:var(--m3);text-transform:uppercase;letter-spacing:.5px">Surec Gecmisi</div>
      <div id="sm-log" style="max-height:220px;overflow-y:auto;padding:0 20px 16px;font-size:11px"></div>
    </div>
  </div>
</div>

<script>
var SUREC_BASE  = <?=json_encode(BASE_URL)?>;
var SM_DATA = {gkk_id:0, surec_id:0, irsno:'', stok:''};

function surec_ac(btn) {
    SM_DATA.gkk_id   = parseInt(btn.getAttribute('data-gkk'));
    SM_DATA.surec_id = parseInt(btn.getAttribute('data-surec'));
    SM_DATA.irsno    = btn.getAttribute('data-irsno');
    SM_DATA.stok     = btn.getAttribute('data-stok');
    document.getElementById('sm-baslik').textContent = SM_DATA.irsno + ' / ' + SM_DATA.stok;
    document.getElementById('sm-alt').textContent    = 'GKK: ' + SM_DATA.gkk_id + (SM_DATA.surec_id ? ' | Surec: ' + SM_DATA.surec_id : ' | Surec baslatilmamis');
    document.getElementById('sm-form').innerHTML     = '';
    document.getElementById('sm-log').innerHTML      = 'Yukleniyor...';
    document.getElementById('surec-modal').style.display = 'flex';
    surec_adimlar();
    surec_log();
}

function surec_adimlar() {
    var btns = SM_DATA.surec_id === 0
        ? [{a:'surec_baslat', t:'Surec Baslat'}]
        : [
            {a:'bildirim',        t:'Bildirim Yap'},
            {a:'tedarikci_yanit', t:'Tedarikci Yaniti'},
            {a:'aksiyon',         t:'Aksiyon Sec'},
            {a:'gerceklesme',     t:'Gerceklesme'},
            {a:'not_ekle',        t:'Not Ekle'},
            {a:'kapat',           t:'Kapat'}
          ];
    document.getElementById('sm-adimlar').innerHTML = btns.map(function(b){
        return '<button type="button" onclick="surec_form(\'' + b.a + '\')" style="padding:5px 10px;border:1px solid var(--kenar);border-radius:5px;background:#fff;font-size:11px;cursor:pointer;font-weight:600">' + b.t + '</button>';
    }).join('');
}

function surec_form(action) {
    var h = '';
    if (action === 'surec_baslat') {
        h = '<button onclick="surec_kaydet(\'surec_baslat\')" style="padding:9px 18px;background:#DC2626;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer">Surec Baslat</button>';
    } else if (action === 'bildirim') {
        h = '<label class="form-et">Bildirim Notu</label><textarea id="f-not" class="form-alan" rows="3" placeholder="Tedarikci bildirilen detaylar..."></textarea>'
          + '<label class="form-et" style="margin-top:8px">Belge (opsiyonel)</label><input type="file" id="f-belge" class="form-alan">'
          + '<button onclick="surec_kaydet(\'bildirim_yap\')" style="margin-top:8px;padding:9px 18px;background:#F59E0B;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Bildirimi Kaydet</button>';
    } else if (action === 'tedarikci_yanit') {
        h = '<label class="form-et">Tedarikci Yaniti</label><textarea id="f-yanit" class="form-alan" rows="3" placeholder="Tedarikci yaniti..."></textarea>'
          + '<label class="form-et" style="margin-top:8px">Yeni Sevkiyat Tarihi (varsa)</label><input type="date" id="f-sevk" class="form-alan">'
          + '<label class="form-et" style="margin-top:8px">Belge (opsiyonel)</label><input type="file" id="f-belge2" class="form-alan">'
          + '<button onclick="surec_kaydet(\'tedarikci_yaniti\')" style="margin-top:8px;padding:9px 18px;background:#3B82F6;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Yaniti Kaydet</button>';
    } else if (action === 'aksiyon') {
        h = '<label class="form-et">Aksiyon Turu</label>'
          + '<select id="f-aksiyon" class="form-alan"><option value="IADE">Iade</option><option value="AYIKLAMA">Ayiklama</option><option value="SART_ONAY">Sartli Onay</option><option value="YENI_SEVKIYAT">Yeni Sevkiyat</option><option value="DIGER">Diger</option></select>'
          + '<textarea id="f-aksiyon-not" class="form-alan" rows="2" placeholder="Detay..." style="margin-top:6px"></textarea>'
          + '<button onclick="surec_kaydet(\'aksiyon_sec\')" style="margin-top:8px;padding:9px 18px;background:#8B5CF6;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Aksiyon Kaydet</button>';
    } else if (action === 'gerceklesme') {
        h = '<label class="form-et">Gerceklesme Tarihi</label><input type="date" id="f-gtarih" class="form-alan">'
          + '<textarea id="f-gnot" class="form-alan" rows="2" placeholder="Detay..." style="margin-top:6px"></textarea>'
          + '<button onclick="surec_kaydet(\'gerceklesme\')" style="margin-top:8px;padding:9px 18px;background:#16A34A;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Gerceklesmeni Kaydet</button>';
    } else if (action === 'not_ekle') {
        h = '<textarea id="f-snot" class="form-alan" rows="3" placeholder="Serbest not..."></textarea>'
          + '<input type="file" id="f-belge3" class="form-alan" style="margin-top:6px">'
          + '<button onclick="surec_kaydet(\'not_ekle\')" style="margin-top:8px;padding:9px 18px;background:#6B7280;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Not Ekle</button>';
    } else if (action === 'kapat') {
        h = '<textarea id="f-knot" class="form-alan" rows="2" placeholder="Kapanis notu..."></textarea>'
          + '<button onclick="surec_kaydet(\'kapat\')" style="margin-top:8px;padding:9px 18px;background:#374151;color:#fff;border:none;border-radius:6px;font-weight:700;cursor:pointer;width:100%">Sureci Kapat</button>';
    }
    document.getElementById('sm-form').innerHTML = h;
}

function g(id) { var e=document.getElementById(id); return e?e.value:''; }

function surec_kaydet(action) {
    var fd = new FormData();
    fd.append('action',   action);
    fd.append('gkk_id',   SM_DATA.gkk_id);
    fd.append('surec_id', SM_DATA.surec_id);
    if (action==='bildirim_yap')    { fd.append('aciklama', g('f-not')); var b=document.getElementById('f-belge'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action==='tedarikci_yaniti'){ fd.append('yanit',g('f-yanit')); fd.append('sevk_tarihi',g('f-sevk')); var b=document.getElementById('f-belge2'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action==='aksiyon_sec')     { fd.append('aksiyon_tipi',g('f-aksiyon')); fd.append('aciklama',g('f-aksiyon-not')); }
    if (action==='gerceklesme')     { fd.append('not',g('f-gnot')); fd.append('tarih',g('f-gtarih')); }
    if (action==='not_ekle')        { fd.append('aciklama',g('f-snot')); var b=document.getElementById('f-belge3'); if(b&&b.files[0]) fd.append('belge',b.files[0]); }
    if (action==='kapat')           { fd.append('not',g('f-knot')); }

    fetch(SUREC_BASE + '/islemler/kalite/gkk_surec_kaydet.php', {method:'POST', body:fd})
    .then(function(r){ return r.text().then(function(t){ try{return JSON.parse(t);}catch(e){throw new Error(t.substring(0,200));} }); })
    .then(function(d){
        if (d.success) {
            if (d.surec_id) SM_DATA.surec_id = d.surec_id;
            document.getElementById('sm-alt').textContent = 'GKK: ' + SM_DATA.gkk_id + ' | Surec: ' + SM_DATA.surec_id;
            document.getElementById('sm-form').innerHTML = '<div style="color:#16A34A;font-weight:700;padding:10px">Kaydedildi.</div>';
            surec_adimlar();
            surec_log();
        } else {
            alert('Hata: ' + d.message);
        }
    })
    .catch(function(e){ alert('Hata: ' + e.message); });
}

function surec_log() {
    if (!SM_DATA.surec_id) {
        document.getElementById('sm-log').innerHTML = '<div style="color:var(--m3)">Henuz surec baslatilmamis.</div>';
        return;
    }
    fetch(SUREC_BASE + '/islemler/kalite/gkk_surec_kaydet.php?surec_id=' + SM_DATA.surec_id)
    .then(function(r){ return r.json(); })
    .then(function(d){
        var logs = d.logs || [];
        if (!logs.length) { document.getElementById('sm-log').innerHTML = '<div style="color:var(--m3)">Log yok.</div>'; return; }
        document.getElementById('sm-log').innerHTML = logs.map(function(l){
            return '<div style="border-left:3px solid var(--kenar);padding:5px 8px;margin-bottom:6px">'
                + '<b>' + (l.islem_tipi||'') + '</b>'
                + (l.yeni_asama ? ' -&gt; ' + l.yeni_asama : '')
                + (l.aciklama ? '<div style="color:var(--m2)">' + l.aciklama + '</div>' : '')
                + (l.dosya_adi ? '<div style="color:#4F46E5">Belge: ' + l.dosya_adi + '</div>' : '')
                + '<div style="color:var(--m3)">' + (l.yapan||'') + ' - ' + (l.tarih||'') + '</div>'
                + '</div>';
        }).join('');
    })
    .catch(function(){ document.getElementById('sm-log').innerHTML = '<div style="color:#DC2626">Log yuklenemedi.</div>'; });
}

document.getElementById('surec-modal').addEventListener('click', function(e){
    if (e.target === this) this.style.display = 'none';
});
</script>
