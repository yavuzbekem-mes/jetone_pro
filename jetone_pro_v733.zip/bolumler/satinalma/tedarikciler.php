<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$mesaj = '';

// --- POST İŞLEMLERİ ---

// Yeni kayıt
if (isset($_POST['tedarikci_kayit'])) {
    try {
        $db->prepare("INSERT INTO tedarikci_bilgileri
            (tedarikci_adi,ilgili_kisi_ad,ilgili_kisi_mail,ilgili_kisi_tel,`ilgili_kisi_ünvan`,tarih)
            VALUES (?,?,?,?,?,NOW())")
           ->execute([
               trim($_POST['tedarikci_adi']??''),
               trim($_POST['ilgili_kisi_ad']??''),
               trim($_POST['ilgili_kisi_mail']??''),
               trim($_POST['ilgili_kisi_tel']??''),
               trim($_POST['ilgili_kisi_unvan']??''),
           ]);
        $mesaj = 'ok:Tedarikçi başarıyla eklendi.';
    } catch(Throwable $e) { $mesaj = 'err:'.$e->getMessage(); }
}

// Satır içi güncelleme (contenteditable)
if (isset($_POST['inline_update'])) {
    try {
        $col = $_POST['col'] ?? '';
        $allowed = ['tedarikci_adi','ilgili_kisi_ad','ilgili_kisi_mail','ilgili_kisi_tel','ilgili_kisi_ünvan'];
        if (in_array($col, $allowed)) {
            $db->prepare("UPDATE tedarikci_bilgileri SET `$col`=? WHERE id=?")
               ->execute([trim($_POST['val']??''), (int)$_POST['id']]);
        }
        echo 'ok'; exit;
    } catch(Throwable $e) { echo 'err:'.$e->getMessage(); exit; }
}

// Sil
if (isset($_POST['sil_id'])) {
    try {
        $db->prepare("DELETE FROM tedarikci_bilgileri WHERE id=?")->execute([(int)$_POST['sil_id']]);
        $mesaj = 'ok:Kayıt silindi.';
    } catch(Throwable $e) { $mesaj = 'err:'.$e->getMessage(); }
}

// Tiger cari listesi
$cariler = [];
if ($tiger_ok) {
    try {
        $cariler = $tigerdb_pdo->query("SELECT DISTINCT C.CODE AS kod, C.DEFINITION_ AS unvan
            FROM dbo.LG_222_02_CLFLINE F WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_CLCARD C WITH(NOLOCK) ON F.CLIENTREF=C.LOGICALREF
            ORDER BY C.DEFINITION_ ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Tedarikçi listesi
$tedarikciler = $db->query("SELECT * FROM tedarikci_bilgileri ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$toplam = count($tedarikciler);
$firmalar = count(array_unique(array_column($tedarikciler, 'tedarikci_adi')));
?>
<style>
#tblTed th { background:#1E3A5F !important; color:#fff !important; }
#tblTed td, #tblTed th { border:1px solid #000 !important; }
#tblTed td[contenteditable=true]:focus { background:#FFF9C4 !important; outline:2px solid #F59E0B; }
#tblTed td[contenteditable=true] { cursor:text; }
.ted-ctx { display:none;position:fixed;background:#fff;border:1px solid #E2E8F0;border-radius:8px;
  box-shadow:0 8px 24px rgba(0,0,0,.15);min-width:160px;z-index:9999;padding:4px 0; }
.ted-ctx button { display:flex;align-items:center;gap:8px;width:100%;padding:8px 14px;
  font-size:12px;font-weight:600;border:none;background:none;cursor:pointer;text-align:left; }
.ted-ctx button:hover { background:#F1F5F9; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🏭 Tedarikçi Listesi</h1>
    <div class="s-yol">Satınalma / <b>Tedarikçi Yönetimi</b></div>
  </div>
  <button onclick="document.getElementById('modalEkle').style.display='flex'"
    style="background:#1E3A5F;color:#fff;border:none;padding:8px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
    ➕ Tedarikçi Ekle
  </button>
</div>

<?php if($mesaj): [$tip,$txt] = explode(':',$mesaj,2); ?>
<div style="background:<?php echo $tip==='ok'?'#F0FDF4':'#FEF2F2';?>;color:<?php echo $tip==='ok'?'#166534':'#991B1B';?>;
  border:1px solid <?php echo $tip==='ok'?'#86EFAC':'#FECACA';?>;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-weight:600">
  <?php echo $tip==='ok'?'✅':'❌'; ?> <?php echo htmlspecialchars($txt);?>
</div>
<?php endif;?>

<!-- Özet -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
  <div style="background:#DBEAFE;border:1px solid #93C5FD;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#1D4ED8"><?php echo $toplam;?></div>
    <div style="font-size:11px;color:#1E40AF;font-weight:600">👤 Toplam Kişi</div>
  </div>
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#15803D"><?php echo $firmalar;?></div>
    <div style="font-size:11px;color:#166534;font-weight:600">🏭 Farklı Firma</div>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblTed" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:40px">#</th>
    <th style="width:80px;text-align:center">İşlem</th>
    <th>Firma Adı</th>
    <th>İlgili Kişi</th>
    <th>Mail</th>
    <th>Telefon</th>
    <th>Ünvan</th>
    <th>Tarih</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>İşlem</th><th>Firma Adı</th><th>İlgili Kişi</th>
    <th>Mail</th><th>Telefon</th><th>Ünvan</th><th>Tarih</th>
  </tr></tfoot>
  <tbody>
  <?php $say=0; foreach($tedarikciler as $r): $say++;?>
  <tr data-id="<?php echo $r['id'];?>"
      data-firma="<?php echo htmlspecialchars($r['tedarikci_adi'],ENT_QUOTES);?>"
      data-mail="<?php echo htmlspecialchars($r['ilgili_kisi_mail'],ENT_QUOTES);?>"
      data-ad="<?php echo htmlspecialchars($r['ilgili_kisi_ad'],ENT_QUOTES);?>"
      data-tel="<?php echo htmlspecialchars($r['ilgili_kisi_tel'],ENT_QUOTES);?>">
    <td style="color:#64748B;font-size:11px;text-align:center"><?php echo $say;?></td>
    <td style="text-align:center;white-space:nowrap">
      <button onclick="tedCtx(event,this.closest('tr'))"
        style="background:#1E3A5F;color:#fff;border:none;padding:3px 10px;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer">
        ☰ Menü
      </button>
    </td>
    <td contenteditable="true" data-col="tedarikci_adi" style="font-weight:700;white-space:nowrap"><?php echo htmlspecialchars($r['tedarikci_adi']);?></td>
    <td contenteditable="true" data-col="ilgili_kisi_ad" style="white-space:nowrap"><?php echo htmlspecialchars($r['ilgili_kisi_ad']);?></td>
    <td contenteditable="true" data-col="ilgili_kisi_mail" style="white-space:nowrap;color:#0369A1"><?php echo htmlspecialchars($r['ilgili_kisi_mail']);?></td>
    <td contenteditable="true" data-col="ilgili_kisi_tel" style="white-space:nowrap"><?php echo htmlspecialchars($r['ilgili_kisi_tel']);?></td>
    <td contenteditable="true" data-col="ilgili_kisi_ünvan" style="font-size:11px;white-space:nowrap"><?php echo htmlspecialchars($r['ilgili_kisi_ünvan']??'');?></td>
    <td style="font-size:11px;white-space:nowrap"><?php echo htmlspecialchars($r['tarih']??'');?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<!-- Context Menü -->
<div id="tedCtxMenu" class="ted-ctx">
  <button onclick="tedSil()">🗑️ Sil</button>
  <button id="tedAraBtn" onclick="tedAra()">📞 Ara</button>
  <button id="tedWaBtn" onclick="tedWa()">💬 WhatsApp</button>
  <button id="tedMailBtn" onclick="tedMail()">📧 Mail Gönder</button>
</div>

<!-- Modal: Tedarikçi Ekle -->
<div id="modalEkle" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:10px;width:540px;max-width:100%;max-height:92vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="background:#1E3A5F;color:#fff;padding:13px 18px;border-radius:10px 10px 0 0;display:flex;align-items:center;justify-content:space-between">
      <span style="font-weight:700;font-size:14px">➕ Tedarikçi Ekle</span>
      <button onclick="document.getElementById('modalEkle').style.display='none'"
        style="background:rgba(255,255,255,.15);border:none;color:#fff;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:14px">✕</button>
    </div>
    <form method="POST" style="padding:16px">
      <div style="display:grid;grid-template-columns:1fr;gap:10px">
        <div>
          <label class="form-etiket">Firma Adı *</label>
          <?php if($tiger_ok && $cariler): ?>
          <select name="tedarikci_adi" class="form-alan" required>
            <option value="">— Seçin —</option>
            <?php foreach($cariler as $c):?>
            <option value="<?php echo htmlspecialchars($c['unvan']);?>">
              <?php echo htmlspecialchars($c['unvan']); ?> — <?php echo htmlspecialchars($c['kod']);?>
            </option>
            <?php endforeach;?>
          </select>
          <?php else: ?>
          <input type="text" name="tedarikci_adi" class="form-alan" required placeholder="Firma adı">
          <?php endif;?>
        </div>
        <div>
          <label class="form-etiket">İlgili Kişi Adı *</label>
          <input type="text" name="ilgili_kisi_ad" class="form-alan" required placeholder="Ad Soyad">
        </div>
        <div>
          <label class="form-etiket">Mail *</label>
          <input type="email" name="ilgili_kisi_mail" class="form-alan" required placeholder="ornek@firma.com">
        </div>
        <div>
          <label class="form-etiket">Telefon</label>
          <input type="tel" name="ilgili_kisi_tel" class="form-alan" placeholder="05XX XXX XX XX">
        </div>
        <div>
          <label class="form-etiket">Ünvan</label>
          <input type="text" name="ilgili_kisi_unvan" class="form-alan" placeholder="Satış Sorumlusu">
        </div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px;padding-top:12px;border-top:1px solid #E2E8F0">
        <button type="button" onclick="document.getElementById('modalEkle').style.display='none'"
          style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:7px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">İptal</button>
        <button type="submit" name="tedarikci_kayit"
          style="background:#1E3A5F;color:#fff;border:none;padding:7px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script>
// Context menü
var _tedRow = null;
function tedCtx(e, tr) {
  e.preventDefault(); e.stopPropagation();
  _tedRow = tr;
  var tel = tr.dataset.tel || '', mail = tr.dataset.mail || '';
  var clean = tel.replace(/\D/g,'');
  document.getElementById('tedAraBtn').style.display  = (tel.startsWith('0') && tel.length>=10) ? 'flex':'none';
  document.getElementById('tedWaBtn').style.display   = (clean.length>=10) ? 'flex':'none';
  document.getElementById('tedMailBtn').style.display = (mail.includes('@')) ? 'flex':'none';
  var m = document.getElementById('tedCtxMenu');
  m.style.left = e.pageX+'px'; m.style.top = e.pageY+'px'; m.style.display='block';
}
document.addEventListener('click', function(e){
  if(!e.target.closest('#tedCtxMenu')) document.getElementById('tedCtxMenu').style.display='none';
});
function tedSil() {
  if(!_tedRow) return;
  if(!confirm('Bu kaydı silmek istediğinize emin misiniz?')) return;
  var f=document.createElement('form'); f.method='POST';
  f.innerHTML='<input type="hidden" name="sil_id" value="'+_tedRow.dataset.id+'">';
  document.body.appendChild(f); f.submit();
}
function tedAra()  { if(_tedRow) window.location.href='tel:'+_tedRow.dataset.tel; }
function tedWa()   {
  var t=(_tedRow.dataset.tel||'').replace(/\D/g,'');
  if(t.startsWith('0')) t='90'+t.substring(1);
  window.open('https://wa.me/'+t,'_blank');
}
function tedMail() {
  var r=_tedRow;
  window.location.href='mailto:'+r.dataset.mail+'?subject='+encodeURIComponent(r.dataset.firma+' Malzeme Talebi')+'&body=Merhaba%20'+encodeURIComponent(r.dataset.ad);
}

// Satır içi contenteditable kaydet
document.querySelectorAll('#tblTed td[contenteditable]').forEach(function(td){
  var orig='';
  td.addEventListener('focus', function(){ orig=this.textContent.trim(); this.style.background='#FFF9C4'; });
  td.addEventListener('blur', function(){
    this.style.background='';
    var val=this.textContent.trim();
    if(val===orig) return;
    var id=this.closest('tr').dataset.id;
    var col=this.dataset.col;
    var fd=new FormData();
    fd.append('inline_update','1'); fd.append('id',id); fd.append('col',col); fd.append('val',val);
    fetch('<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-tedarikciler',{method:'POST',body:fd,credentials:'same-origin'})
      .then(function(r){return r.text();})
      .then(function(t){
        if(t==='ok') { /* başarılı */ }
        else { alert('Güncelleme hatası: '+t); }
      });
  });
  td.addEventListener('keydown', function(e){ if(e.key==='Enter'){e.preventDefault();this.blur();} });
});

// DataTables
$(document).ready(function(){
  $('#tblTed').DataTable({
    initComplete: function(){
      this.api().columns([2,3,4,6]).every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    columnDefs:[{orderable:false,targets:1}],
    order:[[0,'desc']],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Tedarikciler'},
      'print'
    ]
  });
});
</script>
