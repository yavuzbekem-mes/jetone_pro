<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$satirlar = [];

if ($tiger_ok) {
    try {
        $sql = "SELECT
            CASE WHEN OL.DUEDATE < GETDATE() THEN 'GECIKTI' ELSE 'BEKLIYOR' END AS durum,
            CASE
                WHEN OL.DUEDATE < GETDATE()
                    THEN CAST(DATEDIFF(DAY, OL.DUEDATE, GETDATE()) AS VARCHAR) + ' gün gecikti'
                ELSE CAST(DATEDIFF(DAY, GETDATE(), OL.DUEDATE) AS VARCHAR) + ' gün kaldı'
            END AS termin_durum,
            ORF.FICHENO        AS siparis_no,
            IT.CODE            AS stok_kodu,
            IT.NAME            AS stok_adi,
            UNIL.CODE          AS birim,
            OL.AMOUNT          AS siparis_miktari,
            OL.SHIPPEDAMOUNT   AS gelen_miktar,
            CASE WHEN OL.SHIPPEDAMOUNT >= OL.AMOUNT THEN 0
                 ELSE OL.AMOUNT - OL.SHIPPEDAMOUNT END AS kalan_miktar,
            FORMAT(ORF.DATE_,'dd.MM.yyyy')  AS siparis_tarihi,
            FORMAT(OL.DUEDATE,'dd.MM.yyyy') AS termin_tarihi,
            CASE WHEN OL.SHIPPEDAMOUNT = 0 THEN '' ELSE ISNULL((
                SELECT TOP 1 STF.FICHENO
                FROM LG_222_02_STLINE STL
                LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STL.STOCKREF=OL.STOCKREF AND STL.TRCODE=1 AND STL.CANCELLED=0
                ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,STL.DATE_)) ASC, STL.LOGICALREF ASC
            ),'') END AS son_irsaliye_no,
            CASE WHEN OL.SHIPPEDAMOUNT = 0 THEN '' ELSE ISNULL((
                SELECT TOP 1 FORMAT(STL.DATE_,'dd.MM.yyyy')
                FROM LG_222_02_STLINE STL
                LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STL.STOCKREF=OL.STOCKREF AND STL.TRCODE=1 AND STL.CANCELLED=0
                ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,STL.DATE_)) ASC, STL.LOGICALREF ASC
            ),'') END AS irsaliye_tarihi,
            CL.DEFINITION_ AS firma_adi
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON OL.STOCKREF=IT.LOGICALREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON ORF.CLIENTREF=CL.LOGICALREF
        LEFT JOIN dbo.LG_222_UNITSETL UNIL WITH(NOLOCK) ON OL.UOMREF=UNIL.LOGICALREF
        WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT < OL.AMOUNT
        ORDER BY
            CASE WHEN OL.DUEDATE < GETDATE()
                THEN DATEDIFF(DAY,OL.DUEDATE,GETDATE())
                ELSE 10000+DATEDIFF(DAY,GETDATE(),OL.DUEDATE)
            END ASC";
        $satirlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$geciken  = count(array_filter($satirlar, fn($r)=>$r['durum']==='GECIKTI'));
$bekleyen = count($satirlar) - $geciken;
$firmalar = count(array_unique(array_column($satirlar, 'firma_adi')));
?>
<style>
#tblAcikSip th { background:#1E3A5F !important; color:#fff !important; }
#tblAcikSip td, #tblAcikSip th { border:1px solid #000 !important; white-space:nowrap !important; }
table.dataTable#tblAcikSip tbody tr.gec-satir td { background:#FEE2E2 !important; }
table.dataTable#tblAcikSip tbody tr.gec-satir td.termin-cell { background:#DC2626 !important; color:#fff !important; font-weight:700; }
table.dataTable#tblAcikSip tbody tr td.termin-cell-ok { background:#D1FAE5 !important; color:#065F46 !important; font-weight:600; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🛒 Açık Satınalma Siparişleri</h1>
    <div class="s-yol">Satınalma / <b>Açık Siparişler & Mail Takip</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php else:?>

<!-- Özet Kartlar -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
  <div style="background:#FEE2E2;border:1px solid #FECACA;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#DC2626"><?php echo $geciken;?></div>
    <div style="font-size:11px;color:#991B1B;font-weight:600">🔴 Geciken Sipariş</div>
  </div>
  <div style="background:#FEF9C3;border:1px solid #FDE047;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#A16207"><?php echo $bekleyen;?></div>
    <div style="font-size:11px;color:#854D0E;font-weight:600">🟡 Bekleyen Sipariş</div>
  </div>
  <div style="background:#DBEAFE;border:1px solid #93C5FD;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#1D4ED8"><?php echo $firmalar;?></div>
    <div style="font-size:11px;color:#1E40AF;font-weight:600">🏭 Tedarikçi</div>
  </div>
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#15803D"><?php echo count($satirlar);?></div>
    <div style="font-size:11px;color:#166534;font-weight:600">📋 Toplam Kalem</div>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblAcikSip" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Durum</th>
      <th>Termin Durumu</th>
      <th>Firma Adı</th>
      <th>Sipariş No</th>
      <th>Stok Kodu</th>
      <th>Stok Adı</th>
      <th>Birim</th>
      <th style="text-align:right">Sipariş Mik.</th>
      <th style="text-align:right">Gelen Mik.</th>
      <th style="text-align:right">Kalan Mik.</th>
      <th>Sipariş Tarihi</th>
      <th>Termin Tarihi</th>
      <th>Son İrsaliye No</th>
      <th>Son İrs. Tarihi</th>
      <th style="text-align:center">Mail</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Durum</th><th>Termin Durumu</th><th>Firma Adı</th><th>Sipariş No</th>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Birim</th>
      <th>Sipariş Mik.</th><th>Gelen Mik.</th><th>Kalan Mik.</th>
      <th>Sipariş Tarihi</th><th>Termin Tarihi</th>
      <th>Son İrsaliye No</th><th>Son İrs. Tarihi</th><th>Mail</th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($satirlar as $r):
    $gec    = $r['durum'] === 'GECIKTI';
    $trCls  = $gec ? 'gec-satir' : '';
    $tCls   = $gec ? 'termin-cell' : 'termin-cell-ok';
    $dBadge = $gec
      ? '<span style="background:#DC2626;color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700">🔴 GECİKTİ</span>'
      : '<span style="background:#D1FAE5;color:#065F46;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700">🟢 BEKLIYOR</span>';
  ?>
  <tr class="<?php echo $trCls;?>" data-firma="<?php echo htmlspecialchars($r['firma_adi']);?>">
    <td><?php echo $dBadge;?></td>
    <td class="<?php echo $tCls;?>"><?php echo htmlspecialchars($r['termin_durum']);?></td>
    <td style="font-weight:700"><?php echo htmlspecialchars($r['firma_adi']);?></td>
    <td style="font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['siparis_no']);?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']);?></code></td>
    <td><?php echo htmlspecialchars($r['stok_adi']);?></td>
    <td style="text-align:center;font-size:11px"><?php echo htmlspecialchars($r['birim']??'');?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format((float)$r['siparis_miktari'],0,'','.');?></td>
    <td style="text-align:right"><?php echo number_format((float)$r['gelen_miktar'],0,'','.');?></td>
    <td style="text-align:right;font-weight:700;color:#DC2626"><?php echo number_format((float)$r['kalan_miktar'],0,'','.');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['siparis_tarihi']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['termin_tarihi']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['son_irsaliye_no']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['irsaliye_tarihi']);?></td>
    <td style="text-align:center">
      <button class="btn-mail" data-firma="<?php echo htmlspecialchars($r['firma_adi']);?>"
        style="background:#1E3A5F;color:#fff;border:none;padding:4px 10px;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer">
        📧 Mail
      </button>
    </td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($satirlar)):?>
  <tr><td colspan="15" style="text-align:center;padding:30px;color:#888">Açık sipariş bulunamadı.</td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
  if(!$('#tblAcikSip tbody tr').length || $('#tblAcikSip tbody td[colspan]').length) return;
  $('#tblAcikSip').DataTable({
    initComplete: function(){
      this.api().columns([0,1,2,3]).every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    columnDefs:[{orderable:false,targets:14}],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Acik_Satinalma_Siparisler'},
      'print'
    ]
  });
});

// Mail Gönder
document.addEventListener('click', async function(e){
  var btn = e.target.closest('.btn-mail');
  if(!btn) return;
  e.preventDefault();

  var firma = btn.dataset.firma;
  btn.disabled = true;
  btn.textContent = '⏳';

  try {
    // Tedarikçi maillerini çek
    var res = await fetch('<?php echo BASE_URL;?>/bolumler/satinalma/ajax/tedarikci_api.php?firma='+encodeURIComponent(firma));
    var data = await res.json();

    if(!data.ok || (!data.mails?.length && !data.eslesen_kayitlar?.length)){
      alert('⚠️ '+firma+' firması için mail adresi bulunamadı!\nTedarikçi Bilgileri sayfasından ekleyin.');
      btn.disabled=false; btn.textContent='📧 Mail';
      return;
    }
    // Her iki format da desteklenir
    var toMails = data.mails && data.mails.length
      ? data.mails.join(';')
      : (data.eslesen_kayitlar||[]).map(function(k){return k.ilgili_kisi_mail;}).filter(function(m){return m&&m!=='0';}).join(';');

    // POLİZA CC
    var ccMails = '';
    try {
      var pr = await fetch('<?php echo BASE_URL;?>/bolumler/satinalma/ajax/tedarikci_api.php?firma=POL%C4%B0ZA');
      var pd = await pr.json();
      if(pd.ok && pd.mails) ccMails = pd.mails.join(';');
    } catch(ex){}

    // O firmaya ait tüm satırları topla
    var satirlar = [];
    document.querySelectorAll('#tblAcikSip tbody tr[data-firma="'+firma.replace(/"/g,'&quot;')+'"]').forEach(function(tr){
      var c = tr.cells;
      satirlar.push({
        siparis_no:      c[3].textContent.trim(),
        stok_kodu:       c[4].textContent.trim(),
        stok_adi:        c[5].textContent.trim(),
        birim:           c[6].textContent.trim(),
        siparis_miktari: c[7].textContent.trim(),
        gelen_miktar:    c[8].textContent.trim(),
        kalan_miktar:    c[9].textContent.trim(),
        siparis_tarihi:  c[10].textContent.trim(),
        termin_tarihi:   c[11].textContent.trim(),
        son_irs_no:      c[12].textContent.trim(),
        son_irs_tarih:   c[13].textContent.trim()
      });
    });

    // HTML tablo oluştur
    var satirHtml = satirlar.map(function(s,i){
      var bg = i%2===0?'#ffffff':'#f9f9f9';
      var sipNo = s.siparis_no.length>4 ? s.siparis_no.slice(-4) : s.siparis_no;
      return '<tr style="background:'+bg+'">'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+sipNo+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+s.stok_kodu+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc">'+s.stok_adi+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+s.birim+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:right">'+s.siparis_miktari+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:right">'+s.gelen_miktar+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:right;font-weight:bold;color:#DC2626">'+s.kalan_miktar+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+s.siparis_tarihi+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center;font-weight:bold">'+s.termin_tarihi+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+s.son_irs_no+'</td>'+
        '<td style="padding:7px 10px;border:1px solid #ccc;text-align:center">'+s.son_irs_tarih+'</td>'+
      '</tr>';
    }).join('');

    var emailHtml =
      '<div style="font-family:Arial,sans-serif;line-height:1.6;font-size:13px">'+
      '<p>Sayın İlgili, Merhaba</p><br>'+
      '<p>Açık siparişleriniz aşağıdaki gibidir. Varsa bakiyelerin sevkini ve yeni siparişlerimizi kontrol ve teyit rica ederiz.</p><br>'+
      '<table style="border-collapse:collapse;width:100%;border:2px solid #1E3A5F">'+
        '<thead><tr style="background:#1E3A5F;color:#fff">'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Sipariş No</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Stok Kodu</th>'+
          '<th style="padding:8px;border:1px solid #2d5986">Stok Adı</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Birim</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:right">Sipariş Mik.</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:right">Gelen Mik.</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:right">Kalan Mik.</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Sipariş Tarihi</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Termin Tarihi</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Son İrs. No</th>'+
          '<th style="padding:8px;border:1px solid #2d5986;text-align:center">Son İrs. Tarihi</th>'+
        '</tr></thead>'+
        '<tbody>'+satirHtml+'</tbody>'+
      '</table><br>'+
      '<p>İyi çalışmalar.</p>'+
      '</div>';

    // Panoya kopyala
    var tmp = document.createElement('div');
    tmp.innerHTML = emailHtml;
    tmp.style.cssText = 'position:fixed;left:0;top:0;background:#fff;z-index:99999;padding:20px';
    document.body.appendChild(tmp);
    var range = document.createRange();
    range.selectNodeContents(tmp);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand('copy');
    sel.removeAllRanges();
    document.body.removeChild(tmp);

    // mailto aç
    var subject = 'Açık Siparişler - '+firma;
    window.location.href = 'mailto:'+toMails+'?cc='+ccMails+'&subject='+encodeURIComponent(subject);

    setTimeout(function(){
      alert('✅ Formatlı sipariş tablosu panoya kopyalandı!\nMail açıldıktan sonra CTRL+V ile yapıştırın.');
    }, 500);

  } catch(ex) {
    alert('Hata: '+ex.message);
  }
  btn.disabled=false; btn.textContent='📧 Mail';
});
</script>
