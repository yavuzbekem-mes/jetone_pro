<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();
$today  = date('Y-m-d');
$tr_gun = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
$AJAX   = BASE_URL.'/bolumler/satinalma/ajax/sefer_ajax.php';
?>
<style>
/* Sefer Takip - ERP Uyumlu */
.sf-view{display:none} .sf-view.on{display:block}
.sf-spinner{width:16px;height:16px;border:2.5px solid #E2E8F0;border-top-color:#2563EB;border-radius:50%;animation:sfspin .6s linear infinite;display:inline-block}
@keyframes sfspin{to{transform:rotate(360deg)}}
.sf-loading{display:flex;align-items:center;justify-content:center;padding:32px;gap:9px;color:#64748B;font-size:13px}
.sf-empty{text-align:center;padding:44px;color:#64748B}
.sb{display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:11px;font-weight:700;gap:4px}
.sb-plan{background:#F1F5F9;color:#475569;border:1px solid #CBD5E1}
.sb-ok{background:#F0FDF4;color:#16A34A;border:1px solid #86EFAC}
.sb-prog{background:#FFFBEB;color:#D97706;border:1px solid #FDE68A}
.nbadge{background:#EFF6FF;color:#1D4ED8;border:1px solid #BFDBFE;font-weight:700;font-size:12px;padding:2px 9px;border-radius:100px;min-width:22px;text-align:center;display:inline-block}
/* Nokta tablosu */
.nt-table{width:100%;border-collapse:collapse}
.nt-table th{background:#1E3A5F!important;color:#fff!important;padding:8px 12px;font-size:11px;font-weight:700;text-align:left;border:1px solid #2d5986}
.nt-table td{padding:9px 12px;font-size:12px;border:1px solid #E2E8F0;vertical-align:top}
.nt-table tbody tr:hover td{background:#F8FAFC}
.nt-sira{width:26px;height:26px;border-radius:50%;background:#1E3A5F;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:11px}
.nt-firma{font-weight:700;font-size:13px}
.nt-contact{font-size:11px;color:#64748B;margin-top:2px}
.nt-warn{font-weight:700;color:#DC2626;font-size:11px}
.nt-ok{font-weight:600;color:#16A34A;font-size:11px}
/* Drag */
.sf-drag-handle{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:4px;color:#94A3B8;font-size:14px;cursor:grab;user-select:none}
.sf-drag-handle:hover{color:#475569;background:#F1F5F9}
.nt-table tbody tr.sf-drag-over td{background:#EFF6FF;border-top:2px solid #2563EB!important}
.nt-table tbody tr.sf-dragging{opacity:.35}
/* Modal */
.sf-ovl{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;align-items:center;justify-content:center;padding:16px}
.sf-ovl.on{display:flex}
.sf-modal{background:#fff;border-radius:10px;width:520px;max-width:100%;max-height:92vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.sf-modal.wide{width:660px}
.sf-mh{background:#1E3A5F;color:#fff;padding:13px 18px;border-radius:10px 10px 0 0;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:1}
.sf-mh h3{font-weight:700;font-size:14px}
.sf-mc{background:rgba(255,255,255,.15);border:none;color:#fff;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center}
.sf-mc:hover{background:rgba(255,255,255,.28)}
.sf-mb{padding:16px}
.sf-mf{padding:10px 16px;border-top:1px solid #E2E8F0;display:flex;gap:8px;justify-content:flex-end;position:sticky;bottom:0;background:#fff;z-index:1}
.fg2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.fg2 .full{grid-column:1/-1}
.fg{display:flex;flex-direction:column;gap:4px}
.fg label{font-size:11px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.3px}
.fg label .req{color:#DC2626;margin-left:2px}
.fg input,.fg textarea,.fg select{border:1px solid #D1D5DB;border-radius:6px;padding:7px 10px;font-family:inherit;font-size:13px;color:#111827;background:#F9FAFB;outline:none;transition:border-color .15s;resize:vertical}
.fg input:focus,.fg textarea:focus,.fg select:focus{border-color:#2563EB;background:#fff}
.sf-alert{padding:8px 12px;border-radius:6px;font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px;margin-bottom:10px}
.al-err{background:#FEF2F2;color:#DC2626;border:1px solid #FECACA}
.cf-body{padding:24px 18px;text-align:center}
.cf-icon{font-size:2.5rem;margin-bottom:8px}
.cf-body h3{font-size:15px;margin-bottom:5px;font-weight:700}
.cf-body p{color:#64748B;font-size:12px}
/* Butonlar */
.btn{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border:none;border-radius:6px;font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;white-space:nowrap;line-height:1;text-decoration:none;vertical-align:middle}
.btn-p{background:#1E3A5F;color:#fff} .btn-p:hover{background:#2d5986}
.btn-d{background:#DC2626;color:#fff} .btn-d:hover{background:#B91C1C}
.btn-ok{background:#16A34A;color:#fff} .btn-ok:hover{background:#15803D}
.btn-g{background:#F1F5F9;border:1px solid #E2E8F0;color:#374151} .btn-g:hover{background:#E2E8F0}
.btn-warn{background:#D97706;color:#fff}
.btn-sm{padding:5px 10px;font-size:12px}
.btn-xs{padding:3px 8px;font-size:11px;border-radius:5px}
.sflex{flex:1}
/* Print */
.pf-wrap{background:#fff;width:297mm;min-height:210mm;margin:0 auto;padding:10mm 12mm;font-family:Arial,sans-serif;font-size:10pt;color:#111}
.pf-hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.pf-title{font-weight:800;font-size:18pt;text-transform:uppercase;text-align:center;flex:1;line-height:1.1}
.pf-datebox{text-align:right;flex-shrink:0;min-width:110px}
.pf-datebox .pd{font-weight:700;font-size:11pt;line-height:1.3}
.pf-datebox .pg{font-weight:800;font-size:13pt;line-height:1.2}
.pf-info{background:#1E3A5F;color:#fff;padding:8px 14px;margin-bottom:12px;display:flex;flex-wrap:wrap;gap:4px 20px;align-items:center;font-size:9pt;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.pf-info .pi{display:flex;align-items:center;gap:4px}
.pf-info .pi b{font-weight:700;color:#93C5FD;font-size:8pt;text-transform:uppercase}
.pf-imza{display:flex;justify-content:flex-end;gap:60px;margin-top:22px}
.pf-imza-box .lb{font-weight:700;font-size:8.5pt;text-transform:uppercase;margin-bottom:4px;text-align:center}
.pf-imza-box .ln{border-bottom:1.5px solid #111;width:170px;height:36px}
.sf-actions{white-space:nowrap;text-align:right;padding-right:12px!important}
.sf-actions .btn{margin-left:2px}
/* Sefer tablosu özel */
#sf-tbl th{background:#1E3A5F!important;color:#fff!important}
#sf-tbl td,#sf-tbl th{border:1px solid #000!important;white-space:nowrap!important}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🚛 İstanbul Sefer Takip</h1>
    <div class="s-yol">Satınalma / <b>Malzeme Alım Yönetimi</b></div>
  </div>
</div>

<!-- VIEW: LİSTE -->
<div id="sf-vlist" class="sf-view on">
  <div class="kart" style="padding:12px;margin-bottom:12px">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div><label class="form-etiket">Tarih</label><input type="date" id="lf-tarih" class="form-alan" onchange="sfLoadList()"></div>
      <div style="flex:1;min-width:200px"><label class="form-etiket">Arama</label><input type="text" id="lf-ara" class="form-alan" placeholder="🔍 Firma, şoför, plaka ara..." oninput="sfLoadList()"></div>
      <div><label class="form-etiket">Durum</label>
        <select id="lf-durum" class="form-alan" onchange="sfLoadList()">
          <option value="">Tüm Durumlar</option>
          <option value="Planlandı">Planlandı</option>
          <option value="Devam Ediyor">Devam Ediyor</option>
          <option value="Tamamlandı">Tamamlandı</option>
        </select>
      </div>
      <button class="btn btn-p" onclick="sfOpenSefer()">➕ Yeni Sefer</button>
    </div>
  </div>

  <div class="kart" style="overflow:hidden;padding:0">
    <div style="padding:10px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #E2E8F0">
      <span style="font-weight:700;font-size:13px;color:#1E3A5F">🚛 Sefer Listesi</span>
      <span id="sf-cnt" style="font-size:12px;color:#64748B"></span>
    </div>
    <div style="overflow-x:auto">
    <table id="sf-tbl" style="width:100%;border-collapse:collapse">
      <thead><tr>
        <th style="width:40px">#</th>
        <th style="width:100px">Tarih</th>
        <th>Firmalar / Noktalar</th>
        <th>Şoför</th>
        <th>Plaka</th>
        <th style="width:70px;text-align:center">Nokta</th>
        <th style="width:110px">Durum</th>
        <th style="width:170px;text-align:right">İşlemler</th>
      </tr></thead>
      <tbody id="sf-tbody">
        <tr><td colspan="8"><div class="sf-loading"><div class="sf-spinner"></div> Yükleniyor...</div></td></tr>
      </tbody>
    </table>
    </div>
  </div>
</div>

<!-- VIEW: DETAY -->
<div id="sf-vdet" class="sf-view">
  <div class="kart" style="padding:10px 14px;margin-bottom:12px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
    <button class="btn btn-g btn-sm" onclick="sfShowList()">‹ Listeye Dön</button>
    <span id="sf-crumb" style="font-size:12px;color:#64748B;flex:1"></span>
    <button class="btn btn-g btn-sm" onclick="sfEditSefer()">✏️ Seferi Düzenle</button>
    <button class="btn btn-p btn-sm" onclick="sfOpenNokta(null)">➕ Nokta Ekle</button>
    <button class="btn btn-ok btn-sm" onclick="sfPrint()">🖨️ Yazdır</button>
  </div>
  <div id="sf-detbody">
    <div class="sf-loading"><div class="sf-spinner"></div> Yükleniyor...</div>
  </div>
</div>

<!-- MODAL: SEFER -->
<div class="sf-ovl" id="m-sefer">
  <div class="sf-modal">
    <div class="sf-mh"><h3 id="ms-title">Yeni Sefer</h3><button class="sf-mc" onclick="sfCloseModal('m-sefer')">✕</button></div>
    <div class="sf-mb">
      <div id="ms-alert"></div>
      <input type="hidden" id="ms-id">
      <div class="fg2">
        <div class="fg"><label>Tarih <span class="req">*</span></label><input type="date" id="ms-tarih"></div>
        <div class="fg"><label>Durum</label>
          <select id="ms-durum"><option>Planlandı</option><option>Devam Ediyor</option><option>Tamamlandı</option></select>
        </div>
        <div class="fg"><label>Şoför Adı</label><input type="text" id="ms-sofor" placeholder="Ad Soyad"></div>
        <div class="fg"><label>Şoför Telefon</label><input type="text" id="ms-tel" placeholder="0532 111 22 33"></div>
        <div class="fg"><label>Plaka</label><input type="text" id="ms-plaka" placeholder="34 ABC 001"></div>
        <div class="fg"><label>Notlar</label><input type="text" id="ms-notlar" placeholder="Ek not..."></div>
      </div>
    </div>
    <div class="sf-mf">
      <button class="btn btn-g" onclick="sfCloseModal('m-sefer')">İptal</button>
      <button class="btn btn-p" id="ms-save" onclick="sfSaveSefer()">💾 Kaydet</button>
    </div>
  </div>
</div>

<!-- MODAL: NOKTA -->
<div class="sf-ovl" id="m-nokta">
  <div class="sf-modal wide">
    <div class="sf-mh"><h3 id="mn-title">Nokta Ekle</h3><button class="sf-mc" onclick="sfCloseModal('m-nokta')">✕</button></div>
    <div class="sf-mb">
      <div id="mn-alert"></div>
      <input type="hidden" id="mn-id"><input type="hidden" id="mn-sid">
      <div class="fg2">
        <div class="fg full"><label>Firma Adı <span class="req">*</span></label><input type="text" id="mn-firma" placeholder="Firma adı"></div>
        <div class="fg"><label>İlgili Kişi</label><input type="text" id="mn-kisi" placeholder="İsmail Bey"></div>
        <div class="fg"><label>İletişim</label><input type="text" id="mn-tel" placeholder="0533 421 63 68"></div>
        <div class="fg full"><label>Adres</label><textarea id="mn-adres" rows="2" placeholder="Tam adres..."></textarea></div>
        <div class="fg"><label>Palet Miktarı</label><input type="text" id="mn-palet" placeholder="2 Palet (100*120)"></div>
        <div class="fg"><label>Durum</label>
          <select id="mn-dsel" onchange="sfMnDurum()">
            <option value="">— Seçin —</option>
            <option value="ALINDI">✅ Alındı</option>
            <option value="TESLIM_EDILDI">✅ Teslim Edildi</option>
            <option value="ALINMADI">❌ Alınmadı</option>
            <option value="SADECE_IADE_BIRAKILACAK">⚠️ Sadece İade Bırakılacak</option>
            <option value="SADECE_MALZEME_BIRAKILACAK">⚠️ Sadece Malzeme Bırakılacak</option>
            <option value="ALINACAK">📦 Alınacak</option>
            <option value="BEKLEMEDE">⏳ Beklemede</option>
            <option value="custom">✏️ Özel yaz...</option>
          </select>
        </div>
        <div class="fg full" id="mn-cw" style="display:none">
          <label>Özel Açıklama</label>
          <textarea id="mn-dtxt" rows="2" placeholder="Açıklama..."></textarea>
        </div>
      </div>
    </div>
    <div class="sf-mf">
      <button class="btn btn-g" onclick="sfCloseModal('m-nokta')">İptal</button>
      <button class="btn btn-p" id="mn-save" onclick="sfSaveNokta()">💾 Ekle</button>
    </div>
  </div>
</div>

<!-- MODAL: ONAY -->
<div class="sf-ovl" id="m-confirm">
  <div class="sf-modal" style="width:360px">
    <div class="sf-mh" style="background:#DC2626"><h3>Silme Onayı</h3><button class="sf-mc" onclick="sfCloseModal('m-confirm')">✕</button></div>
    <div class="cf-body"><div class="cf-icon">🗑️</div><h3 id="cf-title">Silmek istiyor musunuz?</h3><p id="cf-sub">Bu işlem geri alınamaz.</p></div>
    <div class="sf-mf">
      <button class="btn btn-g" onclick="sfCloseModal('m-confirm')">Vazgeç</button>
      <button class="btn btn-d" id="cf-btn">Evet, Sil</button>
    </div>
  </div>
</div>

<script>
var SF_AJAX   = '<?php echo $AJAX;?>';
var SF_CUR_ID = 0;
var SF_GUNLER = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
var SF_DRAG_SRC = null;

function sfId(i){ return document.getElementById(i); }
function sfV(i){ var e=sfId(i); return e?e.value:''; }
function sfEsc(s){ return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'):''; }
function sfAlert(el,msg){ sfId(el).innerHTML='<div class="sf-alert al-err">⚠️ '+sfEsc(msg)+'</div>'; }
function sfClearAlert(el){ sfId(el).innerHTML=''; }

async function sfApi(params,method,body){
  try{
    var opts={method:method||'GET',headers:{'Content-Type':'application/json'}};
    if(body) opts.body=JSON.stringify(body);
    var res=await fetch(SF_AJAX+'?'+params,opts);
    var text=await res.text();
    var t=text.trim();
    if(t[0]!=='{'&&t[0]!=='['){console.error('JSON değil:',text.substring(0,300));return{ok:0,error:'Sunucu hatası'};}
    return JSON.parse(t);
  }catch(e){return{ok:0,error:e.message};}
}

function sfShowList(){ sfId('sf-vlist').classList.add('on'); sfId('sf-vdet').classList.remove('on'); sfLoadList(); }
function sfShowDetail(id){ SF_CUR_ID=id; sfId('sf-vlist').classList.remove('on'); sfId('sf-vdet').classList.add('on'); sfLoadDetail(id); }

async function sfLoadList(){
  var tarih=sfV('lf-tarih'), ara=sfV('lf-ara').toLowerCase(), durum=sfV('lf-durum');
  sfId('sf-tbody').innerHTML='<tr><td colspan="8"><div class="sf-loading"><div class="sf-spinner"></div> Yükleniyor...</div></td></tr>';
  var j=await sfApi('api=sefer_list');
  if(!j.ok){ sfId('sf-tbody').innerHTML='<tr><td colspan="8"><div class="sf-empty"><p>'+sfEsc(j.error)+'</p></div></td></tr>'; return; }
  var data=j.data||[];
  if(tarih) data=data.filter(function(r){return r.tarih===tarih;});
  if(ara)   data=data.filter(function(r){return (r.sofor_adi||'').toLowerCase().includes(ara)||(r.plaka||'').toLowerCase().includes(ara)||(r.firmalar||'').toLowerCase().includes(ara);});
  if(durum) data=data.filter(function(r){return r.durum===durum;});
  sfId('sf-cnt').textContent=data.length+' sefer';
  if(!data.length){ sfId('sf-tbody').innerHTML='<tr><td colspan="8"><div class="sf-empty"><div style="font-size:2rem">🚛</div><p>Sefer bulunamadı.</p></div></td></tr>'; return; }
  sfId('sf-tbody').innerHTML=data.map(function(r,i){
    var t=r.tarih?r.tarih.split('-').reverse().join('.'):'—';
    var frm=r.firmalar?(r.firmalar.length>55?r.firmalar.substring(0,53)+'...':r.firmalar):'—';
    return '<tr class="clickable" onclick="sfShowDetail('+r.id+')">'+
      '<td style="color:#64748B;font-weight:600">'+(i+1)+'</td>'+
      '<td style="font-size:.8rem;font-weight:500">'+t+'</td>'+
      '<td><div style="font-weight:600;font-size:.84rem">'+sfEsc(frm)+'</div><div style="font-size:.72rem;color:#64748B">'+r.nokta_sayisi+' durak</div></td>'+
      '<td>'+(r.sofor_adi?'<div style="font-weight:500">'+sfEsc(r.sofor_adi)+'</div>'+(r.sofor_tel?'<div style="font-size:.72rem;color:#64748B">'+sfEsc(r.sofor_tel)+'</div>':''):'<span style="color:#64748B">—</span>')+'</td>'+
      '<td><span style="font-weight:600;font-size:.8rem">'+sfEsc(r.plaka||'—')+'</span></td>'+
      '<td style="text-align:center"><span class="nbadge">'+r.nokta_sayisi+'</span></td>'+
      '<td>'+sfSB(r.durum)+'</td>'+
      '<td class="sf-actions" onclick="event.stopPropagation()">'+
        '<button class="btn btn-p btn-xs" onclick="sfShowDetail('+r.id+')">İncele</button>'+
        '<button class="btn btn-g btn-xs" onclick="sfOpenSefer('+r.id+')">✏️</button>'+
        '<button class="btn btn-d btn-xs" onclick="sfConfirmDelSefer('+r.id+',\''+sfEsc(r.sofor_adi||t).replace(/'/g,"\\'")+'\')">🗑</button>'+
      '</td>'+
    '</tr>';
  }).join('');
}

function sfSB(d){
  if(!d||d==='Planlandı')return'<span class="sb sb-plan">⬜ Planlandı</span>';
  if(d==='Tamamlandı')return'<span class="sb sb-ok">✅ Tamamlandı</span>';
  if(d==='Devam Ediyor')return'<span class="sb sb-prog">🔄 Devam Ediyor</span>';
  return'<span class="sb sb-plan">'+sfEsc(d)+'</span>';
}

async function sfLoadDetail(id){
  sfId('sf-detbody').innerHTML='<div class="sf-loading"><div class="sf-spinner"></div> Yükleniyor...</div>';
  var j=await sfApi('api=sefer_get&id='+id);
  if(!j.ok){sfId('sf-detbody').innerHTML='<p style="padding:20px;color:#DC2626">'+sfEsc(j.error)+'</p>';return;}
  sfRenderDetail(j.data);
}

function sfDurumCell(dv){
  if(!dv)return'<span style="color:#64748B">—</span>';
  var up=dv.toUpperCase();
  if(up==='ALINDI'||up==='TESLIM_EDILDI')return'<span class="nt-ok">✅ '+sfEsc(dv)+'</span>';
  if(up==='ALINMADI')return'<span style="font-weight:600;color:#DC2626">❌ Alınmadı</span>';
  if(up.indexOf('BIRAKILACAK')>=0||up.indexOf('IADE')>=0)return'<span class="nt-warn">⚠️ '+sfEsc(dv)+'</span>';
  return'<span style="font-weight:500">'+sfEsc(dv)+'</span>';
}

function sfRenderDetail(s){
  var noktalar=s.noktalar||[];
  var tp=s.tarih?s.tarih.split('-'):['','',''];
  var tarihFmt=tp[2]+'.'+tp[1]+'.'+tp[0];
  var gunFmt=s.tarih?SF_GUNLER[new Date(s.tarih).getDay()]:'';
  sfId('sf-crumb').textContent=tarihFmt+(s.sofor_adi?' — '+s.sofor_adi:'');
  var rows=noktalar.length?noktalar.map(function(n,i){
    return '<tr data-id="'+n.id+'">'+
      '<td style="width:28px;padding:0 4px;text-align:center"><span class="sf-drag-handle" title="Sırayı değiştirmek için sürükle">⠿</span></td>'+
      '<td><div class="nt-sira">'+(i+1)+'</div></td>'+
      '<td><div class="nt-firma">'+sfEsc(n.firma_adi)+'</div></td>'+
      '<td>'+(n.ilgili_kisi?'<div style="font-weight:500">'+sfEsc(n.ilgili_kisi)+'</div>':'<span style="color:#64748B">—</span>')+(n.iletisim?'<div class="nt-contact">📞 '+sfEsc(n.iletisim)+'</div>':'')+'</td>'+
      '<td style="font-size:.78rem;min-width:180px;white-space:normal;line-height:1.5">'+(sfEsc(n.adres)||'<span style="color:#64748B">—</span>')+'</td>'+
      '<td style="font-weight:600;white-space:normal;min-width:100px">'+(sfEsc(n.palet_miktari)||'—')+'</td>'+
      '<td>'+sfDurumCell(n.durum)+'</td>'+
      '<td class="sf-actions">'+
        '<button class="btn btn-g btn-xs" onclick="sfOpenNokta('+n.id+')">✏️</button>'+
        '<button class="btn btn-d btn-xs" onclick="sfConfirmDelNokta('+n.id+',\''+sfEsc(n.firma_adi).replace(/'/g,"\\'")+'\')">🗑</button>'+
      '</td>'+
    '</tr>';
  }).join(''):'<tr><td colspan="8"><div class="sf-empty"><div style="font-size:2rem">📭</div><p>Henüz nokta eklenmedi.</p></div></td></tr>';

  sfId('sf-detbody').innerHTML=
    '<div class="pf-wrap">'+
      '<div class="pf-hdr">'+
        '<div style="width:110px"></div>'+
        '<div class="pf-title">İSTANBUL — MALZEME ALIM BİLGİLERİ</div>'+
        '<div class="pf-datebox"><div class="pd">'+tarihFmt+'</div><div class="pg">'+gunFmt+'</div></div>'+
      '</div>'+
      '<div class="pf-info">'+
        '<div class="pi"><b>Şoför</b> '+(sfEsc(s.sofor_adi)||'—')+'</div>'+
        '<div class="pi"><b>Tel</b> '+(sfEsc(s.sofor_tel)||'—')+'</div>'+
        '<div class="pi"><b>Plaka</b> '+(sfEsc(s.plaka)||'—')+'</div>'+
        '<div class="pi"><b>Durum</b> '+sfEsc(s.durum||'—')+'</div>'+
        (s.notlar?'<div class="pi"><b>Not</b> '+sfEsc(s.notlar)+'</div>':'')+
      '</div>'+
      '<table class="nt-table">'+
        '<thead><tr>'+
          '<th style="width:28px"></th>'+
          '<th style="width:46px">Sıra</th>'+
          '<th style="width:130px">Firma Adı</th>'+
          '<th style="width:140px">İlgili / Tel</th>'+
          '<th style="min-width:180px">Adres</th>'+
          '<th style="width:120px">Palet / Miktar</th>'+
          '<th>Durum</th>'+
          '<th style="width:80px;text-align:right">İşlem</th>'+
        '</tr></thead>'+
        '<tbody>'+rows+'</tbody>'+
      '</table>'+
      '<div class="pf-imza">'+
        '<div class="pf-imza-box"><div class="lb">Şoför Ad/Soyad</div><div class="ln">'+sfEsc(s.sofor_adi||'')+'</div></div>'+
        '<div class="pf-imza-box"><div class="lb">İmza</div><div class="ln"></div></div>'+
      '</div>'+
    '</div>';
  sfInitDrag();
}

/* SEFER MODAL */
async function sfOpenSefer(id){
  sfClearAlert('ms-alert');
  if(id){
    sfId('ms-title').textContent='Sefer Düzenle'; sfId('ms-save').textContent='💾 Güncelle';
    var j=await sfApi('api=sefer_get&id='+id);
    if(!j.ok){alert('Veri alınamadı');return;}
    var r=j.data;
    sfId('ms-id').value=r.id; sfId('ms-tarih').value=r.tarih||'';
    sfId('ms-sofor').value=r.sofor_adi||''; sfId('ms-tel').value=r.sofor_tel||'';
    sfId('ms-plaka').value=r.plaka||''; sfId('ms-notlar').value=r.notlar||'';
    sfId('ms-durum').value=r.durum||'Planlandı';
  } else {
    sfId('ms-title').textContent='Yeni Sefer'; sfId('ms-save').textContent='💾 Kaydet';
    sfId('ms-id').value=''; sfId('ms-tarih').value='<?php echo $today;?>';
    sfId('ms-sofor').value=''; sfId('ms-tel').value='';
    sfId('ms-plaka').value=''; sfId('ms-notlar').value='';
    sfId('ms-durum').value='Planlandı';
  }
  sfOpenModal('m-sefer');
}
function sfEditSefer(){ sfOpenSefer(SF_CUR_ID); }
async function sfSaveSefer(){
  var btn=sfId('ms-save'); btn.disabled=true; btn.textContent='⏳...';
  var id=sfV('ms-id');
  if(!sfV('ms-tarih')){sfAlert('ms-alert','Tarih zorunlu');btn.disabled=false;btn.textContent=id?'💾 Güncelle':'💾 Kaydet';return;}
  var p={tarih:sfV('ms-tarih'),sofor_adi:sfV('ms-sofor'),sofor_tel:sfV('ms-tel'),plaka:sfV('ms-plaka'),durum:sfV('ms-durum'),notlar:sfV('ms-notlar')};
  if(id) p.id=parseInt(id);
  var j=await sfApi('api='+(id?'sefer_update':'sefer_add'),'POST',p);
  btn.disabled=false; btn.textContent=id?'💾 Güncelle':'💾 Kaydet';
  if(!j.ok){sfAlert('ms-alert',j.error);return;}
  sfCloseModal('m-sefer');
  if(id&&SF_CUR_ID==id) sfLoadDetail(id); else sfLoadList();
}

/* NOKTA MODAL */
async function sfOpenNokta(id){
  sfClearAlert('mn-alert');
  sfId('mn-sid').value=SF_CUR_ID;
  if(id){
    sfId('mn-title').textContent='Nokta Düzenle'; sfId('mn-save').textContent='💾 Güncelle';
    var j=await sfApi('api=sefer_get&id='+SF_CUR_ID);
    if(!j.ok){alert('Veri alınamadı');return;}
    var nokta=(j.data.noktalar||[]).find(function(n){return n.id==id;});
    if(!nokta){alert('Nokta bulunamadı');return;}
    sfId('mn-id').value=nokta.id;
    sfId('mn-firma').value=nokta.firma_adi||''; sfId('mn-kisi').value=nokta.ilgili_kisi||'';
    sfId('mn-tel').value=nokta.iletisim||''; sfId('mn-adres').value=nokta.adres||'';
    sfId('mn-palet').value=nokta.palet_miktari||'';
    var sel=sfId('mn-dsel'); var dv=nokta.durum||'';
    var known=Array.from(sel.options).map(function(o){return o.value;}).filter(function(v){return v&&v!=='custom';});
    if(!dv){sel.value='';sfId('mn-cw').style.display='none';sfId('mn-dtxt').value='';}
    else if(known.indexOf(dv)>=0){sel.value=dv;sfId('mn-dtxt').value=dv;sfId('mn-cw').style.display='none';}
    else{sel.value='custom';sfId('mn-dtxt').value=dv;sfId('mn-cw').style.display='';}
  } else {
    sfId('mn-title').textContent='Nokta Ekle'; sfId('mn-save').textContent='💾 Ekle';
    sfId('mn-id').value='';
    ['mn-firma','mn-kisi','mn-tel','mn-adres','mn-palet','mn-dtxt'].forEach(function(i){sfId(i).value='';});
    sfId('mn-dsel').value=''; sfId('mn-cw').style.display='none';
  }
  sfOpenModal('m-nokta');
}
function sfMnDurum(){
  var v=sfV('mn-dsel');
  sfId('mn-cw').style.display=v==='custom'?'':'none';
  sfId('mn-dtxt').value=v==='custom'?'':v;
}
async function sfSaveNokta(){
  var btn=sfId('mn-save'); btn.disabled=true; btn.textContent='⏳...';
  var id=sfV('mn-id'); var sid=sfV('mn-sid');
  var sv=sfV('mn-dsel');
  var durum=sv==='custom'?sfV('mn-dtxt').trim():(sfV('mn-dtxt').trim()||sv);
  var firma=sfV('mn-firma').trim();
  if(!firma){sfAlert('mn-alert','Firma adı zorunlu');btn.disabled=false;btn.textContent=id?'💾 Güncelle':'💾 Ekle';return;}
  var p={sefer_id:parseInt(sid),firma_adi:firma,ilgili_kisi:sfV('mn-kisi').trim(),iletisim:sfV('mn-tel').trim(),adres:sfV('mn-adres').trim(),palet_miktari:sfV('mn-palet').trim(),durum:durum};
  if(id) p.id=parseInt(id);
  var j=await sfApi('api='+(id?'nokta_update':'nokta_add'),'POST',p);
  btn.disabled=false; btn.textContent=id?'💾 Güncelle':'💾 Ekle';
  if(!j.ok){sfAlert('mn-alert',j.error);return;}
  sfCloseModal('m-nokta'); sfLoadDetail(SF_CUR_ID);
}

/* SİL */
function sfConfirmDelSefer(id,label){
  sfId('cf-title').textContent='"'+label+'" seferini sil?';
  sfId('cf-sub').textContent='Tüm nokta kayıtları da silinecek.';
  sfId('cf-btn').onclick=async function(){var j=await sfApi('api=sefer_delete','POST',{id:id});sfCloseModal('m-confirm');if(j.ok)sfLoadList();};
  sfOpenModal('m-confirm');
}
function sfConfirmDelNokta(id,firma){
  sfId('cf-title').textContent='"'+firma+'" noktasını sil?';
  sfId('cf-sub').textContent='Bu işlem geri alınamaz.';
  sfId('cf-btn').onclick=async function(){var j=await sfApi('api=nokta_delete','POST',{id:id});sfCloseModal('m-confirm');if(j.ok)sfLoadDetail(SF_CUR_ID);};
  sfOpenModal('m-confirm');
}

/* MODAL */
function sfOpenModal(id){ sfId(id).classList.add('on'); }
function sfCloseModal(id){ sfId(id).classList.remove('on'); }
document.querySelectorAll('#SF .sf-ovl').forEach(function(el){
  el.addEventListener('click',function(e){if(e.target===el)sfCloseModal(el.id);});
});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape') document.querySelectorAll('#SF .sf-ovl.on').forEach(function(el){sfCloseModal(el.id);});
});

/* PRINT */
function sfPrint(){
  var html=document.querySelector('#sf-detbody .pf-wrap');
  if(!html){alert('Önce bir sefer detayını açın.');return;}
  var blob=new Blob(['<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Sefer Formu</title><style>@page{size:A4 landscape;margin:0;}*{box-sizing:border-box;margin:0;padding:0;}body{background:#fff;font-family:Inter,system-ui,sans-serif;font-size:10pt;color:#111;}.pf-wrap{width:100%;padding:8mm 10mm;background:#fff;}.pf-hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;}.pf-title{font-weight:800;font-size:18pt;text-transform:uppercase;text-align:center;flex:1;letter-spacing:.4px;}.pf-datebox{text-align:right;flex-shrink:0;min-width:110px;}.pd{font-weight:700;font-size:11pt;}.pg{font-weight:800;font-size:13pt;}.pf-info{background:#111;color:#fff;padding:7px 13px;margin-bottom:11px;display:flex;flex-wrap:wrap;gap:4px 20px;align-items:center;font-size:9pt;-webkit-print-color-adjust:exact;print-color-adjust:exact;}.pi{display:flex;align-items:center;gap:4px;}.pi b{font-weight:700;color:#aaa;font-size:8pt;text-transform:uppercase;}.nt-table{width:100%;border-collapse:collapse;border:1.5px solid #111;}.nt-table thead{background:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact;}.nt-table thead th{padding:8px 9px;color:#fff;text-align:left;font-weight:700;font-size:8pt;text-transform:uppercase;letter-spacing:.5px;border:1px solid #333;}.nt-table tbody td{padding:8px 9px;font-size:9pt;vertical-align:middle;border:1px solid #bbb;line-height:1.4;white-space:normal;}.nt-sira{width:26px;height:26px;border-radius:50%;background:#111;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:9pt;-webkit-print-color-adjust:exact;print-color-adjust:exact;}.nt-firma{font-weight:700;font-size:10pt;}.nt-contact{font-size:8pt;color:#555;margin-top:2px;}.nt-warn{font-weight:700;color:#b91c1c;}.nt-ok{font-weight:600;color:#15803d;}.pf-imza{display:flex;justify-content:flex-end;gap:60px;margin-top:20px;}.pf-imza-box .lb{font-weight:700;font-size:8pt;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;text-align:center;}.pf-imza-box .ln{border-bottom:1.5px solid #111;width:170px;height:34px;display:flex;align-items:flex-end;padding-bottom:2px;font-weight:600;font-size:10pt;}.sf-drag-handle,.sf-actions{display:none!important;}</style></head><body>'+html.outerHTML+'<script>window.onload=function(){window.print();};<\/script></body></html>'],{type:'text/html;charset=utf-8'});
  var url=URL.createObjectURL(blob);
  var w=window.open(url,'_blank');
  if(w) w.onload=function(){setTimeout(function(){URL.revokeObjectURL(url);},1000);};
}

/* DRAG & DROP */
function sfInitDrag(){
  var tbody=document.querySelector('#sf-detbody .nt-table tbody');
  if(!tbody)return;
  var dragOver=null;
  tbody.addEventListener('mousedown',function(e){
    var h=e.target.closest('.sf-drag-handle');
    if(!h)return;
    var tr=h.closest('tr');
    if(tr)tr.setAttribute('draggable','true');
  });
  tbody.addEventListener('mouseup',function(){
    tbody.querySelectorAll('tr[draggable]').forEach(function(tr){tr.removeAttribute('draggable');});
  });
  tbody.addEventListener('dragstart',function(e){
    var tr=e.target.closest('tr');
    if(!tr){e.preventDefault();return;}
    SF_DRAG_SRC=tr;
    setTimeout(function(){tr.classList.add('sf-dragging');},0);
    e.dataTransfer.effectAllowed='move';
  });
  tbody.addEventListener('dragover',function(e){
    e.preventDefault();
    var tr=e.target.closest('tr');
    if(!tr||tr===SF_DRAG_SRC)return;
    if(tr!==dragOver){if(dragOver)dragOver.classList.remove('sf-drag-over');dragOver=tr;tr.classList.add('sf-drag-over');}
    e.dataTransfer.dropEffect='move';
  });
  tbody.addEventListener('drop',function(e){
    e.preventDefault();
    if(dragOver){dragOver.classList.remove('sf-drag-over');dragOver=null;}
    var tr=e.target.closest('tr');
    if(!tr||tr===SF_DRAG_SRC||!SF_DRAG_SRC)return;
    var rows=Array.from(tbody.querySelectorAll('tr'));
    var si=rows.indexOf(SF_DRAG_SRC),ti=rows.indexOf(tr);
    if(si<ti)tbody.insertBefore(SF_DRAG_SRC,tr.nextSibling);
    else tbody.insertBefore(SF_DRAG_SRC,tr);
    tbody.querySelectorAll('tr').forEach(function(r,i){var el=r.querySelector('.nt-sira');if(el)el.textContent=i+1;});
    sfSaveOrder(tbody);
  });
  tbody.addEventListener('dragend',function(){
    if(SF_DRAG_SRC){SF_DRAG_SRC.classList.remove('sf-dragging');SF_DRAG_SRC.removeAttribute('draggable');}
    if(dragOver){dragOver.classList.remove('sf-drag-over');dragOver=null;}
    SF_DRAG_SRC=null;
  });
}
async function sfSaveOrder(tbody){
  var order=[];
  tbody.querySelectorAll('tr[data-id]').forEach(function(tr,i){order.push({id:parseInt(tr.dataset.id),sira:i+1});});
  if(!order.length)return;
  await sfApi('api=nokta_reorder','POST',{order:order});
}

sfLoadList();
</script>
