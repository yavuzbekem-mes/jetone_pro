<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$mesaj    = '';
$mesaj_tip = '';

// Kaydet
if (isset($_POST['kaydet'])) {
    $tad    = trim($_POST['tedarikci_adi'] ?? '');
    $alt    = trim($_POST['alt_tedarikci'] ?? '');
    $kod    = trim(strtoupper($_POST['stok_kodu'] ?? ''));
    $min    = floatval($_POST['min_paket_miktari'] ?? 0);

    if (!$tad || !$kod || !$min) {
        $mesaj = 'Firma adı, stok kodu ve min. paket miktarı zorunludur.';
        $mesaj_tip = 'hata';
    } else {
        // Stok kodu daha önce kayıtlı mı?
        $chk = $db->prepare("SELECT COUNT(*) FROM tedarikci_listesi WHERE stok_kodu=?");
        $chk->execute([$kod]);
        if ($chk->fetchColumn() > 0) {
            $mesaj = "Bu stok kodu ($kod) zaten kayıtlı!";
            $mesaj_tip = 'hata';
        } else {
            // Stok adını Tiger'dan çek
            $stok_adi = '';
            if ($tiger_ok) {
                try {
                    $ts = $tigerdb_pdo->prepare("SELECT NAME FROM LG_222_ITEMS WHERE CODE=? AND CARDTYPE NOT IN (4,22)");
                    $ts->execute([$kod]);
                    $row = $ts->fetch(PDO::FETCH_ASSOC);
                    $stok_adi = $row['NAME'] ?? '';
                } catch(Throwable $e) {}
            }
            try {
                $ins = $db->prepare("INSERT INTO tedarikci_listesi (tedarikci_adi,alt_tedarikci,stok_kodu,stok_adi,min_paket_miktari,tarih) VALUES (?,?,?,?,?,NOW())");
                $ins->execute([$tad, $alt, $kod, $stok_adi, $min]);
                $mesaj = "Tedarikçi başarıyla kaydedildi.";
                $mesaj_tip = 'basarili';
            } catch(Throwable $e) {
                $mesaj = "Kayıt hatası: ".$e->getMessage();
                $mesaj_tip = 'hata';
            }
        }
    }
}

// Sil
if (isset($_POST['sil_id'])) {
    try {
        $db->prepare("DELETE FROM tedarikci_listesi WHERE id=?")->execute([(int)$_POST['sil_id']]);
        $mesaj = 'Kayıt silindi.';
        $mesaj_tip = 'basarili';
    } catch(Throwable $e) {
        $mesaj = 'Silme hatası: '.$e->getMessage();
        $mesaj_tip = 'hata';
    }
}

// Güncelle (inline edit AJAX)
if (isset($_POST['inline_guncelle'])) {
    header('Content-Type: application/json');
    $id  = (int)($_POST['id'] ?? 0);
    $col = $_POST['col'] ?? '';
    $val = trim($_POST['val'] ?? '');
    $izin = ['tedarikci_adi','alt_tedarikci','stok_kodu','stok_adi','min_paket_miktari'];
    if ($id && in_array($col, $izin)) {
        try {
            $db->prepare("UPDATE tedarikci_listesi SET `$col`=? WHERE id=?")->execute([$val, $id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e) {
            echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
        }
    } else {
        echo json_encode(['ok'=>false,'error'=>'Geçersiz istek']);
    }
    exit;
}

// Tiger cari listesi (yeni kayıt modalı için)
$cariler = [];
if ($tiger_ok) {
    try {
        $cs = $tigerdb_pdo->query("SELECT DISTINCT CLCARD.CODE AS kod, CLCARD.DEFINITION_ AS ad
            FROM LG_222_02_CLFLINE WITH(NOLOCK)
            LEFT JOIN LG_222_CLCARD WITH(NOLOCK) ON LG_222_02_CLFLINE.CLIENTREF=LG_222_CLCARD.LOGICALREF
            ORDER BY LG_222_CLCARD.DEFINITION_ ASC");
        $cariler = $cs->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Liste
$liste = $db->query("SELECT * FROM tedarikci_listesi ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
#tblTedKod th { background:#1E3A5F !important; color:#fff !important; }
#tblTedKod td, #tblTedKod th { border:1px solid #000 !important; }
#tblTedKod td[contenteditable=true]:focus { background:#FFFBEB !important; outline:2px solid #F59E0B; }
#tblTedKod td.kaydedildi { background:#D1FAE5 !important; transition:background .8s; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🏭 Tedarikçi Tanımlı Kodlar</h1>
    <div class="s-yol">Satınalma / <b>Tedarikçi Listesi</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px">(<?php echo count($liste);?> kayıt)</span>
    </div>
  </div>
  <button onclick="document.getElementById('plYeniModal').style.display='block'"
    style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
    ➕ Tedarikçi Ekle
  </button>
</div>

<?php if($mesaj):?>
<div style="background:<?php echo $mesaj_tip==='basarili'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $mesaj_tip==='basarili'?'#065F46':'#991B1B';?>;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-weight:600">
  <?php echo $mesaj_tip==='basarili'?'✅':'❌';?> <?php echo htmlspecialchars($mesaj);?>
</div>
<?php endif;?>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblTedKod" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:40px">#</th>
    <th>Stok Kodu</th>
    <th>Stok Adı</th>
    <th>Ana Firma Adı</th>
    <th>Alt Tedarikçi</th>
    <th style="text-align:right">Min. Paket Mik.</th>
    <th style="width:100px;text-align:center">İşlem</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Stok Kodu</th><th>Stok Adı</th>
    <th>Ana Firma Adı</th><th>Alt Tedarikçi</th>
    <th>Min. Paket Mik.</th><th>İşlem</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($liste as $i=>$r):?>
  <tr>
    <td style="color:#64748B;text-align:center;font-size:11px"><?php echo $i+1;?></td>
    <td contenteditable="true" onblur="plInline(this,<?php echo $r['id'];?>,'stok_kodu')"
        style="font-weight:700;color:#0369A1;white-space:nowrap"><?php echo htmlspecialchars($r['stok_kodu']);?></td>
    <td contenteditable="true" onblur="plInline(this,<?php echo $r['id'];?>,'stok_adi')"
        style="white-space:nowrap"><?php echo htmlspecialchars($r['stok_adi']??'');?></td>
    <td contenteditable="true" onblur="plInline(this,<?php echo $r['id'];?>,'tedarikci_adi')"
        style="font-weight:600;white-space:nowrap"><?php echo htmlspecialchars($r['tedarikci_adi']??'');?></td>
    <td contenteditable="true" onblur="plInline(this,<?php echo $r['id'];?>,'alt_tedarikci')"
        style="font-size:12px;color:#64748B;white-space:nowrap"><?php echo htmlspecialchars($r['alt_tedarikci']??'');?></td>
    <td contenteditable="true" onblur="plInline(this,<?php echo $r['id'];?>,'min_paket_miktari')"
        style="text-align:right;font-weight:600"><?php echo number_format((float)($r['min_paket_miktari']??0),0,'','.');?></td>
    <td style="text-align:center;white-space:nowrap">
      <button onclick="plKopyala(<?php echo $r['id'];?>)"
        style="background:#0369A1;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer;margin-right:3px">📋</button>
      <form method="POST" style="display:inline" onsubmit="return confirm('Silmek istediğinize emin misiniz?')">
        <input type="hidden" name="sil_id" value="<?php echo $r['id'];?>">
        <button type="submit" style="background:#DC2626;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer">🗑</button>
      </form>
    </td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($liste)):?>
  <tr><td colspan="7" style="text-align:center;padding:30px;color:#888">Henüz kayıt yok.</td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>
</div>

<!-- YENİ KAYIT MODAL -->
<div id="plYeniModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:10px;width:520px;max-width:100%;max-height:92vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="background:#1E3A5F;color:#fff;padding:13px 18px;border-radius:10px 10px 0 0;display:flex;align-items:center;justify-content:space-between">
      <span style="font-weight:700;font-size:14px">➕ Tedarikçi Ekle</span>
      <button onclick="document.getElementById('plYeniModal').style.display='none'" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:14px">✕</button>
    </div>
    <div style="padding:16px">
      <form method="POST">
        <div style="display:grid;grid-template-columns:1fr;gap:10px">
          <div>
            <label class="form-etiket">Ana Firma Adı *</label>
            <?php if(!empty($cariler)):?>
            <select name="tedarikci_adi" class="form-alan" id="plCariSel">
              <option value="">— Seçin —</option>
              <?php foreach($cariler as $c):?>
              <option value="<?php echo htmlspecialchars($c['ad']??'');?>"><?php echo htmlspecialchars($c['ad']??'');?> — <?php echo htmlspecialchars($c['kod']??'');?></option>
              <?php endforeach;?>
            </select>
            <?php else:?>
            <input type="text" name="tedarikci_adi" class="form-alan" placeholder="Firma adı...">
            <?php endif;?>
          </div>
          <div>
            <label class="form-etiket">Alt Tedarikçi (Müşteri)</label>
            <?php if(!empty($cariler)):?>
            <select name="alt_tedarikci" class="form-alan">
              <option value="">— Yok —</option>
              <?php foreach($cariler as $c):?>
              <option value="<?php echo htmlspecialchars($c['ad']??'');?>"><?php echo htmlspecialchars($c['ad']??'');?> — <?php echo htmlspecialchars($c['kod']??'');?></option>
              <?php endforeach;?>
            </select>
            <?php else:?>
            <input type="text" name="alt_tedarikci" class="form-alan" placeholder="Alt tedarikçi...">
            <?php endif;?>
          </div>
          <div>
            <label class="form-etiket">Stok Kodu *</label>
            <input type="text" name="stok_kodu" class="form-alan" placeholder="Ör: 9002860110" id="plStokKod" style="text-transform:uppercase">
            <div id="plStokAdiOnizle" style="font-size:11px;color:#065F46;margin-top:4px;font-weight:600"></div>
          </div>
          <div>
            <label class="form-etiket">Min. Paket Miktarı *</label>
            <input type="number" name="min_paket_miktari" class="form-alan" placeholder="Ör: 1000" step="0.01">
          </div>
        </div>
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px;padding-top:10px;border-top:1px solid #E2E8F0">
          <button type="button" onclick="document.getElementById('plYeniModal').style.display='none'"
            style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">İptal</button>
          <button type="submit" name="kaydet"
            style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// Modal flex display
document.getElementById('plYeniModal').style.cssText += ';display:none';
document.querySelector('#plYeniModal').addEventListener('click',function(e){if(e.target===this)this.style.display='none';});

// Inline edit kaydet
function plInline(el, id, col) {
  var val = el.innerText.trim();
  fetch('<?php echo BASE_URL;?>/bolumler/satinalma/ajax/tanimli_ted_ajax.php', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'id='+id+'&col='+encodeURIComponent(col)+'&val='+encodeURIComponent(val)
  }).then(r=>r.json()).then(d=>{
    if(d.ok){
      el.style.background='#D1FAE5';
      setTimeout(()=>{ el.style.background=''; }, 1500);
    } else {
      el.style.background='#FEE2E2';
      alert('Güncelleme hatası: '+(d.error||''));
    }
  }).catch(()=>{
    el.style.background='#FEE2E2';
  });
}

// Kopyala → modal aç, firma doldur
function plKopyala(id) {
  var row = document.querySelector('#tblTedKod tbody tr:nth-child('+(id+1)+')');
  // Daha güvenli: veri-id ile bul
  var rows = document.querySelectorAll('#tblTedKod tbody tr');
  var tad = '', alt = '';
  rows.forEach(function(tr) {
    var btn = tr.querySelector('button[onclick*="plKopyala('+id+')"]');
    if(btn) {
      tad = tr.cells[3].innerText.trim();
      alt = tr.cells[4].innerText.trim();
    }
  });
  var sel = document.getElementById('plCariSel');
  if(sel) { Array.from(sel.options).forEach(o=>{ if(o.value===tad) sel.value=tad; }); }
  document.getElementById('plStokKod').value = '';
  document.getElementById('plYeniModal').style.display = 'flex';
  setTimeout(()=>document.getElementById('plStokKod').focus(),100);
}

// Stok kodu onblur → Tiger'dan adı getir
<?php if($tiger_ok):?>
document.getElementById('plStokKod').addEventListener('blur', function(){
  var kod = this.value.trim().toUpperCase();
  if(!kod) return;
  var prev = document.getElementById('plStokAdiOnizle');
  prev.textContent = '⏳ Kontrol ediliyor...';
  // Tiger API yok, sunucu tarafı gerekli — basit bilgi göster
  prev.textContent = '';
});
<?php endif;?>

// DataTables
$(document).ready(function(){
  if(!$('#tblTedKod tbody tr td[colspan]').length) {
    $('#tblTedKod').DataTable({
      initComplete: function(){
        this.api().columns([1,2,3,4]).every(function(){
          var col=this, th=$(col.footer());
          if(!th||!th.length) return;
          var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
            .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
          col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
        });
      },
      language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
      scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
      columnDefs:[{orderable:false,targets:6}],
      dom:'Bfrtip',
      buttons:[
        {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Tanimli_Tedarikciler'},
        'print'
      ]
    });
  }
});
</script>
