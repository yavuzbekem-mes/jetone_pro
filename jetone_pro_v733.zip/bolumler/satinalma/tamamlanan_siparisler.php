<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$satirlar = [];

// Dönem filtresi
$currentYear  = (int)date('Y');
$selYear      = isset($_POST['year'])  ? (int)$_POST['year']  : $currentYear;
$selMonth     = isset($_POST['month']) ? (int)$_POST['month'] : 0; // 0 = tümü
$years  = range($currentYear, $currentYear - 4);
$months = [0=>'Tüm Aylar',1=>'Ocak',2=>'Şubat',3=>'Mart',4=>'Nisan',5=>'Mayıs',6=>'Haziran',
           7=>'Temmuz',8=>'Ağustos',9=>'Eylül',10=>'Ekim',11=>'Kasım',12=>'Aralık'];

if ($tiger_ok) {
    try {
        $ayFilter = $selMonth > 0
            ? "AND MONTH(ORF.DATE_) = ".intval($selMonth)
            : "";

        $sql = "SELECT
            ORF.FICHENO        AS siparis_no,
            IT.CODE            AS stok_kodu,
            IT.NAME            AS stok_adi,
            UNIL.CODE          AS birim,
            OL.AMOUNT          AS siparis_miktari,
            OL.SHIPPEDAMOUNT   AS gelen_miktar,
            FORMAT(ORF.DATE_,'dd.MM.yyyy')  AS siparis_tarihi,
            FORMAT(OL.DUEDATE,'dd.MM.yyyy') AS termin_tarihi,
            ISNULL((
                SELECT TOP 1 STF.FICHENO
                FROM LG_222_02_STLINE STL
                LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STL.STOCKREF=OL.STOCKREF AND STL.TRCODE=1 AND STL.CANCELLED=0
                ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,STL.DATE_)) ASC, STL.LOGICALREF ASC
            ),'') AS son_irsaliye_no,
            ISNULL((
                SELECT TOP 1 FORMAT(STL.DATE_,'dd.MM.yyyy')
                FROM LG_222_02_STLINE STL
                LEFT JOIN LG_222_02_STFICHE STF ON STL.STFICHEREF=STF.LOGICALREF
                WHERE STL.STOCKREF=OL.STOCKREF AND STL.TRCODE=1 AND STL.CANCELLED=0
                ORDER BY ABS(DATEDIFF(DAY,OL.DUEDATE,STL.DATE_)) ASC, STL.LOGICALREF ASC
            ),'') AS irsaliye_tarihi,
            CL.DEFINITION_ AS firma_adi
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON OL.STOCKREF=IT.LOGICALREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON ORF.CLIENTREF=CL.LOGICALREF
        LEFT JOIN dbo.LG_222_UNITSETL UNIL WITH(NOLOCK) ON OL.UOMREF=UNIL.LOGICALREF
        WHERE OL.TRCODE=2
          AND OL.SHIPPEDAMOUNT >= OL.AMOUNT
          AND YEAR(ORF.DATE_) = ".intval($selYear)."
          $ayFilter
        ORDER BY ORF.FICHENO DESC";

        $satirlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$firmalar = count(array_unique(array_column($satirlar, 'firma_adi')));
$baslik   = $months[$selMonth].' '.$selYear;
?>
<style>
#tblTamSip th { background:#1E3A5F !important; color:#fff !important; }
#tblTamSip td, #tblTamSip th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">✅ Tamamlanan Satınalma Siparişleri</h1>
    <div class="s-yol">Satınalma / <b>Tamamlanan Siparişler</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Yıl</label>
      <select name="year" class="form-alan">
        <?php foreach($years as $y):?><option value="<?php echo $y;?>" <?php echo $y==$selYear?'selected':'';?>><?php echo $y;?></option><?php endforeach;?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Ay</label>
      <select name="month" class="form-alan">
        <?php foreach($months as $n=>$ad):?><option value="<?php echo $n;?>" <?php echo $n==$selMonth?'selected':'';?>><?php echo $ad;?></option><?php endforeach;?>
      </select>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Getir</button>
  </form>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php elseif(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php else:?>

<!-- Özet -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#15803D"><?php echo count($satirlar);?></div>
    <div style="font-size:11px;color:#166534;font-weight:600">✅ Tamamlanan Kalem</div>
  </div>
  <div style="background:#DBEAFE;border:1px solid #93C5FD;border-radius:8px;padding:10px 18px">
    <div style="font-size:26px;font-weight:900;color:#1D4ED8"><?php echo $firmalar;?></div>
    <div style="font-size:11px;color:#1E40AF;font-weight:600">🏭 Tedarikçi</div>
  </div>
  <div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:10px 18px">
    <div style="font-size:16px;font-weight:700;color:#334155"><?php echo htmlspecialchars($baslik);?></div>
    <div style="font-size:11px;color:#64748B;font-weight:600">📅 Seçili Dönem</div>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblTamSip" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Firma Adı</th>
      <th>Sipariş No</th>
      <th>Stok Kodu</th>
      <th>Stok Adı</th>
      <th>Birim</th>
      <th style="text-align:right">Sipariş Mik.</th>
      <th style="text-align:right">Gelen Mik.</th>
      <th>Sipariş Tarihi</th>
      <th>Termin Tarihi</th>
      <th>Son İrsaliye No</th>
      <th>Son İrs. Tarihi</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Firma Adı</th><th>Sipariş No</th><th>Stok Kodu</th><th>Stok Adı</th>
      <th>Birim</th><th>Sipariş Mik.</th><th>Gelen Mik.</th>
      <th>Sipariş Tarihi</th><th>Termin Tarihi</th>
      <th>Son İrsaliye No</th><th>Son İrs. Tarihi</th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($satirlar as $r):?>
  <tr>
    <td style="font-weight:700"><?php echo htmlspecialchars($r['firma_adi']);?></td>
    <td style="font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['siparis_no']);?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']);?></code></td>
    <td><?php echo htmlspecialchars($r['stok_adi']);?></td>
    <td style="text-align:center;font-size:11px"><?php echo htmlspecialchars($r['birim']??'');?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format((float)$r['siparis_miktari'],0,'','.');?></td>
    <td style="text-align:right;color:#16A34A;font-weight:700"><?php echo number_format((float)$r['gelen_miktar'],0,'','.');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['siparis_tarihi']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['termin_tarihi']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['son_irsaliye_no']);?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['irsaliye_tarihi']);?></td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($satirlar)):?>
  <tr><td colspan="11" style="text-align:center;padding:30px;color:#888">Seçilen dönemde tamamlanan sipariş bulunamadı.</td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
  if(!$('#tblTamSip tbody tr').length || $('#tblTamSip tbody td[colspan]').length) return;
  $('#tblTamSip').DataTable({
    initComplete: function(){
      this.api().columns([0,1,2]).every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    order:[[1,'desc']],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Tamamlanan_Satinalma_<?php echo $selYear."_".$selMonth;?>'},
      'print'
    ]
  });
});
</script>
