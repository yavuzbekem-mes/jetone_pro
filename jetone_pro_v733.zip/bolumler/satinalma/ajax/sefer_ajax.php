<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
Auth::zorunlu();

$act  = $_GET['api'] ?? '';
$body = [];
$raw  = file_get_contents('php://input');
if ($raw) { $d = json_decode($raw, true); if (is_array($d)) $body = $d; }
if (empty($body) && !empty($_POST)) $body = $_POST;

try {
    if ($act === 'sefer_list') {
        $s = $db->query("SELECT s.*, COUNT(n.id) AS nokta_sayisi,
            GROUP_CONCAT(n.firma_adi ORDER BY n.sira SEPARATOR ', ') AS firmalar
            FROM seferler s LEFT JOIN sefer_noktalari n ON n.sefer_id=s.id
            GROUP BY s.id ORDER BY s.tarih DESC, s.id DESC");
        echo json_encode(['ok'=>1,'data'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
    }
    elseif ($act === 'sefer_get') {
        $id = (int)($_GET['id']??0);
        $s  = $db->prepare("SELECT * FROM seferler WHERE id=?");
        $s->execute([$id]);
        $sefer = $s->fetch(PDO::FETCH_ASSOC);
        if (!$sefer) { echo json_encode(['ok'=>0,'error'=>'Bulunamadı']); exit; }
        $n = $db->prepare("SELECT * FROM sefer_noktalari WHERE sefer_id=? ORDER BY sira");
        $n->execute([$id]);
        $sefer['noktalar'] = $n->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['ok'=>1,'data'=>$sefer]);
    }
    elseif ($act === 'sefer_add') {
        $s = $db->prepare("INSERT INTO seferler (tarih,sofor_adi,sofor_tel,plaka,durum,notlar) VALUES (?,?,?,?,?,?)");
        $s->execute([$body['tarih']??date('Y-m-d'),$body['sofor_adi']??'',$body['sofor_tel']??'',$body['plaka']??'',$body['durum']??'Planlandı',$body['notlar']??'']);
        echo json_encode(['ok'=>1,'id'=>$db->lastInsertId()]);
    }
    elseif ($act === 'sefer_update') {
        $id = (int)($body['id']??0);
        if (!$id) { echo json_encode(['ok'=>0,'error'=>'ID yok']); exit; }
        $db->prepare("UPDATE seferler SET tarih=?,sofor_adi=?,sofor_tel=?,plaka=?,durum=?,notlar=? WHERE id=?")
           ->execute([$body['tarih']??date('Y-m-d'),$body['sofor_adi']??'',$body['sofor_tel']??'',$body['plaka']??'',$body['durum']??'Planlandı',$body['notlar']??'',$id]);
        echo json_encode(['ok'=>1]);
    }
    elseif ($act === 'sefer_delete') {
        $id = (int)($body['id']??0);
        $db->prepare("DELETE FROM seferler WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>1]);
    }
    elseif ($act === 'nokta_add') {
        $sid = (int)($body['sefer_id']??0);
        if (!$sid||empty($body['firma_adi'])) { echo json_encode(['ok'=>0,'error'=>'Eksik alan']); exit; }
        $mx = $db->prepare("SELECT COALESCE(MAX(sira),0)+1 FROM sefer_noktalari WHERE sefer_id=?");
        $mx->execute([$sid]); $sira = (int)$mx->fetchColumn();
        $db->prepare("INSERT INTO sefer_noktalari (sefer_id,sira,firma_adi,ilgili_kisi,iletisim,adres,palet_miktari,durum) VALUES (?,?,?,?,?,?,?,?)")
           ->execute([$sid,$sira,trim($body['firma_adi']),$body['ilgili_kisi']??'',$body['iletisim']??'',$body['adres']??'',$body['palet_miktari']??'',$body['durum']??'']);
        echo json_encode(['ok'=>1,'id'=>$db->lastInsertId()]);
    }
    elseif ($act === 'nokta_update') {
        $id = (int)($body['id']??0);
        if (!$id) { echo json_encode(['ok'=>0,'error'=>'ID yok']); exit; }
        $db->prepare("UPDATE sefer_noktalari SET firma_adi=?,ilgili_kisi=?,iletisim=?,adres=?,palet_miktari=?,durum=? WHERE id=?")
           ->execute([trim($body['firma_adi']??''),$body['ilgili_kisi']??'',$body['iletisim']??'',$body['adres']??'',$body['palet_miktari']??'',$body['durum']??'',$id]);
        echo json_encode(['ok'=>1]);
    }
    elseif ($act === 'nokta_delete') {
        $id = (int)($body['id']??0);
        $db->prepare("DELETE FROM sefer_noktalari WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>1]);
    }
    elseif ($act === 'nokta_reorder') {
        $order = $body['order']??[];
        if (empty($order)||!is_array($order)) { echo json_encode(['ok'=>0,'error'=>'Sıra listesi boş']); exit; }
        $s = $db->prepare("UPDATE sefer_noktalari SET sira=? WHERE id=?");
        foreach ($order as $item) {
            $id=(int)($item['id']??0); $sira=(int)($item['sira']??0);
            if($id>0&&$sira>0) $s->execute([$sira,$id]);
        }
        echo json_encode(['ok'=>1]);
    }
    else {
        echo json_encode(['ok'=>0,'error'=>'Bilinmeyen işlem: '.htmlspecialchars($act)]);
    }
} catch (PDOException $e) {
    echo json_encode(['ok'=>0,'error'=>$e->getMessage()]);
}
