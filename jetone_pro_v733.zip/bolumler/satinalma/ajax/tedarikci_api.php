<?php
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
ob_start(); error_reporting(0); ini_set('display_errors',0);
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$firma = trim($_GET['firma'] ?? '');
if (!$firma) { echo json_encode(['ok'=>false,'error'=>'firma parametresi gerekli']); exit; }

try {
    $db->exec("SET NAMES 'utf8mb4'");

    // 1) Birebir eşleşme
    $stmt = $db->prepare("
        SELECT ilgili_kisi_ad, ilgili_kisi_mail, ilgili_kisi_tel, `ilgili_kisi_ünvan` AS unvan
        FROM tedarikci_bilgileri
        WHERE tedarikci_adi = ?
        ORDER BY id ASC
    ");
    $stmt->execute([trim($firma)]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2) Bulunamazsa LIKE araması
    if (empty($rows)) {
        $stmt2 = $db->prepare("
            SELECT ilgili_kisi_ad, ilgili_kisi_mail, ilgili_kisi_tel, `ilgili_kisi_ünvan` AS unvan
            FROM tedarikci_bilgileri
            WHERE tedarikci_adi LIKE ?
            ORDER BY id ASC
        ");
        $stmt2->execute(['%'.trim($firma).'%']);
        $rows = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    }

    // Geçerli mail adresleri
    $mails = array_values(array_unique(array_filter(
        array_column($rows, 'ilgili_kisi_mail'),
        fn($m) => $m && $m !== '0' && filter_var(trim($m), FILTER_VALIDATE_EMAIL)
    )));

    echo json_encode([
        'ok'               => !empty($rows),
        'firma'            => $firma,
        'eslesen_kayitlar' => $rows,   // eski API uyumu
        'mails'            => $mails,
        'sayi'             => count($mails)
    ]);
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
