<?php
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
ob_start(); error_reporting(0); ini_set('display_errors',0); ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$id  = (int)($_POST['id'] ?? 0);
$col = $_POST['col'] ?? '';
$val = trim($_POST['val'] ?? '');
$izin = ['tedarikci_adi','alt_tedarikci','stok_kodu','stok_adi','min_paket_miktari'];

if (!$id || !in_array($col, $izin)) {
    echo json_encode(['ok'=>false,'error'=>'Geçersiz istek']);
    exit;
}

try {
    $db->prepare("UPDATE tedarikci_listesi SET `$col`=? WHERE id=?")->execute([$val, $id]);
    echo json_encode(['ok'=>true]);
} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
