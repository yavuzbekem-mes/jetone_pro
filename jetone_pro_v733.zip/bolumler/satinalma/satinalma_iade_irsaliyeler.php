<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$satirlar = [];

// Dönem filtresi - varsayılan son 2 ay
$currentYear  = (int)date('Y');
$currentMonth = (int)date('m');
$selYear      = isset($_POST['year'])   ? (int)$_POST['year']   : $currentYear;
$selMonth     = isset($_POST['month'])  ? (int)$_POST['month']  : 0; // 0=tüm ay
$selMonth2    = isset($_POST['month2']) ? (int)$_POST['month2'] : 0; // bitiş ayı
$selAy        = isset($_POST['ay_aralik']) ? (int)$_POST['ay_aralik'] : 2; // ay aralığı

$years  = range($currentYear, $currentYear - 4);
$months = [0=>'Tüm Aylar',1=>'Ocak',2=>'Şubat',3=>'Mart',4=>'Nisan',5=>'Mayıs',6=>'Haziran',
           7=>'Temmuz',8=>'Ağustos',9=>'Eylül',10=>'Ekim',11=>'Kasım',12=>'Aralık'];

if ($tiger_ok) {
    try {
        $sql = "SELECT TOP 1000000 * FROM (
        SELECT
            YEAR(F.DATE_)                           AS yil,
            MONTH(F.DATE_)                          AS ay,
            F.SPECODE                               AS ozel_kod,
            CONVERT(VARCHAR(10),F.DATE_,104)        AS tarih,
            F.FICHENO                               AS irsaliye_no,
            C.DEFINITION_                           AS tedarikci,
            CASE WHEN L.LINETYPE=4 THEN S.CODE   ELSE I.CODE  END AS malzeme_kodu,
            CASE WHEN L.LINETYPE=4 THEN S.DEFINITION_ ELSE I.NAME END AS malzeme_adi,
            O.Siparis_Miktari                       AS siparis_miktari,
            L.AMOUNT                                AS miktar,
            U.CODE                                  AS birim,
            L.PRICE                                 AS birim_fiyat,
            L.TOTAL                                 AS toplam_tutar,
            ISNULL(F.GENEXP1,'')                    AS detay1,
            ISNULL(F.GENEXP2,'')                    AS detay2,
            ISNULL(F.GENEXP3,'')                    AS detay3,
            L.SPECODE2                              AS lot_no,
            F.DATE_                                 AS sort_tarih
        FROM LG_222_02_STLINE L WITH(NOLOCK)
        LEFT JOIN LG_222_02_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
        LEFT JOIN LG_222_ITEMS I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF AND L.LINETYPE IN(0,1)
        LEFT JOIN LG_222_SRVCARD S WITH(NOLOCK) ON S.LOGICALREF=L.STOCKREF AND L.LINETYPE=4
        LEFT JOIN LG_222_UNITSETL U ON L.UOMREF=U.LOGICALREF
        LEFT JOIN (SELECT ORDFICHEREF,STOCKREF,SUM(AMOUNT) Siparis_Miktari FROM LG_222_02_ORFLINE GROUP BY ORDFICHEREF,STOCKREF) O
            ON O.ORDFICHEREF=L.ORDFICHEREF AND O.STOCKREF=L.STOCKREF
        WHERE L.LINETYPE IN(0,1,4) AND L.CANCELLED=0 AND F.TRCODE=6
          AND F.DATE_ >= DATEADD(MONTH,-" . intval($selAy) . ",GETDATE())
          AND YEAR(F.DATE_) = " . intval($selYear) . "
          " . ($selMonth > 0 ? "AND MONTH(F.DATE_) = " . intval($selMonth) : "") . "

        UNION ALL

        SELECT
            YEAR(F.DATE_), MONTH(F.DATE_), F.SPECODE,
            CONVERT(VARCHAR(10),F.DATE_,104), F.FICHENO, C.DEFINITION_,
            CASE WHEN L.LINETYPE=4 THEN S.CODE   ELSE I.CODE  END,
            CASE WHEN L.LINETYPE=4 THEN S.DEFINITION_ ELSE I.NAME END,
            O.Siparis_Miktari, L.AMOUNT, U.CODE, L.PRICE, L.TOTAL,
            ISNULL(F.GENEXP1,''), ISNULL(F.GENEXP2,''), ISNULL(F.GENEXP3,''),
            L.SPECODE2, F.DATE_
        FROM LG_222_01_STLINE L WITH(NOLOCK)
        LEFT JOIN LG_222_01_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
        LEFT JOIN LG_222_ITEMS I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF AND L.LINETYPE IN(0,1)
        LEFT JOIN LG_222_SRVCARD S WITH(NOLOCK) ON S.LOGICALREF=L.STOCKREF AND L.LINETYPE=4
        LEFT JOIN LG_222_UNITSETL U ON L.UOMREF=U.LOGICALREF
        LEFT JOIN (SELECT ORDFICHEREF,STOCKREF,SUM(AMOUNT) Siparis_Miktari FROM LG_222_01_ORFLINE GROUP BY ORDFICHEREF,STOCKREF) O
            ON O.ORDFICHEREF=L.ORDFICHEREF AND O.STOCKREF=L.STOCKREF
        WHERE L.LINETYPE IN(0,1,4) AND L.CANCELLED=0 AND F.TRCODE=6
          AND F.DATE_ >= DATEADD(MONTH,-" . intval($selAy) . ",GETDATE())
          AND YEAR(F.DATE_) = " . intval($selYear) . "
          " . ($selMonth > 0 ? "AND MONTH(F.DATE_) = " . intval($selMonth) : "") . "
        ) X
        ORDER BY yil DESC, sort_tarih DESC, irsaliye_no DESC";

        $satirlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$benzersiz = count(array_unique(array_column($satirlar, 'irsaliye_no')));
?>
<style>
#tblSatIade th { background:#1E3A5F !important; color:#fff !important; }
#tblSatIade td, #tblSatIade th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">↩️ Satınalma İade İrsaliyeleri</h1>
    <div class="s-yol">Satınalma / <b>İade İrsaliyeleri</b>
      <?php if($tiger_ok):?>
        <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
        <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo $benzersiz;?> irsaliye, <?php echo count($satirlar);?> kalem — son 12 ay)</span>
      <?php else:?>
        <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span>
      <?php endif;?>
    </div>
  </div>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Yıl</label>
      <select name="year" class="form-alan">
        <?php foreach($years as $y):?><option value="<?php echo $y;?>" <?php echo $y==$selYear?'selected':'';?>><?php echo $y;?></option><?php endforeach;?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Ay</label>
      <select name="month" class="form-alan">
        <?php foreach($months as $n=>$ad):?><option value="<?php echo $n;?>" <?php echo $n==$selMonth?'selected':'';?>><?php echo $ad;?></option><?php endforeach;?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Son X Ay</label>
      <select name="ay_aralik" class="form-alan">
        <?php foreach([1=>'1 Ay',2=>'2 Ay',3=>'3 Ay',6=>'6 Ay',12=>'12 Ay',24=>'24 Ay'] as $v=>$ad):?>
        <option value="<?php echo $v;?>" <?php echo $v==$selAy?'selected':'';?>><?php echo $ad;?></option>
        <?php endforeach;?>
      </select>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Filtrele</button>
    <a href="?sayfa=<?php echo $_GET['sayfa']??'';?>" style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">↺ Sıfırla</a>
  </form>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php elseif(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php elseif(empty($satirlar)):?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:30px;text-align:center;color:var(--m2)">İrsaliye bulunamadı.</div>
<?php else:?>

<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblSatIade" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>İrs. No</th>
    <th>Tarih</th>
    <th>Tedarikçi</th>
    <th>Malzeme Kodu</th>
    <th>Malzeme Adı</th>
    <th style="text-align:right">Sipariş Mik.</th>
    <th style="text-align:right">Satınalma Mik.</th>
    <th>Birim</th>
    <th style="text-align:right">Birim Fiyat</th>
    <th style="text-align:right">Toplam Tutar</th>
    <th>Özel Kod</th>
    <th>Lot No</th>
    <th>Detay 1</th>
    <th>Detay 2</th>
    <th>Detay 3</th>
  </tr></thead>
  <tfoot><tr>
    <th>İrs. No</th><th>Tarih</th><th>Tedarikçi</th>
    <th>Malzeme Kodu</th><th>Malzeme Adı</th>
    <th>Sipariş Mik.</th><th>Satınalma Mik.</th><th>Birim</th>
    <th>Birim Fiyat</th><th>Toplam Tutar</th>
    <th>Özel Kod</th><th>Lot No</th>
    <th>Detay 1</th><th>Detay 2</th><th>Detay 3</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($satirlar as $r):?>
  <tr>
    <td style="font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['irsaliye_no']);?></td>
    <td data-order="<?php echo date('Y-m-d', strtotime($r['sort_tarih']));?>"><?php echo htmlspecialchars($r['tarih']);?></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($r['tedarikci']??'');?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['malzeme_kodu']??'');?></code></td>
    <td><?php echo htmlspecialchars($r['malzeme_adi']??'');?></td>
    <td style="text-align:right"><?php echo $r['siparis_miktari'] ? number_format((float)$r['siparis_miktari'],0,'','.'): '—';?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format((float)($r['miktar']??0),0,'','.');?></td>
    <td style="text-align:center;font-size:11px"><?php echo htmlspecialchars($r['birim']??'');?></td>
    <td style="text-align:right;font-size:11px"><?php echo number_format((float)($r['birim_fiyat']??0),4,',','.');?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format((float)($r['toplam_tutar']??0),2,',','.');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['ozel_kod']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['lot_no']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars(trim($r['detay1']??''));?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars(trim($r['detay2']??''));?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars(trim($r['detay3']??''));?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
  if(!$('#tblSatIade tbody tr').length) return;
  $('#tblSatIade').DataTable({
    initComplete: function(){
      this.api().columns([0,1,2,3,7,10]).every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    order:[[1,'desc']],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Satinalma_Iade_Irsaliyeler'},
      'print'
    ]
  });
});
</script>
