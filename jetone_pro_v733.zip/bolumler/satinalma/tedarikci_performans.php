<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';

$currentYear  = (int)date('Y');
$selYear      = isset($_POST['year'])  ? (int)$_POST['year']  : $currentYear;
$selMonth     = isset($_POST['month']) ? (int)$_POST['month'] : 0;
$years  = range($currentYear, $currentYear-3);
$months = [0=>'Tüm Yıl',1=>'Ocak',2=>'Şubat',3=>'Mart',4=>'Nisan',5=>'Mayıs',6=>'Haziran',
           7=>'Temmuz',8=>'Ağustos',9=>'Eylül',10=>'Ekim',11=>'Kasım',12=>'Aralık'];

// Performans verisi: Tiger irsaliyeler vs termin
$performans = []; // firma => [zamaninda, gec, toplam, puanlar]
$aylik_genel = []; // ay => [zamaninda, gec, toplam]

if ($tiger_ok) {
    try {
        // Filtre: DUEDATE ayına göre (teslim tarihi esas)
        $ayFlt = $selMonth > 0 ? "AND MONTH(OL.DUEDATE) = ".intval($selMonth) : "";

        // Doğru mantık:
        // Her sipariş kalemi (ORFLINE) için terminle EN YAKIN irsaliyeyi bul (CROSS APPLY)
        // Gecikme = irsaliye tarihi - termin tarihi
        // Yıl filtresi DUEDATE üzerinden uygulanır
        $sql = "
        SELECT
            CL.DEFINITION_                                  AS firma,
            OL.DUEDATE                                      AS termin,
            MONTH(OL.DUEDATE)                               AS ay,
            ORF.FICHENO                                     AS siparis_no,
            IT.CODE                                         AS stok_kodu,
            IT.NAME                                         AS stok_adi,
            nearest.irs_tarihi                              AS irs_tarihi,
            nearest.irs_no                                  AS irs_no,
            DATEDIFF(DAY, OL.DUEDATE, nearest.irs_tarihi)  AS gecikme_gun
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF = ORF.LOGICALREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON ORF.CLIENTREF = CL.LOGICALREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON OL.STOCKREF = IT.LOGICALREF
        CROSS APPLY (
            SELECT TOP 1
                F.DATE_    AS irs_tarihi,
                F.FICHENO  AS irs_no
            FROM dbo.LG_222_02_STLINE SL WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_02_STFICHE F WITH(NOLOCK) ON SL.STFICHEREF = F.LOGICALREF
            WHERE SL.STOCKREF = OL.STOCKREF
              AND SL.TRCODE = 1
              AND SL.CANCELLED = 0
              AND F.TRCODE = 1
              AND SL.AMOUNT > 0
            ORDER BY ABS(DATEDIFF(DAY, OL.DUEDATE, F.DATE_)) ASC, F.DATE_ ASC
        ) nearest
        WHERE OL.TRCODE = 2
          AND OL.SHIPPEDAMOUNT > 0
          AND YEAR(OL.DUEDATE) = ".intval($selYear)."
          $ayFlt
          AND CL.DEFINITION_ IS NOT NULL
          AND OL.DUEDATE IS NOT NULL
        ORDER BY CL.DEFINITION_, OL.DUEDATE";

        $rows = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $r) {
            $f   = $r['firma'] ?? 'Bilinmiyor';
            $gec = (int)($r['gecikme_gun'] ?? 0);
            $ay  = (int)($r['ay'] ?? 0);

            if (!isset($performans[$f])) $performans[$f] = ['zamaninda'=>0,'gec'=>0,'toplam'=>0];
            if (!isset($aylik_genel[$ay])) $aylik_genel[$ay] = ['zamaninda'=>0,'gec'=>0,'toplam'=>0];

            $performans[$f]['toplam']++;
            $aylik_genel[$ay]['toplam']++;

            // ≤2 gün gecikmeli = zamanında (erken veya en geç +2 gün)
            if ($gec <= 2) {
                $performans[$f]['zamaninda']++;
                $aylik_genel[$ay]['zamaninda']++;
            } else {
                $performans[$f]['gec']++;
                $aylik_genel[$ay]['gec']++;
            }
        }

        // Puan hesapla ve sırala
        foreach ($performans as $f => &$v) {
            $v['puan'] = $v['toplam'] > 0 ? round($v['zamaninda'] / $v['toplam'] * 100, 1) : 0;
        }
        uasort($performans, fn($a,$b) => $b['puan'] <=> $a['puan']);

    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$genel_toplam    = array_sum(array_column($performans, 'toplam'));
$genel_zamaninda = array_sum(array_column($performans, 'zamaninda'));
$genel_puan      = $genel_toplam > 0 ? round($genel_zamaninda / $genel_toplam * 100, 1) : 0;

function puan_renk($p) {
    if ($p >= 90) return ['#D1FAE5','#065F46','🟢'];
    if ($p >= 70) return ['#FEF9C3','#854D0E','🟡'];
    if ($p >= 50) return ['#FED7AA','#92400E','🟠'];
    return ['#FEE2E2','#991B1B','🔴'];
}
?>
<style>
#tblPerf th { background:#1E3A5F !important; color:#fff !important; }
#tblPerf td, #tblPerf th { border:1px solid #000 !important; white-space:nowrap !important; }
.perf-bar { height:8px;border-radius:4px;background:#E2E8F0;overflow:hidden }
.perf-bar-fill { height:100%;border-radius:4px;transition:width .5s }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📈 Tedarikçi Performans</h1>
    <div class="s-yol">Satınalma / <b>Termin Uyum Analizi</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
    <div><label class="form-etiket">Yıl</label>
      <select name="year" class="form-alan">
        <?php foreach($years as $y):?><option value="<?php echo $y;?>" <?php echo $y==$selYear?'selected':'';?>><?php echo $y;?></option><?php endforeach;?>
      </select></div>
    <div><label class="form-etiket">Ay</label>
      <select name="month" class="form-alan">
        <?php foreach($months as $n=>$ad):?><option value="<?php echo $n;?>" <?php echo $n==$selMonth?'selected':'';?>><?php echo $ad;?></option><?php endforeach;?>
      </select></div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Analiz Et</button>
  </form>
  <div style="margin-top:8px;font-size:11px;color:#64748B">
    ✅ <b>Zamanında:</b> Termin tarihinden erken veya en geç +2 gün içinde gelen teslimatlar puan alır.
    ❌ <b>Geç:</b> +2 günden fazla gecikmeli teslimatlar puan almaz.
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php elseif(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php elseif(empty($performans)):?>
<div style="background:#F1F5F9;padding:30px;text-align:center;color:#888;border-radius:8px">Seçilen dönemde veri bulunamadı.</div>
<?php else:?>

<!-- Genel Özet -->
<?php list($bg,$tc,$ic) = puan_renk($genel_puan);?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px">
  <div style="background:<?php echo $bg;?>;border:1px solid #E2E8F0;border-radius:10px;padding:14px 18px">
    <div style="font-size:32px;font-weight:900;color:<?php echo $tc;?>"><?php echo $genel_puan;?>%</div>
    <div style="font-size:12px;font-weight:600;color:#374151"><?php echo $ic;?> Genel Performans</div>
  </div>
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:10px;padding:14px 18px">
    <div style="font-size:32px;font-weight:900;color:#15803D"><?php echo $genel_zamaninda;?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">✅ Zamanında Teslimat</div>
  </div>
  <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:10px;padding:14px 18px">
    <div style="font-size:32px;font-weight:900;color:#DC2626"><?php echo $genel_toplam - $genel_zamaninda;?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">❌ Geç Teslimat</div>
  </div>
  <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:14px 18px">
    <div style="font-size:32px;font-weight:900;color:#1D4ED8"><?php echo count($performans);?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">🏭 Tedarikçi Sayısı</div>
  </div>
</div>

<!-- Aylık Genel Grafik -->
<?php if($selMonth === 0 && !empty($aylik_genel)):?>
<div class="kart" style="padding:10px;margin-bottom:12px">
  <div style="font-weight:700;font-size:11px;color:#1E3A5F;margin-bottom:6px">📅 Aylık Genel Performans (<?php echo $selYear;?>)</div>
  <div style="position:relative;height:120px">
    <canvas id="aylikChart"></canvas>
  </div>
</div>
<?php endif;?>

<!-- Firma Bazlı Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblPerf" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:35px">#</th>
    <th>Firma Adı</th>
    <th style="text-align:center">Performans</th>
    <th style="text-align:center">İlerleme</th>
    <th style="text-align:center">✅ Zamanında</th>
    <th style="text-align:center">❌ Geç</th>
    <th style="text-align:center">Toplam</th>
    <th style="text-align:center">Durum</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Firma Adı</th><th>Performans</th><th>İlerleme</th>
    <th>Zamanında</th><th>Geç</th><th>Toplam</th><th>Durum</th>
  </tr></tfoot>
  <tbody>
  <?php $i=1; foreach($performans as $firma=>$v): list($bg,$tc,$ic)=puan_renk($v['puan']);?>
  <tr>
    <td style="text-align:center;color:#64748B;font-size:11px"><?php echo $i++;?></td>
    <td style="font-weight:700"><?php echo htmlspecialchars($firma);?></td>
    <td style="text-align:center">
      <span style="background:<?php echo $bg;?>;color:<?php echo $tc;?>;padding:3px 10px;border-radius:100px;font-weight:700;font-size:13px">
        <?php echo $v['puan'];?>%
      </span>
    </td>
    <td style="min-width:120px;padding:0 12px">
      <div class="perf-bar">
        <div class="perf-bar-fill" style="width:<?php echo $v['puan'];?>%;background:<?php echo $v['puan']>=70?'#16A34A':($v['puan']>=50?'#F59E0B':'#DC2626');?>"></div>
      </div>
    </td>
    <td style="text-align:center;color:#16A34A;font-weight:700"><?php echo $v['zamaninda'];?></td>
    <td style="text-align:center;color:#DC2626;font-weight:700"><?php echo $v['gec'];?></td>
    <td style="text-align:center;font-weight:600"><?php echo $v['toplam'];?></td>
    <td style="text-align:center;font-size:16px"><?php echo $ic;?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
<?php if($selMonth === 0 && !empty($aylik_genel)): ksort($aylik_genel); ?>
var ayLabels = <?php echo json_encode(array_map(fn($a)=>['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'][$a], array_keys($aylik_genel)));?>;
var ayZaman  = <?php echo json_encode(array_map(fn($v)=>$v['toplam']>0?round($v['zamaninda']/$v['toplam']*100,1):0, array_values($aylik_genel)));?>;
var ayGec    = <?php echo json_encode(array_map(fn($v)=>$v['toplam']>0?round($v['gec']/$v['toplam']*100,1):0, array_values($aylik_genel)));?>;
new Chart(document.getElementById('aylikChart'),{
  type:'bar',
  data:{
    labels:ayLabels,
    datasets:[
      {label:'Zamanında %',data:ayZaman,backgroundColor:'rgba(22,163,74,.7)',borderRadius:3},
      {label:'Geç %',data:ayGec,backgroundColor:'rgba(220,38,38,.6)',borderRadius:3}
    ]
  },
  options:{
    responsive:true,
    maintainAspectRatio:false,
    scales:{
      x:{stacked:true,ticks:{font:{size:10}},grid:{display:false}},
      y:{stacked:true,max:100,ticks:{font:{size:10},callback:function(v){return v+'%'}},grid:{color:'rgba(0,0,0,.05)'}}
    },
    plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:12}}}
  }
});
<?php endif;?>

$(document).ready(function(){
  if(!$('#tblPerf tbody tr td[colspan]').length){
    $('#tblPerf').DataTable({
      initComplete:function(){
        this.api().columns([1,7]).every(function(){
          var col=this,th=$(col.footer());
          if(!th||!th.length)return;
          var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
            .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
          col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+v+'</option>');});
        });
      },
      language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
      scrollCollapse:true,scrollY:500,paging:false,scrollX:true,
      order:[[2,'desc']],
      columnDefs:[{orderable:false,targets:[3,7]}],
      dom:'Bfrtip',
      buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Tedarikci_Performans_<?php echo $selYear."_".$selMonth;?>'}]
    });
  }
});
</script>
<?php endif;?>
