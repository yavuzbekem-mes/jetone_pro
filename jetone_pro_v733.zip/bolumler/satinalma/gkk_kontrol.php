<?php
/**
 * GKK - Giriş Kalite Kontrol
 * Route: satinalma-gkk
 */
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();
set_time_limit(60);

$tiger_ok = ($tigerdb_pdo !== null);
$mes_ok   = ($mes_pdo    !== null);
$hata     = '';

$f_basl    = trim($_GET['basl']    ?? date('Y-m-01'));
$f_bitis   = trim($_GET['bitis']   ?? date('Y-m-d'));
$f_irsno   = trim($_GET['irsno']   ?? '');
$f_stok    = trim($_GET['stok']    ?? '');
$f_tedarik = trim($_GET['tedarik'] ?? '');
$f_durum   = trim($_GET['durum']   ?? 'bekliyor'); // bekliyor | tamam | hepsi

// GKK tablosu oluştur
global $db;
if($db) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS gkk_kontrol (
            id           INT AUTO_INCREMENT PRIMARY KEY,
            irsaliye_no  VARCHAR(100) NOT NULL,
            stok_kodu    VARCHAR(100) NOT NULL,
            stok_adi     VARCHAR(255) DEFAULT '',
            miktar       DECIMAL(18,4) DEFAULT 0,
            birim        VARCHAR(20)  DEFAULT 'ADET',
            tedarikci    VARCHAR(255) DEFAULT '',
            cari_kodu    VARCHAR(100) DEFAULT '',
            karar        ENUM('KABUL','SARTLI_KABUL','RED') NOT NULL,
            aciklama     TEXT,
            kayit_eden   VARCHAR(100) DEFAULT '',
            kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_irsno_stok (irsaliye_no, stok_kodu)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch(Throwable $e) {}
}

// Etiket alınmış kalemleri Tiger'dan çek
$satirlar = [];
if($tiger_ok && $mes_ok) {
    try {
        $w = ["L.LINETYPE IN(0,1) AND L.CANCELLED=0 AND F.TRCODE=1",
              "CONVERT(date,F.DATE_) BETWEEN ? AND ?"];
        $p = [$f_basl, $f_bitis];
        if($f_irsno)   { $w[] = "F.FICHENO LIKE ?"; $p[] = "%$f_irsno%"; }
        if($f_stok)    { $w[] = "I.CODE LIKE ?";    $p[] = "%$f_stok%"; }
        if($f_tedarik) { $w[] = "C.DEFINITION_ LIKE ?"; $p[] = "%$f_tedarik%"; }
        $ws = implode(' AND ', $w);

        $sql = "SELECT F.FICHENO AS irsaliye_no, CONVERT(date,F.DATE_) AS tarih,
                       C.CODE AS cari_kodu, C.DEFINITION_ AS tedarikci,
                       I.CODE AS stok_kodu, I.NAME AS stok_adi,
                       SUM(L.AMOUNT) AS miktar, U.CODE AS birim,
                       ISNULL(C.EMAILADDR,'') AS email
                FROM LG_222_01_STLINE L WITH(NOLOCK)
                JOIN LG_222_01_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
                LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
                LEFT JOIN LG_222_ITEMS I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF
                LEFT JOIN LG_222_UNITSETL U WITH(NOLOCK) ON U.LOGICALREF=L.UOMREF
                WHERE $ws
                GROUP BY F.FICHENO,F.DATE_,C.CODE,C.DEFINITION_,I.CODE,I.NAME,U.CODE,C.EMAILADDR
                UNION ALL
                SELECT F.FICHENO,CONVERT(date,F.DATE_),C.CODE,C.DEFINITION_,
                       I.CODE,I.NAME,SUM(L.AMOUNT),U.CODE,ISNULL(C.EMAILADDR,'')
                FROM LG_222_02_STLINE L WITH(NOLOCK)
                JOIN LG_222_02_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
                LEFT JOIN LG_222_CLCARD C WITH(NOLOCK) ON C.LOGICALREF=F.CLIENTREF
                LEFT JOIN LG_222_ITEMS I WITH(NOLOCK) ON I.LOGICALREF=L.STOCKREF
                LEFT JOIN LG_222_UNITSETL U WITH(NOLOCK) ON U.LOGICALREF=L.UOMREF
                WHERE $ws
                GROUP BY F.FICHENO,F.DATE_,C.CODE,C.DEFINITION_,I.CODE,I.NAME,U.CODE,C.EMAILADDR";

        $st = $tigerdb_pdo->prepare($sql);
        $st->execute(array_merge($p, $p));
        $tumSatirlar = $st->fetchAll(PDO::FETCH_ASSOC);

        // Sadece etiket alınmışları göster
        $irsno_list = array_unique(array_column($tumSatirlar,'irsaliye_no'));
        $etiket_map = []; // irsno|stok => ['paket_sayisi','toplam_miktar']
        if(!empty($irsno_list)) {
            $in = implode(',',array_fill(0,count($irsno_list),'?'));
            $se = $mes_pdo->prepare(
                "SELECT URETIM_EMRI_NO,STOK_KODU,COUNT(*) AS cnt,SUM(MIKTAR) AS top
                 FROM dbo.PAKETLER WHERE URETIM_EMRI_NO IN ($in) AND AKTIF IN (0,2)
                 GROUP BY URETIM_EMRI_NO,STOK_KODU"
            );
            $se->execute(array_values($irsno_list));
            foreach($se->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $etiket_map[$r['URETIM_EMRI_NO'].'|'.$r['STOK_KODU']] = [
                    'paket_sayisi' => (int)$r['cnt'],
                    'toplam_miktar'=> (float)$r['top'],
                ];
            }
        }

        // GKK kararlarını çek
        $gkk_map = []; // irsno|stok => karar
        if($db && !empty($irsno_list)) {
            try {
                $in2 = implode(',',array_fill(0,count($irsno_list),'?'));
                $sg = $db->prepare("SELECT irsaliye_no,stok_kodu,karar FROM gkk_kontrol WHERE irsaliye_no IN ($in2)");
                $sg->execute(array_values($irsno_list));
                foreach($sg->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    $gkk_map[$r['irsaliye_no'].'|'.$r['stok_kodu']] = $r['karar'];
                }
            } catch(Throwable $e){}
        }

        // Filtrele
        foreach($tumSatirlar as $r) {
            $key = $r['irsaliye_no'].'|'.$r['stok_kodu'];
            $etiket = $etiket_map[$key] ?? null;
            if(!$etiket) continue; // etiket alınmamış, gösterme

            $gkk_karar = $gkk_map[$key] ?? null;

            // Durum filtresi
            if($f_durum === 'bekliyor' && $gkk_karar !== null) continue;
            if($f_durum === 'tamam'    && $gkk_karar === null) continue;

            $satirlar[] = array_merge($r, [
                'paket_sayisi'  => $etiket['paket_sayisi'],
                'etiket_miktar' => $etiket['toplam_miktar'],
                'gkk_karar'     => $gkk_karar,
            ]);
        }

        // UNION dedup
        $uniq = []; $satirlar_son = [];
        foreach($satirlar as $r) {
            $key = $r['irsaliye_no'].'|'.$r['stok_kodu'];
            if(!isset($uniq[$key])) { $uniq[$key]=true; $satirlar_son[]=$r; }
        }
        $satirlar = $satirlar_son;
        usort($satirlar, fn($a,$b) => strcmp($b['tarih'].$b['irsaliye_no'], $a['tarih'].$a['irsaliye_no']));

    } catch(Throwable $e){ $hata = $e->getMessage(); }
}

$toplam     = count($satirlar);
$bekleyen   = count(array_filter($satirlar, fn($r) => $r['gkk_karar'] === null));
$kararli    = $toplam - $bekleyen;
?>
<style>
.gkk-badge-bekliyor   { background:#FEF3C7;color:#92400E;padding:3px 10px;border-radius:12px;font-size:10px;font-weight:700 }
.gkk-badge-KABUL      { background:#D1FAE5;color:#065F46;padding:3px 10px;border-radius:12px;font-size:10px;font-weight:700 }
.gkk-badge-SARTLI_KABUL { background:#DBEAFE;color:#1E40AF;padding:3px 10px;border-radius:12px;font-size:10px;font-weight:700 }
.gkk-badge-RED        { background:#FEE2E2;color:#7F1D1D;padding:3px 10px;border-radius:12px;font-size:10px;font-weight:700 }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔬 GKK — Giriş Kalite Kontrol</h1>
    <div class="s-yol">Satınalma / <b>GKK</b></div>
  </div>
</div>
<div class="s-body">

<?php if($hata):?>
<div style="padding:12px;background:#FEF2F2;color:#7F1D1D;border:1px solid #FECACA;border-radius:var(--r);margin-bottom:14px;font-size:13px">⚠️ <?=htmlspecialchars($hata)?></div>
<?php endif;?>

<!-- Filtre -->
<div class="kart" style="padding:16px;margin-bottom:14px">
  <form method="GET" action="">
    <input type="hidden" name="sayfa" value="satinalma-gkk">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;align-items:flex-end">
      <div><label class="form-et" style="font-size:11px">Başlangıç</label>
           <input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
      <div><label class="form-et" style="font-size:11px">Bitiş</label>
           <input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
      <div><label class="form-et" style="font-size:11px">İrsaliye No</label>
           <input type="text" name="irsno" class="form-alan" value="<?=htmlspecialchars($f_irsno)?>" placeholder="İRS..."></div>
      <div><label class="form-et" style="font-size:11px">Stok Kodu</label>
           <input type="text" name="stok" class="form-alan" value="<?=htmlspecialchars($f_stok)?>" placeholder="2961..."></div>
      <div><label class="form-et" style="font-size:11px">Tedarikçi</label>
           <input type="text" name="tedarik" class="form-alan" value="<?=htmlspecialchars($f_tedarik)?>" placeholder="Firma..."></div>
      <div><label class="form-et" style="font-size:11px">Durum</label>
           <select name="durum" class="form-alan">
             <option value="bekliyor" <?=$f_durum==='bekliyor'?'selected':''?>>⏳ Karar Bekliyor</option>
             <option value="tamam"    <?=$f_durum==='tamam'   ?'selected':''?>>✅ Kararlandı</option>
             <option value="hepsi"   <?=$f_durum==='hepsi'   ?'selected':''?>>📋 Tümü</option>
           </select></div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-t" style="flex:1;padding:10px">🔍 Ara</button>
        <a href="?sayfa=satinalma-gkk" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">↺</a>
      </div>
    </div>
  </form>
</div>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:14px">
  <?php foreach([
    ['Etiket Alınan', $toplam,   '#6B7280'],
    ['Karar Bekliyor',$bekleyen, '#F59E0B'],
    ['Kararlandı',    $kararli,  '#16A34A'],
  ] as [$l,$v,$r]):?>
  <div style="background:var(--yuzey);border-radius:var(--r);padding:14px;border-top:3px solid <?=$r?>;box-shadow:var(--shadow);text-align:center">
    <div style="font-size:11px;text-transform:uppercase;font-weight:700;color:var(--m3);margin-bottom:4px"><?=$l?></div>
    <div style="font-size:24px;font-weight:900;color:<?=$r?>"><?=$v?></div>
  </div>
  <?php endforeach;?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:14px">🔬 GKK Listesi</div>
  <?php if(empty($satirlar)):?>
  <div style="padding:40px;text-align:center;color:var(--m3)"><div style="font-size:36px">🔬</div><div>Kayıt bulunamadı.</div></div>
  <?php else:?>
  <div style="overflow:auto;max-height:640px">
  <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
    <colgroup>
      <col style="width:130px"><col style="width:90px"><col style="width:160px">
      <col style="width:90px"><col style="width:180px"><col style="width:65px">
      <col style="width:70px"><col style="width:80px"><col style="width:200px">
    </colgroup>
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E293B;color:#fff;border-bottom:2px solid #0F172A">
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155">İrsaliye No</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155">Tarih</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155">Tedarikçi</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155">Stok Kodu</th>
        <th style="padding:9px 10px;text-align:left;font-size:11px;border-right:1px solid #334155">Stok Adı</th>
        <th style="padding:9px 10px;text-align:right;font-size:11px;border-right:1px solid #334155">Miktar</th>
        <th style="padding:9px 10px;font-size:11px;border-right:1px solid #334155">Paket</th>
        <th style="padding:9px 10px;text-align:center;font-size:11px;border-right:1px solid #334155">GKK</th>
        <th style="padding:9px 10px;text-align:center;font-size:11px">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($satirlar as $i=>$r):
      $bg = $i%2===0?'#fff':'var(--kenar-a)';
      $karar = $r['gkk_karar'];
      $badge = $karar ? "<span class='gkk-badge-$karar'>" . ($karar==='SARTLI_KABUL'?'⚠️ Şartlı':($karar==='KABUL'?'✅ Kabul':'🔴 Red')) . "</span>"
                      : "<span class='gkk-badge-bekliyor'>⏳ Bekliyor</span>";
      $irs  = htmlspecialchars($r['irsaliye_no']);
      $sk   = htmlspecialchars($r['stok_kodu']);
      $sa   = htmlspecialchars($r['stok_adi']??'');
      $ted  = htmlspecialchars($r['tedarikci']??'');
      $ck   = htmlspecialchars($r['cari_kodu']??'');
      $em   = htmlspecialchars($r['email']??'');
      $mik  = number_format((float)($r['miktar']??0),2);
      $bir  = htmlspecialchars($r['birim']??'ADET');
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:7px 10px;font-family:monospace;font-size:10px;font-weight:700;border-right:1px solid var(--kenar);overflow:hidden;white-space:nowrap"><?=$irs?></td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars($r['tarih']??'')?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=$ted?>"><?=$ted?></td>
      <td style="padding:7px 10px;font-size:11px;font-weight:700;border-right:1px solid var(--kenar);white-space:nowrap"><?=$sk?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=$sa?>"><?=$sa?></td>
      <td style="padding:7px 10px;text-align:right;font-weight:700;color:#16A34A;border-right:1px solid var(--kenar);white-space:nowrap"><?=$mik?></td>
      <td style="padding:7px 10px;text-align:center;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar)"><?=(int)$r['paket_sayisi']?> pkg</td>
      <td style="padding:7px 10px;text-align:center;border-right:1px solid var(--kenar)"><?=$badge?></td>
      <td style="padding:7px 10px;text-align:center;white-space:nowrap">
        <?php if(!$karar):?>
        <button onclick="gkkKararAc('<?=$irs?>','<?=$sk?>','<?=$sa?>','<?=$ted?>','<?=$ck?>','<?=$em?>',<?=(float)($r['miktar']??0)?>, '<?=$bir?>')"
                class="btn btn-t" style="padding:4px 10px;font-size:11px">🔬 Karar Ver</button>
        <?php else:?>
        <button onclick="gkkKararAc('<?=$irs?>','<?=$sk?>','<?=$sa?>','<?=$ted?>','<?=$ck?>','<?=$em?>',<?=(float)($r['miktar']??0)?>, '<?=$bir?>')"
                style="padding:4px 10px;border:none;border-radius:6px;cursor:pointer;font-size:11px;background:var(--kenar-a);color:var(--m2)">✏️ Güncelle</button>
        <?php endif;?>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

<!-- GKK Karar Modalı -->
<div id="gkk-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99000;overflow:auto;padding:30px 20px;align-items:flex-start;justify-content:center"
     onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:var(--r-xl);width:100%;max-width:600px;box-shadow:0 24px 60px rgba(0,0,0,.25);margin:auto">
    <div style="padding:16px 22px;border-bottom:1px solid var(--kenar);background:linear-gradient(135deg,rgba(37,99,235,.07),var(--yuzey));display:flex;align-items:center;justify-content:space-between">
      <span style="font-size:15px;font-weight:800">🔬 GKK Kararı</span>
      <button onclick="document.getElementById('gkk-modal').style.display='none'"
              style="width:28px;height:28px;border-radius:6px;border:1.5px solid var(--kenar);background:var(--yuzey);cursor:pointer">✕</button>
    </div>
    <div style="padding:22px">
      <!-- Ürün bilgisi -->
      <div id="gkk-bilgi" style="background:var(--kenar-a);border-radius:var(--r);padding:12px 14px;margin-bottom:16px;font-size:12px;line-height:1.8"></div>

      <!-- Karar butonları -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
        <button onclick="gkkSecKarar('KABUL')" id="btn-kabul"
                style="padding:14px;border:2px solid #16A34A;border-radius:var(--r);cursor:pointer;font-weight:800;font-size:13px;background:#fff;color:#16A34A;transition:.2s"
                onmouseover="this.style.background='#D1FAE5'" onmouseout="if(!this.classList.contains('secili'))this.style.background='#fff'">
          ✅ Kabul
        </button>
        <button onclick="gkkSecKarar('SARTLI_KABUL')" id="btn-sartli"
                style="padding:14px;border:2px solid #1E40AF;border-radius:var(--r);cursor:pointer;font-weight:800;font-size:13px;background:#fff;color:#1E40AF;transition:.2s"
                onmouseover="this.style.background='#DBEAFE'" onmouseout="if(!this.classList.contains('secili'))this.style.background='#fff'">
          ⚠️ Şartlı Kabul
        </button>
        <button onclick="gkkSecKarar('RED')" id="btn-red"
                style="padding:14px;border:2px solid #DC2626;border-radius:var(--r);cursor:pointer;font-weight:800;font-size:13px;background:#fff;color:#DC2626;transition:.2s"
                onmouseover="this.style.background='#FEE2E2'" onmouseout="if(!this.classList.contains('secili'))this.style.background='#fff'">
          🔴 Red
        </button>
      </div>

      <!-- Açıklama -->
      <div style="margin-bottom:16px">
        <label class="form-et">Açıklama / Bulgular <span id="aciklama-zorunlu" style="color:#DC2626;display:none">*</span></label>
        <textarea id="gkk-aciklama" class="form-alan" rows="3" placeholder="Kalite bulgularını girin..."
                  style="resize:vertical"></textarea>
      </div>

      <!-- Red için: mail -->
      <div id="gkk-mail-bolum" style="display:none;margin-bottom:16px;padding:12px 14px;background:#FEF2F2;border-radius:var(--r);border-left:4px solid #DC2626">
        <div style="font-size:12px;font-weight:700;color:#7F1D1D;margin-bottom:8px">📧 Tedarikçi Bildirim Maili</div>
        <div style="font-size:11px;color:var(--m3);margin-bottom:8px">
          Kaydet butonuna bastıktan sonra mail oluşturulacak ve Outlook açılacak.
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <input type="text" id="gkk-mail-to" class="form-alan" style="flex:1;font-size:11px" placeholder="Tedarikçi mail adresi...">
          <button type="button" onclick="gkkMailSorgula()"
                  style="padding:7px 12px;background:#7F1D1D;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:11px;white-space:nowrap">🔍 Mail Bul</button>
        </div>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button onclick="document.getElementById('gkk-modal').style.display='none'"
                class="btn" style="padding:10px 20px;background:var(--kenar-a);color:var(--m2)">İptal</button>
        <button id="gkk-kaydet-btn" onclick="gkkKaydet()" disabled
                class="btn btn-t" style="padding:10px 24px;font-weight:800">💾 Kaydet</button>
      </div>
    </div>
  </div>
</div>

</div><!-- /s-body -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
var BASE_GKK = '<?=BASE_URL?>';
var _gkk = {};

function gkkKararAc(irsno, sk, sa, ted, ck, email, mik, birim) {
    _gkk = { irsno:irsno, sk:sk, sa:sa, ted:ted, ck:ck, email:email, mik:mik, birim:birim, karar:null };
    document.getElementById('gkk-bilgi').innerHTML =
        '<b>İrsaliye:</b> ' + irsno + '<br>' +
        '<b>Stok:</b> ' + sk + ' — ' + sa + '<br>' +
        '<b>Miktar:</b> <span style="color:#16A34A;font-weight:700">' + mik + ' ' + birim + '</span><br>' +
        '<b>Tedarikçi:</b> ' + ted;
    document.getElementById('gkk-aciklama').value = '';
    document.getElementById('gkk-mail-bolum').style.display = 'none';
    document.getElementById('gkk-mail-to').value = email || '';
    document.getElementById('aciklama-zorunlu').style.display = 'none';
    document.getElementById('gkk-kaydet-btn').disabled = true;
    ['btn-kabul','btn-sartli','btn-red'].forEach(function(id){ document.getElementById(id).classList.remove('secili'); document.getElementById(id).style.background='#fff'; });
    document.getElementById('gkk-modal').style.display = 'flex';
}

function gkkSecKarar(karar) {
    _gkk.karar = karar;
    ['btn-kabul','btn-sartli','btn-red'].forEach(function(id){ document.getElementById(id).classList.remove('secili'); document.getElementById(id).style.background='#fff'; });
    var colors = { KABUL:'#D1FAE5', SARTLI_KABUL:'#DBEAFE', RED:'#FEE2E2' };
    var ids    = { KABUL:'btn-kabul', SARTLI_KABUL:'btn-sartli', RED:'btn-red' };
    var btn = document.getElementById(ids[karar]);
    btn.classList.add('secili'); btn.style.background = colors[karar];
    document.getElementById('gkk-mail-bolum').style.display = karar==='RED' ? 'block' : 'none';
    document.getElementById('aciklama-zorunlu').style.display = karar==='RED' ? 'inline' : 'none';
    document.getElementById('gkk-kaydet-btn').disabled = false;
}

function gkkMailSorgula() {
    if(!_gkk.ted) return;
    fetch(BASE_GKK+'/bolumler/satinalma/ajax/tedarikci_api.php?firma='+encodeURIComponent(_gkk.ted))
    .then(function(r){return r.json();})
    .then(function(d){
        var mails = [];
        if(d.ok && d.mails && d.mails.length) mails = d.mails;
        else if(d.eslesen_kayitlar) mails = d.eslesen_kayitlar.map(function(k){return k.ilgili_kisi_mail;}).filter(Boolean);
        if(mails.length) document.getElementById('gkk-mail-to').value = mails.join(';');
        else alert('Mail adresi bulunamadı. Tedarikçi Bilgileri sayfasından ekleyin.');
    })
    .catch(function(e){ alert('Mail sorgu hatası: '+e.message); });
}

function gkkKaydet() {
    if(!_gkk.karar) { alert('Karar seçiniz'); return; }
    var aciklama = document.getElementById('gkk-aciklama').value.trim();
    if(_gkk.karar==='RED' && !aciklama) { alert('Red kararı için açıklama zorunludur'); return; }

    var btn = document.getElementById('gkk-kaydet-btn');
    btn.disabled=true; btn.textContent='⏳ Kaydediliyor...';

    fetch(BASE_GKK+'/islemler/satinalma/gkk_karar_kaydet.php',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
            irsaliye_no: _gkk.irsno,
            stok_kodu:   _gkk.sk,
            stok_adi:    _gkk.sa,
            miktar:      _gkk.mik,
            birim:       _gkk.birim,
            tedarikci:   _gkk.ted,
            cari_kodu:   _gkk.ck,
            karar:       _gkk.karar,
            aciklama:    aciklama,
            mail_to:     document.getElementById('gkk-mail-to').value
        })
    })
    .then(function(r){return r.json();})
    .then(function(d){
        btn.disabled=false; btn.textContent='💾 Kaydet';
        if(d.success){
            document.getElementById('gkk-modal').style.display='none';
            // Red ise Outlook maili aç
            if(_gkk.karar==='RED' && d.mailto_link) {
                setTimeout(function(){ window.location.href = d.mailto_link; }, 300);
            }
            setTimeout(function(){ location.reload(); }, _gkk.karar==='RED'?1500:300);
        } else {
            alert('Hata: ' + d.message);
        }
    })
    .catch(function(e){ btn.disabled=false; btn.textContent='💾 Kaydet'; alert('Hata: '+e.message); });
}
</script>
