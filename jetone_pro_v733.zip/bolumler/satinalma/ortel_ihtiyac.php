<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok    = ($tigerdb_pdo !== null);
$days_ahead  = 60;
$days_to_move= isset($_POST['days_to_move']) ? max(1,(int)$_POST['days_to_move']) : 2;

// 60 günlük tarih başlıkları
$date_headers = [];
$today = new DateTime();
for ($i=0;$i<$days_ahead;$i++) {
    $d = clone $today;
    $d->add(new DateInterval("P{$i}D"));
    $date_headers[] = $d->format('Y-m-d');
}

// ── 1. Arçelik Siparişleri ────────────────────────────────────────
$siparisler = [];
try {
    $st = $db->prepare("SELECT sip_id,sip_no,TRIM(sip_kodu) sip_kodu,sip_baslik,
        sip_miktar,sip_sevk_miktari,sip_teslim_tarihi,
        (sip_miktar-sip_sevk_miktari) kalan_miktar
        FROM siparis
        WHERE musteri_firma_adi='ARÇELİK KURUTUCU VE ELEKTRİK MOTORLARI İŞLETMESİ'
          AND (sip_miktar-sip_sevk_miktari) > 0
          AND sip_statu='Aktif'
        ORDER BY sip_teslim_tarihi ASC");
    $st->execute();
    $siparisler = $st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

$siparis_lookup = [];
foreach ($siparisler as $s) {
    $k = trim($s['sip_kodu']);
    if (!isset($siparis_lookup[$k])) $siparis_lookup[$k] = ['baslik'=>$s['sip_baslik'],'siparisler'=>[]];
    $siparis_lookup[$k]['siparisler'][] = $s;
}

// ── 2. Reçeteler ──────────────────────────────────────────────────
$receteler = $db->query("SELECT TRIM(stok_kodu) stok_kodu, TRIM(girdi_kodu) girdi_kodu, girdi_adi, girdi_birim_miktar FROM ortel_receteler")->fetchAll(PDO::FETCH_ASSOC);
$recipe_codes = array_unique(array_column($receteler,'stok_kodu'));

// ── 3. Tiger Stok ─────────────────────────────────────────────────
$stok_lookup = $girdi_stok_lookup = [];
if ($tiger_ok && !empty($siparis_lookup)) {
    $fn_stok = function($kodlar) use ($tigerdb_pdo) {
        if (empty($kodlar)) return [];
        $in = "'".implode("','", array_map(fn($k)=>str_replace("'","''",$k),$kodlar))."'";
        $sql = "SELECT TRIM(IT.CODE) stok_kodu,
            ISNULL((SELECT SUM(ONHAND) FROM LV_222_02_STINVTOT LV WITH(NOLOCK) INNER JOIN L_CAPIWHOUSE CAP WITH(NOLOCK) ON CAP.NR=LV.INVENNO WHERE LV.STOCKREF=IT.LOGICALREF AND CAP.NAME='ÜRETİM' AND CAP.FIRMNR=222),0) uretim_stok,
            ISNULL((SELECT SUM(ONHAND) FROM LV_222_02_STINVTOT LV WITH(NOLOCK) INNER JOIN L_CAPIWHOUSE CAP WITH(NOLOCK) ON CAP.NR=LV.INVENNO WHERE LV.STOCKREF=IT.LOGICALREF AND CAP.NAME='MERKEZ' AND CAP.FIRMNR=222),0) merkez_stok
        FROM LG_222_ITEMS IT WITH(NOLOCK) WHERE TRIM(IT.CODE) IN ($in) AND IT.CARDTYPE NOT IN (4,22)";
        try {
            $rows = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            $r = [];
            foreach ($rows as $row) $r[trim($row['stok_kodu'])] = ['uretim'=>floatval($row['uretim_stok']),'merkez'=>floatval($row['merkez_stok'])];
            return $r;
        } catch(Throwable $e) { return []; }
    };
    $stok_lookup       = $fn_stok(array_keys($siparis_lookup));
    $girdi_stok_lookup = $fn_stok(array_unique(array_column($receteler,'girdi_kodu')));
}

// ── 4. Sipariş + Stok düşümü ─────────────────────────────────────
$grouped_orders = [];
foreach ($siparis_lookup as $kod => $data) {
    if (!in_array($kod,$recipe_codes)) continue;
    $stok = isset($stok_lookup[$kod]) ? ($stok_lookup[$kod]['uretim']+$stok_lookup[$kod]['merkez']) : 0;
    $sip_by_date = [];
    foreach ($data['siparisler'] as $s) { $t=$s['sip_teslim_tarihi']; $sip_by_date[$t]=($sip_by_date[$t]??0)+floatval($s['kalan_miktar']); }
    ksort($sip_by_date);
    $cur=$stok; $daily_orders=$daily_needs=$stock_after=array_fill_keys($date_headers,0); $bakiye_sip=$bakiye_ihtiyac=0;
    foreach ($sip_by_date as $t=>$m) {
        if (strtotime($t)<strtotime($date_headers[0])) {
            $bakiye_sip+=$m;
            if ($cur>=$m) $cur-=$m; else { $bakiye_ihtiyac+=($m-$cur); $cur=0; }
        }
    }
    foreach ($date_headers as $date) {
        $ord=$sip_by_date[$date]??0; $daily_orders[$date]=$ord;
        if ($ord>0) { if ($cur>=$ord) $cur-=$ord; else { $daily_needs[$date]=$ord-$cur; $cur=0; } }
        $stock_after[$date]=$cur;
    }
    $grouped_orders[$kod]=['baslik'=>$data['baslik'],'initial_stock'=>$stok,'balance'=>$bakiye_sip,'balance_need'=>$bakiye_ihtiyac,'daily_orders'=>$daily_orders,'daily_needs'=>$daily_needs,'stock_after'=>$stock_after];
}

// ── 5. Girdi İhtiyaçları ─────────────────────────────────────────
$requirements = [];
foreach ($receteler as $r) {
    $gk=trim($r['girdi_kodu']); $sk=trim($r['stok_kodu']); $bm=floatval($r['girdi_birim_miktar']);
    if (!isset($requirements[$gk])) {
        $mev=isset($girdi_stok_lookup[$gk])?($girdi_stok_lookup[$gk]['uretim']+$girdi_stok_lookup[$gk]['merkez']):0;
        $requirements[$gk]=['girdi_adi'=>$r['girdi_adi'],'mevcut_stok'=>$mev,'daily_req'=>array_fill_keys($date_headers,0),'balance_req'=>0,'daily_needs'=>array_fill_keys($date_headers,0)];
    }
    if (!isset($grouped_orders[$sk])) continue;
    if ($grouped_orders[$sk]['balance_need']>0) $requirements[$gk]['balance_req']+=$grouped_orders[$sk]['balance_need']*$bm;
    foreach ($date_headers as $date) { if ($grouped_orders[$sk]['daily_needs'][$date]>0) $requirements[$gk]['daily_req'][$date]+=$grouped_orders[$sk]['daily_needs'][$date]*$bm; }
}
foreach ($requirements as $gk=>&$data) {
    $cur=$data['mevcut_stok'];
    if ($data['balance_req']>0) { if ($cur>=$data['balance_req']) $cur-=$data['balance_req']; else { $data['balance_req']-=$cur; $cur=0; } }
    foreach ($date_headers as $d) { $req=$data['daily_req'][$d]; if ($req>0) { if ($cur>=$req) $cur-=$req; else { $data['daily_needs'][$d]=$req-$cur; $cur=0; } } }
}
unset($data);

// ── 6. Tarih Kaydırma ────────────────────────────────────────────
$adjusted = [];
foreach ($requirements as $gk=>&$data) {
    $adjusted[$gk]=['girdi_adi'=>$data['girdi_adi'],'mevcut_stok'=>$data['mevcut_stok'],'balance_req'=>$data['balance_req'],'daily_needs'=>array_fill_keys($date_headers,0)];
    foreach ($date_headers as $date) {
        if ($data['daily_needs'][$date]<=0) continue;
        $req=$data['daily_needs'][$date];
        $adj=new DateTime($date); $adj->modify("-{$days_to_move} days");
        $dow=(int)$adj->format('N');
        if ($dow==6) $adj->modify('-1 day'); elseif ($dow==7) $adj->modify('+1 day');
        $adj_str=$adj->format('Y-m-d');
        if ($adj < new DateTime($date_headers[0])) $adjusted[$gk]['balance_req']+=$req;
        elseif (in_array($adj_str,$date_headers)) $adjusted[$gk]['daily_needs'][$adj_str]+=$req;
        else $adjusted[$gk]['balance_req']+=$req;
    }
}
unset($data);

// Aktif günler
$aktif_gunler=[];
foreach ($adjusted as $gk=>$d) { foreach ($date_headers as $dt) { if ($d['daily_needs'][$dt]>0) $aktif_gunler[$dt]=true; } }
ksort($aktif_gunler);

function fmt_n($n) { return $n>0?number_format($n,0,'','.'):'-'; }
function th_style($date) {
    $d=date('N',strtotime($date));
    $lbl=date('d.m',strtotime($date)).'<br><small>'.['','Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$d].'</small>';
    $s=$d>=6?' style="color:#DC2626"':'';
    return "<th$s>$lbl</th>";
}

// Mail JSON
$mail_verisi=[]; $mail_tarihler=[];
foreach ($adjusted as $gk=>$data) {
    $mev=$data['mevcut_stok']; $has=false;
    if ($data['balance_req']>0) $has=true;
    foreach ($aktif_gunler as $d=>$v) { if ($data['daily_needs'][$d]>0) { $has=true; break; } }
    if (!$has) continue;
    $gunler=[];
    foreach ($aktif_gunler as $d=>$v) {
        $m=$data['daily_needs'][$d];
        $gunler[]=['tarih'=>$d,'label'=>date('d.m.Y',strtotime($d)),'gun'=>(int)date('N',strtotime($d)),'miktar'=>$m>0?number_format($m,0,'','.'):'-'];
    }
    $mail_verisi[]=['gkod'=>$gk,'gadi'=>$data['girdi_adi'],'mevcut'=>fmt_n($mev),'bakiye'=>$data['balance_req']>0?number_format($data['balance_req'],0,'','.'):'-','gunler'=>$gunler];
}
foreach ($aktif_gunler as $d=>$v) {
    $gun=(int)date('N',strtotime($d));
    $mail_tarihler[]=['tarih'=>$d,'label'=>date('d.m.Y',strtotime($d)),'gun'=>$gun,'gun_adi'=>['','Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$gun]];
}

// Excel için TÜM girdiler — TÜM tarihler (60 gün), sıfır olanlar dahil
$tum_girdiler = [];
foreach ($adjusted as $gk=>$data) {
    $gunler=[];
    foreach ($date_headers as $d) {
        $m = (int)($data['daily_needs'][$d]??0);
        $gun = (int)date('N',strtotime($d));
        $gunler[]=['tarih'=>$d,'label'=>date('d.m.Y',strtotime($d)),'gun_adi'=>['','Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$gun],'miktar'=>$m];
    }
    $tum_girdiler[]=[
        'gkod'   => $gk,
        'gadi'   => $data['girdi_adi'],
        'bakiye' => (int)($data['balance_req']??0),
        'gunler' => $gunler
    ];
}
// Tablo için tüm 60 günlük başlık listesi
$tablo_gunler = [];
foreach ($date_headers as $d) {
    $gun=(int)date('N',strtotime($d));
    $tablo_gunler[]=['tarih'=>$d,'label'=>date('d.m.Y',strtotime($d)),'gun_adi'=>['','Pzt','Sal','Çar','Per','Cum','Cmt','Paz'][$gun]];
}
?>
<style>
#tblOrtel1 th, #tblOrtel2 th, #tblOrtel3 th { background:#1E3A5F !important; color:#fff !important; }
#tblOrtel1 td, #tblOrtel1 th,
#tblOrtel2 td, #tblOrtel2 th,
#tblOrtel3 td, #tblOrtel3 th { border:1px solid #000 !important; white-space:nowrap !important; }
.ortel-tabs { display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap }
.ortel-tab-btn { padding:7px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;border:2px solid #E2E8F0;background:#F8FAFC;color:#374151 }
.ortel-tab-btn.aktif { background:#1E3A5F;color:#fff;border-color:#1E3A5F }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📊 Ortel İhtiyaç Hesaplama</h1>
    <div class="s-yol">Satınalma / Ortel İhtiyaç / <b>ARÇELİK Girdi Planı</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<div class="kart" style="padding:10px 14px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
    <div>
      <label class="form-etiket">Siparişten Kaç Gün Önce?</label>
      <input type="number" name="days_to_move" value="<?php echo $days_to_move;?>" min="1" max="30" class="form-alan" style="width:80px">
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔄 Hesapla</button>
    <span style="font-size:11px;color:#64748B;align-self:center">
      📦 Sipariş: <b><?php echo count($siparisler);?></b> &nbsp;|
      🔧 Girdi türü: <b><?php echo count($requirements);?></b> &nbsp;|
      📅 Aktif gün: <b><?php echo count($aktif_gunler);?></b>
    </span>
  </form>
</div>

<div class="ortel-tabs">
  <button class="ortel-tab-btn aktif" onclick="showTab('tab1',this)"><?php echo $days_to_move;?> Gün Öncesi İhtiyaç</button>
  <button class="ortel-tab-btn" onclick="showTab('tab2',this)">Girdi İhtiyaçları</button>
  <button class="ortel-tab-btn" onclick="showTab('tab3',this)">Sipariş Detayları</button>
</div>

<div id="tab1">
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:8px 14px;background:#EFF6FF;border-bottom:1px solid #BFDBFE;display:flex;align-items:center;justify-content:space-between">
      <span style="font-weight:700;font-size:12px;color:#1E3A5F">🕐 <?php echo $days_to_move;?> Gün Öncesi (Hafta sonu ayarlı)</span>
      <button onclick="ortelMailGonder()" style="background:#1E3A5F;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">📧 Mail Gönder</button>
    </div>
    <table id="tblOrtel1" style="width:100%;border-collapse:collapse">
      <thead><tr>
        <th>Girdi Kodu</th><th>Girdi Adı</th><th>Mevcut Stok</th><th>Bakiye İhtiyaç</th>
        <?php foreach($date_headers as $d): $day=date('N',strtotime($d)); $c=$day>=6?' style="color:#EF4444"':''?>
        <th<?php echo $c;?>><?php echo date('d.m',strtotime($d));?><br><small style="font-weight:normal"><?php echo ['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'][$day%7];?></small></th>
        <?php endforeach;?>
      </tr></thead>
      <tfoot><tr><th>Girdi Kodu</th><th>Girdi Adı</th><th>Mevcut Stok</th><th>Bakiye İhtiyaç</th>
        <?php foreach($date_headers as $d):?><th><?php echo $d;?></th><?php endforeach;?>
      </tr></tfoot>
      <tbody>
      <?php foreach($adjusted as $gk=>$data): $mev=$data['mevcut_stok'];?>
      <tr>
        <td style="font-weight:700"><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:10px"><?php echo htmlspecialchars($gk);?></code></td>
        <td><?php echo htmlspecialchars($data['girdi_adi']);?></td>
        <td style="text-align:right;font-weight:<?php echo $mev>0?'700':'400';?>;color:<?php echo $mev>0?'#16A34A':'#94A3B8';?>"><?php echo fmt_n($mev);?></td>
        <td style="text-align:right;font-weight:700;color:<?php echo $data['balance_req']>0?'#DC2626':'#94A3B8';?>"><?php echo fmt_n($data['balance_req']);?></td>
        <?php foreach($date_headers as $d): $v=$data['daily_needs'][$d];?>
        <td style="text-align:right;<?php echo $v>0?'font-weight:700;color:#1D4ED8;':'color:#D1D5DB;';?>"><?php echo fmt_n($v);?></td>
        <?php endforeach;?>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>

<div id="tab2" style="display:none">
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:8px 14px;background:#F0FDF4;border-bottom:1px solid #86EFAC;font-weight:700;font-size:12px;color:#065F46">📦 Girdi İhtiyaçları (Stok Düşümlü, Kaydırılmamış)</div>
    <table id="tblOrtel2" style="width:100%;border-collapse:collapse">
      <thead><tr>
        <th>Girdi Kodu</th><th>Girdi Adı</th><th>Mevcut Stok</th><th>Bakiye İhtiyaç</th>
        <?php foreach($date_headers as $d): $day=date('N',strtotime($d)); $c=$day>=6?' style="color:#EF4444"':''?>
        <th<?php echo $c;?>><?php echo date('d.m',strtotime($d));?></th>
        <?php endforeach;?>
      </tr></thead>
      <tfoot><tr><th>Girdi Kodu</th><th>Girdi Adı</th><th>Mevcut Stok</th><th>Bakiye İhtiyaç</th>
        <?php foreach($date_headers as $d):?><th><?php echo $d;?></th><?php endforeach;?></tr></tfoot>
      <tbody>
      <?php foreach($requirements as $gk=>$data): $mev=$data['mevcut_stok'];?>
      <tr>
        <td style="font-weight:700"><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:10px"><?php echo htmlspecialchars($gk);?></code></td>
        <td><?php echo htmlspecialchars($data['girdi_adi']);?></td>
        <td style="text-align:right;font-weight:700;color:<?php echo $mev>0?'#16A34A':'#94A3B8';?>"><?php echo fmt_n($mev);?></td>
        <td style="text-align:right;font-weight:700;color:<?php echo $data['balance_req']>0?'#DC2626':'#94A3B8';?>"><?php echo fmt_n($data['balance_req']);?></td>
        <?php foreach($date_headers as $d): $v=$data['daily_needs'][$d];?>
        <td style="text-align:right;<?php echo $v>0?'font-weight:700;color:#1D4ED8;':'color:#D1D5DB;';?>"><?php echo fmt_n($v);?></td>
        <?php endforeach;?>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>

<div id="tab3" style="display:none">
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:8px 14px;background:#FFFBEB;border-bottom:1px solid #FDE68A;font-weight:700;font-size:12px;color:#92400E">🛒 Sipariş Detayları (Stok Düşümlü)</div>
    <table id="tblOrtel3" style="width:100%;border-collapse:collapse">
      <thead><tr>
        <th>Sipariş Kodu</th><th>Sipariş Adı</th><th>Başl. Stok</th><th>Bak. Sip.</th><th>Bak. İht.</th>
        <?php foreach($date_headers as $d): $day=date('N',strtotime($d)); $c=$day>=6?' style="color:#EF4444"':''?>
        <th<?php echo $c;?>><?php echo date('d.m',strtotime($d));?> S</th>
        <th<?php echo $c;?>><?php echo date('d.m',strtotime($d));?> İ</th>
        <th<?php echo $c;?>><?php echo date('d.m',strtotime($d));?> K</th>
        <?php endforeach;?>
      </tr></thead>
      <tfoot><tr><th>Sipariş Kodu</th><th>Sipariş Adı</th><th>Başl. Stok</th><th>Bak. Sip.</th><th>Bak. İht.</th>
        <?php foreach($date_headers as $d):?><th><?php echo $d;?> S</th><th><?php echo $d;?> İ</th><th><?php echo $d;?> K</th><?php endforeach;?>
      </tr></tfoot>
      <tbody>
      <?php foreach($grouped_orders as $kod=>$data):?>
      <tr>
        <td style="font-weight:700"><code style="background:#FEF9C3;padding:1px 5px;border-radius:3px;font-size:10px"><?php echo htmlspecialchars($kod);?></code></td>
        <td><?php echo htmlspecialchars($data['baslik']);?></td>
        <td style="text-align:right;font-weight:700;color:#16A34A"><?php echo fmt_n($data['initial_stock']);?></td>
        <td style="text-align:right"><?php echo fmt_n($data['balance']);?></td>
        <td style="text-align:right;font-weight:700;color:<?php echo $data['balance_need']>0?'#DC2626':'#94A3B8';?>"><?php echo fmt_n($data['balance_need']);?></td>
        <?php foreach($date_headers as $d):?>
        <td style="text-align:right;<?php echo $data['daily_orders'][$d]>0?'color:#1D4ED8;font-weight:700':'color:#D1D5DB';?>"><?php echo fmt_n($data['daily_orders'][$d]);?></td>
        <td style="text-align:right;<?php echo $data['daily_needs'][$d]>0?'color:#DC2626;font-weight:700':'color:#D1D5DB';?>"><?php echo fmt_n($data['daily_needs'][$d]);?></td>
        <td style="text-align:right;font-size:10px;color:#64748B"><?php echo fmt_n($data['stock_after'][$d]);?></td>
        <?php endforeach;?>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
</div>

<script>
var MAIL_VERISI  = <?php echo json_encode($mail_verisi,  JSON_UNESCAPED_UNICODE);?>;
var MAIL_GUNLER  = <?php echo json_encode($mail_tarihler, JSON_UNESCAPED_UNICODE);?>;
var TUM_GIRDILER = <?php echo json_encode($tum_girdiler,  JSON_UNESCAPED_UNICODE);?>;
var TABLO_GUNLER = <?php echo json_encode($tablo_gunler,  JSON_UNESCAPED_UNICODE);?>;
var DAYS_MOVE    = <?php echo $days_to_move;?>;

function showTab(id, btn) {
    document.querySelectorAll('#tab1,#tab2,#tab3').forEach(function(el){ el.style.display='none'; });
    document.querySelectorAll('.ortel-tab-btn').forEach(function(el){ el.classList.remove('aktif'); });
    document.getElementById(id).style.display = 'block';
    btn.classList.add('aktif');
    var map = {tab1:'tblOrtel1', tab2:'tblOrtel2', tab3:'tblOrtel3'};
    var tbl = map[id];
    if (tbl && !$.fn.DataTable.isDataTable('#'+tbl)) {
        initDT(tbl);
    }
}

function initDT(id) {
    $('#'+id).DataTable({
        initComplete: function(){
            this.api().columns([0,1]).every(function(){
                var col=this, th=$(col.footer());
                if(!th||!th.length) return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change', function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'350px', paging:false, scrollX:true,
        dom:'Bfrtip',
        buttons:[{
            extend:'excelHtml5',
            text:'📊 Excel',
            className:'btn-dt',
            filename:'Ortel_Ihtiyac',
            customize: function(xlsx) {
                // Sayısal hücrelerdeki noktalı formatı temizle
                var sheet = xlsx.xl.worksheets['sheet1.xml'];
                $('c[t="inlineStr"] is t, c[t="str"] is t', sheet).each(function(){
                    var v = $(this).text().replace(/\./g,'').replace(/,/g,'.');
                    if (!isNaN(v) && v !== '') {
                        $(this).closest('c').removeAttr('t');
                        $(this).replaceWith('<v>'+parseFloat(v)+'</v>');
                    }
                });
            },
            exportOptions:{
                format:{
                    body: function(data, row, col, node){
                        // HTML tag temizle, nokta binlik ayracını sil
                        var clean = $('<div/>').html(data).text().trim();
                        clean = clean.replace(/\./g,'').replace(/,/g,'.');
                        var num = parseFloat(clean);
                        return isNaN(num) ? $('<div/>').html(data).text().trim() : num;
                    }
                }
            }
        },'print']
    });
}

<?php
// mail fonksiyonu - dosyadan al
?>
function parseNum(s) {
    return parseFloat(String(s).replace(/\./g,'').replace(',','.')) || 0;
}
function fmtTR(n) {
    return n > 0 ? n.toLocaleString('tr-TR', {maximumFractionDigits:0}) : '-';
}

// ── Excel indir (mail fonksiyonundan bağımsız çağrılabilir) ──────
function ortelExcelIndir() {
    var tumGunler = TABLO_GUNLER; // Tüm 60 gün

    // Başlıklar: Girdi Kodu | Girdi Adı | TOPLAM | Bakiye | tarih1 | tarih2 ...
    var basliklar = ['Girdi Kodu', 'Girdi Adı', 'TOPLAM', 'Bakiye İhtiyaç'];
    tumGunler.forEach(function(g){ basliklar.push(g.label+' '+g.gun_adi); });

    var satirlar = [];
    var gunToplamlar = {};
    tumGunler.forEach(function(g){ gunToplamlar[g.tarih] = 0; });
    var bakiyeGenel = 0, toplamGenel = 0;

    TUM_GIRDILER.forEach(function(s) {
        var bm = s.bakiye || 0;
        bakiyeGenel += bm;
        var girdiToplam = bm;

        var gunMiktarlar = [];
        tumGunler.forEach(function(g) {
            var m = 0;
            s.gunler.forEach(function(sg){ if(sg.tarih===g.tarih) m = sg.miktar || 0; });
            gunMiktarlar.push(m);
            gunToplamlar[g.tarih] += m;
            girdiToplam += m;
        });

        toplamGenel += girdiToplam;

        // Sıra: Kodu | Adı | TOPLAM | Bakiye | günler...
        var satir = [s.gkod, s.gadi, girdiToplam, bm];
        gunMiktarlar.forEach(function(m){ satir.push(m); });
        satirlar.push(satir);
    });

    // Genel toplam alt satırı
    var toplamSatir = ['GENEL TOPLAM', '', toplamGenel, bakiyeGenel];
    tumGunler.forEach(function(g){ toplamSatir.push(gunToplamlar[g.tarih]); });
    satirlar.push(toplamSatir);

    if (typeof XLSX === 'undefined') { alert('Excel kütüphanesi yüklenemedi.'); return; }
    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.aoa_to_sheet([basliklar].concat(satirlar));
    var cols = [{wch:22},{wch:48},{wch:12},{wch:14}];
    tumGunler.forEach(function(){ cols.push({wch:12}); });
    ws['!cols'] = cols;
    XLSX.utils.book_append_sheet(wb, ws, 'Ortel İhtiyaç');
    var tarih = new Date().toISOString().slice(0,10).replace(/-/g,'');
    XLSX.writeFile(wb, 'Ortel_Ihtiyac_'+tarih+'.xlsx');
}

// ── Mail gönder + Excel indir ─────────────────────────────────────
function ortelMailGonder() {
    try {
        // Önce Excel indir
        ortelExcelIndir();

        var yil  = new Date().getFullYear();
        var to   = 'kalite@ortelelektronik.com.tr;necmettin.gul@ortelelektronik.com.tr;ismail.erdik@ortelelektronik.com.tr;mustafa.gul@ortelelektronik.com.tr';
        var cc   = 'bulent.colak@poliza.com.tr;ahmet.sensoy@poliza.com.tr;tarkan.aslan@poliza.com.tr;kaliteguvence@poliza.com.tr;planlama1@poliza.com.tr;planlama2@poliza.com.tr';
        var konu = yil + ' - ARÇELİK Girdi İhtiyaç Planı (' + DAYS_MOVE + ' Gün Öncesi)';

        var TH  = 'background:#1e3a5f;color:#fff;padding:7px 12px;border:1px solid #555;font-size:12px;font-weight:bold;text-align:';
        var TD  = 'padding:5px 12px;border:1px solid #d1d5db;font-size:12px;text-align:';
        var TTOP= 'padding:6px 12px;border:1px solid #999;font-size:12px;font-weight:bold;background:#1e3a5f;color:#fff;text-align:';
        var TVAL= 'padding:6px 12px;border:1px solid #999;font-size:12px;font-weight:bold;background:#fbbf24;color:#1e3a5f;text-align:';

        var thead = '<thead><tr>'
            +'<th style="'+TH+'left">Girdi Kodu</th>'
            +'<th style="'+TH+'left">Girdi Adı</th>'
            +'<th style="'+TH+'center">Tarih</th>'
            +'<th style="'+TH+'center">Miktar</th>'
            +'</tr></thead>';

        var tbody = '<tbody>'; var sc = 0;
        MAIL_VERISI.forEach(function(s) {
            var ag = s.gunler.filter(function(g){ return g.miktar !== '-'; });
            if (ag.length === 0 && s.bakiye === '-') return;
            var rbg = sc % 2 === 0 ? '#f8fafc' : '#fff';
            var gt  = 0;

            if (s.bakiye !== '-') {
                var bm = parseNum(s.bakiye); gt += bm;
                tbody += '<tr style="background:#fef9c3">'
                    +'<td style="'+TD+'left;border-left:4px solid #f59e0b"><b>'+s.gkod+'</b></td>'
                    +'<td style="'+TD+'left">'+s.gadi+'</td>'
                    +'<td style="'+TD+'center;font-weight:bold;color:#92400e">Bakiye</td>'
                    +'<td style="'+TD+'center;font-weight:bold;color:#92400e">'+s.bakiye+'</td>'
                    +'</tr>';
            }
            ag.forEach(function(g) {
                var m = parseNum(g.miktar); gt += m;
                tbody += '<tr style="background:'+rbg+'">'
                    +'<td style="'+TD+'left"><b>'+s.gkod+'</b></td>'
                    +'<td style="'+TD+'left">'+s.gadi+'</td>'
                    +'<td style="'+TD+'center">'+g.label+'</td>'
                    +'<td style="'+TD+'center;font-weight:bold;color:#1e40af">'+g.miktar+'</td>'
                    +'</tr>';
            });
            var tf = fmtTR(gt);
            tbody += '<tr>'
                +'<td style="'+TTOP+'left" colspan="3">TOPLAM — '+s.gkod+'</td>'
                +'<td style="'+TVAL+'center">'+tf+'</td>'
                +'</tr>';
            tbody += '<tr><td colspan="4" style="padding:2px;border:none;background:#cbd5e1"></td></tr>';
            sc++;
        });
        tbody += '</tbody>';

        var tablo = '<table cellspacing="0" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:12px;">'+thead+tbody+'</table>';
        var html  = '<p style="font-family:Arial,sans-serif;font-size:13px;">Merhaba,</p>'
            +'<p style="font-family:Arial,sans-serif;font-size:13px;">ARÇELİK siparişlerine ait <strong>'+DAYS_MOVE+' gün öncesi girdi ihtiyaç planı</strong> ekte Excel olarak gönderilmiştir. Özet tablo aşağıdadır.</p><br>'
            +tablo
            +'<br><p style="font-family:Arial,sans-serif;font-size:11px;color:#666;">* Hafta sonu ihtiyaçları kaydırılmıştır. * Mevcut stok düşüldü.</p>'
            +'<br><p style="font-family:Arial,sans-serif;font-size:13px;">Saygılarımızla.</p>';

        var mailto = 'mailto:'+to+'?cc='+encodeURIComponent(cc)+'&subject='+encodeURIComponent(konu);

        function copyHtml() {
            var t = document.createElement('div');
            t.setAttribute('contenteditable','true');
            t.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;overflow:hidden;opacity:.01';
            t.innerHTML = html;
            document.body.appendChild(t);
            t.focus();
            var rng = document.createRange(); rng.selectNodeContents(t);
            var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rng);
            document.execCommand('copy');
            sel.removeAllRanges(); document.body.removeChild(t);
        }
        function openMail() {
            window.location.href = mailto;
            setTimeout(function(){ alert('✅ Excel indirildi ve tablo panoya kopyalandı!\nOutlook açıldıktan sonra Ctrl+V ile yapıştırın.'); }, 1000);
        }

        if (typeof ClipboardItem !== 'undefined' && navigator.clipboard) {
            var blob = new Blob([html], {type:'text/html'});
            navigator.clipboard.write([new ClipboardItem({'text/html': blob})])
                .then(openMail).catch(function(){ copyHtml(); openMail(); });
        } else {
            copyHtml(); openMail();
        }
    } catch(e) { alert('Hata: '+e); }
}

$(document).ready(function(){
    initDT('tblOrtel1');
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
