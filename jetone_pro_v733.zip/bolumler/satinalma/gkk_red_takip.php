<?php
/**
 * GKK Red Takip — Satınalma Planlama Uyarı & Aksiyon Sayfası
 * Route: satinalma-gkk-red
 */
if(!defined('ROOT_DIR')) require_once dirname(dirname(__DIR__)).'/core/config.php';
if(!isset($mes_pdo))      require_once ROOT_DIR.'/core/baglanlogo.php';
if(!class_exists('Auth')) require_once ROOT_DIR.'/core/auth.php';
Auth::zorunlu();

global $db;

// Aksiyon güncelle
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['action'])) {
    $gkk_id  = (int)($_POST['gkk_id']??0);
    $aksiyon = trim($_POST['aksiyon']??'');
    $durum   = trim($_POST['durum']??'');
    $not     = trim($_POST['not']??'');
    $kul = Auth::kullanici(); $kul_adi='';
    if(is_array($kul)){
        if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
        elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    }
    if($gkk_id && $db) {
        try {
            // Aksiyon tablosu
            $db->exec("CREATE TABLE IF NOT EXISTS gkk_red_aksiyonlar (
                id              INT AUTO_INCREMENT PRIMARY KEY,
                gkk_id          INT NOT NULL,
                durum           VARCHAR(50) DEFAULT 'BEKLIYOR',
                aksiyon_notu    TEXT,
                planlanan_tarih DATE,
                gerceklesen_tarih DATE,
                sorumlu         VARCHAR(100) DEFAULT '',
                kaydeden        VARCHAR(100) DEFAULT '',
                kayit_tarihi    DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_gkk(gkk_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            if($_POST['action']==='update_durum') {
                $db->prepare("INSERT INTO gkk_red_aksiyonlar (gkk_id,durum,aksiyon_notu,sorumlu,kaydeden)
                              VALUES(?,?,?,?,?)
                              ON DUPLICATE KEY UPDATE durum=VALUES(durum),aksiyon_notu=VALUES(aksiyon_notu),sorumlu=VALUES(sorumlu),kaydeden=VALUES(kaydeden),kayit_tarihi=NOW()")
                   ->execute([$gkk_id, $durum, $not, $aksiyon, $kul_adi]);
                echo json_encode(['success'=>true]); exit;
            }
        } catch(Throwable $e) {
            echo json_encode(['success'=>false,'message'=>$e->getMessage()]); exit;
        }
    }
    echo json_encode(['success'=>false,'message'=>'Geçersiz istek']); exit;
}

// Filtreler
$f_basl   = trim($_GET['basl']    ?? date('Y-m-d', strtotime('-3 months')));
$f_bitis  = trim($_GET['bitis']   ?? date('Y-m-d'));
$f_durum  = trim($_GET['durum']   ?? '');
$f_cari   = trim($_GET['cari']    ?? '');

// GKK Red kayıtları
$redler = [];
if($db) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS gkk_red_aksiyonlar (
            id INT AUTO_INCREMENT PRIMARY KEY, gkk_id INT NOT NULL,
            durum VARCHAR(50) DEFAULT 'BEKLIYOR', aksiyon_notu TEXT,
            sorumlu VARCHAR(100) DEFAULT '', kaydeden VARCHAR(100) DEFAULT '',
            kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_gkk(gkk_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Debug: sonuc filtresi RED
        $w = ["g.sonuc='RED'"];
        $p = [];
        if($f_basl && $f_bitis) { $w[]="DATE(g.kontrol_tarihi) BETWEEN ? AND ?"; $p[]=$f_basl; $p[]=$f_bitis; }
        if($f_durum) { $w[]="COALESCE(a.durum,'BEKLIYOR')=?"; $p[]=$f_durum; }
        if($f_cari)  { $w[]="g.irsaliye_no LIKE ?"; $p[]="%$f_cari%"; }
        $ws = implode(' AND ', $w);

        $st = $db->prepare("
            SELECT g.*,
                   COALESCE(a.durum,'BEKLIYOR') AS aksiyon_durum,
                   a.aksiyon_notu, a.sorumlu, a.kaydeden AS aksiyon_kaydeden,
                   a.kayit_tarihi AS aksiyon_tarihi
            FROM gkk_kontrol_sonuclari g
            LEFT JOIN gkk_red_aksiyonlar a ON a.gkk_id=g.id
            WHERE $ws
            ORDER BY g.kontrol_tarihi DESC
        ");
        $st->execute($p);
        $redler = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}

// Tedarikçi bilgisi Tiger'dan
$tedarikci_map = [];
if(!empty($redler) && $tigerdb_pdo) {
    try {
        $irsno_list = array_unique(array_column($redler,'irsaliye_no'));
        $in = implode(',',array_fill(0,count($irsno_list),'?'));
        $st2 = $tigerdb_pdo->prepare("SELECT F.FICHENO, C.DEFINITION_ AS CARI_UNVANI, C.CODE AS CARI_KODU
            FROM (SELECT FICHENO,CLIENTREF FROM LG_222_01_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1
                  UNION ALL SELECT FICHENO,CLIENTREF FROM LG_222_02_STFICHE WHERE FICHENO IN ($in) AND TRCODE=1) F
            LEFT JOIN LG_222_CLCARD C ON C.LOGICALREF=F.CLIENTREF");
        $st2->execute(array_merge($irsno_list,$irsno_list));
        foreach($st2->fetchAll(PDO::FETCH_ASSOC) as $r) $tedarikci_map[$r['FICHENO']] = $r;
    } catch(Throwable $e) {}
}

// Özet sayılar
$ozet = ['BEKLIYOR'=>0,'INCELENIYOR'=>0,'TEDARIKCI_BILDIRILDI'=>0,'COZULDU'=>0,'RED_IPTAL'=>0];
foreach($redler as $r) $ozet[$r['aksiyon_durum']] = ($ozet[$r['aksiyon_durum']]??0) + 1;

$durum_renk = [
    'BEKLIYOR'            => ['bg'=>'#FEF3C7','fg'=>'#92400E','label'=>'⏳ Bekliyor'],
    'INCELENIYOR'         => ['bg'=>'#DBEAFE','fg'=>'#1E40AF','label'=>'🔍 İnceleniyor'],
    'TEDARIKCI_BILDIRILDI'=> ['bg'=>'#EDE9FE','fg'=>'#5B21B6','label'=>'📧 Tedarikçi Bildirildi'],
    'COZULDU'             => ['bg'=>'#D1FAE5','fg'=>'#065F46','label'=>'✅ Çözüldü'],
    'RED_IPTAL'           => ['bg'=>'#F3F4F6','fg'=>'#6B7280','label'=>'🚫 Red İptal'],
];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🚨 GKK Red Takip</h1>
    <div class="s-yol">Satınalma / <b>GKK Red Takip</b></div>
  </div>
  <div>
    <a href="?sayfa=kalite-gkk-liste" class="btn" style="padding:8px 14px;font-size:12px;background:var(--kenar-a);color:var(--m2)">
      🔬 GKK Listesi
    </a>
  </div>
</div>

<div class="s-body">

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:16px">
<?php foreach($ozet as $key=>$sayi):
    $dr = $durum_renk[$key]??['bg'=>'#fff','fg'=>'#333','label'=>$key];
?>
<div style="background:<?=$dr['bg']?>;border-radius:var(--r);padding:14px 16px;border-left:4px solid <?=$dr['fg']?>">
  <div style="font-size:11px;font-weight:700;color:<?=$dr['fg']?>;margin-bottom:4px"><?=$dr['label']?></div>
  <div style="font-size:24px;font-weight:900;color:<?=$dr['fg']?>"><?=$sayi?></div>
</div>
<?php endforeach;?>
</div>

<!-- Filtreler -->
<div class="kart" style="padding:14px;margin-bottom:14px">
  <form method="GET" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;align-items:flex-end">
    <input type="hidden" name="sayfa" value="satinalma-gkk-red">
    <div><label class="form-et" style="font-size:11px">Başlangıç</label><input type="date" name="basl" class="form-alan" value="<?=htmlspecialchars($f_basl)?>"></div>
    <div><label class="form-et" style="font-size:11px">Bitiş</label><input type="date" name="bitis" class="form-alan" value="<?=htmlspecialchars($f_bitis)?>"></div>
    <div>
      <label class="form-et" style="font-size:11px">Durum</label>
      <select name="durum" class="form-alan">
        <option value="">Tümü</option>
        <?php foreach($durum_renk as $k=>$dr):?>
        <option value="<?=$k?>" <?=$f_durum===$k?'selected':''?>><?=$dr['label']?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div><label class="form-et" style="font-size:11px">İrsaliye No</label><input type="text" name="cari" class="form-alan" value="<?=htmlspecialchars($f_cari)?>" placeholder="ARS..."></div>
    <div style="display:flex;gap:8px">
      <button type="submit" class="btn btn-t" style="flex:1;padding:10px">🔍 Ara</button>
      <a href="?sayfa=satinalma-gkk-red" class="btn" style="padding:10px 12px;background:var(--kenar-a);color:var(--m2)">↺</a>
    </div>
  </form>
</div>

<!-- Liste -->
<?php if(empty($redler)):?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">
  <div style="font-size:40px;margin-bottom:10px">✅</div>
  <div style="font-weight:700">Seçilen kriterlerde red kaydı bulunamadı.</div>
</div>
<?php else:?>
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 18px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <span style="font-weight:800;font-size:14px">🚨 Red Edilen Kalemler</span>
    <span style="font-size:12px;color:var(--m3)"><?=count($redler)?> kayıt</span>
  </div>
  <div style="overflow:auto;max-height:680px">
  <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
    <colgroup>
      <col style="width:130px"><col style="width:80px"><col style="width:200px">
      <col style="width:100px"><col style="width:60px"><col style="width:80px">
      <col style="width:90px"><col style="width:100px"><col style="width:120px">
      <col style="width:110px"><col style="width:90px">
    </colgroup>
    <thead style="position:sticky;top:0;z-index:2">
      <tr style="background:#1E293B;color:#fff;border-bottom:2px solid #0F172A;font-size:11px">
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:left">İrsaliye No</th>
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:left">Tarih</th>
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:left">Tedarikçi</th>
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:left">Stok Kodu</th>
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:right">Miktar</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Birim</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Kontrol</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Hata Oranı</th>
        <th style="padding:9px 10px;border-right:1px solid #334155">Kontrol Eden</th>
        <th style="padding:9px 10px;border-right:1px solid #334155;text-align:center">Durum</th>
        <th style="padding:9px 10px;text-align:center">Aksiyon</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($redler as $i=>$r):
      $bg = $i%2===0?'#fff':'var(--kenar-a)';
      $ted = $tedarikci_map[$r['irsaliye_no']] ?? null;
      $durum_key = $r['aksiyon_durum']??'BEKLIYOR';
      $dr = $durum_renk[$durum_key]??$durum_renk['BEKLIYOR'];
      $ka = (int)($r['kontrol_adet']??0);
      $ha = (int)($r['hata_adet']??0);
      $oran = $ka>0 ? round(($ha/$ka)*100,1) : null;
      $oran_renk = $oran===null?'#6B7280':($oran>=50?'#DC2626':($oran>=20?'#F59E0B':'#16A34A'));
    ?>
    <tr style="border-bottom:1px solid var(--kenar);background:<?=$bg?>">
      <td style="padding:7px 10px;font-family:monospace;font-size:10px;font-weight:700;border-right:1px solid var(--kenar);overflow:hidden;white-space:nowrap">
        <a href="?sayfa=kalite-gkk-detay&fis_id=<?=$r['fis_id']?>&irsaliye_no=<?=urlencode($r['irsaliye_no'])?>&cari=<?=urlencode($ted['CARI_UNVANI']??'')?>&cari_kodu=<?=urlencode($ted['CARI_KODU']??'')?>&tarih=<?=urlencode(substr($r['kontrol_tarihi'],0,10))?>"
           style="color:#4F46E5;font-weight:800"><?=htmlspecialchars($r['irsaliye_no'])?></a>
      </td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar);white-space:nowrap"><?=htmlspecialchars(substr($r['kontrol_tarihi'],0,10))?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($ted['CARI_UNVANI']??'')?>">
        <?=htmlspecialchars($ted['CARI_UNVANI']??'—')?>
      </td>
      <td style="padding:7px 10px;font-size:11px;font-weight:600;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=htmlspecialchars($r['stok_adi']??'')?>">
        <div style="font-family:monospace;font-size:10px"><?=htmlspecialchars($r['stok_kodu']??'')?></div>
        <div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars(substr($r['stok_adi']??'',0,25))?></div>
      </td>
      <td style="padding:7px 10px;text-align:right;font-weight:700;border-right:1px solid var(--kenar)"><?=number_format((float)($r['miktar']??0),2)?></td>
      <td style="padding:7px 10px;font-size:11px;color:var(--m3);border-right:1px solid var(--kenar)"><?=htmlspecialchars($r['birim']??'')?></td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar)">
        <?php if($ka>0):?>
        <div style="font-size:10px">Kontrol: <b><?=$ka?></b></div>
        <div style="font-size:10px">Hata: <b style="color:#DC2626"><?=$ha?></b></div>
        <?php else:?><span style="color:var(--m3)">—</span><?php endif;?>
      </td>
      <td style="padding:7px 10px;text-align:center;border-right:1px solid var(--kenar)">
        <?php if($oran!==null):?>
        <span style="font-weight:900;color:<?=$oran_renk?>;font-size:13px">%<?=$oran?></span>
        <?php else:?>—<?php endif;?>
      </td>
      <td style="padding:7px 10px;font-size:11px;border-right:1px solid var(--kenar);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        <?=htmlspecialchars($r['kontrol_eden']??'')?>
        <div style="font-size:10px;color:var(--m3)"><?=htmlspecialchars(substr($r['kontrol_tarihi']??'',0,16))?></div>
      </td>
      <td style="padding:7px 10px;text-align:center;border-right:1px solid var(--kenar)">
        <span style="background:<?=$dr['bg']?>;color:<?=$dr['fg']?>;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;white-space:nowrap">
          <?=$dr['label']?>
        </span>
        <?php if(!empty($r['aksiyon_notu'])):?>
        <div style="font-size:10px;color:var(--m3);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:90px" title="<?=htmlspecialchars($r['aksiyon_notu'])?>">
          <?=htmlspecialchars(substr($r['aksiyon_notu'],0,25))?>
        </div>
        <?php endif;?>
      </td>
      <td style="padding:7px 10px;text-align:center">
        <button type="button" onclick="aksiyonAc(<?=$r['id']?>,'<?=htmlspecialchars($r['stok_kodu'],ENT_QUOTES)?>','<?=htmlspecialchars($r['irsaliye_no'],ENT_QUOTES)?>','<?=htmlspecialchars($durum_key,ENT_QUOTES)?>','<?=htmlspecialchars($r['aksiyon_notu']??'',ENT_QUOTES)?>')"
                style="padding:4px 10px;background:#4F46E5;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap">
          ✏️ Aksiyon
        </button>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>
<?php endif;?>
</div>

<!-- Aksiyon Modal -->
<div id="aksiyon-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.4);z-index:99000;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:12px;padding:24px;width:480px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.3)">
    <div style="font-weight:800;font-size:16px;margin-bottom:4px;color:var(--m1)">✏️ Aksiyon Güncelle</div>
    <div id="aksiyon-baslik" style="font-size:12px;color:var(--m3);margin-bottom:16px"></div>
    <input type="hidden" id="aksiyon-gkk-id">
    <div style="margin-bottom:12px">
      <label class="form-et">Durum <span style="color:#DC2626">*</span></label>
      <select id="aksiyon-durum" class="form-alan">
        <?php foreach($durum_renk as $k=>$dr):?>
        <option value="<?=$k?>"><?=$dr['label']?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div style="margin-bottom:12px">
      <label class="form-et">Sorumlu / Yapılacak Aksiyon</label>
      <input type="text" id="aksiyon-sorumlu" class="form-alan" placeholder="Sorumlu kişi veya aksiyon...">
    </div>
    <div style="margin-bottom:18px">
      <label class="form-et">Not</label>
      <textarea id="aksiyon-not" class="form-alan" rows="3" placeholder="Tedarikçi bildirimi, bekleyen parça, çözüm detayı..."></textarea>
    </div>
    <div style="display:flex;gap:10px">
      <button type="button" onclick="aksiyonKaydet()"
              class="btn btn-t" style="flex:1;padding:11px;font-weight:800">💾 Kaydet</button>
      <button type="button" onclick="document.getElementById('aksiyon-modal').style.display='none'"
              class="btn" style="padding:11px 16px;background:var(--kenar-a);color:var(--m2)">İptal</button>
    </div>
  </div>
</div>

<script>
var BASE_RED = <?=json_encode(BASE_URL)?>;

function aksiyonAc(id, stok, irsno, durum, not_) {
    document.getElementById('aksiyon-gkk-id').value = id;
    document.getElementById('aksiyon-baslik').textContent = irsno + ' — ' + stok;
    document.getElementById('aksiyon-durum').value = durum || 'BEKLIYOR';
    document.getElementById('aksiyon-not').value = not_ || '';
    document.getElementById('aksiyon-modal').style.display = 'flex';
}

function aksiyonKaydet() {
    var id     = document.getElementById('aksiyon-gkk-id').value;
    var durum  = document.getElementById('aksiyon-durum').value;
    var not_   = document.getElementById('aksiyon-not').value;
    var sorumlu= document.getElementById('aksiyon-sorumlu').value;
    if(!id || !durum) return;

    var fd = new FormData();
    fd.append('action','update_durum');
    fd.append('gkk_id', id);
    fd.append('durum', durum);
    fd.append('not', not_);
    fd.append('aksiyon', sorumlu);

    fetch(location.href, {method:'POST', body:fd})
    .then(function(r){return r.json();})
    .then(function(d){
        if(d.success){
            document.getElementById('aksiyon-modal').style.display='none';
            location.reload();
        } else { alert('Hata: '+d.message); }
    }).catch(function(e){ alert('Hata: '+e.message); });
}

document.getElementById('aksiyon-modal').addEventListener('click', function(e){
    if(e.target===this) this.style.display='none';
});
</script>
