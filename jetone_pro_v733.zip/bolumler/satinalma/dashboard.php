<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$bugun    = date('Y-m-d');
$hafta_son = date('Y-m-d', strtotime('sunday this week'));
$hafta_bas = date('Y-m-d', strtotime('monday this week'));

$gecen = $bugun_sip = $hafta_sip = [];
$ozet  = ['gecen'=>0,'bugun'=>0,'hafta'=>0,'toplam_acik'=>0];

if ($tiger_ok) {
    try {
        $sql = "SELECT
            OL.AMOUNT          AS siparis_miktari,
            OL.SHIPPEDAMOUNT   AS gelen_miktar,
            OL.AMOUNT - OL.SHIPPEDAMOUNT AS kalan,
            FORMAT(ORF.DATE_,'dd.MM.yyyy')  AS siparis_tarihi,
            FORMAT(OL.DUEDATE,'dd.MM.yyyy') AS termin_tarihi,
            OL.DUEDATE         AS duedate_raw,
            ORF.DATE_          AS siparis_raw,
            IT.CODE            AS stok_kodu,
            IT.NAME            AS stok_adi,
            CL.DEFINITION_     AS firma_adi,
            DATEDIFF(DAY,OL.DUEDATE,GETDATE()) AS gecikme_gun
        FROM dbo.LG_222_02_ORFLINE OL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON OL.STOCKREF=IT.LOGICALREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON ORF.CLIENTREF=CL.LOGICALREF
        WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT < OL.AMOUNT
        ORDER BY OL.DUEDATE ASC";

        $tum = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $ozet['toplam_acik'] = count($tum);

        foreach ($tum as $r) {
            $due = substr($r['duedate_raw'], 0, 10);
            if ($due < $bugun) {
                $gecen[] = $r;
                $ozet['gecen']++;
            } elseif ($due === $bugun) {
                $bugun_sip[] = $r;
                $ozet['bugun']++;
            } elseif ($due <= $hafta_son) {
                $hafta_sip[] = $r;
                $ozet['hafta']++;
            }
        }
    } catch(Throwable $e) {}

    // Grafik: firma bazlı geciken sayısı (top 10)
    $firma_geciken = [];
    foreach ($gecen as $r) {
        $f = $r['firma_adi'] ?? 'Bilinmiyor';
        $firma_geciken[$f] = ($firma_geciken[$f] ?? 0) + 1;
    }
    arsort($firma_geciken);
    $firma_geciken = array_slice($firma_geciken, 0, 10, true);

    // Grafik: bu ay irsaliye girişleri (günlük)
    $gunluk_giris = [];
    try {
        $gs = $tigerdb_pdo->query("
            SELECT FORMAT(F.DATE_,'dd') AS gun, COUNT(DISTINCT F.FICHENO) AS sayi
            FROM LG_222_02_STFICHE F WITH(NOLOCK)
            WHERE F.TRCODE=1 AND YEAR(F.DATE_)=YEAR(GETDATE()) AND MONTH(F.DATE_)=MONTH(GETDATE())
            GROUP BY FORMAT(F.DATE_,'dd')
            ORDER BY gun ASC");
        foreach ($gs->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $gunluk_giris[(int)$r['gun']] = (int)$r['sayi'];
        }
    } catch(Throwable $e) {}
}

function mini_tablo($baslik, $satirlar, $renk, $bos_mesaj) {
    $badge_bg = $renk === 'red' ? '#FEE2E2' : ($renk === 'blue' ? '#DBEAFE' : '#D1FAE5');
    $badge_c  = $renk === 'red' ? '#991B1B' : ($renk === 'blue' ? '#1E40AF' : '#065F46');
    echo '<div class="kart" style="padding:0;overflow:hidden">';
    echo '<div style="padding:10px 14px;background:'.($renk==='red'?'#FEF2F2':($renk==='blue'?'#EFF6FF':'#F0FDF4')).';border-bottom:1px solid #E2E8F0;display:flex;align-items:center;justify-content:space-between">';
    echo '<span style="font-weight:700;font-size:13px;color:'.($renk==='red'?'#DC2626':($renk==='blue'?'#1D4ED8':'#15803D')).'">'.htmlspecialchars($baslik).'</span>';
    echo '<span style="background:'.$badge_bg.';color:'.$badge_c.';padding:2px 8px;border-radius:100px;font-size:11px;font-weight:700">'.count($satirlar).'</span>';
    echo '</div>';
    if (empty($satirlar)) {
        echo '<div style="padding:20px;text-align:center;color:#94A3B8;font-size:12px">'.$bos_mesaj.'</div>';
    } else {
        echo '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
        echo '<thead><tr style="background:#1E3A5F;color:#fff">';
        echo '<th style="padding:6px 10px;text-align:left;white-space:nowrap">Firma</th>';
        echo '<th style="padding:6px 10px;text-align:left;white-space:nowrap">Stok Kodu</th>';
        echo '<th style="padding:6px 10px;text-align:right;white-space:nowrap">Kalan</th>';
        echo '<th style="padding:6px 10px;text-align:center;white-space:nowrap">Termin</th>';
        if ($renk === 'red') echo '<th style="padding:6px 10px;text-align:center;white-space:nowrap">Gecikme</th>';
        echo '</tr></thead><tbody>';
        foreach (array_slice($satirlar, 0, 15) as $r) {
            $bg = $renk === 'red' ? 'background:#FFF5F5' : '';
            echo '<tr style="border-bottom:1px solid #F1F5F9;'.$bg.'">';
            echo '<td style="padding:5px 10px;font-weight:600;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'.htmlspecialchars($r['firma_adi']??'').'</td>';
            echo '<td style="padding:5px 10px"><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px">'.htmlspecialchars($r['stok_kodu']??'').'</code></td>';
            echo '<td style="padding:5px 10px;text-align:right;font-weight:700;color:'.($renk==='red'?'#DC2626':'#1D4ED8').'">'.number_format((float)($r['kalan']??0),0,'','.').'</td>';
            echo '<td style="padding:5px 10px;text-align:center">'.htmlspecialchars($r['termin_tarihi']??'').'</td>';
            if ($renk === 'red') echo '<td style="padding:5px 10px;text-align:center;color:#DC2626;font-weight:700">'.(int)($r['gecikme_gun']??0).' gün</td>';
            echo '</tr>';
        }
        if (count($satirlar) > 15) echo '<tr><td colspan="5" style="text-align:center;padding:6px;color:#94A3B8;font-size:10px">+' . (count($satirlar)-15) . ' kayıt daha...</td></tr>';
        echo '</tbody></table></div>';
    }
    echo '</div>';
}
?>
<style>
.sat-kart-stat{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:16px 20px;display:flex;flex-direction:column;gap:4px}
</style>

<div class="s-bar">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📊 Satınalma Dashboard</h1>
    <div class="s-yol">Satınalma / <b>Genel Durum</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php else:?>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px">
  <div class="sat-kart-stat" style="border-left:4px solid #DC2626">
    <div style="font-size:32px;font-weight:900;color:#DC2626"><?php echo $ozet['gecen'];?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">🔴 Termini Geçen</div>
  </div>
  <div class="sat-kart-stat" style="border-left:4px solid #F59E0B">
    <div style="font-size:32px;font-weight:900;color:#D97706"><?php echo $ozet['bugun'];?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">🟡 Bugün Beklenen</div>
  </div>
  <div class="sat-kart-stat" style="border-left:4px solid #3B82F6">
    <div style="font-size:32px;font-weight:900;color:#2563EB"><?php echo $ozet['hafta'];?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">📅 Bu Hafta Beklenen</div>
  </div>
  <div class="sat-kart-stat" style="border-left:4px solid #8B5CF6">
    <div style="font-size:32px;font-weight:900;color:#7C3AED"><?php echo $ozet['toplam_acik'];?></div>
    <div style="font-size:12px;font-weight:600;color:#374151">📋 Toplam Açık Kalem</div>
  </div>
</div>

<!-- Mini Tablolar -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
  <div>
    <div style="font-weight:700;font-size:12px;color:#DC2626;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px">🔴 Termini Geçen Siparişler</div>
    <?php mini_tablo('', $gecen, 'red', 'Geciken sipariş yok ✅');?>
  </div>
  <div>
    <div style="font-weight:700;font-size:12px;color:#D97706;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px">🟡 Bugünkü Siparişler (<?php echo date('d.m.Y');?>)</div>
    <?php mini_tablo('', $bugun_sip, 'yellow', 'Bugüne ait beklenti yok');?>
  </div>
  <div>
    <div style="font-weight:700;font-size:12px;color:#2563EB;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px">📅 Bu Hafta Beklenen</div>
    <?php mini_tablo('', $hafta_sip, 'blue', 'Bu hafta beklenen yok');?>
  </div>
</div>

<!-- Grafikler -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
  <div class="kart" style="padding:10px">
    <div style="font-weight:700;font-size:11px;color:#1E3A5F;margin-bottom:6px">🏭 Firma Bazlı Geciken (Top 8)</div>
    <div style="position:relative;height:160px">
      <canvas id="firmaGecChart"></canvas>
    </div>
  </div>
  <div class="kart" style="padding:10px">
    <div style="font-weight:700;font-size:11px;color:#1E3A5F;margin-bottom:6px">📥 Bu Ay Günlük İrsaliye</div>
    <div style="position:relative;height:160px">
      <canvas id="gunlukChart"></canvas>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
// Firma bazlı geciken grafik
var firmaLabels = <?php echo json_encode(array_keys(array_slice($firma_geciken,0,8,true)));?>;
var firmaData   = <?php echo json_encode(array_values(array_slice($firma_geciken,0,8,true)));?>;
new Chart(document.getElementById('firmaGecChart'), {
  type:'bar',
  data:{
    labels: firmaLabels.map(function(l){return l.length>20?l.substr(0,19)+'…':l;}),
    datasets:[{
      data: firmaData,
      backgroundColor:['#DC2626','#EF4444','#F87171','#FCA5A5','#FECACA','#FEE2E2','#FECACA','#FCA5A5'],
      borderRadius:3
    }]
  },
  options:{
    indexAxis:'y',
    responsive:true,
    maintainAspectRatio:false,
    plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return ' '+c.raw+' kalem';}}}},
    scales:{
      x:{beginAtZero:true,ticks:{stepSize:1,font:{size:10}},grid:{display:false}},
      y:{ticks:{font:{size:10}},grid:{display:false}}
    }
  }
});

// Günlük irsaliye grafik
var gunLabels = <?php echo json_encode(array_map(fn($g)=>str_pad($g,2,'0',STR_PAD_LEFT).'.'.date('m'), array_keys($gunluk_giris)));?>;
var gunData   = <?php echo json_encode(array_values($gunluk_giris));?>;
new Chart(document.getElementById('gunlukChart'), {
  type:'bar',
  data:{
    labels: gunLabels,
    datasets:[{
      data: gunData,
      backgroundColor:'rgba(30,58,95,.6)',
      borderColor:'#1E3A5F',
      borderWidth:1,
      borderRadius:3
    }]
  },
  options:{
    responsive:true,
    maintainAspectRatio:false,
    plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return ' '+c.raw+' irsaliye';}}}},
    scales:{
      y:{beginAtZero:true,ticks:{stepSize:1,font:{size:10}},grid:{color:'rgba(0,0,0,.05)'}},
      x:{ticks:{font:{size:9}},grid:{display:false}}
    }
  }
});
</script>
<?php endif;?>
