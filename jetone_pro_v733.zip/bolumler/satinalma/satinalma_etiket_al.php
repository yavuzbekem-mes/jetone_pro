<?php
/**
 * Satınalma — Etiket Al (Çoklu Paket)
 * Route: satinalma-etiket-al
 */
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();

$kul = Auth::kullanici(); $kul_adi='';
if(is_array($kul)){
    if(!empty($kul['ad_soyad'])) $kul_adi=trim($kul['ad_soyad']);
    elseif(!empty($kul['ad']))   $kul_adi=trim($kul['ad'].' '.($kul['soyad']??''));
    elseif(!empty($kul['email']))$kul_adi=explode('@',$kul['email'])[0];
}
if(!$kul_adi) $kul_adi='JETONE';

$irsaliye_no = trim($_GET['irsaliye_no'] ?? '');
$stok_kodu   = trim($_GET['stok_kodu']   ?? '');
$stok_adi    = trim($_GET['stok_adi']    ?? '');
$ir_miktar   = (float)($_GET['miktar']   ?? 0);
$birim       = trim($_GET['birim']       ?? 'ADET');
$tedarikci   = trim($_GET['tedarikci']   ?? '');
$cari_kodu   = trim($_GET['cari_kodu']    ?? '');
$ambar_no    = (int)($_GET['ambar_no']    ?? 1);
$lot_no      = trim($_GET['lot_no']      ?? '');
$tarih       = trim($_GET['tarih']       ?? date('Y-m-d'));

if(!$irsaliye_no || !$stok_kodu) {
    echo '<div class="s-body"><div style="padding:20px;color:#DC2626">Geçersiz parametreler.</div></div>';
    return;
}

// Stok adı Tiger'dan çek
if(!$stok_adi && $tigerdb_pdo) {
    try {
        $st=$tigerdb_pdo->prepare("SELECT TOP 1 NAME FROM dbo.LG_222_ITEMS WHERE CODE=? AND ACTIVE=0");
        $st->execute([$stok_kodu]);
        $r=$st->fetch(PDO::FETCH_ASSOC);
        if($r) $stok_adi=$r['NAME'];
    } catch(Throwable $e){}
}

// Mevcut paketleri çek
$mevcut_paketler = [];
$toplam_alinan   = 0;
if($mes_pdo) {
    try {
        $st2=$mes_pdo->prepare(
            "SELECT PAKET_NO,MIKTAR,BIRIM,CALISAN,AKTIF,EKLENME_TARIHI
             FROM dbo.PAKETLER WHERE URETIM_EMRI_NO=? AND STOK_KODU=? AND AKTIF=0 ORDER BY ID DESC"
        );
        $st2->execute([$irsaliye_no,$stok_kodu]);
        $mevcut_paketler = $st2->fetchAll(PDO::FETCH_ASSOC);
        $toplam_alinan   = (float)array_sum(array_column($mevcut_paketler,'MIKTAR'));
    } catch(Throwable $e){}
}
$kalan_miktar = max(0, $ir_miktar - $toplam_alinan);
?>
<style>
@media(max-width:900px){
    .ea-grid{grid-template-columns:1fr !important}
}
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🏷️ Etiket Al</h1>
    <div class="s-yol">Satınalma /
      <a href="?sayfa=satinalma-etiket&basl=<?=date('Y-m-01')?>&bitis=<?=date('Y-m-d')?>"
         style="color:var(--t)">Etiket Listesi</a> / <b><?=htmlspecialchars($irsaliye_no)?></b>
    </div>
  </div>
</div>

<div class="s-body">
<div class="ea-grid" style="display:grid;grid-template-columns:1fr 2fr;gap:16px;align-items:flex-start">

<!-- ═══ SOL: İrsaliye Bilgisi ═══ -->
<div style="display:flex;flex-direction:column;gap:12px">

  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #F59E0B">
    <div style="padding:14px;background:#FFFBEB;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#F59E0B">📋 İrsaliye Bilgisi</div>
    </div>
    <div style="padding:16px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:12px">
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);border-left:3px solid #F59E0B">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">İrsaliye No</div>
          <div style="font-weight:800;font-family:monospace"><?=htmlspecialchars($irsaliye_no)?></div>
        </div>
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);border-left:3px solid #F59E0B">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">Tarih</div>
          <div style="font-weight:600"><?=htmlspecialchars($tarih)?></div>
        </div>
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);border-left:3px solid #16A34A">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">Stok Kodu</div>
          <div style="font-weight:800"><?=htmlspecialchars($stok_kodu)?></div>
        </div>
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);border-left:3px solid #16A34A">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">İrsaliye Miktarı</div>
          <div style="font-weight:800;color:#16A34A;font-size:15px"><?=number_format($ir_miktar,2)?> <?=htmlspecialchars($birim)?></div>
        </div>
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);border-left:3px solid var(--t);grid-column:span 2">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">Stok Adı</div>
          <div style="font-weight:600"><?=htmlspecialchars($stok_adi)?></div>
        </div>
        <?php if($tedarikci): ?>
        <div style="background:var(--kenar-a);padding:10px 12px;border-radius:var(--r);grid-column:span 2">
          <div style="color:var(--m3);font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:2px">Tedarikçi</div>
          <div style="font-weight:600"><?=htmlspecialchars($tedarikci)?></div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Durum özeti -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px">
        <div style="text-align:center;padding:10px;background:#D1FAE5;border-radius:var(--r)">
          <div style="font-size:10px;color:#065F46;font-weight:700;text-transform:uppercase">Alınan</div>
          <div style="font-size:18px;font-weight:900;color:#16A34A"><?=number_format($toplam_alinan,2)?></div>
        </div>
        <div style="text-align:center;padding:10px;background:<?=$kalan_miktar>0.01?'#FEF3C7':'#D1FAE5'?>;border-radius:var(--r)">
          <div style="font-size:10px;color:<?=$kalan_miktar>0.01?'#92400E':'#065F46'?>;font-weight:700;text-transform:uppercase">Kalan</div>
          <div style="font-size:18px;font-weight:900;color:<?=$kalan_miktar>0.01?'#F59E0B':'#16A34A'?>"><?=number_format($kalan_miktar,2)?></div>
        </div>
        <div style="text-align:center;padding:10px;background:var(--kenar-a);border-radius:var(--r)">
          <div style="font-size:10px;color:var(--m3);font-weight:700;text-transform:uppercase">Paket Sayısı</div>
          <div style="font-size:18px;font-weight:900;color:var(--m2)"><?=count($mevcut_paketler)?></div>
        </div>
      </div>
    </div>
  </div>

</div><!-- /SOL -->

<!-- ═══ SAĞ: Mevcut Paketler + Form ═══ -->
<div style="display:flex;flex-direction:column;gap:12px">

<?php if(!empty($mevcut_paketler)): ?>
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #16A34A">
    <div style="padding:14px;background:#F0FDF4;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#16A34A">📦 Mevcut Paketler</div>
    </div>
    <div style="overflow-y:auto;max-height:220px">
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead style="position:sticky;top:0;background:#1E293B;color:#fff">
        <tr>
          <th style="padding:7px 12px;text-align:left">Paket No</th>
          <th style="padding:7px 12px;text-align:right">Miktar</th>
          <th style="padding:7px 12px">Kaydeden</th>
          <th style="padding:7px 12px">Tarih</th>
          <th style="padding:7px 12px;text-align:center">Etiket</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($mevcut_paketler as $j=>$pkg): ?>
      <tr style="border-bottom:1px solid var(--kenar);background:<?=$j%2===0?'#fff':'var(--kenar-a)'?>">
        <td style="padding:6px 12px;font-family:monospace;font-weight:700;font-size:11px"><?=htmlspecialchars($pkg['PAKET_NO']??'')?></td>
        <td style="padding:6px 12px;text-align:right;font-weight:700;color:#16A34A"><?=number_format((float)($pkg['MIKTAR']??0),2)?></td>
        <td style="padding:6px 12px;font-size:11px;color:var(--m2)"><?=htmlspecialchars($pkg['CALISAN']??'')?></td>
        <td style="padding:6px 12px;font-size:11px;color:var(--m3)"><?=htmlspecialchars(substr($pkg['EKLENME_TARIHI']??'',0,16))?></td>
        <td style="padding:6px 12px;text-align:center">
          <?php
          // POST form ile HAMMADDE etiketi yaz — DB'den gelen tüm bilgilerle
          $pkg_etur = $pkg['ETIKET_TURU'] ?? 'HAMMADDE';
          $pkg_json = json_encode([[
              'uretim_emri_no' => $irsaliye_no,
              'malzeme_kodu'   => $stok_kodu,
              'malzeme_adi'    => $stok_adi,
              'firma_kodu'     => $cari_kodu ?: '15601',
              'firma_adi'      => $tedarikci ?: 'POLİZA ENDÜSTRİ A.Ş.',
              'uretim_tarihi'  => $tarih,
              'operator_kodu'  => $pkg['EKLEYEN'] ?? $kul_adi,
              'miktar'         => (float)($pkg['MIKTAR']??0),
              'lot_no'         => $pkg['PAKET_NO']??'',
              'etiket_turu'    => $pkg_etur,
          ]], JSON_UNESCAPED_UNICODE);
          ?>
          <button type="button"
                  onclick="postaEtiketYazdir(<?=htmlspecialchars($pkg_json,ENT_QUOTES)?>)"
                  style="padding:3px 8px;background:#FEF3C7;color:#92400E;border-radius:5px;font-size:10px;font-weight:700;border:none;cursor:pointer">🖨️ Yazdır</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
<?php endif; ?>

<?php if($kalan_miktar > 0.01): ?>
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #7C3AED">
    <div style="padding:14px;background:#F5F3FF;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#7C3AED">➕ Paket Oluştur</div>
      <div style="font-size:11px;color:var(--m3);margin-top:2px">
        Farklı miktarlarda birden fazla paket oluşturabilirsiniz.
        İrsaliye: <b style="color:#16A34A"><?=number_format($ir_miktar,2)?> <?=htmlspecialchars($birim)?></b>
      </div>
    </div>
    <div style="padding:20px">

      <!-- Ortak bilgiler -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;padding:14px;background:var(--kenar-a);border-radius:var(--r)">
        <div>
          <label class="form-et">Ambar / Depo</label>
          <select id="glob-ambar" class="form-alan">
            <?php
            $ambar_list = [0=>'Merkez',1=>'Üretim',2=>'Karantina',3=>'Kırma',4=>'Emanet',5=>'BSH',98=>'Takım Boz'];
            foreach($ambar_list as $av=>$al):
            ?>
            <option value="<?=$av?>" <?=$ambar_no===$av?'selected':''?>><?=$av?> — <?=$al?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="form-et">Raf / Stok Yeri</label>
          <input type="text" id="glob-stokyeri" class="form-alan" value="GKK"
                 style="text-transform:uppercase" oninput="this.value=this.value.toUpperCase()">
        </div>
        <div>
          <label class="form-et">Operatör</label>
          <input type="text" id="glob-calisan" class="form-alan" value="<?=htmlspecialchars($kul_adi)?>">
        </div>
        <div>
          <label class="form-et">Tarih</label>
          <input type="date" id="glob-tarih" class="form-alan" value="<?=htmlspecialchars($tarih)?>">
        </div>
      </div>

      <!-- Paket satırları -->
      <div id="paket-satirlar"></div>

      <button type="button" onclick="satirEkle()"
              class="btn" style="padding:8px 16px;background:var(--kenar-a);color:var(--m2);font-size:12px;margin-bottom:14px">
        ➕ Paket Satırı Ekle
      </button>

      <!-- Toplam kontrol -->
      <div style="background:var(--kenar-a);border-radius:var(--r);padding:12px 16px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between">
        <span style="font-size:12px;font-weight:700">Toplam Girilen:</span>
        <span id="toplam-gosterge" style="font-size:18px;font-weight:900;color:var(--t)">0.00 <?=htmlspecialchars($birim)?></span>
      </div>
      <div id="dogrulama-mesaj" style="font-size:12px;margin-bottom:12px;display:none"></div>

      <button type="button" id="kaydet-btn" onclick="paketleriKaydet()" disabled
              class="btn btn-t" style="width:100%;padding:14px;font-size:14px;font-weight:800">
        🏷️ Paketleri Oluştur ve Etiket Yazdır
      </button>
    </div>
  </div>
<?php else: ?>
  <div class="kart" style="padding:0;overflow:hidden;border-top:4px solid #16A34A">
    <div style="padding:14px;background:#F0FDF4;border-bottom:1px solid var(--kenar)">
      <div style="font-weight:800;font-size:13px;color:#16A34A">✅ Tüm Etiketler Alındı</div>
    </div>
    <div style="padding:24px;text-align:center">
      <div style="font-size:12px;color:var(--m3);margin-bottom:14px">
        <?=number_format($ir_miktar,2)?> <?=htmlspecialchars($birim)?> — <?=count($mevcut_paketler)?> paket
      </div>
      <a href="?sayfa=satinalma-etiket&basl=<?=date('Y-m-01')?>&bitis=<?=date('Y-m-d')?>"
         class="btn btn-t" style="display:inline-block;padding:10px 24px">
        ← Listeye Dön
      </a>
    </div>
  </div>
<?php endif; ?>

</div><!-- /SAĞ -->

</div><!-- /ea-grid -->
</div><!-- /s-body -->

<input type="hidden" id="_ea_base"   value="<?=BASE_URL?>">
<input type="hidden" id="_ea_miktar" value="<?=htmlspecialchars((string)$ir_miktar)?>">
<input type="hidden" id="_ea_kalan"  value="<?=htmlspecialchars((string)$kalan_miktar)?>">
<input type="hidden" id="_ea_tarih"  value="<?=htmlspecialchars($tarih)?>">
<input type="hidden" id="_ea_birim"  value="<?=htmlspecialchars($birim)?>">
<input type="hidden" id="_ea_irsno"  value="<?=htmlspecialchars($irsaliye_no)?>">
<input type="hidden" id="_ea_sk"     value="<?=htmlspecialchars($stok_kodu)?>">
<input type="hidden" id="_ea_sa"     value="<?=htmlspecialchars($stok_adi)?>">
<input type="hidden" id="_ea_lot"    value="<?=htmlspecialchars($lot_no)?>">
<input type="hidden" id="_ea_ted"    value="<?=htmlspecialchars($tedarikci)?>">
<input type="hidden" id="_ea_cari"   value="<?=htmlspecialchars($cari_kodu)?>">
<script>
var BASE_EA   = document.getElementById('_ea_base').value;

function postaEtiketYazdir(pktler) {
    if(!Array.isArray(pktler)) pktler = [pktler];
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = BASE_EA + '/bolumler/uretim/paket_yazdir.php';
    form.target = '_blank';
    var inp = document.createElement('input');
    inp.type = 'hidden'; inp.name = 'paketler';
    inp.value = JSON.stringify(pktler);
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

function mevcutEtiketYazdir(paketNo, miktar, ekleyen, etiketTuru) {
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = BASE_EA + '/bolumler/uretim/paket_yazdir.php';
    form.target = '_blank';
    var inp = document.createElement('input');
    inp.type = 'hidden'; inp.name = 'paketler';
    inp.value = JSON.stringify([{
        uretim_emri_no: document.getElementById('_ea_irsno').value,
        malzeme_kodu:   document.getElementById('_ea_sk').value,
        malzeme_adi:    document.getElementById('_ea_sa').value,
        firma_kodu:     document.getElementById('_ea_cari').value || '15601',
        firma_adi:      document.getElementById('_ea_ted').value || 'POLİZA ENDÜSTRİ A.Ş.',
        uretim_tarihi:  document.getElementById('_ea_tarih').value || '',
        operator_kodu:  ekleyen || (document.getElementById('glob-calisan') ? document.getElementById('glob-calisan').value : ''),
        miktar:         miktar,
        lot_no:         paketNo,
        etiket_turu:    etiketTuru || 'HAMMADDE'
    }]);
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}
var IR_MIKTAR      = parseFloat(document.getElementById('_ea_miktar').value);
var KONTROL_MIKTAR = parseFloat(document.getElementById('_ea_kalan').value) || IR_MIKTAR;
var BIRIM     = document.getElementById('_ea_birim').value;
var SATIR_IDX = 0;

window.addEventListener('load', function(){
    if(document.getElementById('paket-satirlar')) {
        satirEkle();
        var ilkMiktar = document.querySelector('.paket-miktar-input');
        if(ilkMiktar && KONTROL_MIKTAR > 0) ilkMiktar.value = KONTROL_MIKTAR.toFixed(2);
        toplamHesapla();
    }
});

function satirEkle() {
    var idx = ++SATIR_IDX;
    var div = document.createElement('div');
    div.id = 'satir-'+idx;
    div.style.cssText = 'background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r);padding:14px;margin-bottom:10px';
    div.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">'
        + '<span style="font-size:12px;font-weight:800;color:var(--m2)">📦 Paket Grubu ' + idx + '</span>'
        + '<button type="button" onclick="satirSil('+idx+')" style="padding:4px 10px;background:#FEE2E2;color:#7F1D1D;border:none;border-radius:6px;cursor:pointer;font-size:11px">✕ Sil</button>'
        + '</div>'
        + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'
        +   '<div>'
        +     '<label style="font-size:11px;font-weight:700;color:var(--m3);display:block;margin-bottom:4px">Paket Başına Miktar (' + BIRIM + ')</label>'
        +     '<input type="number" class="form-alan paket-miktar-input" data-idx="'+idx+'" step="0.01" min="0.01" placeholder="Örn: 100" oninput="toplamHesapla()" style="width:100%">'
        +   '</div>'
        +   '<div>'
        +     '<label style="font-size:11px;font-weight:700;color:var(--m3);display:block;margin-bottom:4px">Adet (kaç paket)</label>'
        +     '<input type="number" class="form-alan paket-adet-input" data-idx="'+idx+'" step="1" min="1" value="1" oninput="toplamHesapla()" style="width:100%">'
        +   '</div>'
        + '</div>'
        + '<div id="oz-'+idx+'" style="margin-top:6px;font-size:11px;color:var(--m3);text-align:right"></div>';
    document.getElementById('paket-satirlar').appendChild(div);
    toplamHesapla();
}

function satirSil(idx) {
    var el = document.getElementById('satir-'+idx);
    if(el && document.querySelectorAll('.paket-miktar-input').length > 1) {
        el.remove(); toplamHesapla();
    }
}

function toplamHesapla() {
    var inputs = document.querySelectorAll('.paket-miktar-input');
    var top = 0; var toplamPaket = 0;
    inputs.forEach(function(el) {
        var idx  = el.getAttribute('data-idx');
        var mik  = parseFloat(el.value)||0;
        var adet = parseInt((document.querySelector('.paket-adet-input[data-idx="'+idx+'"]')||{}).value)||1;
        var s    = mik * adet;
        top += s; toplamPaket += adet;
        var oz = document.getElementById('oz-'+idx);
        if(oz) oz.textContent = mik>0 ? adet+' × '+mik.toFixed(2)+' = '+s.toFixed(2)+' '+BIRIM : '';
    });
    document.getElementById('toplam-gosterge').innerHTML =
        '<b>'+top.toFixed(2)+' '+BIRIM+'</b>'
        +' <span style="font-size:11px;color:var(--m3);margin-left:8px">('+toplamPaket+' paket)</span>';
    var msg = document.getElementById('dogrulama-mesaj');
    var btn = document.getElementById('kaydet-btn');
    if(!msg || !btn) return;
    if(top === 0) { msg.style.display='none'; btn.disabled=true; return; }
    msg.style.display='block';
    if(top > KONTROL_MIKTAR + 0.01) {
        // Kalan miktarı aşıyor — izin verme
        msg.style.cssText='font-size:12px;margin-bottom:12px;color:#DC2626;font-weight:700';
        msg.textContent='❌ Kalan miktarı aşıyor! Maksimum: '+KONTROL_MIKTAR.toFixed(2)+' '+BIRIM;
        btn.disabled=true;
    } else if(Math.abs(top - KONTROL_MIKTAR) <= 0.01) {
        // Tam kalan miktar — ideal
        msg.style.cssText='font-size:12px;margin-bottom:12px;color:#16A34A;font-weight:700';
        msg.textContent='✅ '+top.toFixed(2)+' '+BIRIM+' ('+toplamPaket+' paket) — tüm kalan alındı';
        btn.disabled=false;
    } else {
        // Kalan miktardan az — izin ver, kısmi etiket
        msg.style.cssText='font-size:12px;margin-bottom:12px;color:#0EA5E9;font-weight:700';
        msg.textContent='ℹ️ '+top.toFixed(2)+' '+BIRIM+' ('+toplamPaket+' paket) — kalan: '+(KONTROL_MIKTAR-top).toFixed(2)+' '+BIRIM+' sonra alınabilir';
        btn.disabled=false;
    }
}

function paketleriKaydet() {
    var inputs   = document.querySelectorAll('.paket-miktar-input');
    var ambar    = document.getElementById('glob-ambar').value;
    var stokyeri = document.getElementById('glob-stokyeri').value;
    var calisan  = document.getElementById('glob-calisan').value;
    var tarihv   = document.getElementById('glob-tarih').value;
    var paketler = [];
    inputs.forEach(function(el) {
        var idx  = el.getAttribute('data-idx');
        var mik  = parseFloat(el.value)||0;
        var adet = parseInt((document.querySelector('.paket-adet-input[data-idx="'+idx+'"]')||{}).value)||1;
        if(mik > 0 && adet > 0) {
            for(var j=0; j<adet; j++) paketler.push(mik);
        }
    });
    if(!paketler.length) return;
    var btn = document.getElementById('kaydet-btn');
    btn.disabled=true; btn.textContent='⏳ Oluşturuluyor...';
    fetch(BASE_EA+'/islemler/uretim/satinalma_paket_kaydet.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
            irsaliye_no: document.getElementById('_ea_irsno').value,
            stok_kodu:   document.getElementById('_ea_sk').value,
            stok_adi:    document.getElementById('_ea_sa').value,
            birim:       document.getElementById('_ea_birim').value,
            tarih:       tarihv,
            calisan:     calisan,
            ambar:       parseInt(ambar),
            stok_yeri:   stokyeri||'GKK',
            lot_no:      document.getElementById('_ea_lot').value,
            tedarikci:   document.getElementById('_ea_ted').value,
            paketler:    paketler
        })
    })
    .then(function(r){ return r.json(); })
    .then(function(d) {
        btn.disabled=false; btn.textContent='🏷️ Paketleri Oluştur ve Etiket Yazdır';
        if(d.success) {
            if(d.paket_detaylar && d.paket_detaylar.length > 0) {
                var form = document.createElement('form');
                form.method='POST'; form.action=BASE_EA+'/bolumler/uretim/paket_yazdir.php';
                form.target='_blank';
                var inp = document.createElement('input');
                inp.type='hidden'; inp.name='paketler';
                inp.value = JSON.stringify(d.paket_detaylar.map(function(p) {
                    return {
                        uretim_emri_no: p.irsaliye_no,
                        malzeme_kodu:   p.stok_kodu,
                        malzeme_adi:    p.stok_adi,
                        firma_kodu:     document.getElementById('_ea_cari').value || '15601',
                        firma_adi:      document.getElementById('_ea_ted').value || 'POLİZA ENDÜSTRİ A.Ş.',
                        uretim_tarihi:  p.tarih,
                        operator_kodu:  p.ekleyen || document.getElementById('glob-calisan').value,
                        miktar:         p.miktar,
                        lot_no:         p.paket_no,
                        etiket_turu:    'HAMMADDE'
                    };
                }));
                form.appendChild(inp);
                document.body.appendChild(form);
                form.submit();
                document.body.removeChild(form);
            }
            setTimeout(function(){ location.reload(); }, 600);
        } else {
            alert('Hata: ' + d.message);
        }
    })
    .catch(function(e) {
        btn.disabled=false; btn.textContent='🏷️ Paketleri Oluştur ve Etiket Yazdır';
        alert('Hata: '+e.message);
    });
}
</script>
