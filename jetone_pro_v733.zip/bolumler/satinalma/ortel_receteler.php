<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();

$mesaj = $mesaj_tip = '';

// Sil
if (isset($_GET['sil']) && is_numeric($_GET['sil'])) {
    $db->prepare("DELETE FROM ortel_receteler WHERE id=?")->execute([(int)$_GET['sil']]);
    header('Location: '.BASE_URL.'/panel.php?sayfa=satinalma-ortel-recete&islem=silok');
    exit;
}

// Kaydet / Güncelle
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stok_kodu          = trim($_POST['stok_kodu']??'');
    $stok_adi           = trim($_POST['stok_adi']??'');
    $girdi_kodu         = trim($_POST['girdi_kodu']??'');
    $girdi_adi          = trim($_POST['girdi_adi']??'');
    $girdi_birim_miktar = floatval($_POST['girdi_birim_miktar']??0);

    if (!$stok_kodu || !$girdi_kodu) {
        $mesaj = 'Stok kodu ve girdi kodu zorunludur.'; $mesaj_tip = 'hata';
    } elseif (isset($_POST['kaydet'])) {
        $db->prepare("INSERT INTO ortel_receteler (stok_kodu,stok_adi,girdi_kodu,girdi_adi,girdi_birim_miktar) VALUES (?,?,?,?,?)")
           ->execute([$stok_kodu,$stok_adi,$girdi_kodu,$girdi_adi,$girdi_birim_miktar]);
        $mesaj = 'Reçete kaydedildi.'; $mesaj_tip = 'basarili';
    } elseif (isset($_POST['duzenle']) && isset($_POST['id'])) {
        $db->prepare("UPDATE ortel_receteler SET stok_kodu=?,stok_adi=?,girdi_kodu=?,girdi_adi=?,girdi_birim_miktar=? WHERE id=?")
           ->execute([$stok_kodu,$stok_adi,$girdi_kodu,$girdi_adi,$girdi_birim_miktar,(int)$_POST['id']]);
        $mesaj = 'Reçete güncellendi.'; $mesaj_tip = 'basarili';
    }
}

$edit_data = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_data = $db->query("SELECT * FROM ortel_receteler WHERE id=".(int)$_GET['edit'])->fetch(PDO::FETCH_ASSOC);
}

$receteler = $db->query("SELECT * FROM ortel_receteler ORDER BY stok_kodu, girdi_kodu")->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
#tblOrtelRec th { background:#1E3A5F !important; color:#fff !important; }
#tblOrtelRec td, #tblOrtelRec th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🔧 Ortel Reçeteler</h1>
    <div class="s-yol">Satınalma / Ortel İhtiyaç / <b>Reçete Tanımları</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px">(<?php echo count($receteler);?> kayıt)</span>
    </div>
  </div>
  <button onclick="document.getElementById('receteForm').style.display=document.getElementById('receteForm').style.display==='none'?'block':'none'"
    style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
    <?php echo $edit_data ? '✏️ Düzenleme Modu' : '➕ Yeni Reçete';?>
  </button>
</div>

<?php if($mesaj):?>
<div style="background:<?php echo $mesaj_tip==='basarili'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $mesaj_tip==='basarili'?'#065F46':'#991B1B';?>;padding:10px 14px;border-radius:8px;margin-bottom:10px;font-weight:600">
  <?php echo $mesaj_tip==='basarili'?'✅':'❌';?> <?php echo htmlspecialchars($mesaj);?>
</div>
<?php endif;?>

<!-- Form -->
<div id="receteForm" style="<?php echo ($edit_data||($mesaj_tip==='hata'))?'display:block':'display:none';?>">
<div class="kart" style="padding:14px;margin-bottom:14px">
  <div style="font-weight:700;font-size:12px;color:#1E3A5F;margin-bottom:10px">
    <?php echo $edit_data ? '✏️ Reçete Düzenle (ID:'.$edit_data['id'].')' : '➕ Yeni Reçete Ekle';?>
  </div>
  <form method="POST">
    <?php if($edit_data):?><input type="hidden" name="id" value="<?php echo $edit_data['id'];?>"><?php endif;?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-bottom:12px">
      <div>
        <label class="form-etiket">Stok Kodu *</label>
        <input type="text" name="stok_kodu" class="form-alan" value="<?php echo htmlspecialchars($edit_data['stok_kodu']??'');?>" required placeholder="Ör: 2988080600">
      </div>
      <div>
        <label class="form-etiket">Stok Adı</label>
        <input type="text" name="stok_adi" class="form-alan" value="<?php echo htmlspecialchars($edit_data['stok_adi']??'');?>" placeholder="Stok adı...">
      </div>
      <div>
        <label class="form-etiket">Girdi Kodu *</label>
        <input type="text" name="girdi_kodu" class="form-alan" value="<?php echo htmlspecialchars($edit_data['girdi_kodu']??'');?>" required placeholder="Ör: 2985725200">
      </div>
      <div>
        <label class="form-etiket">Girdi Adı</label>
        <input type="text" name="girdi_adi" class="form-alan" value="<?php echo htmlspecialchars($edit_data['girdi_adi']??'');?>" placeholder="Girdi adı...">
      </div>
      <div>
        <label class="form-etiket">Girdi Birim Miktar *</label>
        <input type="number" name="girdi_birim_miktar" class="form-alan" step="0.01" value="<?php echo $edit_data['girdi_birim_miktar']??1;?>" required>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <?php if($edit_data):?>
      <button type="submit" name="duzenle" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Güncelle</button>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-ortel-recete"
        style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">İptal</a>
      <?php else:?>
      <button type="submit" name="kaydet" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
      <?php endif;?>
    </div>
  </form>
</div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblOrtelRec" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:35px">#</th>
    <th>Stok Kodu</th>
    <th>Stok Adı</th>
    <th>Girdi Kodu</th>
    <th>Girdi Adı</th>
    <th style="text-align:right">Birim Miktar</th>
    <th style="width:100px;text-align:center">İşlem</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Stok Kodu</th><th>Stok Adı</th>
    <th>Girdi Kodu</th><th>Girdi Adı</th><th>Birim Miktar</th><th>İşlem</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($receteler as $i=>$r):?>
  <tr>
    <td style="text-align:center;color:#64748B;font-size:11px"><?php echo $i+1;?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']);?></code></td>
    <td style="font-size:12px"><?php echo htmlspecialchars($r['stok_adi']??'');?></td>
    <td><code style="background:#EFF6FF;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700;color:#1D4ED8"><?php echo htmlspecialchars($r['girdi_kodu']);?></code></td>
    <td style="font-size:12px"><?php echo htmlspecialchars($r['girdi_adi']??'');?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format((float)($r['girdi_birim_miktar']??0),2,',','.');?></td>
    <td style="text-align:center;white-space:nowrap">
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-ortel-recete&edit=<?php echo $r['id'];?>"
        style="background:#0369A1;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;text-decoration:none;margin-right:3px">✏️</a>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-ortel-recete&sil=<?php echo $r['id'];?>"
        onclick="return confirm('Bu reçeteyi silmek istiyor musunuz?')"
        style="background:#DC2626;color:#fff;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;text-decoration:none">🗑</a>
    </td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<script>
$(document).ready(function(){
  if(!$('#tblOrtelRec tbody tr').length) return;
  $('#tblOrtelRec').DataTable({
    initComplete:function(){
      this.api().columns([1,2,3,4]).every(function(){
        var col=this,th=$(col.footer());if(!th||!th.length)return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>35)v=v.substr(0,36)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    columnDefs:[{orderable:false,targets:6}],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Ortel_Receteler'},
      'print'
    ]
  });
});
</script>
