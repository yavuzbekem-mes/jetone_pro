<?php
/**
 * JETONE.PRO — İkon Rehberi
 * panel.php: 'ayarlar-ikon-rehberi' => 'bolumler/ayarlar/ikon_rehberi.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
?>
<style>
.ikon-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(90px,1fr)); gap:8px; }
.ikon-kart {
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  gap:5px; padding:10px 6px; border-radius:10px; background:var(--yuzey);
  border:1.5px solid var(--kenar); cursor:pointer; transition:all .15s;
  text-align:center; min-height:72px;
}
.ikon-kart:hover { border-color:var(--t); background:var(--t-a); transform:translateY(-1px); box-shadow:0 4px 12px rgba(30,58,95,.12); }
.ikon-kart:active { transform:scale(.95); }
.ikon-kart .ikon-sembol { font-size:22px; line-height:1; }
.ikon-kart .ikon-kod { font-size:9px; color:var(--m2); font-family:monospace; word-break:break-all; margin-top:2px; }
.ikon-kart .ikon-ad { font-size:10px; color:var(--m); font-weight:600; line-height:1.2; }
.ikon-kategori { font-size:12px; font-weight:800; color:var(--m2); text-transform:uppercase; letter-spacing:1px;
                 margin:18px 0 8px; padding-bottom:6px; border-bottom:2px solid var(--kenar); }
.ikon-filtre { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
.ikon-filtre button { padding:5px 14px; border-radius:20px; border:1.5px solid var(--kenar);
                       background:none; cursor:pointer; font-size:12px; font-weight:700; color:var(--m2); }
.ikon-filtre button.aktif { background:var(--t); color:#fff; border-color:var(--t); }
#kopyalandiBilgi { position:fixed; bottom:24px; right:24px; background:#1E3A5F; color:#fff;
                   padding:10px 18px; border-radius:10px; font-size:13px; font-weight:700;
                   z-index:9999; display:none; box-shadow:0 4px 16px rgba(0,0,0,.2); }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🎨 İkon Rehberi</h1>
    <div class="s-yol">Ayarlar / <b>İkon Rehberi</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="font-size:12px;color:var(--m2)">İkona tıkla → emoji kopyalanır</span>
  </div>
</div>

<div class="s-body">

<!-- Arama -->
<div class="kart" style="margin-bottom:14px;padding:12px">
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <input type="text" id="ikonArama" class="form-alan" style="flex:1;min-width:220px"
           placeholder="🔍 İkon ara... (örn: fabrika, makine, kalite)"
           oninput="ikonAra(this.value)">
    <button onclick="ikonAra('');document.getElementById('ikonArama').value=''" class="btn btn-b btn-sm">Temizle</button>
    <span id="ikonSayac" style="font-size:12px;color:var(--m2);white-space:nowrap"></span>
  </div>
</div>

<!-- Kategori filtreleri -->
<div class="ikon-filtre" id="kategoriFiltre">
  <button class="aktif" onclick="kategoriSec('hepsi',this)">Tümü</button>
  <button onclick="kategoriSec('uretim',this)">🏭 Üretim</button>
  <button onclick="kategoriSec('kalite',this)">✅ Kalite</button>
  <button onclick="kategoriSec('malzeme',this)">📦 Malzeme</button>
  <button onclick="kategoriSec('insan',this)">👥 İnsan</button>
  <button onclick="kategoriSec('teknik',this)">🔧 Teknik</button>
  <button onclick="kategoriSec('bilgi',this)">📊 Veri & Bilgi</button>
  <button onclick="kategoriSec('durum',this)">🚦 Durum</button>
  <button onclick="kategoriSec('ofis',this)">📋 Ofis & Yönetim</button>
  <button onclick="kategoriSec('ok',this)">✔ OK & İşaret</button>
</div>

<div id="ikonKonteynir"></div>

</div><!-- /s-body -->

<div id="kopyalandiBilgi">📋 Kopyalandı!</div>

<script>
var IKONLAR = [
  // ── ÜRETİM & FABRİKA ─────────────────────────────────────────────
  {k:'uretim', e:'🏭', a:'Fabrika'},
  {k:'uretim', e:'⚙️', a:'Dişli'},
  {k:'uretim', e:'🔩', a:'Vida Somun'},
  {k:'uretim', e:'🪛', a:'Tornavida'},
  {k:'uretim', e:'🔧', a:'İngiliz Anahtarı'},
  {k:'uretim', e:'🪝', a:'Kanca'},
  {k:'uretim', e:'⛏', a:'Kazma'},
  {k:'uretim', e:'🔨', a:'Çekiç'},
  {k:'uretim', e:'⚒', a:'Kazma Çekiç'},
  {k:'uretim', e:'🛠️', a:'Alet Takımı'},
  {k:'uretim', e:'🪚', a:'Testere'},
  {k:'uretim', e:'🔑', a:'Anahtar'},
  {k:'uretim', e:'🧲', a:'Mıknatıs'},
  {k:'uretim', e:'💡', a:'Ampul'},
  {k:'uretim', e:'⚡', a:'Elektrik'},
  {k:'uretim', e:'🔋', a:'Pil'},
  {k:'uretim', e:'🔌', a:'Fiş'},
  {k:'uretim', e:'🖨️', a:'Yazıcı'},
  {k:'uretim', e:'🏗️', a:'İnşaat'},
  {k:'uretim', e:'🚧', a:'Barikat'},
  {k:'uretim', e:'🏚️', a:'Depo'},
  {k:'uretim', e:'🏬', a:'Bina'},
  {k:'uretim', e:'🔬', a:'Mikroskop'},
  {k:'uretim', e:'🧪', a:'Test Tüpü'},
  {k:'uretim', e:'🧫', a:'Petri Kabı'},
  {k:'uretim', e:'⚗️', a:'Kimya Şişesi'},
  {k:'uretim', e:'💉', a:'Şırınga'},
  {k:'uretim', e:'🌡️', a:'Termometre'},
  {k:'uretim', e:'⚖️', a:'Terazi'},
  {k:'uretim', e:'📐', a:'Gönye'},
  {k:'uretim', e:'📏', a:'Cetvel'},
  {k:'uretim', e:'🖇️', a:'Ataş'},
  {k:'uretim', e:'✂️', a:'Makas'},
  {k:'uretim', e:'🗜️', a:'Mengene'},
  {k:'uretim', e:'🪣', a:'Kova'},
  {k:'uretim', e:'🧯', a:'Yangın Tüpü'},
  {k:'uretim', e:'🪖', a:'Baret'},
  {k:'uretim', e:'🦺', a:'Yelek'},
  {k:'uretim', e:'🥽', a:'Koruyucu Gözlük'},
  {k:'uretim', e:'🧤', a:'Eldiven'},

  // ── KALİTE & KONTROL ─────────────────────────────────────────────
  {k:'kalite', e:'✅', a:'Onay'},
  {k:'kalite', e:'❌', a:'Ret'},
  {k:'kalite', e:'⚠️', a:'Uyarı'},
  {k:'kalite', e:'🚨', a:'Alarm'},
  {k:'kalite', e:'🔍', a:'Büyüteç'},
  {k:'kalite', e:'🔎', a:'Büyüteç 2'},
  {k:'kalite', e:'🎯', a:'Hedef'},
  {k:'kalite', e:'🏆', a:'Kupa'},
  {k:'kalite', e:'🥇', a:'Altın Madalya'},
  {k:'kalite', e:'⭐', a:'Yıldız'},
  {k:'kalite', e:'🌟', a:'Parlayan Yıldız'},
  {k:'kalite', e:'💎', a:'Elmas'},
  {k:'kalite', e:'🔖', a:'Yer İmi'},
  {k:'kalite', e:'📌', a:'Toplu İğne'},
  {k:'kalite', e:'📎', a:'Ataş'},
  {k:'kalite', e:'🎖️', a:'Madalya'},
  {k:'kalite', e:'🏅', a:'Madalya 2'},
  {k:'kalite', e:'🔐', a:'Kilit'},
  {k:'kalite', e:'🔒', a:'Kilitli'},
  {k:'kalite', e:'🔓', a:'Açık'},
  {k:'kalite', e:'🛡️', a:'Kalkan'},
  {k:'kalite', e:'✔️', a:'Tik'},
  {k:'kalite', e:'☑️', a:'Kutucuk Tik'},
  {k:'kalite', e:'🩺', a:'Stetoskop'},

  // ── MALZEME & LOJİSTİK ───────────────────────────────────────────
  {k:'malzeme', e:'📦', a:'Kutu'},
  {k:'malzeme', e:'🗃️', a:'Dosya Kutusu'},
  {k:'malzeme', e:'🗂️', a:'Dosya Bölücü'},
  {k:'malzeme', e:'📫', a:'Posta Kutusu'},
  {k:'malzeme', e:'🚚', a:'Kamyon'},
  {k:'malzeme', e:'🚛', a:'TIR'},
  {k:'malzeme', e:'🏪', a:'Mağaza'},
  {k:'malzeme', e:'🏬', a:'Depo'},
  {k:'malzeme', e:'🛒', a:'Alışveriş Arabası'},
  {k:'malzeme', e:'🛒', a:'Sepet'},
  {k:'malzeme', e:'🪜', a:'Merdiven'},
  {k:'malzeme', e:'🧺', a:'Sepet'},
  {k:'malzeme', e:'🪤', a:'Kapan'},
  {k:'malzeme', e:'⛽', a:'Yakıt'},
  {k:'malzeme', e:'🔢', a:'Numara'},
  {k:'malzeme', e:'🏷️', a:'Etiket'},
  {k:'malzeme', e:'📋', a:'Pano'},
  {k:'malzeme', e:'🗒️', a:'Not Defteri'},
  {k:'malzeme', e:'📝', a:'Kalem Not'},
  {k:'malzeme', e:'🗄️', a:'Dolap'},
  {k:'malzeme', e:'🏠', a:'Ev Depo'},

  // ── İNSAN & ORGANİZASYON ────────────────────────────────────────
  {k:'insan', e:'👤', a:'Kişi'},
  {k:'insan', e:'👥', a:'Kişiler'},
  {k:'insan', e:'👨‍🔧', a:'Teknisyen'},
  {k:'insan', e:'👷', a:'İşçi'},
  {k:'insan', e:'👷‍♂️', a:'İşçi Erkek'},
  {k:'insan', e:'👷‍♀️', a:'İşçi Kadın'},
  {k:'insan', e:'👨‍💼', a:'Yönetici'},
  {k:'insan', e:'👩‍💼', a:'Yönetici Kadın'},
  {k:'insan', e:'🧑‍🏭', a:'Fabrika İşçisi'},
  {k:'insan', e:'👨‍🔬', a:'Bilim İnsanı'},
  {k:'insan', e:'🧑‍💻', a:'Programcı'},
  {k:'insan', e:'🤝', a:'El Sıkışma'},
  {k:'insan', e:'👋', a:'El Sallama'},
  {k:'insan', e:'🙋', a:'El Kaldırma'},
  {k:'insan', e:'🧑‍🤝‍🧑', a:'Takım'},
  {k:'insan', e:'🫂', a:'Kucaklaşma'},

  // ── TEKNİK & BİLİŞİM ────────────────────────────────────────────
  {k:'teknik', e:'💻', a:'Laptop'},
  {k:'teknik', e:'🖥️', a:'Masaüstü'},
  {k:'teknik', e:'🖱️', a:'Mouse'},
  {k:'teknik', e:'⌨️', a:'Klavye'},
  {k:'teknik', e:'📱', a:'Telefon'},
  {k:'teknik', e:'📡', a:'Anten'},
  {k:'teknik', e:'🔗', a:'Bağlantı'},
  {k:'teknik', e:'🌐', a:'Web'},
  {k:'teknik', e:'☁️', a:'Bulut'},
  {k:'teknik', e:'💾', a:'Disket'},
  {k:'teknik', e:'💿', a:'CD'},
  {k:'teknik', e:'🖲️', a:'Trackball'},
  {k:'teknik', e:'📲', a:'Mobil'},
  {k:'teknik', e:'🔭', a:'Teleskop'},
  {k:'teknik', e:'📡', a:'Sinyal'},
  {k:'teknik', e:'🔐', a:'Şifre'},
  {k:'teknik', e:'🧩', a:'Puzzle'},
  {k:'teknik', e:'🤖', a:'Robot'},
  {k:'teknik', e:'🛰️', a:'Uydu'},

  // ── VERİ & BİLGİ ────────────────────────────────────────────────
  {k:'bilgi', e:'📊', a:'Bar Grafik'},
  {k:'bilgi', e:'📈', a:'Yükselen Grafik'},
  {k:'bilgi', e:'📉', a:'Düşen Grafik'},
  {k:'bilgi', e:'📑', a:'Rapor'},
  {k:'bilgi', e:'📃', a:'Sayfa'},
  {k:'bilgi', e:'📄', a:'Belge'},
  {k:'bilgi', e:'📁', a:'Klasör'},
  {k:'bilgi', e:'📂', a:'Açık Klasör'},
  {k:'bilgi', e:'🗃️', a:'Arşiv'},
  {k:'bilgi', e:'📰', a:'Gazete'},
  {k:'bilgi', e:'🗞️', a:'Rulo'},
  {k:'bilgi', e:'📚', a:'Kitap'},
  {k:'bilgi', e:'📖', a:'Açık Kitap'},
  {k:'bilgi', e:'📓', a:'Not Defteri'},
  {k:'bilgi', e:'📔', a:'Süslü Not'},
  {k:'bilgi', e:'🗓️', a:'Takvim'},
  {k:'bilgi', e:'📅', a:'Takvim 2'},
  {k:'bilgi', e:'⏱️', a:'Kronometre'},
  {k:'bilgi', e:'⏰', a:'Çalar Saat'},
  {k:'bilgi', e:'🕐', a:'Saat'},
  {k:'bilgi', e:'⌚', a:'Kol Saati'},
  {k:'bilgi', e:'🔔', a:'Çan'},
  {k:'bilgi', e:'🔕', a:'Sessiz Çan'},
  {k:'bilgi', e:'📣', a:'Megafon'},
  {k:'bilgi', e:'📢', a:'Hoparlör'},
  {k:'bilgi', e:'💬', a:'Mesaj'},
  {k:'bilgi', e:'📧', a:'E-posta'},
  {k:'bilgi', e:'📩', a:'Gelen Kutusu'},
  {k:'bilgi', e:'✉️', a:'Zarf'},
  {k:'bilgi', e:'🗺️', a:'Harita'},
  {k:'bilgi', e:'🧭', a:'Pusula'},

  // ── DURUM & GÖSTERGELER ──────────────────────────────────────────
  {k:'durum', e:'🟢', a:'Yeşil Daire'},
  {k:'durum', e:'🟡', a:'Sarı Daire'},
  {k:'durum', e:'🔴', a:'Kırmızı Daire'},
  {k:'durum', e:'🔵', a:'Mavi Daire'},
  {k:'durum', e:'🟠', a:'Turuncu Daire'},
  {k:'durum', e:'🟣', a:'Mor Daire'},
  {k:'durum', e:'⚫', a:'Siyah Daire'},
  {k:'durum', e:'⚪', a:'Beyaz Daire'},
  {k:'durum', e:'🔶', a:'Turuncu Baklava'},
  {k:'durum', e:'🔷', a:'Mavi Baklava'},
  {k:'durum', e:'▶️', a:'Oynat'},
  {k:'durum', e:'⏸️', a:'Durdur'},
  {k:'durum', e:'⏹️', a:'Stop'},
  {k:'durum', e:'⏭️', a:'İleri'},
  {k:'durum', e:'⏮️', a:'Geri'},
  {k:'durum', e:'🔄', a:'Yenile'},
  {k:'durum', e:'↩️', a:'Geri Dön'},
  {k:'durum', e:'↪️', a:'İleri Git'},
  {k:'durum', e:'⬆️', a:'Yukarı'},
  {k:'durum', e:'⬇️', a:'Aşağı'},
  {k:'durum', e:'➡️', a:'Sağ'},
  {k:'durum', e:'⬅️', a:'Sol'},
  {k:'durum', e:'🔛', a:'Açık'},
  {k:'durum', e:'🔜', a:'Yakında'},
  {k:'durum', e:'🔝', a:'Üst'},
  {k:'durum', e:'🆕', a:'Yeni'},
  {k:'durum', e:'🆗', a:'OK'},
  {k:'durum', e:'🆙', a:'Güncelle'},
  {k:'durum', e:'🆓', a:'Ücretsiz'},
  {k:'durum', e:'❓', a:'Soru'},
  {k:'durum', e:'❗', a:'Ünlem'},
  {k:'durum', e:'‼️', a:'Çift Ünlem'},
  {k:'durum', e:'🚩', a:'Bayrak'},
  {k:'durum', e:'🏁', a:'Finiş'},
  {k:'durum', e:'🚦', a:'Trafik Lambası'},
  {k:'durum', e:'🚥', a:'Trafik Işığı'},

  // ── OFİS & YÖNETİM ──────────────────────────────────────────────
  {k:'ofis', e:'🏢', a:'Ofis Binası'},
  {k:'ofis', e:'💼', a:'Evrak Çantası'},
  {k:'ofis', e:'🗂️', a:'Dosyalar'},
  {k:'ofis', e:'✏️', a:'Kalem'},
  {k:'ofis', e:'🖊️', a:'Tükenmez Kalem'},
  {k:'ofis', e:'🖋️', a:'Dolma Kalem'},
  {k:'ofis', e:'📝', a:'Not Al'},
  {k:'ofis', e:'📌', a:'Raptiye'},
  {k:'ofis', e:'📍', a:'Konum'},
  {k:'ofis', e:'🗑️', a:'Çöp'},
  {k:'ofis', e:'🏛️', a:'Kurum'},
  {k:'ofis', e:'🏦', a:'Banka'},
  {k:'ofis', e:'💰', a:'Para'},
  {k:'ofis', e:'💵', a:'Dolar'},
  {k:'ofis', e:'💳', a:'Kart'},
  {k:'ofis', e:'🧾', a:'Fiş'},
  {k:'ofis', e:'🤑', a:'Para Gözlü'},
  {k:'ofis', e:'📊', a:'Sunum'},
  {k:'ofis', e:'🗣️', a:'Konuşan'},
  {k:'ofis', e:'📞', a:'Telefon'},
  {k:'ofis', e:'☎️', a:'Sabit Telefon'},
  {k:'ofis', e:'📟', a:'Pager'},
  {k:'ofis', e:'🖨️', a:'Baskı'},
  {k:'ofis', e:'📠', a:'Faks'},
  {k:'ofis', e:'🏆', a:'Ödül'},

  // ── OK & İŞARET ──────────────────────────────────────────────────
  {k:'ok', e:'✅', a:'Yeşil Onay'},
  {k:'ok', e:'☑️', a:'Onay Kutusu'},
  {k:'ok', e:'✔️', a:'Tik İşareti'},
  {k:'ok', e:'❎', a:'Çarpı Kutusu'},
  {k:'ok', e:'❌', a:'Kırmızı Çarpı'},
  {k:'ok', e:'⛔', a:'Yasak'},
  {k:'ok', e:'🚫', a:'Yasak 2'},
  {k:'ok', e:'🔞', a:'18+'},
  {k:'ok', e:'💯', a:'100 Puan'},
  {k:'ok', e:'🔥', a:'Ateş'},
  {k:'ok', e:'⚡', a:'Şimşek'},
  {k:'ok', e:'💥', a:'Patlama'},
  {k:'ok', e:'✨', a:'Sparkle'},
  {k:'ok', e:'🌈', a:'Gökkuşağı'},
  {k:'ok', e:'⭐', a:'Yıldız'},
  {k:'ok', e:'🌙', a:'Ay'},
  {k:'ok', e:'☀️', a:'Güneş'},
  {k:'ok', e:'🌤️', a:'Güneşli Bulut'},
  {k:'ok', e:'🌧️', a:'Yağmur'},
  {k:'ok', e:'❄️', a:'Kar'},
  {k:'ok', e:'🌊', a:'Dalga'},
  {k:'ok', e:'🌿', a:'Yaprak'},
  {k:'ok', e:'🌱', a:'Fide'},
  {k:'ok', e:'♻️', a:'Geri Dönüşüm'},
];

var aktifKategori = 'hepsi';
var aramaMetni   = '';

function render() {
  var filtreli = IKONLAR.filter(function(ikon){
    var katFlt  = aktifKategori==='hepsi' || ikon.k===aktifKategori;
    var araFlt  = !aramaMetni || ikon.a.toLowerCase().includes(aramaMetni.toLowerCase()) || ikon.e.includes(aramaMetni);
    return katFlt && araFlt;
  });

  document.getElementById('ikonSayac').textContent = filtreli.length + ' ikon';

  // Kategoriye göre grupla
  var gruplar = {};
  var katAdlari = {
    'uretim':'🏭 Üretim & Fabrika','kalite':'✅ Kalite & Kontrol',
    'malzeme':'📦 Malzeme & Lojistik','insan':'👥 İnsan & Organizasyon',
    'teknik':'💻 Teknik & Bilişim','bilgi':'📊 Veri & Bilgi',
    'durum':'🚦 Durum & Göstergeler','ofis':'💼 Ofis & Yönetim','ok':'✔ OK & İşaret'
  };

  filtreli.forEach(function(ikon){
    if (!gruplar[ikon.k]) gruplar[ikon.k] = [];
    gruplar[ikon.k].push(ikon);
  });

  var html = '';
  var siralama = ['uretim','kalite','malzeme','insan','teknik','bilgi','durum','ofis','ok'];
  siralama.forEach(function(kat){
    if (!gruplar[kat] || !gruplar[kat].length) return;
    if (aktifKategori==='hepsi') {
      html += '<div class="ikon-kategori">'+katAdlari[kat]+' <span style="font-size:11px;color:var(--m3);font-weight:400">('+gruplar[kat].length+')</span></div>';
    }
    html += '<div class="ikon-grid">';
    gruplar[kat].forEach(function(ikon){
      html += '<div class="ikon-kart" onclick="ikonKopyala(\''+ikon.e+'\')" title="Kopyala: '+ikon.e+'">'
        + '<div class="ikon-sembol">'+ikon.e+'</div>'
        + '<div class="ikon-ad">'+ikon.a+'</div>'
        + '</div>';
    });
    html += '</div>';
  });

  if (!html) html = '<div style="padding:48px;text-align:center;color:var(--m2)">Sonuç bulunamadı</div>';
  document.getElementById('ikonKonteynir').innerHTML = html;
}

function ikonKopyala(emoji) {
  navigator.clipboard.writeText(emoji).then(function(){
    var el = document.getElementById('kopyalandiBilgi');
    el.textContent = emoji + ' Kopyalandı!';
    el.style.display = 'block';
    setTimeout(function(){ el.style.display='none'; }, 1800);
  }).catch(function(){
    // Fallback
    var ta=document.createElement('textarea');
    ta.value=emoji; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
    var el=document.getElementById('kopyalandiBilgi');
    el.textContent=emoji+' Kopyalandı!'; el.style.display='block';
    setTimeout(function(){ el.style.display='none'; },1800);
  });
}

function ikonAra(metin) {
  aramaMetni = metin;
  render();
}

function kategoriSec(kat, btn) {
  aktifKategori = kat;
  document.querySelectorAll('.ikon-filtre button').forEach(function(b){ b.classList.remove('aktif'); });
  btn.classList.add('aktif');
  render();
}

// İlk render
render();
</script>
