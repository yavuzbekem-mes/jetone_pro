<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<div class="s-bar"><div class="s-bas">Bulunamadi</div></div>'; return; }
$q = $db->prepare("SELECT d.*, CONCAT(p.ad,' ',p.soyad) zimmet_adi FROM demirbaslar d LEFT JOIN personeller p ON d.zimmet_personel_id=p.id WHERE d.id=? LIMIT 1");
$q->execute([$id]); $d = $q->fetch();
if (!$d) { echo '<div class="s-bar"><div class="s-bas">Bulunamadi</div></div>'; return; }
$hareketler = $db->prepare("SELECT dh.*, CONCAT(p.ad,' ',p.soyad) per_adi FROM demirbas_hareketler dh LEFT JOIN personeller p ON dh.personel_id=p.id WHERE dh.demirbas_id=? ORDER BY dh.tarih DESC");
$hareketler->execute([$id]); $hareketler = $hareketler->fetchAll();
$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();
$durum_cfg=['aktif'=>['#D1FAE5','#065F46','Aktif'],'zimmetli'=>['#DBEAFE','#1E40AF','Zimmetli'],'depoda'=>['#F3F4F6','#6B7280','Depoda'],'bakimda'=>['#FEF3C7','#92400E','Bakimda'],'hurdaya_ayrildi'=>['#FEE2E2','#991B1B','Hurda']];
$dc = $durum_cfg[$d['durum']] ?? ['#F3F4F6','#374151',$d['durum']];
$har_tr = ['zimmet'=>'Zimmet','iade'=>'Iade','devir'=>'Devir','bakim'=>'Bakim','kayip'=>'Kayip','hurda'=>'Hurda'];
$garanti_gecti = $d['garanti_bitis'] && $d['garanti_bitis'] < date('Y-m-d');
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo htmlspecialchars($d['adi']); ?></h1>
    <div class="s-yol">Idari / <a href="?sayfa=idari-demirbas-listesi" style="color:var(--t);text-decoration:none">Envanter</a> / <b><?php echo htmlspecialchars($d['adi']); ?></b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px"><?php echo $dc[2]; ?></span>
    <a href="?sayfa=idari-demirbas-form&id=<?php echo $id; ?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Duzenle</a>
    <a href="?sayfa=idari-demirbas-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Liste</a>
  </div>

  <button onclick="dtExcelIndir('tbl-demirbas_detay','Demirbas_Detay')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:12px">Demirbaş Detay</div>
    <?php $bilgiler = [
      'Barkod'          => htmlspecialchars($d['barkod']??'—'),
      'Kategori'        => htmlspecialchars($d['kategori']??'—'),
      'Marka / Model'   => htmlspecialchars(trim(($d['marka']??'').' '.($d['model']??'')))||'—',
      'Seri No'         => htmlspecialchars($d['seri_no']??'—'),
      'Konum'           => htmlspecialchars($d['konum']??'—'),
      'Zimmetli'        => htmlspecialchars($d['zimmet_adi']??'—'),
      'Zimmet Tarihi'   => $d['zimmet_tarihi']?date('d.m.Y',strtotime($d['zimmet_tarihi'])):'—',
      'Satin Alma'      => $d['satin_alma_tarihi']?date('d.m.Y',strtotime($d['satin_alma_tarihi'])):'—',
      'Satin Alma Tutar'=> $d['satin_alma_tutar']?number_format($d['satin_alma_tutar'],2).' TL':'—',
      'Tedarikci'       => htmlspecialchars($d['tedarikci']??'—'),
      'Garanti Bitis'   => ($d['garanti_bitis']?date('d.m.Y',strtotime($d['garanti_bitis'])):'—').($garanti_gecti?' (Doldu)':''),
      'Amortisman'      => $d['amortisman_yil']?$d['amortisman_yil'].' yil':'—',
    ];
    foreach ($bilgiler as $k=>$v): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $k; ?></span>
      <span style="font-weight:600"><?php echo $v; ?></span>
    </div>
    <?php endforeach; ?>
    <?php if ($d['notlar']): ?><div style="margin-top:10px;padding:10px;background:var(--bg);border-radius:8px;font-size:13px;color:var(--m2)"><?php echo nl2br(htmlspecialchars($d['notlar'])); ?></div><?php endif; ?>
  </div>

  <div class="kart" style="padding:16px">
    <div class="kart-bas" style="margin-bottom:12px">Hareket Ekle</div>
    <div style="display:grid;gap:10px">
      <div>
        <label class="form-etiket">Hareket Tipi</label>
        <select class="form-alan" id="hTip">
          <?php foreach ($har_tr as $k=>$et): ?><option value="<?php echo $k; ?>"><?php echo $et; ?></option><?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-etiket">Personel</label>
        <select class="form-alan" id="hPer">
          <option value="">— Secmiyorum —</option>
          <?php foreach ($personeller as $pr): ?><option value="<?php echo $pr['id']; ?>"><?php echo htmlspecialchars($pr['ad_soyad']); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-etiket">Tarih</label>
        <input type="date" class="form-alan" id="hTarih" value="<?php echo date('Y-m-d'); ?>">
      </div>
      <div>
        <label class="form-etiket">Aciklama</label>
        <textarea class="form-alan" id="hAcik" rows="2"></textarea>
      </div>
      <button onclick="hareketEkle()" style="background:var(--t);color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Hareketi Kaydet</button>
    </div>
  </div>
</div>

<!-- Hareket gecmisi -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Hareket Gecmisi</div></div>
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-demirbas_detay" style="width:100%">
    <thead><tr><th>Tarih</th><th>Tip</th><th>Personel</th><th>Aciklama</th></tr></thead>
    <tbody>
      <?php if (empty($hareketler)): ?>
      <tr><td colspan="4" style="text-align:center;padding:24px;color:var(--m2)">Hareket kaydi yok.</td></tr>
      <?php else: foreach ($hareketler as $h):
        $hc=['zimmet'=>['#DBEAFE','#1E40AF'],'iade'=>['#D1FAE5','#065F46'],'devir'=>['#FEF3C7','#92400E'],'bakim'=>['#EDE9FE','#5B21B6'],'kayip'=>['#FEE2E2','#991B1B'],'hurda'=>['#F3F4F6','#6B7280']][$h['hareket_tipi']]??['#F3F4F6','#374151'];
      ?>
      <tr>
        <td><?php echo date('d.m.Y',strtotime($h['tarih'])); ?></td>
        <td><span style="background:<?php echo $hc[0]; ?>;color:<?php echo $hc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $har_tr[$h['hareket_tipi']]??$h['hareket_tipi']; ?></span></td>
        <td><?php echo htmlspecialchars($h['per_adi']??'—'); ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($h['aciklama']??''); ?></td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
</div>

<script>
function hareketEkle() {
    var fd = new FormData();
    fd.append('demirbas_id', <?php echo $id; ?>);
    fd.append('hareket_tipi', document.getElementById('hTip').value);
    fd.append('personel_id', document.getElementById('hPer').value);
    fd.append('tarih', document.getElementById('hTarih').value);
    fd.append('aciklama', document.getElementById('hAcik').value);
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/demirbas-hareket.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert(r.hata);
    });
}
</script>
