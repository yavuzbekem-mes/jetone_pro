<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<div class="s-bar"><div class="s-bas">Bulunamadi</div></div>'; return; }
$q = $db->prepare("SELECT s.*, t.teklif_no FROM sozlesmeler s LEFT JOIN teklifler t ON s.teklif_id=t.id WHERE s.id=? LIMIT 1");
$q->execute([$id]); $s = $q->fetch();
if (!$s) { echo '<div class="s-bar"><div class="s-bas">Bulunamadi</div></div>'; return; }

$durum_cfg = ['taslak'=>['#F3F4F6','#6B7280','Taslak'],'aktif'=>['#D1FAE5','#065F46','Aktif'],'suresi_doldu'=>['#FEE2E2','#991B1B','Suresi Doldu'],'feshedildi'=>['#FEE2E2','#991B1B','Feshedildi'],'yenilendi'=>['#DBEAFE','#1E40AF','Yenilendi']];
$dc = $durum_cfg[$s['durum']] ?? ['#F3F4F6','#374151',$s['durum']];
$tip_tr = ['tedarik'=>'Tedarik','hizmet'=>'Hizmet','kira'=>'Kira','is'=>'Is Sozlesmesi','diger'=>'Diger'];
$bugun = date('Y-m-d');
$kalanGun = $s['bitis'] ? (int)((strtotime($s['bitis'])-strtotime($bugun))/(86400)) : null;
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo htmlspecialchars($s['sozlesme_no']); ?></h1>
    <div class="s-yol">Idari / <a href="?sayfa=idari-sozlesme-listesi" style="color:var(--t);text-decoration:none">Sozlesmeler</a> / <b><?php echo htmlspecialchars($s['sozlesme_no']); ?></b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px"><?php echo $dc[2]; ?></span>
    <a href="?sayfa=idari-sozlesme-form&id=<?php echo $id; ?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Duzenle</a>
    <a href="?sayfa=idari-sozlesme-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Liste</a>
  </div>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:2fr 1fr;gap:14px">

  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:12px">Sozlesme Detaylari</div>
    <?php $bilgiler = [
      'Sozlesme No'    => htmlspecialchars($s['sozlesme_no']),
      'Tip'            => $tip_tr[$s['tip']]??$s['tip'],
      'Konu'           => htmlspecialchars($s['konu']),
      'Taraf / Firma'  => htmlspecialchars($s['taraf_adi']),
      'E-posta'        => htmlspecialchars($s['taraf_email']??'—'),
      'Baslangic'      => $s['baslangic']?date('d.m.Y',strtotime($s['baslangic'])):'—',
      'Bitis'          => $s['bitis']?date('d.m.Y',strtotime($s['bitis'])):'—',
      'Sure (Ay)'      => $s['sure_ay']?$s['sure_ay'].' ay':'—',
      'Tutar'          => $s['tutar']?number_format($s['tutar'],2).' '.($s['para_birimi']??'TRY'):'—',
      'Ot. Yenileme'   => $s['yenileme']?'Evet':'Hayir',
      'Ilgili Teklif'  => htmlspecialchars($s['teklif_no']??'—'),
    ];
    foreach ($bilgiler as $k=>$v): ?>
    <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $k; ?></span>
      <span style="font-weight:600"><?php echo $v; ?></span>
    </div>
    <?php endforeach; ?>
    <?php if ($s['notlar']): ?><div style="margin-top:10px;padding:10px;background:var(--bg);border-radius:8px;font-size:13px;color:var(--m2)"><?php echo nl2br(htmlspecialchars($s['notlar'])); ?></div><?php endif; ?>
  </div>

  <div>
    <?php if ($kalanGun !== null): ?>
    <div class="kart" style="padding:18px 20px;margin-bottom:14px;text-align:center">
      <?php if ($kalanGun < 0): ?>
        <div style="font-size:36px">⚠️</div>
        <div style="font-size:22px;font-weight:800;color:#EF4444"><?php echo abs($kalanGun); ?> gun gecti</div>
        <div style="color:var(--m2);font-size:13px">Sozlesme suresi doldu</div>
      <?php elseif ($kalanGun <= 30): ?>
        <div style="font-size:36px">⏳</div>
        <div style="font-size:22px;font-weight:800;color:#D97706"><?php echo $kalanGun; ?> gun kaldi</div>
        <div style="color:var(--m2);font-size:13px">Yenileme sureci baslatilmali</div>
      <?php else: ?>
        <div style="font-size:36px">✅</div>
        <div style="font-size:22px;font-weight:800;color:#059669"><?php echo $kalanGun; ?> gun kaldi</div>
        <div style="color:var(--m2);font-size:13px">Sozlesme aktif</div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="kart" style="padding:16px">
      <div class="kart-bas" style="margin-bottom:10px">Durumu Guncelle</div>
      <?php foreach (['aktif'=>['#D1FAE5','#065F46','Aktif yap'],'suresi_doldu'=>['#FEE2E2','#991B1B','Suresi Doldu'],'feshedildi'=>['#FEE2E2','#7F1D1D','Feshet'],'yenilendi'=>['#DBEAFE','#1E40AF','Yenilendi']] as $k=>$d): ?>
      <button onclick="durumDegistir('<?php echo $k; ?>')" style="width:100%;background:<?php echo $d[0]; ?>;color:<?php echo $d[1]; ?>;border:none;padding:9px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;margin-bottom:6px;text-align:left"><?php echo $d[2]; ?></button>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</div>

<script>
function durumDegistir(durum) {
    if (!confirm('Durum guncellensin mi?')) return;
    var fd = new FormData(); fd.append('id', <?php echo $id; ?>); fd.append('durum', durum);
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/sozlesme-durum.php', {method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){ if(r.ok) location.reload(); else alert(r.hata); });
}
</script>
