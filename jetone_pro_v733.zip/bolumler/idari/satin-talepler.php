<?php
/**
 * İdari İşler — Satınalma Talepleri Listesi
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$user   = Auth::kullanici();
$uid    = (int)$user['id'];
$rol_id = (int)($user['rol_id'] ?? 0);

// Sistem rolü kontrolü (rol_id=1 veya sistem_rol=1 olan)
$is_sistem = 0;
$user_dept = '';
try {
    $sr = $db->prepare("SELECT sistem_rol FROM roller WHERE id=? LIMIT 1");
    $sr->execute([$rol_id]);
    $is_sistem = (int)($sr->fetchColumn() ?: 0);
} catch (Throwable $e) {}

// rol_id=1 (ilk kayıt genellikle süper admin) ise direkt yetkili say
if ($rol_id === 1) $is_sistem = 1;

// Departman kontrolü
try {
    $dr = $db->prepare("SELECT d.ad FROM personeller p JOIN departmanlar d ON p.departman_id=d.id WHERE p.kullanici_id=? AND p.durum='aktif' LIMIT 1");
    $dr->execute([$uid]);
    $user_dept = $dr->fetchColumn() ?: '';
} catch (Throwable $e) {}

$is_yonetici = ($is_sistem === 1)
    || stripos($user_dept,'satın') !== false
    || stripos($user_dept,'satin') !== false
    || stripos($user_dept,'idari') !== false;

// Filtreler
$f_durum  = $_GET['durum']  ?? '';
$f_yil    = (int)($_GET['yil']   ?? date('Y'));
$f_arama  = trim($_GET['ara']    ?? '');

// Sorgu
$where  = ["1=1"];
$params = [];

// Yönetici değilse sadece kendi talepleri
if (!$is_yonetici) {
    $where[] = "t.talep_eden_id = ?";
    $params[] = $uid;
}
if ($f_durum)   { $where[] = "t.durum = ?";                             $params[] = $f_durum; }
if ($f_yil > 0) { $where[] = "YEAR(t.olusturma) = ?"; $params[] = $f_yil; }
if ($f_arama)   { $where[] = "(t.talep_no LIKE ? OR t.talep_eden_adi LIKE ? OR t.departman LIKE ?)";
                  $params[] = "%$f_arama%"; $params[] = "%$f_arama%"; $params[] = "%$f_arama%"; }

$q = $db->prepare("SELECT t.*,
    (SELECT COUNT(*) FROM satin_alma_kalemler WHERE talep_id=t.id) k_say,
    (SELECT COUNT(*) FROM satin_alma_kalemler WHERE talep_id=t.id AND kalem_durum='onaylandi') k_onay
    FROM satin_alma_talepler t
    WHERE " . implode(' AND ', $where) . "
    ORDER BY t.olusturma DESC");
$q->execute($params);
$talepler = $q->fetchAll();

// Özet sayaçlar
$ozet = ['bekliyor'=>0,'onayda'=>0,'teklifte'=>0,'siparisde'=>0,'kismi_tedarik'=>0,'tamamlandi'=>0,'reddedildi'=>0];
// Özet: yıl filtresinden bağımsız tüm açık talepler
try {
    $ozet_where = $is_yonetici ? "1=1" : "talep_eden_id=?";
    $ozet_params = $is_yonetici ? [] : [$uid];
    $ozet_q = $db->prepare("SELECT durum, COUNT(*) n FROM satin_alma_talepler WHERE $ozet_where GROUP BY durum");
    $ozet_q->execute($ozet_params);
    foreach ($ozet_q->fetchAll() as $oz) {
        if (isset($ozet[$oz['durum']])) $ozet[$oz['durum']] = (int)$oz['n'];
    }
} catch (Throwable $e) {
    foreach ($talepler as $t) {
        if (isset($ozet[$t['durum']])) $ozet[$t['durum']]++;
    }
}

$durum_cfg = [
    'bekliyor'      => ['bg'=>'#FEF9C3','renk'=>'#854D0E','etiket'=>'Bekliyor'],
    'onayda'        => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','etiket'=>'Onayda'],
    'reddedildi'    => ['bg'=>'#FEE2E2','renk'=>'#991B1B','etiket'=>'Reddedildi'],
    'teklifte'      => ['bg'=>'#FEF3C7','renk'=>'#92400E','etiket'=>'Teklif Aşaması'],
    'siparisde'     => ['bg'=>'#E0E7FF','renk'=>'#3730A3','etiket'=>'Siparişte'],
    'kismi_tedarik' => ['bg'=>'#D1FAE5','renk'=>'#065F46','etiket'=>'Kısmi Tedarik'],
    'tamamlandi'    => ['bg'=>'#D1FAE5','renk'=>'#065F46','etiket'=>'Tamamlandı'],
    'iptal'         => ['bg'=>'#F3F4F6','renk'=>'#6B7280','etiket'=>'İptal'],
];
$oncelik_cfg = [
    'dusuk'  => ['bg'=>'#F3F4F6','renk'=>'#6B7280','etiket'=>'Düşük'],
    'normal' => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','etiket'=>'Normal'],
    'yuksek' => ['bg'=>'#FEF3C7','renk'=>'#92400E','etiket'=>'Yüksek'],
    'acil'   => ['bg'=>'#FEE2E2','renk'=>'#991B1B','etiket'=>'ACİL'],
];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🛒 Satınalma Talepleri</h1>
    <div class="s-yol">İdari İşler / <b>Satınalma Talepleri</b></div>
  </div>
  <a href="?sayfa=idari-satin-yeni" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px;display:inline-flex;align-items:center;gap:6px">+ Yeni Talep</a>

  <button onclick="dtExcelIndir('tbl-satin_talepler','Satin_Talepler')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:16px">
  <?php
  $ozet_map = [
    ['key'=>'bekliyor',   'ikon'=>'⏳','etiket'=>'Bekliyor'],
    ['key'=>'onayda',     'ikon'=>'👁','etiket'=>'Onayda'],
    ['key'=>'teklifte',   'ikon'=>'📋','etiket'=>'Teklifte'],
    ['key'=>'siparisde',  'ikon'=>'📦','etiket'=>'Siparişte'],
    ['key'=>'kismi_tedarik','ikon'=>'🔄','etiket'=>'Kısmi'],
    ['key'=>'tamamlandi', 'ikon'=>'✅','etiket'=>'Tamamlandı'],
  ];
  foreach ($ozet_map as $o):
      $cfg = $durum_cfg[$o['key']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151'];
      $aktif_style = $f_durum===$o['key'] ? 'box-shadow:0 0 0 2px var(--t)' : '';
  ?>
  <a href="?sayfa=idari-satin-talepler&durum=<?php echo $o['key']; ?>&yil=<?php echo $f_yil; ?>"
     style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:14px;text-decoration:none;<?php echo $aktif_style; ?>">
    <div style="font-size:22px;margin-bottom:4px"><?php echo $o['ikon']; ?></div>
    <div style="font-size:24px;font-weight:800;color:<?php echo $cfg['renk']; ?>"><?php echo $ozet[$o['key']]; ?></div>
    <div style="font-size:12px;color:var(--m2)"><?php echo $o['etiket']; ?></div>
  </a>
  <?php endforeach; ?>
</div>

<!-- Filtre bar -->
<div class="kart" style="padding:12px 16px;margin-bottom:14px">
  <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <input type="hidden" name="sayfa" value="idari-satin-talepler">
    <input type="search" name="ara" value="<?php echo htmlspecialchars($f_arama); ?>"
           placeholder="🔍 Talep no, ad, departman..."
           style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px;width:220px">
    <select name="durum" style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
      <option value="">Tüm Durumlar</option>
      <?php foreach ($durum_cfg as $k => $d): ?>
      <option value="<?php echo $k; ?>" <?php echo $f_durum===$k?'selected':''; ?>><?php echo $d['etiket']; ?></option>
      <?php endforeach; ?>
    </select>
    <select name="yil" style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
      <option value="0" <?php echo $f_yil===0?'selected':''; ?>>Tüm Yıllar</option>
      <?php for ($y=date('Y')+1;$y>=2020;$y--): ?>
      <option value="<?php echo $y; ?>" <?php echo $f_yil===$y?'selected':''; ?>><?php echo $y; ?></option>
      <?php endfor; ?>
    </select>
    <button type="submit" style="background:var(--t);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">Filtrele</button>
    <?php if ($f_durum || $f_arama): ?>
    <a href="?sayfa=idari-satin-talepler&yil=<?php echo $f_yil; ?>" style="color:var(--m2);font-size:13px;text-decoration:none">Temizle ×</a>
    <?php endif; ?>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
  <div style="overflow-y:auto;max-height:calc(100vh - 320px)">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-satin_talepler" style="width:100%">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="width:130px">Talep No</th>
        <th>Talep Eden</th>
        <th>Departman</th>
        <th style="width:90px">Tür</th>
        <th style="width:80px">Öncelik</th>
        <th style="width:70px;text-align:center">Kalem</th>
        <th style="width:110px">Termin</th>
        <th style="width:130px">Tarih</th>
        <th style="width:120px">İlgili</th>
        <th style="width:130px">Durum</th>
        <th style="width:80px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($talepler)): ?>
      <tr><td colspan="11" style="text-align:center;padding:40px;color:var(--m2)">
        <?php echo $f_durum || $f_arama ? 'Filtre sonucu bulunamadı.' : 'Henüz satınalma talebi oluşturulmamış.'; ?>
      </td></tr>
      <?php else: ?>
      <?php foreach ($talepler as $t):
          $dc = $durum_cfg[$t['durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151','etiket'=>$t['durum']];
          $oc = $oncelik_cfg[$t['oncelik']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151','etiket'=>$t['oncelik']];
          $tur_etiket = $t['talep_turu']==='sarf_malzeme' ? '🧴 Sarf' : '🔧 Teknik';
          $acil_str   = $t['oncelik']==='acil' ? 'background:#FFF1F0' : '';
      ?>
      <tr style="cursor:pointer;<?php echo $acil_str; ?>" onclick="location.href='?sayfa=idari-satin-detay&id=<?php echo $t['id']; ?>'">
        <td>
          <span style="font-weight:800;color:var(--t);font-size:13px"><?php echo htmlspecialchars($t['talep_no']); ?></span>
        </td>
        <td>
          <div style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($t['talep_eden_adi']); ?></div>
        </td>
        <td style="font-size:13px;color:var(--m2)"><?php echo htmlspecialchars($t['departman'] ?? '—'); ?></td>
        <td><span style="font-size:12px"><?php echo $tur_etiket; ?></span></td>
        <td>
          <span style="background:<?php echo $oc['bg']; ?>;color:<?php echo $oc['renk']; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
            <?php echo $oc['etiket']; ?>
          </span>
        </td>
        <td style="text-align:center">
          <span style="font-size:13px;font-weight:700"><?php echo $t['k_say']; ?></span>
          <?php if ($t['k_onay'] > 0): ?>
          <span style="font-size:11px;color:#059669">(<?php echo $t['k_onay']; ?> onay)</span>
          <?php endif; ?>
        </td>
        <td style="font-size:13px;color:<?php echo ($t['termin_tarihi'] && $t['termin_tarihi'] < date('Y-m-d') && $t['durum']!=='tamamlandi') ? '#EF4444' : 'var(--m)'; ?>">
          <?php echo $t['termin_tarihi'] ? date('d.m.Y', strtotime($t['termin_tarihi'])) : '—'; ?>
        </td>
        <td style="font-size:12px;color:var(--m2)"><?php echo date('d.m.Y H:i', strtotime($t['olusturma'])); ?></td>
        <td style="font-size:12px">
          <?php if (!empty($t['takip_eden_adi'])): ?>
          <span style="color:#1D4ED8;font-weight:600"><?php echo htmlspecialchars($t['takip_eden_adi']); ?></span>
          <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
        </td>
        <td>
          <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px">
            <?php echo $dc['etiket']; ?>
          </span>
        </td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=idari-satin-detay&id=<?php echo $t['id']; ?>"
             style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;background:#EFF6FF;color:#1D4ED8;border-radius:6px;text-decoration:none;font-size:14px" title="Detay">👁</a>
          <?php if ($t['durum']==='bekliyor' && ($t['talep_eden_id']==$uid || $is_yonetici)): ?>
          <a href="?sayfa=idari-satin-yeni&id=<?php echo $t['id']; ?>"
             style="display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none;font-size:14px;margin-left:2px" title="Düzenle">✏️</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
  </div>

  <div style="padding:10px 16px;font-size:13px;color:var(--m2);border-top:1px solid var(--kenar);background:var(--bg)">
    Toplam: <strong><?php echo count($talepler); ?></strong> talep
  </div>
</div>

</div>
