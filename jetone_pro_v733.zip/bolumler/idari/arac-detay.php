<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<div class="s-bar"><div class="s-bas">Araç bulunamadı</div></div>'; return; }

$q = $db->prepare("SELECT a.*, CONCAT(p.ad,' ',p.soyad) sorumlu_adi FROM araclar a LEFT JOIN personeller p ON a.sorumlu_id=p.id WHERE a.id=?");
$q->execute([$id]); $a = $q->fetch();
if (!$a) { echo '<div class="s-bar"><div class="s-bas">Araç bulunamadı</div></div>'; return; }

// Son 5 bakım
$bakimlar = $db->prepare("SELECT * FROM arac_bakimlar WHERE arac_id=? ORDER BY tarih DESC LIMIT 5");
$bakimlar->execute([$id]); $bakimlar = $bakimlar->fetchAll();

// Son 10 yakıt
$yakitlar = $db->prepare("SELECT ay.*, CONCAT(p.ad,' ',p.soyad) surucu FROM arac_yakitlar ay LEFT JOIN personeller p ON ay.surucu_id=p.id WHERE ay.arac_id=? ORDER BY ay.tarih DESC LIMIT 10");
$yakitlar->execute([$id]); $yakitlar = $yakitlar->fetchAll();

// Aktif görevler
$gorevler = $db->prepare("SELECT ag.*, CONCAT(p.ad,' ',p.soyad) surucu FROM arac_gorevler ag LEFT JOIN personeller p ON ag.surucu_id=p.id WHERE ag.arac_id=? ORDER BY ag.baslangic DESC LIMIT 10");
$gorevler->execute([$id]); $gorevler = $gorevler->fetchAll();

// Personel listesi
$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();

$dc = ['aktif'=>['bg'=>'#D1FAE5','renk'=>'#065F46','et'=>'Aktif'],'bakim'=>['bg'=>'#FEF3C7','renk'=>'#92400E','et'=>'Bakımda'],'pasif'=>['bg'=>'#F3F4F6','renk'=>'#6B7280','et'=>'Pasif'],'hurda'=>['bg'=>'#FEE2E2','renk'=>'#991B1B','et'=>'Hurda']][$a['durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151','et'=>$a['durum']];

$bakim_tr = ['periyodik'=>'Periyodik','ariza'=>'Arıza','kaza'=>'Kaza','muayene'=>'Muayene','lastik'=>'Lastik','fren'=>'Fren','yag'=>'Yağ','diger'=>'Diğer'];
$gorev_tr = ['planli'=>'Planlandı','devam'=>'Devam Ediyor','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas" style="font-size:26px;letter-spacing:1px"><?php echo htmlspecialchars($a['plaka']); ?></h1>
    <div class="s-yol">İdari / <a href="?sayfa=idari-arac-listesi" style="color:var(--t);text-decoration:none">Araçlar</a> / <b><?php echo htmlspecialchars($a['plaka']); ?></b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px"><?php echo $dc['et']; ?></span>
    <a href="?sayfa=idari-arac-form&id=<?php echo $id; ?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">✏️ Düzenle</a>
    <a href="?sayfa=idari-arac-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Liste</a>
  </div>

  <button onclick="dtExcelIndir('tbl-arac_detay','Arac_Detay')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">

  <!-- Araç bilgileri -->
  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:14px">🚗 Araç Bilgileri</div>
    <?php
    $bilgiler = [
        'Marka / Model' => trim(($a['marka']??'').' '.($a['model']??'')),
        'Yıl' => $a['yil'] ?: '—',
        'Renk' => $a['renk'] ?: '—',
        'Araç Cinsi' => $a['cins'] ?: '—',
        'Yakıt' => ucfirst($a['yakit_tipi'] ?? '—'),
        'Güncel KM' => $a['km_guncel'] ? number_format($a['km_guncel']).' km' : '—',
        'Sorumlu' => $a['sorumlu_adi'] ?: '—',
        'Ruhsat Sahibi' => $a['ruhsat_sahibi'] ?: '—',
    ];
    foreach ($bilgiler as $k=>$v): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $k; ?></span>
      <span style="font-weight:600"><?php echo htmlspecialchars($v); ?></span>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Tarihler -->
  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:14px">📅 Önemli Tarihler</div>
    <?php
    $tarihler = ['muayene_bitis'=>'Muayene Bitiş','sigorta_bitis'=>'Sigorta Bitiş','kasko_bitis'=>'Kasko Bitiş','egzos_bitis'=>'Egzoz Bitiş'];
    $bugun = date('Y-m-d'); $uyari = date('Y-m-d',strtotime('+30 days'));
    foreach ($tarihler as $k=>$et):
        $val = $a[$k] ?? '';
        $renk = 'var(--m)';
        $badge = '';
        if ($val) {
            if ($val < $bugun) { $renk='#EF4444'; $badge='<span style="font-size:10px;background:#FEE2E2;color:#991B1B;padding:1px 6px;border-radius:10px;margin-left:4px">GEÇTİ</span>'; }
            elseif ($val <= $uyari) { $renk='#D97706'; $badge='<span style="font-size:10px;background:#FEF3C7;color:#92400E;padding:1px 6px;border-radius:10px;margin-left:4px">YAKLAŞIYOR</span>'; }
        }
    ?>
    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $et; ?></span>
      <div style="display:flex;align-items:center">
        <span style="font-weight:700;color:<?php echo $renk; ?>"><?php echo $val ? date('d.m.Y',strtotime($val)) : '—'; ?></span>
        <?php echo $badge; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if ($a['notlar']): ?>
    <div style="margin-top:12px;padding:10px;background:var(--bg);border-radius:8px;font-size:13px;color:var(--m2)"><?php echo nl2br(htmlspecialchars($a['notlar'])); ?></div>
    <?php endif; ?>
  </div>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;margin-bottom:12px">
  <?php foreach (['bakim'=>'🔧 Bakımlar','yakit'=>'⛽ Yakıt','gorev'=>'📍 Görevler'] as $sk=>$set): ?>
  <button onclick="sekmeAc('<?php echo $sk; ?>')" id="btn-<?php echo $sk; ?>"
    style="padding:8px 18px;border:1.5px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-size:13px;font-weight:600;background:var(--bg);color:var(--m2)">
    <?php echo $set; ?>
  </button>
  <?php endforeach; ?>
</div>

<!-- Bakım sekmesi -->
<div id="sekme-bakim" class="sekme-panel">
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
      <div class="kart-bas">Bakım Geçmişi</div>
      <button onclick="yeniBakim()" style="background:var(--t);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Bakım Ekle</button>
    </div>
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-arac_detay" style="width:100%">
      <thead><tr>
        <th>Tarih</th><th>Tür</th><th>KM</th><th>Servis</th><th>Yapılan İşler</th><th style="text-align:right">Tutar</th><th>Son. KM</th><th style="width:70px"></th>
      </tr></thead>
      <tbody>
        <?php if (empty($bakimlar)): ?>
        <tr><td colspan="7" style="text-align:center;padding:24px;color:var(--m2)">Bakım kaydı yok.</td></tr>
        <?php else: foreach ($bakimlar as $b): ?>
        <tr>
          <td><?php echo date('d.m.Y',strtotime($b['tarih'])); ?></td>
          <td><span style="background:#EDE9FE;color:#5B21B6;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $bakim_tr[$b['bakim_tipi']]??$b['bakim_tipi']; ?></span></td>
          <td><?php echo $b['km'] ? number_format($b['km']).' km' : '—'; ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($b['servis']??''); ?></td>
          <td style="font-size:12px;max-width:200px"><?php echo htmlspecialchars(mb_substr($b['yapilan_isler']??'',0,80)); ?></td>
          <td style="text-align:right;font-weight:700"><?php echo $b['tutar'] ? number_format($b['tutar'],2).' ₺' : '—'; ?></td>
          <td><?php echo $b['sonraki_bakim_km'] ? number_format($b['sonraki_bakim_km']).' km' : '—'; ?></td>
          <td><div style="display:flex;gap:3px">
            <button onclick="bakimDuzenle(<?php echo htmlspecialchars(json_encode($b,JSON_UNESCAPED_UNICODE)); ?>)" style="background:#EFF6FF;color:#1D4ED8;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">✏️</button>
            <button onclick="kayitSil('bakim',<?php echo $b['id']; ?>)" style="background:#FEE2E2;color:#EF4444;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">🗑</button>
          </div></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table></div>
</div>
</div>

<!-- Yakıt sekmesi -->
<div id="sekme-yakit" class="sekme-panel" style="display:none">
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
      <div class="kart-bas">Yakıt Takibi</div>
      <button onclick="yeniYakit()" style="background:var(--t);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Yakıt Ekle</button>
    </div>
    <table class="tablo" style="width:100%">
      <thead><tr><th>Tarih</th><th style="text-align:right">KM</th><th style="text-align:right">Litre</th><th style="text-align:right">Tutar</th><th style="text-align:right">₺/L</th><th>İstasyon</th><th>Sürücü</th><th style="width:70px"></th></tr></thead>
      <tbody>
        <?php if (empty($yakitlar)): ?>
        <tr><td colspan="7" style="text-align:center;padding:24px;color:var(--m2)">Yakıt kaydı yok.</td></tr>
        <?php else: foreach ($yakitlar as $y): ?>
        <tr>
          <td><?php echo date('d.m.Y',strtotime($y['tarih'])); ?></td>
          <td style="text-align:right;font-weight:600"><?php echo number_format($y['km']); ?></td>
          <td style="text-align:right"><?php echo number_format($y['litre'],2).' L'; ?></td>
          <td style="text-align:right;font-weight:700"><?php echo $y['tutar'] ? number_format($y['tutar'],2).' ₺' : '—'; ?></td>
          <td style="text-align:right;color:var(--m2);font-size:12px"><?php echo $y['birim_fiyat'] ? number_format($y['birim_fiyat'],3) : '—'; ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($y['istasyon']??''); ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($y['surucu']??''); ?></td>
          <td><div style="display:flex;gap:3px">
            <button onclick="yakitDuzenle(<?php echo htmlspecialchars(json_encode($y,JSON_UNESCAPED_UNICODE)); ?>)" style="background:#EFF6FF;color:#1D4ED8;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">✏️</button>
            <button onclick="kayitSil('yakit',<?php echo $y['id']; ?>)" style="background:#FEE2E2;color:#EF4444;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">🗑</button>
          </div></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Görev sekmesi -->
<div id="sekme-gorev" class="sekme-panel" style="display:none">
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
      <div class="kart-bas">Görevler / Seferler</div>
      <button onclick="yeniGorev()" style="background:var(--t);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Görev Ekle</button>
    </div>
    <table class="tablo" style="width:100%">
      <thead><tr><th>Başlangıç</th><th>Bitiş</th><th>Güzergah</th><th>Amaç</th><th style="text-align:right">KM</th><th>Sürücü</th><th>Durum</th><th style="width:70px"></th></tr></thead>
      <tbody>
        <?php if (empty($gorevler)): ?>
        <tr><td colspan="7" style="text-align:center;padding:24px;color:var(--m2)">Görev kaydı yok.</td></tr>
        <?php else: foreach ($gorevler as $g):
            $gdc = ['planli'=>['bg'=>'#DBEAFE','renk'=>'#1E40AF'],'devam'=>['bg'=>'#D1FAE5','renk'=>'#065F46'],'tamamlandi'=>['bg'=>'#F3F4F6','renk'=>'#374151'],'iptal'=>['bg'=>'#FEE2E2','renk'=>'#991B1B']][$g['durum']]??['bg'=>'#F3F4F6','renk'=>'#374151'];
        ?>
        <tr>
          <td style="font-size:13px"><?php echo date('d.m.Y H:i',strtotime($g['baslangic'])); ?></td>
          <td style="font-size:13px"><?php echo $g['bitis'] ? date('d.m.Y H:i',strtotime($g['bitis'])) : '—'; ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars(($g['kalkis_yeri']??'').' → '.($g['varis_yeri']??'')); ?></td>
          <td style="font-size:12px;max-width:160px"><?php echo htmlspecialchars(mb_substr($g['amac']??'',0,60)); ?></td>
          <td style="text-align:right;font-size:12px"><?php echo ($g['km_baslangic']&&$g['km_bitis']) ? number_format($g['km_bitis']-$g['km_baslangic']).' km' : '—'; ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($g['surucu']??''); ?></td>
          <td><span style="background:<?php echo $gdc['bg']; ?>;color:<?php echo $gdc['renk']; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $gorev_tr[$g['durum']]??$g['durum']; ?></span></td>
          <td><div style="display:flex;gap:3px">
            <button onclick="gorevDuzenle(<?php echo htmlspecialchars(json_encode($g,JSON_UNESCAPED_UNICODE)); ?>)" style="background:#EFF6FF;color:#1D4ED8;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">✏️</button>
            <button onclick="kayitSil('gorev',<?php echo $g['id']; ?>)" style="background:#FEE2E2;color:#EF4444;border:none;width:26px;height:26px;border-radius:5px;cursor:pointer;font-size:11px">🗑</button>
          </div></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>

<!-- Modal: Bakım Ekle -->
<div id="bakimModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:540px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 16px;font-size:16px">🔧 Bakım Kaydı Ekle</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div>
        <label class="form-etiket">Tür</label>
        <select class="form-alan" id="bTur">
          <?php foreach ($bakim_tr as $k=>$et): ?><option value="<?php echo $k; ?>"><?php echo $et; ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-etiket">Tarih</label><input type="date" class="form-alan" id="bTarih" value="<?php echo date('Y-m-d'); ?>"></div>
      <div><label class="form-etiket">KM</label><input type="number" class="form-alan" id="bKm" value="<?php echo $a['km_guncel']; ?>"></div>
      <div><label class="form-etiket">Tutar (₺)</label><input type="number" class="form-alan" id="bTutar" step="0.01"></div>
      <div><label class="form-etiket">Servis / Firma</label><input type="text" class="form-alan" id="bServis"></div>
      <div><label class="form-etiket">Sonraki Bakım KM</label><input type="number" class="form-alan" id="bSonrakiKm"></div>
      <div style="grid-column:1/3"><label class="form-etiket">Yapılan İşler</label><textarea class="form-alan" id="bIsler" rows="2"></textarea></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button onclick="document.getElementById('bakimModal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="bakimKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<!-- Modal: Yakıt Ekle -->
<div id="yakitModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:480px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 16px;font-size:16px">⛽ Yakıt Kaydı Ekle</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-etiket">Tarih</label><input type="date" class="form-alan" id="yTarih" value="<?php echo date('Y-m-d'); ?>"></div>
      <div><label class="form-etiket">KM</label><input type="number" class="form-alan" id="yKm" value="<?php echo $a['km_guncel']; ?>"></div>
      <div><label class="form-etiket">Litre</label><input type="number" class="form-alan" id="yLitre" step="0.01" oninput="yakitHesapla()"></div>
      <div><label class="form-etiket">Birim Fiyat (₺)</label><input type="number" class="form-alan" id="yBirimF" step="0.001" oninput="yakitHesapla()"></div>
      <div><label class="form-etiket">Tutar (₺)</label><input type="number" class="form-alan" id="yTutar" step="0.01"></div>
      <div><label class="form-etiket">İstasyon</label><input type="text" class="form-alan" id="yIstasyon"></div>
      <div style="grid-column:1/3">
        <label class="form-etiket">Sürücü</label>
        <select class="form-alan" id="ySurucu">
          <option value="">— Seçiniz —</option>
          <?php foreach ($personeller as $p): ?><option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option><?php endforeach; ?>
        </select>
      </div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button onclick="document.getElementById('yakitModal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="yakitKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<!-- Modal: Görev Ekle -->
<div id="gorevModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:520px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 16px;font-size:16px">📍 Görev / Sefer Ekle</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-etiket">Başlangıç</label><input type="datetime-local" class="form-alan" id="gBaslangic"></div>
      <div><label class="form-etiket">Bitiş</label><input type="datetime-local" class="form-alan" id="gBitis"></div>
      <div><label class="form-etiket">Kalkış Yeri</label><input type="text" class="form-alan" id="gKalkis"></div>
      <div><label class="form-etiket">Varış Yeri</label><input type="text" class="form-alan" id="gVaris"></div>
      <div><label class="form-etiket">KM Başlangıç</label><input type="number" class="form-alan" id="gKmBas" value="<?php echo $a['km_guncel']; ?>"></div>
      <div><label class="form-etiket">KM Bitiş</label><input type="number" class="form-alan" id="gKmBit"></div>
      <div>
        <label class="form-etiket">Sürücü</label>
        <select class="form-alan" id="gSurucu">
          <option value="">— Seçiniz —</option>
          <?php foreach ($personeller as $p): ?><option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-etiket">Durum</label>
        <select class="form-alan" id="gDurum">
          <?php foreach ($gorev_tr as $k=>$et): ?><option value="<?php echo $k; ?>"><?php echo $et; ?></option><?php endforeach; ?>
        </select>
      </div>
      <div style="grid-column:1/3"><label class="form-etiket">Amaç / Açıklama</label><textarea class="form-alan" id="gAmac" rows="2"></textarea></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button onclick="document.getElementById('gorevModal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="gorevKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<script>
var ARAC_ID = <?php echo $id; ?>;
var BASE = '<?php echo BASE_URL; ?>';

function sekmeAc(s) {
    document.querySelectorAll('.sekme-panel').forEach(function(el){ el.style.display='none'; });
    document.getElementById('sekme-'+s).style.display='block';
    document.querySelectorAll('[id^="btn-"]').forEach(function(b){
        b.style.background='var(--bg)'; b.style.color='var(--m2)'; b.style.borderColor='var(--kenar)';
    });
    var btn = document.getElementById('btn-'+s);
    btn.style.background='var(--t)'; btn.style.color='#fff'; btn.style.borderColor='var(--t)';
}
sekmeAc('bakim');

function yeniBakim()  {
  document.getElementById('bakimModal').dataset.editId = '';
  document.getElementById('bakimModal').querySelector('form')?.reset();
  document.getElementById('bakimModal').style.display='flex';
}
function bakimDuzenle(b) {
  var m = document.getElementById('bakimModal');
  m.dataset.editId = b.id;
  document.getElementById('bTur').value = b.bakim_tipi||'';
  document.getElementById('bTarih').value = b.tarih||'';
  document.getElementById('bKm').value = b.km||'';
  document.getElementById('bServis').value = b.servis||'';
  document.getElementById('bIsler').value = b.yapilan_isler||'';
  document.getElementById('bTutar').value = b.tutar||'';
  document.getElementById('bSonrakiKm').value = b.sonraki_bakim_km||'';
  m.style.display='flex';
}
function yakitDuzenle(y) {
  var m = document.getElementById('yakitModal');
  m.dataset.editId = y.id;
  document.getElementById('yTarih').value = y.tarih||'';
  document.getElementById('yKm').value = y.km||'';
  document.getElementById('yLitre').value = y.litre||'';
  document.getElementById('yTutar').value = y.tutar||'';
  document.getElementById('yIstasyon').value = y.istasyon||'';
  document.getElementById('ySurucu').value = y.surucu||'';
  m.style.display='flex';
}
function gorevDuzenle(g) {
  var m = document.getElementById('gorevModal');
  m.dataset.editId = g.id;
  document.getElementById('gBaslangic').value = (g.baslangic||'').substring(0,16);
  document.getElementById('gBitis').value = (g.bitis||'').substring(0,16);
  document.getElementById('gKalkis').value = g.kalkis_yeri||'';
  document.getElementById('gVaris').value = g.varis_yeri||'';
  document.getElementById('gAmac').value = g.amac||'';
  document.getElementById('gKmBas').value = g.km_baslangic||'';
  document.getElementById('gKmBit').value = g.km_bitis||'';
  document.getElementById('gDurum').value = g.durum||'planli';
  m.style.display='flex';
}
function kayitSil(tip, id) {
  if (!confirm('Bu kayıt silinsin mi?')) return;
  var urlMap = {bakim:'arac-bakim-kaydet',yakit:'arac-yakit-kaydet',gorev:'arac-gorev-kaydet'};
  var fd = new FormData();
  fd.append('islem','sil'); fd.append('id',id); fd.append('arac_id',ARAC_ID);
  fetch(BASE_URL+'/bolumler/idari/ajax/'+urlMap[tip]+'.php',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(r){if(r.ok)location.reload();else alert('Hata: '+(r.hata||'?'));});
}
function yeniBakim() {
  var m = document.getElementById('bakimModal');
  m.dataset.editId = '';
  m.querySelector('h3').textContent = '🔧 Bakım Kaydı Ekle';
  m.style.display='flex';
}
function yeniYakit() {
  var m = document.getElementById('yakitModal');
  m.dataset.editId = '';
  m.style.display='flex';
}
function yeniGorev() {
  var m = document.getElementById('gorevModal');
  m.dataset.editId = '';
  m.style.display='flex';
}

function yakitHesapla() {
    var l = parseFloat(document.getElementById('yLitre').value)||0;
    var f = parseFloat(document.getElementById('yBirimF').value)||0;
    if (l && f) document.getElementById('yTutar').value = (l*f).toFixed(2);
}

function post(url, data) {
    var fd = new FormData();
    for (var k in data) fd.append(k, data[k]||'');
    return fetch(BASE+url,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();});
}

function bakimKaydet() {
    var m = document.getElementById('bakimModal');
    var editId = m.dataset.editId||'';
    post('/bolumler/idari/ajax/arac-bakim-kaydet.php', {
        islem: editId ? 'guncelle' : 'ekle',
        id: editId,
        arac_id:ARAC_ID, bakim_tipi:document.getElementById('bTur').value,
        tarih:document.getElementById('bTarih').value, km:document.getElementById('bKm').value,
        tutar:document.getElementById('bTutar').value, servis:document.getElementById('bServis').value,
        sonraki_bakim_km:document.getElementById('bSonrakiKm').value,
        yapilan_isler:document.getElementById('bIsler').value
    }).then(function(r){ if(r.ok) location.reload(); else alert(r.hata||'?'); });
}

function yakitKaydet() {
    var m = document.getElementById('yakitModal');
    var editId = m.dataset.editId||'';
    post('/bolumler/idari/ajax/arac-yakit-kaydet.php', {
        islem: editId ? 'guncelle' : 'ekle',
        id: editId,
        arac_id:ARAC_ID, tarih:document.getElementById('yTarih').value,
        km:document.getElementById('yKm').value, litre:document.getElementById('yLitre').value,
        birim_fiyat:document.getElementById('yBirimF').value, tutar:document.getElementById('yTutar').value,
        istasyon:document.getElementById('yIstasyon').value, surucu_id:document.getElementById('ySurucu').value
    }).then(function(r){ if(r.ok) location.reload(); else alert(r.hata||'?'); });
}

function gorevKaydet() {
    var m = document.getElementById('gorevModal');
    var editId = m.dataset.editId||'';
    post('/bolumler/idari/ajax/arac-gorev-kaydet.php', {
        islem: editId ? 'guncelle' : 'ekle',
        id: editId,
        arac_id:ARAC_ID, baslangic:document.getElementById('gBaslangic').value,
        bitis:document.getElementById('gBitis').value, kalkis_yeri:document.getElementById('gKalkis').value,
        varis_yeri:document.getElementById('gVaris').value, km_baslangic:document.getElementById('gKmBas').value,
        km_bitis:document.getElementById('gKmBit').value, surucu_id:document.getElementById('gSurucu').value,
        durum:document.getElementById('gDurum').value, amac:document.getElementById('gAmac').value
    }).then(function(r){ if(r.ok) location.reload(); else alert(r.hata||'?'); });
}
</script>
