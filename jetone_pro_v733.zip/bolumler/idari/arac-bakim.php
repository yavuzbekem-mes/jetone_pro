<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kayitlar = $db->query("SELECT ab.*, a.plaka, a.marka FROM arac_bakimlar ab JOIN araclar a ON ab.arac_id=a.id ORDER BY ab.tarih DESC LIMIT 100")->fetchAll();
$bakim_tr = ['periyodik'=>'Periyodik','ariza'=>'Arıza','kaza'=>'Kaza','muayene'=>'Muayene','lastik'=>'Lastik','fren'=>'Fren','yag'=>'Yağ','diger'=>'Diğer'];
$toplam = array_sum(array_column($kayitlar,'tutar'));
?>
<div class="s-bar"><div><h1 class="s-bas">🔧 Bakım Kayıtları</h1><div class="s-yol">İdari / Araçlar / <b>Bakımlar</b></div></div>
  <button onclick="dtExcelIndir('tbl-arac_bakim','Arac_Bakim')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700">Toplam Kayıt</div><div style="font-size:22px;font-weight:800"><?php echo count($kayitlar); ?></div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700">Toplam Maliyet</div><div style="font-size:22px;font-weight:800;color:var(--t)"><?php echo number_format($toplam,2); ?> ₺</div></div>
</div>
<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto"><table class="tablo" id="tbl-arac_bakim" style="width:100%">
    <thead><tr><th>Tarih</th><th>Plaka</th><th>Tür</th><th style="text-align:right">KM</th><th>Servis</th><th>Yapılan İşler</th><th style="text-align:right">Tutar</th><th>Son. Bakım KM</th></tr></thead>
    <tbody>
      <?php foreach ($kayitlar as $k): ?>
      <tr>
        <td><?php echo date('d.m.Y',strtotime($k['tarih'])); ?></td>
        <td><a href="?sayfa=idari-arac-detay&id=<?php echo $k['arac_id']; ?>" style="font-weight:700;color:var(--t);text-decoration:none"><?php echo htmlspecialchars($k['plaka']); ?></a></td>
        <td><span style="background:#EDE9FE;color:#5B21B6;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $bakim_tr[$k['bakim_tipi']]??$k['bakim_tipi']; ?></span></td>
        <td style="text-align:right"><?php echo $k['km'] ? number_format($k['km']).' km' : '—'; ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($k['servis']??''); ?></td>
        <td style="font-size:12px;max-width:200px"><?php echo htmlspecialchars(mb_substr($k['yapilan_isler']??'',0,80)); ?></td>
        <td style="text-align:right;font-weight:700"><?php echo $k['tutar'] ? number_format($k['tutar'],2).' ₺' : '—'; ?></td>
        <td><?php echo $k['sonraki_bakim_km'] ? number_format($k['sonraki_bakim_km']).' km' : '—'; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
</div>
