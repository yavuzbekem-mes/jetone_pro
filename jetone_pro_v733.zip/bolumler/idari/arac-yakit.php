<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kayitlar = $db->query("SELECT ay.*, a.plaka, a.marka, a.model, CONCAT(p.ad,' ',p.soyad) surucu
    FROM arac_yakitlar ay JOIN araclar a ON ay.arac_id=a.id LEFT JOIN personeller p ON ay.surucu_id=p.id
    ORDER BY ay.tarih DESC LIMIT 100")->fetchAll();
$toplam_litre = array_sum(array_column($kayitlar,'litre'));
$toplam_tutar = array_sum(array_column($kayitlar,'tutar'));
?>
<div class="s-bar">
  <div><h1 class="s-bas">⛽ Yakıt Takibi</h1><div class="s-yol">İdari / Araçlar / <b>Yakıt</b></div></div>

  <button onclick="dtExcelIndir('tbl-arac_yakit','Arac_Yakit')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700">Toplam Kayıt</div><div style="font-size:22px;font-weight:800"><?php echo count($kayitlar); ?></div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700">Toplam Litre</div><div style="font-size:22px;font-weight:800"><?php echo number_format($toplam_litre,1); ?> L</div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700">Toplam Tutar</div><div style="font-size:22px;font-weight:800;color:var(--t)"><?php echo number_format($toplam_tutar,2); ?> ₺</div></div>
</div>
<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto"><table class="tablo" id="tbl-arac_yakit" style="width:100%">
    <thead><tr><th>Tarih</th><th>Plaka / Araç</th><th style="text-align:right">KM</th><th style="text-align:right">Litre</th><th style="text-align:right">₺/L</th><th style="text-align:right">Tutar</th><th>İstasyon</th><th>Sürücü</th></tr></thead>
    <tbody>
      <?php foreach ($kayitlar as $k): ?>
      <tr>
        <td><?php echo date('d.m.Y',strtotime($k['tarih'])); ?></td>
        <td><a href="?sayfa=idari-arac-detay&id=<?php echo $k['arac_id']; ?>" style="font-weight:700;color:var(--t);text-decoration:none"><?php echo htmlspecialchars($k['plaka']); ?></a><span style="font-size:12px;color:var(--m2);margin-left:6px"><?php echo htmlspecialchars(($k['marka']??'').' '.($k['model']??'')); ?></span></td>
        <td style="text-align:right;font-weight:600"><?php echo number_format($k['km']); ?></td>
        <td style="text-align:right"><?php echo number_format($k['litre'],2); ?> L</td>
        <td style="text-align:right;font-size:12px;color:var(--m2)"><?php echo $k['birim_fiyat'] ? number_format($k['birim_fiyat'],3) : '—'; ?></td>
        <td style="text-align:right;font-weight:700"><?php echo $k['tutar'] ? number_format($k['tutar'],2).' ₺' : '—'; ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($k['istasyon']??''); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($k['surucu']??''); ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
</div>
