<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

// Tablo yoksa oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `evraklar` (
        `id`              INT AUTO_INCREMENT PRIMARY KEY,
        `evrak_no`        VARCHAR(30) NOT NULL UNIQUE,
        `baslik`          VARCHAR(300) NOT NULL,
        `kategori`        VARCHAR(50) DEFAULT 'genel',
        `aciklama`        TEXT,
        `durum`           VARCHAR(30) DEFAULT 'bekliyor',
        `oncelik`         VARCHAR(20) DEFAULT 'normal',
        `ilgili_departman`VARCHAR(100) DEFAULT NULL,
        `ilgili_kisi`     VARCHAR(150) DEFAULT NULL,
        `son_tarih`          DATE DEFAULT NULL,
        `gecerlilik_tarihi`  DATE DEFAULT NULL,
        `hatirlatma_gun`     INT DEFAULT NULL COMMENT 'Kaç gün önce mail atılsın',
        `hatirlatma_gonderildi` TINYINT(1) DEFAULT 0,
        `dosya_adi`          VARCHAR(255) DEFAULT NULL,
        `dosya_yol`       VARCHAR(500) DEFAULT NULL,
        `dosya_boyut`     INT DEFAULT NULL,
        `dosya_tip`       VARCHAR(50) DEFAULT NULL,
        `etiketler`       VARCHAR(300) DEFAULT NULL,
        `notlar`          TEXT,
        `olusturan_id`    INT DEFAULT NULL,
        `olusturan_adi`   VARCHAR(150) DEFAULT NULL,
        `onaylayan_id`    INT DEFAULT NULL,
        `onaylayan_adi`   VARCHAR(150) DEFAULT NULL,
        `onay_tarihi`     DATETIME DEFAULT NULL,
        `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
        `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

// Filtreler
$f_durum   = $_GET['durum']    ?? '';
$f_kat     = $_GET['kategori'] ?? '';
$f_arama   = trim($_GET['arama'] ?? '');
$f_onc     = $_GET['oncelik']  ?? '';

$where = ['1=1'];
$params = [];
if ($f_durum)  { $where[] = "durum=?";     $params[] = $f_durum; }
if ($f_kat)    { $where[] = "kategori=?";  $params[] = $f_kat; }
if ($f_onc)    { $where[] = "oncelik=?";   $params[] = $f_onc; }
if ($f_arama)  { $where[] = "(baslik LIKE ? OR evrak_no LIKE ? OR ilgili_kisi LIKE ? OR etiketler LIKE ?)";
                 $params = array_merge($params, ["%$f_arama%","%$f_arama%","%$f_arama%","%$f_arama%"]); }

$evraklar = [];
$ozet = [];
try {
    $q = $db->prepare("SELECT * FROM evraklar WHERE " . implode(' AND ', $where) . " ORDER BY olusturma DESC");
    $q->execute($params);
    $evraklar = $q->fetchAll();

    $oz = $db->query("SELECT durum, COUNT(*) n FROM evraklar GROUP BY durum")->fetchAll();
    foreach ($oz as $o) $ozet[$o['durum']] = (int)$o['n'];
} catch(Throwable $e) {}

$departmanlar = [];
try { $departmanlar = $db->query("SELECT ad FROM departmanlar WHERE 1 ORDER BY ad")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e) {}

$durum_cfg = [
    'bekliyor'    => ['bg'=>'#FEF9C3','renk'=>'#854D0E','ikon'=>'⏳','et'=>'Bekliyor'],
    'inceleniyor' => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','ikon'=>'🔍','et'=>'İnceleniyor'],
    'onaylandi'   => ['bg'=>'#D1FAE5','renk'=>'#065F46','ikon'=>'✅','et'=>'Onaylandı'],
    'reddedildi'  => ['bg'=>'#FEE2E2','renk'=>'#991B1B','ikon'=>'❌','et'=>'Reddedildi'],
    'arsivlendi'  => ['bg'=>'#F3F4F6','renk'=>'#6B7280','ikon'=>'📦','et'=>'Arşivlendi'],
];
$kat_cfg = [
    'sozlesme'=>['ikon'=>'📄','et'=>'Sözleşme'],
    'fatura'  =>['ikon'=>'🧾','et'=>'Fatura'],
    'izin'    =>['ikon'=>'🏖','et'=>'İzin'],
    'resmi'   =>['ikon'=>'🏛','et'=>'Resmi Yazı'],
    'diger'   =>['ikon'=>'📎','et'=>'Diğer'],
    'genel'   =>['ikon'=>'📋','et'=>'Genel'],
];
$onc_cfg = [
    'dusuk'  =>['bg'=>'#F3F4F6','renk'=>'#6B7280','et'=>'Düşük'],
    'normal' =>['bg'=>'#DBEAFE','renk'=>'#1E40AF','et'=>'Normal'],
    'yuksek' =>['bg'=>'#FEF3C7','renk'=>'#92400E','et'=>'Yüksek'],
    'acil'   =>['bg'=>'#FEE2E2','renk'=>'#991B1B','et'=>'Acil'],
];

function fmt_boyut($b) {
    if (!$b) return '';
    if ($b < 1024) return $b.' B';
    if ($b < 1024*1024) return round($b/1024,1).' KB';
    return round($b/1024/1024,1).' MB';
}
?>
<div class="s-bar">
  <div><h1 class="s-bas">📋 Evrak Takibi</h1><div class="s-yol">İdari İşler / <b>Evraklar</b></div></div>
  <div style="display:flex;gap:8px">
    <button onclick="hatirlatmaGonder()" style="background:#FEF3C7;color:#92400E;border:1px solid #F59E0B;padding:10px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">📧 Hatırlatma Gönder</button>
    <button onclick="modalAc()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">+ Yeni Evrak</button>
  </div>

  <button onclick="dtExcelIndir('tbl-evrak','Evrak')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet kartlar -->
<div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
  <?php foreach($durum_cfg as $dk=>$dv): ?>
  <a href="?sayfa=idari-evrak&durum=<?php echo $dk; ?>" style="text-decoration:none;flex:1;min-width:120px">
    <div class="kart" style="padding:14px 16px;border-left:4px solid <?php echo $f_durum===$dk?'var(--t)':$dv['renk']; ?>">
      <div style="font-size:20px;font-weight:900;color:<?php echo $dv['renk']; ?>"><?php echo $ozet[$dk] ?? 0; ?></div>
      <div style="font-size:11px;font-weight:700;color:var(--m2)"><?php echo $dv['ikon'].' '.$dv['et']; ?></div>
    </div>
  </a>
  <?php endforeach; ?>
  <?php if ($f_durum): ?>
  <a href="?sayfa=idari-evrak" style="text-decoration:none;flex:1;min-width:100px">
    <div class="kart" style="padding:14px 16px;border-left:4px solid #9CA3AF">
      <div style="font-size:20px;font-weight:900;color:#9CA3AF"><?php echo array_sum($ozet); ?></div>
      <div style="font-size:11px;font-weight:700;color:var(--m2)">🔄 Tümü</div>
    </div>
  </a>
  <?php endif; ?>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px 16px;margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
  <input type="text" placeholder="🔍 Ara..." value="<?php echo htmlspecialchars($f_arama); ?>"
    oninput="aramaYap(this.value)" class="form-alan" style="width:180px;padding:7px 10px">
  <select onchange="filtreDegis('kategori',this.value)" class="form-alan" style="width:140px">
    <option value="">Tüm Kategoriler</option>
    <?php foreach($kat_cfg as $k=>$v): ?>
    <option value="<?php echo $k; ?>" <?php echo $f_kat===$k?'selected':''; ?>><?php echo $v['ikon'].' '.$v['et']; ?></option>
    <?php endforeach; ?>
  </select>
  <select onchange="filtreDegis('oncelik',this.value)" class="form-alan" style="width:130px">
    <option value="">Tüm Öncelikler</option>
    <?php foreach($onc_cfg as $k=>$v): ?>
    <option value="<?php echo $k; ?>" <?php echo $f_onc===$k?'selected':''; ?>><?php echo $v['et']; ?></option>
    <?php endforeach; ?>
  </select>
  <span style="font-size:12px;color:var(--m2);margin-left:auto"><?php echo count($evraklar); ?> evrak</span>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-evrak" id="evrakTable">
    <thead>
      <tr>
        <th style="width:130px">Evrak No</th>
        <th>Başlık</th>
        <th style="width:100px">Kategori</th>
        <th style="width:100px">Öncelik</th>
        <th style="width:120px">İlgili Kişi</th>
        <th style="width:100px">Son Tarih</th>
        <th style="width:105px">Geçerlilik</th>
        <th style="width:80px;text-align:center">Dosya</th>
        <th style="width:120px">Durum</th>
        <th style="width:90px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($evraklar)): ?>
    <tr><td colspan="10" style="text-align:center;padding:40px;color:var(--m2)">
      <?php echo $f_arama||$f_durum||$f_kat ? 'Sonuç bulunamadı.' : 'Henüz evrak eklenmemiş.'; ?>
    </td></tr>
    <?php else: foreach($evraklar as $e):
      $dc = $durum_cfg[$e['durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#6B7280','ikon'=>'?','et'=>$e['durum']];
      $kc = $kat_cfg[$e['kategori']] ?? ['ikon'=>'📎','et'=>$e['kategori']];
      $oc = $onc_cfg[$e['oncelik']] ?? ['bg'=>'#F3F4F6','renk'=>'#6B7280','et'=>$e['oncelik']];
      $gecmis = $e['son_tarih'] && $e['son_tarih'] < date('Y-m-d') && !in_array($e['durum'],['onaylandi','arsivlendi']);
    ?>
    <tr style="<?php echo $gecmis?'background:#FFF5F5':''; ?>">
      <td>
        <span style="font-weight:800;font-size:12px;color:var(--t)"><?php echo htmlspecialchars($e['evrak_no']); ?></span>
        <div style="font-size:10px;color:var(--m2)"><?php echo date('d.m.Y',strtotime($e['olusturma'])); ?></div>
      </td>
      <td>
        <div style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($e['baslik']); ?></div>
        <?php if ($e['aciklama']): ?>
        <div style="font-size:11px;color:var(--m2);margin-top:2px"><?php echo htmlspecialchars(mb_substr($e['aciklama'],0,60)).( mb_strlen($e['aciklama'])>60?'...':''); ?></div>
        <?php endif; ?>
        <?php if ($e['etiketler']): ?>
        <div style="margin-top:4px;display:flex;gap:4px;flex-wrap:wrap">
          <?php foreach(explode(',',$e['etiketler']) as $et): $et=trim($et); if(!$et) continue; ?>
          <span style="background:#EDE9FE;color:#5B21B6;font-size:10px;font-weight:600;padding:1px 6px;border-radius:10px">#<?php echo htmlspecialchars($et); ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </td>
      <td><span style="font-size:12px"><?php echo $kc['ikon'].' '.htmlspecialchars($kc['et']); ?></span></td>
      <td><span style="background:<?php echo $oc['bg']; ?>;color:<?php echo $oc['renk']; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $oc['et']; ?></span></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($e['ilgili_kisi']??'—'); ?></td>
      <td>
        <?php if ($e['son_tarih']): ?>
        <span style="font-size:12px;font-weight:600;color:<?php echo $gecmis?'#EF4444':'var(--m)'; ?>">
          <?php echo $gecmis?'⚠️ ':''; echo date('d.m.Y',strtotime($e['son_tarih'])); ?>
        </span>
        <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
      </td>
      <td>
        <?php
        $gec_tar = $e['gecerlilik_tarihi'] ?? null;
        $hat_gun = (int)($e['hatirlatma_gun'] ?? 0);
        $gec_gecmis = $gec_tar && $gec_tar < date('Y-m-d');
        $gec_yakin  = $gec_tar && !$gec_gecmis && $hat_gun &&
                      (strtotime($gec_tar) - time()) <= ($hat_gun * 86400);
        ?>
        <?php if ($gec_tar): ?>
        <span style="font-size:12px;font-weight:600;color:<?php echo $gec_gecmis?'#EF4444':($gec_yakin?'#F97316':'var(--m)'); ?>">
          <?php echo $gec_gecmis?'⛔ ':($gec_yakin?'⚠️ ':''); ?>
          <?php echo date('d.m.Y',strtotime($gec_tar)); ?>
        </span>
        <?php if ($hat_gun): ?>
        <div style="font-size:10px;color:var(--m2)"><?php echo $hat_gun; ?> gün önce hat.</div>
        <?php endif; ?>
        <?php else: ?><span style="color:var(--m3)">—</span><?php endif; ?>
      </td>
      <td style="text-align:center">
        <?php if ($e['dosya_yol']): ?>
        <a href="<?php echo BASE_URL.'/'.$e['dosya_yol']; ?>" target="_blank"
           style="display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;background:#EFF6FF;color:#1D4ED8;border-radius:6px;text-decoration:none;font-size:14px" title="<?php echo htmlspecialchars($e['dosya_adi']??''); ?> (<?php echo fmt_boyut($e['dosya_boyut']); ?>)">📎</a>
        <?php else: ?><span style="color:var(--m3);font-size:12px">—</span><?php endif; ?>
      </td>
      <td>
        <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
          <?php echo $dc['ikon'].' '.$dc['et']; ?>
        </span>
      </td>
      <td style="text-align:center">
        <div style="display:flex;gap:3px;justify-content:center">
          <button onclick="duzenle(<?php echo htmlspecialchars(json_encode($e,JSON_UNESCAPED_UNICODE)); ?>)"
            style="background:#FEF3C7;color:#92400E;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:13px" title="Düzenle">✏️</button>
          <?php if ($e['durum']==='bekliyor'||$e['durum']==='inceleniyor'): ?>
          <button onclick="durumDegis(<?php echo $e['id']; ?>,'onaylandi')"
            style="background:#D1FAE5;color:#065F46;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:13px" title="Onayla">✅</button>
          <?php endif; ?>
          <button onclick="sil(<?php echo $e['id']; ?>,'<?php echo addslashes($e['baslik']); ?>')"
            style="background:#FEE2E2;color:#EF4444;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:13px" title="Sil">🗑</button>
        </div>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
</div>

<!-- Hatırlatma Sonuç Modalı -->
<div id="hatirlatmaModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1001;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.96);backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:520px;max-height:85vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
      <div style="font-size:15px;font-weight:800">📧 Hatırlatma Sonucu</div>
      <button onclick="document.getElementById('hatirlatmaModal').style.display='none'" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:30px;height:30px;cursor:pointer">✕</button>
    </div>
    <div id="hatirlatmaSonuc"></div>
  </div>
</div>

<!-- Modal -->
<div id="evrakModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.95);backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:580px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px">
      <div style="font-size:16px;font-weight:800" id="modalBaslik">📋 Yeni Evrak</div>
      <button onclick="modalKapat()" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:32px;height:32px;cursor:pointer;font-size:16px">✕</button>
    </div>
    <form id="evrakForm" enctype="multipart/form-data">
      <input type="hidden" id="evrakId" name="id" value="">
      <input type="hidden" id="evrakIslem" name="islem" value="ekle">

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
        <div style="grid-column:1/-1">
          <label class="form-etiket">Başlık *</label>
          <input type="text" name="baslik" id="fBaslik" class="form-alan" required placeholder="Evrak başlığı">
        </div>
        <div>
          <label class="form-etiket">Kategori</label>
          <select name="kategori" id="fKategori" class="form-alan">
            <option value="genel">📋 Genel</option>
            <option value="sozlesme">📄 Sözleşme</option>
            <option value="fatura">🧾 Fatura</option>
            <option value="izin">🏖 İzin</option>
            <option value="resmi">🏛 Resmi Yazı</option>
            <option value="diger">📎 Diğer</option>
          </select>
        </div>
        <div>
          <label class="form-etiket">Öncelik</label>
          <select name="oncelik" id="fOncelik" class="form-alan">
            <option value="dusuk">Düşük</option>
            <option value="normal" selected>Normal</option>
            <option value="yuksek">Yüksek</option>
            <option value="acil">🚨 Acil</option>
          </select>
        </div>
        <div>
          <label class="form-etiket">Durum</label>
          <select name="durum" id="fDurum" class="form-alan">
            <option value="bekliyor">⏳ Bekliyor</option>
            <option value="inceleniyor">🔍 İnceleniyor</option>
            <option value="onaylandi">✅ Onaylandı</option>
            <option value="reddedildi">❌ Reddedildi</option>
            <option value="arsivlendi">📦 Arşivlendi</option>
          </select>
        </div>
        <div>
          <label class="form-etiket">Son Tarih</label>
          <input type="date" name="son_tarih" id="fSonTarih" class="form-alan">
        </div>
        <div>
          <label class="form-etiket">Geçerlilik Tarihi</label>
          <input type="date" name="gecerlilik_tarihi" id="fGecTarih" class="form-alan">
        </div>
        <div>
          <label class="form-etiket">Hatırlatma <span style="font-size:11px;color:var(--m2)">(gün önce)</span></label>
          <select name="hatirlatma_gun" id="fHatir" class="form-alan">
            <option value="">— Yok —</option>
            <option value="7">7 gün önce</option>
            <option value="14">14 gün önce</option>
            <option value="30">30 gün önce</option>
            <option value="60">60 gün önce</option>
            <option value="90">90 gün önce</option>
          </select>
        </div>
        <div>
          <label class="form-etiket">İlgili Departman</label>
          <select name="ilgili_departman" id="fDept" class="form-alan">
            <option value="">— Seçin —</option>
            <?php foreach ($departmanlar as $d): ?>
            <option value="<?php echo htmlspecialchars($d); ?>"><?php echo htmlspecialchars($d); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="form-etiket">İlgili Kişi</label>
          <input type="text" name="ilgili_kisi" id="fKisi" class="form-alan" placeholder="Ad Soyad">
        </div>
        <div style="grid-column:1/-1">
          <label class="form-etiket">Açıklama</label>
          <textarea name="aciklama" id="fAck" class="form-alan" rows="2" style="resize:none" placeholder="Kısa açıklama..."></textarea>
        </div>
        <div style="grid-column:1/-1">
          <label class="form-etiket">Etiketler <span style="font-size:11px;color:var(--m2)">(virgülle ayırın)</span></label>
          <input type="text" name="etiketler" id="fEtiket" class="form-alan" placeholder="sözleşme, 2026, tedarikçi">
        </div>
        <div style="grid-column:1/-1">
          <label class="form-etiket">Dosya Yükle <span style="font-size:11px;color:var(--m2)">(PDF, DOC, XLS, JPG, ZIP — max 20MB)</span></label>
          <input type="file" name="dosya" id="fDosya" class="form-alan" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.zip,.rar">
          <div id="mevcutDosya" style="font-size:11px;color:var(--m2);margin-top:4px"></div>
        </div>
        <div style="grid-column:1/-1">
          <label class="form-etiket">Notlar</label>
          <textarea name="notlar" id="fNotlar" class="form-alan" rows="2" style="resize:none" placeholder="Ek notlar..."></textarea>
        </div>
      </div>

      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px">
        <button type="button" onclick="modalKapat()" style="padding:10px 20px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
        <button type="button" onclick="kaydet()" id="kaydetBtn" style="padding:10px 24px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script>
var AJAX = '<?php echo BASE_URL; ?>/bolumler/idari/ajax/evrak-kaydet.php';

function filtreDegis(key, val) {
    var url = new URL(location.href);
    if (val) url.searchParams.set(key, val); else url.searchParams.delete(key);
    location.href = url.toString();
}
var _aramaTimer;
function aramaYap(val) {
    clearTimeout(_aramaTimer);
    _aramaTimer = setTimeout(function(){ filtreDegis('arama', val); }, 400);
}

function modalAc() {
    document.getElementById('evrakForm').reset();
    document.getElementById('evrakId').value = '';
    document.getElementById('evrakIslem').value = 'ekle';
    document.getElementById('modalBaslik').textContent = '📋 Yeni Evrak';
    document.getElementById('mevcutDosya').textContent = '';
    document.getElementById('evrakModal').style.display = 'flex';
}
function modalKapat() {
    document.getElementById('evrakModal').style.display = 'none';
}
function duzenle(e) {
    document.getElementById('evrakId').value = e.id;
    document.getElementById('evrakIslem').value = 'guncelle';
    document.getElementById('modalBaslik').textContent = '✏️ Evrak Düzenle: ' + e.evrak_no;
    document.getElementById('fBaslik').value   = e.baslik || '';
    document.getElementById('fKategori').value = e.kategori || 'genel';
    document.getElementById('fOncelik').value  = e.oncelik || 'normal';
    document.getElementById('fDurum').value    = e.durum || 'bekliyor';
    document.getElementById('fSonTarih').value = e.son_tarih || '';
    document.getElementById('fDept').value     = e.ilgili_departman || '';
    document.getElementById('fKisi').value     = e.ilgili_kisi || '';
    document.getElementById('fAck').value      = e.aciklama || '';
    document.getElementById('fEtiket').value   = e.etiketler || '';
    document.getElementById('fNotlar').value   = e.notlar || '';
    document.getElementById('fGecTarih').value  = e.gecerlilik_tarihi || '';
    document.getElementById('fHatir').value     = e.hatirlatma_gun || '';
    if (e.dosya_adi) document.getElementById('mevcutDosya').textContent = 'Mevcut: ' + e.dosya_adi;
    document.getElementById('evrakModal').style.display = 'flex';
}
function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    var fd = new FormData(document.getElementById('evrakForm'));
    fetch(AJAX, {method:'POST', body:fd, credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(r){
        if (r.ok) { location.reload(); }
        else { alert('Hata: '+(r.hata||'?')); btn.disabled=false; btn.textContent='💾 Kaydet'; }
    }).catch(function(){ alert('Bağlantı hatası'); btn.disabled=false; btn.textContent='💾 Kaydet'; });
}
function durumDegis(id, durum) {
    if (!confirm('Durum "'+durum+'" olarak güncellensin mi?')) return;
    var fd = new FormData();
    fd.append('islem','durum'); fd.append('id',id); fd.append('durum',durum);
    fetch(AJAX, {method:'POST', body:fd, credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(r){ if(r.ok) location.reload(); else alert('Hata: '+(r.hata||'?')); });
}
function hatirlatmaGonder() {
    if (!confirm('Geçerlilik tarihi yaklaşan evraklar için hatırlatma maili gönderilsin mi?')) return;
    var btn = document.querySelector('[onclick="hatirlatmaGonder()"]');
    if (btn) { btn.disabled=true; btn.textContent='Gönderiliyor...'; }
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/evrak-hatirlatma.php', {credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(r){
        if (btn) { btn.disabled=false; btn.textContent='📧 Hatırlatma Gönder'; }
        if (r.ok) {
            var html = '<div style="background:#D1FAE5;color:#065F46;padding:12px;border-radius:8px;font-weight:700;margin-bottom:14px">✅ ' + r.mesaj + '</div>';
            // Alıcılar
            html += '<div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px">📬 MAİL ALICILARI (' + (r.alici_detay ? r.alici_detay.length : 0) + ' KİŞİ)</div>';
            if (r.alici_detay && r.alici_detay.length) {
                html += '<div style="border:1px solid var(--kenar);border-radius:8px;overflow:hidden;margin-bottom:14px">';
                r.alici_detay.forEach(function(a, i) {
                    html += '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;' + (i%2===0?'background:var(--bg)':'') + '">';
                    html += '<div style="width:32px;height:32px;border-radius:50%;background:#DBEAFE;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0">👤</div>';
                    html += '<div><div style="font-size:13px;font-weight:600">' + a.isim + '</div>';
                    html += '<div style="font-size:11px;color:var(--m2)">' + a.dept + ' · ' + a.email + '</div></div></div>';
                });
                html += '</div>';
            } else {
                html += '<div style="color:var(--m2);font-size:13px;margin-bottom:14px">Alıcı bulunamadı</div>';
            }
            // Evraklar
            if (r.evraklar && r.evraklar.length) {
                html += '<div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px">📋 HATIRLATMA GÖNDERİLEN EVRAKLAR</div>';
                html += '<div style="border:1px solid var(--kenar);border-radius:8px;overflow:hidden">';
                r.evraklar.forEach(function(e, i) {
                    html += '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;' + (i%2===0?'background:var(--bg)':'') + '">';
                    html += '<div><div style="font-size:12px;font-weight:700;color:var(--t)">' + e.evrak_no + '</div>';
                    html += '<div style="font-size:12px">' + e.baslik + '</div></div>';
                    html += '<span style="background:#FEF3C7;color:#92400E;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">' + e.kalan_gun + ' gün</span></div>';
                });
                html += '</div>';
            }
            document.getElementById('hatirlatmaSonuc').innerHTML = html;
            document.getElementById('hatirlatmaModal').style.display = 'flex';
        } else { alert('Hata: '+(r.hata||'?')); }
    }).catch(function(){
        if (btn) { btn.disabled=false; btn.textContent='📧 Hatırlatma Gönder'; }
        alert('Bağlantı hatası');
    });
}
function sil(id, baslik) {
    if (!confirm('"'+baslik+'" silinsin mi?')) return;
    var fd = new FormData();
    fd.append('islem','sil'); fd.append('id',id);
    fetch(AJAX, {method:'POST', body:fd, credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(r){ if(r.ok) location.reload(); else alert('Hata: '+(r.hata||'?')); });
}
</script>
