<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$sozlesmeler = $db->query("SELECT * FROM sozlesmeler ORDER BY olusturma DESC LIMIT 100")->fetchAll();
$durum_cfg = ['taslak'=>['#F3F4F6','#6B7280','Taslak'],'aktif'=>['#D1FAE5','#065F46','Aktif'],'suresi_doldu'=>['#FEE2E2','#991B1B','Süresi Doldu'],'feshedildi'=>['#FEE2E2','#991B1B','Feshedildi'],'yenilendi'=>['#DBEAFE','#1E40AF','Yenilendi']];
$tip_tr = ['tedarik'=>'Tedarik','hizmet'=>'Hizmet','kira'=>'Kira','is'=>'İş','diger'=>'Diğer'];
$uyari_limit = date('Y-m-d',strtotime('+30 days')); $bugun=date('Y-m-d');
?>
<div class="s-bar">
  <div><h1 class="s-bas">📄 Sözleşmeler</h1><div class="s-yol">İdari / Teklif & Sözleşme / <b>Sözleşmeler</b></div></div>
  <a href="?sayfa=idari-sozlesme-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Sözleşme</a>

  <button onclick="dtExcelIndir('tbl-sozlesme_listesi','Sozlesme_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto"><table class="tablo" id="tbl-sozlesme_listesi" style="width:100%">
    <thead><tr><th>Sözleşme No</th><th>Tip</th><th>Konu</th><th>Taraf</th><th>Başlangıç</th><th>Bitiş</th><th style="text-align:right">Tutar</th><th>Durum</th><th style="text-align:center">İşlem</th></tr></thead>
    <tbody>
      <?php if (empty($sozlesmeler)): ?><tr><td colspan="9" style="text-align:center;padding:40px;color:var(--m2)">Henüz sözleşme eklenmemiş.</td></tr>
      <?php else: foreach ($sozlesmeler as $s):
        $dc=$durum_cfg[$s['durum']]??['#F3F4F6','#374151','?'];
        $yaklasıyor = $s['bitis'] && $s['bitis']>=$bugun && $s['bitis']<=$uyari_limit;
        $gecti = $s['bitis'] && $s['bitis']<$bugun && $s['durum']==='aktif';
      ?>
      <tr style="cursor:pointer<?php echo $gecti?' background:#FFF1F0':($yaklasıyor?' background:#FFFBEB':''); ?>" onclick="location.href='?sayfa=idari-sozlesme-detay&id=<?php echo $s['id']; ?>'">
        <td style="font-weight:800;color:var(--t)"><?php echo htmlspecialchars($s['sozlesme_no']); ?></td>
        <td style="font-size:12px"><?php echo $tip_tr[$s['tip']]??$s['tip']; ?></td>
        <td style="font-weight:600"><?php echo htmlspecialchars(mb_substr($s['konu'],0,60)); ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($s['taraf_adi']); ?></td>
        <td style="font-size:13px"><?php echo $s['baslangic']?date('d.m.Y',strtotime($s['baslangic'])):'—'; ?></td>
        <td style="color:<?php echo $gecti?'#EF4444':($yaklasıyor?'#D97706':'var(--m)'); ?>;font-size:13px;font-weight:<?php echo ($gecti||$yaklasıyor)?'700':'400'; ?>">
          <?php echo $s['bitis']?date('d.m.Y',strtotime($s['bitis'])):'—'; ?>
          <?php echo $gecti?'⚠️':($yaklasıyor?'⏳':''); ?>
        </td>
        <td style="text-align:right;font-weight:700"><?php echo $s['tutar']?number_format($s['tutar'],2).' ₺':'—'; ?></td>
        <td><span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $dc[2]; ?></span></td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=idari-sozlesme-form&id=<?php echo $s['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none">✏️</a>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
</div>
