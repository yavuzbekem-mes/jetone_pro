<?php
/**
 * Satınalma Talebi Detay & Onay Sayfası
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$user   = Auth::kullanici();
$uid    = (int)$user['id'];
$rol_id = (int)($user['rol_id'] ?? 0);

// Sistem rolü kontrolü
$is_sistem = 0;
try {
    $sr2 = $db->prepare("SELECT sistem_rol FROM roller WHERE id=? LIMIT 1");
    $sr2->execute([$rol_id]);
    $is_sistem = (int)($sr2->fetchColumn() ?: 0);
} catch (Throwable $e) {}
if ($rol_id === 1) $is_sistem = 1; // ilk rol her zaman süper admin

// Kullanıcının bağlı olduğu departmanı bul
try {
    $dept_row = $db->prepare(
        "SELECT d.ad FROM personeller p
         JOIN departmanlar d ON p.departman_id = d.id
         WHERE p.kullanici_id = ? AND p.durum = 'aktif' LIMIT 1"
    );
    $dept_row->execute([$uid]);
    $user_dept = $dept_row->fetchColumn() ?: '';
} catch (Throwable $e) { $user_dept = ''; }

// Onay yetkisi:
// 1. Sistem rolü olan (Süper Admin, Yönetici = sistem_rol=1)
// 2. Satınalma departmanı çalışanı
// 3. İdari İşler departmanı çalışanı
$is_satin_dept = (stripos($user_dept, 'satın') !== false || stripos($user_dept, 'satin') !== false);
$is_idari_dept = (stripos($user_dept, 'idari') !== false);
$is_yonetici   = ($is_sistem === 1) || $is_satin_dept || $is_idari_dept;

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<div class="s-bar"><div class="s-bas">Talep bulunamadı</div></div>'; return; }

$q = $db->prepare("SELECT t.* FROM satin_alma_talepler t WHERE t.id = ?");
$q->execute([$id]); $talep = $q->fetch();
if (!$talep) { echo '<div class="s-bar"><div class="s-bas">Talep bulunamadı</div></div>'; return; }

// Kalemler
$kq = $db->prepare("SELECT * FROM satin_alma_kalemler WHERE talep_id=? ORDER BY sira_no");
$kq->execute([$id]); $kalemler = $kq->fetchAll();

// Takip kişisi: sadece Satınalma ve İdari İşler departmanı personeli
$kullanicilar_list = [];
$idari_sorumlu = null;
try {
    $kullanicilar_list = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, d.ad dept_adi,
            p.pozisyon, p.unvan
        FROM personeller p
        JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif' AND (
            d.ad LIKE '%Satınalma%' OR d.ad LIKE '%Satin%' OR d.ad LIKE '%Satın%'
            OR d.ad LIKE '%İdari%'  OR d.ad LIKE '%Idari%'
            OR p.pozisyon LIKE '%Satınalma%' OR p.pozisyon LIKE '%Satin%'
            OR p.unvan LIKE '%Satınalma%'    OR p.unvan LIKE '%İdari%'
        )
        ORDER BY d.ad, p.ad")->fetchAll();

    // Fallback: hiç bulunamazsa tüm aktif kullanıcılar
    if (empty($kullanicilar_list)) {
        $kullanicilar_list = $db->query("SELECT id, ad_soyad FROM kullanicilar WHERE aktif=1 ORDER BY ad_soyad")->fetchAll();
    }

    // Varsayılan: İdari > Satınalma müdürü sıralamasıyla ilk kişi
    $idari_sorumlu = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad
        FROM personeller p
        JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif' AND (d.ad LIKE '%İdari%' OR d.ad LIKE '%Idari%'
            OR p.pozisyon LIKE '%İdari%Sorumlu%' OR p.unvan LIKE '%İdari%')
        ORDER BY CASE WHEN p.pozisyon LIKE '%Sorumlu%' OR p.unvan LIKE '%Sorumlu%' THEN 0 ELSE 1 END
        LIMIT 1")->fetch() ?: null;

    if (!$idari_sorumlu && !empty($kullanicilar_list)) {
        $idari_sorumlu = $kullanicilar_list[0];
    }
} catch(Throwable $e) {}

// Geçmiş
$gq = $db->prepare("SELECT * FROM satin_alma_gecmis WHERE talep_id=? ORDER BY olusturma DESC");
$gq->execute([$id]); $gecmis = $gq->fetchAll();

// Mail log
$mq = $db->prepare("SELECT * FROM satin_alma_mail_log WHERE talep_id=? ORDER BY olusturma DESC LIMIT 10");
$mq->execute([$id]); $mail_log = $mq->fetchAll();

$durum_cfg = [
    'bekliyor'      => ['bg'=>'#FEF9C3','renk'=>'#854D0E','etiket'=>'Bekliyor','ikon'=>'⏳'],
    'onayda'        => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','etiket'=>'Onay Aşamasında','ikon'=>'👁'],
    'reddedildi'    => ['bg'=>'#FEE2E2','renk'=>'#991B1B','etiket'=>'Reddedildi','ikon'=>'❌'],
    'teklifte'      => ['bg'=>'#FEF3C7','renk'=>'#92400E','etiket'=>'Teklif Toplanıyor','ikon'=>'📋'],
    'siparisde'     => ['bg'=>'#E0E7FF','renk'=>'#3730A3','etiket'=>'Siparişte','ikon'=>'📦'],
    'kismi_tedarik' => ['bg'=>'#D1FAE5','renk'=>'#065F46','etiket'=>'Kısmi Tedarik','ikon'=>'🔄'],
    'tamamlandi'    => ['bg'=>'#D1FAE5','renk'=>'#065F46','etiket'=>'Tamamlandı','ikon'=>'✅'],
    'iptal'         => ['bg'=>'#F3F4F6','renk'=>'#6B7280','etiket'=>'İptal','ikon'=>'🚫'],
];
$dc = $durum_cfg[$talep['durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151','etiket'=>$talep['durum'],'ikon'=>'•'];
$oncelik_tr = ['dusuk'=>'Düşük','normal'=>'Normal','yuksek'=>'Yüksek','acil'=>'ACİL'];
$tur_tr = ['sarf_malzeme'=>'🧴 Sarf Malzeme','teknik_satin_alma'=>'🔧 Teknik Satınalma'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo htmlspecialchars($talep['talep_no']); ?></h1>
    <div class="s-yol">İdari İşler / Satınalma /
      <a href="?sayfa=idari-satin-talepler" style="color:var(--t);text-decoration:none">Talepler</a> /
      <b><?php echo htmlspecialchars($talep['talep_no']); ?></b>
    </div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px">
      <?php echo $dc['ikon'].' '.$dc['etiket']; ?>
    </span>
    <a href="?sayfa=idari-satin-talepler" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Listele</a>
  </div>
</div>

<div class="s-body" style="display:grid;grid-template-columns:1fr 340px;gap:16px;align-items:start">

<!-- SOL: Ana içerik -->
<div>

  <!-- Talep özet bilgileri -->
  <div class="kart" style="margin-bottom:14px;padding:18px 20px">
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px 20px">
      <?php
      $bilgiler = [
        'Talep Eden'   => htmlspecialchars($talep['talep_eden_adi']),
        'Departman'    => htmlspecialchars($talep['departman'] ?? '—'),
        'Talep Türü'   => $tur_tr[$talep['talep_turu']] ?? $talep['talep_turu'],
        'Öncelik'      => '<span style="background:'.($talep['oncelik']==='acil'?'#FEE2E2':'#DBEAFE').';color:'.($talep['oncelik']==='acil'?'#991B1B':'#1E40AF').';padding:2px 8px;border-radius:20px;font-size:12px;font-weight:700">'.($oncelik_tr[$talep['oncelik']]??$talep['oncelik']).'</span>',
        'Termin'       => $talep['termin_tarihi'] ? date('d.m.Y',strtotime($talep['termin_tarihi'])) : '—',
        'Oluşturma'    => date('d.m.Y H:i',strtotime($talep['olusturma'])),
        'Toplam Kalem' => count($kalemler) . ' adet',
        'Toplam Miktar'=> number_format($talep['toplam_miktar'],0),
        'İlgili Kişi'  => !empty($talep['takip_eden_adi']) ? '<span style="color:#1D4ED8;font-weight:700">'.htmlspecialchars($talep['takip_eden_adi']).'</span>' : '—',
      ];
      foreach ($bilgiler as $k => $v): ?>
      <div>
        <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:3px"><?php echo $k; ?></div>
        <div style="font-size:14px;font-weight:600"><?php echo $v; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php if ($talep['aciklama']): ?>
    <div style="margin-top:14px;padding:12px;background:var(--bg);border-radius:8px;font-size:13px">
      <strong>Açıklama:</strong> <?php echo nl2br(htmlspecialchars($talep['aciklama'])); ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Kalemler tablosu -->
  <div class="kart" style="overflow:hidden;margin-bottom:14px">
    <div class="kart-ust" style="display:flex;align-items:center;justify-content:space-between">
      <div class="kart-bas">Talep Kalemleri</div>
      <?php if ($is_yonetici && $talep['durum']==='bekliyor'): ?>
      <button onclick="topluOnayla()" style="background:#059669;color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">✅ Tümünü Onayla</button>
      <?php endif; ?>
    </div>
    <div style="overflow-x:auto">
    <table class="tablo" id="tbl-satin_talep_detay" style="width:100%">
      <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
        <tr>
          <th style="width:44px;text-align:center">#</th>
          <th style="width:90px">Kod</th>
          <th>Ürün / Malzeme</th>
          <th style="width:120px">Marka</th>
          <th style="width:90px;text-align:right">Miktar</th>
          <th style="width:70px">Birim</th>
          <th>Kullanım Yeri</th>
          <th style="width:110px;text-align:center">Durum</th>
          <?php if ($is_yonetici && in_array($talep['durum'],['bekliyor','onayda'])): ?>
          <th style="width:100px;text-align:center">İşlem</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($kalemler as $k):
            $kdc = ['bekliyor'=>['bg'=>'#FEF9C3','renk'=>'#854D0E','et'=>'Bekliyor'],
                    'onaylandi'=>['bg'=>'#D1FAE5','renk'=>'#065F46','et'=>'Onaylandı'],
                    'reddedildi'=>['bg'=>'#FEE2E2','renk'=>'#991B1B','et'=>'Reddedildi'],
                    'tedarik_edildi'=>['bg'=>'#D1FAE5','renk'=>'#065F46','et'=>'Tedarik Edildi']][$k['kalem_durum']]
                  ?? ['bg'=>'#F3F4F6','renk'=>'#374151','et'=>$k['kalem_durum']];
        ?>
        <tr id="kalem-<?php echo $k['id']; ?>" style="background:<?php echo $kdc['bg']; ?>33">
          <td style="text-align:center;font-weight:700;color:var(--m2)"><?php echo $k['sira_no']; ?></td>
          <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($k['urun_kodu']??''); ?></td>
          <td style="font-weight:700"><?php echo htmlspecialchars($k['urun_adi']); ?></td>
          <td style="font-size:13px"><?php echo htmlspecialchars($k['marka']??''); ?></td>
          <td style="text-align:right;font-weight:700"><?php echo number_format($k['miktar'],0); ?></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($k['birim']); ?></td>
          <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($k['aciklama']??''); ?></td>
          <td style="text-align:center">
            <span style="background:<?php echo $kdc['bg']; ?>;color:<?php echo $kdc['renk']; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">
              <?php echo $kdc['et']; ?>
            </span>
          </td>
          <?php if ($is_yonetici && in_array($talep['durum'],['bekliyor','onayda'])): ?>
          <td style="text-align:center">
            <div style="display:flex;gap:3px;justify-content:center">
              <?php if ($k['kalem_durum']==='bekliyor'): ?>
              <button onclick="kalemOnayla(<?php echo $k['id']; ?>)" style="background:#D1FAE5;color:#065F46;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:700">✓</button>
              <button onclick="kalemReddet(<?php echo $k['id']; ?>)" style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:700">✕</button>
              <?php else: ?>
              <button onclick="kalemSifirla(<?php echo $k['id']; ?>)" style="background:#F3F4F6;color:#6B7280;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px">↩</button>
              <?php endif; ?>
            </div>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>

  <!-- Geçmiş -->
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust"><div class="kart-bas">📋 İşlem Geçmişi</div></div>
    <div style="padding:4px 0">
      <?php if (empty($gecmis)): ?>
      <p style="text-align:center;color:var(--m2);padding:16px">Geçmiş kaydı yok.</p>
      <?php else: ?>
      <?php foreach ($gecmis as $g):
          $gc = $durum_cfg[$g['yeni_durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#374151','etiket'=>$g['yeni_durum']];
      ?>
      <div style="display:flex;gap:12px;align-items:flex-start;padding:10px 16px;border-bottom:1px solid var(--kenar)">
        <div style="width:8px;height:8px;border-radius:50%;background:<?php echo $gc['renk']; ?>;margin-top:5px;flex-shrink:0"></div>
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
            <span style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($g['kullanici_adi']??'Sistem'); ?></span>
            <span style="background:<?php echo $gc['bg']; ?>;color:<?php echo $gc['renk']; ?>;font-size:11px;font-weight:700;padding:1px 8px;border-radius:20px">
              <?php echo $gc['etiket'] ?? $g['yeni_durum']; ?>
            </span>
            <span style="font-size:11px;color:var(--m2)"><?php echo date('d.m.Y H:i',strtotime($g['olusturma'])); ?></span>
          </div>
          <?php if ($g['not_metni']): ?>
          <div style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($g['not_metni']); ?></div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- SAĞ: Aksiyon paneli -->
<div>

  <?php if ($is_yonetici && in_array($talep['durum'],['bekliyor','onayda','teklifte','siparisde','kismi_tedarik'])): ?>
  <div class="kart" style="padding:16px;margin-bottom:14px">
    <div class="kart-bas" style="margin-bottom:14px">⚡ Durum Güncelle</div>

    <div style="margin-bottom:12px">
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">Not (isteğe bağlı)</label>
      <textarea id="aksiyonNot" class="form-alan" rows="3" placeholder="Onay notu, ret gerekçesi..."
                style="resize:none;font-size:13px"></textarea>
    </div>

    <?php if ($talep['durum']==='bekliyor'): ?>
    <?php
    // Kalem durumlarına bak
    $k_onay = count(array_filter($kalemler, function($k){ return $k['kalem_durum']==='onaylandi'; }));
    $k_red  = count(array_filter($kalemler, function($k){ return $k['kalem_durum']==='reddedildi'; }));
    $k_top  = count($kalemler);
    $k_bek  = $k_top - $k_onay - $k_red;
    // Durum tespiti
    $onay_label  = '';
    $onay_durum  = 'onayda';
    $onay_renk   = '#1D4ED8';
    if ($k_red > 0 && $k_onay > 0) {
        $onay_label = "✅ Kısmi Onay ({$k_onay} onaylı / {$k_red} reddedildi)";
        $onay_durum = 'onayda';
        $onay_renk  = '#0891B2';
    } elseif ($k_red > 0 && $k_onay === 0) {
        $onay_label = "❌ Reddet ({$k_red} kalem reddedildi)";
        $onay_durum = 'reddedildi';
        $onay_renk  = '#EF4444';
    } elseif ($k_onay === $k_top && $k_top > 0) {
        $onay_label = "✅ Tümünü Onayla ({$k_top} kalem)";
        $onay_durum = 'onayda';
        $onay_renk  = '#059669';
    } else {
        $onay_label = "👁 Onaya Al";
        $onay_durum = 'onayda';
        $onay_renk  = '#1D4ED8';
    }
    ?>
    <div style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;padding:10px 12px;font-size:12px;margin-bottom:12px">
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <span style="color:#059669;font-weight:700">✓ <?php echo $k_onay; ?> Onaylı</span>
        <span style="color:#EF4444;font-weight:700">✗ <?php echo $k_red; ?> Reddedildi</span>
        <span style="color:var(--m2)">⏳ <?php echo $k_bek; ?> Bekliyor</span>
      </div>
    </div>
    <button onclick="onayModalAc('<?php echo $onay_durum; ?>','<?php echo addslashes($onay_label); ?>')"
            style="width:100%;background:<?php echo $onay_renk; ?>;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px;margin-bottom:8px">
      <?php echo $onay_label; ?>
    </button>
    <?php if ($onay_durum !== 'reddedildi'): ?>
    <button onclick="durumGuncelle('reddedildi',null,true)" style="width:100%;background:#EF4444;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px">
      ❌ Tamamen Reddet
    </button>
    <?php endif; ?>
    <?php endif; ?>

    <?php if ($talep['durum']==='onayda'): ?>
    <button onclick="durumGuncelle('teklifte')" style="width:100%;background:#D97706;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px;margin-bottom:8px">
      📋 Teklif Toplanıyor
    </button>
    <button onclick="durumGuncelle('reddedildi',null,true)" style="width:100%;background:#EF4444;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px">
      ❌ Reddet
    </button>
    <?php endif; ?>

    <?php if ($talep['durum']==='teklifte'): ?>
    <button onclick="durumGuncelle('siparisde')" style="width:100%;background:#4F46E5;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px;margin-bottom:8px">
      📦 Sipariş Oluşturuldu
    </button>
    <?php endif; ?>

    <?php if ($talep['durum']==='siparisde'): ?>
    <button onclick="durumGuncelle('kismi_tedarik')" style="width:100%;background:#0891B2;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px;margin-bottom:8px">
      🔄 Kısmi Tedarik
    </button>
    <button onclick="durumGuncelle('tamamlandi')" style="width:100%;background:#059669;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px">
      ✅ Tamamlandı
    </button>
    <?php endif; ?>

    <?php if ($talep['durum']==='kismi_tedarik'): ?>
    <button onclick="durumGuncelle('tamamlandi')" style="width:100%;background:#059669;color:#fff;border:none;padding:10px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:14px">
      ✅ Tamamlandı
    </button>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Mail log -->
  <?php if (!empty($mail_log)): ?>
  <div class="kart" style="padding:14px">
    <div class="kart-bas" style="margin-bottom:10px">📧 Mail Geçmişi</div>
    <?php foreach ($mail_log as $ml): ?>
    <div style="display:flex;align-items:flex-start;gap:8px;padding:7px 0;border-bottom:1px solid var(--kenar);font-size:12px">
      <span><?php echo $ml['durum']==='gonderildi'?'✅':'❌'; ?></span>
      <div>
        <div style="font-weight:600"><?php echo htmlspecialchars($ml['konu']); ?></div>
        <div style="color:var(--m2)"><?php echo htmlspecialchars($ml['alici']); ?></div>
        <div style="color:var(--m2)"><?php echo date('d.m.Y H:i',strtotime($ml['olusturma'])); ?></div>
        <?php if ($ml['hata_mesaji']): ?>
        <div style="color:#EF4444"><?php echo htmlspecialchars($ml['hata_mesaji']); ?></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>
</div>

<!-- Onay Modalı -->
<div id="onayModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
  <div style="background:rgba(255,255,255,0.92);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:460px;box-shadow:0 20px 60px rgba(0,0,0,.2);border:1px solid rgba(255,255,255,.6)">
    <div style="font-size:16px;font-weight:800;margin-bottom:16px" id="onayModalBaslik">Onayla</div>
    <div style="margin-bottom:12px">
      <label style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;display:block;margin-bottom:5px">Takip Edecek Kişi *</label>
      <select id="takipKisi" class="form-alan">
        <option value="">— Seçin —</option>
        <?php foreach ($kullanicilar_list as $ku): ?>
        <option value="<?php echo $ku['id']; ?>" data-adi="<?php echo htmlspecialchars($ku['ad_soyad']); ?>"
          <?php if ($idari_sorumlu && $idari_sorumlu['id']==$ku['id']) echo 'selected'; ?>>
          <?php echo htmlspecialchars($ku['ad_soyad']); ?>
        </option>
        <?php endforeach; ?>
      </select>
      <?php if ($idari_sorumlu): ?>
      <div style="font-size:11px;color:var(--m2);margin-top:4px">İdari işler sorumlusu otomatik seçildi: <b><?php echo htmlspecialchars($idari_sorumlu['ad_soyad']); ?></b></div>
      <?php endif; ?>
    </div>
    <div style="margin-bottom:16px">
      <label style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;display:block;margin-bottom:5px">Not (isteğe bağlı)</label>
      <textarea id="onayNot" class="form-alan" rows="2" placeholder="Onay notu..." style="resize:none"></textarea>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button type="button" onclick="document.getElementById('onayModal').style.display='none'" style="padding:10px 20px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
      <button type="button" onclick="onayOnayla()" id="onayBtn" style="padding:10px 20px;background:#059669;color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">✅ Onayla</button>
    </div>
  </div>
</div>

<script>
var TALEP_ID = <?php echo $id; ?>;
var BASE = '<?php echo BASE_URL; ?>';

var _onayDurum = '';
function onayModalAc(durum, etiket) {
    _onayDurum = durum;
    document.getElementById('onayModalBaslik').textContent = etiket || 'Onayla';
    document.getElementById('onayNot').value = document.getElementById('aksiyonNot').value.trim();
    document.getElementById('onayModal').style.display = 'flex';
}
function onayOnayla() {
    var takipSel = document.getElementById('takipKisi');
    var takipId  = takipSel.value;
    var takipAdi = takipSel.options[takipSel.selectedIndex]?.dataset?.adi || '';
    var not = document.getElementById('onayNot').value.trim();
    if (!takipId) { alert('Lütfen takip edecek kişiyi seçin.'); return; }
    document.getElementById('onayBtn').disabled = true;
    document.getElementById('onayBtn').textContent = 'Kaydediliyor...';
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/satin-durum-guncelle.php', {
        method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({talep_id: TALEP_ID, durum: _onayDurum, not: not,
                              takip_eden_id: takipId, takip_eden_adi: takipAdi})
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else { alert('Hata: '+(r.hata||'?')); document.getElementById('onayBtn').disabled=false; document.getElementById('onayBtn').textContent='✅ Onayla'; }
    });
}
function durumGuncelle(yeniDurum, varsayilanNot, redMi) {
    var not = document.getElementById('aksiyonNot').value.trim();
    if (redMi && !not) { alert('Red gerekçesi giriniz.'); document.getElementById('aksiyonNot').focus(); return; }
    if (!confirm('Durum "' + yeniDurum + '" olarak güncellensin mi?')) return;
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/satin-durum-guncelle.php', {
        method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({talep_id: TALEP_ID, durum: yeniDurum, not: not || varsayilanNot || ''})
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert('Hata: '+(r.hata||'?'));
    });
}

function kalemOnayla(kid) {
    kalemDurum(kid,'onaylandi');
}
function kalemReddet(kid) {
    kalemDurum(kid,'reddedildi');
}
function kalemSifirla(kid) {
    kalemDurum(kid,'bekliyor');
}

function kalemDurum(kid, durum) {
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/satin-kalem-durum.php', {
        method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({kalem_id: kid, durum: durum, talep_id: TALEP_ID})
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert('Hata: '+(r.hata||'?'));
    });
}

function topluOnayla() {
    if (!confirm('Tüm kalemler onaylansın mı?')) return;
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/satin-kalem-durum.php', {
        method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({talep_id: TALEP_ID, toplu: true, durum: 'onaylandi'})
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert('Hata: '+(r.hata||'?'));
    });
}
</script>
