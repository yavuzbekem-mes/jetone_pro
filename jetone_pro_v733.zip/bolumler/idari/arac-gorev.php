<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$gorevler = $db->query("SELECT ag.*, a.plaka, CONCAT(p.ad,' ',p.soyad) surucu FROM arac_gorevler ag JOIN araclar a ON ag.arac_id=a.id LEFT JOIN personeller p ON ag.surucu_id=p.id ORDER BY ag.baslangic DESC LIMIT 100")->fetchAll();
$gorev_tr = ['planli'=>'Planlandı','devam'=>'Devam Ediyor','tamamlandi'=>'Tamamlandı','iptal'=>'İptal'];
$toplam_km = 0;
foreach ($gorevler as $g) if ($g['km_baslangic']&&$g['km_bitis']) $toplam_km += $g['km_bitis']-$g['km_baslangic'];
?>
<div class="s-bar"><div><h1 class="s-bas">📍 Görevler / Seferler</h1><div class="s-yol">İdari / Araçlar / <b>Görevler</b></div></div>
  <button onclick="dtExcelIndir('tbl-arac_gorev','Arac_Gorev')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Tüm Araç Görevleri <span style="font-size:13px;color:var(--m2)">(toplam <?php echo number_format($toplam_km); ?> km)</span></div></div>
  <div style="overflow-x:auto"><table class="tablo" id="tbl-arac_gorev" style="width:100%">
    <thead><tr><th>Başlangıç</th><th>Bitiş</th><th>Plaka</th><th>Güzergah</th><th>Amaç</th><th style="text-align:right">KM</th><th>Sürücü</th><th>Durum</th></tr></thead>
    <tbody>
      <?php foreach ($gorevler as $g):
        $dc = ['planli'=>['#DBEAFE','#1E40AF'],'devam'=>['#D1FAE5','#065F46'],'tamamlandi'=>['#F3F4F6','#374151'],'iptal'=>['#FEE2E2','#991B1B']][$g['durum']]??['#F3F4F6','#374151'];
      ?>
      <tr>
        <td style="font-size:13px"><?php echo date('d.m.Y H:i',strtotime($g['baslangic'])); ?></td>
        <td style="font-size:13px"><?php echo $g['bitis']?date('d.m.Y H:i',strtotime($g['bitis'])):'—'; ?></td>
        <td><a href="?sayfa=idari-arac-detay&id=<?php echo $g['arac_id']; ?>" style="font-weight:700;color:var(--t);text-decoration:none"><?php echo htmlspecialchars($g['plaka']); ?></a></td>
        <td style="font-size:12px"><?php echo htmlspecialchars(($g['kalkis_yeri']??'').' → '.($g['varis_yeri']??'')); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars(mb_substr($g['amac']??'',0,50)); ?></td>
        <td style="text-align:right;font-size:12px"><?php echo ($g['km_baslangic']&&$g['km_bitis'])?number_format($g['km_bitis']-$g['km_baslangic']).' km':'—'; ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($g['surucu']??''); ?></td>
        <td><span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $gorev_tr[$g['durum']]??$g['durum']; ?></span></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
</div>
