<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$teklifler = $db->query("SELECT t.*, (SELECT COUNT(*) FROM teklif_kalemleri WHERE teklif_id=t.id) k_say FROM teklifler t ORDER BY t.olusturma DESC LIMIT 100")->fetchAll();
$durum_cfg = ['taslak'=>['#F3F4F6','#6B7280','Taslak'],'gonderildi'=>['#DBEAFE','#1E40AF','Gönderildi'],'kabul'=>['#D1FAE5','#065F46','Kabul'],'red'=>['#FEE2E2','#991B1B','Reddedildi'],'revize'=>['#FEF3C7','#92400E','Revize'],'suresi_doldu'=>['#F3F4F6','#6B7280','Süresi Doldu']];
$tip_cfg = ['alinan'=>['#EDE9FE','#5B21B6','Alınan'],'verilen'=>['#FEF3C7','#92400E','Verilen']];
?>
<div class="s-bar">
  <div><h1 class="s-bas">📋 Teklifler</h1><div class="s-yol">İdari / Teklif & Sözleşme / <b>Teklifler</b></div></div>
  <a href="?sayfa=idari-teklif-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Teklif</a>

  <button onclick="dtExcelIndir('tbl-teklif_listesi','Teklif_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto"><table class="tablo" id="tbl-teklif_listesi" style="width:100%">
    <thead><tr><th>Teklif No</th><th>Tip</th><th>Konu</th><th>Tedarikçi</th><th>Geçerlilik</th><th style="text-align:right">Tutar</th><th>Kalem</th><th>Durum</th><th style="text-align:center">İşlem</th></tr></thead>
    <tbody>
      <?php if (empty($teklifler)): ?><tr><td colspan="9" style="text-align:center;padding:40px;color:var(--m2)">Henüz teklif eklenmemiş.</td></tr>
      <?php else: foreach ($teklifler as $t):
        $dc=$durum_cfg[$t['durum']]??['#F3F4F6','#374151','?'];
        $tc=$tip_cfg[$t['tip']]??['#F3F4F6','#374151','?'];
        $gecti = $t['gecerlilik_tarihi'] && $t['gecerlilik_tarihi']<date('Y-m-d');
      ?>
      <tr style="cursor:pointer" onclick="location.href='?sayfa=idari-teklif-detay&id=<?php echo $t['id']; ?>'">
        <td style="font-weight:800;color:var(--t)"><?php echo htmlspecialchars($t['teklif_no']); ?></td>
        <td><span style="background:<?php echo $tc[0]; ?>;color:<?php echo $tc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $tc[2]; ?></span></td>
        <td style="font-weight:600"><?php echo htmlspecialchars(mb_substr($t['konu'],0,60)); ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($t['tedarikci_adi']??'—'); ?></td>
        <td style="color:<?php echo $gecti?'#EF4444':'var(--m)'; ?>;font-size:13px"><?php echo $t['gecerlilik_tarihi']?date('d.m.Y',strtotime($t['gecerlilik_tarihi'])):'—'; ?></td>
        <td style="text-align:right;font-weight:700"><?php echo $t['toplam_tutar']?number_format($t['toplam_tutar'],2).' ₺':'—'; ?></td>
        <td style="text-align:center"><?php echo $t['k_say']; ?></td>
        <td><span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $dc[2]; ?></span></td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=idari-teklif-form&id=<?php echo $t['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none">✏️</a>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
</div>
