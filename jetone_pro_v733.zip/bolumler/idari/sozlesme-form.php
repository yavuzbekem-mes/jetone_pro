<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
$s = null;
if ($id) {
    $q = $db->prepare("SELECT * FROM sozlesmeler WHERE id=? LIMIT 1");
    $q->execute([$id]); $s = $q->fetch();
}
// Teklifler (baglanabilmesi icin)
$teklifler = $db->query("SELECT id, teklif_no, konu FROM teklifler ORDER BY olusturma DESC LIMIT 50")->fetchAll();
$v = function($k,$d='') use ($s) { return htmlspecialchars($s[$k] ?? $d); };
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Sozlesme Duzenle' : 'Yeni Sozlesme'; ?></h1>
    <div class="s-yol">Idari / <a href="?sayfa=idari-sozlesme-listesi" style="color:var(--t);text-decoration:none">Sozlesmeler</a> / <b><?php echo $id ? $v('sozlesme_no') : 'Yeni'; ?></b></div>
  </div>
  <a href="?sayfa=idari-sozlesme-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Geri</a>
</div>

<div class="s-body">
<form id="sozForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">Sozlesme Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">

    <div>
      <label class="form-etiket">Sozlesme Tipi</label>
      <select class="form-alan" name="tip">
        <?php foreach (['tedarik'=>'Tedarik','hizmet'=>'Hizmet','kira'=>'Kira','is'=>'Is Sozlesmesi','diger'=>'Diger'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($s['tip']??'tedarik')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Durum</label>
      <select class="form-alan" name="durum">
        <?php foreach (['taslak'=>'Taslak','aktif'=>'Aktif','suresi_doldu'=>'Suresi Doldu','feshedildi'=>'Feshedildi','yenilendi'=>'Yenilendi'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($s['durum']??'taslak')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Para Birimi</label>
      <select class="form-alan" name="para_birimi">
        <option value="TRY" <?php echo ($s['para_birimi']??'TRY')==='TRY'?'selected':''; ?>>TRY</option>
        <option value="USD" <?php echo ($s['para_birimi']??'')==='USD'?'selected':''; ?>>USD</option>
        <option value="EUR" <?php echo ($s['para_birimi']??'')==='EUR'?'selected':''; ?>>EUR</option>
      </select>
    </div>
    <div>
      <label class="form-etiket">Ilgili Teklif</label>
      <select class="form-alan" name="teklif_id">
        <option value="">— Secmiyorum —</option>
        <?php foreach ($teklifler as $tk): ?>
        <option value="<?php echo $tk['id']; ?>" <?php echo ($s['teklif_id']??'')==$tk['id']?'selected':''; ?>><?php echo htmlspecialchars($tk['teklif_no'].' — '.mb_substr($tk['konu'],0,40)); ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="grid-column:1/5">
      <label class="form-etiket">Konu <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="konu" value="<?php echo $v('konu'); ?>" required>
    </div>

    <div style="grid-column:1/3">
      <label class="form-etiket">Taraf / Firma Adi <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="taraf_adi" value="<?php echo $v('taraf_adi'); ?>" required>
    </div>
    <div>
      <label class="form-etiket">E-posta</label>
      <input type="email" class="form-alan" name="taraf_email" value="<?php echo $v('taraf_email'); ?>">
    </div>
    <div>
      <label class="form-etiket">Sozlesme Tutari</label>
      <input type="number" class="form-alan" name="tutar" value="<?php echo $v('tutar'); ?>" step="0.01">
    </div>

    <div>
      <label class="form-etiket">Baslangic Tarihi</label>
      <input type="date" class="form-alan" name="baslangic" value="<?php echo $v('baslangic'); ?>">
    </div>
    <div>
      <label class="form-etiket">Bitis Tarihi</label>
      <input type="date" class="form-alan" name="bitis" value="<?php echo $v('bitis'); ?>">
    </div>
    <div>
      <label class="form-etiket">Sure (Ay)</label>
      <input type="number" class="form-alan" name="sure_ay" value="<?php echo $v('sure_ay'); ?>" min="1">
    </div>
    <div>
      <label class="form-etiket">Hatirlat. (gun oncesi)</label>
      <input type="number" class="form-alan" name="hatirlatma_gun" value="<?php echo $v('hatirlatma_gun','30'); ?>" min="1" max="180">
    </div>

    <div>
      <label class="form-etiket">Otomatik Yenileme</label>
      <select class="form-alan" name="yenileme">
        <option value="0" <?php echo !($s['yenileme']??0)?'selected':''; ?>>Hayir</option>
        <option value="1" <?php echo ($s['yenileme']??0)?'selected':''; ?>>Evet</option>
      </select>
    </div>
  </div>
</div>

<div class="kart" style="padding:16px 20px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start">
    <div>
      <label class="form-etiket">Notlar</label>
      <textarea class="form-alan" name="notlar" rows="3"><?php echo $v('notlar'); ?></textarea>
    </div>
    <div style="padding-top:22px">
      <button type="button" onclick="kaydet()" id="kaydetBtn"
        style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit;white-space:nowrap">
        Kaydet
      </button>
    </div>
  </div>
</div>
</form>
</div>

<script>
function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    var fd = new FormData(document.getElementById('sozForm'));
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/sozlesme-kaydet.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled = false; btn.textContent = 'Kaydet';
        if (r.ok) { location.href = '?sayfa=idari-sozlesme-detay&id='+r.id; }
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){ btn.disabled=false; btn.textContent='Kaydet'; alert('Baglanti hatasi'); });
}
</script>
