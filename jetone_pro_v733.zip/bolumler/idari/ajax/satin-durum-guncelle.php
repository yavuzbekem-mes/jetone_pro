<?php
// Tüm output'u yakala - PHP hata mesajları JSON'u bozmasın
ob_start();
@ini_set('display_errors', 0);
@ini_set('log_errors', 1);
@error_reporting(0);

try {
    require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
    require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
    require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
} catch (Throwable $boot_err) {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'hata'=>'Sistem hatasi: '.$boot_err->getMessage()]);
    exit;
}
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
$user   = Auth::kullanici();
$uid_c  = (int)($user['id'] ?? 0);
$rol_id_c = (int)($user['rol_id'] ?? 0);

// Yetki kontrolü — çok katmanlı
$yetkili = false;
try {
    $sis = $db->prepare("SELECT sistem_rol FROM roller WHERE id=? LIMIT 1");
    $sis->execute([$rol_id_c]);
    $is_sis = (int)($sis->fetchColumn() ?: 0);
    if ($rol_id_c <= 2) $is_sis = 1;
    if ($is_sis === 1) { $yetkili = true; }

    if (!$yetkili) {
        $per_q = $db->prepare("SELECT d.ad dept, p.pozisyon, p.unvan FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.kullanici_id=? AND p.durum='aktif' LIMIT 1");
        $per_q->execute([$uid_c]);
        $per = $per_q->fetch();
        if ($per) {
            $dn = $per['dept'] ?? '';
            $pn = ($per['pozisyon'] ?? '') . ' ' . ($per['unvan'] ?? '');
            $yetkili = stripos($dn,'satın')!==false || stripos($dn,'satin')!==false
                    || stripos($dn,'idari')!==false
                    || stripos($pn,'müdür')!==false || stripos($pn,'mudur')!==false
                    || stripos($pn,'sorumlu')!==false;
        }
    }
    if (!$yetkili && $rol_id_c <= 3) $yetkili = true;
} catch (Throwable $e) { $yetkili = ($rol_id_c <= 3); }
if (!$yetkili) { echo json_encode(['ok'=>false,'hata'=>'Yetkisiz islem']); exit; }
$uid  = (int)$user['id'];
$u_adi = trim(($user['ad']??'').' '.($user['soyad']??''));

$d = json_decode(file_get_contents('php://input'), true) ?: [];
$talep_id  = (int)($d['talep_id'] ?? 0);
$yeni_durum = $d['durum'] ?? '';
$not_metin = trim($d['not'] ?? '');
$takip_eden_id  = (int)($d['takip_eden_id'] ?? 0);
$takip_eden_adi = trim($d['takip_eden_adi'] ?? '');

// takip_eden kolonları yoksa otomatik ekle
try {
    $chk_col = $db->query("SHOW COLUMNS FROM satin_alma_talepler LIKE 'takip_eden_id'")->fetch();
    if (!$chk_col) {
        $db->exec("ALTER TABLE satin_alma_talepler ADD COLUMN takip_eden_id INT DEFAULT NULL");
        $db->exec("ALTER TABLE satin_alma_talepler ADD COLUMN takip_eden_adi VARCHAR(150) DEFAULT NULL");
    }
} catch (Throwable $e) {}

$gecerli_durumlar = ['bekliyor','onayda','reddedildi','teklifte','siparisde','kismi_tedarik','tamamlandi','iptal'];
if (!$talep_id || !in_array($yeni_durum, $gecerli_durumlar)) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz parametre']); exit;
}

try {
    $talep = $db->prepare("SELECT * FROM satin_alma_talepler WHERE id=? LIMIT 1");
    $talep->execute([$talep_id]); $t = $talep->fetch();
    if (!$t) { echo json_encode(['ok'=>false,'hata'=>'Talep bulunamadı']); exit; }

    $eski_durum = $t['durum'];

    // Güncelle
    $extra = [];
    if ($yeni_durum === 'onayda')   { $extra['onay_tarihi']="NOW()"; $extra['onaylayan_id']=$uid; }
    if ($yeni_durum === 'reddedildi' && $not_metin) $extra['ret_notu']=$not_metin;

    $set = "durum=?, guncelleme=NOW()";
    $params = [$yeni_durum];
    if (isset($extra['onay_tarihi'])) { $set .= ", onay_tarihi=NOW(), onaylayan_id=?"; $params[] = $uid; }
    if (isset($extra['ret_notu']))    { $set .= ", ret_notu=?"; $params[] = $not_metin; }
    // Takip eden kişiyi kaydet
    if ($takip_eden_id) {
        $set .= ", takip_eden_id=?, takip_eden_adi=?";
        $params[] = $takip_eden_id;
        $params[] = $takip_eden_adi;
    }
    $params[] = $talep_id;

    $db->prepare("UPDATE satin_alma_talepler SET $set WHERE id=?")->execute($params);

    // Geçmiş kaydı
    $gecmis_not = $not_metin ?: null;
    if ($takip_eden_adi) {
        $gecmis_not = ($gecmis_not ? $gecmis_not.' | ' : '') . $takip_eden_adi.' takibindedir';
    }
    $db->prepare("INSERT INTO satin_alma_gecmis (talep_id,kullanici_id,kullanici_adi,eski_durum,yeni_durum,not_metni)
        VALUES (?,?,?,?,?,?)")
       ->execute([$talep_id, $uid, $u_adi, $eski_durum, $yeni_durum, $gecmis_not]);

    // Mail gönder
    $tetikleyen_map = [
        'onayda'        => 'onayda',
        'reddedildi'    => 'reddedildi',
        'teklifte'      => 'teklifte',
        'siparisde'     => 'siparisde',
        'kismi_tedarik' => 'kismi_tedarik',
        'tamamlandi'    => 'tamamlandi',
    ];
    if (isset($tetikleyen_map[$yeni_durum])) {
        // Kalem özeti - onaylananlar/reddedilenler listesi
        $kalem_ozet = '';
        try {
            $kq = $db->prepare("SELECT urun_adi, kalem_durum FROM satin_alma_kalemler WHERE talep_id=? ORDER BY sira_no");
            $kq->execute([$talep_id]);
            $kalemler_ozet = $kq->fetchAll();
            $onay_say = count(array_filter($kalemler_ozet, function($k){ return $k['kalem_durum']==='onaylandi'; }));
            $red_say  = count(array_filter($kalemler_ozet, function($k){ return $k['kalem_durum']==='reddedildi'; }));
            $bek_say  = count(array_filter($kalemler_ozet, function($k){ return $k['kalem_durum']==='bekliyor'; }));
            if ($onay_say > 0 || $red_say > 0) {
                $kalem_ozet = "Kalem durumları: {$onay_say} onaylı, {$red_say} reddedildi, {$bek_say} bekliyor";
            }
        } catch (Throwable $e) {}

        $takip_str = $takip_eden_adi ? "$u_adi tarafından onaylandı, $takip_eden_adi takibindedir" : '';
        $not_ile_ozet = trim(implode(' | ', array_filter([$not_metin, $kalem_ozet, $takip_str])));

        require_once __DIR__ . '/satin-mail.php';
        satinMailGonder($talep_id, $tetikleyen_map[$yeni_durum], [
            'not'      => $not_ile_ozet,
            'onaylayan'=> $u_adi,
        ]);
        require_once ROOT_DIR . '/core/satin-bildirim.php';
        satinBildirimGonder($talep_id, $tetikleyen_map[$yeni_durum], ['not' => $not_ile_ozet]);

        // Direkt bildirim - hem ERP hem personel portala
        $durum_tr_map = [
            'onayda'=>'Onay Aşamasında','teklifte'=>'Teklif Toplanıyor',
            'siparisde'=>'Sipariş Oluşturuldu','tamamlandi'=>'Tamamlandı',
            'reddedildi'=>'Reddedildi','kismi_tedarik'=>'Kısmi Tedarik'
        ];
        try {
            $talep_bil = $db->prepare("SELECT talep_no, talep_eden_id, talep_eden_adi, personel_id FROM satin_alma_talepler WHERE id=? LIMIT 1");
            $talep_bil->execute([$talep_id]);
            $tb = $talep_bil->fetch();
            if ($tb) {
                $bil_baslik = '🛒 Satınalma: ' . ($tb['talep_no']??'');
                $bil_mesaj  = ($durum_tr_map[$yeni_durum] ?? $yeni_durum) . ($not_metin ? ' — '.$not_metin : '');
                $erp_link   = '?sayfa=idari-satin-detay&id='.$talep_id;

                // 1. ERP bildirimi - talep eden kullanıcıya
                if ($tb['talep_eden_id']) {
                    $db->prepare("INSERT INTO bildirimler (kullanici_id, portal_tipi, baslik, mesaj, tip, modul, link, okundu)
                        VALUES (?, 'erp', ?, ?, 'bilgi', 'idari-satinalma', ?, 0)")
                       ->execute([$tb['talep_eden_id'], $bil_baslik, $bil_mesaj, $erp_link]);
                }

                // 2. Personel portal bildirimi - personel_id veya ad ile portal_kullanicilari bul
                $pkul_id = null;

                // Yöntem 1: personel_id doğrudan
                if (!empty($tb['personel_id'])) {
                    $pq = $db->prepare("SELECT id FROM portal_kullanicilari WHERE ilgili_id=? AND tip='personel' AND durum=1 LIMIT 1");
                    $pq->execute([$tb['personel_id']]);
                    $pkul_id = $pq->fetchColumn() ?: null;
                }

                // Yöntem 2: talep_eden_id -> kullanicilar.email -> personeller.email -> portal
                if (!$pkul_id && $tb['talep_eden_id']) {
                    $em = $db->prepare("SELECT email FROM kullanicilar WHERE id=? LIMIT 1");
                    $em->execute([$tb['talep_eden_id']]);
                    $t_email = $em->fetchColumn();
                    if ($t_email) {
                        $pq2 = $db->prepare("SELECT pk.id FROM portal_kullanicilari pk
                            JOIN personeller p ON pk.ilgili_id=p.id
                            WHERE p.email=? AND pk.tip='personel' AND pk.durum=1 LIMIT 1");
                        $pq2->execute([$t_email]);
                        $pkul_id = $pq2->fetchColumn() ?: null;
                    }
                }

                // Yöntem 3: talep_eden_adi ile portal_kullanicilari.ad_soyad eşleştir
                if (!$pkul_id && !empty($tb['talep_eden_adi'])) {
                    $pq3 = $db->prepare("SELECT id FROM portal_kullanicilari WHERE ad_soyad=? AND tip='personel' AND durum=1 LIMIT 1");
                    $pq3->execute([trim($tb['talep_eden_adi'])]);
                    $pkul_id = $pq3->fetchColumn() ?: null;
                }

                // Portal bildirimi gönder
                if ($pkul_id) {
                    $db->prepare("INSERT INTO bildirimler (kullanici_id, portal_tipi, baslik, mesaj, tip, modul, link, okundu)
                        VALUES (?, 'personel', ?, ?, 'bilgi', 'satinalma', NULL, 0)")
                       ->execute([$pkul_id, $bil_baslik, $bil_mesaj]);
                }
            }
        } catch (Throwable $e2) {}
    }

    echo json_encode(['ok'=>true]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
