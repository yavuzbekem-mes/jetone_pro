<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$db_id = (int)($p['demirbas_id']??0);
if (!$db_id || empty($p['tarih'])) { echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }
try {
    $db->prepare("INSERT INTO demirbas_hareketler (demirbas_id,hareket_tipi,personel_id,tarih,aciklama,olusturan_id) VALUES (?,?,?,?,?,?)")
       ->execute([$db_id,$p['hareket_tipi']??'zimmet',(int)($p['personel_id']??0)||null,$p['tarih'],trim($p['aciklama']??'')||null,$user['id']??null]);
    // Zimmet/iade durumunu guncelle
    if ($p['hareket_tipi'] === 'zimmet' && !empty($p['personel_id'])) {
        $db->prepare("UPDATE demirbaslar SET durum='zimmetli',zimmet_personel_id=?,zimmet_tarihi=? WHERE id=?")
           ->execute([(int)$p['personel_id'],$p['tarih'],$db_id]);
    } elseif (in_array($p['hareket_tipi'],['iade','devir'])) {
        $db->prepare("UPDATE demirbaslar SET durum='aktif',zimmet_personel_id=NULL,zimmet_tarihi=NULL WHERE id=?")->execute([$db_id]);
    } elseif ($p['hareket_tipi'] === 'hurda') {
        $db->prepare("UPDATE demirbaslar SET durum='hurdaya_ayrildi' WHERE id=?")->execute([$db_id]);
    } elseif ($p['hareket_tipi'] === 'bakim') {
        $db->prepare("UPDATE demirbaslar SET durum='bakimda' WHERE id=?")->execute([$db_id]);
    }
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
