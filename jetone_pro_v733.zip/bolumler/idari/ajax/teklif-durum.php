<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$id = (int)($_POST['id'] ?? 0);
$durum = $_POST['durum'] ?? '';
$gecerli = ['taslak','gonderildi','kabul','red','revize','suresi_doldu'];
if (!$id || !in_array($durum,$gecerli)) { echo json_encode(['ok'=>false,'hata'=>'Gecersiz']); exit; }
try {
    $db->prepare("UPDATE teklifler SET durum=? WHERE id=?")->execute([$durum,$id]);
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
