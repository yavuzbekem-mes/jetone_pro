<?php
/**
 * Satınalma - Mail Gönderici Yardımcısı
 * Her aşama değişiminde çağrılır
 */
if (!defined('ROOT_DIR')) {
    require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
    require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
}

function satinMailGonder(int $talep_id, string $tetikleyen, array $ekstra = []): array
{
    global $db;

    // SMTP ayarlarını al
    try {
        $smtp_ent = $db->query(
            "SELECT host, port, kullanici, sifre, ek_parametreler
             FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1"
        )->fetch();
    } catch (Throwable $e) { $smtp_ent = null; }

    if (!$smtp_ent) {
        return ['ok' => false, 'hata' => 'SMTP entegrasyonu tanımlanmamış'];
    }

    // Şifreyi çöz — hem AES hem düz metin dene
    $key = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
    $sifre = '';
    if (!empty($smtp_ent['sifre'])) {
        $enc = trim($smtp_ent['sifre']);
        // Önce decrypt dene
        $dec1 = @openssl_decrypt($enc, 'AES-256-CBC', $key, 0, '1234567890123456');
        // Eski key ile de dene
        $dec2 = @openssl_decrypt($enc, 'AES-256-CBC', 'jetone2024secretkey!!', 0, '1234567890123456');
        if ($dec1 !== false && strlen($dec1) > 0 && ctype_print($dec1)) {
            $sifre = $dec1; // AES decrypt başarılı
        } elseif ($dec2 !== false && strlen($dec2) > 0 && ctype_print($dec2)) {
            $sifre = $dec2; // eski key ile decrypt
        } else {
            // base64 olabilir mi?
            $b64dec = @base64_decode($enc, true);
            if ($b64dec !== false && ctype_print($b64dec) && strlen($b64dec) > 0) {
                $sifre = $b64dec;
            } else {
                $sifre = $enc; // düz metin
            }
        }
    }
    $ekPar = json_decode($smtp_ent['ek_parametreler'] ?? '{}', true) ?: [];
    $secure    = $ekPar['smtp_secure']    ?? 'ssl';
    $fromName  = $ekPar['smtp_from_name'] ?? 'Jetone ERP';

    // Talep bilgilerini al
    $talep = $db->prepare(
        "SELECT t.*, CONCAT(k.ad,' ',k.soyad) mev_adi, k.email mev_mail
         FROM satin_alma_talepler t
         LEFT JOIN kullanicilar k ON t.talep_eden_id = k.id
         WHERE t.id = ?"
    );
    $talep->execute([$talep_id]);
    $t = $talep->fetch();
    if (!$t) return ['ok' => false, 'hata' => 'Talep bulunamadı'];

    // Kalemleri al
    $kalemler = $db->prepare(
        "SELECT * FROM satin_alma_kalemler WHERE talep_id = ? ORDER BY sira_no"
    );
    $kalemler->execute([$talep_id]);
    $kalem_list = $kalemler->fetchAll();

    // Sorumlu mailler — departman adı ile eşleştir (önce departman, sonra pozisyon)
    $mud_mail   = '';
    $idari_mail = '';
    try {
        $mudRow = $db->query("SELECT p.email, CONCAT(p.ad,' ',p.soyad) isim
             FROM personeller p
             JOIN departmanlar d ON p.departman_id = d.id
             WHERE p.durum='aktif' AND p.email IS NOT NULL AND p.email != ''
               AND (
                   d.ad LIKE '%Satınalma%' OR d.ad LIKE '%Satin%'
                   OR p.pozisyon LIKE '%Satınalma%Müdür%' OR p.pozisyon LIKE '%Satin%Mudur%'
                   OR p.unvan    LIKE '%Satınalma%Müdür%'
               )
             ORDER BY CASE WHEN p.pozisyon LIKE '%Müdür%' OR p.unvan LIKE '%Müdür%' THEN 0 ELSE 1 END
             LIMIT 1")->fetch();
        $mud_mail = $mudRow ? $mudRow['email'] : '';

        $idariRow = $db->query("SELECT p.email, CONCAT(p.ad,' ',p.soyad) isim
              FROM personeller p
              JOIN departmanlar d ON p.departman_id = d.id
              WHERE p.durum='aktif' AND p.email IS NOT NULL AND p.email != ''
                AND (
                    d.ad LIKE '%İdari%' OR d.ad LIKE '%Idari%'
                    OR p.pozisyon LIKE '%İdari%Sorumlu%' OR p.pozisyon LIKE '%Idari%Sorumlu%'
                    OR p.unvan    LIKE '%İdari%İşler%'
                )
              ORDER BY CASE WHEN p.pozisyon LIKE '%Sorumlu%' OR p.unvan LIKE '%Sorumlu%' THEN 0 ELSE 1 END
              LIMIT 1")->fetch();
        $idari_mail = $idariRow ? $idariRow['email'] : '';

        // Fallback: ayarlar_kv
        if (!$mud_mail)   $mud_mail   = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='satin_mudur_mail' LIMIT 1")->fetchColumn() ?: '';
        if (!$idari_mail) $idari_mail = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='idari_sorumlu_mail' LIMIT 1")->fetchColumn() ?: '';
    } catch (Throwable $e) { $mud_mail = ''; $idari_mail = ''; }

    // Durum etiketleri
    $durum_tr = [
        'bekliyor'       => 'Bekliyor',
        'onayda'         => 'Onay Aşamasında',
        'reddedildi'     => 'Reddedildi',
        'teklifte'       => 'Teklif Toplanıyor',
        'siparisde'      => 'Sipariş Oluşturuldu',
        'kismi_tedarik'  => 'Kısmi Tedarik',
        'tamamlandi'     => 'Tamamlandı',
        'iptal'          => 'İptal Edildi',
    ];
    $oncelik_tr = ['dusuk'=>'Düşük','normal'=>'Normal','yuksek'=>'Yüksek','acil'=>'ACİL'];
    $tur_tr = ['sarf_malzeme'=>'Sarf Malzeme','teknik_satin_alma'=>'Teknik Satınalma'];

    // Mail konu ve alıcılar
    $durum_etiket = $durum_tr[$t['durum']] ?? $t['durum'];
    $konu = "[{$t['talep_no']}] Satınalma Talebi — $durum_etiket";

    // Alıcı listesi: sunucu maili + talep eden + satınalma müdürü + idari sorumlu
    $alicilar = [];

    // 1. SMTP gönderici (sunucu) maili — her zaman dahil
    if (!empty($smtp_ent['kullanici'])) $alicilar[] = trim($smtp_ent['kullanici']);

    // 2. Talep eden kullanıcının maili (kullanicilar tablosundan)
    try {
        $talep_eden_mail = $db->prepare("SELECT email FROM kullanicilar WHERE id=? LIMIT 1");
        $talep_eden_mail->execute([$t['talep_eden_id']]);
        $te_mail = $talep_eden_mail->fetchColumn();
        if ($te_mail && filter_var($te_mail, FILTER_VALIDATE_EMAIL)) $alicilar[] = trim($te_mail);
    } catch (Throwable $e) {}

    // 3. talep tablosundaki mev_mail (personel kaydından gelen mail)
    if (!empty($t['mev_mail']) && filter_var($t['mev_mail'], FILTER_VALIDATE_EMAIL))
        $alicilar[] = trim($t['mev_mail']);

    // 4. Satınalma müdürü
    if (!empty($mud_mail) && filter_var($mud_mail, FILTER_VALIDATE_EMAIL))
        $alicilar[] = trim($mud_mail);

    // 5. İdari işler sorumlusu
    if (!empty($idari_mail) && filter_var($idari_mail, FILTER_VALIDATE_EMAIL))
        $alicilar[] = trim($idari_mail);

    // 6. Ekstra mail (gerekirse)
    if (!empty($ekstra['ekstra_mail']) && filter_var($ekstra['ekstra_mail'], FILTER_VALIDATE_EMAIL))
        $alicilar[] = trim($ekstra['ekstra_mail']);

    $alicilar = array_values(array_unique(array_filter($alicilar)));

    if (empty($alicilar)) {
        return ['ok' => false, 'hata' => 'Gönderilecek mail adresi bulunamadı.'];
    }

    // Kalem tablosu HTML
    $kalem_html = '';
    foreach ($kalem_list as $i => $k) {
        $kd_map = [
            'bekliyor'       => ['bg'=>'#FEF9C3','renk'=>'#854D0E','yaz'=>'Bekliyor'],
            'onaylandi'      => ['bg'=>'#D1FAE5','renk'=>'#065F46','yaz'=>'Onaylandı ✓'],
            'reddedildi'     => ['bg'=>'#FEE2E2','renk'=>'#991B1B','yaz'=>'Reddedildi ✕'],
            'tedarik_edildi' => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','yaz'=>'Tedarik Edildi'],
        ];
        $kd_cfg     = $kd_map[$k['kalem_durum']] ?? $kd_map['bekliyor'];
        $durum_renk = $kd_cfg['bg'];
        $durum_renk_text = $kd_cfg['renk'];
        $durum_yaz  = $kd_cfg['yaz'];
        // Kalem notu varsa ekle
        if (!empty($k['kalem_notu'])) $durum_yaz .= ' — ' . htmlspecialchars($k['kalem_notu']);
        if ($k['kalem_durum'] === 'onaylandi') {
            $zebra_bg = '#F0FDF4';
            $border_b = 'border-bottom:1px solid #BBF7D0';
            $urun_renk = '#065F46';
        } elseif ($k['kalem_durum'] === 'reddedildi') {
            $zebra_bg = '#FFF1F2';
            $border_b = 'border-bottom:1px solid #FECDD3';
            $urun_renk = '#881337';
        } else {
            $zebra_bg = ($i % 2 === 0) ? '#FFFFFF' : '#F8FAFC';
            $border_b = 'border-bottom:1px solid #F1F5F9';
            $urun_renk = '#111827';
        }
        $kalem_html .= "<tr style='background:{$zebra_bg}'>
            <td style='padding:11px 12px;{$border_b};text-align:center;color:#9CA3AF;font-size:12px;font-weight:700'>{$k['sira_no']}</td>
            <td style='padding:11px 12px;{$border_b};color:#6B7280;font-size:12px;font-family:monospace'>" . htmlspecialchars($k['urun_kodu'] ?? '') . "</td>
            <td style='padding:11px 12px;{$border_b};font-weight:700;color:{$urun_renk}'>" . htmlspecialchars($k['urun_adi']) . "</td>
            <td style='padding:11px 12px;{$border_b};color:#6B7280;font-size:12px'>" . htmlspecialchars($k['marka'] ?? '') . "</td>
            <td style='padding:11px 12px;{$border_b};text-align:right;font-weight:600;color:#374151'>" . number_format($k['miktar'], 0) . " <span style='color:#9CA3AF;font-size:11px'>{$k['birim']}</span></td>
            <td style='padding:11px 12px;{$border_b};color:#6B7280;font-size:12px'>" . htmlspecialchars($k['aciklama'] ?? '') . "</td>
            <td style='padding:11px 12px;{$border_b};text-align:center'>
              <span style='background:{$durum_renk};color:{$durum_renk_text};font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;letter-spacing:.3px'>{$durum_yaz}</span>
            </td>
        </tr>";
    }

    // Aşama açıklaması
    $onaylayan_adi = $ekstra['onaylayan'] ?? '';
    $aşama_aciklama = [
        'talep_olusturuldu' => 'Yeni bir satınalma talebi oluşturuldu ve onay bekliyor.',
        'onaylandi'         => 'Satınalma talebi onaylandı ve işleme alındı.',
        'reddedildi'        => 'Satınalma talebi reddedildi.',
        'teklifte'          => 'Tedarikçilerden teklif toplanıyor.',
        'siparisde'         => 'Sipariş oluşturuldu.',
        'kismi_tedarik'     => 'Kısmi tedarik gerçekleşti.',
        'tamamlandi'        => 'Talep tamamen tamamlandı.',
        'kalem_onaylandi'   => ($onaylayan_adi ? "$onaylayan_adi tarafından " : '') . 'kalem değerlendirmesi tamamlandı.',
        'kalem_reddedildi'  => ($onaylayan_adi ? "$onaylayan_adi tarafından " : '') . 'bir veya daha fazla kalem reddedildi.',
        'kalem_guncellendi' => 'Kalem durumları güncellendi.',
    ][$tetikleyen] ?? "Talep durumu güncellendi: $durum_etiket";

    $not_html = '';
    if (!empty($ekstra['not'])) {
        $not_html = "
      <div style='background:#FFFBEB;border:1px solid #FDE68A;border-left:4px solid #F59E0B;border-radius:0 10px 10px 0;padding:14px 18px;margin-bottom:20px'>
        <div style='font-size:10px;font-weight:700;color:#B45309;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px'>Not</div>
        <div style='font-size:14px;color:#92400E'>" . htmlspecialchars($ekstra['not']) . "</div>
      </div>";
    }

    // Durum renk ayarları
    $dr = [
        'bekliyor'      => ['bg'=>'#FFFBEB','renk'=>'#D97706','b_bg'=>'#FEF3C7','b_renk'=>'#92400E','ikon'=>'&#9203;'],
        'onayda'        => ['bg'=>'#EFF6FF','renk'=>'#2563EB','b_bg'=>'#DBEAFE','b_renk'=>'#1E40AF','ikon'=>'&#128065;'],
        'reddedildi'    => ['bg'=>'#FFF1F2','renk'=>'#E11D48','b_bg'=>'#FFE4E6','b_renk'=>'#9F1239','ikon'=>'&#10060;'],
        'teklifte'      => ['bg'=>'#FFFBEB','renk'=>'#D97706','b_bg'=>'#FEF3C7','b_renk'=>'#92400E','ikon'=>'&#128203;'],
        'siparisde'     => ['bg'=>'#F5F3FF','renk'=>'#7C3AED','b_bg'=>'#EDE9FE','b_renk'=>'#5B21B6','ikon'=>'&#128230;'],
        'kismi_tedarik' => ['bg'=>'#F0FDF4','renk'=>'#16A34A','b_bg'=>'#DCFCE7','b_renk'=>'#15803D','ikon'=>'&#128260;'],
        'tamamlandi'    => ['bg'=>'#F0FDF4','renk'=>'#16A34A','b_bg'=>'#DCFCE7','b_renk'=>'#15803D','ikon'=>'&#9989;'],
        'iptal'         => ['bg'=>'#F9FAFB','renk'=>'#6B7280','b_bg'=>'#F3F4F6','b_renk'=>'#374151','ikon'=>'&#128683;'],
    ];
    $durum_r = $dr[$t['durum']] ?? $dr['bekliyor'];
    $oncelik_renk = ['dusuk'=>'#6B7280','normal'=>'#2563EB','yuksek'=>'#D97706','acil'=>'#DC2626'];
    $onc_renk = $oncelik_renk[$t['oncelik']] ?? '#374151';

    // Mail body
    $body = "
<!DOCTYPE html>
<html lang='tr'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>{$t['talep_no']}</title>
</head>
<body style='margin:0;padding:0;background-color:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif'>
<div style='max-width:640px;margin:0 auto;padding:24px 16px'>

  <!-- Ana kart -->
  <div style='background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06),0 4px 16px rgba(0,0,0,.06)'>

    <!-- Header: logo + durum şeridi -->
    <!-- Header: solid turuncu - gradient mail istemcilerinde çalışmaz -->
    <table width='100%' cellpadding='0' cellspacing='0' style='background-color:#F97316'>
      <tr>
        <td style='padding:24px 32px 0 32px'>
          <table width='100%' cellpadding='0' cellspacing='0'>
            <tr>
              <td style='vertical-align:middle'>
                <div style='color:#7C2D00;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:5px'>SATINALMA YÖNETİM SİSTEMİ</div>
                <div style='font-size:28px;font-weight:900;letter-spacing:-.5px'>
                  <span style='color:#1C1917'>Jetone</span><span style='color:#7C2D00'> ERP</span>
                </div>
              </td>
              <td style='vertical-align:middle;text-align:right'>
                <div style='display:inline-block;background:#7C2D00;color:#FED7AA;font-size:13px;font-weight:700;padding:6px 16px;border-radius:20px;letter-spacing:.5px'>
                  {$t['talep_no']}
                </div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style='padding:16px 32px 0 32px'>
          <div style='height:1px;background-color:#EA580C'></div>
        </td>
      </tr>
      <tr>
        <td style='padding:14px 32px 18px 32px;background-color:{$durum_r['bg']}'>
          <table cellpadding='0' cellspacing='0'>
            <tr>
              <td style='vertical-align:middle;padding-right:10px;font-size:18px'>{$durum_r['ikon']}</td>
              <td style='vertical-align:middle'>
                <div style='font-size:15px;font-weight:700;color:{$durum_r['renk']}'>{$aşama_aciklama}</div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <div style='padding:28px 32px'>

      <!-- Özet bilgi grid -->
      <table style='width:100%;border-collapse:collapse;margin-bottom:24px'>
        <tr>
          <td colspan='4' style='padding:0 0 12px'>
            <div style='height:1px;background:linear-gradient(to right,#F97316,#FED7AA,transparent)'></div>
          </td>
        </tr>
        <tr>
          <td style='padding:10px 14px 10px 0;vertical-align:top;width:25%'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Talep Eden</div>
            <div style='font-size:14px;font-weight:700;color:#111827'>" . htmlspecialchars($t['talep_eden_adi']) . "</div>
          </td>
          <td style='padding:10px 14px 10px 0;vertical-align:top;width:25%'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Departman</div>
            <div style='font-size:14px;font-weight:600;color:#374151'>" . htmlspecialchars($t['departman'] ?? '—') . "</div>
          </td>
          <td style='padding:10px 14px 10px 0;vertical-align:top;width:25%'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Talep Türü</div>
            <div style='font-size:14px;font-weight:600;color:#374151'>" . ($tur_tr[$t['talep_turu']] ?? $t['talep_turu']) . "</div>
          </td>
          <td style='padding:10px 0 10px 0;vertical-align:top;width:25%'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Öncelik</div>
            <div style='display:inline-block;background:{$durum_r['b_bg']};color:{$onc_renk};font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px'>" . ($oncelik_tr[$t['oncelik']] ?? $t['oncelik']) . "</div>
          </td>
        </tr>
        <tr>
          <td style='padding:10px 14px 0 0;vertical-align:top'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Termin Tarihi</div>
            <div style='font-size:14px;font-weight:600;color:#374151'>" . ($t['termin_tarihi'] ? date('d.m.Y', strtotime($t['termin_tarihi'])) : '—') . "</div>
          </td>
          <td style='padding:10px 14px 0 0;vertical-align:top'>
            <div style='font-size:10px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px'>Oluşturma</div>
            <div style='font-size:14px;font-weight:600;color:#374151'>" . date('d.m.Y H:i', strtotime($t['olusturma'])) . "</div>
          </td>
          <td colspan='2'></td>
        </tr>
        <tr>
          <td colspan='4' style='padding:16px 0 0'>
            <div style='height:1px;background:#F3F4F6'></div>
          </td>
        </tr>
      </table>

      {$not_html}

      <!-- Kalemler başlık -->
      <div style='display:flex;align-items:center;gap:10px;margin-bottom:12px'>
        <div style='width:3px;height:18px;background:#F97316;border-radius:2px'></div>
        <div style='font-size:13px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.8px'>Talep Kalemleri</div>
      </div>

      <!-- Kalemler tablosu -->
      <table style='width:100%;border-collapse:separate;border-spacing:0;border-radius:10px;overflow:hidden;border:1px solid #E5E7EB;font-size:13px'>
        <thead>
          <tr style='background:#0F172A'>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:center;letter-spacing:.5px'>#</th>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:left;letter-spacing:.5px'>KOD</th>
            <th style='padding:10px 12px;color:#E2E8F0;font-weight:600;font-size:11px;text-align:left;letter-spacing:.5px'>ÜRÜN / MALZEME</th>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:left;letter-spacing:.5px'>MARKA</th>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:right;letter-spacing:.5px'>MİKTAR</th>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:left;letter-spacing:.5px'>KULLANIM YERİ</th>
            <th style='padding:10px 12px;color:#94A3B8;font-weight:600;font-size:11px;text-align:center;letter-spacing:.5px'>DURUM</th>
          </tr>
        </thead>
        <tbody>{$kalem_html}</tbody>
      </table>

      <!-- Açıklama -->
      " . (!empty($t['aciklama']) ? "
      <div style='margin-top:20px;background:#F8FAFC;border:1px solid #E2E8F0;border-left:4px solid #F97316;border-radius:0 8px 8px 0;padding:14px 18px'>
        <div style='font-size:11px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px'>Açıklama</div>
        <div style='font-size:14px;color:#374151;line-height:1.6'>" . nl2br(htmlspecialchars($t['aciklama'])) . "</div>
      </div>" : "") . "

    </div>

    <!-- Footer -->
    <div style='background:#F8FAFC;border-top:1px solid #E5E7EB;padding:20px 32px'>
      <table style='width:100%;border-collapse:collapse'>
        <tr>
          <td style='vertical-align:middle'>
            <div style='font-size:13px;font-weight:800;color:#EA580C'>Jetone ERP</div>
            <div style='font-size:11px;color:#6B7280;margin-top:2px'>Satınalma Yönetim Sistemi</div>
          </td>
          <td style='text-align:right;vertical-align:middle'>
            <div style='font-size:11px;color:#4B5563'>Bu mail otomatik gönderilmiştir</div>
            <div style='font-size:11px;color:#6B7280;margin-top:2px'>" . date('d.m.Y H:i') . "</div>
          </td>
        </tr>
      </table>
    </div>
  </div><!-- /ana kart -->
</div><!-- /wrapper -->
</body></html>";

    // SMTP ile gönder
    require_once ROOT_DIR . '/bolumler/idari/ajax/satin-smtp-send.php';
    $result = satinSmtpSend(
        $smtp_ent['host'], (int)$smtp_ent['port'], $secure,
        $smtp_ent['kullanici'], $sifre, $fromName,
        $alicilar, $konu, $body
    );

    // Log kaydet
    try {
        $db->prepare("INSERT INTO satin_alma_mail_log (talep_id,alici,konu,durum,hata_mesaji,tetikleyen) VALUES (?,?,?,?,?,?)")
           ->execute([
               $talep_id,
               implode(', ', $alicilar),
               $konu,
               $result['ok'] ? 'gonderildi' : 'hata',
               $result['ok'] ? null : ($result['hata'] ?? ''),
               $tetikleyen
           ]);
    } catch (Throwable $e) {}

    return $result;
}
