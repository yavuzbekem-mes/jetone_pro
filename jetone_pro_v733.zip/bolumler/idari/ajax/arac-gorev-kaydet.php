<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$arac_id = (int)($p['arac_id']??0);
if (($p['islem']??'ekle') === 'sil') { $db->prepare('DELETE FROM arac_gorevler WHERE id=?')->execute([(int)$p['id']]); echo json_encode(['ok'=>true]); exit; }
if (!$arac_id || empty($p['baslangic'])) { echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }
try {
    $islem = $p['islem'] ?? 'ekle';
$id_upd = (int)($p['id'] ?? 0);

if ($islem === 'sil' && $id_upd) {
    $db->prepare("DELETE FROM arac_gorevler WHERE id=?")->execute([$id_upd]);
    echo json_encode(['ok'=>true]); exit;
}

if ($islem === 'guncelle' && $id_upd) {
    $params_upd = [$p['baslangic']??null,!empty($p['bitis'])?$p['bitis']:null,trim($p['kalkis_yeri']??''),trim($p['varis_yeri']??''),trim($p['amac']??''),!empty($p['km_baslangic'])?(int)$p['km_baslangic']:null,!empty($p['km_bitis'])?(int)$p['km_bitis']:null,$p['durum']??'planli',trim($p['notlar']??'')];
    $params_upd[] = $id_upd;
    $db->prepare("UPDATE arac_gorevler SET baslangic=?,bitis=?,kalkis_yeri=?,varis_yeri=?,amac=?,km_baslangic=?,km_bitis=?,durum=?,notlar=? WHERE id=?")->execute($params_upd);
    echo json_encode(['ok'=>true]); exit;
}

$db->prepare("INSERT INTO arac_gorevler (arac_id,surucu_id,baslangic,bitis,kalkis_yeri,varis_yeri,amac,km_baslangic,km_bitis,durum,olusturan_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([$arac_id,(($tmp=(int)($p['surucu_id']??0)) !== 0 ? $tmp : null),$p['baslangic'],$p['bitis'] ?: null,trim($p['kalkis_yeri']??''),trim($p['varis_yeri']??''),trim($p['amac']??''),(($tmp=(int)($p['km_baslangic']??0)) !== 0 ? $tmp : null),(($tmp=(int)($p['km_bitis']??0)) !== 0 ? $tmp : null),$p['durum']??'planli',$user['id']??null]);
    if (!empty($p['km_bitis'])) $db->prepare("UPDATE araclar SET km_guncel=GREATEST(km_guncel,?) WHERE id=?")->execute([(int)$p['km_bitis'],$arac_id]);
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
