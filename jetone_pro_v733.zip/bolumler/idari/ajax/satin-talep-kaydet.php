<?php
/**
 * Satınalma Talebi Kaydet AJAX
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
$user = Auth::kullanici();
$uid  = (int)$user['id'];

$edit_id     = (int)($_POST['edit_id'] ?? 0);
$talep_turu  = in_array($_POST['talep_turu']??'', ['sarf_malzeme','teknik_satin_alma']) ? $_POST['talep_turu'] : 'sarf_malzeme';
$oncelik     = in_array($_POST['oncelik']??'', ['dusuk','normal','yuksek','acil']) ? $_POST['oncelik'] : 'normal';
$departman   = trim($_POST['departman'] ?? '');
$termin      = !empty($_POST['termin_tarihi']) ? $_POST['termin_tarihi'] : null;
$aciklama    = trim($_POST['aciklama'] ?? '');
$talep_adi   = trim($_POST['talep_eden_adi'] ?? '');

// Kalemler
$kodlar    = $_POST['k_kod']      ?? [];
$adlar     = $_POST['k_adi']      ?? [];
$markalar  = $_POST['k_marka']    ?? [];
$miktarlar = $_POST['k_miktar']   ?? [];
$birimler  = $_POST['k_birim']    ?? [];
$aciklar   = $_POST['k_aciklama'] ?? [];

$kalemler = [];
foreach ($adlar as $i => $adi) {
    if (trim($adi) === '') continue;
    $kalemler[] = [
        'sira_no'    => $i + 1,
        'urun_kodu'  => trim($kodlar[$i]   ?? ''),
        'urun_adi'   => trim($adi),
        'marka'      => trim($markalar[$i] ?? ''),
        'miktar'     => max(0.001, (float)($miktarlar[$i] ?? 1)),
        'birim'      => trim($birimler[$i] ?? 'Adet') ?: 'Adet',
        'aciklama'   => trim($aciklar[$i]  ?? ''),
    ];
}

if (empty($kalemler)) {
    echo json_encode(['ok'=>false,'hata'=>'En az bir kalem gerekli']);
    exit;
}

$toplam_miktar = array_sum(array_column($kalemler, 'miktar'));

try {
    $db->beginTransaction();

    // Talep edenin personel_id'sini bul
    $per_id_kayit = null;
    try {
        // kullanici_id eşleşmesi
        $pq = $db->prepare("SELECT id FROM personeller WHERE kullanici_id=? AND durum='aktif' LIMIT 1");
        $pq->execute([$uid]); $per_id_kayit = $pq->fetchColumn() ?: null;
        // Bulunamazsa email ile dene
        if (!$per_id_kayit) {
            $eq = $db->prepare("SELECT email FROM kullanicilar WHERE id=? LIMIT 1");
            $eq->execute([$uid]); $k_mail = $eq->fetchColumn();
            if ($k_mail) {
                $pq2 = $db->prepare("SELECT id FROM personeller WHERE email=? AND durum='aktif' LIMIT 1");
                $pq2->execute([$k_mail]); $per_id_kayit = $pq2->fetchColumn() ?: null;
            }
        }
        // Bulunamazsa ad soyad ile dene
        if (!$per_id_kayit && $talep_adi) {
            $pq3 = $db->prepare("SELECT id FROM personeller WHERE CONCAT(TRIM(ad),' ',TRIM(soyad))=? AND durum='aktif' LIMIT 1");
            $pq3->execute([$talep_adi]); $per_id_kayit = $pq3->fetchColumn() ?: null;
        }
    } catch (Throwable $e) {}

    if ($edit_id) {
        // Güncelle
        $db->prepare("UPDATE satin_alma_talepler SET
            departman=?, talep_turu=?, oncelik=?, termin_tarihi=?, aciklama=?,
            toplam_miktar=?, personel_id=COALESCE(personel_id,?), guncelleme=NOW()
            WHERE id=? AND durum='bekliyor'")
           ->execute([$departman, $talep_turu, $oncelik, $termin, $aciklama, $toplam_miktar, $per_id_kayit, $edit_id]);
        // Kalemleri sil ve yeniden ekle
        $db->prepare("DELETE FROM satin_alma_kalemler WHERE talep_id=?")->execute([$edit_id]);
        $talep_id = $edit_id;
    } else {
        // Talep no oluştur: SAT-2024-0001
        $yil = date('Y');
        $son = $db->query("SELECT MAX(id) FROM satin_alma_talepler")->fetchColumn();
        $sira = str_pad(($son + 1), 4, '0', STR_PAD_LEFT);
        $talep_no = "SAT-{$yil}-{$sira}";

        // personel_id kolonu var mı kontrol et
        $per_id_kolon_var = false;
        try {
            $db->query("SELECT personel_id FROM satin_alma_talepler LIMIT 0");
            $per_id_kolon_var = true;
        } catch (Throwable $e) {}

        if ($per_id_kolon_var) {
            $db->prepare("INSERT INTO satin_alma_talepler
                (talep_no, talep_eden_id, talep_eden_adi, departman, talep_turu, oncelik,
                 termin_tarihi, aciklama, durum, toplam_miktar, personel_id)
                VALUES (?,?,?,?,?,?,?,?,'bekliyor',?,?)")
               ->execute([$talep_no, $uid, $talep_adi, $departman, $talep_turu, $oncelik,
                         $termin, $aciklama, $toplam_miktar, $per_id_kayit]);
        } else {
            // Kolonu ekle, sonra INSERT yap
            try { $db->exec("ALTER TABLE satin_alma_talepler ADD COLUMN personel_id INT DEFAULT NULL"); } catch (Throwable $e) {}
            $db->prepare("INSERT INTO satin_alma_talepler
                (talep_no, talep_eden_id, talep_eden_adi, departman, talep_turu, oncelik,
                 termin_tarihi, aciklama, durum, toplam_miktar, personel_id)
                VALUES (?,?,?,?,?,?,?,?,'bekliyor',?,?)")
               ->execute([$talep_no, $uid, $talep_adi, $departman, $talep_turu, $oncelik,
                         $termin, $aciklama, $toplam_miktar, $per_id_kayit]);
        }
        $talep_id = (int)$db->lastInsertId();
    }

    // Kalemleri ekle
    $stmt = $db->prepare("INSERT INTO satin_alma_kalemler
        (talep_id, sira_no, urun_kodu, urun_adi, marka, miktar, birim, aciklama)
        VALUES (?,?,?,?,?,?,?,?)");
    foreach ($kalemler as $k) {
        $stmt->execute([$talep_id, $k['sira_no'], $k['urun_kodu'], $k['urun_adi'],
                        $k['marka'], $k['miktar'], $k['birim'], $k['aciklama']]);
    }

    // Geçmiş kaydı
    $db->prepare("INSERT INTO satin_alma_gecmis (talep_id, kullanici_id, kullanici_adi, eski_durum, yeni_durum, not_metni)
        VALUES (?,?,?,?,?,?)")
       ->execute([$talep_id, $uid, $talep_adi, null, 'bekliyor', 'Talep oluşturuldu']);

    $db->commit();

    // Mail + Bildirim gönder (yeni talep ise)
    if (!$edit_id) {
        require_once __DIR__ . '/satin-mail.php';
        satinMailGonder($talep_id, 'talep_olusturuldu');
        require_once ROOT_DIR . '/core/satin-bildirim.php';
        satinBildirimGonder($talep_id, 'talep_olusturuldu');
    }

    echo json_encode(['ok'=>true, 'talep_id'=>$talep_id]);

} catch (Throwable $e) {
    $db->rollBack();
    echo json_encode(['ok'=>false, 'hata'=>$e->getMessage()]);
}
