<?php
/**
 * Native PHP SMTP gönderici (satınalma için)
 * PHPMailer gerektirmez
 */
if (!function_exists('satinSmtpSend')) {
function satinSmtpSend(string $host, int $port, string $secure, string $user, string $pass, string $fromName, array $alicilar, string $konu, string $body): array
{
    $log = [];
    try {
        $ctx = stream_context_create([
            'ssl' => ['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]
        ]);
        if ($secure === 'ssl') {
            $fp = @stream_socket_client("ssl://$host:$port", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
        } else {
            $fp = @fsockopen($host, $port, $errno, $errstr, 15);
        }
        if (!$fp) return ['ok'=>false,'hata'=>"Bağlantı kurulamadı: $errstr ($errno)"];
        stream_set_timeout($fp, 15);

        $rd = function() use ($fp, &$log) { $r=fgets($fp,1024); $log[]='< '.trim($r); return $r; };
        $wr = function($s) use ($fp, &$log) { $log[]='> '.trim($s); fputs($fp,$s); };

        $rd();
        $wr("EHLO jetone.pro\r\n");
        while ($l = fgets($fp, 1024)) { $log[]='< '.trim($l); if (substr($l,3,1)==' ') break; }

        if ($secure === 'tls') {
            $wr("STARTTLS\r\n"); $rd();
            stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $wr("EHLO jetone.pro\r\n");
            while ($l = fgets($fp, 1024)) { $log[]='< '.trim($l); if (substr($l,3,1)==' ') break; }
        }

        $wr("AUTH LOGIN\r\n"); $rd();
        $wr(base64_encode($user)."\r\n"); $rd();
        $wr(base64_encode($pass)."\r\n");
        $authR = $rd();
        if (substr($authR,0,3) !== '235') {
            fclose($fp);
            return ['ok'=>false,'hata'=>'Kimlik doğrulama hatası: '.trim($authR),'log'=>$log];
        }

        $wr("MAIL FROM:<$user>\r\n"); $rd();
        foreach ($alicilar as $alici) {
            $wr("RCPT TO:<$alici>\r\n"); $rd();
        }
        $wr("DATA\r\n"); $rd();

        $to_str = implode(', ', $alicilar);
        $date   = date('r');
        $konu_b64 = '=?UTF-8?B?'.base64_encode($konu).'?=';
        $from_b64 = '=?UTF-8?B?'.base64_encode($fromName).'?=';
        $msg  = "Date: $date\r\n"
              . "From: $from_b64 <$user>\r\n"
              . "To: $to_str\r\n"
              . "Subject: $konu_b64\r\n"
              . "MIME-Version: 1.0\r\n"
              . "Content-Type: text/html; charset=UTF-8\r\n"
              . "Content-Transfer-Encoding: base64\r\n"
              . "\r\n"
              . chunk_split(base64_encode($body), 76, "\r\n");

        $wr($msg."\r\n.\r\n");
        $dataR = $rd();
        $wr("QUIT\r\n");
        fclose($fp);

        if (substr($dataR,0,3) === '250') {
            return ['ok'=>true];
        }
        return ['ok'=>false,'hata'=>'Mail kabul edilmedi: '.trim($dataR),'log'=>$log];
    } catch (Throwable $e) {
        return ['ok'=>false,'hata'=>$e->getMessage(),'log'=>$log];
    }
}
}
