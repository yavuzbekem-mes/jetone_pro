<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$uid  = (int)$user['id'];
$uadi = $user['ad_soyad'] ?? 'Bilinmiyor';

// Tablo yoksa oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `evraklar` (
        `id`              INT AUTO_INCREMENT PRIMARY KEY,
        `evrak_no`        VARCHAR(30) NOT NULL UNIQUE,
        `baslik`          VARCHAR(300) NOT NULL,
        `kategori`        VARCHAR(50) DEFAULT 'genel' COMMENT 'sozlesme,fatura,izin,resmi,diger,genel',
        `aciklama`        TEXT,
        `durum`           VARCHAR(30) DEFAULT 'bekliyor' COMMENT 'bekliyor,inceleniyor,onaylandi,reddedildi,arsivlendi',
        `oncelik`         VARCHAR(20) DEFAULT 'normal' COMMENT 'dusuk,normal,yuksek,acil',
        `ilgili_departman`VARCHAR(100) DEFAULT NULL,
        `ilgili_kisi`     VARCHAR(150) DEFAULT NULL,
        `son_tarih`          DATE DEFAULT NULL,
        `gecerlilik_tarihi`  DATE DEFAULT NULL,
        `hatirlatma_gun`     INT DEFAULT NULL,
        `hatirlatma_gonderildi` TINYINT(1) DEFAULT 0,
        `dosya_adi`          VARCHAR(255) DEFAULT NULL,
        `dosya_yol`       VARCHAR(500) DEFAULT NULL,
        `dosya_boyut`     INT DEFAULT NULL,
        `dosya_tip`       VARCHAR(50) DEFAULT NULL,
        `etiketler`       VARCHAR(300) DEFAULT NULL,
        `notlar`          TEXT,
        `olusturan_id`    INT DEFAULT NULL,
        `olusturan_adi`   VARCHAR(150) DEFAULT NULL,
        `onaylayan_id`    INT DEFAULT NULL,
        `onaylayan_adi`   VARCHAR(150) DEFAULT NULL,
        `onay_tarihi`     DATETIME DEFAULT NULL,
        `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
        `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_durum` (`durum`),
        INDEX `idx_kategori` (`kategori`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

$islem = $_POST['islem'] ?? '';

try {
    if ($islem === 'ekle' || $islem === 'guncelle') {
        $id_upd  = (int)($_POST['id'] ?? 0);
        $baslik  = trim($_POST['baslik'] ?? '');
        $kat     = $_POST['kategori'] ?? 'genel';
        $ack     = trim($_POST['aciklama'] ?? '');
        $durum   = $_POST['durum'] ?? 'bekliyor';
        $onc     = $_POST['oncelik'] ?? 'normal';
        $dept    = trim($_POST['ilgili_departman'] ?? '');
        $kisi    = trim($_POST['ilgili_kisi'] ?? '');
        $son_tar  = !empty($_POST['son_tarih']) ? $_POST['son_tarih'] : null;
        $gec_tar  = !empty($_POST['gecerlilik_tarihi']) ? $_POST['gecerlilik_tarihi'] : null;
        $hat_gun  = !empty($_POST['hatirlatma_gun']) ? (int)$_POST['hatirlatma_gun'] : null;
        $etiket   = trim($_POST['etiketler'] ?? '');
        $notlar   = trim($_POST['notlar'] ?? '');

        if (!$baslik) { echo json_encode(['ok'=>false,'hata'=>'Başlık zorunlu']); exit; }

        // Dosya yükleme
        $dosya_adi = $dosya_yol = $dosya_tip = null;
        $dosya_boyut = null;

        if (!empty($_FILES['dosya']['name'])) {
            $upload_dir = ROOT_DIR . '/bolumler/idari/yuklenen_dosyalar/evraklar/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $orig_adi  = $_FILES['dosya']['name'];
            $dosya_tip = $_FILES['dosya']['type'];
            $dosya_boyut = $_FILES['dosya']['size'];
            $ext       = strtolower(pathinfo($orig_adi, PATHINFO_EXTENSION));
            $izin_ext  = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png','zip','rar'];

            if (!in_array($ext, $izin_ext)) { echo json_encode(['ok'=>false,'hata'=>'Desteklenmeyen dosya türü: '.$ext]); exit; }
            if ($dosya_boyut > 20*1024*1024) { echo json_encode(['ok'=>false,'hata'=>'Dosya 20MB sınırını aşıyor']); exit; }

            $dosya_adi = uniqid('EVR_') . '.' . $ext;
            $hedef = $upload_dir . $dosya_adi;
            if (!move_uploaded_file($_FILES['dosya']['tmp_name'], $hedef)) {
                echo json_encode(['ok'=>false,'hata'=>'Dosya yüklenemedi']); exit;
            }
            $dosya_yol = 'bolumler/idari/yuklenen_dosyalar/evraklar/' . $dosya_adi;
        }

        if ($islem === 'ekle') {
            // Evrak no oluştur
            $son = $db->query("SELECT MAX(id) FROM evraklar")->fetchColumn();
            $evrak_no = 'EVR-' . date('Y') . '-' . str_pad(((int)$son + 1), 4, '0', STR_PAD_LEFT);

            $db->prepare("INSERT INTO evraklar (evrak_no,baslik,kategori,aciklama,durum,oncelik,
                ilgili_departman,ilgili_kisi,son_tarih,gecerlilik_tarihi,hatirlatma_gun,
                dosya_adi,dosya_yol,dosya_boyut,dosya_tip,
                etiketler,notlar,olusturan_id,olusturan_adi)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$evrak_no,$baslik,$kat,$ack,$durum,$onc,$dept,$kisi,$son_tar,
                          $gec_tar,$hat_gun,
                          $dosya_adi,$dosya_yol,$dosya_boyut,$dosya_tip,$etiket,$notlar,$uid,$uadi]);
            echo json_encode(['ok'=>true,'id'=>$db->lastInsertId(),'evrak_no'=>$evrak_no]);
        } else {
            $set = "baslik=?,kategori=?,aciklama=?,durum=?,oncelik=?,ilgili_departman=?,ilgili_kisi=?,son_tarih=?,gecerlilik_tarihi=?,hatirlatma_gun=?,etiketler=?,notlar=?";
            $params = [$baslik,$kat,$ack,$durum,$onc,$dept,$kisi,$son_tar,$gec_tar,$hat_gun,$etiket,$notlar];
            if ($dosya_adi) {
                $set .= ",dosya_adi=?,dosya_yol=?,dosya_boyut=?,dosya_tip=?";
                $params = array_merge($params, [$dosya_adi,$dosya_yol,$dosya_boyut,$dosya_tip]);
            }
            // Onay
            if ($durum === 'onaylandi') {
                $set .= ",onaylayan_id=?,onaylayan_adi=?,onay_tarihi=NOW()";
                $params[] = $uid; $params[] = $uadi;
            }
            $params[] = $id_upd;
            $db->prepare("UPDATE evraklar SET $set WHERE id=?")->execute($params);
            echo json_encode(['ok'=>true,'id'=>$id_upd]);
        }
    } elseif ($islem === 'sil') {
        $id_sil = (int)($_POST['id'] ?? 0);
        $row = $db->prepare("SELECT dosya_yol FROM evraklar WHERE id=? LIMIT 1");
        $row->execute([$id_sil]); $row = $row->fetch();
        if ($row && $row['dosya_yol']) {
            $tam = ROOT_DIR . '/' . $row['dosya_yol'];
            if (file_exists($tam)) unlink($tam);
        }
        $db->prepare("DELETE FROM evraklar WHERE id=?")->execute([$id_sil]);
        echo json_encode(['ok'=>true]);
    } elseif ($islem === 'durum') {
        $id_d  = (int)($_POST['id'] ?? 0);
        $dur   = $_POST['durum'] ?? '';
        $params = [$dur];
        $set = "durum=?";
        if ($dur === 'onaylandi') {
            $set .= ",onaylayan_id=?,onaylayan_adi=?,onay_tarihi=NOW()";
            $params[] = $uid; $params[] = $uadi;
        }
        $params[] = $id_d;
        $db->prepare("UPDATE evraklar SET $set WHERE id=?")->execute($params);
        echo json_encode(['ok'=>true]);
    } else {
        echo json_encode(['ok'=>false,'hata'=>'Geçersiz işlem']);
    }
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
