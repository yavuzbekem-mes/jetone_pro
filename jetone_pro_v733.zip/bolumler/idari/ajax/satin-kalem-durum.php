<?php
// Tüm output'u yakala - PHP hata mesajları JSON'u bozmasın
ob_start();
@ini_set('display_errors', 0);
@ini_set('log_errors', 1);
@error_reporting(0);

try {
    require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
    require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
    require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
} catch (Throwable $boot_err) {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'hata'=>'Sistem hatasi: '.$boot_err->getMessage()]);
    exit;
}
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
$user     = Auth::kullanici();
$uid_c    = (int)($user['id'] ?? 0);
$rol_id_c = (int)($user['rol_id'] ?? 0);
$u_adi    = trim(($user['ad_soyad'] ?? '') ?: '');

// Yetki kontrolü — geniş kontrol
$yetkili = false;
try {
    // 1. Sistem rolü (sistem_rol=1)
    $sis = $db->prepare("SELECT sistem_rol FROM roller WHERE id=? LIMIT 1");
    $sis->execute([$rol_id_c]);
    $is_sis = (int)($sis->fetchColumn() ?: 0);
    if ($rol_id_c <= 2) $is_sis = 1; // ilk 2 rol her zaman sistem (Süper Admin, Yönetici)
    if ($is_sis === 1) { $yetkili = true; }

    if (!$yetkili) {
        // 2. Personel departman veya pozisyon/unvan kontrolü
        $per_row = $db->prepare(
            "SELECT d.ad dept, p.pozisyon, p.unvan FROM personeller p
             LEFT JOIN departmanlar d ON p.departman_id=d.id
             WHERE p.kullanici_id=? AND p.durum='aktif' LIMIT 1"
        );
        $per_row->execute([$uid_c]);
        $per = $per_row->fetch();
        if ($per) {
            $dept_n = $per['dept'] ?? '';
            $poz_n  = ($per['pozisyon'] ?? '') . ' ' . ($per['unvan'] ?? '');
            $yetkili = stripos($dept_n,'satın')!==false || stripos($dept_n,'satin')!==false
                    || stripos($dept_n,'idari')!==false
                    || stripos($poz_n,'müdür')!==false   || stripos($poz_n,'mudur')!==false
                    || stripos($poz_n,'sorumlu')!==false || stripos($poz_n,'yönetici')!==false;
        }
    }

    if (!$yetkili) {
        // 3. Kullanicilar tablosundaki email / ad bazlı fallback
        // (personeller tablosunda kullanici_id bağlantısı kurulmamış olabilir)
        // Rol ID'si 1 veya 2 ise (Süper Admin, Yönetici) her zaman yetkili
        if ($rol_id_c <= 3) $yetkili = true;
    }
} catch (Throwable $e) {
    // Hata durumunda rol_id'ye göre karar ver
    $yetkili = ($rol_id_c <= 3);
}
if (!$yetkili) { echo json_encode(['ok'=>false,'hata'=>'Yetkisiz islem']); exit; }

$d        = json_decode(file_get_contents('php://input'), true) ?: [];
$talep_id = (int)($d['talep_id'] ?? 0);
$durum    = $d['durum'] ?? 'bekliyor';
$toplu    = !empty($d['toplu']);
$kalem_not = trim($d['not'] ?? '');
$gecerli  = ['bekliyor','onaylandi','reddedildi','tedarik_edildi'];

if (!$talep_id || !in_array($durum, $gecerli)) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz parametre']); exit;
}

try {
    if ($toplu) {
        $db->prepare("UPDATE satin_alma_kalemler SET kalem_durum=? WHERE talep_id=?")
           ->execute([$durum, $talep_id]);
    } else {
        $kalem_id = (int)($d['kalem_id'] ?? 0);
        if (!$kalem_id) { echo json_encode(['ok'=>false,'hata'=>'Kalem ID gerekli']); exit; }
        $db->prepare("UPDATE satin_alma_kalemler SET kalem_durum=?, kalem_notu=? WHERE id=?")
           ->execute([$durum, $kalem_not ?: null, $kalem_id]);
    }

    // Kalem bazlı onay/red sonrası geçmiş ve mail
    $durum_etiket = ['onaylandi'=>'Onaylandı','reddedildi'=>'Reddedildi',
                     'tedarik_edildi'=>'Tedarik Edildi','bekliyor'=>'Bekliyor'][$durum] ?? $durum;
    $not_str = $toplu ? "Tüm kalemler: $durum_etiket" : "Kalem #".($d['kalem_id']??'?').": $durum_etiket";
    if ($kalem_not) $not_str .= " — $kalem_not";

    // Geçmiş kaydı
    $db->prepare("INSERT INTO satin_alma_gecmis (talep_id,kullanici_id,kullanici_adi,eski_durum,yeni_durum,not_metni)
        VALUES (?,?,?,?,?,?)")
       ->execute([$talep_id, $uid_c, $u_adi ?: 'Yetkili', 'kalem_guncelleme', "kalem_$durum", $not_str]);

    // Satır bazlı onay/red — mail atılmaz, sadece geçmiş kaydı
    // Mail ve bildirim, "Onaya Al" veya durum değişiminde satin-durum-guncelle.php'den gönderilir

    echo json_encode(['ok'=>true]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
