<?php
/**
 * AJAX — Son 24 saat irsaliyeleri Tiger'dan çek
 * GET /bolumler/idari/ajax/guvenlik_arac_irs.php
 */
ob_start();
$root = dirname(dirname(dirname(__DIR__)));
require_once $root . '/core/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/auth.php';
require_once $root . '/core/baglanlogo.php';
ob_end_clean();

header('Content-Type: application/json; charset=utf-8');
if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false]); exit; }

$irsaliyeler = [];
$irs_map     = [];

if ($tigerdb_pdo) {
    try {
        $rows = $tigerdb_pdo->query("
            SELECT DISTINCT
                STF.FICHENO          AS irsaliye_no,
                CL.DEFINITION_       AS musteri,
                CONVERT(varchar,STF.DATE_,104) AS tarih
            FROM dbo.LG_222_02_STFICHE STF WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STF.CLIENTREF
            WHERE STF.TRCODE IN (8)
              AND STF.DATE_ >= DATEADD(HOUR,-24,GETDATE())
            UNION ALL
            SELECT DISTINCT
                STF.FICHENO,
                CL.DEFINITION_,
                CONVERT(varchar,STF.DATE_,104)
            FROM dbo.LG_222_01_STFICHE STF WITH(NOLOCK)
            LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STF.CLIENTREF
            WHERE STF.TRCODE IN (8)
              AND STF.DATE_ >= DATEADD(HOUR,-24,GETDATE())
            ORDER BY irsaliye_no DESC
        ")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $r) {
            $irsaliyeler[] = [
                'irsaliye_no' => $r['irsaliye_no'],
                'musteri'     => $r['musteri'] ?? '',
                'tarih'       => $r['tarih'] ?? '',
            ];
            $irs_map[$r['irsaliye_no']] = $r['musteri'] ?? '';
        }
    } catch(Throwable $e) {}
}

// Bugün zaten bağlanmış irsaliyeler
$bagli = [];
try {
    $rows2 = $db->query("
        SELECT irsaliye_no FROM guv_arac_giris_cikis
        WHERE irsaliye_no IS NOT NULL AND irsaliye_no!=''
          AND DATE(c_zaman) = CURDATE()
    ")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($rows2 as $irs) $bagli[$irs] = 1;
} catch(Throwable $e) {}

echo json_encode([
    'ok'          => true,
    'irsaliyeler' => $irsaliyeler,
    'irs_map'     => $irs_map,
    'bagli'       => $bagli,
    'sayi'        => count($irsaliyeler),
]);
