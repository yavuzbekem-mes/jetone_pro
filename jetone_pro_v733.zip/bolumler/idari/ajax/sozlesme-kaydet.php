<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$fields = ['tip'=>$p['tip']??'tedarik','konu'=>trim($p['konu']??''),'taraf_adi'=>trim($p['taraf_adi']??''),'taraf_email'=>trim($p['taraf_email']??''),'baslangic'=>(!empty($p['baslangic']) ? $p['baslangic'] : null),'bitis'=>(!empty($p['bitis']) ? $p['bitis'] : null),'sure_ay'=>(($tmp=(int)($p['sure_ay']??0)) !== 0 ? $tmp : null),'tutar'=>(($tmp=(float)($p['tutar']??0)) !== 0.0 ? $tmp : null),'para_birimi'=>$p['para_birimi']??'TRY','yenileme'=>(int)($p['yenileme']??0),'hatirlatma_gun'=>(int)($p['hatirlatma_gun']??30),'durum'=>$p['durum']??'taslak','teklif_id'=>(($tmp=(int)($p['teklif_id']??0)) !== 0 ? $tmp : null),'notlar'=>trim($p['notlar']??'')];
if (!$fields['konu'] || !$fields['taraf_adi']) { echo json_encode(['ok'=>false,'hata'=>'Konu ve taraf adi zorunlu']); exit; }
// null string to null
foreach ($fields as $k=>$v) if ($v === '') $fields[$k] = null;
try {
    if ($id) {
        $set = implode('=?,', array_keys($fields)).'=?';
        $vals = array_values($fields); $vals[] = $id;
        $db->prepare("UPDATE sozlesmeler SET $set WHERE id=?")->execute($vals);
    } else {
        $son = $db->query("SELECT MAX(id) FROM sozlesmeler")->fetchColumn();
        $no = 'SZL-'.date('Y').'-'.str_pad(($son+1),4,'0',STR_PAD_LEFT);
        $fields['sozlesme_no'] = $no; $fields['olusturan_id'] = $user['id']??null;
        $cols = implode(',', array_keys($fields));
        $phs = implode(',', array_fill(0, count($fields), '?'));
        $db->prepare("INSERT INTO sozlesmeler ($cols) VALUES ($phs)")->execute(array_values($fields));
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
