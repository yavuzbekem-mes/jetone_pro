<?php
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$id     = (int)($_POST['id'] ?? 0);
$tarih  = $_POST['tarih'] ?? '';
$corba  = $_POST['corba']  ?? '';
$yemek1 = $_POST['yemek1'] ?? '';
$yemek2 = $_POST['yemek2'] ?? '';
$yemek3 = $_POST['yemek3'] ?? '';
$tatli  = $_POST['tatli']  ?? '';
$kalori = (int)($_POST['kalori'] ?? 0);
$notlar = $_POST['notlar'] ?? '';

if (!$tarih) { echo json_encode(['ok'=>false,'hata'=>'Tarih yok']); exit; }

try {
    if ($id) {
        $db->prepare("UPDATE yemek_menuler SET corba=?,yemek1=?,yemek2=?,yemek3=?,tatli=?,kalori=?,notlar=? WHERE id=?")
           ->execute([$corba,$yemek1,$yemek2,$yemek3,$tatli,$kalori?:null,$notlar,$id]);
    } else {
        $db->prepare("INSERT INTO yemek_menuler (tarih,ogun,corba,yemek1,yemek2,yemek3,tatli,kalori,notlar,olusturan_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE corba=VALUES(corba),yemek1=VALUES(yemek1),yemek2=VALUES(yemek2),yemek3=VALUES(yemek3),tatli=VALUES(tatli),kalori=VALUES(kalori),notlar=VALUES(notlar)")
           ->execute([$tarih,'oglen',$corba,$yemek1,$yemek2,$yemek3,$tatli,$kalori?:null,$notlar,(Auth::kullanici())['id']??null]);
        $id = (int)$db->lastInsertId() ?: $id;
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
