<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$id          = (int)($_POST['id'] ?? 0);
$plaka       = strtoupper(trim($_POST['plaka'] ?? ''));
$marka       = trim($_POST['marka'] ?? '');
$model       = trim($_POST['model'] ?? '');
$yil         = (int)($_POST['yil'] ?? 0) ?: null;
$renk        = trim($_POST['renk'] ?? '');
$cins        = trim($_POST['cins'] ?? '');
$yakit_tipi  = $_POST['yakit_tipi'] ?? 'dizel';
$motor_no    = trim($_POST['motor_no'] ?? '');
$sasi_no     = trim($_POST['sasi_no'] ?? '');
$ruhsat      = trim($_POST['ruhsat_sahibi'] ?? '');
$km          = (int)($_POST['km_guncel'] ?? 0);
$durum       = $_POST['durum'] ?? 'aktif';
$sorumlu_id  = (int)($_POST['sorumlu_id'] ?? 0) ?: null;
$muayene     = $_POST['muayene_bitis'] ?: null;
$sigorta     = $_POST['sigorta_bitis'] ?: null;
$kasko       = $_POST['kasko_bitis'] ?: null;
$egzos       = $_POST['egzos_bitis'] ?: null;
$notlar      = trim($_POST['notlar'] ?? '');

if (!$plaka) { echo json_encode(['ok'=>false,'hata'=>'Plaka zorunlu']); exit; }

try {
    if ($id) {
        $db->prepare("UPDATE araclar SET plaka=?,marka=?,model=?,yil=?,renk=?,cins=?,yakit_tipi=?,
            motor_no=?,sasi_no=?,ruhsat_sahibi=?,km_guncel=?,durum=?,sorumlu_id=?,
            muayene_bitis=?,sigorta_bitis=?,kasko_bitis=?,egzos_bitis=?,notlar=? WHERE id=?")
           ->execute([$plaka,$marka,$model,$yil,$renk,$cins,$yakit_tipi,$motor_no,$sasi_no,
                     $ruhsat,$km,$durum,$sorumlu_id,$muayene,$sigorta,$kasko,$egzos,$notlar,$id]);
    } else {
        $db->prepare("INSERT INTO araclar (plaka,marka,model,yil,renk,cins,yakit_tipi,motor_no,sasi_no,
            ruhsat_sahibi,km_guncel,durum,sorumlu_id,muayene_bitis,sigorta_bitis,kasko_bitis,egzos_bitis,notlar)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$plaka,$marka,$model,$yil,$renk,$cins,$yakit_tipi,$motor_no,$sasi_no,
                     $ruhsat,$km,$durum,$sorumlu_id,$muayene,$sigorta,$kasko,$egzos,$notlar]);
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
