<?php
/**
 * Evrak Hatırlatma Mail Gönderici
 * URL: /bolumler/idari/ajax/evrak-hatirlatma.php
 * Cron veya panel'den manuel tetiklenebilir
 * Cron: 0 8 * * * php /path/to/evrak-hatirlatma.php
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean();

// CLI veya yetkili kullanıcı
$is_cli = (php_sapi_name() === 'cli');
if (!$is_cli) {
    header('Content-Type: application/json; charset=utf-8');
    Auth::zorunlu();
}

try {
    // Tablo yoksa çık
    $tbl = $db->query("SHOW TABLES LIKE 'evraklar'")->fetch();
    if (!$tbl) { echo json_encode(['ok'=>true,'gonderilen'=>0,'mesaj'=>'Tablo yok']); exit; }

    // Bugün hatırlatma yapılması gereken evrakları bul
    $bugun = date('Y-m-d');
    $q = $db->query("SELECT * FROM evraklar
        WHERE gecerlilik_tarihi IS NOT NULL
          AND hatirlatma_gun IS NOT NULL
          AND hatirlatma_gonderildi = 0
          AND durum NOT IN ('arsivlendi','reddedildi')
          AND DATE_SUB(gecerlilik_tarihi, INTERVAL hatirlatma_gun DAY) <= '$bugun'
          AND gecerlilik_tarihi >= '$bugun'");
    $evraklar = $q->fetchAll();

    if (empty($evraklar)) {
        echo json_encode(['ok'=>true,'gonderilen'=>0,'mesaj'=>'Hatırlatma gereken evrak yok']);
        exit;
    }

    // Mail alıcıları: İdari + Satınalma departmanı + ayarlar_kv
    $alicilar = [];
    $alici_detay = []; // isim + mail listesi için
    try {
        $dept_rows = $db->query("SELECT DISTINCT p.email, CONCAT(p.ad,' ',p.soyad) isim, d.ad dept
            FROM personeller p
            JOIN departmanlar d ON p.departman_id=d.id
            WHERE p.durum='aktif' AND p.email IS NOT NULL AND p.email != ''
              AND (d.ad LIKE '%İdari%' OR d.ad LIKE '%Idari%'
                   OR d.ad LIKE '%Satın%' OR d.ad LIKE '%Satin%'
                   OR d.ad LIKE '%Satinalma%')")->fetchAll();
        foreach ($dept_rows as $dr) {
            $alicilar[] = $dr['email'];
            $alici_detay[] = ['isim'=>$dr['isim'], 'email'=>$dr['email'], 'dept'=>$dr['dept']];
        }
    } catch(Throwable $e) {}

    // Ayarlar kv'den fallback
    try {
        $fb1 = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='idari_sorumlu_mail' LIMIT 1")->fetchColumn();
        $fb2 = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='satin_mudur_mail' LIMIT 1")->fetchColumn();
        $fb3 = $db->query("SELECT kullanici FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1")->fetchColumn();
        if ($fb1) $alicilar[] = $fb1;
        if ($fb2) $alicilar[] = $fb2;
        if ($fb3) $alicilar[] = $fb3;
    } catch(Throwable $e) {}

    $alicilar = array_values(array_unique(array_filter($alicilar, function($m){ return filter_var($m, FILTER_VALIDATE_EMAIL); })));

    if (empty($alicilar)) {
        echo json_encode(['ok'=>false,'hata'=>'Mail alıcısı bulunamadı']);
        exit;
    }

    // SMTP ayarları
    require_once dirname(__DIR__) . '/ajax/satin-mail.php'; // PHPMailer loader

    $gonderilen = 0;
    foreach ($evraklar as $evrak) {
        $kalan_gun = (int)((strtotime($evrak['gecerlilik_tarihi']) - time()) / 86400);
        $gec_fmt   = date('d.m.Y', strtotime($evrak['gecerlilik_tarihi']));
        $hat_gun   = (int)$evrak['hatirlatma_gun'];

        $konu  = "⚠️ Evrak Geçerlilik Hatırlatması: {$evrak['baslik']}";
        $icerik = "
        <div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px'>
          <div style='background:#F97316;color:#fff;padding:16px 20px;border-radius:10px 10px 0 0'>
            <h2 style='margin:0;font-size:18px'>⚠️ Evrak Geçerlilik Hatırlatması</h2>
          </div>
          <div style='background:#fff;border:1px solid #E5E7EB;border-top:none;padding:20px;border-radius:0 0 10px 10px'>
            <table style='width:100%;border-collapse:collapse;font-size:14px'>
              <tr style='background:#F9FAFB'><td style='padding:8px 12px;font-weight:700;width:40%'>Evrak No</td><td style='padding:8px 12px'>{$evrak['evrak_no']}</td></tr>
              <tr><td style='padding:8px 12px;font-weight:700'>Başlık</td><td style='padding:8px 12px'>{$evrak['baslik']}</td></tr>
              <tr style='background:#F9FAFB'><td style='padding:8px 12px;font-weight:700'>Geçerlilik Tarihi</td><td style='padding:8px 12px;color:#EF4444;font-weight:700'>{$gec_fmt}</td></tr>
              <tr><td style='padding:8px 12px;font-weight:700'>Kalan Gün</td><td style='padding:8px 12px;color:#F97316;font-weight:800'>{$kalan_gun} gün</td></tr>
              <tr style='background:#F9FAFB'><td style='padding:8px 12px;font-weight:700'>Kategori</td><td style='padding:8px 12px'>{$evrak['kategori']}</td></tr>
              " . ($evrak['ilgili_kisi'] ? "<tr><td style='padding:8px 12px;font-weight:700'>İlgili Kişi</td><td style='padding:8px 12px'>{$evrak['ilgili_kisi']}</td></tr>" : "") . "
              " . ($evrak['aciklama'] ? "<tr style='background:#F9FAFB'><td style='padding:8px 12px;font-weight:700'>Açıklama</td><td style='padding:8px 12px'>{$evrak['aciklama']}</td></tr>" : "") . "
            </table>
            <div style='margin-top:16px;padding:12px;background:#FEF3C7;border-radius:8px;font-size:13px;color:#92400E'>
              Bu evrak <strong>{$hat_gun} gün</strong> içinde geçerlilik süresini dolduracak. Gerekli işlemlerin yapılması önerilir.
            </div>
            <div style='margin-top:12px;font-size:11px;color:#9CA3AF;text-align:center'>
              Bu mail Jetone ERP tarafından otomatik gönderilmiştir. • " . date('d.m.Y H:i') . "
            </div>
          </div>
        </div>";

        // Mail gönder (satin-mail.php'deki _smtpGonder fonksiyonu varsa kullan)
        $mail_ok = false;
        try {
            if (function_exists('_smtpGonder')) {
                $mail_ok = _smtpGonder($alicilar, $konu, $icerik, $db);
            } else {
                // Fallback: mail() fonksiyonu
                $headers  = "MIME-Version: 1.0\r\n";
                $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                $headers .= "From: Jetone ERP <noreply@jetone.pro>\r\n";
                foreach ($alicilar as $al) { mail($al, $konu, $icerik, $headers); }
                $mail_ok = true;
            }
        } catch(Throwable $e2) {}

        if ($mail_ok) {
            $db->prepare("UPDATE evraklar SET hatirlatma_gonderildi=1 WHERE id=?")->execute([$evrak['id']]);
            $gonderilen++;
        }
    }

    $evrak_detay = [];
    foreach ($evraklar as $ev) {
        $kalan = (int)((strtotime($ev['gecerlilik_tarihi']) - time()) / 86400);
        $evrak_detay[] = ['evrak_no'=>$ev['evrak_no'], 'baslik'=>$ev['baslik'], 'kalan_gun'=>$kalan];
    }
    echo json_encode([
        'ok'       => true,
        'gonderilen'=> $gonderilen,
        'toplam'   => count($evraklar),
        'alicilar' => $alicilar,
        'alici_detay' => $alici_detay,
        'evraklar' => $evrak_detay,
        'mesaj'    => $gonderilen > 0
            ? "$gonderilen evrak için ".count($alicilar)." kişiye hatırlatma maili gönderildi"
            : "Gönderilecek evrak yok (toplam: ".count($evraklar).")"
    ]);

} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
