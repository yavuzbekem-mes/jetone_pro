<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);

$adlar      = $p['k_adi'] ?? [];
$miktarlar  = $p['k_miktar'] ?? [];
$birimler   = $p['k_birim'] ?? [];
$fiyatlar   = $p['k_birim_fiyat'] ?? [];
$kdvler     = $p['k_kdv'] ?? [];
$indirimler = $p['k_indirim'] ?? [];

$kalemler = [];
$toplam = 0;
foreach ($adlar as $i => $adi) {
    if (!trim($adi)) continue;
    $m = (float)($miktarlar[$i] ?? 1);
    $f = (float)($fiyatlar[$i] ?? 0);
    $kdv = (float)($kdvler[$i] ?? 20);
    $ind = (float)($indirimler[$i] ?? 0);
    $sat = $m * $f * (1 - $ind/100);
    $sat_kdv = $sat * $kdv / 100;
    $top = $sat + $sat_kdv;
    $toplam += $top;
    $kalemler[] = ['sira'=>$i+1,'urun_adi'=>trim($adi),'miktar'=>$m,'birim'=>$birimler[$i]??'Adet','birim_fiyat'=>$f,'kdv_oran'=>(int)$kdv,'indirim_oran'=>$ind,'toplam'=>round($top,2)];
}

try {
    $db->beginTransaction();
    if ($id) {
        $db->prepare("UPDATE teklifler SET tip=?,konu=?,tedarikci_adi=?,tedarikci_email=?,tedarikci_tel=?,gecerlilik_tarihi=?,para_birimi=?,kdv_dahil=?,durum=?,notlar=?,toplam_tutar=? WHERE id=?")
           ->execute([$p['tip']??'alinan',trim($p['konu']??''),trim($p['tedarikci_adi']??''),trim($p['tedarikci_email']??''),trim($p['tedarikci_tel']??''),(!empty($p['gecerlilik_tarihi']) ? $p['gecerlilik_tarihi'] : null),$p['para_birimi']??'TRY',(int)($p['kdv_dahil']??1),$p['durum']??'taslak',trim($p['notlar']??''),round($toplam,2),$id]);
        $db->prepare("DELETE FROM teklif_kalemleri WHERE teklif_id=?")->execute([$id]);
    } else {
        $son = $db->query("SELECT MAX(id) FROM teklifler")->fetchColumn();
        $no = 'TKL-'.date('Y').'-'.str_pad(($son+1),4,'0',STR_PAD_LEFT);
        $db->prepare("INSERT INTO teklifler (teklif_no,tip,konu,tedarikci_adi,tedarikci_email,tedarikci_tel,gecerlilik_tarihi,para_birimi,kdv_dahil,durum,notlar,toplam_tutar,olusturan_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$no,$p['tip']??'alinan',trim($p['konu']??''),trim($p['tedarikci_adi']??''),trim($p['tedarikci_email']??''),trim($p['tedarikci_tel']??''),(!empty($p['gecerlilik_tarihi']) ? $p['gecerlilik_tarihi'] : null),$p['para_birimi']??'TRY',(int)($p['kdv_dahil']??1),$p['durum']??'taslak',trim($p['notlar']??''),round($toplam,2),$user['id']??null]);
        $id = (int)$db->lastInsertId();
    }
    $stmt = $db->prepare("INSERT INTO teklif_kalemleri (teklif_id,sira,urun_adi,miktar,birim,birim_fiyat,kdv_oran,indirim_oran,toplam) VALUES (?,?,?,?,?,?,?,?,?)");
    foreach ($kalemler as $k) $stmt->execute([$id,$k['sira'],$k['urun_adi'],$k['miktar'],$k['birim'],$k['birim_fiyat'],$k['kdv_oran'],$k['indirim_oran'],$k['toplam']]);
    $db->commit();
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { $db->rollBack(); echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
