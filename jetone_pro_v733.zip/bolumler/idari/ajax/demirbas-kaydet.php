<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$adi = trim($p['adi'] ?? '');
if (!$adi) { echo json_encode(['ok'=>false,'hata'=>'Demirbaş adi zorunlu']); exit; }
$vals = [
    'adi'                => $adi,
    'kategori'           => trim($p['kategori']??'') ?: null,
    'marka'              => trim($p['marka']??'') ?: null,
    'model'              => trim($p['model']??'') ?: null,
    'seri_no'            => trim($p['seri_no']??'') ?: null,
    'barkod'             => trim($p['barkod']??'') ?: null,
    'konum'              => trim($p['konum']??'') ?: null,
    'durum'              => $p['durum']??'aktif',
    'zimmet_personel_id' => (($tmp=(int)($p['zimmet_personel_id']??0)) !== 0 ? $tmp : null),
    'zimmet_tarihi'      => $p['zimmet_tarihi']??null,
    'amortisman_yil'     => (($tmp=(int)($p['amortisman_yil']??0)) !== 0 ? $tmp : null),
    'satin_alma_tarihi'  => $p['satin_alma_tarihi']??null,
    'satin_alma_tutar'   => (($tmp=(float)($p['satin_alma_tutar']??0)) !== 0.0 ? $tmp : null),
    'tedarikci'          => trim($p['tedarikci']??'') ?: null,
    'garanti_bitis'      => $p['garanti_bitis']??null,
    'notlar'             => trim($p['notlar']??'') ?: null,
];
foreach ($vals as $k=>$v) if ($v === '') $vals[$k] = null;
try {
    if ($id) {
        $set = implode('=?,', array_keys($vals)).'=?';
        $v2 = array_values($vals); $v2[] = $id;
        $db->prepare("UPDATE demirbaslar SET $set WHERE id=?")->execute($v2);
    } else {
        $vals['olusturan_id'] = $user['id']??null;
        $cols = implode(',', array_keys($vals));
        $phs  = implode(',', array_fill(0, count($vals),'?'));
        $db->prepare("INSERT INTO demirbaslar ($cols) VALUES ($phs)")->execute(array_values($vals));
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
