<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$uid  = (int)$user['id'];

$d = json_decode(file_get_contents('php://input'), true) ?: [];
$islem = $d['islem'] ?? (empty($d['id']) ? 'ekle' : 'guncelle');

try {
    if ($islem === 'sil') {
        $db->prepare("DELETE FROM etkinlikler WHERE id=?")->execute([(int)$d['id']]);
        echo json_encode(['ok'=>true]); exit;
    }

    $baslik     = trim($d['baslik'] ?? '');
    $tarih      = $d['tarih'] ?? '';
    $saat       = !empty($d['saat']) ? $d['saat'] : null;
    $tur        = $d['tur'] ?? 'ozel';
    $durum      = $d['durum'] ?? 'planli';
    $ilgili_id  = !empty($d['ilgili_id']) ? (int)$d['ilgili_id'] : null;
    $ilgili_adi = trim($d['ilgili_adi'] ?? '');
    $aciklama   = trim($d['aciklama'] ?? '');

    if (!$baslik || !$tarih) { echo json_encode(['ok'=>false,'hata'=>'Başlık ve tarih zorunlu']); exit; }

    $renk_map = ['dogum_gunu'=>'#F97316','yildonumu'=>'#8B5CF6','toplanti'=>'#3B82F6','kutlama'=>'#10B981','ozel'=>'#F59E0B'];
    $renk = $renk_map[$tur] ?? '#F59E0B';

    $id_upd = (int)($d['id'] ?? 0);
    if ($id_upd) {
        $db->prepare("UPDATE etkinlikler SET baslik=?,tarih=?,saat=?,tur=?,durum=?,
            ilgili_id=?,ilgili_adi=?,aciklama=?,renk=? WHERE id=?")
           ->execute([$baslik,$tarih,$saat,$tur,$durum,$ilgili_id,$ilgili_adi,$aciklama,$renk,$id_upd]);
    } else {
        $db->prepare("INSERT INTO etkinlikler (baslik,tarih,saat,tur,durum,ilgili_id,ilgili_adi,aciklama,renk,olusturan_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)")
           ->execute([$baslik,$tarih,$saat,$tur,$durum,$ilgili_id,$ilgili_adi,$aciklama,$renk,$uid]);
    }
    echo json_encode(['ok'=>true]);
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
