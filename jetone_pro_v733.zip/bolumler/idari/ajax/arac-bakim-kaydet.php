<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$arac_id = (int)($p['arac_id']??0);
$islem_check = $p['islem'] ?? 'ekle';
if ($islem_check !== 'sil' && $islem_check !== 'guncelle' && (!$arac_id || empty($p['tarih']))) {
    echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit;
}
try {
    $islem = $p['islem'] ?? 'ekle';
$id_upd = (int)($p['id'] ?? 0);

if ($islem === 'sil' && $id_upd) {
    $db->prepare("DELETE FROM arac_bakimlar WHERE id=?")->execute([$id_upd]);
    echo json_encode(['ok'=>true]); exit;
}

if ($islem === 'guncelle' && $id_upd) {
    $params_upd = [$p['bakim_tipi']??'diger',$p['tarih'],!empty($p['km'])?(int)$p['km']:null,trim($p['servis']??''),trim($p['yapilan_isler']??''),!empty($p['tutar'])?(float)$p['tutar']:null,!empty($p['sonraki_bakim_km'])?(int)$p['sonraki_bakim_km']:null];
    $params_upd[] = $id_upd;
    $db->prepare("UPDATE arac_bakimlar SET bakim_tipi=?,tarih=?,km=?,servis=?,yapilan_isler=?,tutar=?,sonraki_bakim_km=? WHERE id=?")->execute($params_upd);
    echo json_encode(['ok'=>true]); exit;
}

$db->prepare("INSERT INTO arac_bakimlar (arac_id,bakim_tipi,tarih,km,servis,yapilan_isler,tutar,sonraki_bakim_km,olusturan_id) VALUES (?,?,?,?,?,?,?,?,?)")
       ->execute([
    $arac_id,
    $p['bakim_tipi'] ?? 'diger',
    $p['tarih'],
    !empty($p['km']) ? (int)$p['km'] : null,
    trim($p['servis'] ?? ''),
    trim($p['yapilan_isler'] ?? ''),
    (isset($p['tutar']) && $p['tutar'] !== '') ? (float)$p['tutar'] : null,
    !empty($p['sonraki_bakim_km']) ? (int)$p['sonraki_bakim_km'] : null,
    $user['id'] ?? null
]);
    // KM güncelle
    if (!empty($p['km'])) $db->prepare("UPDATE araclar SET km_guncel=GREATEST(km_guncel,?) WHERE id=?")->execute([(int)$p['km'],$arac_id]);
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
