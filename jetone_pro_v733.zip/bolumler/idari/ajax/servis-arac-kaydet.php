<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$plaka = strtoupper(trim($p['plaka'] ?? ''));
if (!$plaka) { echo json_encode(['ok'=>false,'hata'=>'Plaka zorunlu']); exit; }
try {
    $vals = [$plaka, trim($p['marka']??'') ?: null, (int)($p['kapasite']??0), (int)($p['aktif']??1), (($tmp=(int)($p['surucu_id']??0)) !== 0 ? $tmp : null), trim($p['surucu_adi']??'') ?: null, trim($p['surucu_tel']??'') ?: null];
    if ($id) {
        $db->prepare("UPDATE servis_araclar SET plaka=?,marka=?,kapasite=?,aktif=?,surucu_id=?,surucu_adi=?,surucu_tel=? WHERE id=?")->execute(array_merge($vals,[$id]));
    } else {
        $db->prepare("INSERT INTO servis_araclar (plaka,marka,kapasite,aktif,surucu_id,surucu_adi,surucu_tel) VALUES (?,?,?,?,?,?,?)")->execute($vals);
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
