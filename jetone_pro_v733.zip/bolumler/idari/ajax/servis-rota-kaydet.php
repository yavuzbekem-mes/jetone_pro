<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$ad = trim($p['ad'] ?? '');
if (!$ad) { echo json_encode(['ok'=>false,'hata'=>'Rota adi zorunlu']); exit; }
try {
    $vals = [$ad, $p['yon']??'her_iki', (int)($p['vardiya']??0)||null, (int)($p['arac_id']??0)||null, $p['kalkis_saati']??null, trim($p['notlar']??'')||null, (int)($p['aktif']??1)];
    if ($id) {
        $db->prepare("UPDATE servis_rotalar SET ad=?,yon=?,vardiya=?,arac_id=?,kalkis_saati=?,notlar=?,aktif=? WHERE id=?")->execute(array_merge($vals,[$id]));
    } else {
        $db->prepare("INSERT INTO servis_rotalar (ad,yon,vardiya,arac_id,kalkis_saati,notlar,aktif) VALUES (?,?,?,?,?,?,?)")->execute($vals);
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
