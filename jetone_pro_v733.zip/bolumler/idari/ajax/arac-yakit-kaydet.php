<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$p = $_POST;
$arac_id = (int)($p['arac_id']??0);
if (($p['islem']??'ekle') === 'sil') { $db->prepare('DELETE FROM arac_yakitlar WHERE id=?')->execute([(int)$p['id']]); echo json_encode(['ok'=>true]); exit; }
if (!$arac_id || empty($p['tarih']) || empty($p['litre'])) { echo json_encode(['ok'=>false,'hata'=>'Eksik alan']); exit; }
try {
    $islem = $p['islem'] ?? 'ekle';
$id_upd = (int)($p['id'] ?? 0);

if ($islem === 'sil' && $id_upd) {
    $db->prepare("DELETE FROM arac_yakitlar WHERE id=?")->execute([$id_upd]);
    echo json_encode(['ok'=>true]); exit;
}

if ($islem === 'guncelle' && $id_upd) {
    $params_upd = [$p['tarih'],(int)($p['km']??0),(float)($p['litre']??0),!empty($p['tutar'])?(float)$p['tutar']:null,trim($p['istasyon']??''),trim($p['surucu']??''),trim($p['notlar']??'')];
    $params_upd[] = $id_upd;
    $db->prepare("UPDATE arac_yakitlar SET tarih=?,km=?,litre=?,tutar=?,istasyon=?,surucu=?,notlar=? WHERE id=?")->execute($params_upd);
    echo json_encode(['ok'=>true]); exit;
}

$db->prepare("INSERT INTO arac_yakitlar (arac_id,tarih,km,litre,birim_fiyat,tutar,istasyon,surucu_id) VALUES (?,?,?,?,?,?,?,?)")
       ->execute([$arac_id,$p['tarih'],(int)($p['km']??0),(float)$p['litre'],(float)($p['birim_fiyat']??0)||null,(float)($p['tutar']??0)||null,trim($p['istasyon']??''),(int)($p['surucu_id']??0)||null]);
    if (!empty($p['km'])) $db->prepare("UPDATE araclar SET km_guncel=GREATEST(km_guncel,?) WHERE id=?")->execute([(int)$p['km'],$arac_id]);
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
