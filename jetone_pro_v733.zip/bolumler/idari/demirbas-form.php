<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$id = (int)($_GET['id'] ?? 0);
$d = null;
if ($id) { $q=$db->prepare("SELECT * FROM demirbaslar WHERE id=? LIMIT 1"); $q->execute([$id]); $d=$q->fetch(); }
$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();
$kategoriler = ['Bilgisayar','Telefon','Tablet','Yazici','Kamera','Ekipman','Mobilya','Arac','Klima','Beyaz Esya','Diger'];
$v = function($k,$def='') use ($d) { return htmlspecialchars($d[$k] ?? $def); };
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Demirbaş Duzenle' : 'Yeni Demirbaş Ekle'; ?></h1>
    <div class="s-yol">Idari / <a href="?sayfa=idari-demirbas-listesi" style="color:var(--t);text-decoration:none">Envanter</a> / <b><?php echo $id ? $v('adi') : 'Yeni'; ?></b></div>
  </div>
  <a href="?sayfa=idari-demirbas-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Geri</a>
</div>

<div class="s-body">
<form id="dbForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">Demirbaş Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">
    <div style="grid-column:1/3">
      <label class="form-etiket">Demirbaş Adi <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="adi" value="<?php echo $v('adi'); ?>" required>
    </div>
    <div>
      <label class="form-etiket">Kategori</label>
      <select class="form-alan" name="kategori">
        <option value="">— Seciniz —</option>
        <?php foreach ($kategoriler as $kat): ?>
        <option value="<?php echo $kat; ?>" <?php echo $v('kategori')===$kat?'selected':''; ?>><?php echo $kat; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Durum</label>
      <select class="form-alan" name="durum">
        <?php foreach (['aktif'=>'Aktif','zimmetli'=>'Zimmetli','depoda'=>'Depoda','bakimda'=>'Bakimda','hurdaya_ayrildi'=>'Hurda'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($d['durum']??'aktif')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-etiket">Marka</label>
      <input type="text" class="form-alan" name="marka" value="<?php echo $v('marka'); ?>">
    </div>
    <div>
      <label class="form-etiket">Model</label>
      <input type="text" class="form-alan" name="model" value="<?php echo $v('model'); ?>">
    </div>
    <div>
      <label class="form-etiket">Seri No</label>
      <input type="text" class="form-alan" name="seri_no" value="<?php echo $v('seri_no'); ?>">
    </div>
    <div>
      <label class="form-etiket">Barkod</label>
      <input type="text" class="form-alan" name="barkod" value="<?php echo $v('barkod'); ?>" placeholder="Otomatik veya manuel">
    </div>

    <div>
      <label class="form-etiket">Konum</label>
      <input type="text" class="form-alan" name="konum" value="<?php echo $v('konum'); ?>" placeholder="Oda, kat, depo...">
    </div>
    <div>
      <label class="form-etiket">Zimmetli Personel</label>
      <select class="form-alan" name="zimmet_personel_id">
        <option value="">— Zimmet yok —</option>
        <?php foreach ($personeller as $p): ?>
        <option value="<?php echo $p['id']; ?>" <?php echo ($d['zimmet_personel_id']??'')==$p['id']?'selected':''; ?>><?php echo htmlspecialchars($p['ad_soyad']); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Zimmet Tarihi</label>
      <input type="date" class="form-alan" name="zimmet_tarihi" value="<?php echo $v('zimmet_tarihi'); ?>">
    </div>
    <div>
      <label class="form-etiket">Amortisman (yil)</label>
      <input type="number" class="form-alan" name="amortisman_yil" value="<?php echo $v('amortisman_yil'); ?>" min="1" max="50">
    </div>
  </div>
</div>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">Satin Alma Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">
    <div>
      <label class="form-etiket">Satin Alma Tarihi</label>
      <input type="date" class="form-alan" name="satin_alma_tarihi" value="<?php echo $v('satin_alma_tarihi'); ?>">
    </div>
    <div>
      <label class="form-etiket">Satin Alma Tutari</label>
      <input type="number" class="form-alan" name="satin_alma_tutar" value="<?php echo $v('satin_alma_tutar'); ?>" step="0.01">
    </div>
    <div>
      <label class="form-etiket">Tedarikci</label>
      <input type="text" class="form-alan" name="tedarikci" value="<?php echo $v('tedarikci'); ?>">
    </div>
    <div>
      <label class="form-etiket">Garanti Bitis</label>
      <input type="date" class="form-alan" name="garanti_bitis" value="<?php echo $v('garanti_bitis'); ?>">
    </div>
  </div>
</div>

<div class="kart" style="padding:16px 20px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start">
    <div>
      <label class="form-etiket">Notlar</label>
      <textarea class="form-alan" name="notlar" rows="2"><?php echo $v('notlar'); ?></textarea>
    </div>
    <div style="padding-top:22px">
      <button type="button" onclick="kaydet()" id="kaydetBtn"
        style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit;white-space:nowrap">
        Kaydet
      </button>
    </div>
  </div>
</div>
</form>
</div>

<script>
function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    var fd = new FormData(document.getElementById('dbForm'));
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/demirbas-kaydet.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled = false; btn.textContent = 'Kaydet';
        if (r.ok) { location.href = '?sayfa=idari-demirbas-detay&id='+r.id; }
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){ btn.disabled=false; btn.textContent='Kaydet'; alert('Baglanti hatasi'); });
}
</script>
