<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Araçları çek
$araclar = $db->query(
    "SELECT a.*, CONCAT(p.ad,' ',p.soyad) sorumlu_adi,
     (SELECT MAX(tarih) FROM arac_bakimlar WHERE arac_id=a.id) son_bakim_tarihi,
     (SELECT sonraki_bakim_km FROM arac_bakimlar WHERE arac_id=a.id ORDER BY tarih DESC LIMIT 1) sonraki_bakim_km
     FROM araclar a
     LEFT JOIN personeller p ON a.sorumlu_id = p.id
     ORDER BY a.durum, a.plaka"
)->fetchAll();

// Özet
$ozet = ['aktif'=>0,'bakim'=>0,'pasif'=>0,'hurda'=>0];
foreach ($araclar as $a) if (isset($ozet[$a['durum']])) $ozet[$a['durum']]++;

// Yaklaşan muayene/sigorta (30 gün)
$uyarilar = [];
$bugun = date('Y-m-d');
$uyari_limit = date('Y-m-d', strtotime('+60 days'));
foreach ($araclar as $a) {
    foreach (['muayene_bitis'=>'🔍 Muayene','sigorta_bitis'=>'🛡 Sigorta','kasko_bitis'=>'📋 Kasko'] as $k=>$etiket) {
        if (!empty($a[$k]) && $a[$k] <= $uyari_limit) {
            $fark = (int)((strtotime($a[$k]) - strtotime($bugun)) / 86400);
            $uyarilar[] = ['plaka'=>$a['plaka'],'tip'=>$etiket,'tarih'=>$a[$k],
                'gecti'=>$a[$k]<$bugun,'arac_id'=>$a['id'],'fark'=>$fark];
        }
    }
    // Bakım KM uyarısı
    if (!empty($a['sonraki_bakim_km']) && !empty($a['km_guncel'])) {
        $km_fark = (int)$a['sonraki_bakim_km'] - (int)$a['km_guncel'];
        if ($km_fark <= 2000) {
            $uyarilar[] = ['plaka'=>$a['plaka'],'tip'=>'🔧 Bakım','tarih'=>null,
                'gecti'=>$km_fark<=0,'arac_id'=>$a['id'],'fark'=>null,
                'km_fark'=>$km_fark,'km_bilgi'=>($km_fark<=0?'Gecikmiş':''.number_format($km_fark).' km kaldı')];
        }
    }
}
// Önce geçmişler, sonra yaklaşanlar
usort($uyarilar, function($a,$b){ return ($a['gecti']?0:1) - ($b['gecti']?0:1) ?: ($a['fark']??999)-($b['fark']??999); });

$durum_cfg = [
    'aktif'  => ['bg'=>'#D1FAE5','renk'=>'#065F46','et'=>'Aktif'],
    'bakim'  => ['bg'=>'#FEF3C7','renk'=>'#92400E','et'=>'Bakımda'],
    'pasif'  => ['bg'=>'#F3F4F6','renk'=>'#6B7280','et'=>'Pasif'],
    'hurda'  => ['bg'=>'#FEE2E2','renk'=>'#991B1B','et'=>'Hurda'],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🚗 Araç & Filo Yönetimi</h1>
    <div class="s-yol">İdari İşler / <b>Araçlar</b></div>
  </div>
  <a href="?sayfa=idari-arac-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Araç</a>

  <button onclick="dtExcelIndir('tbl-arac_listesi','Arac_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet kartlar -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php foreach ([['aktif','🚗','Aktif'],['bakim','🔧','Bakımda'],['pasif','😴','Pasif'],['hurda','🗑','Hurda']] as [$k,$i,$et]): $d=$durum_cfg[$k]; ?>
  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:14px">
    <div style="font-size:22px"><?php echo $i; ?></div>
    <div style="font-size:26px;font-weight:800;color:<?php echo $d['renk']; ?>"><?php echo $ozet[$k]; ?></div>
    <div style="font-size:12px;color:var(--m2)"><?php echo $et; ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Uyarı Kartları -->
<?php if (!empty($uyarilar)):
$gecenler   = array_filter($uyarilar, function($u){ return $u['gecti']; });
$yaklasanlar = array_filter($uyarilar, function($u){ return !$u['gecti']; });
?>
<div style="display:grid;grid-template-columns:<?php echo !empty($gecenler)&&!empty($yaklasanlar)?'1fr 1fr':'1fr'; ?>;gap:12px;margin-bottom:14px">

  <?php if (!empty($gecenler)): ?>
  <div class="kart" style="border-left:4px solid #EF4444;padding:16px">
    <div style="font-size:12px;font-weight:800;color:#991B1B;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">❌ Süresi Geçen (<?php echo count($gecenler); ?>)</div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <?php foreach ($gecenler as $u): ?>
      <a href="?sayfa=idari-arac-detay&id=<?php echo $u['arac_id']; ?>" style="display:flex;align-items:center;justify-content:space-between;background:#FEF2F2;border:1px solid #FECACA;padding:8px 12px;border-radius:8px;text-decoration:none">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:13px;font-weight:800;color:#1F2937"><?php echo htmlspecialchars($u['plaka']); ?></span>
          <span style="font-size:12px;color:#6B7280"><?php echo $u['tip']; ?></span>
        </div>
        <span style="font-size:11px;font-weight:700;color:#EF4444">
          <?php echo isset($u['km_bilgi']) ? $u['km_bilgi'] : date('d.m.Y',strtotime($u['tarih'])); ?>
        </span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!empty($yaklasanlar)): ?>
  <div class="kart" style="border-left:4px solid #F59E0B;padding:16px">
    <div style="font-size:12px;font-weight:800;color:#92400E;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">⚠️ Yaklaşan Tarihler (<?php echo count($yaklasanlar); ?>)</div>
    <div style="display:flex;flex-direction:column;gap:6px">
      <?php foreach ($yaklasanlar as $u): 
        $fark = $u['fark'] ?? 999;
        $renk = $fark <= 7 ? '#F97316' : ($fark <= 30 ? '#F59E0B' : '#6B7280');
        $bg   = $fark <= 7 ? '#FFF7ED' : ($fark <= 30 ? '#FFFBEB' : '#F9FAFB');
      ?>
      <a href="?sayfa=idari-arac-detay&id=<?php echo $u['arac_id']; ?>" style="display:flex;align-items:center;justify-content:space-between;background:<?php echo $bg; ?>;border:1px solid #E5E7EB;padding:8px 12px;border-radius:8px;text-decoration:none">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:13px;font-weight:800;color:#1F2937"><?php echo htmlspecialchars($u['plaka']); ?></span>
          <span style="font-size:12px;color:#6B7280"><?php echo $u['tip']; ?></span>
        </div>
        <span style="font-size:11px;font-weight:700;color:<?php echo $renk; ?>">
          <?php if (isset($u['km_bilgi'])): echo $u['km_bilgi']; 
          else: echo date('d.m.Y',strtotime($u['tarih'])).' · '.$fark.' gün'; endif; ?>
        </span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

</div>
<?php endif; ?>

<!-- Araç tablosu -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust">
    <div class="kart-bas">Araç Listesi (<?php echo count($araclar); ?>)</div>
  </div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-arac_listesi" style="width:100%">
    <thead>
      <tr>
        <th style="width:110px">Plaka</th>
        <th>Araç</th>
        <th style="width:80px">Yıl</th>
        <th style="width:90px">Yakıt</th>
        <th style="width:110px;text-align:right">Güncel KM</th>
        <th style="width:120px">Muayene</th>
        <th style="width:120px">Sigorta</th>
        <th style="width:150px">Sorumlu</th>
        <th style="width:90px;text-align:center">Durum</th>
        <th style="width:80px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($araclar)): ?>
      <tr><td colspan="10" style="text-align:center;padding:40px;color:var(--m2)">Henüz araç eklenmemiş.</td></tr>
      <?php else: ?>
      <?php foreach ($araclar as $a):
          $dc = $durum_cfg[$a['durum']] ?? $durum_cfg['aktif'];
          $mua_gecti = !empty($a['muayene_bitis']) && $a['muayene_bitis'] < date('Y-m-d');
          $sig_gecti = !empty($a['sigorta_bitis']) && $a['sigorta_bitis'] < date('Y-m-d');
      ?>
      <tr style="cursor:pointer" onclick="location.href='?sayfa=idari-arac-detay&id=<?php echo $a['id']; ?>'">
        <td><span style="font-weight:800;color:var(--t);font-size:14px"><?php echo htmlspecialchars($a['plaka']); ?></span></td>
        <td>
          <div style="font-weight:700"><?php echo htmlspecialchars(($a['marka']??'').' '.($a['model']??'')); ?></div>
          <?php if ($a['renk']): ?><div style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($a['renk']); ?></div><?php endif; ?>
        </td>
        <td><?php echo $a['yil'] ?: '—'; ?></td>
        <td style="font-size:12px;text-transform:capitalize"><?php echo $a['yakit_tipi'] ?: '—'; ?></td>
        <td style="text-align:right;font-weight:600"><?php echo $a['km_guncel'] ? number_format($a['km_guncel']).' km' : '—'; ?></td>
        <td style="color:<?php echo $mua_gecti?'#EF4444':'var(--m)'; ?>;font-size:13px">
          <?php echo $a['muayene_bitis'] ? date('d.m.Y',strtotime($a['muayene_bitis'])) : '—'; ?>
          <?php echo $mua_gecti?'⚠️':''; ?>
        </td>
        <td style="color:<?php echo $sig_gecti?'#EF4444':'var(--m)'; ?>;font-size:13px">
          <?php echo $a['sigorta_bitis'] ? date('d.m.Y',strtotime($a['sigorta_bitis'])) : '—'; ?>
          <?php echo $sig_gecti?'⚠️':''; ?>
        </td>
        <td style="font-size:13px"><?php echo htmlspecialchars($a['sorumlu_adi'] ?? '—'); ?></td>
        <td style="text-align:center">
          <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px"><?php echo $dc['et']; ?></span>
        </td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=idari-arac-form&id=<?php echo $a['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none">✏️</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

</div>
