<?php
/**
 * Güvenlik — Tedarikçi Giriş Çıkış Takip
 * panel.php: 'idari-guvenlik-tedarikci' => 'bolumler/idari/guvenlik_tedarikci.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$db->exec("CREATE TABLE IF NOT EXISTS guv_tedarikci_giris_cikis (
    a_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plaka        VARCHAR(20),
    sofor_adi    VARCHAR(100),
    firma        VARCHAR(100) NOT NULL,
    tel          VARCHAR(20),
    irsaliye_gel VARCHAR(100),
    irsaliye_git VARCHAR(100),
    c_zaman      DATETIME,
    g_zaman      DATETIME,
    guvenlik     VARCHAR(100),
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_cz(c_zaman), INDEX idx_firma(firma)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$mesaj=''; $mesaj_tip='';
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'giris_kaydet':
            try {
                $db->prepare("INSERT INTO guv_tedarikci_giris_cikis (plaka,sofor_adi,firma,tel,irsaliye_gel,c_zaman,guvenlik) VALUES(?,?,?,?,?,?,?)")
                   ->execute([$_POST['plaka']??'',$_POST['sofor_adi'],$_POST['firma'],$_POST['tel']??'',$_POST['irsaliye_gel']??'',$_POST['c_zaman'],$_POST['guvenlik']??$kul_adi]);
                $mesaj='Giriş kaydı oluşturuldu.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'cikis_kaydet':
            try {
                $db->prepare("UPDATE guv_tedarikci_giris_cikis SET irsaliye_git=?,g_zaman=? WHERE a_id=?")
                   ->execute([$_POST['irsaliye_git']??'',$_POST['g_zaman'],(int)$_POST['a_id']]);
                $mesaj='Çıkış kaydedildi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'duzenle':
            try {
                $db->prepare("UPDATE guv_tedarikci_giris_cikis SET plaka=?,sofor_adi=?,firma=?,tel=?,irsaliye_gel=?,c_zaman=? WHERE a_id=?")
                   ->execute([$_POST['plaka']??'',$_POST['sofor_adi'],$_POST['firma'],$_POST['tel']??'',$_POST['irsaliye_gel']??'',$_POST['c_zaman'],(int)$_POST['a_id']]);
                $mesaj='Güncellendi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'sil':
            try {
                $db->prepare("DELETE FROM guv_tedarikci_giris_cikis WHERE a_id=?")->execute([(int)$_POST['a_id']]);
                $mesaj='Silindi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
    }
}

// Son 2 gün
$kayitlar = $db->query("SELECT * FROM guv_tedarikci_giris_cikis WHERE c_zaman >= DATE_SUB(NOW(),INTERVAL 30 DAY) ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
$iceride = array_filter($kayitlar, fn($r)=>empty($r['g_zaman']));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🚛 Tedarikçi Giriş Çıkış</h1>
    <div class="s-yol">İdari İşler / Güvenlik / <b>Tedarikçi</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="modalAc('tGirisModal')" class="btn btn-t btn-sm">+ Tedarikçi Girişi</button>
  </div>
</div>
<div class="s-body">
<?php if ($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?= $mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2' ?>;color:<?= $mesaj_tip==='ok'?'#065F46':'#7F1D1D' ?>;border-left:4px solid <?= $mesaj_tip==='ok'?'#22C55E':'#EF4444' ?>"><?= htmlspecialchars($mesaj) ?></div>
<?php endif; ?>

<!-- İçeride olanlar dashboard -->
<?php if (!empty($iceride)): ?>
<div style="margin-bottom:14px">
  <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px;text-transform:uppercase">Şu an Fabrikada</div>
  <div style="display:flex;flex-wrap:wrap;gap:10px">
  <?php foreach ($iceride as $r): ?>
  <div class="kart" style="padding:10px 14px;border-left:4px solid #F59E0B;background:#FFFBEB;min-width:200px">
    <div style="font-weight:800;font-size:13px"><?= htmlspecialchars($r['firma']) ?></div>
    <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($r['plaka']??'') ?> | <?= htmlspecialchars($r['sofor_adi']??'') ?></div>
    <div style="font-size:10px;color:var(--m3)">Giriş: <?= htmlspecialchars($r['c_zaman']??'') ?></div>
    <button onclick="tCikisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm" style="margin-top:4px;padding:2px 8px;font-size:10px;background:#D97706;color:#fff;border:none;border-radius:4px;cursor:pointer">Çıkış Yap</button>
  </div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden"><div style="overflow-x:auto">
<table id="tblTedarikci" style="width:100%">
  <thead><tr><th>#</th><th>Plaka</th><th>Şoför</th><th>Firma</th><th>Tel</th><th>Gel. İrs.</th><th>Git. İrs.</th><th>Giriş</th><th>Çıkış</th><th>Durum</th><th>İşlem</th></tr></thead>
  <tfoot><tr><th>#</th><th>Plaka</th><th>Şoför</th><th>Firma</th><th>Tel</th><th>Gel. İrs.</th><th>Git. İrs.</th><th>Giriş</th><th>Çıkış</th><th>Durum</th><th>İşlem</th></tr></tfoot>
  <tbody>
  <?php foreach ($kayitlar as $i => $r):
    $dis = empty($r['g_zaman']);
  ?>
  <tr style="background:<?= $dis?'#FFFBEB':'' ?>">
    <td><?= $i+1 ?></td>
    <td><?= htmlspecialchars($r['plaka']??'') ?></td>
    <td><?= htmlspecialchars($r['sofor_adi']??'') ?></td>
    <td style="font-weight:700"><?= htmlspecialchars($r['firma']??'') ?></td>
    <td><?= htmlspecialchars($r['tel']??'') ?></td>
    <td><?= htmlspecialchars($r['irsaliye_gel']??'') ?></td>
    <td><?= htmlspecialchars($r['irsaliye_git']??'') ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['c_zaman']??'') ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['g_zaman']??'') ?></td>
    <td><span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $dis?'#FEF9C3':'#D1FAE5' ?>;color:<?= $dis?'#78350F':'#065F46' ?>"><?= $dis?'İçeride':'Çıktı' ?></span></td>
    <td style="white-space:nowrap">
      <?php if ($dis): ?>
      <button onclick="tCikisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm btn-t" style="font-size:11px;padding:3px 8px">Çıkış</button>
      <?php endif; ?>
      <button onclick="tDuzenleModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF9C3;color:#78350F;border:1px solid #FDE68A">Düzenle</button>
      <button onclick="tSil(<?= $r['a_id'] ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">Sil</button>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div></div>

<!-- Giriş Modal -->
<div id="tGirisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:500px;max-width:95vw;padding:20px;max-height:90vh;overflow-y:auto">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">🚛 Tedarikçi Giriş Kaydı</div>
    <button onclick="modalKapat('tGirisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="giris_kaydet">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-et">Plaka</label><input name="plaka" class="form-alan" placeholder="34 ABC 123"></div>
      <div><label class="form-et">Şoför Adı</label><input name="sofor_adi" class="form-alan" required></div>
      <div class="col-span-2"><label class="form-et">Firma <span style="color:#EF4444">*</span></label><input name="firma" class="form-alan" required style="width:100%"></div>
      <div><label class="form-et">Telefon</label><input name="tel" class="form-alan" type="tel"></div>
      <div><label class="form-et">Gelen İrsaliye No</label><input name="irsaliye_gel" class="form-alan"></div>
      <div><label class="form-et">Giriş Zamanı</label><input type="datetime-local" name="c_zaman" class="form-alan" id="tGirisZaman" required></div>
      <div><label class="form-et">Güvenlik</label><input name="guvenlik" class="form-alan" value="<?= htmlspecialchars($kul_adi) ?>" required></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('tGirisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Çıkış Modal -->
<div id="tCikisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:380px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">🚪 Çıkış Kaydı</div>
    <button onclick="modalKapat('tCikisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="cikis_kaydet">
    <input type="hidden" name="a_id" id="tCikis_id">
    <div style="background:var(--kenar-a);border-radius:8px;padding:10px;font-size:12px;margin-bottom:10px" id="tCikisOzet"></div>
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Giden İrsaliye No</label><input name="irsaliye_git" class="form-alan"></div>
      <div><label class="form-et">Çıkış Zamanı</label><input type="datetime-local" name="g_zaman" class="form-alan" id="tCikisZaman" required></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('tCikisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Çıkışı Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Düzenle Modal -->
<div id="tDuzenleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:460px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">✏️ Düzenle</div>
    <button onclick="modalKapat('tDuzenleModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="duzenle">
    <input type="hidden" name="a_id" id="tDuz_id">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-et">Plaka</label><input name="plaka" class="form-alan" id="tDuz_plaka"></div>
      <div><label class="form-et">Şoför</label><input name="sofor_adi" class="form-alan" id="tDuz_sofor"></div>
      <div class="col-span-2"><label class="form-et">Firma</label><input name="firma" class="form-alan" id="tDuz_firma" required style="width:100%"></div>
      <div><label class="form-et">Tel</label><input name="tel" class="form-alan" id="tDuz_tel"></div>
      <div><label class="form-et">Gelen İrsaliye</label><input name="irsaliye_gel" class="form-alan" id="tDuz_irs"></div>
      <div class="col-span-2"><label class="form-et">Giriş Zamanı</label><input type="datetime-local" name="c_zaman" class="form-alan" id="tDuz_cz" style="width:100%"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('tDuzenleModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<form method="POST" id="tSilForm" style="display:none"><input type="hidden" name="action" value="sil"><input type="hidden" name="a_id" id="tSil_id"></form>

</div>
<style>
#tblTedarikci thead th,#tblTedarikci tfoot th{background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;white-space:nowrap;border-right:1px solid #2D4E7A}
#tblTedarikci tbody td{padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px}
#tblTedarikci tfoot select{width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg)}
</style>
<script>
function modalAc(id){document.getElementById(id).style.display='flex';}
function modalKapat(id){document.getElementById(id).style.display='none';}
document.getElementById('tGirisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();

function tCikisModal(r){
    document.getElementById('tCikis_id').value=r.a_id;
    document.getElementById('tCikisOzet').innerHTML='<strong>'+(r.firma||'')+'</strong> — '+(r.sofor_adi||'')+'<br>Giriş: '+(r.c_zaman||'')+(r.irsaliye_gel?' | İrs: '+r.irsaliye_gel:'');
    document.getElementById('tCikisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();
    modalAc('tCikisModal');
}
function tDuzenleModal(r){
    document.getElementById('tDuz_id').value=r.a_id;
    document.getElementById('tDuz_plaka').value=r.plaka||'';
    document.getElementById('tDuz_sofor').value=r.sofor_adi||'';
    document.getElementById('tDuz_firma').value=r.firma||'';
    document.getElementById('tDuz_tel').value=r.tel||'';
    document.getElementById('tDuz_irs').value=r.irsaliye_gel||'';
    document.getElementById('tDuz_cz').value=(r.c_zaman||'').replace(' ','T').slice(0,16);
    modalAc('tDuzenleModal');
}
function tSil(id){if(!confirm('Silmek istediğinizden emin misiniz?'))return; document.getElementById('tSil_id').value=id; document.getElementById('tSilForm').submit();}

$(document).ready(function(){
    $('#tblTedarikci').DataTable({
        initComplete:function(){this.api().columns([1,2,3,9]).every(function(){var col=this,sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+v+'</option>');});});},
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        order:[[7,'desc']],scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
        dom:'Bfrtip',buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Tedarikci_<?= date("Ymd") ?>'},'print']
    });
});
</script>
