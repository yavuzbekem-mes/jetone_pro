<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<div class="s-bar"><div class="s-bas">Teklif bulunamadi</div></div>'; return; }
$q = $db->prepare("SELECT * FROM teklifler WHERE id=? LIMIT 1");
$q->execute([$id]); $t = $q->fetch();
if (!$t) { echo '<div class="s-bar"><div class="s-bas">Bulunamadi</div></div>'; return; }
$kq = $db->prepare("SELECT * FROM teklif_kalemleri WHERE teklif_id=? ORDER BY sira");
$kq->execute([$id]); $kalemler = $kq->fetchAll();

$durum_cfg = ['taslak'=>['#F3F4F6','#6B7280','Taslak'],'gonderildi'=>['#DBEAFE','#1E40AF','Gonderildi'],'kabul'=>['#D1FAE5','#065F46','Kabul'],'red'=>['#FEE2E2','#991B1B','Reddedildi'],'revize'=>['#FEF3C7','#92400E','Revize'],'suresi_doldu'=>['#F3F4F6','#6B7280','Suresi Doldu']];
$dc = $durum_cfg[$t['durum']] ?? ['#F3F4F6','#374151',$t['durum']];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo htmlspecialchars($t['teklif_no']); ?></h1>
    <div class="s-yol">Idari / <a href="?sayfa=idari-teklif-listesi" style="color:var(--t);text-decoration:none">Teklifler</a> / <b><?php echo htmlspecialchars($t['teklif_no']); ?></b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px"><?php echo $dc[2]; ?></span>
    <a href="?sayfa=idari-teklif-form&id=<?php echo $id; ?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Duzenle</a>
    <a href="?sayfa=idari-teklif-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Liste</a>
  </div>

  <button onclick="dtExcelIndir('tbl-teklif_detay','Teklif_Detay')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:12px">Teklif Bilgileri</div>
    <?php $tip_tr=['alinan'=>'Alinan','verilen'=>'Verilen'];
    $bilgiler=[
      'Teklif No'=>htmlspecialchars($t['teklif_no']),
      'Tip'=>$tip_tr[$t['tip']]??$t['tip'],
      'Konu'=>htmlspecialchars($t['konu']),
      'Tedarikci'=>htmlspecialchars($t['tedarikci_adi']??'—'),
      'E-posta'=>htmlspecialchars($t['tedarikci_email']??'—'),
      'Gecerlilik'=>$t['gecerlilik_tarihi']?date('d.m.Y',strtotime($t['gecerlilik_tarihi'])):'—',
      'Para Birimi'=>$t['para_birimi']??'TRY',
    ];
    foreach ($bilgiler as $k=>$v): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $k; ?></span>
      <span style="font-weight:600"><?php echo $v; ?></span>
    </div>
    <?php endforeach; ?>
    <?php if ($t['notlar']): ?><div style="margin-top:10px;padding:10px;background:var(--bg);border-radius:8px;font-size:13px;color:var(--m2)"><?php echo nl2br(htmlspecialchars($t['notlar'])); ?></div><?php endif; ?>
  </div>
  <div class="kart" style="padding:18px 20px">
    <div class="kart-bas" style="margin-bottom:12px">Finansal Ozet</div>
    <?php
    $ara = 0; $kdvT = 0;
    foreach ($kalemler as $k) {
        $sat = (float)$k['miktar'] * (float)$k['birim_fiyat'] * (1 - (float)$k['indirim_oran']/100);
        $ara += $sat; $kdvT += $sat * (float)$k['kdv_oran']/100;
    }
    ?>
    <div style="padding:12px;background:var(--bg);border-radius:8px">
      <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:14px"><span style="color:var(--m2)">Ara Toplam</span><strong><?php echo number_format($ara,2); ?> <?php echo $t['para_birimi']??'TRY'; ?></strong></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:14px"><span style="color:var(--m2)">KDV</span><strong><?php echo number_format($kdvT,2); ?> <?php echo $t['para_birimi']??'TRY'; ?></strong></div>
      <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:2px solid var(--kenar);font-size:18px;font-weight:800;color:var(--t)">
        <span>TOPLAM</span>
        <span><?php echo number_format($ara+$kdvT,2); ?> <?php echo $t['para_birimi']??'TRY'; ?></span>
      </div>
    </div>
    <!-- Durum degistir -->
    <div style="margin-top:14px">
      <label class="form-etiket">Durumu Guncelle</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
        <?php foreach (['kabul'=>['#D1FAE5','#065F46','Kabul'],'red'=>['#FEE2E2','#991B1B','Reddet'],'gonderildi'=>['#DBEAFE','#1E40AF','Gonderildi'],'revize'=>['#FEF3C7','#92400E','Revize']] as $k=>$d): ?>
        <button onclick="durumDegistir('<?php echo $k; ?>')" style="background:<?php echo $d[0]; ?>;color:<?php echo $d[1]; ?>;border:none;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit"><?php echo $d[2]; ?></button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Kalemler tablosu -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Teklif Kalemleri (<?php echo count($kalemler); ?>)</div></div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-teklif_detay" style="width:100%">
    <thead><tr>
      <th style="width:44px;text-align:center">#</th>
      <th>Urun / Hizmet</th>
      <th style="width:80px;text-align:right">Miktar</th>
      <th style="width:70px">Birim</th>
      <th style="width:130px;text-align:right">Birim Fiyat</th>
      <th style="width:60px;text-align:right">KDV%</th>
      <th style="width:80px;text-align:right">Indirim%</th>
      <th style="width:140px;text-align:right">Toplam</th>
    </tr></thead>
    <tbody>
      <?php foreach ($kalemler as $k): ?>
      <tr>
        <td style="text-align:center;color:var(--m2)"><?php echo $k['sira']; ?></td>
        <td style="font-weight:700"><?php echo htmlspecialchars($k['urun_adi']); ?></td>
        <td style="text-align:right"><?php echo number_format($k['miktar'],2); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($k['birim']); ?></td>
        <td style="text-align:right"><?php echo number_format($k['birim_fiyat'],2); ?> <?php echo $t['para_birimi']??'TRY'; ?></td>
        <td style="text-align:right">%<?php echo $k['kdv_oran']; ?></td>
        <td style="text-align:right"><?php echo $k['indirim_oran']>0?'%'.$k['indirim_oran']:'—'; ?></td>
        <td style="text-align:right;font-weight:700"><?php echo number_format($k['toplam'],2); ?> <?php echo $t['para_birimi']??'TRY'; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
</div>

<script>
function durumDegistir(durum) {
    if (!confirm('Durum "' + durum + '" olarak guncellendi mi?')) return;
    var fd = new FormData();
    fd.append('id', <?php echo $id; ?>);
    fd.append('durum', durum);
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/teklif-durum.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert(r.hata);
    });
}
</script>
