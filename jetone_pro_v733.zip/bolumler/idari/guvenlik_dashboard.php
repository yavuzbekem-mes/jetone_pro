<?php
/**
 * JETONE.PRO — Güvenlik Dashboard
 * panel.php: 'idari-guvenlik-dashboard' => 'bolumler/idari/guvenlik_dashboard.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// ── Araçlar ──────────────────────────────────────────────
$arac_son = [];
try {
    foreach ($db->query("SELECT * FROM guv_arac_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC) as $r)
        if (!isset($arac_son[$r['plaka']])) $arac_son[$r['plaka']] = $r;
} catch(Throwable $e){}

// ── Servisler ─────────────────────────────────────────────
$servis_son = [];
try {
    foreach ($db->query("SELECT * FROM guv_servis_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC) as $r)
        if (!isset($servis_son[$r['plaka']])) $servis_son[$r['plaka']] = $r;
} catch(Throwable $e){}

// ── Tedarikçiler (son 48 saat) ────────────────────────────
$tedarikci_son = [];
try {
    foreach ($db->query("SELECT * FROM guv_tedarikci_giris_cikis WHERE c_zaman>=DATE_SUB(NOW(),INTERVAL 2 DAY) ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC) as $r)
        if (!isset($tedarikci_son[$r['plaka'].$r['firma']])) $tedarikci_son[$r['plaka'].$r['firma']] = $r;
} catch(Throwable $e){}

// ── Ziyaretçiler (bugün) ──────────────────────────────────
$ziyaretciler = [];
try {
    $ziyaretciler = $db->query("SELECT * FROM guv_ziyaretci WHERE DATE(giris_zaman)=CURDATE() ORDER BY giris_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){}

// ── Özet ─────────────────────────────────────────────────
$arac_dis  = count(array_filter($arac_son,     fn($r)=>empty($r['g_zaman'])));
$arac_ic   = count($arac_son) - $arac_dis;
$serv_dis  = count(array_filter($servis_son,   fn($r)=>empty($r['g_zaman'])));
$ted_ic    = count(array_filter($tedarikci_son,fn($r)=>empty($r['g_zaman'])));
$ziy_ic    = count(array_filter($ziyaretciler, fn($r)=>empty($r['cikis_zaman'])));

$plaka_markalar = [
    '59 JF 911'=>'FİORİNO','59 JF 024'=>'LİNEA','59 JD 820'=>'MERCEDES',
    '59 AT 979'=>'FORD','59 AIR 496'=>'İVECO'
];
$servis_markalar = ['34 KGJ 741'=>'SULTAN','59 ADV 150'=>'MERCEDES','59 AIY 173'=>'PRESTİJ','59 AKF 498'=>'SULTAN'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🛡️ Güvenlik Dashboard</h1>
    <div class="s-yol">İdari İşler / <b>Güvenlik</b>
      <span style="font-size:11px;color:var(--m3);margin-left:6px" id="gdSaat"></span>
    </div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap">
    <button onclick="location.reload()" class="btn btn-b btn-sm">↺</button>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-arac"       class="btn btn-b btn-sm">🚗 Araç</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-servis"     class="btn btn-b btn-sm">🚐 Servis</a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-tedarikci"  class="btn btn-b btn-sm">🚛 Tedarikçi</div></a>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-ziyaretci"  class="btn btn-b btn-sm">👤 Ziyaretçi</a>
  </div>
</div>

<div class="s-body">

<!-- ── Özet Kartlar ──────────────────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:20px" class="gd-ozet">
  <?php foreach ([
    ['🚗','Araç Dışarıda',   $arac_dis,  $arac_ic.' içeride',  '#DC2626','linear-gradient(135deg,#DC2626,#B91C1C)','idari-guvenlik-arac'],
    ['🚐','Servis Dışarıda', $serv_dis,  count($servis_son).' toplam','#D97706','linear-gradient(135deg,#D97706,#B45309)','idari-guvenlik-servis'],
    ['🚛','Tedarikçi İçeride',$ted_ic,   count($tedarikci_son).' kayıt','#0F766E','linear-gradient(135deg,#0F766E,#065F46)','idari-guvenlik-tedarikci'],
    ['👤','Ziyaretçi İçeride',$ziy_ic,   count($ziyaretciler).' bugün','#7C3AED','linear-gradient(135deg,#7C3AED,#6D28D9)','idari-guvenlik-ziyaretci'],
    ['📊','Toplam Aktif',    $arac_dis+$serv_dis+$ted_ic+$ziy_ic,'dışarıda/içeride','#1E3A5F','linear-gradient(135deg,#1E3A5F,#1E40AF)','idari-guvenlik-dashboard'],
  ] as $k): ?>
  <a href="<?= BASE_URL ?>/panel.php?sayfa=<?= $k[6] ?>" style="text-decoration:none">
    <div style="background:<?= $k[5] ?>;border-radius:12px;padding:16px;color:#fff;position:relative;overflow:hidden">
      <div style="font-size:28px;margin-bottom:6px;opacity:.9"><?= $k[0] ?></div>
      <div style="font-size:28px;font-weight:900;line-height:1"><?= $k[2] ?></div>
      <div style="font-size:12px;font-weight:700;margin-top:4px;opacity:.9"><?= $k[1] ?></div>
      <div style="font-size:10px;opacity:.7;margin-top:2px"><?= $k[3] ?></div>
      <div style="position:absolute;right:-10px;bottom:-10px;font-size:60px;opacity:.1"><?= $k[0] ?></div>
    </div>
  </a>
  <?php endforeach; ?>
</div>

<!-- ── ARAÇ DURUM KARTLARI ───────────────────────────────── -->
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:14px">
  <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="font-weight:800;font-size:13px;color:var(--t)">🚗 Araç Durumları</div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-arac" style="font-size:11px;color:#2563EB;font-weight:600">Kayıt Ekle / Tümünü Gör →</a>
  </div>
  <?php if (empty($arac_son)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Araç kaydı yok</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;padding:16px">
    <?php foreach ($arac_son as $r):
      $dis    = empty($r['g_zaman']);
      $marka  = $plaka_markalar[$r['plaka']] ?? '';
      $irs_dur= $r['irsaliye_durumu'] ?? 'irsaliyeli';
      $irs_no = $r['irsaliye_no'] ?? '';
      $zaman  = $dis ? ($r['c_zaman']?date('d.m.Y H:i',strtotime($r['c_zaman'])):'—')
                     : ($r['g_zaman']?date('d.m.Y H:i',strtotime($r['g_zaman'])):'—');
    ?>
    <div style="border-radius:12px;border:1px solid <?= $dis?'#FECACA':'#BBF7D0' ?>;
                background:<?= $dis?'#FFF5F5':'#F0FDF4' ?>;overflow:hidden">
      <!-- Başlık bandı -->
      <div style="background:<?= $dis?'#DC2626':'#16A34A' ?>;padding:10px 16px;
                  display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:18px;font-weight:900;color:#fff;letter-spacing:.05em;font-family:monospace">
            <?= htmlspecialchars($r['plaka']) ?>
          </div>
          <?php if($marka): ?>
          <div style="font-size:11px;color:rgba(255,255,255,.8);margin-top:1px"><?= $marka ?></div>
          <?php endif; ?>
        </div>
        <div style="font-size:13px;font-weight:700;color:#fff;
                    background:rgba(255,255,255,.2);padding:4px 12px;border-radius:20px">
          <?= $dis ? '↑ Dışarıda' : '↓ İçeride' ?>
        </div>
      </div>
      <!-- İçerik -->
      <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px">
        <?php if(!empty($r['sofor_adi']) || !empty($r['firma'])): ?>
        <div style="display:flex;flex-direction:column;gap:3px">
          <?php if(!empty($r['sofor_adi'])): ?>
          <div style="font-size:14px;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['sofor_adi']) ?></div>
          <?php endif; ?>
          <?php if(!empty($r['firma'])): ?>
          <div style="font-size:13px;color:var(--m2)"><?= htmlspecialchars(mb_strimwidth($r['firma'],0,32,'…')) ?></div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <!-- İrsaliye -->
        <?php if ($dis): ?>
        <div style="background:<?= $irs_dur==='irsaliyesiz'?'#FEF9C3':($irs_no?'#EFF6FF':'#F8FAFC') ?>;
                    border-radius:8px;padding:8px 12px">
          <?php if ($irs_dur === 'irsaliyesiz'): ?>
          <div style="font-size:12px;font-weight:700;color:#92400E">📋 İrsaliyesiz Çıktı</div>
          <?php elseif ($irs_no): ?>
          <div style="font-size:11px;color:#6B7280;margin-bottom:2px">Çıkış İrsaliyesi</div>
          <div style="font-size:16px;font-weight:800;color:#1D4ED8;font-family:monospace"><?= htmlspecialchars($irs_no) ?></div>
          <?php else: ?>
          <div style="font-size:12px;color:#94A3B8">İrsaliye girilmemiş</div>
          <?php endif; ?>
        </div>
        <?php else: ?>
        <?php if($irs_no || ($r['irsaliye_no_giris']??'')): ?>
        <div style="background:#F0FDF4;border-radius:8px;padding:8px 12px;display:flex;gap:16px">
          <?php if($irs_no): ?>
          <div><div style="font-size:11px;color:#6B7280">Çıkış İrs.</div>
          <div style="font-size:13px;font-weight:700;color:#1D4ED8;font-family:monospace"><?= htmlspecialchars($irs_no) ?></div></div>
          <?php endif; ?>
          <?php if($r['irsaliye_no_giris']??''): ?>
          <div><div style="font-size:11px;color:#6B7280">Giriş İrs.</div>
          <div style="font-size:13px;font-weight:700;color:#059669;font-family:monospace"><?= htmlspecialchars($r['irsaliye_no_giris']) ?></div></div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <!-- Zaman -->
        <div style="font-size:12px;color:var(--m2);display:flex;align-items:center;gap:4px">
          <span style="color:<?= $dis?'#DC2626':'#16A34A' ?>">●</span>
          <?= $dis?'Çıkış':'Giriş' ?>: <strong><?= $zaman ?></strong>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- ── SERVİS DURUM KARTLARI ─────────────────────────────── -->
<div class="kart" style="padding:0;overflow:hidden;margin-bottom:14px">
  <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
    <div style="font-weight:800;font-size:13px;color:var(--t)">🚐 Servis Araç Durumları</div>
    <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-servis" style="font-size:11px;color:#2563EB;font-weight:600">Kayıt Ekle / Tümünü Gör →</a>
  </div>
  <?php if (empty($servis_son)): ?>
  <div style="padding:40px;text-align:center;color:var(--m3)">Servis aracı kaydı yok</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px;padding:16px">
    <?php foreach ($servis_son as $r):
      $dis   = empty($r['g_zaman']);
      $marka = $servis_markalar[$r['plaka']] ?? '';
      $zaman = $dis ? ($r['c_zaman']?date('d.m.Y H:i',strtotime($r['c_zaman'])):'—')
                    : ($r['g_zaman']?date('d.m.Y H:i',strtotime($r['g_zaman'])):'—');
    ?>
    <div style="border-radius:12px;border:1px solid <?= $dis?'#FECACA':'#BBF7D0' ?>;
                background:<?= $dis?'#FFF5F5':'#F0FDF4' ?>;overflow:hidden">
      <div style="background:<?= $dis?'#D97706':'#0F766E' ?>;padding:10px 16px;
                  display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:18px;font-weight:900;color:#fff;font-family:monospace"><?= htmlspecialchars($r['plaka']) ?></div>
          <?php if($marka): ?><div style="font-size:11px;color:rgba(255,255,255,.8)"><?= $marka ?></div><?php endif; ?>
        </div>
        <div style="font-size:13px;font-weight:700;color:#fff;background:rgba(255,255,255,.2);padding:4px 12px;border-radius:20px">
          <?= $dis ? '↑ Dışarıda' : '↓ İçeride' ?>
        </div>
      </div>
      <div style="padding:14px 16px;display:flex;flex-direction:column;gap:6px">
        <?php if(!empty($r['sofor_adi'])): ?>
        <div style="font-size:14px;font-weight:700;color:var(--t)"><?= htmlspecialchars($r['sofor_adi']) ?></div>
        <?php endif; ?>
        <?php if(!empty($r['yer'])): ?>
        <div style="font-size:13px;color:var(--m2)">📍 <?= htmlspecialchars($r['yer']) ?></div>
        <?php endif; ?>
        <div style="font-size:12px;color:var(--m2);display:flex;align-items:center;gap:4px;margin-top:4px">
          <span style="color:<?= $dis?'#D97706':'#0F766E' ?>">●</span>
          <?= $dis?'Çıkış':'Giriş' ?>: <strong><?= $zaman ?></strong>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- ── TEDARİKÇİ + ZİYARETÇİ ────────────────────────────── -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px" class="gd-alt">

  <!-- Tedarikçiler -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:800;font-size:13px;color:var(--t)">🚛 Tedarikçiler <span style="font-size:11px;color:var(--m2);font-weight:400">Son 48 saat</span></div>
      <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-tedarikci" style="font-size:11px;color:#2563EB;font-weight:600">Tümü →</a>
    </div>
    <?php if (empty($tedarikci_son)): ?>
    <div style="padding:24px;text-align:center;color:var(--m3);font-size:12px">Kayıt yok</div>
    <?php else: ?>
    <?php foreach ($tedarikci_son as $r):
      $ic = empty($r['g_zaman']);
    ?>
    <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;gap:10px;
                border-left:3px solid <?= $ic?'#F59E0B':'#22C55E' ?>">
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px;color:var(--t)"><?= htmlspecialchars($r['firma']??'') ?></div>
        <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($r['plaka']??'') ?><?= $r['sofor_adi']?' · '.$r['sofor_adi']:'' ?></div>
        <?php if ($r['irsaliye_gel']??''): ?>
        <div style="font-size:10px;color:#2563EB;font-family:monospace">📄 <?= htmlspecialchars($r['irsaliye_gel']) ?></div>
        <?php endif; ?>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <span style="font-size:10px;font-weight:700;padding:3px 8px;border-radius:10px;
              background:<?= $ic?'#FEF9C3':'#D1FAE5' ?>;color:<?= $ic?'#78350F':'#065F46' ?>">
          <?= $ic?'İçeride':'Çıktı' ?>
        </span>
        <div style="font-size:10px;color:var(--m3);margin-top:2px"><?= $r['c_zaman']?date('d.m H:i',strtotime($r['c_zaman'])):'—' ?></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Ziyaretçiler -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <div style="font-weight:800;font-size:13px;color:var(--t)">👤 Ziyaretçiler <span style="font-size:11px;color:var(--m2);font-weight:400">Bugün</span></div>
      <a href="<?= BASE_URL ?>/panel.php?sayfa=idari-guvenlik-ziyaretci" style="font-size:11px;color:#2563EB;font-weight:600">Kayıt Ekle →</a>
    </div>
    <?php if (empty($ziyaretciler)): ?>
    <div style="padding:24px;text-align:center;color:var(--m3);font-size:12px">Bugün ziyaretçi yok</div>
    <?php else: ?>
    <?php foreach ($ziyaretciler as $r):
      $ic   = empty($r['cikis_zaman']);
      $dk   = round((($ic?time():strtotime($r['cikis_zaman']))-strtotime($r['giris_zaman']))/60);
    ?>
    <div style="padding:10px 16px;border-bottom:1px solid var(--kenar);display:flex;align-items:center;gap:10px;
                border-left:3px solid <?= $ic?'#7C3AED':'#22C55E' ?>">
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px;color:var(--t)"><?= htmlspecialchars($r['ad_soyad']) ?></div>
        <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($r['firma']??'') ?><?= $r['gorusulen']?' · '.$r['gorusulen']:'' ?></div>
        <?php if ($r['rozet_no']??''): ?><div style="font-size:10px;color:var(--m3)">🔖 <?= htmlspecialchars($r['rozet_no']) ?></div><?php endif; ?>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <span style="font-size:10px;font-weight:700;padding:3px 8px;border-radius:10px;
              background:<?= $ic?'#EDE9FE':'#D1FAE5' ?>;color:<?= $ic?'#5B21B6':'#065F46' ?>">
          <?= $ic?'İçeride':'Çıktı' ?>
        </span>
        <div style="font-size:10px;color:var(--m3);margin-top:2px"><?= $dk > 0 ? $dk.' dk' : '' ?></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div><!-- /alt grid -->
</div><!-- /s-body -->

<style>
@media(max-width:900px){ .gd-ozet{grid-template-columns:repeat(3,1fr)!important} }
@media(max-width:600px){ .gd-ozet{grid-template-columns:repeat(2,1fr)!important} .gd-alt{grid-template-columns:1fr!important} }
</style>
<script>
document.getElementById('gdSaat').textContent = new Date().toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
setTimeout(function(){ location.reload(); }, 60000);
</script>
