<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$f_durum = $_GET['durum'] ?? '';
$f_ara = trim($_GET['ara'] ?? '');
$where = ["1=1"]; $params = [];
if ($f_durum) { $where[] = "d.durum=?"; $params[]=$f_durum; }
if ($f_ara)   { $where[] = "(d.adi LIKE ? OR d.barkod LIKE ? OR d.seri_no LIKE ?)"; $params[]="%$f_ara%"; $params[]="%$f_ara%"; $params[]="%$f_ara%"; }
$q = $db->prepare("SELECT d.*, CONCAT(p.ad,' ',p.soyad) zimmet_adi FROM demirbaslar d LEFT JOIN personeller p ON d.zimmet_personel_id=p.id WHERE ".implode(' AND ',$where)." ORDER BY d.adi LIMIT 200");
$q->execute($params); $kayitlar = $q->fetchAll();
$ozet=['aktif'=>0,'zimmetli'=>0,'depoda'=>0,'bakimda'=>0,'hurdaya_ayrildi'=>0];
foreach($kayitlar as $k) if(isset($ozet[$k['durum']])) $ozet[$k['durum']]++;
$durum_cfg=['aktif'=>['#D1FAE5','#065F46','Aktif'],'zimmetli'=>['#DBEAFE','#1E40AF','Zimmetli'],'depoda'=>['#F3F4F6','#6B7280','Depoda'],'bakimda'=>['#FEF3C7','#92400E','Bakımda'],'hurdaya_ayrildi'=>['#FEE2E2','#991B1B','Hurda']];
?>
<div class="s-bar">
  <div><h1 class="s-bas">🏷 Demirbaş Envanteri</h1><div class="s-yol">İdari / Demirbaş / <b>Envanter</b></div></div>
  <a href="?sayfa=idari-demirbas-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Demirbaş Ekle</a>

  <button onclick="dtExcelIndir('tbl-demirbas_listesi','Demirbas_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:16px">
  <?php foreach ($durum_cfg as $k=>[$bg,$renk,$et]): ?>
  <a href="?sayfa=idari-demirbas-listesi&durum=<?php echo $k; ?>" style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:12px;text-decoration:none;<?php echo $f_durum===$k?'box-shadow:0 0 0 2px var(--t)':''; ?>">
    <div style="font-size:20px;font-weight:800;color:<?php echo $renk; ?>"><?php echo $ozet[$k]; ?></div>
    <div style="font-size:12px;color:var(--m2)"><?php echo $et; ?></div>
  </a>
  <?php endforeach; ?>
</div>
<!-- Filtre -->
<div class="kart" style="padding:12px 16px;margin-bottom:14px">
  <form method="GET" style="display:flex;gap:10px;align-items:center">
    <input type="hidden" name="sayfa" value="idari-demirbas-listesi">
    <input type="search" name="ara" value="<?php echo htmlspecialchars($f_ara); ?>" placeholder="🔍 Ad, barkod, seri no..." style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px;flex:1">
    <select name="durum" style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
      <option value="">Tüm Durumlar</option>
      <?php foreach ($durum_cfg as $k=>[$bg,$renk,$et]): ?>
      <option value="<?php echo $k; ?>" <?php echo $f_durum===$k?'selected':''; ?>><?php echo $et; ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" style="background:var(--t);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">Filtrele</button>
    <?php if ($f_durum||$f_ara): ?><a href="?sayfa=idari-demirbas-listesi" style="color:var(--m2);font-size:13px;text-decoration:none">Temizle ×</a><?php endif; ?>
  </form>
</div>
<!-- Tablo -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Kayıtlar (<?php echo count($kayitlar); ?>)</div></div>
  <div style="overflow-x:auto"><table class="tablo" id="tbl-demirbas_listesi" style="width:100%">
    <thead><tr><th>Barkod</th><th>Adı</th><th>Kategori</th><th>Marka / Model</th><th>Seri No</th><th>Satın Alma</th><th>Garanti</th><th>Konum</th><th>Zimmetli</th><th>Durum</th><th style="text-align:center">İşlem</th></tr></thead>
    <tbody>
      <?php if (empty($kayitlar)): ?><tr><td colspan="11" style="text-align:center;padding:40px;color:var(--m2)">Kayıt bulunamadı.</td></tr>
      <?php else: foreach ($kayitlar as $d):
        $dc=$durum_cfg[$d['durum']]??['#F3F4F6','#374151','?'];
        $gar_gecti=$d['garanti_bitis']&&$d['garanti_bitis']<date('Y-m-d');
      ?>
      <tr style="cursor:pointer" onclick="location.href='?sayfa=idari-demirbas-detay&id=<?php echo $d['id']; ?>'">
        <td style="font-size:11px;font-family:monospace;color:var(--m2)"><?php echo htmlspecialchars($d['barkod']??'—'); ?></td>
        <td style="font-weight:700"><?php echo htmlspecialchars($d['adi']); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($d['kategori']??''); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars(($d['marka']??'').' '.($d['model']??'')); ?></td>
        <td style="font-size:11px;font-family:monospace"><?php echo htmlspecialchars($d['seri_no']??''); ?></td>
        <td style="font-size:12px"><?php echo $d['satin_alma_tarihi']?date('d.m.Y',strtotime($d['satin_alma_tarihi'])):'—'; ?></td>
        <td style="color:<?php echo $gar_gecti?'#EF4444':'var(--m)'; ?>;font-size:12px"><?php echo $d['garanti_bitis']?date('d.m.Y',strtotime($d['garanti_bitis'])):'—'; ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($d['konum']??''); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($d['zimmet_adi']??'—'); ?></td>
        <td><span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $dc[2]; ?></span></td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=idari-demirbas-form&id=<?php echo $d['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none">✏️</a>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
</div>
