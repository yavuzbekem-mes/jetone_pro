<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$zimmetler = $db->query(
    "SELECT d.*, CONCAT(p.ad,' ',p.soyad) zimmet_adi, dep.ad dept_adi
     FROM demirbaslar d
     JOIN personeller p ON d.zimmet_personel_id = p.id
     LEFT JOIN departmanlar dep ON p.departman_id = dep.id
     WHERE d.durum = 'zimmetli'
     ORDER BY p.ad, p.soyad, d.adi"
)->fetchAll();

// Personel bazlı grupla
$gruplar = [];
foreach ($zimmetler as $z) {
    $gruplar[$z['zimmet_adi']][] = $z;
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">Zimmet Listesi</h1>
    <div class="s-yol">Idari / Demirbaş / <b>Zimmetler</b></div>
  </div>
  <a href="?sayfa=idari-demirbas-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">Envanter</a>

  <button onclick="dtExcelIndir('tbl-demirbas_zimmet','Demirbas_Zimmet')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<?php if (empty($gruplar)): ?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m2)">Aktif zimmet kaydı bulunamadi.</div>
<?php else: foreach ($gruplar as $pers_adi => $items): ?>
<div class="kart" style="overflow:hidden;margin-bottom:14px">
  <div class="kart-ust" style="background:var(--bg)">
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:36px;height:36px;border-radius:50%;background:var(--t);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800">
        <?php echo mb_substr($pers_adi,0,1); ?>
      </div>
      <div>
        <div class="kart-bas"><?php echo htmlspecialchars($pers_adi); ?></div>
        <div style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($items[0]['dept_adi']??''); ?> &mdash; <?php echo count($items); ?> adet zimmet</div>
      </div>
    </div>
  </div>
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-demirbas_zimmet" style="width:100%">
    <thead><tr>
      <th>Demirbaş Adi</th>
      <th>Kategori</th>
      <th>Marka / Model</th>
      <th>Seri No</th>
      <th>Konum</th>
      <th>Zimmet Tarihi</th>
      <th>Satin Alma Tutari</th>
      <th style="text-align:center">Islem</th>
    </tr></thead>
    <tbody>
      <?php foreach ($items as $z): ?>
      <tr>
        <td style="font-weight:700"><?php echo htmlspecialchars($z['adi']); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($z['kategori']??''); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars(trim(($z['marka']??'').' '.($z['model']??''))); ?></td>
        <td style="font-size:11px;font-family:monospace"><?php echo htmlspecialchars($z['seri_no']??''); ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($z['konum']??''); ?></td>
        <td style="font-size:13px"><?php echo $z['zimmet_tarihi']?date('d.m.Y',strtotime($z['zimmet_tarihi'])):'—'; ?></td>
        <td style="font-size:13px"><?php echo $z['satin_alma_tutar']?number_format($z['satin_alma_tutar'],2).' TL':'—'; ?></td>
        <td style="text-align:center">
          <a href="?sayfa=idari-demirbas-detay&id=<?php echo $z['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#EFF6FF;color:#1D4ED8;border-radius:6px;text-decoration:none">👁</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endforeach; endif; ?>

</div>
