<?php
/**
 * Güvenlik — Araç Giriş Çıkış Takip
 * panel.php: 'idari-guvenlik-arac' => 'bolumler/idari/guvenlik_arac.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';

// İrsaliyeler AJAX ile yüklenir - sayfa performansı için Tiger sorgusu buradan kaldırıldı
$irs_map = [];
$irsaliyeler = [];
$bagli_irsaliyeler = [];

// Tabloyu garantile
$db->exec("CREATE TABLE IF NOT EXISTS guv_arac_giris_cikis (
    a_id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plaka             VARCHAR(20) NOT NULL,
    firma             VARCHAR(150),
    randevu           VARCHAR(10),
    sofor_adi         VARCHAR(100),
    irsaliye_durumu   ENUM('irsaliyeli','irsaliyesiz') DEFAULT 'irsaliyeli',
    irsaliye_no       VARCHAR(50),
    irsaliye_no_giris VARCHAR(50),
    c_km              INT,
    g_km              INT,
    c_zaman           DATETIME,
    g_zaman           DATETIME,
    guvenlik          VARCHAR(100),
    kayit_tarihi      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_plaka(plaka), INDEX idx_czaman(c_zaman)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// Eski tabloya yeni kolonları ekle (varsa hata görmezden gel)
try { $db->exec("ALTER TABLE guv_arac_giris_cikis ADD COLUMN irsaliye_durumu ENUM('irsaliyeli','irsaliyesiz') DEFAULT 'irsaliyeli' AFTER sofor_adi"); } catch(Throwable $e){}
try { $db->exec("ALTER TABLE guv_arac_giris_cikis ADD COLUMN irsaliye_no VARCHAR(50) AFTER irsaliye_durumu"); } catch(Throwable $e){}
try { $db->exec("ALTER TABLE guv_arac_giris_cikis ADD COLUMN irsaliye_no_giris VARCHAR(50) AFTER irsaliye_no"); } catch(Throwable $e){}
// Eski irsaliye kolonunu irsaliye_no'ya taşı (varsa)
try { $db->exec("UPDATE guv_arac_giris_cikis SET irsaliye_no=irsaliye WHERE irsaliye IS NOT NULL AND irsaliye_no IS NULL AND irsaliye!=''"); } catch(Throwable $e){}

$mesaj = ''; $mesaj_tip = '';

// Araç çıkış kaydı (yeni kayıt)
if (isset($_POST['action']) && $_POST['action'] === 'cikis_kaydet') {
    try {
        $irs_dur = $_POST['irsaliye_durumu'] ?? 'irsaliyeli';
        $irs_no  = $irs_dur === 'irsaliyesiz' ? null : (trim($_POST['irsaliye_no'] ?? '') ?: null);
        // Firma: irsaliyeli ise Tiger'dan sorgula, irsaliyesiz ise formdan al
        $firma = $_POST['firma'] ?? '';
        if ($irs_dur === 'irsaliyeli' && $irs_no) {
            require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
            if ($tigerdb_pdo) {
                try {
                    $fRow = $tigerdb_pdo->prepare("
                        SELECT TOP 1 CL.DEFINITION_ AS musteri
                        FROM dbo.LG_222_02_STFICHE STF WITH(NOLOCK)
                        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STF.CLIENTREF
                        WHERE STF.FICHENO=? AND STF.TRCODE IN (8)
                        UNION ALL
                        SELECT TOP 1 CL.DEFINITION_
                        FROM dbo.LG_222_01_STFICHE STF WITH(NOLOCK)
                        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STF.CLIENTREF
                        WHERE STF.FICHENO=? AND STF.TRCODE IN (8)
                    ");
                    $fRow->execute([$irs_no, $irs_no]);
                    $fResult = $fRow->fetchColumn();
                    if ($fResult) $firma = $fResult;
                } catch(Throwable $e){}
            }
        }
        $db->prepare("INSERT INTO guv_arac_giris_cikis (plaka,firma,randevu,sofor_adi,irsaliye_durumu,irsaliye_no,c_km,c_zaman,guvenlik)
            VALUES (?,?,?,?,?,?,?,?,?)")
           ->execute([
               $_POST['plaka'], $firma, $_POST['randevu'] ?? '',
               $_POST['sofor_adi'], $irs_dur, $irs_no,
               (int)$_POST['c_km'], $_POST['c_zaman'], $_POST['guvenlik'] ?? $kul_adi
           ]);
        $mesaj = 'Araç çıkış kaydı oluşturuldu.'; $mesaj_tip = 'ok';
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}
// Giriş kaydını sonlandır
if (isset($_POST['action']) && $_POST['action'] === 'giris_kaydet') {
    try {
        $db->prepare("UPDATE guv_arac_giris_cikis SET g_km=?,g_zaman=?,irsaliye_no_giris=? WHERE a_id=?")
           ->execute([(int)$_POST['g_km'], $_POST['g_zaman'], $_POST['irsaliye_no_giris'] ?? '', (int)$_POST['a_id']]);
        $mesaj = 'Giriş kaydı tamamlandı.'; $mesaj_tip = 'ok';
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}
// Düzenle
if (isset($_POST['action']) && $_POST['action'] === 'duzenle') {
    try {
        $irs_dur2 = $_POST['irsaliye_durumu'] ?? 'irsaliyeli';
        $irs_no2  = $irs_dur2 === 'irsaliyesiz' ? null : (trim($_POST['irsaliye_no'] ?? '') ?: null);
        $firma2   = ($irs_no2 && isset($irs_map[$irs_no2])) ? $irs_map[$irs_no2] : ($_POST['firma'] ?? '');
        $db->prepare("UPDATE guv_arac_giris_cikis SET plaka=?,firma=?,sofor_adi=?,randevu=?,c_km=?,c_zaman=?,irsaliye_durumu=?,irsaliye_no=? WHERE a_id=?")
           ->execute([$_POST['plaka'],$firma2,$_POST['sofor_adi'],$_POST['randevu']??'',(int)$_POST['c_km'],$_POST['c_zaman'],$irs_dur2,$irs_no2,(int)$_POST['a_id']]);
        $mesaj = 'Kayıt güncellendi.'; $mesaj_tip = 'ok';
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}
// Sil
if (isset($_POST['action']) && $_POST['action'] === 'sil') {
    try {
        $db->prepare("DELETE FROM guv_arac_giris_cikis WHERE a_id=?")->execute([(int)$_POST['a_id']]);
        $mesaj = 'Kayıt silindi.'; $mesaj_tip = 'ok';
    } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
}

// Veri çek
$kayitlar = $db->query("SELECT * FROM guv_arac_giris_cikis ORDER BY (g_zaman IS NULL) DESC, c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);

// Son durum (araç bazında)
$son_durumlar = [];
$son_km = [];
foreach ($kayitlar as $r) {
    $p = $r['plaka'];
    if (!isset($son_durumlar[$p])) $son_durumlar[$p] = $r;
    if (!isset($son_km[$p]) && $r['g_km']) $son_km[$p] = $r['g_km'];
}

$plaka_markalar = [
    '59 JF 911'=>'FİORİNO','59 JF 024'=>'LİNEA','59 JD 820'=>'MERCEDES',
    '59 AT 979'=>'FORD','59 AIR 496'=>'İVECO'
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🚗 Araç Giriş Çıkış Takip</h1>
    <div class="s-yol">İdari İşler / Güvenlik / <b>Araç Takip</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="modalAc('cikisModal')" class="btn btn-t btn-sm">+ Araç Çıkış Kaydı</button>
  </div>
</div>
<div class="s-body">
<?php if ($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?= $mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2' ?>;color:<?= $mesaj_tip==='ok'?'#065F46':'#7F1D1D' ?>;border-left:4px solid <?= $mesaj_tip==='ok'?'#22C55E':'#EF4444' ?>">
  <?= htmlspecialchars($mesaj) ?>
</div>
<?php endif; ?>

<!-- Dashboard araç durumları -->
<div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px">
<?php foreach ($son_durumlar as $arac):
    $disarida = empty($arac['g_zaman']);
    $marka = $plaka_markalar[$arac['plaka']] ?? '';
?>
<div class="kart" style="padding:12px 16px;min-width:180px;border-left:4px solid <?= $disarida?'#EF4444':'#22C55E' ?>">
  <div style="font-weight:800;font-size:13px"><?= htmlspecialchars($arac['plaka']) ?><?= $marka?" <span style='font-size:10px;color:var(--m2)'>($marka)</span>":'' ?></div>
  <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($arac['sofor_adi']??'') ?></div>
  <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $disarida?'#FEE2E2':'#D1FAE5' ?>;color:<?= $disarida?'#991B1B':'#065F46' ?>">
    <?= $disarida?'● Dışarıda':'● İçeride' ?>
  </span>
  <div style="font-size:10px;color:var(--m3);margin-top:3px"><?= htmlspecialchars($disarida?$arac['c_zaman']:$arac['g_zaman']) ?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto">
<table id="tblArac" style="width:100%">
  <thead><tr>
    <th>#</th><th>Plaka</th><th>Şoför</th><th>Firma</th>
    <th>Çıkış</th><th>Giriş</th><th>Çıkış KM</th><th>Giriş KM</th>
    <th>İrs. Durumu</th><th>Çıkış İrs.</th><th>Giriş İrs.</th><th>Durum</th><th>Süre(dk)</th><th>İşlem</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Plaka</th><th>Şoför</th><th>Firma</th>
    <th>Çıkış</th><th>Giriş</th><th>Çıkış KM</th><th>Giriş KM</th>
    <th>İrs. Durumu</th><th>Çıkış İrs.</th><th>Giriş İrs.</th><th>Durum</th><th>Süre(dk)</th><th>İşlem</th>
  </tr></tfoot>
  <tbody>
  <?php foreach ($kayitlar as $i => $r):
    $disarida = empty($r['g_zaman']);
    $sure = !$disarida ? round((strtotime($r['g_zaman'])-strtotime($r['c_zaman']))/60) : '';
    $durum_html = $disarida
      ? '<span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:#FEE2E2;color:#991B1B">Dışarıda</span>'
      : '<span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:#D1FAE5;color:#065F46">İçeride</span>';
  ?>
  <tr>
    <td><?= $i+1 ?></td>
    <td style="font-weight:700"><?= htmlspecialchars($r['plaka']) ?></td>
    <td><?= htmlspecialchars($r['sofor_adi']??'') ?></td>
    <td><?= htmlspecialchars($r['firma']??'') ?></td>
    <td style="white-space:nowrap;font-size:11px"><?= htmlspecialchars($r['c_zaman']??'') ?></td>
    <td style="white-space:nowrap;font-size:11px"><?= htmlspecialchars($r['g_zaman']??'') ?></td>
    <td><?= htmlspecialchars($r['c_km']??'') ?></td>
    <td><?= htmlspecialchars($r['g_km']??'') ?></td>
    <td style="text-align:center">
      <?php $id=$r['irsaliye_durumu']??'irsaliyeli'; ?>
      <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;
            background:<?= $id==='irsaliyesiz'?'#FEF9C3':'#EFF6FF' ?>;
            color:<?= $id==='irsaliyesiz'?'#78350F':'#1D4ED8' ?>">
        <?= $id==='irsaliyesiz'?'İrsaliyesiz':'İrsaliyeli' ?>
      </span>
    </td>
    <td style="font-family:monospace;font-size:11px;font-weight:700;color:<?= $r['irsaliye_no']?'#2563EB':'#94A3B8' ?>"><?= htmlspecialchars($r['irsaliye_no']??'—') ?></td>
    <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['irsaliye_no_giris']??'') ?></td>
    <td><?= $durum_html ?></td>
    <td><?= $sure ?></td>
    <td style="white-space:nowrap">
      <?php if ($disarida): ?>
      <button onclick="girisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm btn-t" style="font-size:11px;padding:3px 8px">Giriş</button>
      <?php else: ?>
      <span style="font-size:11px;color:var(--m3)">Tamamlandı</span>
      <?php endif; ?>
      <button onclick="duzenleModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF9C3;color:#78350F;border:1px solid #FDE68A">Düzenle</button>
      <button onclick="silKayit(<?= $r['a_id'] ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">Sil</button>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>

<!-- MODALLER -->
<?php
$firmalar = ['ARÇELİK KURUTUCU','ARÇELİK Beks Depo','ARÇELİK TKM','ARÇELİK Eİ','SMARTHAUSE','BALORMAN','AKPLAS','MTN','ORTEL','TOPDAL','BOYPLAST','VATAN ÇOCUK','MTBS','GOLDMASTER','ÇERKEZKÖY','ÇORLU','TEKİRDAĞ','İSTANBUL','KARAAĞAÇ','KAPAKLI','SANAYİ','YILMAZ KALIP','KARGO','Diğer...'];
?>
<!-- Çıkış Modal -->
<div id="cikisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
  <div class="kart" style="width:520px;max-width:95vw;padding:20px;max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div style="font-weight:800;font-size:15px">🚗 Araç Çıkış Kaydı</div>
      <button onclick="modalKapat('cikisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="cikis_kaydet">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label class="form-et">Plaka</label>
          <select name="plaka" class="form-alan" required id="aracPlakaSelect" onchange="plakaKmGetir(this.value)">
            <option value="">— Seçin —</option>
            <?php foreach (array_keys($plaka_markalar) as $p): ?>
            <option value="<?= $p ?>"><?= $p ?> <?= $plaka_markalar[$p] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="form-et">Şoför Adı</label>
          <input name="sofor_adi" class="form-alan" required>
        </div>
        <div>
          <label class="form-et">Randevu</label>
          <select name="randevu" class="form-alan">
            <option value="">RANDEVUSUZ</option>
            <option>02:00</option><option>06:00</option><option>09:00</option>
            <option>13:00</option><option>17:00</option><option>22:00</option>
          </select>
        </div>
        <div>
          <label class="form-et">Çıkış KM</label>
          <input type="number" name="c_km" class="form-alan" id="aracCikisKm" required>
        </div>
        <div class="col-span-2">
          <label class="form-et">İrsaliye Durumu</label>
          <div style="display:flex;gap:8px;align-items:center">
            <label style="display:flex;align-items:center;gap:5px;font-size:13px;cursor:pointer">
              <input type="radio" name="irsaliye_durumu" value="irsaliyeli" id="rdIrsaliyeli" checked onchange="irsaliyeDurumGuncelle()">
              İrsaliyeli
            </label>
            <label style="display:flex;align-items:center;gap:5px;font-size:13px;cursor:pointer">
              <input type="radio" name="irsaliye_durumu" value="irsaliyesiz" id="rdIrsaliyesiz" onchange="irsaliyeDurumGuncelle()">
              İrsaliyesiz Çıktı
            </label>
          </div>
        </div>
        <!-- İrsaliyeli: irsaliye seç, firma otomatik gelir -->
        <div class="col-span-2" id="irsaliyeSecimDiv">
          <label class="form-et">İrsaliye No <span style="color:#EF4444">*</span>
            <span style="font-size:10px;color:var(--m2);font-weight:400"> — Son 24 saat</span>
          </label>
          <select name="irsaliye_no" id="irsaliyeSelect" class="form-alan" style="width:100%" onchange="irsaliyeSecildi(this.value)">
            <option value="">⏳ Yükleniyor...</option>
          </select>
          <div id="irsaliyeFirmaGoster" style="font-size:11px;color:#2563EB;margin-top:4px;font-weight:700"></div>
          <input type="hidden" name="firma" id="firmaGizli" value="">
        </div>
        <!-- İrsaliyesiz: firma dropdown manuel -->
        <div class="col-span-2" id="firmaManuelDiv" style="display:none">
          <label class="form-et">Firma <span style="color:#EF4444">*</span></label>
          <select name="firma" id="firmaManuelSelect" class="form-alan" style="width:100%" onchange="firmaDigerKontrol(this.value)">
            <?php foreach ($firmalar as $f): ?><option><?= $f ?></option><?php endforeach; ?>
          </select>
          <input type="text" id="firmaDigerInput" name="firma" class="form-alan"
                 style="display:none;width:100%;margin-top:6px"
                 placeholder="Firma adı yazın...">
        </div>
        <div>
          <label class="form-et">Çıkış Zamanı</label>
          <input type="datetime-local" name="c_zaman" class="form-alan" id="aracCikisZaman" required>
        </div>
        <div>
          <label class="form-et">Güvenlik</label>
          <input name="guvenlik" class="form-alan" value="<?= htmlspecialchars($kul_adi) ?>" required>
        </div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
        <button type="button" onclick="modalKapat('cikisModal')" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<!-- Giriş Modal -->
<div id="girisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
  <div class="kart" style="width:420px;max-width:95vw;padding:20px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div style="font-weight:800;font-size:15px">🏁 Araç Giriş Kaydı</div>
      <button onclick="modalKapat('girisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="giris_kaydet">
      <input type="hidden" name="a_id" id="giris_a_id">
      <div style="display:grid;gap:10px">
        <div style="background:var(--kenar-a);border-radius:8px;padding:10px;font-size:12px" id="giris_ozet"></div>
        <div>
          <label class="form-et">Giriş KM</label>
          <input type="number" name="g_km" class="form-alan" required>
        </div>
        <div>
          <label class="form-et">Giriş Zamanı</label>
          <input type="datetime-local" name="g_zaman" class="form-alan" required id="giris_zaman_input">
        </div>
        <div>
          <label class="form-et">Giriş İrsaliye No
            <span style="font-size:10px;color:var(--m2);font-weight:400"> — opsiyonel</span>
          </label>
          <input type="text" name="irsaliye_no_giris" class="form-alan"
                 placeholder="İrsaliye no girin (opsiyonel)"
                 style="font-family:monospace;text-transform:uppercase"
                 oninput="this.value=this.value.toUpperCase()">
        </div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
        <button type="button" onclick="modalKapat('girisModal')" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t">Kaydı Sonlandır</button>
      </div>
    </form>
  </div>
</div>

<!-- Düzenle Modal -->
<div id="duzenleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
  <div class="kart" style="width:480px;max-width:95vw;padding:20px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div style="font-weight:800;font-size:15px">✏️ Kayıt Düzenle</div>
      <button onclick="modalKapat('duzenleModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="duzenle">
      <input type="hidden" name="a_id" id="duzenle_a_id">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div><label class="form-et">Plaka</label><input name="plaka" class="form-alan" id="d_plaka" required></div>
        <div><label class="form-et">Firma</label><input name="firma" class="form-alan" id="d_firma"></div>
        <div><label class="form-et">Şoför Adı</label><input name="sofor_adi" class="form-alan" id="d_sofor"></div>
        <div><label class="form-et">Randevu</label><input name="randevu" class="form-alan" id="d_randevu"></div>
        <div><label class="form-et">Çıkış KM</label><input type="number" name="c_km" class="form-alan" id="d_ckm"></div>
        <div><label class="form-et">Çıkış Zamanı</label><input type="datetime-local" name="c_zaman" class="form-alan" id="d_czaman"></div>
        <div class="col-span-2"><label class="form-et">Çıkış İrsaliye</label><input name="irsaliye" class="form-alan" id="d_irsaliye" style="width:100%"></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
        <button type="button" onclick="modalKapat('duzenleModal')" class="btn btn-b">İptal</button>
        <button type="submit" class="btn btn-t">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<!-- Sil Form -->
<form method="POST" id="silForm" style="display:none">
  <input type="hidden" name="action" value="sil">
  <input type="hidden" name="a_id" id="sil_a_id">
</form>

</div><!-- /s-body -->

<style>
#tblArac thead th,#tblArac tfoot th{background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;white-space:nowrap;border-right:1px solid #2D4E7A}
#tblArac tbody td{padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px}
#tblArac tfoot select{width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg)}
</style>

<script>
var sonKm = <?= json_encode($son_km) ?>;
var irsMap = {}; // AJAX ile doldurulur
var irsYuklendi = false;

// İrsaliyeleri AJAX ile yükle (modal açılınca bir kez çağrılır)
function irsaliyeleriYukle() {
    if (irsYuklendi) return;
    var sArr = [document.getElementById('irsaliyeSelect')];
    sArr.forEach(function(s){ if(s) s.innerHTML = '<option value="">⏳ Yükleniyor...</option>'; });

    fetch('<?= BASE_URL ?>/bolumler/idari/ajax/guvenlik_arac_irs.php')
        .then(function(r){ return r.json(); })
        .then(function(d) {
            irsYuklendi = true;
            irsMap = d.irs_map || {};
            var bagli = d.bagli || {};

            // Çıkış irsaliye select
            var sel = document.getElementById('irsaliyeSelect');
            if (sel) {
                sel.innerHTML = '<option value="">— İrsaliye seçin —</option>';
                (d.irsaliyeler || []).forEach(function(ir) {
                    var opt = document.createElement('option');
                    opt.value = ir.irsaliye_no;
                    var baglandimi = bagli[ir.irsaliye_no];
                    if (baglandimi) return; // bağlı olanları listeye ekleme
                    opt.textContent = ir.irsaliye_no + ' — ' + (ir.musteri||'').substring(0,30);
                    sel.appendChild(opt);
                });
            }

        })
        .catch(function(e){ console.error('İrsaliye yüklenemedi:', e); });
}

function firmaDigerKontrol(val) {
    var sel   = document.getElementById('firmaManuelSelect');
    var input = document.getElementById('firmaDigerInput');
    if (val === 'Diğer...') {
        sel.name   = '';   // select'i POST'tan çıkar
        input.style.display = '';
        input.name = 'firma';
        input.required = true;
        input.focus();
    } else {
        sel.name   = 'firma';
        input.style.display = 'none';
        input.name = '';
        input.required = false;
        input.value = '';
    }
}

function irsaliyeDurumGuncelle() {
    var irs = document.querySelector('input[name="irsaliye_durumu"]:checked').value;
    var secimDiv   = document.getElementById('irsaliyeSecimDiv');
    var firmaMan   = document.getElementById('firmaManuelDiv');
    var firmaGizli = document.getElementById('firmaGizli');
    var firmaManSel= document.getElementById('firmaManuelSelect');
    if (irs === 'irsaliyesiz') {
        secimDiv.style.display  = 'none';
        firmaMan.style.display  = '';
        firmaGizli.name         = ''; // irsaliyeli firma hidden devre dışı
        if (firmaManSel) firmaManSel.name = 'firma';
    } else {
        secimDiv.style.display  = '';
        firmaMan.style.display  = 'none';
        firmaGizli.name         = 'firma'; // irsaliyeli firma hidden aktif
        if (firmaManSel) firmaManSel.name = '';
    }
}

function irsaliyeSecildi(irsNo) {
    var firma = irsMap[irsNo] || '';
    document.getElementById('firmaGizli').value = firma;
    document.getElementById('irsaliyeFirmaGoster').textContent = firma ? '✓ Firma: ' + firma : '';
}

function modalAc(id){
    document.getElementById(id).style.display='flex';
    if (id === 'cikisModal' || id === 'girisModal') irsaliyeleriYukle();
}
function modalKapat(id){ document.getElementById(id).style.display='none'; }

function plakaKmGetir(plaka){ if(sonKm[plaka]) document.getElementById('aracCikisKm').value=sonKm[plaka]; }

// Şimdiki zamanı datetime-local formatında set et
document.getElementById('aracCikisZaman').value = (function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();

function girisModal(r){
    irsaliyeleriYukle();
    document.getElementById('giris_a_id').value = r.a_id;
    document.getElementById('giris_ozet').innerHTML =
        '<strong>' + r.plaka + '</strong> — ' + (r.sofor_adi||'') + ' | ' + (r.firma||'') +
        '<br>Çıkış: ' + (r.c_zaman||'') + ' | Çıkış KM: ' + (r.c_km||'');
    document.getElementById('giris_zaman_input').value = (function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();
    modalAc('girisModal');
}

function duzenleModal(r){
    document.getElementById('duzenle_a_id').value = r.a_id;
    document.getElementById('d_plaka').value    = r.plaka||'';
    document.getElementById('d_firma').value    = r.firma||'';
    document.getElementById('d_sofor').value    = r.sofor_adi||'';
    document.getElementById('d_randevu').value  = r.randevu||'';
    document.getElementById('d_ckm').value      = r.c_km||'';
    document.getElementById('d_czaman').value   = (r.c_zaman||'').replace(' ','T').slice(0,16);
    document.getElementById('d_irsaliye').value = r.irsaliye||'';
    modalAc('duzenleModal');
}

function silKayit(id){
    if(!confirm('Bu kaydı silmek istediğinizden emin misiniz?')) return;
    document.getElementById('sil_a_id').value = id;
    document.getElementById('silForm').submit();
}

$(document).ready(function(){
    $('#tblArac').DataTable({
        initComplete: function(){
            this.api().columns([1,2,3,10]).every(function(){
                var col=this,sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty())
                    .on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
                col.data().unique().sort().each(function(d){ var v=$('<div/>').html(d).text(); sel.append('<option value="'+v+'">'+v+'</option>'); });
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        order:[[11,'asc'],[4,'desc']], scrollCollapse:true, scrollY:'500px', paging:false, scrollX:true,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Arac_Takip_<?= date("Ymd") ?>'},
                 {extend:'print',text:'🖨️ Yazdır'}]
    });
});
</script>
