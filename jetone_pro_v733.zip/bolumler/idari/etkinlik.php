<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();
$uid  = (int)$user['id'];

// Tablo oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `etkinlikler` (
        `id`          INT AUTO_INCREMENT PRIMARY KEY,
        `baslik`      VARCHAR(300) NOT NULL,
        `aciklama`    TEXT,
        `tarih`       DATE NOT NULL,
        `saat`        TIME DEFAULT NULL,
        `tur`         VARCHAR(30) DEFAULT 'ozel' COMMENT 'dogum_gunu,yildonumu,toplanti,kutlama,ozel',
        `ilgili_id`   INT DEFAULT NULL COMMENT 'personel_id (dogum günü için)',
        `ilgili_adi`  VARCHAR(150) DEFAULT NULL,
        `durum`       VARCHAR(20) DEFAULT 'planli' COMMENT 'planli,tamamlandi,iptal',
        `renk`        VARCHAR(20) DEFAULT '#F97316',
        `olusturan_id`INT DEFAULT NULL,
        `olusturma`   DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

$bugun     = date('Y-m-d');
$yarin     = date('Y-m-d', strtotime('+1 day'));
$bu_hafta  = date('Y-m-d', strtotime('+7 day'));
$bu_ay_son = date('Y-m-d', strtotime('last day of this month'));

// Yaklaşan doğum günleri (beyaz yaka + tüm personel, 30 gün içinde)
$dogum_gunleri = [];
try {
    $perler = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad, dogum_tarihi, vardiya_tipi,
        departman_id
        FROM personeller
        WHERE durum='aktif' AND vardiya_tipi='beyaz'
          AND dogum_tarihi IS NOT NULL AND CHAR_LENGTH(dogum_tarihi) >= 8
        ORDER BY DATE_FORMAT(dogum_tarihi, '%m-%d')")->fetchAll();

    foreach ($perler as $p) {
        $md    = date('m-d', strtotime($p['dogum_tarihi']));
        $yil   = date('Y');
        $dg    = date('Y-m-d', strtotime("$yil-$md"));
        if ($dg < $bugun) $dg = date('Y-m-d', strtotime(($yil+1)."-$md")); // geçtiyse gelecek yıl
        $fark  = (int)((strtotime($dg) - strtotime($bugun)) / 86400);
        if ($fark <= 30) {
            $dogum_gunleri[] = [
                'personel_id' => $p['id'],
                'ad_soyad'    => $p['ad_soyad'],
                'dogum_tarihi'=> $p['dogum_tarihi'],
                'tarih'       => $dg,
                'fark'        => $fark,
                'vardiya_tipi'=> $p['vardiya_tipi'] ?? 'tek',
            ];
        }
    }
    usort($dogum_gunleri, function($a,$b){ return $a['fark'] - $b['fark']; });
} catch(Throwable $e) {}

// Etkinlikler (önümüzdeki 30 gün + geçmiş 7 gün)
$etkinlikler = [];
try {
    $eq = $db->prepare("SELECT * FROM etkinlikler
        WHERE tarih >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
          AND tarih <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
        ORDER BY tarih ASC, saat ASC");
    $eq->execute();
    $etkinlikler = $eq->fetchAll();
} catch(Throwable $e) {}

$tur_cfg = [
    'dogum_gunu' => ['ikon'=>'🎂','renk'=>'#F97316','et'=>'Doğum Günü'],
    'yildonumu'  => ['ikon'=>'🥂','renk'=>'#8B5CF6','et'=>'Yıldönümü'],
    'toplanti'   => ['ikon'=>'📅','renk'=>'#3B82F6','et'=>'Toplantı'],
    'kutlama'    => ['ikon'=>'🎉','renk'=>'#10B981','et'=>'Kutlama'],
    'ozel'       => ['ikon'=>'⭐','renk'=>'#F59E0B','et'=>'Özel'],
];
$durum_cfg = [
    'planli'     => ['bg'=>'#DBEAFE','renk'=>'#1E40AF','et'=>'Planlandı'],
    'tamamlandi' => ['bg'=>'#D1FAE5','renk'=>'#065F46','et'=>'Tamamlandı'],
    'iptal'      => ['bg'=>'#FEE2E2','renk'=>'#991B1B','et'=>'İptal'],
];
?>
<div class="s-bar">
  <div><h1 class="s-bas">🎉 Etkinlikler & Doğum Günleri</h1><div class="s-yol">İdari İşler / <b>Etkinlikler</b></div></div>
  <button onclick="modalAc()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">+ Etkinlik Ekle</button>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 360px;gap:14px">

<!-- SOL: Takvim / Etkinlik listesi -->
<div>

  <!-- Yaklaşan doğum günleri uyarısı -->
  <?php
  $yarin_dg  = array_filter($dogum_gunleri, function($d){ return $d['fark'] === 1; });
  $bugun_dg  = array_filter($dogum_gunleri, function($d){ return $d['fark'] === 0; });
  $hafta_dg  = array_filter($dogum_gunleri, function($d){ return $d['fark'] > 1 && $d['fark'] <= 7; });
  ?>

  <?php if (!empty($bugun_dg)): ?>
  <div style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border-radius:12px;padding:16px 20px;margin-bottom:12px;display:flex;align-items:center;gap:14px">
    <div style="font-size:36px">🎂</div>
    <div>
      <div style="font-weight:800;font-size:15px;margin-bottom:4px">Bugün Doğum Günü! 🎉</div>
      <?php foreach($bugun_dg as $d): ?>
      <div style="font-size:13px;opacity:.9"><b><?php echo htmlspecialchars($d['ad_soyad']); ?></b> — Bugün özel günü!</div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!empty($yarin_dg)): ?>
  <div style="background:#FEF3C7;border:1px solid #F59E0B;border-radius:12px;padding:14px 18px;margin-bottom:12px;display:flex;align-items:center;gap:12px">
    <div style="font-size:28px">⚠️</div>
    <div>
      <div style="font-weight:800;font-size:13px;color:#92400E;margin-bottom:3px">Yarın Doğum Günü — Kutlama Hazırlanabilir!</div>
      <?php foreach($yarin_dg as $d): ?>
      <div style="font-size:12px;color:#92400E">
        <b><?php echo htmlspecialchars($d['ad_soyad']); ?></b>
        <button onclick="etkinlikEkleKutlama(<?php echo $d['personel_id']; ?>,'<?php echo addslashes($d['ad_soyad']); ?>','<?php echo $d['tarih']; ?>')"
          style="margin-left:8px;background:#F97316;color:#fff;border:none;padding:3px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">+ Kutlama Organize Et</button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Etkinlik listesi -->
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust"><div class="kart-bas">📅 Yaklaşan Etkinlikler</div></div>

    <?php if (empty($etkinlikler)): ?>
    <div style="padding:30px;text-align:center;color:var(--m2)">Henüz etkinlik eklenmemiş.</div>
    <?php else: ?>

    <?php
    $son_tarih = '';
    foreach ($etkinlikler as $e):
      $tc = $tur_cfg[$e['tur']] ?? ['ikon'=>'⭐','renk'=>'#F59E0B','et'=>$e['tur']];
      $dc = $durum_cfg[$e['durum']] ?? ['bg'=>'#F3F4F6','renk'=>'#6B7280','et'=>$e['durum']];
      $e_tarih = $e['tarih'];
      $fark = (int)((strtotime($e_tarih) - strtotime($bugun)) / 86400);
      $fark_et = $fark === 0 ? '🔴 Bugün' : ($fark === 1 ? '🟡 Yarın' : ($fark < 0 ? abs($fark).' gün önce' : $fark.' gün sonra'));
      $aylar = ['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
      $tarih_fmt = (int)date('d',strtotime($e_tarih)).' '.$aylar[(int)date('m',strtotime($e_tarih))].' '.date('Y',strtotime($e_tarih));

      // Tarih ayırıcı
      if ($e_tarih !== $son_tarih):
        $son_tarih = $e_tarih;
    ?>
    <div style="padding:8px 16px;background:var(--bg);font-size:11px;font-weight:700;color:var(--m2);border-bottom:1px solid var(--kenar)">
      <?php echo $tarih_fmt; ?> · <span style="color:<?php echo $fark<=0?'#EF4444':($fark<=3?'#F97316':'var(--m2)'); ?>"><?php echo $fark_et; ?></span>
    </div>
    <?php endif; ?>

    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--kenar)">
      <div style="width:42px;height:42px;border-radius:12px;background:<?php echo $tc['renk']; ?>22;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0"><?php echo $tc['ikon']; ?></div>
      <div style="flex:1">
        <div style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($e['baslik']); ?></div>
        <div style="font-size:11px;color:var(--m2);margin-top:2px">
          <?php if ($e['saat']): echo date('H:i', strtotime($e['saat'])).' · '; endif; ?>
          <?php echo $tc['et']; ?>
          <?php if ($e['ilgili_adi']): ?> · <b><?php echo htmlspecialchars($e['ilgili_adi']); ?></b><?php endif; ?>
        </div>
        <?php if ($e['aciklama']): ?><div style="font-size:11px;color:var(--m2);margin-top:2px"><?php echo htmlspecialchars(mb_substr($e['aciklama'],0,80)); ?></div><?php endif; ?>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
        <span style="background:<?php echo $dc['bg']; ?>;color:<?php echo $dc['renk']; ?>;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px"><?php echo $dc['et']; ?></span>
        <div style="display:flex;gap:4px">
          <button onclick="duzenle(<?php echo htmlspecialchars(json_encode($e,JSON_UNESCAPED_UNICODE)); ?>)"
            style="background:#EFF6FF;color:#1D4ED8;border:none;width:26px;height:26px;border-radius:6px;cursor:pointer;font-size:11px">✏️</button>
          <button onclick="sil(<?php echo $e['id']; ?>)"
            style="background:#FEE2E2;color:#EF4444;border:none;width:26px;height:26px;border-radius:6px;cursor:pointer;font-size:11px">🗑</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<!-- SAĞ: Doğum günleri listesi -->
<div>
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust"><div class="kart-bas">🎂 Yaklaşan Doğum Günleri (30 Gün)</div></div>
    <?php if (empty($dogum_gunleri)): ?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:13px">Doğum tarihi girilmiş personel yok.
</div>
    <?php else: foreach ($dogum_gunleri as $d):
      $fark = $d['fark'];
      $bg   = $fark === 0 ? '#FEF3C7' : ($fark === 1 ? '#FFF7ED' : 'transparent');
      $renk = $fark === 0 ? '#92400E' : ($fark === 1 ? '#B45309' : 'var(--m)');
      $rozet = $fark === 0 ? '🎂 Bugün' : ($fark === 1 ? '⚠️ Yarın' : $fark.' gün sonra');
      $rozet_bg = $fark === 0 ? '#F97316' : ($fark === 1 ? '#FEF3C7' : '#F3F4F6');
      $rozet_renk = $fark === 0 ? '#fff' : ($fark === 1 ? '#92400E' : '#6B7280');
      $vt_badge = $d['vardiya_tipi'] === 'beyaz' ? '<span style="font-size:9px;background:#D1FAE5;color:#065F46;padding:1px 5px;border-radius:6px;font-weight:700;margin-left:4px">Beyaz</span>' : '';
    ?>
    <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--kenar);background:<?php echo $bg; ?>">
      <div style="width:36px;height:36px;border-radius:50%;background:<?php echo $fark<=1?'#F97316':'#E5E7EB'; ?>;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">
        <?php echo $fark===0?'🎂':($fark===1?'🎈':'👤'); ?>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:13px;color:<?php echo $renk; ?>"><?php echo htmlspecialchars($d['ad_soyad']); ?><?php echo $vt_badge; ?></div>
        <div style="font-size:11px;color:var(--m2)"><?php echo date('d.m', strtotime($d['tarih'])); ?></div>
      </div>
      <div style="text-align:right">
        <span style="background:<?php echo $rozet_bg; ?>;color:<?php echo $rozet_renk; ?>;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px;white-space:nowrap"><?php echo $rozet; ?></span>
        <?php if ($fark <= 3): ?>
        <div style="margin-top:4px">
          <button onclick="etkinlikEkleKutlama(<?php echo $d['personel_id']; ?>,'<?php echo addslashes($d['ad_soyad']); ?>','<?php echo $d['tarih']; ?>')"
            style="background:#F97316;color:#fff;border:none;padding:3px 8px;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap">+ Organize Et</button>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>
</div>
</div>

<!-- Modal -->
<div id="etkinlikModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.96);backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;margin-bottom:16px">
      <div style="font-size:15px;font-weight:800" id="etkinlikModalBaslik">🎉 Yeni Etkinlik</div>
      <button onclick="modalKapat()" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:30px;height:30px;cursor:pointer">✕</button>
    </div>
    <div style="display:grid;gap:10px">
      <input type="hidden" id="eId">
      <div>
        <label class="form-etiket">Başlık *</label>
        <input type="text" id="eBaslik" class="form-alan" placeholder="Etkinlik başlığı">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label class="form-etiket">Tarih *</label>
          <input type="date" id="eTarih" class="form-alan" value="<?php echo date('Y-m-d'); ?>">
        </div>
        <div>
          <label class="form-etiket">Saat</label>
          <input type="time" id="eSaat" class="form-alan">
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label class="form-etiket">Tür</label>
          <select id="eTur" class="form-alan">
            <?php foreach($tur_cfg as $k=>$v): ?>
            <option value="<?php echo $k; ?>"><?php echo $v['ikon'].' '.$v['et']; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="form-etiket">Durum</label>
          <select id="eDurum" class="form-alan">
            <?php foreach($durum_cfg as $k=>$v): ?>
            <option value="<?php echo $k; ?>"><?php echo $v['et']; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div>
        <label class="form-etiket">İlgili Kişi</label>
        <input type="text" id="eIlgiliAdi" class="form-alan" placeholder="Ad Soyad">
        <input type="hidden" id="eIlgiliId">
      </div>
      <div>
        <label class="form-etiket">Açıklama</label>
        <textarea id="eAck" class="form-alan" rows="2" style="resize:none"></textarea>
      </div>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
      <button onclick="modalKapat()" style="padding:10px 18px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
      <button onclick="kaydet()" id="eKaydetBtn" style="padding:10px 22px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">💾 Kaydet</button>
    </div>
  </div>
</div>

<script>
var AJAX = '<?php echo BASE_URL; ?>/bolumler/idari/ajax/etkinlik-kaydet.php';

function modalAc() {
    document.getElementById('eId').value = '';
    document.getElementById('eBaslik').value = '';
    document.getElementById('eTarih').value = '<?php echo date('Y-m-d'); ?>';
    document.getElementById('eSaat').value = '';
    document.getElementById('eTur').value = 'ozel';
    document.getElementById('eDurum').value = 'planli';
    document.getElementById('eIlgiliAdi').value = '';
    document.getElementById('eIlgiliId').value = '';
    document.getElementById('eAck').value = '';
    document.getElementById('etkinlikModalBaslik').textContent = '🎉 Yeni Etkinlik';
    document.getElementById('etkinlikModal').style.display = 'flex';
}
function modalKapat() { document.getElementById('etkinlikModal').style.display = 'none'; }

function etkinlikEkleKutlama(pid, adi, tarih) {
    document.getElementById('eId').value = '';
    document.getElementById('eBaslik').value = adi + ' Doğum Günü Kutlaması 🎂';
    document.getElementById('eTarih').value = tarih;
    document.getElementById('eSaat').value = '10:00';
    document.getElementById('eTur').value = 'kutlama';
    document.getElementById('eDurum').value = 'planli';
    document.getElementById('eIlgiliAdi').value = adi;
    document.getElementById('eIlgiliId').value = pid;
    document.getElementById('eAck').value = adi + ' için doğum günü kutlaması organizasyonu.';
    document.getElementById('etkinlikModalBaslik').textContent = '🎂 Kutlama Organize Et';
    document.getElementById('etkinlikModal').style.display = 'flex';
}

function duzenle(e) {
    document.getElementById('eId').value = e.id;
    document.getElementById('eBaslik').value = e.baslik || '';
    document.getElementById('eTarih').value = e.tarih || '';
    document.getElementById('eSaat').value = e.saat ? e.saat.substring(0,5) : '';
    document.getElementById('eTur').value = e.tur || 'ozel';
    document.getElementById('eDurum').value = e.durum || 'planli';
    document.getElementById('eIlgiliAdi').value = e.ilgili_adi || '';
    document.getElementById('eIlgiliId').value = e.ilgili_id || '';
    document.getElementById('eAck').value = e.aciklama || '';
    document.getElementById('etkinlikModalBaslik').textContent = '✏️ Etkinlik Düzenle';
    document.getElementById('etkinlikModal').style.display = 'flex';
}

function kaydet() {
    var baslik = document.getElementById('eBaslik').value.trim();
    var tarih  = document.getElementById('eTarih').value;
    if (!baslik || !tarih) { alert('Başlık ve tarih zorunlu'); return; }
    var btn = document.getElementById('eKaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    var data = {
        id:         document.getElementById('eId').value,
        baslik:     baslik,
        tarih:      tarih,
        saat:       document.getElementById('eSaat').value,
        tur:        document.getElementById('eTur').value,
        durum:      document.getElementById('eDurum').value,
        ilgili_id:  document.getElementById('eIlgiliId').value,
        ilgili_adi: document.getElementById('eIlgiliAdi').value,
        aciklama:   document.getElementById('eAck').value,
    };
    fetch(AJAX, {method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)})
    .then(function(r){return r.json();})
    .then(function(r){
        if (r.ok) location.reload();
        else { alert('Hata: '+(r.hata||'?')); btn.disabled=false; btn.textContent='💾 Kaydet'; }
    }).catch(function(){ alert('Bağlantı hatası'); btn.disabled=false; btn.textContent='💾 Kaydet'; });
}

function sil(id) {
    if (!confirm('Etkinlik silinsin mi?')) return;
    fetch(AJAX, {method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({islem:'sil', id:id})})
    .then(function(r){return r.json();})
    .then(function(r){ if(r.ok) location.reload(); else alert('Hata'); });
}
</script>
