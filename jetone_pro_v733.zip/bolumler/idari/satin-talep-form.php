<?php
/**
 * İdari İşler — Yeni Satınalma Talebi Formu
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$user   = Auth::kullanici();
$uid    = (int)$user['id'];
// Session'da ad_soyad alanı var
$u_adi = trim($user['ad_soyad'] ?? (($user['ad'] ?? '') . ' ' . ($user['soyad'] ?? '')));
if (!$u_adi && !empty($user['id'])) {
    // DB'den al
    $uq = $db->prepare("SELECT CONCAT(ad,' ',soyad) FROM kullanicilar WHERE id=? LIMIT 1");
    $uq->execute([$uid]); $u_adi = $uq->fetchColumn() ?: 'Kullanıcı';
}

// Düzenleme modu
$edit_id = (int)($_GET['id'] ?? 0);
$talep   = null;
$kalemler_mevcut = [];

if ($edit_id) {
    $q = $db->prepare("SELECT * FROM satin_alma_talepler WHERE id=? AND (talep_eden_id=? OR 1=1) LIMIT 1");
    $q->execute([$edit_id, $uid]);
    $talep = $q->fetch();
    if ($talep) {
        $kq = $db->prepare("SELECT * FROM satin_alma_kalemler WHERE talep_id=? ORDER BY sira_no");
        $kq->execute([$edit_id]);
        $kalemler_mevcut = $kq->fetchAll();
    }
}

// Kullanıcının departmanı
try {
    $dept_q = $db->prepare("SELECT d.ad FROM personeller p JOIN departmanlar d ON p.departman_id=d.id WHERE p.kullanici_id=? LIMIT 1");
    $dept_q->execute([$uid]);
    $user_dept = $dept_q->fetchColumn() ?: '';
} catch (Throwable $e) { $user_dept = ''; }

$v = function($key, $default = '') use ($talep) {
    return htmlspecialchars($talep[$key] ?? $default);
};
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $edit_id ? 'Talebi Düzenle' : 'Yeni Satınalma Talebi'; ?></h1>
    <div class="s-yol">İdari İşler / Satınalma / <b><?php echo $edit_id ? 'Düzenle' : 'Yeni Talep'; ?></b></div>
  </div>
  <a href="?sayfa=idari-satin-talepler" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Listeye Dön</a>
</div>

<div class="s-body">
<form id="talepForm">
<?php if ($edit_id): ?>
<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?>">
<?php endif; ?>

<!-- Üst bilgiler -->
<div class="kart" style="margin-bottom:14px;padding:16px 20px">
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;align-items:end">

    <div>
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">Talep Eden</label>
      <input type="text" class="form-alan" value="<?php echo htmlspecialchars($u_adi); ?>" readonly
             style="background:var(--bg);color:var(--m2)">
      <input type="hidden" name="talep_eden_id" value="<?php echo $uid; ?>">
      <input type="hidden" name="talep_eden_adi" value="<?php echo htmlspecialchars($u_adi); ?>">
    </div>

    <div>
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">Bölüm / Departman</label>
      <input type="text" class="form-alan" name="departman"
             value="<?php echo $v('departman', $user_dept); ?>"
             placeholder="Departman / Bölüm">
    </div>

    <div>
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">Öncelik</label>
      <select class="form-alan" name="oncelik">
        <?php foreach (['dusuk'=>'Düşük','normal'=>'Normal','yuksek'=>'Yüksek','acil'=>'ACİL'] as $k=>$v_tr): ?>
        <option value="<?php echo $k; ?>" <?php echo ($talep['oncelik']??'normal')===$k?'selected':''; ?>><?php echo $v_tr; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">Termin Tarihi</label>
      <input type="date" class="form-alan" name="termin_tarihi"
             value="<?php echo $v('termin_tarihi'); ?>">
    </div>

  </div>

  <!-- Talep türü -->
  <div style="margin-top:14px;display:flex;gap:24px;align-items:center">
    <span style="font-size:13px;font-weight:600;color:var(--m2)">Talep Türü:</span>
    <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:14px;font-weight:600">
      <input type="radio" name="talep_turu" value="sarf_malzeme"
             <?php echo (!$talep || $talep['talep_turu']==='sarf_malzeme')?'checked':''; ?>>
      🧴 Sarf Malzeme
    </label>
    <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:14px;font-weight:600">
      <input type="radio" name="talep_turu" value="teknik_satin_alma"
             <?php echo ($talep && $talep['talep_turu']==='teknik_satin_alma')?'checked':''; ?>>
      🔧 Teknik Satınalma
    </label>
  </div>
</div>

<!-- Kalemler tablosu -->
<div class="kart" style="margin-bottom:14px;overflow:hidden">
  <div class="kart-ust" style="display:flex;align-items:center;justify-content:space-between">
    <div class="kart-bas">Talep Kalemleri</div>
    <button type="button" onclick="satırEkle()" style="width:32px;height:32px;background:var(--t);color:#fff;border:none;border-radius:8px;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1">+</button>
  </div>

  <div style="overflow-x:auto">
  <table style="width:100%;border-collapse:collapse;font-size:13px" id="kalemTablo">
    <thead>
      <tr style="background:#1E293B;color:#fff">
        <th style="padding:10px 8px;text-align:center;width:44px;white-space:nowrap">Sıra<br>No</th>
        <th style="padding:10px 8px;width:100px">Ürün / Malzeme<br>Kodu</th>
        <th style="padding:10px 8px;min-width:240px">Ürün / Malzeme Ölçüsü ve Adı <span style="color:#FDA58E">*</span></th>
        <th style="padding:10px 8px;width:130px">Marka</th>
        <th style="padding:10px 8px;width:80px;text-align:right">Miktar</th>
        <th style="padding:10px 8px;width:90px">Birim</th>
        <th style="padding:10px 8px;min-width:200px">Açıklama (Kullanım Yeri)</th>
        <th style="padding:10px 8px;width:36px"></th>
      </tr>
    </thead>
    <tbody id="kalemBody">
    </tbody>
  </table>
  </div>

  <div style="padding:10px 16px;display:flex;justify-content:flex-end;align-items:center;gap:16px;border-top:1px solid var(--kenar);background:var(--bg)">
    <span style="font-size:13px;color:var(--m2)">
      Satır: <strong id="satirSay">0</strong>
      &nbsp;|&nbsp;
      Toplam Miktar: <strong id="toplamMiktar">0</strong>
    </span>
  </div>
</div>

<!-- Açıklama + Kaydet -->
<div class="kart" style="padding:16px 20px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start">
    <div>
      <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">
        Açıklama <span style="font-weight:400;text-transform:none">(Tedarikçi önerileri, teknik şartnameler, özel notlar...)</span>
      </label>
      <textarea class="form-alan" name="aciklama" rows="3"
                placeholder="Tedarikçi önerileri, teknik şartnameler, özel notlar..."
                style="resize:vertical"><?php echo $v('aciklama'); ?></textarea>
    </div>
    <div style="display:flex;flex-direction:column;gap:10px;padding-top:24px;min-width:280px">
      <?php
// Mail alıcılarını göster — departman adına göre eşleştir
$mud_mail_goster = $mud_isim = $idari_mail_goster = $idari_isim = '';
try {
    $mr = $db->query("SELECT p.email, CONCAT(p.ad,' ',p.soyad) isim
        FROM personeller p JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif' AND p.email IS NOT NULL AND p.email!=''
          AND (d.ad LIKE '%Satınalma%' OR d.ad LIKE '%Satin%'
               OR p.pozisyon LIKE '%Satınalma%Müdür%' OR p.unvan LIKE '%Satınalma%Müdür%')
        ORDER BY CASE WHEN p.pozisyon LIKE '%Müdür%' OR p.unvan LIKE '%Müdür%' THEN 0 ELSE 1 END LIMIT 1")->fetch();
    $mud_mail_goster = $mr ? $mr['email'] : '';
    $mud_isim        = $mr ? $mr['isim']  : '';

    $ir = $db->query("SELECT p.email, CONCAT(p.ad,' ',p.soyad) isim
        FROM personeller p JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif' AND p.email IS NOT NULL AND p.email!=''
          AND (d.ad LIKE '%İdari%' OR d.ad LIKE '%Idari%'
               OR p.pozisyon LIKE '%İdari%Sorumlu%' OR p.unvan LIKE '%İdari%İşler%')
        ORDER BY CASE WHEN p.pozisyon LIKE '%Sorumlu%' OR p.unvan LIKE '%Sorumlu%' THEN 0 ELSE 1 END LIMIT 1")->fetch();
    $idari_mail_goster = $ir ? $ir['email'] : '';
    $idari_isim        = $ir ? $ir['isim']  : '';

    if (!$mud_mail_goster)   $mud_mail_goster   = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='satin_mudur_mail' LIMIT 1")->fetchColumn() ?: '';
    if (!$idari_mail_goster) $idari_mail_goster = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='idari_sorumlu_mail' LIMIT 1")->fetchColumn() ?: '';
} catch (Throwable $e) {}
?>
      <!-- Mail alıcıları -->
      <div style="background:var(--bg);border:1.5px solid var(--kenar);border-radius:8px;padding:10px 14px;font-size:12px">
        <div style="font-size:10px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:6px;letter-spacing:.5px">📧 Mail Gönderilecek</div>
        <div style="display:flex;flex-direction:column;gap:4px">
          <div style="display:flex;align-items:center;gap:6px">
            <span style="width:6px;height:6px;border-radius:50%;background:#3B82F6;flex-shrink:0"></span>
            <span style="color:var(--m2)">Talep Eden:</span>
            <span style="font-weight:600;color:var(--m)"><?php echo htmlspecialchars($user['email'] ?? 'mail yok'); ?></span>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <span style="width:6px;height:6px;border-radius:50%;background:#F97316;flex-shrink:0"></span>
            <span style="color:var(--m2)">Satınalma Müdürü:</span>
            <span style="font-weight:600;color:<?php echo $mud_mail_goster ? 'var(--m)' : '#EF4444'; ?>">
              <?php if ($mud_isim ?? ''): ?><span style="color:var(--m)"><?php echo htmlspecialchars($mud_isim); ?></span> <span style="color:var(--m2);font-weight:400">&lt;<?php echo htmlspecialchars($mud_mail_goster); ?>&gt;</span>
              <?php elseif ($mud_mail_goster): ?><?php echo htmlspecialchars($mud_mail_goster); ?>
              <?php else: ?>⚠ Pozisyon bulunamadı<?php endif; ?>
            </span>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <span style="width:6px;height:6px;border-radius:50%;background:#10B981;flex-shrink:0"></span>
            <span style="color:var(--m2)">İdari Sorumlu:</span>
            <span style="font-weight:600;color:<?php echo $idari_mail_goster ? 'var(--m)' : '#EF4444'; ?>">
              <?php if ($idari_isim ?? ''): ?><span style="color:var(--m)"><?php echo htmlspecialchars($idari_isim); ?></span> <span style="color:var(--m2);font-weight:400">&lt;<?php echo htmlspecialchars($idari_mail_goster); ?>&gt;</span>
              <?php elseif ($idari_mail_goster): ?><?php echo htmlspecialchars($idari_mail_goster); ?>
              <?php else: ?>⚠ Pozisyon bulunamadı<?php endif; ?>
            </span>
          </div>
        </div>
        <?php if (!$mud_mail_goster || !$idari_mail_goster): ?>
        <div style="margin-top:8px;padding:6px 8px;background:#FEF2F2;border-radius:6px;font-size:11px;color:#991B1B">
          ⚠ Personel listesinde "Satınalma Müdürü" ve/veya "İdari İşler Sorumlusu" pozisyonu/ünvanı olan aktif personel bulunamadı.
        </div>
        <?php endif; ?>
      </div>

      <button type="button" onclick="talepKaydet()" id="kaydetBtn"
              style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap">
        💾 Talebi Kaydet
      </button>
    </div>
  </div>
</div>

</form>
</div>

<script>
var SATIR_NO = 1;
var EDIT_ID  = <?php echo $edit_id ?: 0; ?>;
var MEVCUT_KALEMLER = <?php echo json_encode($kalemler_mevcut, JSON_UNESCAPED_UNICODE); ?>;
var BIRIMLER = ['Adet','Kutu','Paket','Kg','Lt','Mt','Takım','Rulo','Çift','Set','Palet'];

function satırHtml(no, kalem) {
    var k = kalem || {};
    var birimOpts = BIRIMLER.map(function(b){
        var sel = (k.birim||'Adet')===b ? 'selected' : '';
        return '<option '+sel+'>'+b+'</option>';
    }).join('');
    return '<tr id="satir-'+no+'" style="transition:background .15s">'
        +'<td style="padding:6px 8px;text-align:center;font-weight:700;color:var(--m2);background:var(--bg)">'+no+'</td>'
        +'<td style="padding:4px 6px"><input type="text" class="form-alan" name="k_kod[]" value="'+(k.urun_kodu||'')+'" placeholder="Kod" style="font-size:12px;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><input type="text" class="form-alan kalem-adi" name="k_adi[]" value="'+(k.urun_adi||'')+'" placeholder="Ürün / malzeme adı ve ölçüsü" required style="font-size:13px;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><input type="text" class="form-alan" name="k_marka[]" value="'+(k.marka||'')+'" placeholder="Marka" style="font-size:12px;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><input type="number" class="form-alan k-miktar" name="k_miktar[]" value="'+(k.miktar||1)+'" min="0.001" step="any" style="font-size:13px;padding:7px 9px;text-align:right" oninput="toplamGuncelle()"></td>'
        +'<td style="padding:4px 6px"><select class="form-alan" name="k_birim[]" style="font-size:12px;padding:7px 9px">'+birimOpts+'</select></td>'
        +'<td style="padding:4px 6px"><input type="text" class="form-alan" name="k_aciklama[]" value="'+(k.aciklama||'')+'" placeholder="Kullanım yeri / açıklama" style="font-size:12px;padding:7px 9px"></td>'
        +'<td style="padding:4px 8px;text-align:center">'
        +'<button type="button" onclick="satirSil('+no+')" style="width:24px;height:24px;border:none;background:#FEE2E2;color:#EF4444;border-radius:4px;cursor:pointer;font-size:14px;display:inline-flex;align-items:center;justify-content:center">×</button>'
        +'</td></tr>';
}

function satırEkle(kalem) {
    document.getElementById('kalemBody').insertAdjacentHTML('beforeend', satırHtml(SATIR_NO++, kalem));
    toplamGuncelle();
}

function satirSil(no) {
    var row = document.getElementById('satir-'+no);
    if (row) { row.remove(); toplamGuncelle(); satirNoGuncelle(); }
}

function satirNoGuncelle() {
    var rows = document.querySelectorAll('#kalemBody tr');
    rows.forEach(function(r, i) {
        var td = r.querySelector('td:first-child');
        if (td) td.textContent = (i+1);
    });
}

function toplamGuncelle() {
    var rows  = document.querySelectorAll('#kalemBody tr');
    var toplam = 0;
    rows.forEach(function(r) {
        var inp = r.querySelector('.k-miktar');
        if (inp) toplam += parseFloat(inp.value)||0;
    });
    document.getElementById('satirSay').textContent    = rows.length;
    document.getElementById('toplamMiktar').textContent = toplam.toLocaleString('tr-TR', {maximumFractionDigits:3});
}

function talepKaydet() {
    var rows = document.querySelectorAll('#kalemBody tr');
    if (rows.length === 0) { alert('En az bir kalem ekleyin.'); return; }

    var bosKalem = false;
    rows.forEach(function(r){
        var adi = r.querySelector('.kalem-adi');
        if (adi && !adi.value.trim()) bosKalem = true;
    });
    if (bosKalem) { alert('Ürün/Malzeme Adı boş bırakılamaz.'); return; }

    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.innerHTML = '⏳ Kaydediliyor...';

    var form = document.getElementById('talepForm');
    var fd   = new FormData(form);

    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/satin-talep-kaydet.php', {
        method:'POST', body: fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled=false; btn.innerHTML='💾 Talebi Kaydet';
        if (r.ok) {
            if (typeof JT !== 'undefined') JT.bildirim('Talep kaydedildi!','basari');
            location.href='?sayfa=idari-satin-talepler';
        } else {
            alert('Hata: '+(r.hata||'Bilinmeyen hata'));
        }
    }).catch(function(){
        btn.disabled=false; btn.innerHTML='💾 Talebi Kaydet';
        alert('Bağlantı hatası');
    });
}

// Sayfa yüklenince
document.addEventListener('DOMContentLoaded', function(){
    if (MEVCUT_KALEMLER && MEVCUT_KALEMLER.length > 0) {
        MEVCUT_KALEMLER.forEach(function(k){ satırEkle(k); });
    } else {
        // Yeni form: 4 boş satır
        for (var i=0; i<4; i++) satırEkle();
    }
});
</script>
