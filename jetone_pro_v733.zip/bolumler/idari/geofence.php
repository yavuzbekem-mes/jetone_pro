<?php
/** İK — Geofence / İş Yeri Konum Yönetimi */
if (!Auth::girisYapilmisMi()) return;
$kul = Auth::kullanici();
$super_admin = ((int)($kul['rol_id']??0) === 1);

// Kaydet
if ($_SERVER['REQUEST_METHOD']==='POST' && $super_admin) {
    $islem = $_POST['islem']??'';
    try {
        if ($islem==='kaydet') {
            $ad  = trim($_POST['ad']??'');
            $lat = (float)$_POST['lat'];
            $lng = (float)$_POST['lng'];
            $m   = max(50,(int)$_POST['yaricap']);
            $id  = (int)($_POST['id']??0);
            if ($id) {
                $db->prepare("UPDATE geofence_lokasyonlari SET ad=?,lat=?,lng=?,yaricap_metre=? WHERE id=?")->execute([$ad,$lat,$lng,$m,$id]);
            } else {
                $db->prepare("INSERT INTO geofence_lokasyonlari (ad,lat,lng,yaricap_metre,aktif) VALUES (?,?,?,?,1)")->execute([$ad,$lat,$lng,$m]);
            }
            Auth::logKaydet($kul['id'],'geofence_kaydet','idari',null,"Geofence güncellendi: $ad");
        } elseif ($islem==='toggle') {
            $id = (int)$_POST['id'];
            $db->prepare("UPDATE geofence_lokasyonlari SET aktif=NOT aktif WHERE id=?")->execute([$id]);
        } elseif ($islem==='sil') {
            $id = (int)$_POST['id'];
            $db->prepare("DELETE FROM geofence_lokasyonlari WHERE id=?")->execute([$id]);
        } elseif ($islem==='ayar') {
            $zorunlu = (int)($_POST['zorunlu']??0);
            $db->exec("INSERT INTO ayarlar (anahtar,deger) VALUES ('geofence_zorunlu','$zorunlu') ON DUPLICATE KEY UPDATE deger='$zorunlu'");
        }
    } catch(Exception $e){ $hata = $e->getMessage(); }
    header('Location: '.BASE_URL.'/panel.php?sayfa=idari-geofence'); exit;
}

$lokasyonlar = [];
try { $lokasyonlar = $db->query("SELECT * FROM geofence_lokasyonlari ORDER BY id")->fetchAll(); } catch(Exception $e){}
$gf_zorunlu = false;
try { $gf_zorunlu = (bool)$db->query("SELECT deger FROM ayarlar WHERE anahtar='geofence_zorunlu' LIMIT 1")->fetchColumn(); } catch(Exception $e){}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📍 Geofence — İş Yeri Konum Yönetimi</h1>
    <div class="s-yol">İdari / <b>Geofence</b></div>
  </div>

  <button onclick="dtExcelIndir('tbl-geofence','Geofence')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">

<?php if (!$super_admin): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m2)">⛔ Bu sayfayı yönetmek için Süper Admin yetkisi gereklidir.</div>
<?php else: ?>

<!-- Geofence zorunlu mu ayarı -->
<div class="kart" style="margin-bottom:14px">
  <div class="kart-ust"><div class="kart-bas">⚙️ Genel Ayar</div></div>
  <form method="POST" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
    <input type="hidden" name="islem" value="ayar">
    <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:14px;font-weight:600">
      <input type="checkbox" name="zorunlu" value="1" <?php echo $gf_zorunlu?'checked':''; ?> style="width:18px;height:18px;accent-color:var(--t)">
      Geofence Zorunlu — İş yeri dışından giriş/çıkış yapılamaz
    </label>
    <button type="submit" class="btn btn-t btn-sm">Kaydet</button>
  </form>
  <div style="font-size:12px;color:var(--m2);margin-top:8px">
    ℹ️ Kapalı iken iş yeri dışından giriş yapılabilir (uyarı gösterilir). Açık iken iş yeri dışından giriş reddedilir.
  </div>
</div>

<!-- Yeni lokasyon ekle / düzenle -->
<div class="kart" style="margin-bottom:14px">
  <div class="kart-ust"><div class="kart-bas">➕ Lokasyon Ekle / Güncelle</div></div>
  <form method="POST">
    <input type="hidden" name="islem" value="kaydet">
    <input type="hidden" name="id" id="gfId" value="0">
    <div class="form-grid-2">
      <div class="form-grup">
        <label class="form-et">Lokasyon Adı <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="ad" id="gfAd" placeholder="Ana Fabrika" required>
      </div>
      <div class="form-grup">
        <label class="form-et">Yarıçap (metre) <span class="zorunlu">*</span></label>
        <input type="number" class="form-alan" name="yaricap" id="gfYaricap" value="200" min="50" max="2000">
      </div>
      <div class="form-grup">
        <label class="form-et">Enlem (Latitude) <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="lat" id="gfLat" placeholder="41.290089" required>
      </div>
      <div class="form-grup">
        <label class="form-et">Boylam (Longitude) <span class="zorunlu">*</span></label>
        <input type="text" class="form-alan" name="lng" id="gfLng" placeholder="27.969982" required>
      </div>
      <div class="form-grup form-span-2">
        <label class="form-et">📍 Koordinat Yardımı</label>
        <div style="background:var(--bg);border-radius:var(--r);padding:10px 14px;font-size:13px;color:var(--m2)">
          Google Maps'te konuma sağ tıklayın → koordinatları kopyalayın.<br>
          Örn: <code style="background:#fff;padding:2px 6px;border-radius:4px">41.290089, 27.969982</code>
          → Enlem: <b>41.290089</b>, Boylam: <b>27.969982</b>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:8px;margin-top:10px">
      <button type="submit" class="btn btn-t">💾 Kaydet</button>
      <button type="button" class="btn btn-b" onclick="formuSifirla()">✕ İptal</button>
      <button type="button" class="btn btn-b" onclick="konumAlGF()">📍 Mevcut Konumumu Kullan</button>
    </div>
  </form>
</div>

<!-- Lokasyon listesi -->
<div class="kart">
  <div class="kart-ust"><div class="kart-bas">📍 Kayıtlı Lokasyonlar</div></div>
  <?php if (empty($lokasyonlar)): ?>
  <div style="padding:24px;text-align:center;color:var(--m2)">Henüz lokasyon eklenmemiş</div>
  <?php else: ?>
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="tbl-geofence">
    <thead><tr><th>Lokasyon Adı</th><th>Koordinat</th><th>Yarıçap</th><th>Durum</th><th>İşlemler</th></tr></thead>
    <tbody>
    <?php foreach ($lokasyonlar as $l): ?>
    <tr>
      <td><b><?php echo htmlspecialchars($l['ad']); ?></b></td>
      <td style="font-family:monospace;font-size:12px"><?php echo $l['lat']; ?>, <?php echo $l['lng']; ?></td>
      <td><?php echo $l['yaricap_metre']; ?> m</td>
      <td><span class="roz" style="background:<?php echo $l['aktif']?'#D1FADF':'#FEE4E2'; ?>;color:<?php echo $l['aktif']?'#0A8F4E':'#F04438'; ?>"><?php echo $l['aktif']?'✓ Aktif':'✗ Pasif'; ?></span></td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn btn-sm btn-b" onclick="duzenle(<?php echo htmlspecialchars(json_encode($l)); ?>)">✏️</button>
          <form method="POST" style="display:inline"><input type="hidden" name="islem" value="toggle"><input type="hidden" name="id" value="<?php echo $l['id']; ?>"><button type="submit" class="btn btn-sm btn-b"><?php echo $l['aktif']?'⏸':'▶'; ?></button></form>
          <form method="POST" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="islem" value="sil"><input type="hidden" name="id" value="<?php echo $l['id']; ?>"><button type="submit" class="btn btn-sm" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer">🗑</button></form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<script>
function duzenle(l) {
  document.getElementById('gfId').value = l.id;
  document.getElementById('gfAd').value = l.ad;
  document.getElementById('gfLat').value = l.lat;
  document.getElementById('gfLng').value = l.lng;
  document.getElementById('gfYaricap').value = l.yaricap_metre;
  window.scrollTo({top:0,behavior:'smooth'});
}
function formuSifirla() {
  document.getElementById('gfId').value = '0';
  document.getElementById('gfAd').value = '';
  document.getElementById('gfLat').value = '';
  document.getElementById('gfLng').value = '';
  document.getElementById('gfYaricap').value = '200';
}
function konumAlGF() {
  if (!navigator.geolocation) { alert('Konum desteklenmiyor'); return; }
  navigator.geolocation.getCurrentPosition(function(p){
    document.getElementById('gfLat').value = p.coords.latitude.toFixed(6);
    document.getElementById('gfLng').value = p.coords.longitude.toFixed(6);
    alert('Konum alındı: ' + p.coords.latitude.toFixed(6) + ', ' + p.coords.longitude.toFixed(6));
  }, function(){ alert('Konum alınamadı'); });
}
</script>
<?php endif; ?>
</div>
