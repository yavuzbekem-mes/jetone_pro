<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
$t = null; $kalemler = [];
if ($id) {
    $q = $db->prepare("SELECT * FROM teklifler WHERE id=? LIMIT 1");
    $q->execute([$id]); $t = $q->fetch();
    if ($t) {
        $kq = $db->prepare("SELECT * FROM teklif_kalemleri WHERE teklif_id=? ORDER BY sira");
        $kq->execute([$id]); $kalemler = $kq->fetchAll();
    }
}
$v = function($k,$d='') use ($t) { return htmlspecialchars($t[$k] ?? $d); };
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Teklif Düzenle' : 'Yeni Teklif'; ?></h1>
    <div class="s-yol">İdari / <a href="?sayfa=idari-teklif-listesi" style="color:var(--t);text-decoration:none">Teklifler</a> / <b><?php echo $id ? $v('teklif_no') : 'Yeni'; ?></b></div>
  </div>
  <a href="?sayfa=idari-teklif-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Geri</a>
</div>

<div class="s-body">
<form id="teklifForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">Teklif Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">
    <div>
      <label class="form-etiket">Teklif Tipi</label>
      <select class="form-alan" name="tip">
        <option value="alinan" <?php echo ($t['tip']??'alinan')==='alinan'?'selected':''; ?>>Alinan Teklif</option>
        <option value="verilen" <?php echo ($t['tip']??'')==='verilen'?'selected':''; ?>>Verilen Teklif</option>
      </select>
    </div>
    <div>
      <label class="form-etiket">Durum</label>
      <select class="form-alan" name="durum">
        <?php foreach (['taslak'=>'Taslak','gonderildi'=>'Gonderildi','kabul'=>'Kabul','red'=>'Reddedildi','revize'=>'Revize'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($t['durum']??'taslak')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Para Birimi</label>
      <select class="form-alan" name="para_birimi">
        <option value="TRY" <?php echo ($t['para_birimi']??'TRY')==='TRY'?'selected':''; ?>>TRY</option>
        <option value="USD" <?php echo ($t['para_birimi']??'')==='USD'?'selected':''; ?>>USD</option>
        <option value="EUR" <?php echo ($t['para_birimi']??'')==='EUR'?'selected':''; ?>>EUR</option>
      </select>
    </div>
    <div>
      <label class="form-etiket">Gecerlilik Tarihi</label>
      <input type="date" class="form-alan" name="gecerlilik_tarihi" value="<?php echo $v('gecerlilik_tarihi'); ?>">
    </div>
    <div style="grid-column:1/5">
      <label class="form-etiket">Konu <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="konu" value="<?php echo $v('konu'); ?>" placeholder="Teklif konusu" required>
    </div>
    <div>
      <label class="form-etiket">Tedarikci / Firma</label>
      <input type="text" class="form-alan" name="tedarikci_adi" value="<?php echo $v('tedarikci_adi'); ?>">
    </div>
    <div>
      <label class="form-etiket">E-posta</label>
      <input type="email" class="form-alan" name="tedarikci_email" value="<?php echo $v('tedarikci_email'); ?>">
    </div>
    <div>
      <label class="form-etiket">Telefon</label>
      <input type="text" class="form-alan" name="tedarikci_tel" value="<?php echo $v('tedarikci_tel'); ?>">
    </div>
    <div>
      <label class="form-etiket">KDV</label>
      <select class="form-alan" name="kdv_dahil">
        <option value="1" <?php echo ($t['kdv_dahil']??1)?'selected':''; ?>>KDV Dahil</option>
        <option value="0" <?php echo isset($t['kdv_dahil'])&&!$t['kdv_dahil']?'selected':''; ?>>KDV Haric</option>
      </select>
    </div>
  </div>
</div>

<div class="kart" style="margin-bottom:14px;overflow:hidden">
  <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
    <div class="kart-bas">Teklif Kalemleri</div>
    <button type="button" onclick="kalemEkle(null)" style="width:32px;height:32px;background:var(--t);color:#fff;border:none;border-radius:8px;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1">+</button>
  </div>
  <div style="overflow-x:auto">
  <table style="width:100%;border-collapse:collapse;font-size:13px">
    <thead>
      <tr style="background:#0F172A;color:#fff">
        <th style="padding:10px 8px;width:36px;text-align:center">#</th>
        <th style="padding:10px 8px;min-width:240px;text-align:left">Urun / Hizmet Adi</th>
        <th style="padding:10px 8px;width:80px;text-align:right">Miktar</th>
        <th style="padding:10px 8px;width:80px">Birim</th>
        <th style="padding:10px 8px;width:120px;text-align:right">Birim Fiyat</th>
        <th style="padding:10px 8px;width:60px;text-align:right">KDV%</th>
        <th style="padding:10px 8px;width:70px;text-align:right">Indirim%</th>
        <th style="padding:10px 8px;width:130px;text-align:right">Toplam</th>
        <th style="padding:10px 8px;width:32px"></th>
      </tr>
    </thead>
    <tbody id="kalemBody"></tbody>
  </table>
  </div>
  <div style="padding:12px 16px;display:flex;justify-content:flex-end;gap:24px;border-top:1px solid var(--kenar);background:var(--bg)">
    <span style="font-size:13px;color:var(--m2)">Ara Toplam: <strong id="araToplam">0,00</strong></span>
    <span style="font-size:13px;color:var(--m2)">KDV: <strong id="kdvToplam">0,00</strong></span>
    <span style="font-size:15px;font-weight:800;color:var(--t)">TOPLAM: <strong id="genelToplam">0,00</strong></span>
  </div>
</div>

<div class="kart" style="padding:16px 20px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start">
    <div>
      <label class="form-etiket">Notlar</label>
      <textarea class="form-alan" name="notlar" rows="3" placeholder="Odeme kosullari, teslimat suresi..."><?php echo $v('notlar'); ?></textarea>
    </div>
    <div style="padding-top:22px">
      <button type="button" onclick="kaydet()" id="kaydetBtn"
        style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit;white-space:nowrap">
        Kaydet
      </button>
    </div>
  </div>
</div>
</form>
</div>

<script>
var SIRA = 1;
var MEVCUT = <?php echo json_encode($kalemler, JSON_UNESCAPED_UNICODE); ?>;
var BIRIMLER = ['Adet','Saat','Gun','Ay','Kg','Lt','Mt','Paket','Kutu','Set'];

function kalemEkle(k) {
    k = k || {};
    var birimOpts = BIRIMLER.map(function(b){
        return '<option'+(b===(k.birim||'Adet')?' selected':'')+'>'+b+'</option>';
    }).join('');
    var no = SIRA++;
    var html = '<tr id="kr-'+no+'">'
        +'<td style="padding:6px 8px;text-align:center;color:var(--m2);font-size:12px">'+no+'</td>'
        +'<td style="padding:4px 6px"><input type="text" class="form-alan" name="k_adi[]" value="'+(k.urun_adi||'')+'" required style="font-size:13px;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><input type="number" class="form-alan k-mik" name="k_miktar[]" value="'+(k.miktar||1)+'" min="0.001" step="any" oninput="topla()" style="text-align:right;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><select class="form-alan" name="k_birim[]" style="padding:7px 9px">'+birimOpts+'</select></td>'
        +'<td style="padding:4px 6px"><input type="number" class="form-alan k-fiy" name="k_birim_fiyat[]" value="'+(k.birim_fiyat||'')+'" step="0.01" oninput="topla()" style="text-align:right;padding:7px 9px" placeholder="0,00"></td>'
        +'<td style="padding:4px 6px"><input type="number" class="form-alan k-kdv" name="k_kdv[]" value="'+(k.kdv_oran||20)+'" min="0" max="100" oninput="topla()" style="text-align:right;padding:7px 9px"></td>'
        +'<td style="padding:4px 6px"><input type="number" class="form-alan k-ind" name="k_indirim[]" value="'+(k.indirim_oran||0)+'" min="0" max="100" step="0.1" oninput="topla()" style="text-align:right;padding:7px 9px"></td>'
        +'<td style="padding:6px 8px;text-align:right;font-weight:700;font-size:13px" id="kr-top-'+no+'">—</td>'
        +'<td style="padding:4px 8px;text-align:center"><button type="button" onclick="document.getElementById(\'kr-'+no+'\').remove();topla()" style="width:24px;height:24px;border:none;background:#FEE2E2;color:#EF4444;border-radius:4px;cursor:pointer;font-size:14px">x</button></td>'
        +'</tr>';
    document.getElementById('kalemBody').insertAdjacentHTML('beforeend', html);
    topla();
}

function topla() {
    var rows = document.querySelectorAll('#kalemBody tr');
    var ara = 0, kdvT = 0;
    rows.forEach(function(r) {
        var no = r.id.replace('kr-','');
        var m = parseFloat(r.querySelector('.k-mik').value)||0;
        var f = parseFloat(r.querySelector('.k-fiy').value)||0;
        var kdv = parseFloat(r.querySelector('.k-kdv').value)||0;
        var ind = parseFloat(r.querySelector('.k-ind').value)||0;
        var sat = m * f * (1 - ind/100);
        var satKdv = sat * kdv / 100;
        ara += sat; kdvT += satKdv;
        var td = document.getElementById('kr-top-'+no);
        if (td) td.textContent = sat.toLocaleString('tr-TR',{minimumFractionDigits:2});
    });
    document.getElementById('araToplam').textContent = ara.toLocaleString('tr-TR',{minimumFractionDigits:2});
    document.getElementById('kdvToplam').textContent = kdvT.toLocaleString('tr-TR',{minimumFractionDigits:2});
    document.getElementById('genelToplam').textContent = (ara+kdvT).toLocaleString('tr-TR',{minimumFractionDigits:2});
}

function kaydet() {
    var rows = document.querySelectorAll('#kalemBody tr');
    if (!rows.length) { alert('En az bir kalem ekleyin.'); return; }
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    var fd = new FormData(document.getElementById('teklifForm'));
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/teklif-kaydet.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled = false; btn.textContent = 'Kaydet';
        if (r.ok) { location.href = '?sayfa=idari-teklif-detay&id='+r.id; }
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){ btn.disabled=false; btn.textContent='Kaydet'; alert('Baglanti hatasi'); });
}

document.addEventListener('DOMContentLoaded', function(){
    if (MEVCUT && MEVCUT.length) { MEVCUT.forEach(function(k){ kalemEkle(k); }); }
    else { kalemEkle(null); }
});
</script>
