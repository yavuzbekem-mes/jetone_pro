<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$id = (int)($_GET['id'] ?? 0);
$arac = null;
if ($id) {
    $q = $db->prepare("SELECT * FROM araclar WHERE id=? LIMIT 1");
    $q->execute([$id]); $arac = $q->fetch();
}

// Personel listesi (sorumlu için)
$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad, pozisyon FROM personeller WHERE durum='aktif' ORDER BY ad,soyad")->fetchAll();

$v = function($k,$d='') use ($arac) { return htmlspecialchars($arac[$k] ?? $d); };
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Araç Düzenle' : 'Yeni Araç Ekle'; ?></h1>
    <div class="s-yol">İdari / <a href="?sayfa=idari-arac-listesi" style="color:var(--t);text-decoration:none">Araçlar</a> / <b><?php echo $id ? $v('plaka') : 'Yeni'; ?></b></div>
  </div>
  <a href="?sayfa=idari-arac-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Geri</a>
</div>

<div class="s-body">
<form id="aracForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">🚗 Araç Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">

    <div style="grid-column:1/3">
      <label class="form-etiket">Plaka <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="plaka" value="<?php echo $v('plaka'); ?>" placeholder="34 ABC 123" required style="text-transform:uppercase;font-weight:700;font-size:16px;letter-spacing:1px">
    </div>

    <div>
      <label class="form-etiket">Durum</label>
      <select class="form-alan" name="durum">
        <?php foreach (['aktif'=>'Aktif','bakim'=>'Bakımda','pasif'=>'Pasif','hurda'=>'Hurda'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($arac['durum']??'aktif')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-etiket">Yakıt Tipi</label>
      <select class="form-alan" name="yakit_tipi">
        <?php foreach (['benzin'=>'Benzin','dizel'=>'Dizel','lpg'=>'LPG','elektrik'=>'Elektrik','hibrit'=>'Hibrit'] as $k=>$et): ?>
        <option value="<?php echo $k; ?>" <?php echo ($arac['yakit_tipi']??'dizel')===$k?'selected':''; ?>><?php echo $et; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-etiket">Marka</label>
      <input type="text" class="form-alan" name="marka" value="<?php echo $v('marka'); ?>" placeholder="Ford, Renault...">
    </div>
    <div>
      <label class="form-etiket">Model</label>
      <input type="text" class="form-alan" name="model" value="<?php echo $v('model'); ?>" placeholder="Transit, Clio...">
    </div>
    <div>
      <label class="form-etiket">Yıl</label>
      <input type="number" class="form-alan" name="yil" value="<?php echo $v('yil'); ?>" min="1990" max="<?php echo date('Y')+1; ?>" placeholder="2020">
    </div>
    <div>
      <label class="form-etiket">Renk</label>
      <input type="text" class="form-alan" name="renk" value="<?php echo $v('renk'); ?>" placeholder="Beyaz">
    </div>

    <div>
      <label class="form-etiket">Araç Cinsi</label>
      <input type="text" class="form-alan" name="cins" value="<?php echo $v('cins'); ?>" placeholder="Binek, Kamyonet...">
    </div>
    <div>
      <label class="form-etiket">Motor No</label>
      <input type="text" class="form-alan" name="motor_no" value="<?php echo $v('motor_no'); ?>">
    </div>
    <div>
      <label class="form-etiket">Şasi No</label>
      <input type="text" class="form-alan" name="sasi_no" value="<?php echo $v('sasi_no'); ?>">
    </div>
    <div>
      <label class="form-etiket">Ruhsat Sahibi</label>
      <input type="text" class="form-alan" name="ruhsat_sahibi" value="<?php echo $v('ruhsat_sahibi'); ?>">
    </div>

    <div>
      <label class="form-etiket">Güncel KM</label>
      <input type="number" class="form-alan" name="km_guncel" value="<?php echo $v('km_guncel','0'); ?>" min="0">
    </div>
    <div>
      <label class="form-etiket">Sorumlu Personel</label>
      <select class="form-alan" name="sorumlu_id">
        <option value="">— Seçiniz —</option>
        <?php foreach ($personeller as $p): ?>
        <option value="<?php echo $p['id']; ?>" <?php echo ($arac['sorumlu_id']??'')==$p['id']?'selected':''; ?>><?php echo htmlspecialchars($p['ad_soyad']); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
</div>

<div class="kart" style="margin-bottom:14px;padding:20px">
  <div class="kart-bas" style="margin-bottom:16px">📅 Tarihler</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">
    <div>
      <label class="form-etiket">Muayene Bitiş</label>
      <input type="date" class="form-alan" name="muayene_bitis" value="<?php echo $v('muayene_bitis'); ?>">
    </div>
    <div>
      <label class="form-etiket">Sigorta Bitiş</label>
      <input type="date" class="form-alan" name="sigorta_bitis" value="<?php echo $v('sigorta_bitis'); ?>">
    </div>
    <div>
      <label class="form-etiket">Kasko Bitiş</label>
      <input type="date" class="form-alan" name="kasko_bitis" value="<?php echo $v('kasko_bitis'); ?>">
    </div>
    <div>
      <label class="form-etiket">Egzoz Bitiş</label>
      <input type="date" class="form-alan" name="egzos_bitis" value="<?php echo $v('egzos_bitis'); ?>">
    </div>
  </div>
</div>

<div class="kart" style="padding:20px">
  <div style="display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start">
    <div>
      <label class="form-etiket">Notlar</label>
      <textarea class="form-alan" name="notlar" rows="3"><?php echo $v('notlar'); ?></textarea>
    </div>
    <div style="padding-top:22px">
      <button type="button" onclick="kaydet()" id="kaydetBtn" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-weight:800;font-size:15px;cursor:pointer;font-family:inherit;white-space:nowrap">
        💾 Kaydet
      </button>
    </div>
  </div>
</div>

</form>
</div>

<script>
function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled = true; btn.innerHTML = '⏳ Kaydediliyor...';
    var fd = new FormData(document.getElementById('aracForm'));
    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/arac-kaydet.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled=false; btn.innerHTML='💾 Kaydet';
        if (r.ok) { if(typeof JT!=='undefined') JT.bildirim('Araç kaydedildi!','basari'); location.href='?sayfa=idari-arac-detay&id='+r.id; }
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){ btn.disabled=false; btn.innerHTML='💾 Kaydet'; alert('Bağlantı hatası'); });
}
</script>
