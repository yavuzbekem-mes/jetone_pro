<?php
/**
 * Güvenlik — Ziyaretçi Giriş Çıkış Takip
 * panel.php: 'idari-guvenlik-ziyaretci' => 'bolumler/idari/guvenlik_ziyaretci.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$db->exec("CREATE TABLE IF NOT EXISTS guv_ziyaretci (
    z_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ad_soyad     VARCHAR(100) NOT NULL,
    tc_no        VARCHAR(11),
    firma        VARCHAR(100),
    tel          VARCHAR(20),
    ziyaret_amaci VARCHAR(200),
    gorusulen    VARCHAR(100),
    plaka        VARCHAR(20),
    giris_zaman  DATETIME NOT NULL,
    cikis_zaman  DATETIME,
    rozet_no     VARCHAR(20),
    guvenlik     VARCHAR(100),
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_gz(giris_zaman)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$mesaj=''; $mesaj_tip='';
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'giris_kaydet':
            try {
                $db->prepare("INSERT INTO guv_ziyaretci (ad_soyad,tc_no,firma,tel,ziyaret_amaci,gorusulen,plaka,giris_zaman,rozet_no,guvenlik) VALUES(?,?,?,?,?,?,?,?,?,?)")
                   ->execute([$_POST['ad_soyad'],$_POST['tc_no']??'',$_POST['firma']??'',$_POST['tel']??'',$_POST['ziyaret_amaci']??'',$_POST['gorusulen']??'',$_POST['plaka']??'',$_POST['giris_zaman'],$_POST['rozet_no']??'',$_POST['guvenlik']??$kul_adi]);
                $mesaj='Ziyaretçi girişi kaydedildi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'cikis_kaydet':
            try {
                $db->prepare("UPDATE guv_ziyaretci SET cikis_zaman=? WHERE z_id=?")
                   ->execute([$_POST['cikis_zaman'],(int)$_POST['z_id']]);
                $mesaj='Çıkış kaydedildi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'sil':
            try {
                $db->prepare("DELETE FROM guv_ziyaretci WHERE z_id=?")->execute([(int)$_POST['z_id']]);
                $mesaj='Silindi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
    }
}

// Son 30 gün
$kayitlar = $db->query("SELECT * FROM guv_ziyaretci WHERE giris_zaman >= DATE_SUB(NOW(),INTERVAL 30 DAY) ORDER BY giris_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
$iceridelar = array_filter($kayitlar, fn($r)=>empty($r['cikis_zaman']));
$bugun = array_filter($kayitlar, fn($r)=>date('Y-m-d',strtotime($r['giris_zaman']))===date('Y-m-d'));
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">👤 Ziyaretçi Takip</h1>
    <div class="s-yol">İdari İşler / Güvenlik / <b>Ziyaretçi</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="modalAc('zGirisModal')" class="btn btn-t btn-sm">+ Ziyaretçi Girişi</button>
  </div>
</div>
<div class="s-body">
<?php if ($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?= $mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2' ?>;color:<?= $mesaj_tip==='ok'?'#065F46':'#7F1D1D' ?>;border-left:4px solid <?= $mesaj_tip==='ok'?'#22C55E':'#EF4444' ?>"><?= htmlspecialchars($mesaj) ?></div>
<?php endif; ?>

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px" class="ziy-grid">
  <div class="kart" style="padding:12px;border-left:4px solid #F59E0B;text-align:center">
    <div style="font-size:24px;font-weight:900;color:#D97706"><?= count($iceridelar) ?></div>
    <div style="font-size:11px;font-weight:700">Şu An İçeride</div>
  </div>
  <div class="kart" style="padding:12px;border-left:4px solid #2563EB;text-align:center">
    <div style="font-size:24px;font-weight:900;color:#2563EB"><?= count($bugun) ?></div>
    <div style="font-size:11px;font-weight:700">Bugün Toplam</div>
  </div>
  <div class="kart" style="padding:12px;border-left:4px solid #22C55E;text-align:center">
    <div style="font-size:24px;font-weight:900;color:#059669"><?= count($kayitlar) ?></div>
    <div style="font-size:11px;font-weight:700">Son 30 Gün</div>
  </div>
</div>

<!-- İçeridekiler -->
<?php if (!empty($iceridelar)): ?>
<div style="margin-bottom:14px">
  <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px;text-transform:uppercase">Şu An Fabrikada</div>
  <div style="display:flex;flex-wrap:wrap;gap:10px">
  <?php foreach ($iceridelar as $r): ?>
  <div class="kart" style="padding:10px 14px;border-left:4px solid #F59E0B;background:#FFFBEB;min-width:200px">
    <div style="font-weight:800;font-size:13px"><?= htmlspecialchars($r['ad_soyad']) ?></div>
    <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($r['firma']??'') ?><?= $r['rozet_no']?" | Rozet: {$r['rozet_no']}":'' ?></div>
    <div style="font-size:10px;color:var(--m3)">Giriş: <?= htmlspecialchars($r['giris_zaman']) ?></div>
    <div style="font-size:10px;color:var(--m2)">Görüşülen: <?= htmlspecialchars($r['gorusulen']??'') ?></div>
    <button onclick="zCikisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm" style="margin-top:4px;padding:2px 8px;font-size:10px;background:#D97706;color:#fff;border:none;border-radius:4px;cursor:pointer">Çıkış Yap</button>
  </div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden"><div style="overflow-x:auto">
<table id="tblZiyaretci" style="width:100%">
  <thead><tr><th>#</th><th>Ad Soyad</th><th>TC</th><th>Firma</th><th>Tel</th><th>Amaç</th><th>Görüşülen</th><th>Plaka</th><th>Rozet</th><th>Giriş</th><th>Çıkış</th><th>Durum</th><th>İşlem</th></tr></thead>
  <tfoot><tr><th>#</th><th>Ad Soyad</th><th>TC</th><th>Firma</th><th>Tel</th><th>Amaç</th><th>Görüşülen</th><th>Plaka</th><th>Rozet</th><th>Giriş</th><th>Çıkış</th><th>Durum</th><th>İşlem</th></tr></tfoot>
  <tbody>
  <?php foreach ($kayitlar as $i => $r):
    $dis = empty($r['cikis_zaman']);
    $sure = !$dis ? round((strtotime($r['cikis_zaman'])-strtotime($r['giris_zaman']))/60) : '';
  ?>
  <tr style="background:<?= $dis?'#FFFBEB':'' ?>">
    <td><?= $i+1 ?></td>
    <td style="font-weight:700"><?= htmlspecialchars($r['ad_soyad']) ?></td>
    <td style="font-family:monospace"><?= htmlspecialchars($r['tc_no']??'') ?></td>
    <td><?= htmlspecialchars($r['firma']??'') ?></td>
    <td><?= htmlspecialchars($r['tel']??'') ?></td>
    <td style="font-size:11px"><?= htmlspecialchars($r['ziyaret_amaci']??'') ?></td>
    <td><?= htmlspecialchars($r['gorusulen']??'') ?></td>
    <td><?= htmlspecialchars($r['plaka']??'') ?></td>
    <td><?= htmlspecialchars($r['rozet_no']??'') ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['giris_zaman']) ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['cikis_zaman']??'') ?></td>
    <td><span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $dis?'#FEF9C3':'#D1FAE5' ?>;color:<?= $dis?'#78350F':'#065F46' ?>"><?= $dis?'İçeride':'Çıktı' ?><?= $sure?" ($sure dk)":'' ?></span></td>
    <td style="white-space:nowrap">
      <?php if ($dis): ?>
      <button onclick="zCikisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm btn-t" style="font-size:11px;padding:3px 8px">Çıkış</button>
      <?php endif; ?>
      <button onclick="zSil(<?= $r['z_id'] ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">Sil</button>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div></div>

<!-- Giriş Modal -->
<div id="zGirisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:560px;max-width:95vw;padding:20px;max-height:92vh;overflow-y:auto">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">👤 Ziyaretçi Giriş Kaydı</div>
    <button onclick="modalKapat('zGirisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="giris_kaydet">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="col-span-2"><label class="form-et">Ad Soyad <span style="color:#EF4444">*</span></label><input name="ad_soyad" class="form-alan" required style="width:100%"></div>
      <div><label class="form-et">TC Kimlik No</label><input name="tc_no" class="form-alan" maxlength="11" pattern="[0-9]{11}"></div>
      <div><label class="form-et">Firma</label><input name="firma" class="form-alan"></div>
      <div><label class="form-et">Telefon</label><input name="tel" class="form-alan" type="tel"></div>
      <div><label class="form-et">Plaka</label><input name="plaka" class="form-alan"></div>
      <div class="col-span-2"><label class="form-et">Ziyaret Amacı</label><input name="ziyaret_amaci" class="form-alan" style="width:100%"></div>
      <div><label class="form-et">Görüşülecek Kişi</label><input name="gorusulen" class="form-alan"></div>
      <div><label class="form-et">Rozet No</label><input name="rozet_no" class="form-alan" placeholder="V-001"></div>
      <div><label class="form-et">Giriş Zamanı</label><input type="datetime-local" name="giris_zaman" class="form-alan" id="zGirisZaman" required></div>
      <div><label class="form-et">Güvenlik</label><input name="guvenlik" class="form-alan" value="<?= htmlspecialchars($kul_adi) ?>" required></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('zGirisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Giriş Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Çıkış Modal -->
<div id="zCikisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:360px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">🚪 Ziyaretçi Çıkışı</div>
    <button onclick="modalKapat('zCikisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="cikis_kaydet">
    <input type="hidden" name="z_id" id="zCikis_id">
    <div style="background:var(--kenar-a);border-radius:8px;padding:10px;font-size:12px;margin-bottom:10px" id="zCikisOzet"></div>
    <div><label class="form-et">Çıkış Zamanı</label><input type="datetime-local" name="cikis_zaman" class="form-alan" id="zCikisZaman" required></div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('zCikisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Çıkışı Kaydet</button>
    </div>
  </form>
</div>
</div>

<form method="POST" id="zSilForm" style="display:none"><input type="hidden" name="action" value="sil"><input type="hidden" name="z_id" id="zSil_id"></form>

</div>
<style>
@media(max-width:600px){.ziy-grid{grid-template-columns:1fr!important}}
#tblZiyaretci thead th,#tblZiyaretci tfoot th{background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;white-space:nowrap;border-right:1px solid #2D4E7A}
#tblZiyaretci tbody td{padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px}
#tblZiyaretci tfoot select{width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg)}
</style>
<script>
function modalAc(id){document.getElementById(id).style.display='flex';}
function modalKapat(id){document.getElementById(id).style.display='none';}
document.getElementById('zGirisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();

function zCikisModal(r){
    document.getElementById('zCikis_id').value=r.z_id;
    document.getElementById('zCikisOzet').innerHTML='<strong>'+(r.ad_soyad||'')+'</strong>'+(r.firma?' — '+r.firma:'')+'<br>Giriş: '+(r.giris_zaman||'')+(r.rozet_no?' | Rozet: '+r.rozet_no:'');
    document.getElementById('zCikisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();
    modalAc('zCikisModal');
}
function zSil(id){if(!confirm('Silmek istediğinizden emin misiniz?'))return; document.getElementById('zSil_id').value=id; document.getElementById('zSilForm').submit();}

$(document).ready(function(){
    $('#tblZiyaretci').DataTable({
        initComplete:function(){this.api().columns([1,3,6,11]).every(function(){var col=this,sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+v+'</option>');});});},
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        order:[[9,'desc']],scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
        dom:'Bfrtip',buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Ziyaretci_<?= date("Ymd") ?>'},'print']
    });
});
</script>
