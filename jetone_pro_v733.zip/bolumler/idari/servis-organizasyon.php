<?php
/**
 * İdari İşler — Servis & Yemek Organizasyonu
 * bolumler/idari/servis-organizasyon.php
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$hafta_bas = $_GET['hafta'] ?? date('Y-m-d', strtotime('monday this week'));
$hafta_bas = date('Y-m-d', strtotime('monday', strtotime($hafta_bas)));
$hafta_bit = date('Y-m-d', strtotime($hafta_bas . ' +6 days'));
$onceki    = date('Y-m-d', strtotime($hafta_bas . ' -7 days'));
$sonraki   = date('Y-m-d', strtotime($hafta_bas . ' +7 days'));
$bugun     = date('Y-m-d');
$bu_hafta  = ($hafta_bas === date('Y-m-d', strtotime('monday this week')));

$vardiya_tanimlari = [
    1 => ['ad' => '1. Vardiya', 'saat' => '08:00–16:00', 'giris' => '08:00', 'renk' => '#D1FAE5', 'renk_k' => '#065F46', 'bg' => '#10B981'],
    2 => ['ad' => '2. Vardiya', 'saat' => '16:00–00:00', 'giris' => '16:00', 'renk' => '#DBEAFE', 'renk_k' => '#1E40AF', 'bg' => '#3B82F6'],
    3 => ['ad' => '3. Vardiya', 'saat' => '00:00–08:00', 'giris' => '00:00', 'renk' => '#F3E8FF', 'renk_k' => '#6D28D9', 'bg' => '#7C3AED'],
];

$durak_tanimlari = [
    'cerkezkoy'  => ['ad' => 'Çerkezköy',  'ikon' => '🚌'],
    'kizilpinar' => ['ad' => 'Kızılpınar', 'ikon' => '🚌'],
    'kapakli'    => ['ad' => 'Kapaklı',    'ikon' => '🚌'],
    'karaagac'   => ['ad' => 'Karaağaç',   'ikon' => '🚌'],
];

$kadro_tanimlari = [
    'beyaz_yaka' => ['ad' => 'Beyaz Yaka', 'gun' => 5],
    'endirekt'   => ['ad' => 'Endirekt',   'gun' => 6],
    'direkt'     => ['ad' => 'Direkt',     'gun' => 6],
    'stajyer'    => ['ad' => 'Stajyer',    'gun' => 6],
];

try {
    // Vardiya ID → No eşlemesi
    $varIdToNo = [];
    $varRows = $db->query("SELECT id,baslangic FROM vardialar WHERE aktif=1 ORDER BY id")->fetchAll();
    foreach ($varRows as $r) {
        $s = substr($r['baslangic'], 0, 5);
        if     ($s === '08:00') $varIdToNo[$r['id']] = 1;
        elseif ($s === '16:00') $varIdToNo[$r['id']] = 2;
        elseif ($s === '00:00') $varIdToNo[$r['id']] = 3;
    }

    // Bu haftanın atamalarını çek
    $atamaMap = [];
    $atamaQ = $db->prepare("SELECT va.personel_id, va.vardiya_id FROM vardiya_atamalari va
        WHERE va.baslangic<=? AND (va.bitis IS NULL OR va.bitis>=?)");
    $atamaQ->execute([$hafta_bit, $hafta_bas]);
    foreach ($atamaQ->fetchAll() as $a) {
        $atamaMap[$a['personel_id']] = $varIdToNo[$a['vardiya_id']] ?? (int)$a['vardiya_id'];
    }

    // Aktif personelleri çek
    $perQ = $db->query("SELECT id, ad, soyad, sicil_no, kadro, servis_durak, vardiya_tipi, aktif_vardiya,
        departman_id FROM personeller WHERE durum='aktif' AND vardiya_tipi IS NOT NULL ORDER BY ad");
    $personeller = $perQ->fetchAll();

    // Her personelin aktif vardiya no'sunu belirle
    $per_veri = [];
    foreach ($personeller as $p) {
        $vno = $atamaMap[$p['id']] ?? (int)($p['aktif_vardiya'] ?? 0);
        if (!$vno && $p['vardiya_tipi'] === 'tek') $vno = 1;
        $per_veri[] = array_merge($p, ['vardiya_no' => $vno]);
    }

    // İstatistikler
    // 1. Vardiyaya göre personel sayısı
    $vardiya_sayilari = [1 => 0, 2 => 0, 3 => 0, 'tek' => 0];
    foreach ($per_veri as $p) {
        if ($p['vardiya_tipi'] === 'tek') $vardiya_sayilari['tek']++;
        elseif ($p['vardiya_no']) $vardiya_sayilari[$p['vardiya_no']] = ($vardiya_sayilari[$p['vardiya_no']] ?? 0) + 1;
    }

    // 2. Durak × Vardiya matrisi
    $durak_vardiya = [];
    foreach (array_keys($durak_tanimlari) as $dk) {
        $durak_vardiya[$dk] = [1 => [], 2 => [], 3 => [], 'tek' => []];
    }
    $durak_vardiya['yok'] = [1 => [], 2 => [], 3 => [], 'tek' => []];

    foreach ($per_veri as $p) {
        $dk  = $p['servis_durak'] ?: 'yok';
        $vno = $p['vardiya_tipi'] === 'tek' ? 'tek' : ($p['vardiya_no'] ?: 0);
        if ($vno && isset($durak_vardiya[$dk][$vno])) {
            $durak_vardiya[$dk][$vno][] = $p;
        }
    }

    // 3. Yemek sayısı (vardiyaya göre)
    $yemek = [1 => 0, 2 => 0, 3 => 0, 'tek' => 0];
    foreach ($per_veri as $p) {
        $vno = $p['vardiya_tipi'] === 'tek' ? 'tek' : ($p['vardiya_no'] ?: null);
        if ($vno) $yemek[$vno]++;
    }

} catch (Throwable $e) {
    $per_veri = []; $durak_vardiya = []; $vardiya_sayilari = []; $yemek = [];
}

$toplam_personel = count($per_veri);
$servis_kullanan = count(array_filter($per_veri, fn($p) => !empty($p['servis_durak'])));
?>

<div class="s-bar">
    <div>
        <h1 class="s-bas">🚌 Servis & Yemek Organizasyonu</h1>
        <div class="s-yol">İdari İşler / <b>Servis & Yemek Organizasyonu</b></div>
    </div>
    <div style="display:flex;gap:8px;align-items:center">
        <button onclick="window.print()" style="background:var(--bg);border:1.5px solid var(--kenar);color:var(--m);padding:9px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;font-family:inherit">🖨 Yazdır</button>
    </div>
</div>

<div class="s-body">

    <!-- Hafta navigasyon -->
    <div style="display:flex;align-items:center;justify-content:space-between;background:var(--yuzey);border-radius:var(--r-lg);padding:14px 20px;margin-bottom:20px;box-shadow:var(--golge)">
        <a href="?sayfa=idari-servis&hafta=<?php echo $onceki; ?>" style="padding:8px 18px;border-radius:8px;background:var(--bg);color:var(--m);text-decoration:none;font-weight:600;font-size:13px">‹ Önceki</a>
        <div style="text-align:center">
            <div style="font-size:16px;font-weight:800"><?php echo date('d M', strtotime($hafta_bas)); ?> – <?php echo date('d M Y', strtotime($hafta_bit)); ?></div>
            <?php if ($bu_hafta): ?>
                <span style="font-size:11px;background:var(--t);color:#fff;padding:2px 10px;border-radius:10px;font-weight:700">Bu Hafta</span>
            <?php endif; ?>
        </div>
        <a href="?sayfa=idari-servis&hafta=<?php echo $sonraki; ?>" style="padding:8px 18px;border-radius:8px;background:var(--bg);color:var(--m);text-decoration:none;font-weight:600;font-size:13px">Sonraki ›</a>
    </div>

    <!-- Genel özet kartlar -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:24px">
        <div style="background:var(--yuzey);border-radius:var(--r-lg);padding:18px;text-align:center;box-shadow:var(--golge)">
            <div style="font-size:32px;font-weight:900;color:var(--m)"><?php echo $toplam_personel; ?></div>
            <div style="font-size:12px;font-weight:700;color:var(--m2);margin-top:4px">TOPLAM PERSONEL</div>
        </div>
        <div style="background:var(--yuzey);border-radius:var(--r-lg);padding:18px;text-align:center;box-shadow:var(--golge)">
            <div style="font-size:32px;font-weight:900;color:#10B981"><?php echo $servis_kullanan; ?></div>
            <div style="font-size:12px;font-weight:700;color:var(--m2);margin-top:4px">SERVİS KULLANAN</div>
        </div>
        <?php foreach ($vardiya_tanimlari as $vno => $vd): ?>
        <div style="background:<?php echo $vd['renk']; ?>;border-radius:var(--r-lg);padding:18px;text-align:center;box-shadow:var(--golge)">
            <div style="font-size:32px;font-weight:900;color:<?php echo $vd['renk_k']; ?>"><?php echo $vardiya_sayilari[$vno] ?? 0; ?></div>
            <div style="font-size:11px;font-weight:700;color:<?php echo $vd['renk_k']; ?>;margin-top:2px"><?php echo $vd['ad']; ?></div>
            <div style="font-size:10px;color:<?php echo $vd['renk_k']; ?>;opacity:.8"><?php echo $vd['saat']; ?></div>
        </div>
        <?php endforeach; ?>
        <div style="background:#FEF3E8;border-radius:var(--r-lg);padding:18px;text-align:center;box-shadow:var(--golge)">
            <div style="font-size:32px;font-weight:900;color:#B45309"><?php echo $vardiya_sayilari['tek'] ?? 0; ?></div>
            <div style="font-size:11px;font-weight:700;color:#B45309;margin-top:2px">Tek Vardiya</div>
            <div style="font-size:10px;color:#B45309;opacity:.8">08:00–16:00</div>
        </div>
    </div>

    <!-- ═══ DURAK × VARDİYA MATRİSİ ═══ -->
    <div style="margin-bottom:24px">
        <h2 style="font-size:15px;font-weight:800;margin-bottom:12px;color:var(--m)">🚌 Durak Bazlı Servis Planı</h2>
        <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;background:var(--yuzey);border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--golge)">
            <thead>
                <tr style="background:#F9FAFB">
                    <th style="padding:12px 16px;text-align:left;font-size:12px;font-weight:700;color:var(--m2);border-bottom:2px solid var(--kenar)">DURAK</th>
                    <?php foreach ($vardiya_tanimlari as $vno => $vd): ?>
                    <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:<?php echo $vd['renk_k']; ?>;border-bottom:2px solid var(--kenar);background:<?php echo $vd['renk']; ?>">
                        <?php echo $vd['ad']; ?><br><span style="font-size:10px;font-weight:400"><?php echo $vd['saat']; ?></span>
                    </th>
                    <?php endforeach; ?>
                    <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:#B45309;border-bottom:2px solid var(--kenar);background:#FEF3E8">
                        Tek Vardiya<br><span style="font-size:10px;font-weight:400">08:00–16:00</span>
                    </th>
                    <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:var(--m2);border-bottom:2px solid var(--kenar)">TOPLAM</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $durak_goster = array_merge(array_keys($durak_tanimlari), ['yok']);
                foreach ($durak_goster as $dk):
                    if (!isset($durak_vardiya[$dk])) continue;
                    $dv = $durak_vardiya[$dk];
                    $toplam_dk = array_sum(array_map('count', $dv));
                    if ($toplam_dk === 0) continue;
                    $durak_adi = $dk === 'yok' ? '— Servis Kullanmıyor' : ($durak_tanimlari[$dk]['ikon'] . ' ' . $durak_tanimlari[$dk]['ad']);
                    $satir_bg  = $dk === 'yok' ? '#FAFAFA' : '#fff';
                ?>
                <tr style="background:<?php echo $satir_bg; ?>;border-bottom:1px solid var(--kenar)" <?php echo $dk !== 'yok' ? 'class="durak-satir"' : ''; ?>>
                    <td style="padding:14px 16px;font-weight:700;font-size:14px"><?php echo $durak_adi; ?></td>
                    <?php foreach ($vardiya_tanimlari as $vno => $vd): ?>
                    <td style="padding:14px 16px;text-align:center;cursor:<?php echo count($dv[$vno]) > 0 ? 'pointer' : 'default'; ?>"
                        onclick="<?php echo count($dv[$vno]) > 0 ? "detayGoster('$dk',$vno)" : ''; ?>">
                        <?php if (count($dv[$vno]) > 0): ?>
                        <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:<?php echo $vd['bg']; ?>;color:#fff;font-size:15px;font-weight:800;cursor:pointer">
                            <?php echo count($dv[$vno]); ?>
                        </span>
                        <?php else: ?>
                        <span style="color:var(--m3);font-size:13px">—</span>
                        <?php endif; ?>
                    </td>
                    <?php endforeach; ?>
                    <td style="padding:14px 16px;text-align:center;cursor:<?php echo count($dv['tek']) > 0 ? 'pointer' : 'default'; ?>"
                        onclick="<?php echo count($dv['tek']) > 0 ? "detayGoster('$dk','tek')" : ''; ?>">
                        <?php if (count($dv['tek']) > 0): ?>
                        <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:#F97316;color:#fff;font-size:15px;font-weight:800">
                            <?php echo count($dv['tek']); ?>
                        </span>
                        <?php else: ?>
                        <span style="color:var(--m3);font-size:13px">—</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:14px 16px;text-align:center;font-size:16px;font-weight:900;color:var(--m)"><?php echo $toplam_dk; ?></td>
                </tr>
                <?php endforeach; ?>
                <!-- Toplam satırı -->
                <tr style="background:#F9FAFB;border-top:2px solid var(--kenar)">
                    <td style="padding:14px 16px;font-weight:800;font-size:14px">TOPLAM</td>
                    <?php foreach ([1,2,3,'tek'] as $vno): ?>
                    <td style="padding:14px 16px;text-align:center;font-size:16px;font-weight:900;color:var(--m)">
                        <?php echo array_sum(array_map(fn($dk) => count($durak_vardiya[$dk][$vno] ?? []), $durak_goster)); ?>
                    </td>
                    <?php endforeach; ?>
                    <td style="padding:14px 16px;text-align:center;font-size:18px;font-weight:900;color:var(--t)"><?php echo $toplam_personel; ?></td>
                </tr>
            </tbody>
        </table>
        </div>
    </div>

    <!-- ═══ YEMEK SAYISI ═══ -->
    <div style="margin-bottom:24px">
        <h2 style="font-size:15px;font-weight:800;margin-bottom:12px;color:var(--m)">🍽 Vardiya Yemek Sayıları</h2>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
            <?php foreach ($vardiya_tanimlari as $vno => $vd):
                $yemek_say = $yemek[$vno] ?? 0;
                // Beyaz yaka haftanın 5 günü, diğerleri 6 gün — yemek 5 veya 6 gün
                // Günlük yemek = kişi sayısı, haftalık = kişi × gün
            ?>
            <div style="background:var(--yuzey);border-radius:var(--r-lg);padding:20px;box-shadow:var(--golge);border-left:4px solid <?php echo $vd['bg']; ?>">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                    <div>
                        <div style="font-size:14px;font-weight:800;color:<?php echo $vd['renk_k']; ?>"><?php echo $vd['ad']; ?></div>
                        <div style="font-size:12px;color:var(--m2)"><?php echo $vd['saat']; ?> · Giriş <?php echo $vd['giris']; ?></div>
                    </div>
                    <div style="width:44px;height:44px;border-radius:50%;background:<?php echo $vd['bg']; ?>;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;font-weight:900"><?php echo $yemek_say; ?></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                    <div style="background:<?php echo $vd['renk']; ?>;border-radius:8px;padding:10px;text-align:center">
                        <div style="font-size:18px;font-weight:900;color:<?php echo $vd['renk_k']; ?>"><?php echo $yemek_say; ?></div>
                        <div style="font-size:10px;color:<?php echo $vd['renk_k']; ?>;font-weight:600">GÜNLÜK</div>
                    </div>
                    <div style="background:<?php echo $vd['renk']; ?>;border-radius:8px;padding:10px;text-align:center">
                        <div style="font-size:18px;font-weight:900;color:<?php echo $vd['renk_k']; ?>"><?php echo $yemek_say * 5; ?></div>
                        <div style="font-size:10px;color:<?php echo $vd['renk_k']; ?>;font-weight:600">HAFTALIK</div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <!-- Tek vardiya -->
            <?php $tek_say = $yemek['tek'] ?? 0; ?>
            <div style="background:var(--yuzey);border-radius:var(--r-lg);padding:20px;box-shadow:var(--golge);border-left:4px solid #F97316">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                    <div>
                        <div style="font-size:14px;font-weight:800;color:#B45309">Tek Vardiya</div>
                        <div style="font-size:12px;color:var(--m2)">08:00–16:00</div>
                    </div>
                    <div style="width:44px;height:44px;border-radius:50%;background:#F97316;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;font-weight:900"><?php echo $tek_say; ?></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                    <div style="background:#FEF3E8;border-radius:8px;padding:10px;text-align:center">
                        <div style="font-size:18px;font-weight:900;color:#B45309"><?php echo $tek_say; ?></div>
                        <div style="font-size:10px;color:#B45309;font-weight:600">GÜNLÜK</div>
                    </div>
                    <div style="background:#FEF3E8;border-radius:8px;padding:10px;text-align:center">
                        <div style="font-size:18px;font-weight:900;color:#B45309"><?php echo $tek_say * 5; ?></div>
                        <div style="font-size:10px;color:#B45309;font-weight:600">HAFTALIK</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══ DETAYLI PERSONEL LİSTESİ ═══ -->
    <div>
        <h2 style="font-size:15px;font-weight:800;margin-bottom:12px;color:var(--m)">👥 Durak Bazlı Detaylı Liste</h2>
        <?php foreach ($durak_tanimlari as $dk => $dtan):
            $toplam_durak = array_sum(array_map(fn($vno) => count($durak_vardiya[$dk][$vno] ?? []), [1,2,3,'tek']));
            if ($toplam_durak === 0) continue;
        ?>
        <div style="background:var(--yuzey);border-radius:var(--r-lg);margin-bottom:16px;box-shadow:var(--golge);overflow:hidden">
            <div style="padding:14px 20px;background:linear-gradient(135deg,#1E293B,#334155);display:flex;align-items:center;justify-content:space-between">
                <div style="display:flex;align-items:center;gap:10px">
                    <span style="font-size:22px"><?php echo $dtan['ikon']; ?></span>
                    <div>
                        <div style="font-size:15px;font-weight:800;color:#fff"><?php echo $dtan['ad']; ?> Durağı</div>
                        <div style="font-size:12px;color:rgba(255,255,255,.6)"><?php echo $toplam_durak; ?> personel bu duraktan servis kullanıyor</div>
                    </div>
                </div>
                <span style="background:rgba(255,255,255,.15);color:#fff;font-size:18px;font-weight:900;padding:6px 14px;border-radius:20px"><?php echo $toplam_durak; ?></span>
            </div>
            <?php foreach ([1,2,3,'tek'] as $vno):
                $kisiler = $durak_vardiya[$dk][$vno] ?? [];
                if (empty($kisiler)) continue;
                $vd = $vno === 'tek' ? ['ad'=>'Tek Vardiya','saat'=>'08:00–16:00','renk'=>'#FEF3E8','renk_k'=>'#B45309','bg'=>'#F97316'] : $vardiya_tanimlari[$vno];
            ?>
            <div style="padding:12px 20px;background:<?php echo $vd['renk']; ?>;border-bottom:1px solid rgba(0,0,0,.05)">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    <span style="background:<?php echo $vd['bg']; ?>;color:#fff;font-size:11px;font-weight:800;padding:3px 10px;border-radius:10px"><?php echo $vd['ad']; ?> — <?php echo $vd['saat']; ?></span>
                    <span style="font-size:12px;color:<?php echo $vd['renk_k']; ?>;font-weight:600"><?php echo count($kisiler); ?> kişi</span>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:6px">
                    <?php foreach ($kisiler as $k): ?>
                    <div style="background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:8px;padding:6px 12px;font-size:12px">
                        <span style="font-weight:700"><?php echo htmlspecialchars($k['ad'].' '.$k['soyad']); ?></span>
                        <span style="color:var(--m2);font-size:11px"> · <?php echo htmlspecialchars($k['sicil_no']??''); ?></span>
                        <?php if ($k['kadro']): ?>
                        <span style="background:#F3F4F6;color:#6B7280;font-size:10px;padding:1px 5px;border-radius:4px;margin-left:4px"><?php echo ['beyaz_yaka'=>'BY','endirekt'=>'END','direkt'=>'DIR','stajyer'=>'STJ'][$k['kadro']]??''; ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Detay Modalı -->
<div id="detayModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
    <div style="background:#fff;border-radius:16px;width:min(480px,100%);max-height:80vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
        <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1">
            <h3 style="font-size:15px;font-weight:800" id="detayBaslik">Personel Listesi</h3>
            <button onclick="document.getElementById('detayModal').style.display='none'" style="border:none;background:none;font-size:22px;cursor:pointer;color:var(--m2)">✕</button>
        </div>
        <div id="detayIcerik" style="padding:20px"></div>
    </div>
</div>

<script>
const DURAK_VARDİYA_DATA = <?php echo json_encode($durak_vardiya, JSON_UNESCAPED_UNICODE); ?>;
const VAR_TAN = <?php echo json_encode($vardiya_tanimlari, JSON_UNESCAPED_UNICODE); ?>;
const DURAK_TAN = <?php echo json_encode($durak_tanimlari, JSON_UNESCAPED_UNICODE); ?>;

function detayGoster(dk, vno){
    const kisiler = DURAK_VARDİYA_DATA[dk]?.[vno] || [];
    const vd = vno==='tek' ? {ad:'Tek Vardiya',saat:'08:00-16:00',renk:'#FEF3E8',renk_k:'#B45309',bg:'#F97316'} : VAR_TAN[vno];
    const durakAdi = dk==='yok' ? 'Servis Kullanmıyor' : (DURAK_TAN[dk]?.ad || dk);

    document.getElementById('detayBaslik').textContent = durakAdi + ' — ' + (vd?.ad||'') + ' (' + kisiler.length + ' kişi)';

    const kadroAd={beyaz_yaka:'Beyaz Yaka',endirekt:'Endirekt',direkt:'Direkt',stajyer:'Stajyer'};
    document.getElementById('detayIcerik').innerHTML = kisiler.length === 0
        ? '<p style="color:#9CA3AF;text-align:center;padding:20px">Personel yok</p>'
        : '<div style="display:flex;flex-direction:column;gap:8px">' + kisiler.map(function(k){
            return '<div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:#F9FAFB;border-radius:10px">'
                + '<div style="width:36px;height:36px;border-radius:50%;background:'+(vd?.bg||'#6B7280')+';display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;font-weight:800;flex-shrink:0">'
                + (k.ad||'').charAt(0)+(k.soyad||'').charAt(0)
                + '</div>'
                + '<div style="flex:1"><div style="font-size:13px;font-weight:700">'+(k.ad||'')+' '+(k.soyad||'')+'</div>'
                + '<div style="font-size:11px;color:#6B7280">'+(k.sicil_no||'')+' · '+(kadroAd[k.kadro]||k.kadro||'')+'</div></div>'
                + '</div>';
        }).join('') + '</div>';

    document.getElementById('detayModal').style.display = 'flex';
}

document.getElementById('detayModal').onclick = function(e){ if(e.target===this) this.style.display='none'; };
</script>

<style>
.durak-satir:hover { background: #FAFBFF !important; }
@media print {
    .s-bar, nav, #detayModal { display: none !important; }
    .s-body { padding: 0 !important; }
    * { box-shadow: none !important; }
}
</style>
