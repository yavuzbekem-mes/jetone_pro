<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Türkiye Resmi Tatilleri (sabit + dini - yıla göre)
function getTatiller(int $yil): array {
    $tatiller = [];
    // Sabit tatiller
    $sabit = [
        '01-01' => 'Yılbaşı',
        '04-23' => 'Ulusal Egemenlik ve Çocuk Bayramı',
        '05-01' => 'Emek ve Dayanışma Günü',
        '05-19' => "Atatürk'ü Anma, Gençlik ve Spor Bayramı",
        '07-15' => 'Demokrasi ve Millî Birlik Günü',
        '08-30' => 'Zafer Bayramı',
        '10-28' => 'Cumhuriyet Bayramı arifesi (yarım gün)',
        '10-29' => 'Cumhuriyet Bayramı',
    ];
    foreach ($sabit as $md => $ad) {
        $tatiller["$yil-$md"] = $ad;
    }
    // Dini tatiller - Diyanet/resmi takvime göre yaklaşık hesap
    // Ramazan Bayramı: hicri takvime göre - önceden girilmiş değerler
    $dini = [
        2024 => [
            'ramazan' => ['04-10','04-11','04-12'],
            'kurban'  => ['06-16','06-17','06-18','06-19'],
        ],
        2025 => [
            'ramazan' => ['03-30','03-31','04-01'],
            'kurban'  => ['06-06','06-07','06-08','06-09'],
        ],
        2026 => [
            'ramazan' => ['03-19','03-20','03-21','03-22'], // arife dahil
            'kurban'  => ['05-27','05-28','05-29','05-30'],
        ],
        2027 => [
            'ramazan' => ['03-08','03-09','03-10'],
            'kurban'  => ['05-16','05-17','05-18','05-19'],
        ],
    ];
    if (isset($dini[$yil])) {
        foreach ($dini[$yil]['ramazan'] as $i => $md) {
            $tatiller["$yil-$md"] = $i === 0 ? 'Ramazan Bayramı Arifesi' : 'Ramazan Bayramı';
        }
        foreach ($dini[$yil]['kurban'] as $i => $md) {
            $tatiller["$yil-$md"] = $i === 0 ? 'Kurban Bayramı Arifesi' : 'Kurban Bayramı';
        }
    }
    return $tatiller;
}

// Vardiya bazlı yemek sayıları - direkt aktif_vardiya'dan
$yemek_v1_tek = 0; $yemek_v2 = 0; $yemek_v3 = 0;
try {
    $per_yemek = $db->query("SELECT vardiya_tipi, aktif_vardiya FROM personeller WHERE durum='aktif'")->fetchAll();
    foreach ($per_yemek as $p) {
        if ($p['vardiya_tipi'] === 'tek' || (int)($p['aktif_vardiya']??0) === 1) $yemek_v1_tek++;
        elseif ((int)($p['aktif_vardiya']??0) === 2) $yemek_v2++;
        elseif ((int)($p['aktif_vardiya']??0) === 3) $yemek_v3++;
    }
} catch (Throwable $e) {}

$ay   = (int)($_GET['ay']  ?? date('n'));
$yil  = (int)($_GET['yil'] ?? date('Y'));
if ($ay < 1 || $ay > 12) $ay = (int)date('n');

$ay_str  = str_pad($ay,2,'0',STR_PAD_LEFT);
$bas     = "$yil-$ay_str-01";
$bit     = date('Y-m-t', strtotime($bas));
$gun_say = (int)date('t', strtotime($bas));

// Resmi tatiller ve çalışma günü sayısı
$resmi_tatiller = getTatiller($yil);
$calisma_gun = 0;
for ($g = 1; $g <= $gun_say; $g++) {
    $t = "$yil-$ay_str-".str_pad($g,2,'0',STR_PAD_LEFT);
    if ((int)date('N',strtotime($t)) !== 7 && !isset($resmi_tatiller[$t])) $calisma_gun++;
}

// O aya ait menüler
try {
    $menuler_q = $db->prepare("SELECT * FROM yemek_menuler WHERE tarih BETWEEN ? AND ? ORDER BY tarih, ogun");
    $menuler_q->execute([$bas,$bit]);
    $menuler_ham = $menuler_q->fetchAll();
} catch (Throwable $e) { $menuler_ham = []; }

// Tarih => ogun => veri olacak şekilde düzenle
$menuler = [];
foreach ($menuler_ham as $m) {
    $menuler[$m['tarih']][$m['ogun']] = $m;
}

// Önceki / sonraki ay
$onceki_ay  = $ay === 1 ? 12 : $ay - 1;
$onceki_yil = $ay === 1 ? $yil - 1 : $yil;
$sonraki_ay  = $ay === 12 ? 1 : $ay + 1;
$sonraki_yil = $ay === 12 ? $yil + 1 : $yil;

$ay_adlari = ['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$gun_adlari = ['','Pzt','Sal','Çar','Per','Cum','Cmt','Paz'];

// Yemek istatistikleri
$dolu_gun = count(array_keys($menuler));
$personel_say = 0;
try {
    $personel_say = $db->query("SELECT COUNT(*) FROM personeller WHERE durum='aktif'")->fetchColumn();
} catch (Throwable $e) {}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🍽 Yemek & Aylık Menü</h1>
    <div class="s-yol">İdari İşler / <b>Yemek Yönetimi</b></div>
  </div>
</div>

<div class="s-body">

<!-- Özet kartlar -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <div class="kart" style="padding:14px">
    <div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Çalışma Günü</div>
    <div style="font-size:26px;font-weight:800"><?php echo $calisma_gun; ?></div>
    <div style="font-size:11px;color:var(--m2)">Toplam: <?php echo $gun_say; ?> gün</div>
  </div>
  <div class="kart" style="padding:14px">
    <div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Menü Girilen</div>
    <div style="font-size:26px;font-weight:800;color:#059669"><?php echo $dolu_gun; ?></div>
  </div>
  <div class="kart" style="padding:14px">
    <div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Aktif Personel</div>
    <div style="font-size:26px;font-weight:800;color:var(--t)"><?php echo $personel_say; ?></div>
  </div>
  <div class="kart" style="padding:14px">
    <div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Aylık Tahmini Öğün</div>
    <div style="font-size:26px;font-weight:800;color:#7C3AED"><?php echo $dolu_gun * $personel_say; ?></div>
  </div>
</div>

<!-- Vardiya Yemek Sayıları -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
  <div style="background:#D1FAE5;border-left:4px solid #10B981;border-radius:10px;padding:16px">
    <div style="font-size:11px;font-weight:700;color:#065F46;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">1. Vardiya + Tek Vardiya</div>
    <div style="font-size:30px;font-weight:900;color:#065F46"><?php echo $yemek_v1_tek; ?></div>
    <div style="font-size:12px;color:#065F46;margin-top:4px">08:00–16:00 &nbsp;|&nbsp; Haftalık: <strong><?php echo $yemek_v1_tek * 5; ?></strong> öğün</div>
  </div>
  <div style="background:#DBEAFE;border-left:4px solid #3B82F6;border-radius:10px;padding:16px">
    <div style="font-size:11px;font-weight:700;color:#1E40AF;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">2. Vardiya</div>
    <div style="font-size:30px;font-weight:900;color:#1E40AF"><?php echo $yemek_v2; ?></div>
    <div style="font-size:12px;color:#1E40AF;margin-top:4px">16:00–00:00 &nbsp;|&nbsp; Haftalık: <strong><?php echo $yemek_v2 * 5; ?></strong> öğün</div>
  </div>
  <div style="background:#F3E8FF;border-left:4px solid #7C3AED;border-radius:10px;padding:16px">
    <div style="font-size:11px;font-weight:700;color:#6D28D9;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">3. Vardiya</div>
    <div style="font-size:30px;font-weight:900;color:#6D28D9"><?php echo $yemek_v3; ?></div>
    <div style="font-size:12px;color:#6D28D9;margin-top:4px">00:00–08:00 &nbsp;|&nbsp; Haftalık: <strong><?php echo $yemek_v3 * 5; ?></strong> öğün</div>
  </div>
</div>

<!-- Ay navigasyonu -->
<div class="kart" style="padding:14px 20px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between">
  <a href="?sayfa=idari-yemek&ay=<?php echo $onceki_ay; ?>&yil=<?php echo $onceki_yil; ?>"
     style="background:var(--bg);border:1.5px solid var(--kenar);padding:8px 14px;border-radius:8px;font-weight:600;text-decoration:none;color:var(--m)">‹ <?php echo $ay_adlari[$onceki_ay]; ?></a>
  <h2 style="font-size:20px;font-weight:800;margin:0"><?php echo $ay_adlari[$ay].' '.$yil; ?></h2>
  <a href="?sayfa=idari-yemek&ay=<?php echo $sonraki_ay; ?>&yil=<?php echo $sonraki_yil; ?>"
     style="background:var(--bg);border:1.5px solid var(--kenar);padding:8px 14px;border-radius:8px;font-weight:600;text-decoration:none;color:var(--m)"><?php echo $ay_adlari[$sonraki_ay]; ?> ›</a>
</div>

<!-- Aylık menü takvimi -->
<div class="kart" style="overflow:hidden;margin-bottom:16px">
  <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
    <div class="kart-bas">Aylık Öğle Yemeği Takvimi</div>
    <div style="font-size:12px;color:var(--m2);display:flex;gap:14px;align-items:center">
      <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;background:#D1FAE5;border-radius:2px;display:inline-block"></span>Menü girildi</span>
      <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;background:#FEF3C7;border-radius:2px;display:inline-block"></span>Bugün</span>
      <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;background:var(--bg);border-radius:2px;border:1px solid var(--kenar);display:inline-block"></span>Tatil</span>
    </div>
  </div>

  <div style="padding:16px">
  <!-- Haftanın günleri başlık -->
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:8px">
    <?php foreach (['Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi','Pazar'] as $i=>$gn): ?>
    <div style="text-align:center;font-size:11px;font-weight:700;color:<?php echo $i===6?'#9CA3AF':'var(--m2)'; ?>;text-transform:uppercase;letter-spacing:.5px;padding:4px 0"><?php echo $gn; ?></div>
    <?php endforeach; ?>
  </div>

  <?php
  // Ayın ilk gününün haftanın kaçıncı günü olduğu (1=Pzt ... 7=Paz)
  $ilk_gun_no = (int)date('N', strtotime($bas)); // 1=Pzt, 7=Paz
  $toplam_hucre = $ilk_gun_no - 1 + $gun_say;
  $satir_say = (int)ceil($toplam_hucre / 7);
  $gun = 1;
  for ($s = 0; $s < $satir_say; $s++):
  ?>
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:6px">
    <?php for ($h = 0; $h < 7; $h++):
      $hucre_no = $s * 7 + $h;
      $goster = $hucre_no >= ($ilk_gun_no - 1) && $gun <= $gun_say;
      if (!$goster): ?>
      <div></div>
    <?php else:
      $tarih = "$yil-$ay_str-".str_pad($gun,2,'0',STR_PAD_LEFT);
      $gun_no = (int)date('N', strtotime($tarih));
      $haftasonu = $gun_no === 7; // Pazar
      $resmi_tatil = isset($resmi_tatiller[$tarih]);
      $tatil_adi   = $resmi_tatiller[$tarih] ?? '';
      $bugun_mu  = $tarih === date('Y-m-d');
      $menu = $menuler[$tarih]['oglen'] ?? null;

      if ($bugun_mu)           $kart_bg = '#FFF7ED';
      elseif ($menu)           $kart_bg = '#F0FDF4';
      elseif ($haftasonu || $resmi_tatil) $kart_bg = 'var(--bg)';
      else                     $kart_bg = 'var(--yuzey)';

      $kart_border = $bugun_mu ? '2px solid #F97316' : ($menu ? '1px solid #BBF7D0' : (($haftasonu||$resmi_tatil) ? '1px solid var(--kenar)' : '1px solid var(--kenar))'));
    ?>
    <div style="background:<?php echo $kart_bg; ?>;border:<?php echo $kart_border; ?>;border-radius:10px;padding:8px;min-height:110px;position:relative;cursor:pointer"
         onclick="<?php echo ($haftasonu || $resmi_tatil) && !$menu ? '' : "kartTikla('{$tarih}')"; ?>"
         id="kart-<?php echo $tarih; ?>"
         data-tarih="<?php echo $tarih; ?>">

      <!-- Gün numarası -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
        <div style="font-size:15px;font-weight:900;<?php echo $bugun_mu?'color:#F97316':($haftasonu?'color:#9CA3AF':'color:var(--m)'); ?>">
          <?php echo $gun; ?>
        </div>
        <?php if ($bugun_mu): ?>
        <span style="font-size:9px;background:#F97316;color:#fff;padding:1px 5px;border-radius:10px;font-weight:700">BUGÜN</span>
        <?php elseif ($menu): ?>
        <span style="font-size:9px;color:#059669">✓</span>
        <?php endif; ?>
      </div>

      <?php if (($haftasonu || $resmi_tatil) && !$menu): ?>
      <div style="font-size:11px;color:#9CA3AF;font-style:italic"><?php echo $resmi_tatil ? mb_substr($tatil_adi,0,20) : 'Pazar'; ?></div>

      <?php elseif ($menu): ?>
      <!-- Yemekler -->
      <?php if ($menu['corba']): ?>
      <div style="font-size:10px;color:#6B7280;margin-bottom:1px">🥣 <?php echo htmlspecialchars(mb_substr($menu['corba'],0,22)); ?></div>
      <?php endif; ?>
      <?php if ($menu['yemek1']): ?>
      <div style="font-size:11px;font-weight:700;color:var(--m);margin-bottom:1px">🍽 <?php echo htmlspecialchars(mb_substr($menu['yemek1'],0,22)); ?></div>
      <?php endif; ?>
      <?php if ($menu['yemek2']): ?>
      <div style="font-size:10px;color:#374151;margin-bottom:1px">• <?php echo htmlspecialchars(mb_substr($menu['yemek2'],0,22)); ?></div>
      <?php endif; ?>
      <?php if ($menu['yemek3']): ?>
      <div style="font-size:10px;color:#374151;margin-bottom:1px">• <?php echo htmlspecialchars(mb_substr($menu['yemek3'],0,22)); ?></div>
      <?php endif; ?>
      <?php if ($menu['tatli']): ?>
      <div style="font-size:10px;color:#7C3AED;margin-bottom:1px">🍮 <?php echo htmlspecialchars(mb_substr($menu['tatli'],0,22)); ?></div>
      <?php endif; ?>
      <?php if ($menu['kalori']): ?>
      <div style="font-size:9px;color:#9CA3AF;margin-top:3px"><?php echo $menu['kalori']; ?> kcal</div>
      <?php endif; ?>

      <?php else: ?>
      <!-- Menü girilmedi -->
      <div style="font-size:10px;color:var(--m2);font-style:italic;margin-top:4px">Menü girilmedi</div>
      <?php if (!$resmi_tatil): ?><div style="position:absolute;bottom:6px;right:8px;font-size:10px;color:#2563EB;font-weight:700">+ Ekle</div><?php endif; ?>
      <?php endif; ?>
    </div>
    <?php $gun++; endif; ?>
    <?php endfor; ?>
  </div>
  <?php endfor; ?>
  </div>
</div>

</div>

<!-- Modal: Menü Ekle/Düzenle -->
<div id="ym_modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:560px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 4px;font-size:16px">🍽 Yemek Menüsü</h3>
    <div id="ym_tarih_goster" style="font-size:13px;color:var(--m2);margin-bottom:16px"></div>
    <input type="hidden" id="ym_tarih">
    <input type="hidden" id="ym_id">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
      <div><label class="form-etiket">Çorba</label><input type="text" class="form-alan" id="ym_corba" placeholder="Mercimek çorbası..."></div>
      <div><label class="form-etiket">Ana Yemek *</label><input type="text" class="form-alan" id="ym_y1" placeholder="Izgar tavuk..."></div>
      <div><label class="form-etiket">2. Yemek</label><input type="text" class="form-alan" id="ym_y2" placeholder="Pilav..."></div>
      <div><label class="form-etiket">3. Yemek / Garnitür</label><input type="text" class="form-alan" id="ym_y3" placeholder="Salata..."></div>
      <div><label class="form-etiket">Tatlı / Meyve</label><input type="text" class="form-alan" id="ym_tatli" placeholder="Sütlaç / Meyve..."></div>
      <div><label class="form-etiket">Tahmini Kalori</label><input type="number" class="form-alan" id="ym_kalori" placeholder="800" min="0"></div>
      <div style="grid-column:1/3"><label class="form-etiket">Not</label><input type="text" class="form-alan" id="ym_not" placeholder="Vejetaryen seçenek mevcut..."></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button id="ym_sil_btn" onclick="menuSil()" style="display:none;background:#FEE2E2;color:#991B1B;border:none;padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;margin-right:auto">Sil</button>
      <button onclick="document.getElementById('ym_modal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="menuKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<script>
var BASE = '<?php echo BASE_URL; ?>';
var AY = <?php echo $ay; ?>;
var YIL = <?php echo $yil; ?>;

<?php
// Tüm menüleri JS'e aktar
$menu_js = [];
foreach ($menuler as $tarih_k => $ogunler) {
    if (isset($ogunler['oglen'])) {
        $m = $ogunler['oglen'];
        $menu_js[$tarih_k] = [
            'id'     => (int)$m['id'],
            'corba'  => $m['corba'] ?? '',
            'yemek1' => $m['yemek1'] ?? '',
            'yemek2' => $m['yemek2'] ?? '',
            'yemek3' => $m['yemek3'] ?? '',
            'tatli'  => $m['tatli'] ?? '',
            'kalori' => $m['kalori'] ? (int)$m['kalori'] : '',
            'notlar' => $m['notlar'] ?? '',
        ];
    }
}
?>
var MENU_VERILERI = <?php echo json_encode($menu_js, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>;
var HAFTASONU_GUNLER = [0]; // 0=Pazar, 6=Cumartesi yok artık

function kartTikla(tarih) {
    var menu = MENU_VERILERI[tarih];
    var d = new Date(tarih+'T00:00:00');
    var haftasonu = d.getDay() === 0; // Sadece Pazar
    if (menu) {
        menuDuzenle(tarih, menu);
    } else if (!haftasonu) {
        menuEkle(tarih);
    }
}

function menuEkle(tarih) {
    document.getElementById('ym_id').value = '';
    document.getElementById('ym_tarih').value = tarih;
    var d = new Date(tarih);
    var gunAdi = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'][d.getDay()];
    document.getElementById('ym_tarih_goster').textContent = gunAdi+' — '+tarih.split('-').reverse().join('.');
    ['ym_corba','ym_y1','ym_y2','ym_y3','ym_tatli','ym_kalori','ym_not'].forEach(function(id){ document.getElementById(id).value=''; });
    document.getElementById('ym_sil_btn').style.display='none';
    document.getElementById('ym_modal').style.display='flex';
}

function menuDuzenle(tarih, m) {
    document.getElementById('ym_id').value    = m.id;
    document.getElementById('ym_tarih').value = tarih;
    var d = new Date(tarih);
    var gunAdi = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'][d.getDay()];
    document.getElementById('ym_tarih_goster').textContent = gunAdi+' — '+tarih.split('-').reverse().join('.');
    document.getElementById('ym_corba').value  = m.corba||'';
    document.getElementById('ym_y1').value     = m.yemek1||'';
    document.getElementById('ym_y2').value     = m.yemek2||'';
    document.getElementById('ym_y3').value     = m.yemek3||'';
    document.getElementById('ym_tatli').value  = m.tatli||'';
    document.getElementById('ym_kalori').value = m.kalori||'';
    document.getElementById('ym_not').value    = m.notlar||'';
    document.getElementById('ym_sil_btn').style.display='block';
    document.getElementById('ym_modal').style.display='flex';
}

function menuKaydet() {
    var id     = document.getElementById('ym_id').value;
    var tarih  = document.getElementById('ym_tarih').value;
    var corba  = document.getElementById('ym_corba').value;
    var yemek1 = document.getElementById('ym_y1').value;
    var yemek2 = document.getElementById('ym_y2').value;
    var yemek3 = document.getElementById('ym_y3').value;
    var tatli  = document.getElementById('ym_tatli').value;
    var kalori = document.getElementById('ym_kalori').value;
    var notlar = document.getElementById('ym_not').value;

    var fd = new FormData();
    fd.append('id',     id);
    fd.append('tarih',  tarih);
    fd.append('corba',  corba);
    fd.append('yemek1', yemek1);
    fd.append('yemek2', yemek2);
    fd.append('yemek3', yemek3);
    fd.append('tatli',  tatli);
    fd.append('kalori', kalori);
    fd.append('notlar', notlar);

    fetch('<?php echo BASE_URL; ?>/bolumler/idari/ajax/yemek-menu-kaydet.php', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
    }).then(function(r){ return r.json(); }).then(function(r){
        if (r.ok) { location.reload(); }
        else { alert('Hata: ' + (r.hata||'?')); }
    }).catch(function(e){ alert('Baglanti hatasi: '+e); });
}

function menuSil() {
    if (!confirm('Bu günün menüsü silinsin mi?')) return;
    var fd = new FormData();
    fd.append('id', document.getElementById('ym_id').value);
    fetch(BASE+'/bolumler/idari/ajax/yemek-menu-sil.php', {method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){
        if(r.ok) location.reload();
        else alert(r.hata);
    });
}

function topluAktar() {
    // Toplu giriş için basit metin modal - sonraki geliştirme
    alert('Toplu giriş özelliği yakında eklenecek.');
}
</script>
