<?php
/**
 * İdari İşler — Servis Yönetimi
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// ── DURAK & VARDİYA MATRİSİ (eski servis-organizasyon.php'den) ──────────
$vardiya_tanimlari = [
    1 => ['ad' => '1. Vardiya', 'saat' => '08:00–16:00', 'renk' => '#D1FAE5', 'renk_k' => '#065F46', 'bg' => '#10B981'],
    2 => ['ad' => '2. Vardiya', 'saat' => '16:00–00:00', 'renk' => '#DBEAFE', 'renk_k' => '#1E40AF', 'bg' => '#3B82F6'],
    3 => ['ad' => '3. Vardiya', 'saat' => '00:00–08:00', 'renk' => '#F3E8FF', 'renk_k' => '#6D28D9', 'bg' => '#7C3AED'],
];

$per_veri = []; $durak_vardiya_mat = []; $vardiya_sayilari = []; $tum_duraklar = [];
try {
    $personeller_tum = $db->query(
        "SELECT id, ad, soyad, sicil_no, kadro, servis_durak, vardiya_tipi, aktif_vardiya
         FROM personeller WHERE durum='aktif' ORDER BY ad"
    )->fetchAll();

    foreach ($personeller_tum as $p) {
        if ($p['vardiya_tipi'] === 'tek') { $vno = 'tek'; }
        elseif (in_array((int)($p['aktif_vardiya']??0), [1,2,3])) { $vno = (int)$p['aktif_vardiya']; }
        else { $vno = 0; }
        $per_veri[] = array_merge($p, ['vardiya_no' => $vno]);
    }

    foreach ($per_veri as $p) {
        if (!empty($p['servis_durak'])) $tum_duraklar[$p['servis_durak']] = true;
    }
    foreach (array_keys($tum_duraklar) as $dk) {
        $durak_vardiya_mat[$dk] = [1=>[], 2=>[], 3=>[], 'tek'=>[]];
    }

    foreach ($per_veri as $p) {
        if (empty($p['servis_durak'])) continue;
        $dk = $p['servis_durak'];
        $vno = $p['vardiya_no'];
        if ($vno && isset($durak_vardiya_mat[$dk][$vno])) {
            $durak_vardiya_mat[$dk][$vno][] = $p;
        }
    }

    $vardiya_sayilari = [1=>0, 2=>0, 3=>0, 'tek'=>0];
    foreach ($per_veri as $p) {
        if ($p['vardiya_no'] && isset($vardiya_sayilari[$p['vardiya_no']])) {
            $vardiya_sayilari[$p['vardiya_no']]++;
        }
    }
} catch (Throwable $e) {}

$toplam_personel = count($per_veri);
$servis_kullanan = count(array_filter($per_veri, function($p){ return !empty($p['servis_durak']); }));

// Servis araçları
try {
    $araclar = $db->query("SELECT sa.*, CONCAT(p.ad,' ',p.soyad) surucu_per FROM servis_araclar sa LEFT JOIN personeller p ON sa.surucu_id=p.id ORDER BY sa.aktif DESC, sa.plaka")->fetchAll();
} catch (Throwable $e) { $araclar = []; }

// Rotalar
try {
    $rotalar = $db->query("SELECT sr.*, sa.plaka arac_plaka,
        (SELECT COUNT(*) FROM servis_duraklar WHERE rota_id=sr.id) dur_say,
        (SELECT COUNT(*) FROM personeller WHERE servis_durak IS NOT NULL AND servis_durak != '' AND aktif_vardiya=sr.vardiya) per_say
        FROM servis_rotalar sr
        LEFT JOIN servis_araclar sa ON sr.arac_id=sa.id
        ORDER BY sr.aktif DESC, sr.ad")->fetchAll();
} catch (Throwable $e) { $rotalar = []; }

// Tüm personel durak listesi (mevcut atamalar)
try {
    $atamalar = $db->query("SELECT ad, soyad, sicil_no, servis_durak, aktif_vardiya, kadro
        FROM personeller WHERE durum='aktif' AND servis_durak IS NOT NULL AND servis_durak != ''
        ORDER BY servis_durak, ad")->fetchAll();
} catch (Throwable $e) { $atamalar = []; }

// Personel listesi (araç sürücüsü için)
$personeller = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();

$yon_tr = ['sabah'=>'Sabah','aksam'=>'Akşam','her_iki'=>'Sabah & Akşam'];
$var_tr = [1=>'1. Vardiya',2=>'2. Vardiya',3=>'3. Vardiya'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🚌 Servis Yönetimi</h1>
    <div class="s-yol">İdari İşler / <b>Servis</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="document.getElementById('aracModal').style.display='flex'" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;font-size:13px">+ Araç Ekle</button>
    <button onclick="document.getElementById('rotaModal').style.display='flex'" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:9px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Rota Ekle</button>
  </div>

  <button onclick="dtExcelIndir('tbl-servis_yonetim','Servis_Yonetim')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php
  $aktif_arac = count(array_filter($araclar, function($a){ return $a['aktif']; }));
  $aktif_rota = count(array_filter($rotalar, function($r){ return $r['aktif']; }));
  $toplam_kap = array_sum(array_column(array_filter($araclar,function($a){return $a['aktif'];}), 'kapasite'));
  ?>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Aktif Araç</div><div style="font-size:26px;font-weight:800;color:#059669"><?php echo $aktif_arac; ?></div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Aktif Rota</div><div style="font-size:26px;font-weight:800;color:#2563EB"><?php echo $aktif_rota; ?></div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Toplam Kapasite</div><div style="font-size:26px;font-weight:800;color:#7C3AED"><?php echo $toplam_kap; ?> kişi</div></div>
  <div class="kart" style="padding:14px"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Servis Kullanan</div><div style="font-size:26px;font-weight:800;color:#F97316"><?php echo count($atamalar); ?> personel</div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">

<!-- Araçlar -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">🚐 Servis Araçları</div></div>
  <table class="tablo" id="tbl-servis_yonetim" style="width:100%">
    <thead><tr><th>Plaka</th><th>Araç</th><th style="text-align:center">Kapasite</th><th>Sürücü</th><th>Tel</th><th style="text-align:center">Durum</th><th style="width:60px"></th></tr></thead>
    <tbody>
      <?php if (empty($araclar)): ?>
      <tr><td colspan="7" style="text-align:center;padding:24px;color:var(--m2)">Araç eklenmemiş.</td></tr>
      <?php else: foreach ($araclar as $a): ?>
      <tr>
        <td style="font-weight:800;color:var(--t)"><?php echo htmlspecialchars($a['plaka']); ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($a['marka']??''); ?></td>
        <td style="text-align:center;font-weight:700"><?php echo $a['kapasite']; ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($a['surucu_per'] ?: ($a['surucu_adi']??'—')); ?></td>
        <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($a['surucu_tel']??''); ?></td>
        <td style="text-align:center">
          <span style="background:<?php echo $a['aktif']?'#D1FAE5':'#F3F4F6'; ?>;color:<?php echo $a['aktif']?'#065F46':'#6B7280'; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $a['aktif']?'Aktif':'Pasif'; ?></span>
        </td>
        <td>
          <button onclick="aracDuzenle(<?php echo htmlspecialchars(json_encode($a,JSON_UNESCAPED_UNICODE)); ?>)" style="background:var(--bg);border:1px solid var(--kenar);padding:4px 8px;border-radius:6px;cursor:pointer;font-size:12px;font-family:inherit">✏️</button>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<!-- Rotalar -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">🗺 Servis Rotaları</div></div>
  <table class="tablo" style="width:100%">
    <thead><tr><th>Rota Adı</th><th>Yön</th><th>Vardiya</th><th>Araç</th><th style="text-align:center">Durak</th><th style="text-align:center">Personel</th><th style="text-align:center">Durum</th></tr></thead>
    <tbody>
      <?php if (empty($rotalar)): ?>
      <tr><td colspan="7" style="text-align:center;padding:24px;color:var(--m2)">Rota eklenmemiş.</td></tr>
      <?php else: foreach ($rotalar as $r): ?>
      <tr style="cursor:pointer" onclick="rotaDetay(<?php echo $r['id']; ?>)">
        <td style="font-weight:700"><?php echo htmlspecialchars($r['ad']); ?></td>
        <td style="font-size:12px"><?php echo $yon_tr[$r['yon']]??$r['yon']; ?></td>
        <td style="font-size:12px"><?php echo $r['vardiya']?$var_tr[$r['vardiya']]:'Tümü'; ?></td>
        <td style="font-size:12px"><?php echo htmlspecialchars($r['arac_plaka']??'—'); ?></td>
        <td style="text-align:center;font-weight:700"><?php echo $r['dur_say']; ?></td>
        <td style="text-align:center;font-weight:700;color:var(--t)"><?php echo $r['per_say']; ?></td>
        <td style="text-align:center"><span style="background:<?php echo $r['aktif']?'#D1FAE5':'#F3F4F6'; ?>;color:<?php echo $r['aktif']?'#065F46':'#6B7280'; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $r['aktif']?'Aktif':'Pasif'; ?></span></td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
</div>

<!-- Personel Servis Atamaları -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
    <div class="kart-bas">👥 Personel Servis Atamaları (<?php echo count($atamalar); ?> kişi)</div>
    <a href="?sayfa=idari-servis-ata" style="background:var(--t);color:#fff;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;text-decoration:none">Atama Yönet</a>
  </div>

  <?php if (!empty($atamalar)):
    // Durağa göre grupla
    $durak_grup = [];
    foreach ($atamalar as $p) {
        $dk = $p['servis_durak'] ?: 'Belirsiz';
        $durak_grup[$dk][] = $p;
    }
  ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;padding:14px">
    <?php foreach ($durak_grup as $durak => $kisiler): ?>
    <div style="background:var(--bg);border:1px solid var(--kenar);border-radius:10px;padding:12px">
      <div style="font-size:12px;font-weight:700;color:var(--t);margin-bottom:8px">🚌 <?php echo htmlspecialchars($durak); ?> (<?php echo count($kisiler); ?>)</div>
      <?php foreach ($kisiler as $k): ?>
      <div style="display:flex;align-items:center;gap:6px;padding:3px 0;font-size:12px">
        <span style="width:20px;height:20px;border-radius:50%;background:var(--t);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;flex-shrink:0"><?php echo mb_substr($k['ad'],0,1); ?></span>
        <span><?php echo htmlspecialchars($k['ad'].' '.$k['soyad']); ?></span>
        <?php if ($k['aktif_vardiya']): ?>
        <span style="font-size:10px;color:var(--m2)">(V<?php echo $k['aktif_vardiya']; ?>)</span>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <p style="text-align:center;padding:24px;color:var(--m2)">Henüz servis ataması yapılmamış. Personel kartlarından servis durağı atayabilirsiniz.</p>
  <?php endif; ?>
</div>


<!-- ══ DURAK × VARDİYA MATRİSİ ══════════════════════════════════ -->
<div class="kart" style="overflow:hidden;margin-bottom:16px">
  <div class="kart-ust"><div class="kart-bas">🚌 Durak Bazlı Servis Planı</div></div>
  <div style="overflow-x:auto">
  <table style="width:100%;border-collapse:collapse;font-size:13px">
    <thead>
      <tr style="background:#F9FAFB">
        <th style="padding:12px 16px;text-align:left;font-size:12px;font-weight:700;color:var(--m2);border-bottom:2px solid var(--kenar)">DURAK</th>
        <?php foreach ($vardiya_tanimlari as $vno => $vd): ?>
        <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:<?php echo $vd['renk_k']; ?>;border-bottom:2px solid var(--kenar);background:<?php echo $vd['renk']; ?>">
          <?php echo $vd['ad']; ?><br><span style="font-size:10px;font-weight:400"><?php echo $vd['saat']; ?></span>
        </th>
        <?php endforeach; ?>
        <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:#B45309;border-bottom:2px solid var(--kenar);background:#FEF3E8">Tek Vardiya</th>
        <th style="padding:12px 16px;text-align:center;font-size:12px;font-weight:700;color:var(--m2);border-bottom:2px solid var(--kenar)">TOPLAM</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $tum_dk = array_merge(array_keys($tum_duraklar ?? []), ['yok']);
      foreach ($tum_dk as $dk):
          if (!isset($durak_vardiya_mat[$dk])) continue;
          $dv = $durak_vardiya_mat[$dk];
          $toplam_dk = array_sum(array_map('count', $dv));
          if ($toplam_dk === 0) continue;
          $durak_adi = $dk === 'yok' ? '— Servis Kullanmıyor' : '🚌 '.htmlspecialchars($dk);
      ?>
      <tr style="border-bottom:1px solid var(--kenar)">
        <td style="padding:12px 16px;font-weight:700"><?php echo $durak_adi; ?></td>
        <?php foreach ($vardiya_tanimlari as $vno => $vd): $say = count($dv[$vno]); ?>
        <td style="padding:12px 16px;text-align:center" onclick="<?php echo $say>0?"durakDetay('".htmlspecialchars($dk,ENT_QUOTES)."',$vno)":''; ?>" style="cursor:<?php echo $say>0?'pointer':'default'; ?>">
          <?php if ($say > 0): ?>
          <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:<?php echo $vd['bg']; ?>;color:#fff;font-size:15px;font-weight:800;cursor:pointer">
            <?php echo $say; ?>
          </span>
          <?php else: ?><span style="color:var(--m2)">—</span><?php endif; ?>
        </td>
        <?php endforeach; ?>
        <td style="padding:12px 16px;text-align:center">
          <?php $say_tek = count($dv['tek']); ?>
          <?php if ($say_tek > 0): ?>
          <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:#F97316;color:#fff;font-size:15px;font-weight:800"><?php echo $say_tek; ?></span>
          <?php else: ?><span style="color:var(--m2)">—</span><?php endif; ?>
        </td>
        <td style="padding:12px 16px;text-align:center;font-size:16px;font-weight:900;color:var(--m)"><?php echo $toplam_dk; ?></td>
      </tr>
      <?php endforeach; ?>
      <tr style="background:#F9FAFB;border-top:2px solid var(--kenar);font-weight:800">
        <td style="padding:12px 16px">TOPLAM</td>
        <?php foreach ([1,2,3] as $vno): ?>
        <td style="padding:12px 16px;text-align:center;font-size:15px;font-weight:900"><?php echo array_sum(array_map(function($dk) use ($durak_vardiya_mat,$vno){ return count($durak_vardiya_mat[$dk][$vno]??[]); }, array_keys($durak_vardiya_mat))); ?></td>
        <?php endforeach; ?>
        <td style="padding:12px 16px;text-align:center;font-size:15px;font-weight:900"><?php echo array_sum(array_map(function($dk) use ($durak_vardiya_mat){ return count($durak_vardiya_mat[$dk]['tek']??[]); }, array_keys($durak_vardiya_mat))); ?></td>
        <td style="padding:12px 16px;text-align:center;font-size:16px;font-weight:900;color:var(--t)"><?php echo $toplam_personel; ?></td>
      </tr>
    </tbody>
  </table>
  </div>
</div>

</div>

<!-- Modal: Araç Ekle/Düzenle -->
<div id="aracModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:480px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 16px;font-size:16px">🚐 Servis Aracı</h3>
    <input type="hidden" id="aracId">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
      <div><label class="form-etiket">Plaka *</label><input type="text" class="form-alan" id="aPlaka" style="text-transform:uppercase"></div>
      <div><label class="form-etiket">Marka / Model</label><input type="text" class="form-alan" id="aMarka"></div>
      <div><label class="form-etiket">Kapasite (kişi)</label><input type="number" class="form-alan" id="aKap" value="0" min="0"></div>
      <div><label class="form-etiket">Durum</label>
        <select class="form-alan" id="aAktif"><option value="1">Aktif</option><option value="0">Pasif</option></select>
      </div>
      <div><label class="form-etiket">Sürücü (Personel)</label>
        <select class="form-alan" id="aSurucu">
          <option value="">— Seçmiyorum —</option>
          <?php foreach ($personeller as $p): ?><option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-etiket">Sürücü Tel (harici)</label><input type="text" class="form-alan" id="aSuruTel"></div>
      <div><label class="form-etiket">Sürücü Adı (harici)</label><input type="text" class="form-alan" id="aSuruAdi" placeholder="Personel listesinde yoksa"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button onclick="document.getElementById('aracModal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="aracKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<!-- Modal: Rota Ekle -->
<div id="rotaModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:var(--yuzey);border-radius:16px;padding:24px;width:520px;max-width:95vw" onclick="event.stopPropagation()">
    <h3 style="margin:0 0 16px;font-size:16px">🗺 Yeni Rota</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
      <div style="grid-column:1/3"><label class="form-etiket">Rota Adı *</label><input type="text" class="form-alan" id="rAd" placeholder="Örn: Çerkezköy - Kapaklı Güzergahı"></div>
      <div><label class="form-etiket">Yön</label>
        <select class="form-alan" id="rYon">
          <option value="her_iki">Sabah & Akşam</option><option value="sabah">Sabah</option><option value="aksam">Akşam</option>
        </select>
      </div>
      <div><label class="form-etiket">Vardiya</label>
        <select class="form-alan" id="rVar">
          <option value="">Tümü</option><option value="1">1. Vardiya</option><option value="2">2. Vardiya</option><option value="3">3. Vardiya</option>
        </select>
      </div>
      <div><label class="form-etiket">Araç</label>
        <select class="form-alan" id="rArac">
          <option value="">— Seçmiyorum —</option>
          <?php foreach ($araclar as $a): ?><option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['plaka'].' - '.($a['marka']??'')); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-etiket">Kalkış Saati</label><input type="time" class="form-alan" id="rSaat"></div>
      <div style="grid-column:1/3"><label class="form-etiket">Notlar</label><textarea class="form-alan" id="rNot" rows="2"></textarea></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button onclick="document.getElementById('rotaModal').style.display='none'" style="background:var(--bg);border:1.5px solid var(--kenar);padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit">İptal</button>
      <button onclick="rotaKaydet()" style="background:var(--t);color:#fff;border:none;padding:9px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Kaydet</button>
    </div>
  </div>
</div>

<script>
var BASE = '<?php echo BASE_URL; ?>';

function post(url, data) {
    var fd = new FormData();
    for (var k in data) fd.append(k, data[k] !== null && data[k] !== undefined ? data[k] : '');
    return fetch(BASE+url, {method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();});
}

function aracDuzenle(a) {
    document.getElementById('aracId').value   = a.id;
    document.getElementById('aPlaka').value   = a.plaka;
    document.getElementById('aMarka').value   = a.marka||'';
    document.getElementById('aKap').value     = a.kapasite||0;
    document.getElementById('aAktif').value   = a.aktif;
    document.getElementById('aSuruci').value  = a.surucu_id||'';
    document.getElementById('aSuruTel').value = a.surucu_tel||'';
    document.getElementById('aSuruAdi').value = a.surucu_adi||'';
    document.getElementById('aracModal').style.display = 'flex';
}

function aracKaydet() {
    post('/bolumler/idari/ajax/servis-arac-kaydet.php', {
        id: document.getElementById('aracId').value,
        plaka: document.getElementById('aPlaka').value,
        marka: document.getElementById('aMarka').value,
        kapasite: document.getElementById('aKap').value,
        aktif: document.getElementById('aAktif').value,
        surucu_id: document.getElementById('aSurucu').value,
        surucu_tel: document.getElementById('aSuruTel').value,
        surucu_adi: document.getElementById('aSuruAdi').value,
    }).then(function(r){ if(r.ok) location.reload(); else alert(r.hata); });
}

function rotaKaydet() {
    post('/bolumler/idari/ajax/servis-rota-kaydet.php', {
        ad: document.getElementById('rAd').value,
        yon: document.getElementById('rYon').value,
        vardiya: document.getElementById('rVar').value,
        arac_id: document.getElementById('rArac').value,
        kalkis_saati: document.getElementById('rSaat').value,
        notlar: document.getElementById('rNot').value,
    }).then(function(r){ if(r.ok) location.reload(); else alert(r.hata); });
}

function rotaDetay(id) {
    location.href = '?sayfa=idari-servis-rota&id=' + id;
}
</script>
