<?php
/**
 * Güvenlik — Servis Araç Giriş Çıkış Takip
 * panel.php: 'idari-guvenlik-servis' => 'bolumler/idari/guvenlik_servis.php'
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$kul = Auth::kullanici();
$kul_adi = $kul['ad_soyad'] ?? $kul['email'] ?? '';

$db->exec("CREATE TABLE IF NOT EXISTS guv_servis_giris_cikis (
    a_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    plaka        VARCHAR(20) NOT NULL,
    sofor_adi    VARCHAR(100),
    yer          VARCHAR(100),
    c_km         INT,
    g_km         INT,
    c_zaman      DATETIME,
    g_zaman      DATETIME,
    guvenlik     VARCHAR(100),
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_plaka(plaka), INDEX idx_cz(c_zaman)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$mesaj=''; $mesaj_tip='';

if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'cikis_kaydet':
            try {
                $db->prepare("INSERT INTO guv_servis_giris_cikis (plaka,sofor_adi,yer,c_km,c_zaman,guvenlik) VALUES(?,?,?,?,?,?)")
                   ->execute([$_POST['plaka'],$_POST['sofor_adi'],$_POST['yer'],(int)$_POST['c_km'],$_POST['c_zaman'],$_POST['guvenlik']??$kul_adi]);
                $mesaj='Servis çıkış kaydı oluşturuldu.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'giris_kaydet':
            try {
                $db->prepare("UPDATE guv_servis_giris_cikis SET g_km=?,g_zaman=? WHERE a_id=?")
                   ->execute([(int)$_POST['g_km'],$_POST['g_zaman'],(int)$_POST['a_id']]);
                $mesaj='Giriş kaydı tamamlandı.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'duzenle':
            try {
                $db->prepare("UPDATE guv_servis_giris_cikis SET plaka=?,sofor_adi=?,yer=?,c_km=?,c_zaman=? WHERE a_id=?")
                   ->execute([$_POST['plaka'],$_POST['sofor_adi'],$_POST['yer'],(int)$_POST['c_km'],$_POST['c_zaman'],(int)$_POST['a_id']]);
                $mesaj='Güncellendi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
        case 'sil':
            try {
                $db->prepare("DELETE FROM guv_servis_giris_cikis WHERE a_id=?")->execute([(int)$_POST['a_id']]);
                $mesaj='Silindi.'; $mesaj_tip='ok';
            } catch(Throwable $e){ $mesaj='Hata: '.$e->getMessage(); $mesaj_tip='hata'; }
            break;
    }
}

$kayitlar = $db->query("SELECT * FROM guv_servis_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
$son_km = [];
$son_durumlar = [];
foreach ($kayitlar as $r) {
    $p = $r['plaka'];
    if (!isset($son_durumlar[$p])) $son_durumlar[$p] = $r;
    if (!isset($son_km[$p]) && $r['g_km']) $son_km[$p] = $r['g_km'];
}

$servis_plakalar = ['34 KGJ 741'=>'SULTAN','59 ADV 150'=>'MERCEDES','59 AIY 173'=>'PRESTİJ','59 AKF 498'=>'SULTAN'];
$yerler = ['ÇERKEZKÖY','KAPAKLI','KARAAĞAÇ','KIZILPINAR','ÇORLU','TEKİRDAĞ','SANAYİ','İSTANBUL','Diğer...'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🚐 Servis Araç Takip</h1>
    <div class="s-yol">İdari İşler / Güvenlik / <b>Servis Takip</b></div>
  </div>
  <div style="display:flex;gap:8px">
    <button onclick="modalAc('sCikisModal')" class="btn btn-t btn-sm">+ Servis Çıkış Kaydı</button>
  </div>
</div>
<div class="s-body">
<?php if ($mesaj): ?>
<div class="kart" style="padding:10px 16px;margin-bottom:12px;background:<?= $mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2' ?>;color:<?= $mesaj_tip==='ok'?'#065F46':'#7F1D1D' ?>;border-left:4px solid <?= $mesaj_tip==='ok'?'#22C55E':'#EF4444' ?>"><?= htmlspecialchars($mesaj) ?></div>
<?php endif; ?>

<!-- Dashboard -->
<div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px">
<?php foreach ($son_durumlar as $r):
    $dis = empty($r['g_zaman']);
    $marka = $servis_plakalar[$r['plaka']] ?? '';
?>
<div class="kart" style="padding:12px 16px;min-width:160px;border-left:4px solid <?= $dis?'#EF4444':'#22C55E' ?>">
  <div style="font-weight:800;font-size:13px"><?= htmlspecialchars($r['plaka']) ?><?= $marka?" <span style='font-size:10px;color:var(--m2)'>($marka)</span>":'' ?></div>
  <div style="font-size:11px;color:var(--m2)"><?= htmlspecialchars($r['sofor_adi']??'') ?> | <?= htmlspecialchars($r['yer']??'') ?></div>
  <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $dis?'#FEE2E2':'#D1FAE5' ?>;color:<?= $dis?'#991B1B':'#065F46' ?>"><?= $dis?'● Dışarıda':'● İçeride' ?></span>
</div>
<?php endforeach; ?>
</div>

<!-- Tablo -->
<div class="kart" style="padding:0;overflow:hidden"><div style="overflow-x:auto">
<table id="tblServis" style="width:100%">
  <thead><tr><th>#</th><th>Plaka</th><th>Şoför</th><th>Yer</th><th>Çıkış</th><th>Giriş</th><th>Çıkış KM</th><th>Giriş KM</th><th>Durum</th><th>Süre(dk)</th><th>İşlem</th></tr></thead>
  <tfoot><tr><th>#</th><th>Plaka</th><th>Şoför</th><th>Yer</th><th>Çıkış</th><th>Giriş</th><th>Çıkış KM</th><th>Giriş KM</th><th>Durum</th><th>Süre(dk)</th><th>İşlem</th></tr></tfoot>
  <tbody>
  <?php foreach ($kayitlar as $i => $r):
    $dis = empty($r['g_zaman']);
    $sure = !$dis ? round((strtotime($r['g_zaman'])-strtotime($r['c_zaman']))/60) : '';
  ?>
  <tr>
    <td><?= $i+1 ?></td>
    <td style="font-weight:700"><?= htmlspecialchars($r['plaka']) ?></td>
    <td><?= htmlspecialchars($r['sofor_adi']??'') ?></td>
    <td><?= htmlspecialchars($r['yer']??'') ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['c_zaman']??'') ?></td>
    <td style="font-size:11px;white-space:nowrap"><?= htmlspecialchars($r['g_zaman']??'') ?></td>
    <td><?= htmlspecialchars($r['c_km']??'') ?></td>
    <td><?= htmlspecialchars($r['g_km']??'') ?></td>
    <td><span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $dis?'#FEE2E2':'#D1FAE5' ?>;color:<?= $dis?'#991B1B':'#065F46' ?>"><?= $dis?'Dışarıda':'İçeride' ?></span></td>
    <td><?= $sure ?></td>
    <td style="white-space:nowrap">
      <?php if ($dis): ?>
      <button onclick="sGirisModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm btn-t" style="font-size:11px;padding:3px 8px">Giriş</button>
      <?php endif; ?>
      <button onclick="sDuzenleModal(<?= htmlspecialchars(json_encode($r)) ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF9C3;color:#78350F;border:1px solid #FDE68A">Düzenle</button>
      <button onclick="sSil(<?= $r['a_id'] ?>)" class="btn btn-sm" style="font-size:11px;padding:3px 8px;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA">Sil</button>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div></div>

<!-- Çıkış Modal -->
<div id="sCikisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:480px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">🚐 Servis Çıkış Kaydı</div>
    <button onclick="modalKapat('sCikisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="cikis_kaydet">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-et">Plaka</label>
        <select name="plaka" class="form-alan" required id="sPlakaSelect" onchange="sPlakaKm(this.value)">
          <option value="">— Seçin —</option>
          <?php foreach ($servis_plakalar as $p=>$m): ?><option value="<?= $p ?>"><?= $p ?> (<?= $m ?>)</option><?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-et">Şoför Adı</label><input name="sofor_adi" class="form-alan" required></div>
      <div><label class="form-et">Gidilecek Yer</label>
        <select name="yer" class="form-alan" required>
          <?php foreach ($yerler as $y): ?><option><?= $y ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label class="form-et">Çıkış KM</label><input type="number" name="c_km" class="form-alan" id="sCikisKm" required></div>
      <div><label class="form-et">Çıkış Zamanı</label><input type="datetime-local" name="c_zaman" class="form-alan" id="sCikisZaman" required></div>
      <div><label class="form-et">Güvenlik</label><input name="guvenlik" class="form-alan" value="<?= htmlspecialchars($kul_adi) ?>" required></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('sCikisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<!-- Giriş Modal -->
<div id="sGirisModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:380px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">🏁 Giriş Kaydı Sonlandır</div>
    <button onclick="modalKapat('sGirisModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="giris_kaydet">
    <input type="hidden" name="a_id" id="sGiris_id">
    <div style="background:var(--kenar-a);border-radius:8px;padding:10px;font-size:12px;margin-bottom:10px" id="sGirisOzet"></div>
    <div style="display:grid;gap:10px">
      <div><label class="form-et">Giriş KM</label><input type="number" name="g_km" class="form-alan" required></div>
      <div><label class="form-et">Giriş Zamanı</label><input type="datetime-local" name="g_zaman" class="form-alan" id="sGirisZaman" required></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('sGirisModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Sonlandır</button>
    </div>
  </form>
</div>
</div>

<!-- Düzenle Modal -->
<div id="sDuzenleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div class="kart" style="width:440px;max-width:95vw;padding:20px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <div style="font-weight:800;font-size:15px">✏️ Düzenle</div>
    <button onclick="modalKapat('sDuzenleModal')" style="border:none;background:none;font-size:18px;cursor:pointer">✕</button>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="duzenle">
    <input type="hidden" name="a_id" id="sDuz_id">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="form-et">Plaka</label><input name="plaka" class="form-alan" id="sDuz_plaka" required></div>
      <div><label class="form-et">Şoför</label><input name="sofor_adi" class="form-alan" id="sDuz_sofor"></div>
      <div><label class="form-et">Yer</label><input name="yer" class="form-alan" id="sDuz_yer"></div>
      <div><label class="form-et">Çıkış KM</label><input type="number" name="c_km" class="form-alan" id="sDuz_ckm"></div>
      <div class="col-span-2"><label class="form-et">Çıkış Zamanı</label><input type="datetime-local" name="c_zaman" class="form-alan" id="sDuz_czaman" style="width:100%"></div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button type="button" onclick="modalKapat('sDuzenleModal')" class="btn btn-b">İptal</button>
      <button type="submit" class="btn btn-t">Kaydet</button>
    </div>
  </form>
</div>
</div>

<form method="POST" id="sSilForm" style="display:none">
  <input type="hidden" name="action" value="sil"><input type="hidden" name="a_id" id="sSil_id">
</form>

</div>
<style>
#tblServis thead th,#tblServis tfoot th{background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;white-space:nowrap;border-right:1px solid #2D4E7A}
#tblServis tbody td{padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px}
#tblServis tfoot select{width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg)}
</style>
<script>
var sKm=<?= json_encode($son_km) ?>;
function modalAc(id){document.getElementById(id).style.display='flex';}
function modalKapat(id){document.getElementById(id).style.display='none';}
function sPlakaKm(p){if(sKm[p]) document.getElementById('sCikisKm').value=sKm[p];}
document.getElementById('sCikisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();

function sGirisModal(r){
    document.getElementById('sGiris_id').value=r.a_id;
    document.getElementById('sGirisOzet').innerHTML='<strong>'+r.plaka+'</strong> — '+(r.sofor_adi||'')+' | '+(r.yer||'')+'<br>Çıkış: '+(r.c_zaman||'')+' KM: '+(r.c_km||'');
    document.getElementById('sGirisZaman').value=(function(){var d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,16);})();
    modalAc('sGirisModal');
}
function sDuzenleModal(r){
    document.getElementById('sDuz_id').value=r.a_id;
    document.getElementById('sDuz_plaka').value=r.plaka||'';
    document.getElementById('sDuz_sofor').value=r.sofor_adi||'';
    document.getElementById('sDuz_yer').value=r.yer||'';
    document.getElementById('sDuz_ckm').value=r.c_km||'';
    document.getElementById('sDuz_czaman').value=(r.c_zaman||'').replace(' ','T').slice(0,16);
    modalAc('sDuzenleModal');
}
function sSil(id){if(!confirm('Silmek istediğinizden emin misiniz?'))return; document.getElementById('sSil_id').value=id; document.getElementById('sSilForm').submit();}

$(document).ready(function(){
    $('#tblServis').DataTable({
        initComplete:function(){this.api().columns([1,2,3,8]).every(function(){var col=this,sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty()).on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+v+'</option>');});});},
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        order:[[4,'desc']],scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
        dom:'Bfrtip',buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Servis_Takip_<?= date("Ymd") ?>'},'print']
    });
});
</script>
