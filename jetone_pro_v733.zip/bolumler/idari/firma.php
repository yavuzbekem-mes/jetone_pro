<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Firma bilgilerini al
$firma = [];
try { $firma = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: []; } catch(Throwable $e){}

// POST - kaydet
$basari = $hata = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->prepare("UPDATE ayarlar SET firma_adi=?,firma_kisa_adi=?,vergi_no=?,vergi_dairesi=?,
            telefon=?,email=?,web=?,adres=? WHERE id=1")
           ->execute([
               trim($_POST['firma_adi'] ?? ''),
               trim($_POST['firma_kisa_adi'] ?? ''),
               trim($_POST['vergi_no'] ?? ''),
               trim($_POST['vergi_dairesi'] ?? ''),
               trim($_POST['telefon'] ?? ''),
               trim($_POST['email'] ?? ''),
               trim($_POST['web'] ?? ''),
               trim($_POST['adres'] ?? ''),
           ]);
        $basari = 'Firma bilgileri güncellendi.';
        $firma = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch() ?: [];
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$f = function($key) use ($firma) { return htmlspecialchars($firma[$key] ?? ''); };
?>
<div class="s-bar">
  <div><h1 class="s-bas">🏢 Firma Bilgileri</h1><div class="s-yol">İdari İşler / <b>Firma</b></div></div>
  <button form="firmaForm" type="submit" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">💾 Kaydet</button>
</div>

<div class="s-body">

<?php if ($basari): ?>
<div style="background:#D1FAE5;border:1px solid #6EE7B7;color:#065F46;padding:12px 16px;border-radius:8px;font-weight:600;margin-bottom:14px">✅ <?php echo htmlspecialchars($basari); ?></div>
<?php endif; ?>
<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;font-weight:600;margin-bottom:14px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<form method="POST" id="firmaForm">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

  <!-- Sol: Kimlik Bilgileri -->
  <div class="kart" style="padding:20px">
    <div class="kart-bas" style="margin-bottom:16px">🏢 Kimlik Bilgileri</div>
    <div style="display:grid;gap:12px">
      <div>
        <label class="form-etiket">Firma Adı *</label>
        <input type="text" name="firma_adi" class="form-alan" value="<?php echo $f('firma_adi'); ?>" required placeholder="Poliza Makina A.Ş.">
      </div>
      <div>
        <label class="form-etiket">Kısa Ad / Marka</label>
        <input type="text" name="firma_kisa_adi" class="form-alan" value="<?php echo $f('firma_kisa_adi'); ?>" placeholder="Poliza">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label class="form-etiket">Vergi No</label>
          <input type="text" name="vergi_no" class="form-alan" value="<?php echo $f('vergi_no'); ?>" placeholder="1234567890">
        </div>
        <div>
          <label class="form-etiket">Vergi Dairesi</label>
          <input type="text" name="vergi_dairesi" class="form-alan" value="<?php echo $f('vergi_dairesi'); ?>" placeholder="Çerkezköy">
        </div>
      </div>
    </div>
  </div>

  <!-- Sağ: İletişim -->
  <div class="kart" style="padding:20px">
    <div class="kart-bas" style="margin-bottom:16px">📞 İletişim Bilgileri</div>
    <div style="display:grid;gap:12px">
      <div>
        <label class="form-etiket">Telefon</label>
        <input type="tel" name="telefon" class="form-alan" value="<?php echo $f('telefon'); ?>" placeholder="+90 212 000 00 00">
      </div>
      <div>
        <label class="form-etiket">E-posta</label>
        <input type="email" name="email" class="form-alan" value="<?php echo $f('email'); ?>" placeholder="info@firma.com">
      </div>
      <div>
        <label class="form-etiket">Web Sitesi</label>
        <input type="url" name="web" class="form-alan" value="<?php echo $f('web'); ?>" placeholder="https://www.firma.com">
      </div>
    </div>
  </div>

  <!-- Adres - tam genişlik -->
  <div class="kart" style="padding:20px;grid-column:1/-1">
    <div class="kart-bas" style="margin-bottom:16px">📍 Adres</div>
    <textarea name="adres" class="form-alan" rows="3" placeholder="Firma adresi..."><?php echo $f('adres'); ?></textarea>
  </div>

</div>

<!-- Özet kartı -->
<?php if (!empty($firma['firma_adi'])): ?>
<div class="kart" style="padding:20px;margin-top:14px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border-radius:12px">
  <div style="display:flex;align-items:center;gap:16px">
    <div style="width:60px;height:60px;border-radius:14px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0">🏭</div>
    <div>
      <div style="font-size:20px;font-weight:900"><?php echo $f('firma_adi'); ?></div>
      <?php if ($firma['vergi_no']): ?><div style="font-size:13px;opacity:.85">Vergi No: <?php echo $f('vergi_no'); ?> — <?php echo $f('vergi_dairesi'); ?></div><?php endif; ?>
      <?php if ($firma['telefon'] || $firma['email']): ?>
      <div style="font-size:12px;opacity:.8;margin-top:4px">
        <?php if ($firma['telefon']): ?><?php echo $f('telefon'); ?><?php endif; ?>
        <?php if ($firma['telefon'] && $firma['email']): ?> · <?php endif; ?>
        <?php if ($firma['email']): ?><?php echo $f('email'); ?><?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

</form>
</div>
