<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$f_arama  = trim($_GET['arama'] ?? '');
$f_grup   = trim($_GET['grup'] ?? '');
$stoklar  = [];
$hata     = '';
$gruplar  = ['Ambalaj','Plastik HM','Mamül','Yarımamül','Masterbatch','Yardımcı Malz.'];

if ($tiger_ok) {
    try {
        $sql = "SELECT
            piv.SPECODE  AS ozel_kod,
            piv.STGRPCODE AS grup,
            piv.CODE      AS kod,
            piv.NAME      AS ad,
            ISNULL(FORMAT(piv.[Merkez],    'N0','de-DE'),'0') AS merkez,
            ISNULL(FORMAT(piv.[Üretim],    'N0','de-DE'),'0') AS uretim,
            ISNULL(FORMAT(piv.[BSH],       'N0','de-DE'),'0') AS bsh,
            ISNULL(FORMAT(piv.[Karantina], 'N0','de-DE'),'0') AS karantina,
            ISNULL(FORMAT(piv.[Kırma],     'N0','de-DE'),'0') AS kirma,
            ISNULL(FORMAT(piv.[Emanet],    'N0','de-DE'),'0') AS emanet,
            ISNULL(FORMAT(piv.[Takım Boz], 'N0','de-DE'),'0') AS takim_boz
        FROM (
            SELECT
                IT.SPECODE, IT.STGRPCODE, IT.CODE, IT.NAME,
                CAP.NAME AS ambar,
                SUM(LV.ONHAND) AS miktar
            FROM dbo.LG_222_ITEMS AS IT
            LEFT OUTER JOIN dbo.LV_222_02_STINVTOT AS LV ON LV.STOCKREF = IT.LOGICALREF
            LEFT OUTER JOIN dbo.L_CAPIWHOUSE AS CAP ON CAP.NR = LV.INVENNO
            WHERE
                IT.CARDTYPE NOT IN (4,22)
                AND IT.CANCONFIGURE = 0
                AND CAP.FIRMNR = 222
                AND LV.INVENNO IN (0,1,5,2,3,4,98)
                AND IT.STGRPCODE IN ('Ambalaj','Plastik HM','Mamül','Yarımamül','Masterbatch','Yardımcı Malz.')
            GROUP BY IT.SPECODE, IT.CODE, IT.NAME, IT.LOGICALREF, CAP.NR, CAP.NAME, IT.STGRPCODE
        ) AS src
        PIVOT (
            SUM(miktar)
            FOR ambar IN ([Merkez],[Üretim],[BSH],[Karantina],[Kırma],[Emanet],[Takım Boz])
        ) AS piv
        ORDER BY piv.STGRPCODE, piv.CODE";

        $all = $tigerdb_pdo->query($sql)->fetchAll();

        foreach ($all as $r) {
            if ($f_grup && $r['grup'] !== $f_grup) continue;
            if ($f_arama && stripos(($r['kod']??'').($r['ad']??''), $f_arama) === false) continue;
            $stoklar[] = $r;
        }
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$grup_renk = [
    'Mamül'         => ['#D1FAE5','#065F46'],
    'Yarımamül'     => ['#DBEAFE','#1E40AF'],
    'Ambalaj'       => ['#FEF3C7','#92400E'],
    'Plastik HM'    => ['#EDE9FE','#5B21B6'],
    'Masterbatch'   => ['#FEE2E2','#991B1B'],
    'Yardımcı Malz.' => ['#F3F4F6','#374151'],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Stok Durumu</h1>
    <div class="s-yol">Tanımlamalar / <b>Stoklar</b>
      <?php if ($tiger_ok): ?>
        <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
        <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo number_format(count($stoklar)); ?> malzeme)</span>
      <?php else: ?>
        <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<?php if (!$tiger_ok): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px">
  ⚠️ Tiger DB bağlantısı yok. <a href="?sayfa=ayarlar-enteg" style="color:#991B1B;font-weight:700">Entegrasyon ayarlarına git →</a>
</div>
<?php else: ?>

<!-- Filtreler -->
<form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
  <input type="hidden" name="sayfa" value="tanim-stok">
  <input type="text" name="arama" value="<?php echo htmlspecialchars($f_arama); ?>" class="form-alan" style="width:200px" placeholder="🔍 Malzeme kodu veya adı...">
  <select name="grup" class="form-alan" style="width:160px" onchange="this.form.submit()">
    <option value="">Tüm Gruplar</option>
    <?php foreach($gruplar as $g): ?>
    <option value="<?php echo htmlspecialchars($g); ?>" <?php echo $f_grup===$g?'selected':''; ?>><?php echo htmlspecialchars($g); ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <button type="button" onclick="dtExcelIndir('tbl-stok','StokDurumu')" style="background:#217346;color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
  <?php if($f_arama||$f_grup): ?>
  <a href="?sayfa=tanim-stok" style="padding:8px 12px;background:#F3F4F6;color:#374151;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">✕ Temizle</a>
  <?php endif; ?>
</form>

<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)">
  <table class="tablo" id="tbl-stok" style="min-width:1100px">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th>Malzeme Kodu</th>
        <th>Malzeme Adı</th>
        <th style="width:110px">Grup</th>
        <th style="width:80px;text-align:right">Merkez</th>
        <th style="width:80px;text-align:right">Üretim</th>
        <th style="width:70px;text-align:right">BSH</th>
        <th style="width:90px;text-align:right">Karantina</th>
        <th style="width:70px;text-align:right">Kırma</th>
        <th style="width:75px;text-align:right">Emanet</th>
        <th style="width:90px;text-align:right">Takım Boz</th>
        <th style="width:70px;text-align:center"></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($stoklar as $r):
      [$bg,$fg] = $grup_renk[$r['grup']] ?? ['#F3F4F6','#374151'];
      // Toplam stok
      $toplam = 0;
      foreach(['merkez','uretim','bsh','karantina','kirma','emanet','takim_boz'] as $k) {
          $toplam += (float)str_replace(['.','+'],['',' '], $r[$k]??'0');
      }
    ?>
    <tr>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-weight:700;color:var(--t);font-size:11px"><?php echo htmlspecialchars($r['kod']??''); ?></code></td>
      <td style="font-size:12px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?php echo htmlspecialchars($r['ad']??''); ?>"><?php echo htmlspecialchars($r['ad']??''); ?></td>
      <td><span style="background:<?php echo $bg; ?>;color:<?php echo $fg; ?>;font-size:10px;font-weight:700;padding:2px 6px;border-radius:10px"><?php echo htmlspecialchars($r['grup']??''); ?></span></td>
      <?php foreach(['merkez'=>'Merkez','uretim'=>'Üretim','bsh'=>'BSH','karantina'=>'Karantina','kirma'=>'Kırma','emanet'=>'Emanet','takim_boz'=>'Takım Boz'] as $col=>$lbl):
        $val = $r[$col] ?? '0';
        $num = (float)str_replace(['.','+'],['',' '], $val);
      ?>
      <td style="text-align:right;font-family:monospace;font-size:12px;<?php echo $num > 0 ? 'font-weight:700;color:#065F46' : 'color:#9CA3AF'; ?>"><?php echo $num > 0 ? htmlspecialchars($val) : '—'; ?></td>
      <?php endforeach; ?>
      <td style="text-align:center">
        <button onclick="detayAc('<?php echo addslashes($r['kod']); ?>','<?php echo addslashes($r['ad']); ?>')"
          style="background:#EFF6FF;color:#1D4ED8;border:none;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:11px;font-weight:700">Detay</button>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($stoklar)): ?>
    <tr><td colspan="11" style="text-align:center;padding:30px;color:var(--m2)">Stok verisi bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  
    <tfoot><tr><th>Malzeme Kodu</th><th>Malzeme Adı</th><th>Grup</th><th>Merkez</th><th>Üretim</th><th>BSH</th><th>Karantina</th><th>Kırma</th><th>Emanet</th><th>Takım Boz</th><th></th></tr></tfoot>
  </table>
  </div>
</div>
<?php endif; ?>
</div>

<!-- Detay Modal -->
<div id="stokDetayModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.97);backdrop-filter:blur(12px);border-radius:14px;width:100%;max-width:900px;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:18px 24px;border-bottom:1px solid var(--kenar)">
      <div style="font-size:15px;font-weight:800" id="stokDetayBaslik">📦 Malzeme Detayı</div>
      <button onclick="document.getElementById('stokDetayModal').style.display='none'" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:30px;height:30px;cursor:pointer">✕</button>
    </div>
    <div id="stokDetayIcerik" style="flex:1;overflow-y:auto;padding:20px">
      <div style="text-align:center;padding:30px;color:var(--m2)">Yükleniyor...</div>
    </div>
  </div>
</div>

<script>
var STOK_AJAX = '<?php echo BASE_URL; ?>/bolumler/tanimlamalar/ajax/stok-detay.php';

function detayAc(kod, ad) {
  document.getElementById('stokDetayBaslik').textContent = '📦 ' + kod + ' — ' + ad;
  document.getElementById('stokDetayIcerik').innerHTML = '<div style="text-align:center;padding:30px;color:var(--m2)">⏳ Yükleniyor...</div>';
  document.getElementById('stokDetayModal').style.display = 'flex';

  fetch(STOK_AJAX + '?kod=' + encodeURIComponent(kod), {credentials:'same-origin'})
  .then(function(r){return r.text();})
  .then(function(html){ document.getElementById('stokDetayIcerik').innerHTML = html; })
  .catch(function(){ document.getElementById('stokDetayIcerik').innerHTML = '<div style="color:#EF4444;padding:20px">Veri yüklenemedi.</div>'; });
}
</script>

<script>
$(document).ready(function(){
  if($.fn.DataTable.isDataTable('#tbl-stok'))return;
  var tbl = $('#tbl-stok').DataTable({
    paging:false,
    scrollX:true,
    scrollY:'580px',
    scrollCollapse:true,
    order:[[0,"asc"]],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'tbl-stok'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>

