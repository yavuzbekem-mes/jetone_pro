<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$kayitlar = [];

if ($tiger_ok) {
    try {
        $sql = "SELECT
            WS.CODE AS is_istasyonu,
            CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
            CONVERT(date, PRO.DATE_) AS uretim_tarihi,
            PRO.FICHENO AS emr_no,
            IT.CODE  AS mamul_kod,
            IT.NAME  AS mamul_adi,
            CONVERT(decimal(18,0),(SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN(0,1))) AS stok,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
            CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
            CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT) + ISNULL((SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE WHERE URETIM_EMRI_NO=PRO.FICHENO AND YEAR(URETIM_TARIHI)>=2025),0)) AS kalan,
            CONVERT(decimal(18,0), ISNULL((SELECT SUM(CONVERT(decimal,TOPLAM)) FROM MES.dbo.IKINCI_KALITE WHERE URETIM_EMRI_NO=PRO.FICHENO AND YEAR(URETIM_TARIHI)>=2025),0)) AS ikinci_kalite
        FROM dbo.LG_222_PRODORD AS PRO
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT   ON IT.LOGICALREF   = PRO.ITEMREF
        LEFT OUTER JOIN dbo.LG_222_BOMASTER AS BOM  ON BOM.LOGICALREF  = PRO.MASTERREF
        LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS  ON DIS.PRODORDREF  = PRO.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS   ON WS.LOGICALREF   = DIS.WSREF
        LEFT OUTER JOIN dbo.LG_222_OPRTREQ  AS OPRT ON OPRT.LOGICALREF = DIS.OPREQREF
        WHERE YEAR(PRO.DATE_) = YEAR(GETDATE())
          AND MONTH(PRO.DATE_) = MONTH(GETDATE())
          AND PRO.STATUS IN (0,1)
        GROUP BY YEAR(PRO.DATE_), MONTH(PRO.DATE_), WS.CODE,
            CONVERT(date,PRO.DATE_), PRO.FICHENO, IT.CODE, IT.NAME,
            PRO.PLNAMOUNT, PRO.STATUS, IT.LOGICALREF
        ORDER BY WS.CODE, PRO.STATUS DESC";

        $kayitlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
        // MES.dbo erişimi yoksa ikinci kalite olmadan dene
        try {
            $sql2 = "SELECT
                WS.CODE AS is_istasyonu,
                CASE WHEN PRO.STATUS=1 THEN 'Devam Ediyor' ELSE 'Başlamadı' END AS durum,
                CONVERT(date, PRO.DATE_) AS uretim_tarihi,
                PRO.FICHENO AS emr_no,
                IT.CODE AS mamul_kod, IT.NAME AS mamul_adi,
                CONVERT(decimal(18,0),(SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN(0,1))) AS stok,
                CONVERT(decimal(18,0), PRO.PLNAMOUNT) AS planlanan,
                CONVERT(decimal(18,0), SUM(PRO.ACTAMOUNT)) AS uretilen,
                CONVERT(decimal(18,0), PRO.PLNAMOUNT - SUM(PRO.ACTAMOUNT)) AS kalan,
                0 AS ikinci_kalite
            FROM dbo.LG_222_PRODORD AS PRO
            LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT   ON IT.LOGICALREF   = PRO.ITEMREF
            LEFT OUTER JOIN dbo.LG_222_DISPLINE AS DIS  ON DIS.PRODORDREF  = PRO.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WS   ON WS.LOGICALREF   = DIS.WSREF
            WHERE YEAR(PRO.DATE_) = YEAR(GETDATE())
              AND MONTH(PRO.DATE_) = MONTH(GETDATE())
              AND PRO.STATUS IN (0,1)
            GROUP BY YEAR(PRO.DATE_), MONTH(PRO.DATE_), WS.CODE,
                CONVERT(date,PRO.DATE_), PRO.FICHENO, IT.CODE, IT.NAME,
                PRO.PLNAMOUNT, PRO.STATUS, IT.LOGICALREF
            ORDER BY WS.CODE, PRO.STATUS DESC";
            $kayitlar = $tigerdb_pdo->query($sql2)->fetchAll(PDO::FETCH_ASSOC);
        } catch(Throwable $e2) { $hata = $e2->getMessage(); }
    }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 Üretim Emirleri</h1>
    <div class="s-yol">Tanımlamalar / <b>Üretim Emirleri</b>
      <?php if($tiger_ok && !$hata): ?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo count($kayitlar); ?> kayıt)</span>
      <?php else: ?>
      <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<?php if(!$tiger_ok): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px">
  ⚠️ Tiger DB bağlantısı yok.
</div>
<?php else: ?>

<div class="kart" style="overflow:hidden">
  <table class="tablo" id="tbl-ue" style="width:100%">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th>İş İstasyonu</th><th>Durum</th><th>Tarih</th><th>Emr No</th>
        <th>Mamul Kodu</th><th>Mamul Adı</th>
        <th style="text-align:right">Stok</th>
        <th style="text-align:right">Planlanan</th>
        <th style="text-align:right">Üretilen</th>
        <th style="text-align:right">2. Kalite</th>
        <th style="text-align:right">Kalan</th>
      </tr>
    </thead>
    <tfoot>
      <tr>
        <th>İş İstasyonu</th><th>Durum</th><th>Tarih</th><th>Emr No</th>
        <th>Mamul Kodu</th><th>Mamul Adı</th>
        <th>Stok</th><th>Planlanan</th><th>Üretilen</th><th>2. Kalite</th><th>Kalan</th>
      </tr>
    </tfoot>
    <tbody>
    <?php foreach($kayitlar as $r):
      $dur_bg = $r['durum']==='Devam Ediyor' ? '#D1FAE5' : '#DBEAFE';
      $dur_fg = $r['durum']==='Devam Ediyor' ? '#065F46' : '#1E40AF';
      $kalan  = (float)($r['kalan']??0);
      $kalan_renk = $kalan<=0 ? '#059669' : ($kalan<100 ? '#D97706' : '#DC2626');
    ?>
    <tr>
      <td style="font-weight:700;font-size:11px"><?php echo htmlspecialchars($r['is_istasyonu']??'—');?></td>
      <td><span style="background:<?php echo $dur_bg;?>;color:<?php echo $dur_fg;?>;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['durum']);?></span></td>
      <td style="font-size:11px"><?php echo $r['uretim_tarihi'] ? date('d.m.Y',strtotime($r['uretim_tarihi'])) : '—';?></td>
      <td style="font-size:11px;font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['emr_no']??'');?></td>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['mamul_kod']??'');?></code></td>
      <td style="font-size:12px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo htmlspecialchars($r['mamul_adi']??'');?>"><?php echo htmlspecialchars($r['mamul_adi']??'');?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo number_format((float)($r['stok']??0),0,',','.');?></td>
      <td style="text-align:right"><?php echo number_format((float)($r['planlanan']??0),0,',','.');?></td>
      <td style="text-align:right;color:#065F46;font-weight:600"><?php echo number_format((float)($r['uretilen']??0),0,',','.');?></td>
      <td style="text-align:right;color:#D97706"><?php echo number_format((float)($r['ikinci_kalite']??0),0,',','.');?></td>
      <td style="text-align:right;font-weight:700;color:<?php echo $kalan_renk;?>"><?php echo number_format($kalan,0,',','.');?></td>
    </tr>
    <?php endforeach; ?>
    <?php if(empty($kayitlar)): ?>
    <tr><td colspan="11" style="text-align:center;padding:30px;color:var(--m2)">Bu ay açık üretim emri bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php endif; ?>
</div>

<script>
$(document).ready(function(){
  if($.fn.DataTable.isDataTable('#tbl-ue')) return;
  $('#tbl-ue').DataTable({
    paging:false,
    autoWidth:false,
    scrollY:'580px',
    scrollCollapse:true,
    order:[[1,'desc'],[0,'asc']],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Uretim_Emirleri'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>
