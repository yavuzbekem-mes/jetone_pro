<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$detay_kod = trim($_GET['kod'] ?? '');
$detay_adi = trim($_GET['ad'] ?? '');
$hata = '';

// ── LİSTE MODU ─────────────────────────────────────────────
$receteler = [];
if (!$detay_kod) {
    if ($tiger_ok) {
        try {
            $sql = "SELECT DISTINCT BOM.CODE AS kod, BOM.NAME AS ad
                    FROM dbo.LG_222_BOMLINE AS BML
                    LEFT OUTER JOIN dbo.LG_222_BOMREVSN AS BMR ON BML.BOMREVREF = BMR.LOGICALREF
                    LEFT OUTER JOIN dbo.LG_222_BOMASTER AS BOM ON BMR.BOMMASTERREF = BOM.LOGICALREF
                    LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON BOM.MAINPRODREF = IT.LOGICALREF
                    LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT2 ON BML.ITEMREF = IT2.LOGICALREF
                    WHERE (BML.LINETYPE = 0) AND (BOM.ACTIVE = 0) AND (IT.ACTIVE = 0)
                    ORDER BY BOM.CODE";
            $receteler = $tigerdb_pdo->query($sql)->fetchAll();
        } catch(Throwable $e) { $hata = $e->getMessage(); }
    }
    $f_arama = trim($_GET['arama'] ?? '');
    if ($f_arama) {
        $receteler = array_filter($receteler, function($r) use ($f_arama) {
            return stripos($r['kod'].$r['ad'], $f_arama) !== false;
        });
    }
}

// ── DETAY MODU ──────────────────────────────────────────────
$recete_detay = []; $stok_map = [];
if ($detay_kod && $tiger_ok) {
    try {
        // Stok bilgisi
        $stok_sql = "SELECT IT.CODE AS kod,
            REPLACE(CONVERT(VARCHAR,
                CASE WHEN SUM(CASE WHEN LV.INVENNO IN (0,1,5) THEN LV.ONHAND ELSE 0 END) <= 0
                     THEN 0 ELSE SUM(CASE WHEN LV.INVENNO IN (0,1,5) THEN LV.ONHAND ELSE 0 END) END
            ), '.', ',') AS stok
            FROM dbo.LG_222_ITEMS AS IT
            LEFT OUTER JOIN dbo.LV_222_02_STINVTOT AS LV ON LV.STOCKREF = IT.LOGICALREF
            LEFT OUTER JOIN dbo.L_CAPIWHOUSE AS CAP ON CAP.NR = LV.INVENNO
            WHERE IT.CARDTYPE NOT IN (4,22) AND IT.CANCONFIGURE=0 AND CAP.FIRMNR=222
              AND LV.INVENNO IN (0,1,5,2,3,4,98)
              AND IT.STGRPCODE IN ('Ambalaj','Plastik HM','Mamül','Yarımamül','Masterbatch','Yardımcı Malz.')
            GROUP BY IT.CODE, IT.NAME, IT.LOGICALREF, IT.STGRPCODE, IT.SPECODE";
        foreach ($tigerdb_pdo->query($stok_sql)->fetchAll() as $s) {
            $stok_map[$s['kod']] = $s['stok'];
        }

        // Reçete detayı
        $det_sql = "SELECT BML.LOGICALREF AS satir_id,
            IT2.CODE AS girdi_kod, IT2.NAME AS girdi_ad,
            CASE WHEN FLOOR(BML.AMOUNT)=BML.AMOUNT THEN FORMAT(BML.AMOUNT,'N0','tr-TR')
                 ELSE FORMAT(BML.AMOUNT,'N5','tr-TR') END AS miktar,
            UN.CODE AS birim,
            CASE WHEN BML.LINETYPE=4 THEN 'ANA ÜRÜN' WHEN BML.LINETYPE=0 THEN 'GİRDİ' END AS satir_tipi
            FROM dbo.LG_222_BOMLINE AS BML
            LEFT OUTER JOIN dbo.LG_222_BOMREVSN AS BMR ON BML.BOMREVREF=BMR.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_BOMASTER AS BOM ON BMR.BOMMASTERREF=BOM.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_UNITSETL AS UN  ON BML.UOMREF=UN.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON BOM.MAINPRODREF=IT.LOGICALREF
            LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT2 ON BML.ITEMREF=IT2.LOGICALREF
            WHERE BOM.CODE = ?
            ORDER BY BML.LOGICALREF";
        $s2 = $tigerdb_pdo->prepare($det_sql);
        $s2->execute([$detay_kod]);
        $recete_detay = $s2->fetchAll();
        foreach ($recete_detay as &$row) {
            $row['stok'] = $stok_map[$row['girdi_kod']] ?? '0';
        }
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Reçete Tanımları</h1>
    <div class="s-yol">Tanımlamalar /
      <?php if ($detay_kod): ?>
        <a href="?sayfa=tanim-recete" style="color:var(--t);text-decoration:none">Reçeteler</a> / <b><?php echo htmlspecialchars($detay_kod); ?></b>
      <?php else: ?>
        <b>Reçeteler</b>
        <?php if ($tiger_ok): ?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:6px">● Tiger DB</span>
        <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo number_format(count($receteler)); ?> reçete)</span><?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;gap:8px">
    <?php if ($detay_kod): ?>
    <a href="?sayfa=tanim-recete" style="background:var(--kart);color:var(--m);border:1px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">← Listeye Dön</a>
    <button onclick="dtExcelIndir('tbl-detay','Recete_<?php echo htmlspecialchars($detay_kod); ?>')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
    <?php else: ?>
    <?php endif; ?>
  </div>
</div>

<div class="s-body">
<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<?php if ($detay_kod): ?>
<!-- ═══════════════ DETAY MODU ═══════════════ -->
<div class="kart" style="padding:16px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
  <div>
    <div style="font-size:16px;font-weight:800"><?php echo htmlspecialchars($detay_kod); ?></div>
    <div style="font-size:13px;color:var(--m2);margin-top:2px"><?php echo htmlspecialchars($detay_adi); ?></div>
  </div>
  <div style="display:flex;align-items:center;gap:10px">
    <label class="form-etiket" style="margin:0">Üretim Miktarı:</label>
    <input type="number" id="hesapMiktar" class="form-alan" style="width:120px" placeholder="Adet" value="1" min="1">
    <button onclick="hesapla()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:9px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">🧮 Hesapla</button>
  </div>
</div>

<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 320px)">
  <table class="tablo" id="tbl-detay" style="min-width:900px">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="width:50px">#</th>
        <th>Girdi Kodu</th>
        <th>Girdi Adı</th>
        <th style="width:100px;text-align:right">Birim Sarf</th>
        <th style="width:70px;text-align:center">Birim</th>
        <th style="width:90px;text-align:center">Satır Tipi</th>
        <th style="width:110px;text-align:right">Mevcut Stok</th>
        <th style="width:110px;text-align:right" id="th-brut">Brüt İhtiyaç</th>
        <th style="width:110px;text-align:right" id="th-net">Net İhtiyaç</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($recete_detay as $r):
      $is_ana = ($r['satir_tipi'] === 'ANA ÜRÜN');
      $stok_val = (float)str_replace(['.', ','], ['', '.'], $r['stok']);
    ?>
    <tr style="<?php echo $is_ana ? 'background:#FFF7ED;font-weight:700' : ''; ?>">
      <td style="color:var(--m2)"><?php echo $r['satir_id']; ?></td>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-weight:700;color:var(--t);font-size:11px"><?php echo htmlspecialchars($r['girdi_kod']??''); ?></code></td>
      <td style="font-size:12px"><?php echo htmlspecialchars($r['girdi_ad']??''); ?></td>
      <td style="text-align:right;font-family:monospace;font-weight:700" class="birim-sarf"><?php echo htmlspecialchars($r['miktar']??''); ?></td>
      <td style="text-align:center;font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($r['birim']??''); ?></td>
      <td style="text-align:center">
        <span style="background:<?php echo $is_ana?'#FEF3C7':'#DBEAFE'; ?>;color:<?php echo $is_ana?'#92400E':'#1E40AF'; ?>;font-size:10px;font-weight:700;padding:2px 6px;border-radius:10px">
          <?php echo htmlspecialchars($r['satir_tipi']??''); ?>
        </span>
      </td>
      <td style="text-align:right;font-weight:600;color:<?php echo $stok_val > 0 ? '#065F46' : '#9CA3AF'; ?>" class="stok-val" data-stok="<?php echo $stok_val; ?>">
        <?php echo htmlspecialchars($r['stok']??'0'); ?>
      </td>
      <td style="text-align:right;font-family:monospace" class="brut-cell" data-satir="<?php echo $r['satir_id']; ?>">—</td>
      <td style="text-align:right;font-family:monospace;font-weight:700" class="net-cell" data-satir="<?php echo $r['satir_id']; ?>">—</td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($recete_detay)): ?>
    <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--m2)">Reçete satırı bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  
    <tfoot><tr><th>#</th><th>Girdi Kodu</th><th>Girdi Adı</th><th>Birim Sarf</th><th>Birim</th><th>Satır Tipi</th><th>Mevcut Stok</th><th>Brüt İhtiyaç</th><th>Net İhtiyaç</th></tr></tfoot>
  </table>
  </div>
</div>

<script>
function hesapla() {
  var miktar = parseFloat(document.getElementById('hesapMiktar').value) || 0;
  if (miktar <= 0) { alert('Geçerli bir miktar girin'); return; }

  var rows = document.querySelectorAll('#tbl-detay tbody tr');
  rows.forEach(function(row) {
    var satirTipi = row.querySelector('.birim-sarf');
    if (!satirTipi) return;
    var tipEl = row.querySelector('[class*="satir_tipi"], span');
    // ANA ÜRÜN satırlarını atla
    if (row.style.fontWeight === '700') return;

    var birimSarfTxt = (satirTipi.textContent || '').replace(/\./g,'').replace(',','.');
    var birimSarf    = parseFloat(birimSarfTxt) || 0;
    var stok         = parseFloat(row.querySelector('.stok-val').dataset.stok) || 0;
    var satirId      = row.querySelector('.brut-cell').dataset.satir;

    if (birimSarf === 0) return;

    var brut = miktar * birimSarf;
    var net  = stok - brut;

    var brutEl = row.querySelector('.brut-cell');
    var netEl  = row.querySelector('.net-cell');

    brutEl.textContent = brut % 1 === 0 ? Math.round(brut).toLocaleString('tr-TR') : brut.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:4});
    netEl.textContent  = net % 1 === 0 ? Math.round(net).toLocaleString('tr-TR') : net.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:4});
    netEl.style.color  = net < 0 ? '#EF4444' : net === 0 ? '#F97316' : '#065F46';
    netEl.style.background = net < 0 ? '#FEF2F2' : '';
  });
}
// Enter ile hesapla
document.getElementById('hesapMiktar').addEventListener('keydown', function(e){ if(e.key==='Enter') hesapla(); });
</script>

<?php else: ?>
<!-- ═══════════════ LİSTE MODU ═══════════════ -->
<?php if (!$tiger_ok): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px;margin-bottom:14px">
  ⚠️ Tiger DB bağlantısı yok. <a href="?sayfa=ayarlar-enteg" style="color:#991B1B;font-weight:700">Entegrasyon ayarlarına git →</a>
</div>
<?php else: ?>
<form method="GET" style="display:flex;gap:8px;margin-bottom:12px">
  <input type="hidden" name="sayfa" value="tanim-recete">
  <input type="text" name="arama" value="<?php echo htmlspecialchars($_GET['arama']??''); ?>" class="form-alan" style="width:220px" placeholder="🔍 Reçete kodu veya adı...">
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <button type="button" onclick="dtExcelIndir('tbl-recete','ReceteTanimlari')" style="background:#217346;color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
  <?php if (!empty($_GET['arama'])): ?><a href="?sayfa=tanim-recete" style="padding:8px 12px;background:#F3F4F6;color:#374151;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">✕</a><?php endif; ?>
</form>

<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 290px)">
  <table class="tablo" id="tbl-recete">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr><th>Reçete Kodu</th><th>Reçete Açıklaması</th><th style="width:100px;text-align:center">Detay</th></tr>
    </thead>
    <tbody>
    <?php foreach ($receteler as $r): ?>
    <tr>
      <td><code style="background:var(--bg);padding:2px 6px;border-radius:4px;font-weight:700;color:var(--t);font-size:12px"><?php echo htmlspecialchars($r['kod']); ?></code></td>
      <td style="font-size:13px"><?php echo htmlspecialchars($r['ad']); ?></td>
      <td style="text-align:center">
        <a href="?sayfa=tanim-recete&kod=<?php echo urlencode($r['kod']); ?>&ad=<?php echo urlencode($r['ad']); ?>"
           style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:4px 12px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none;white-space:nowrap">
          🔍 BOM Patlat
        </a>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($receteler)): ?>
    <tr><td colspan="3" style="text-align:center;padding:30px;color:var(--m2)">Reçete bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
    <tfoot><tr><th>Reçete Kodu</th><th>Reçete Açıklaması</th><th>Detay</th></tr></tfoot>
  </table>
  </div>
</div>
<?php endif; ?>
<?php endif; ?>
</div>

<script>
$(document).ready(function(){
  // BOM Detay tablosu
  if($('#tbl-detay').length && !$.fn.DataTable.isDataTable('#tbl-detay')){
    $('#tbl-detay').DataTable({
      paging:false,
      scrollX:true,
      scrollY:'550px',
      scrollCollapse:true,
      order:[],
      dom:'Bfrtip',
      buttons:[
        {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'BOM_Detay'}
      ],
      language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
      initComplete:function(){
        this.api().columns().every(function(){
          var col=this;
          var th=$(col.footer());
          if(!th||!th.length)return;
          var label=th.text().trim();
          if(!label||label==='#'||label==='Brüt İhtiyaç'||label==='Net İhtiyaç'){th.empty();return;}
          var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
            .appendTo(th.empty())
            .on('change',function(){
              var v=$.fn.dataTable.util.escapeRegex($(this).val());
              col.search(v?'^'+v+'$':'',true,false).draw();
            });
          col.data().unique().sort().each(function(d){
            var v=$('<div/>').html(d).text();
            sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
          });
        });
      }
    });
  }

  if($.fn.DataTable.isDataTable('#tbl-recete'))return;
  var tbl = $('#tbl-recete').DataTable({
    paging:false,
    autoWidth:false,
    scrollY:'550px',
    scrollCollapse:true,
    order:[[0,"asc"]],
    columns:[{width:'25%'},{width:'65%'},{width:'10%'}],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'tbl-recete'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>

