<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$kayitlar = [];
$hata = '';
$f_arama = trim($_GET['arama'] ?? '');

if ($tiger_ok) {
    try {
        $sql = "SELECT WS.CODE AS kod, WS.NAME AS ad
                FROM dbo.LG_222_WORKSTAT AS WS
                ORDER BY WS.CODE";
        $all = $tigerdb_pdo->query($sql)->fetchAll();
        if ($f_arama) {
            $kayitlar = array_filter($all, function($r) use ($f_arama) {
                return stripos(($r['kod']??'').($r['ad']??''), $f_arama) !== false;
            });
        } else {
            $kayitlar = $all;
        }
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🏭 İş İstasyonu Tanımları</h1>
    <div class="s-yol">Tanımlamalar / <b>İş İstasyonları</b>
      <?php if ($tiger_ok): ?>
        <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
        <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php echo number_format(count($kayitlar)); ?> istasyon)</span>
      <?php else: ?>
        <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<?php if (!$tiger_ok): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px">
  ⚠️ Tiger DB bağlantısı yok. <a href="?sayfa=ayarlar-enteg" style="color:#991B1B;font-weight:700">Entegrasyon ayarlarına git →</a>
</div>
<?php else: ?>

<form method="GET" style="display:flex;gap:8px;margin-bottom:12px">
  <input type="hidden" name="sayfa" value="tanim-istasyon">
  <input type="text" name="arama" value="<?php echo htmlspecialchars($f_arama); ?>" class="form-alan" style="width:220px" placeholder="🔍 Kod veya ad...">
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <button type="button" onclick="dtExcelIndir('tbl-istasyon','IsIstasyonlari')" style="background:#217346;color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
  <?php if ($f_arama): ?><a href="?sayfa=tanim-istasyon" style="padding:8px 12px;background:#F3F4F6;color:#374151;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">✕</a><?php endif; ?>
</form>

<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)">
  <table class="tablo" id="tbl-istasyon">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr><th>İş İstasyonu Kodu</th><th>İş İstasyonu Adı</th></tr>
    </thead>
    <tbody>
    <?php foreach ($kayitlar as $r): ?>
    <tr>
      <td><code style="background:var(--bg);padding:2px 6px;border-radius:4px;font-weight:700;color:var(--t);font-size:12px"><?php echo htmlspecialchars($r['kod']??''); ?></code></td>
      <td style="font-size:13px"><?php echo htmlspecialchars($r['ad']??''); ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($kayitlar)): ?>
    <tr><td colspan="2" style="text-align:center;padding:30px;color:var(--m2)">İstasyon bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  
    <tfoot><tr><th>İş İstasyonu Kodu</th><th>İş İstasyonu Adı</th></tr></tfoot>
  </table>
  </div>
</div>
<?php endif; ?>
</div>

<script>
$(document).ready(function(){
  if($.fn.DataTable.isDataTable('#tbl-istasyon'))return;
  var tbl = $('#tbl-istasyon').DataTable({
    paging:false,
    autoWidth:false,
    scrollY:'580px',
    scrollCollapse:true,
    order:[[0,"asc"]],
    columns:[{width:'35%'},{width:'65%'}],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'tbl-istasyon'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>

