<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$kul = Auth::kullanici();
$ad_soyad = $kul['ad_soyad'] ?? 'ERP';

$d     = json_decode(file_get_contents('php://input'), true) ?: [];
$islem = $d['islem'] ?? '';

try {
    if ($islem === 'sil') {
        $db->prepare("DELETE FROM malzeme_tanimlari WHERE malzeme_id=?")->execute([(int)$d['id']]);
        echo json_encode(['ok'=>true]); exit;
    }

    $ad = trim($d['ad'] ?? '');
    if (!$ad) { echo json_encode(['ok'=>false,'hata'=>'Malzeme adı zorunlu']); exit; }

    $fields = [
        'malzeme_tur'      => trim($d['tur'] ?? '') ?: null,
        'malzeme_group'    => trim($d['group'] ?? '') ?: null,
        'malzeme_firma'    => trim($d['firma'] ?? '') ?: null,
        'malzeme_kod'      => trim($d['kod'] ?? '') ?: null,
        'malzeme_ad'       => $ad,
        'malzeme_birim'    => trim($d['birim'] ?? 'ADET'),
        'malzeme_stok'     => trim($d['stok'] ?? '') ?: null,
        'map_makina_tonaj' => trim($d['tonaj'] ?? '') ?: null,
        'map_gramaj'       => trim($d['gramaj'] ?? '') ?: null,
        'map_cevrim'       => trim($d['cevrim'] ?? '') ?: null,
        'paket_miktari'    => trim($d['paket'] ?? '') ?: null,
        'taban_miktari'    => trim($d['taban'] ?? '') ?: null,
        'malzeme_ambalaj'  => trim($d['ambalaj'] ?? '') ?: null,
    ];

    if ($islem === 'guncelle') {
        $fields['malzeme_update']         = $ad_soyad;
        $fields['malzeme_update_tarihi']  = date('Y-m-d H:i:s');
        $set = implode(',', array_map(function($k){ return "`$k`=?"; }, array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = (int)$d['id'];
        $db->prepare("UPDATE malzeme_tanimlari SET $set WHERE malzeme_id=?")->execute($vals);
    } else {
        $fields['malzeme_ekleyen'] = $ad_soyad;
        $fields['malzeme_tarihi']  = date('Y-m-d H:i:s');
        $cols = implode(',', array_map(function($k){ return "`$k`"; }, array_keys($fields)));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        $db->prepare("INSERT INTO malzeme_tanimlari ($cols) VALUES ($phs)")->execute(array_values($fields));
    }
    echo json_encode(['ok'=>true]);
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
