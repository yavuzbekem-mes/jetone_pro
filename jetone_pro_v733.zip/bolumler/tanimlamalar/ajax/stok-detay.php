<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/baglanlogo.php';
ob_end_clean();
header('Content-Type: text/html; charset=utf-8');
Auth::zorunlu();

$kod = trim($_GET['kod'] ?? $_POST['malzeme_kodu'] ?? '');
if (!$kod) { echo '<div style="color:#EF4444;padding:20px">Malzeme kodu eksik.</div>'; exit; }
if (!$tigerdb_pdo) { echo '<div style="color:#EF4444;padding:20px">Tiger DB bağlantısı yok.</div>'; exit; }

$ay_isimleri = [1=>'Oca',2=>'Şub',3=>'Mar',4=>'Nis',5=>'May',6=>'Haz',7=>'Tem',8=>'Ağu',9=>'Eyl',10=>'Eki',11=>'Kas',12=>'Ara'];

try {
    /* ── 1. STOK (PIVOT) ── */
    $stok = null;
    try {
        $s = $tigerdb_pdo->prepare("
            SELECT CODE AS kod, NAME AS ad,
                ISNULL([Merkez],0) AS Merkez,
                ISNULL([Üretim],0) AS Uretim,
                ISNULL([BSH],0) AS BSH,
                ISNULL([Karantina],0) AS Karantina,
                ISNULL([Kırma],0) AS Kirma,
                ISNULL([Emanet],0) AS Emanet,
                ISNULL([Takım Boz],0) AS Takim_Boz
            FROM (
                SELECT IT.CODE, IT.NAME, CAP.NAME AS AMBAR, SUM(LV.ONHAND) MIKTAR
                FROM dbo.LG_222_ITEMS IT
                INNER JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
                INNER JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO AND CAP.FIRMNR=222
                WHERE IT.CODE=? AND LV.INVENNO IN (0,1,2,3,4,5,98)
                GROUP BY IT.CODE,IT.NAME,CAP.NAME
            ) SRC
            PIVOT (SUM(MIKTAR) FOR AMBAR IN ([Merkez],[Üretim],[BSH],[Karantina],[Kırma],[Emanet],[Takım Boz])) PVT
        ");
        $s->execute([$kod]); $stok = $s->fetch();
    } catch(Throwable $e) {}

    /* ── Yardımcı: aylık veri çek ── */
    function aylik_cek($pdo, $sql, $params) {
        try {
            $s = $pdo->prepare($sql);
            $s->execute($params);
            return $s->fetchAll();
        } catch(Throwable $e) { return []; }
    }

    $p6 = [':k1'=>$kod,':k2'=>$kod];

    /* ── 2. ÜRETİM ── */
    $uretim_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(URETIM) AS URETIM FROM (
            SELECT YEAR(ST.DATE_) YIL,MONTH(ST.DATE_) AY,ST.AMOUNT URETIM
            FROM dbo.LG_222_02_STLINE ST INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=ST.STOCKREF
            WHERE ST.TRCODE=13 AND ST.LPRODSTAT=0 AND IT.CODE=:k1 AND ST.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(ST.DATE_),MONTH(ST.DATE_),ST.AMOUNT
            FROM dbo.LG_222_01_STLINE ST INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=ST.STOCKREF
            WHERE ST.TRCODE=13 AND ST.LPRODSTAT=0 AND IT.CODE=:k2 AND ST.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 3. SATIŞ ── */
    $satis_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(SATIS) AS SATIS FROM (
            SELECT YEAR(STL.DATE_) YIL,MONTH(STL.DATE_) AY,STL.AMOUNT SATIS
            FROM dbo.LG_222_02_STLINE STL INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=8 AND STL.LINETYPE=0 AND IT.CODE=:k1 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STL.DATE_),MONTH(STL.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL INNER JOIN dbo.LG_222_01_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=8 AND STL.LINETYPE=0 AND IT.CODE=:k2 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 4. SATIŞ İADE ── */
    $satis_iade_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(MIKTAR) SATIS_IADE FROM (
            SELECT YEAR(STL.DATE_) YIL,MONTH(STL.DATE_) AY,STL.AMOUNT MIKTAR
            FROM dbo.LG_222_02_STLINE STL INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=3 AND STL.LINETYPE=0 AND IT.CODE=:k1 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STL.DATE_),MONTH(STL.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL INNER JOIN dbo.LG_222_01_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=3 AND STL.LINETYPE=0 AND IT.CODE=:k2 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 5. SATINALMA ── */
    $satinalma_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(SATINALMA) AS SATINALMA FROM (
            SELECT YEAR(STF.DATE_) YIL,MONTH(STF.DATE_) AY,STL.AMOUNT SATINALMA
            FROM dbo.LG_222_02_STLINE STL INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=1 AND STL.CANCELLED=0 AND IT.CODE=:k1 AND STF.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STF.DATE_),MONTH(STF.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL INNER JOIN dbo.LG_222_01_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=1 AND STL.CANCELLED=0 AND IT.CODE=:k2 AND STF.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 6. SATINALMA İADE ── */
    $satinalma_iade_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(MIKTAR) SATINALMA_IADE FROM (
            SELECT YEAR(STF.DATE_) YIL,MONTH(STF.DATE_) AY,STL.AMOUNT MIKTAR
            FROM dbo.LG_222_02_STLINE STL INNER JOIN dbo.LG_222_02_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=6 AND IT.CODE=:k1 AND STF.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STF.DATE_),MONTH(STF.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL INNER JOIN dbo.LG_222_01_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STF.TRCODE=6 AND IT.CODE=:k2 AND STF.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 7. SARF (TRCODE=12) ── */
    $sarf_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(SARF) AS SARF FROM (
            SELECT YEAR(STL.DATE_) YIL,MONTH(STL.DATE_) AY,STL.AMOUNT SARF
            FROM dbo.LG_222_02_STLINE STL
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STL.TRCODE=12 AND STL.CANCELLED=0 AND STL.LPRODSTAT=0 AND IT.CODE=:k1 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STL.DATE_),MONTH(STL.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STL.TRCODE=12 AND STL.CANCELLED=0 AND STL.LPRODSTAT=0 AND IT.CODE=:k2 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 8. FİRE (TRCODE=11) ── */
    $fire_data = aylik_cek($tigerdb_pdo, "
        SELECT YIL,AY,SUM(FIRE) AS FIRE FROM (
            SELECT YEAR(STL.DATE_) YIL,MONTH(STL.DATE_) AY,STL.AMOUNT FIRE
            FROM dbo.LG_222_02_STLINE STL
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STL.TRCODE=11 AND STL.CANCELLED=0 AND STL.LPRODSTAT=0 AND IT.CODE=:k1 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
            UNION ALL
            SELECT YEAR(STL.DATE_),MONTH(STL.DATE_),STL.AMOUNT
            FROM dbo.LG_222_01_STLINE STL
            INNER JOIN dbo.LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF
            WHERE STL.TRCODE=11 AND STL.CANCELLED=0 AND STL.LPRODSTAT=0 AND IT.CODE=:k2 AND STL.DATE_>=DATEADD(MONTH,-6,GETDATE())
        ) X GROUP BY YIL,AY ORDER BY YIL,AY", $p6);

    /* ── 9. AYLIK BİRLEŞTİR ── */
    $aylik = [];
    function aylik_ekle(&$aylik, $data, $alan, $ay_isimleri) {
        foreach ((array)$data as $row) {
            $key = $row['YIL'].'-'.str_pad($row['AY'],2,'0',STR_PAD_LEFT);
            if (!isset($aylik[$key])) {
                $aylik[$key] = ['etiket'=>($ay_isimleri[$row['AY']]??$row['AY']).' '.$row['YIL'],
                    'URETIM'=>0,'SATIS'=>0,'SATIS_IADE'=>0,'SATINALMA'=>0,'SATINALMA_IADE'=>0,'SARF'=>0,'FIRE'=>0];
            }
            $aylik[$key][$alan] += (float)($row[$alan] ?? 0);
        }
    }
    aylik_ekle($aylik, $uretim_data,       'URETIM',          $ay_isimleri);
    aylik_ekle($aylik, $satis_data,        'SATIS',           $ay_isimleri);
    aylik_ekle($aylik, $satis_iade_data,   'SATIS_IADE',      $ay_isimleri);
    aylik_ekle($aylik, $satinalma_data,    'SATINALMA',       $ay_isimleri);
    aylik_ekle($aylik, $satinalma_iade_data,'SATINALMA_IADE', $ay_isimleri);
    aylik_ekle($aylik, $sarf_data,         'SARF',            $ay_isimleri);
    aylik_ekle($aylik, $fire_data,         'FIRE',            $ay_isimleri);
    krsort($aylik); // en yeni üstte

    /* ── HTML ── */
    $ambarlar = ['Merkez','Uretim','BSH','Karantina','Kirma','Emanet','Takim_Boz'];
    $ambar_etiket = ['Merkez'=>'Merkez','Uretim'=>'Üretim','BSH'=>'BSH','Karantina'=>'Karantina','Kirma'=>'Kırma','Emanet'=>'Emanet','Takim_Boz'=>'Takım Boz'];
?>
<!-- AMBAR STOKLARI -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:20px">
<?php foreach ($ambarlar as $a):
    $val = $stok ? (float)($stok[$a]??0) : 0;
    $renk = $val > 0 ? '#065F46' : '#9CA3AF';
    $bg   = $val > 0 ? '#D1FAE5' : '#F3F4F6';
?>
<div style="background:<?php echo $bg;?>;border-radius:10px;padding:12px 14px;text-align:center">
    <div style="font-size:11px;color:<?php echo $renk;?>;font-weight:600;margin-bottom:4px"><?php echo $ambar_etiket[$a]; ?></div>
    <div style="font-size:20px;font-weight:800;color:<?php echo $renk;?>;font-family:monospace"><?php echo number_format($val,0,',','.'); ?></div>
</div>
<?php endforeach; ?>
</div>

<?php if (!empty($aylik)): ?>
<!-- AYLIK HAREKETLER -->
<div style="font-size:13px;font-weight:700;margin-bottom:8px;color:var(--t)">📅 Son 6 Ay Hareketleri</div>
<div style="overflow-x:auto">
<table style="width:100%;border-collapse:collapse;font-size:12px">
  <thead>
    <tr style="background:var(--bg)">
      <th style="padding:8px 10px;text-align:left;border-bottom:2px solid var(--kenar);white-space:nowrap">Ay</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar)">Üretim</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar)">Satış</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#EF4444">S.İade</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#EF4444">İade%</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar)">Satınalma</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#EF4444">A.İade</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#EF4444">İade%</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#F97316">Sarf</th>
      <th style="padding:8px 10px;text-align:right;border-bottom:2px solid var(--kenar);color:#EF4444">Fire</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($aylik as $a):
    $si_oran = $a['SATIS'] > 0 ? round($a['SATIS_IADE']/$a['SATIS']*100,1) : 0;
    $ai_oran = $a['SATINALMA'] > 0 ? round($a['SATINALMA_IADE']/$a['SATINALMA']*100,1) : 0;
  ?>
  <tr style="border-bottom:1px solid var(--kenar)">
    <td style="padding:7px 10px;font-weight:700;white-space:nowrap"><?php echo $a['etiket']; ?></td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace"><?php echo $a['URETIM']>0 ? number_format($a['URETIM'],0,',','.') : '—'; ?></td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;font-weight:600"><?php echo $a['SATIS']>0 ? number_format($a['SATIS'],0,',','.') : '—'; ?></td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;color:#EF4444"><?php echo $a['SATIS_IADE']>0 ? number_format($a['SATIS_IADE'],0,',','.') : '—'; ?></td>
    <td style="padding:7px 10px;text-align:right;font-weight:700;color:<?php echo $si_oran>5?'#EF4444':($si_oran>0?'#F97316':'#9CA3AF'); ?>">
      <?php echo $si_oran > 0 ? '%'.$si_oran : '—'; ?>
    </td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;font-weight:600"><?php echo $a['SATINALMA']>0 ? number_format($a['SATINALMA'],0,',','.') : '—'; ?></td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;color:#EF4444"><?php echo $a['SATINALMA_IADE']>0 ? number_format($a['SATINALMA_IADE'],0,',','.') : '—'; ?></td>
    <td style="padding:7px 10px;text-align:right;font-weight:700;color:<?php echo $ai_oran>5?'#EF4444':($ai_oran>0?'#F97316':'#9CA3AF'); ?>">
      <?php echo $ai_oran > 0 ? '%'.$ai_oran : '—'; ?>
    </td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;color:#F97316;font-weight:600">
      <?php echo $a['SARF']>0 ? number_format($a['SARF'],0,',','.') : '—'; ?>
    </td>
    <td style="padding:7px 10px;text-align:right;font-family:monospace;color:#EF4444;font-weight:600">
      <?php echo $a['FIRE']>0 ? number_format($a['FIRE'],0,',','.') : '—'; ?>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php else: ?>
<div style="text-align:center;padding:20px;color:var(--m2)">Son 6 ayda hareket bulunamadı.</div>
<?php endif; ?>
<?php
} catch(Throwable $e) {
    echo '<div style="color:#EF4444;padding:20px">Hata: '.htmlspecialchars($e->getMessage()).'</div>';
}
