<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$d = json_decode(file_get_contents('php://input'), true) ?: [];
$islem = $d['islem'] ?? '';
try {
    if ($islem === 'sil') { $db->prepare("DELETE FROM receteler WHERE id=?")->execute([(int)$d['id']]); $db->prepare("DELETE FROM recete_satirlari WHERE recete_id=?")->execute([(int)$d['id']]); echo json_encode(['ok'=>true]); exit; }
    $kod = trim($d['kod']??''); $ad = trim($d['ad']??'');
    if (!$kod || !$ad) { echo json_encode(['ok'=>false,'hata'=>'Kod ve ad zorunlu']); exit; }
    if ($islem === 'guncelle') {
        $db->prepare("UPDATE receteler SET kod=?,ad=?,mamul_kodu=?,versiyon=?,miktar=?,birim=?,aciklama=?,aktif=? WHERE id=?")
           ->execute([$kod,$ad,trim($d['mamul_kodu']??'')||null,trim($d['versiyon']??'1.0'),(float)($d['miktar']??1),$d['birim']??'adet',trim($d['aciklama']??'')||null,(int)($d['aktif']??1),(int)$d['id']]);
    } else {
        $db->prepare("INSERT INTO receteler (kod,ad,mamul_kodu,versiyon,miktar,birim,aciklama,aktif) VALUES (?,?,?,?,?,?,?,?)")
           ->execute([$kod,$ad,trim($d['mamul_kodu']??'')||null,trim($d['versiyon']??'1.0'),(float)($d['miktar']??1),$d['birim']??'adet',trim($d['aciklama']??'')||null,(int)($d['aktif']??1)]);
    }
    echo json_encode(['ok'=>true]);
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
