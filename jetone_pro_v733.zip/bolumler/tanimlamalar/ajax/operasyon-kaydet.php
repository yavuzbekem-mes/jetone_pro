<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$d = json_decode(file_get_contents('php://input'), true) ?: [];
$islem = $d['islem'] ?? '';
try {
    if ($islem === 'sil') { $db->prepare("DELETE FROM operasyonlar WHERE id=?")->execute([(int)$d['id']]); echo json_encode(['ok'=>true]); exit; }
    $kod = trim($d['kod']??''); $ad = trim($d['ad']??'');
    if (!$kod || !$ad) { echo json_encode(['ok'=>false,'hata'=>'Kod ve ad zorunlu']); exit; }
    if ($islem === 'guncelle') {
        $db->prepare("UPDATE operasyonlar SET kod=?,ad=?,tip=?,sure_dk=?,birim_maliyet=?,aciklama=?,aktif=? WHERE id=?")
           ->execute([$kod,$ad,$d['tip']??'uretim',(float)($d['sure_dk']??0),(float)($d['birim_maliyet']??0),trim($d['aciklama']??'')||null,(int)($d['aktif']??1),(int)$d['id']]);
    } else {
        $db->prepare("INSERT INTO operasyonlar (kod,ad,tip,sure_dk,birim_maliyet,aciklama,aktif) VALUES (?,?,?,?,?,?,?)")
           ->execute([$kod,$ad,$d['tip']??'uretim',(float)($d['sure_dk']??0),(float)($d['birim_maliyet']??0),trim($d['aciklama']??'')||null,(int)($d['aktif']??1)]);
    }
    echo json_encode(['ok'=>true]);
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
