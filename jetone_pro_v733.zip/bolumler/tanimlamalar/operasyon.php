<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();

// Filtreler
$f_arama   = trim($_GET['arama'] ?? '');
$f_malzeme = trim($_GET['malzeme'] ?? '');
$f_ist     = trim($_GET['ist'] ?? '');

$operasyonlar = [];
$hata = '';
$tiger_ok = ($tigerdb_pdo !== null);

if ($tiger_ok) {
    try {
        $sqlsrv_sql = "SELECT TOP (1000000)
            IT.CODE  AS malzeme_kod,
            IT.NAME  AS malzeme_adi,
            OP.CODE  AS operasyon_kodu,
            WRK.CODE AS is_ist_kodu,
            WRK.NAME AS is_ist_adi,
            dbo.LG_INTTOTIME2(OPR.RUNTIME) AS proses_cevrimi,
            OPR.BATCHQUANTITY AS parti_buyuklugu
        FROM dbo.LG_222_OPRTREQ AS OPR
        LEFT OUTER JOIN dbo.LG_222_OPERTION AS OP  ON OP.LOGICALREF  = OPR.OPERATIONREF
        LEFT OUTER JOIN dbo.LG_222_WORKSTAT AS WRK ON WRK.LOGICALREF = OPR.WSREF
        LEFT OUTER JOIN dbo.LG_222_RTNGLINE AS RTL ON RTL.OPERATIONREF = OP.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_ROUTING  AS RT  ON RT.LOGICALREF  = RTL.ROUTINGREF
        LEFT OUTER JOIN dbo.LG_222_BOMREVSN AS BMR ON BMR.ROUTINGREF = RT.LOGICALREF
        LEFT OUTER JOIN dbo.LG_222_BOMASTER AS BOM ON BOM.LOGICALREF = BMR.BOMMASTERREF
        LEFT OUTER JOIN dbo.LG_222_BOMLINE  AS BML ON BMR.LOGICALREF = BML.BOMREVREF
        LEFT OUTER JOIN dbo.LG_222_ITEMS    AS IT  ON IT.LOGICALREF  = BOM.MAINPRODREF
        WHERE (OP.CODE <> 'SKOP.001')
          AND (IT.CODE IS NOT NULL)
          AND (IT.CODE NOT LIKE 'H-%')
          AND (BML.LINETYPE <> 4)
        GROUP BY IT.CODE, IT.NAME, WRK.CODE, WRK.NAME, OPR.RUNTIME, OPR.BATCHQUANTITY,
                 OP.LOGICALREF, OP.CODE, IT.SPECODE, IT.SPECODE2
        ORDER BY IT.CODE";

        $stmt = $tigerdb_pdo->query($sqlsrv_sql);
        $all  = $stmt->fetchAll();

        // PHP tarafında filtrele
        foreach ($all as $row) {
            if ($f_arama) {
                $hay = strtolower(($row['malzeme_kod']??'').' '.($row['malzeme_adi']??'').' '.($row['operasyon_kodu']??''));
                if (strpos($hay, strtolower($f_arama)) === false) continue;
            }
            if ($f_malzeme && ($row['malzeme_kod']??'') !== $f_malzeme) continue;
            if ($f_ist     && ($row['is_ist_kodu']??'') !== $f_ist)     continue;
            $operasyonlar[] = $row;
        }

        // Filtre seçenekleri için unique listeler
        $malzemeler_list = array_unique(array_column($all, 'malzeme_kod'));
        $istasyonlar_list = array_unique(array_column($all, 'is_ist_kodu'));
        sort($malzemeler_list); sort($istasyonlar_list);

    } catch (Throwable $e) {
        $hata = 'Tiger DB sorgu hatası: ' . $e->getMessage();
    }
} else {
    // baglanlogo.php'den hata mesajını al
    global $tigerdb_hata;
    $hata = 'Tiger DB bağlantısı kurulamadı. ';
    // entegrasyonlar tablosundan kontrol et
    try {
        $chk = $db->query("SELECT aktif, son_test_mesaji, host FROM entegrasyonlar WHERE kod='logo_tiger' LIMIT 1")->fetch();
        if (!$chk) $hata .= 'Kayıt bulunamadı (logo_tiger entegrasyonu tanımlı değil).';
        elseif (!$chk['aktif']) $hata .= 'Entegrasyon pasif durumda (aktif=0). Entegrasyonlar sayfasından aktifleştirin.';
        else $hata .= 'Bağlantı başarısız. Son mesaj: '.($chk['son_test_mesaji']??'—').' | Host: '.($chk['host']??'—');
    } catch(Throwable $ex) { $hata .= $ex->getMessage(); }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">⚙️ Operasyon Tanımları</h1>
    <div class="s-yol">Tanımlamalar / <b>Operasyonlar</b>
      <?php if ($tiger_ok): ?>
        <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
        <span style="font-size:11px;color:var(--m2);margin-left:4px">(<?php echo number_format(count($operasyonlar)); ?> kayıt)</span>
      <?php else: ?>
        <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px 18px;border-radius:10px;margin-bottom:14px;display:flex;align-items:center;gap:10px">
  <span style="font-size:20px">⚠️</span>
  <div>
    <div style="font-weight:700;margin-bottom:2px">Bağlantı Hatası</div>
    <div style="font-size:13px"><?php echo htmlspecialchars($hata); ?></div>
    <a href="?sayfa=ayarlar-entegrasyonlar" style="font-size:12px;color:#991B1B;font-weight:600;margin-top:4px;display:inline-block">→ Entegrasyon Ayarlarına Git</a>
  </div>
</div>
<?php endif; ?>

<?php if ($tiger_ok): ?>
<!-- Filtreler -->
<form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
  <input type="hidden" name="sayfa" value="tanim-operasyon">
  <input type="text" name="arama" value="<?php echo htmlspecialchars($f_arama); ?>" class="form-alan" style="width:200px" placeholder="🔍 Malzeme kodu, ad, operasyon...">
  <select name="malzeme" class="form-alan" style="width:180px" onchange="this.form.submit()">
    <option value="">Tüm Malzemeler</option>
    <?php foreach(($malzemeler_list??[]) as $m): ?>
    <option value="<?php echo htmlspecialchars($m); ?>" <?php echo $f_malzeme===$m?'selected':''; ?>><?php echo htmlspecialchars($m); ?></option>
    <?php endforeach; ?>
  </select>
  <select name="ist" class="form-alan" style="width:160px" onchange="this.form.submit()">
    <option value="">Tüm İş İstasyonları</option>
    <?php foreach(($istasyonlar_list??[]) as $i): ?>
    <option value="<?php echo htmlspecialchars($i); ?>" <?php echo $f_ist===$i?'selected':''; ?>><?php echo htmlspecialchars($i); ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <button type="button" onclick="dtExcelIndir('tbl-operasyon','OperasyonTanimlari')" style="background:#217346;color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
  <?php if($f_arama||$f_malzeme||$f_ist): ?>
  <a href="?sayfa=tanim-operasyon" style="padding:8px 12px;background:#F3F4F6;color:#374151;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">✕ Temizle</a>
  <?php endif; ?>
</form>

<div class="kart" style="overflow:hidden">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 270px)">
  <table class="tablo" id="tbl-operasyon" style="min-width:900px">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th>Malzeme Kodu</th>
        <th>Malzeme Adı</th>
        <th style="width:120px">Operasyon Kodu</th>
        <th style="width:110px">İş İst. Kodu</th>
        <th>İş İstasyonu Adı</th>
        <th style="width:110px;text-align:center">Proses Çevrimi</th>
        <th style="width:100px;text-align:right">Parti Büyüklüğü</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($operasyonlar)): ?>
    <tr><td colspan="7" style="text-align:center;padding:30px;color:var(--m2)">
      <?php echo $f_arama||$f_malzeme||$f_ist ? 'Filtreye uyan kayıt bulunamadı.' : 'Veri bulunamadı.'; ?>
    </td></tr>
    <?php else: foreach ($operasyonlar as $r): ?>
    <tr>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-weight:700;color:var(--t);font-size:11px"><?php echo htmlspecialchars($r['malzeme_kod']??''); ?></code></td>
      <td style="font-size:12px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?php echo htmlspecialchars($r['malzeme_adi']??''); ?>">
        <?php echo htmlspecialchars($r['malzeme_adi']??'—'); ?>
      </td>
      <td><span style="background:#EDE9FE;color:#5B21B6;font-size:11px;font-weight:700;padding:2px 7px;border-radius:10px"><?php echo htmlspecialchars($r['operasyon_kodu']??''); ?></span></td>
      <td style="font-size:12px;font-weight:700;color:var(--t)"><?php echo htmlspecialchars($r['is_ist_kodu']??''); ?></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($r['is_ist_adi']??''); ?></td>
      <td style="text-align:center;font-family:monospace;font-weight:700;font-size:12px"><?php echo htmlspecialchars($r['proses_cevrimi']??'—'); ?></td>
      <td style="text-align:right;font-size:12px;font-weight:600"><?php echo $r['parti_buyuklugu'] ? number_format((float)$r['parti_buyuklugu'],0,',','.') : '—'; ?></td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  
    <tfoot><tr><th>Malzeme Kodu</th><th>Malzeme Adı</th><th>Operasyon Kodu</th><th>İş İst. Kodu</th><th>İş İstasyonu Adı</th><th>Proses Çevrimi</th><th>Parti Büyüklüğü</th></tr></tfoot>
  </table>
  </div>
</div>
<?php endif; ?>
</div>

<script>
$(document).ready(function(){
  if($.fn.DataTable.isDataTable('#tbl-operasyon'))return;
  var tbl = $('#tbl-operasyon').DataTable({
    paging:false,
    scrollX:true,
    scrollY:'580px',
    scrollCollapse:true,
    order:[[0,"asc"]],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'tbl-operasyon'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>

