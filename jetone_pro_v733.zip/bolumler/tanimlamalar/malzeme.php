<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

// Filtreler
$f_arama  = trim($_GET['arama'] ?? '');
$f_tur    = trim($_GET['tur'] ?? '');
$f_firma  = trim($_GET['firma'] ?? '');
$f_group  = trim($_GET['grp'] ?? '');

$malzemeler = []; $toplam = 0;
$firmalar = []; $gruplar = []; $turler = [];

try {
    $where = ['1=1']; $params = [];
    if ($f_arama) { $where[] = '(malzeme_kod LIKE ? OR malzeme_ad LIKE ?)'; $params[] = "%$f_arama%"; $params[] = "%$f_arama%"; }
    if ($f_tur)   { $where[] = 'malzeme_tur=?';   $params[] = $f_tur; }
    if ($f_firma) { $where[] = 'malzeme_firma=?';  $params[] = $f_firma; }
    if ($f_group) { $where[] = 'malzeme_group=?';  $params[] = $f_group; }
    $w = implode(' AND ', $where);

    $cnt = $db->prepare("SELECT COUNT(*) FROM malzeme_tanimlari WHERE $w");
    $cnt->execute($params); $toplam = (int)$cnt->fetchColumn();

    $q = $db->prepare("SELECT * FROM malzeme_tanimlari WHERE $w ORDER BY malzeme_firma, malzeme_kod");
    $q->execute($params); $malzemeler = $q->fetchAll();

    $firmalar = $db->query("SELECT DISTINCT malzeme_firma FROM malzeme_tanimlari WHERE malzeme_firma IS NOT NULL ORDER BY malzeme_firma")->fetchAll(PDO::FETCH_COLUMN);
    $gruplar  = $db->query("SELECT DISTINCT malzeme_group FROM malzeme_tanimlari WHERE malzeme_group IS NOT NULL ORDER BY malzeme_group")->fetchAll(PDO::FETCH_COLUMN);
    $turler   = $db->query("SELECT DISTINCT malzeme_tur FROM malzeme_tanimlari WHERE malzeme_tur IS NOT NULL ORDER BY malzeme_tur")->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e){ $hata = $e->getMessage(); }


$tur_cfg = [
    'MM'=>['Mamül','#D1FAE5','#065F46'],
    'YM'=>['Yarı Mamül','#DBEAFE','#1E40AF'],
    'HM'=>['Yardımcı Malzeme','#FEF3C7','#92400E'],
];
?>
<div class="s-bar">
  <div><h1 class="s-bas">🧱 Malzeme Tanımları</h1><div class="s-yol">Tanımlamalar / <b>Malzemeler</b> <span style="font-size:11px;color:var(--m2)">(<?php echo number_format($toplam); ?> kayıt)</span></div></div>
  <button onclick="modalAc()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit">+ Yeni Malzeme</button>
</div>

<div class="s-body">
<?php if (!empty($hata)): ?><div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata); ?></div><?php endif; ?>

<!-- Filtreler -->
<form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
  <input type="hidden" name="sayfa" value="tanim-malzeme">
  <input type="text" name="arama" value="<?php echo htmlspecialchars($f_arama); ?>" class="form-alan" style="width:180px" placeholder="🔍 Kod veya ad...">
  <select name="tur" class="form-alan" style="width:140px" onchange="this.form.submit()">
    <option value="">Tüm Türler</option>
    <?php foreach($turler as $t): ?><option value="<?php echo htmlspecialchars($t); ?>" <?php echo $f_tur===$t?'selected':''; ?>><?php echo htmlspecialchars($t); ?></option><?php endforeach; ?>
  </select>
  <select name="firma" class="form-alan" style="width:150px" onchange="this.form.submit()">
    <option value="">Tüm Firmalar</option>
    <?php foreach($firmalar as $f): ?><option value="<?php echo htmlspecialchars($f); ?>" <?php echo $f_firma===$f?'selected':''; ?>><?php echo htmlspecialchars($f); ?></option><?php endforeach; ?>
  </select>
  <select name="grp" class="form-alan" style="width:140px" onchange="this.form.submit()">
    <option value="">Tüm Gruplar</option>
    <?php foreach($gruplar as $g): ?><option value="<?php echo htmlspecialchars($g); ?>" <?php echo $f_group===$g?'selected':''; ?>><?php echo htmlspecialchars($g); ?></option><?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <button type="button" onclick="dtExcelIndir('tbl-malzeme','MalzemeTanimlari')" style="background:#217346;color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
  <?php if($f_arama||$f_tur||$f_firma||$f_group): ?>
  <a href="?sayfa=tanim-malzeme" style="padding:8px 12px;background:#F3F4F6;color:#374151;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">✕ Temizle</a>
  <?php endif; ?>
</form>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
  <div style="overflow-y:auto;max-height:calc(100vh - 270px)">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 290px)"><table class="tablo" id="tbl-malzeme" style="font-size:12px">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="width:50px">ID</th>
        <th>Malzeme Kodu</th>
        <th>Ad</th>
        <th style="width:60px">Tür</th>
        <th style="width:80px">Grup</th>
        <th style="width:100px">Firma</th>
        <th style="width:55px;text-align:center">Birim</th>
        <th style="width:65px;text-align:right">Stok</th>
        <th style="width:65px;text-align:right">Tonaj</th>
        <th style="width:60px;text-align:right">Gramaj</th>
        <th style="width:55px;text-align:right">Çevrim</th>
        <th style="width:55px;text-align:center">Ambalaj</th>
        <th style="width:65px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php if(empty($malzemeler)): ?>
    <tr><td colspan="13" style="text-align:center;padding:30px;color:var(--m2)">Kayıt bulunamadı.</td></tr>
    <?php else: foreach($malzemeler as $m):
      $tc = $tur_cfg[$m['malzeme_tur']] ?? [$m['malzeme_tur']??'—','#F3F4F6','#374151'];
    ?>
    <tr>
      <td style="color:var(--m2)"><?php echo $m['malzeme_id']; ?></td>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-weight:700;color:var(--t);font-size:11px"><?php echo htmlspecialchars($m['malzeme_kod']??'—'); ?></code></td>
      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?php echo htmlspecialchars($m['malzeme_ad']??''); ?>">
        <span style="font-weight:600"><?php echo htmlspecialchars(mb_substr($m['malzeme_ad']??'—',0,50)); ?></span>
      </td>
      <td><span style="background:<?php echo $tc[1]; ?>;color:<?php echo $tc[2]; ?>;font-size:10px;font-weight:700;padding:1px 5px;border-radius:10px"><?php echo htmlspecialchars($m['malzeme_tur']??'—'); ?></span></td>
      <td style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($m['malzeme_group']??''); ?></td>
      <td style="font-size:11px;font-weight:600"><?php echo htmlspecialchars($m['malzeme_firma']??''); ?></td>
      <td style="text-align:center"><?php echo htmlspecialchars($m['malzeme_birim']??''); ?></td>
      <td style="text-align:right;color:<?php echo ($m['malzeme_stok']&&(float)$m['malzeme_stok']>0)?'#065F46':'var(--m2)'; ?>;font-weight:600"><?php echo $m['malzeme_stok']??'—'; ?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo $m['map_makina_tonaj']??''; ?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo $m['map_gramaj']??''; ?></td>
      <td style="text-align:right;color:var(--m2)"><?php echo $m['map_cevrim']??''; ?></td>
      <td style="text-align:center;font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($m['malzeme_ambalaj']??''); ?></td>
      <td style="text-align:center"><div style="display:flex;gap:3px;justify-content:center">
        <button onclick="duzenle(<?php echo htmlspecialchars(json_encode([
          'id'=>$m['malzeme_id'],'tur'=>$m['malzeme_tur']??'','group'=>$m['malzeme_group']??'',
          'firma'=>$m['malzeme_firma']??'','kod'=>$m['malzeme_kod']??'','ad'=>$m['malzeme_ad']??'',
          'birim'=>$m['malzeme_birim']??'ADET','stok'=>$m['malzeme_stok']??'',
          'tonaj'=>$m['map_makina_tonaj']??'','gramaj'=>$m['map_gramaj']??'',
          'cevrim'=>$m['map_cevrim']??'','paket'=>$m['paket_miktari']??'',
          'taban'=>$m['taban_miktari']??'','ambalaj'=>$m['malzeme_ambalaj']??'',
        ],JSON_UNESCAPED_UNICODE)); ?>)" style="background:#EFF6FF;color:#1D4ED8;border:none;width:24px;height:24px;border-radius:4px;cursor:pointer;font-size:11px">✏️</button>
        <button onclick="sil(<?php echo $m['malzeme_id']; ?>)" style="background:#FEE2E2;color:#EF4444;border:none;width:24px;height:24px;border-radius:4px;cursor:pointer;font-size:11px">🗑</button>
      </div></td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  
    <tfoot><tr><th>ID</th><th>Malzeme Kodu</th><th>Ad</th><th>Tür</th><th>Grup</th><th>Firma</th><th>Birim</th><th>Stok</th><th>Tonaj</th><th>Gramaj</th><th>Çevrim</th><th>Ambalaj</th><th>İşlem</th></tr></tfoot>
  </table></div>
</div>
</div>

</div>

<!-- Modal -->
<div id="malzModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.97);backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:600px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.25)">
    <div style="display:flex;justify-content:space-between;margin-bottom:16px">
      <div style="font-size:15px;font-weight:800" id="malzBaslik">🧱 Yeni Malzeme</div>
      <button onclick="document.getElementById('malzModal').style.display='none'" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:30px;height:30px;cursor:pointer">✕</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <input type="hidden" id="malzId">
      <div><label class="form-etiket">Malzeme Kodu</label><input type="text" id="fKod" class="form-alan" placeholder="2137000377"></div>
      <div style="grid-column:1/-1"><label class="form-etiket">Malzeme Adı *</label><input type="text" id="fAd" class="form-alan"></div>
      <div><label class="form-etiket">Tür (MM/YM/HM)</label><select id="fTur" class="form-alan">
        <option value="">— Seçin —</option>
        <option value="MM">MM — Mamül</option>
        <option value="YM">YM — Yarı Mamül</option>
        <option value="HM">HM — Yardımcı Malzeme</option>
      </select></div>
      <div><label class="form-etiket">Grup</label><select id="fGroup" class="form-alan">
        <option value="">— Seçin —</option>
        <option value="Mamül">Mamül</option>
        <option value="Yarımamül">Yarımamül</option>
        <option value="Yard. Malzeme">Yardımcı Malzeme</option>
        <option value="Yarı Mamül">Yarı Mamül</option>
      </select></div>
      <div><label class="form-etiket">Firma</label><input type="text" id="fFirma" class="form-alan" placeholder="ARÇELİK, BSH..."></div>
      <div><label class="form-etiket">Birim</label><select id="fBirim" class="form-alan">
        <?php foreach(['ADET','KG','TON','LT','M','M²','M³','TAKIM','KUTU','RULO'] as $b): ?><option><?php echo $b; ?></option><?php endforeach; ?>
      </select></div>
      <div><label class="form-etiket">Stok</label><input type="text" id="fStok" class="form-alan" placeholder="12345"></div>
      <div><label class="form-etiket">Makina Tonajı</label><select id="fTonaj" class="form-alan">
        <option value="">— Seçin —</option>
        <?php foreach(['80','130','160','200','300','350','420','450','500','650','700','850'] as $t): ?><option value="<?php echo $t; ?>"><?php echo $t; ?></option><?php endforeach; ?>
      </select></div>
      <div><label class="form-etiket">Gramaj</label><input type="text" id="fGramaj" class="form-alan" placeholder="10,4"></div>
      <div><label class="form-etiket">Çevrim</label><input type="text" id="fCevrim" class="form-alan" placeholder="35"></div>
      <div><label class="form-etiket">Paket Miktarı</label><input type="text" id="fPaket" class="form-alan"></div>
      <div><label class="form-etiket">Taban Miktarı</label><input type="text" id="fTaban" class="form-alan"></div>
      <div><label class="form-etiket">Ambalaj</label><select id="fAmbalaj" class="form-alan">
        <option value="">— Seçin —</option>
        <option value="K-550">K-550</option>
        <option value="EUROBOX MAVİ KASA">EUROBOX MAVİ KASA</option>
        <option value="PP SEPARATÖR">PP SEPARATÖR</option>
        <option value="KOLİ">KOLİ</option>
        <option value="POŞET">POŞET</option>
        <option value="KATLANIR KASA">KATLANIR KASA</option>
        <option value="KÜÇÜK KASA">KÜÇÜK KASA</option>
      </select></div>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
      <button onclick="document.getElementById('malzModal').style.display='none'" style="padding:10px 18px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
      <button onclick="kaydet()" id="malzBtn" style="padding:10px 22px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">💾 Kaydet</button>
    </div>
  </div>
</div>

<script>
var AJAX='<?php echo BASE_URL; ?>/bolumler/tanimlamalar/ajax/malzeme-kaydet.php';
var EKLEYEN='<?php echo addslashes($user['ad_soyad']??''); ?>';

function modalAc(){
  document.getElementById('malzId').value='';
  ['fKod','fAd','fGroup','fFirma','fStok','fTonaj','fGramaj','fCevrim','fPaket','fTaban','fAmbalaj'].forEach(function(i){document.getElementById(i).value='';});
  document.getElementById('fTur').value='';document.getElementById('fBirim').value='ADET';
  document.getElementById('malzBaslik').textContent='🧱 Yeni Malzeme';
  document.getElementById('malzModal').style.display='flex';
}
function duzenle(m){
  document.getElementById('malzId').value=m.id;
  document.getElementById('fKod').value=m.kod||'';
  document.getElementById('fAd').value=m.ad||'';
  document.getElementById('fTur').value=m.tur||'';
  var grpEl=document.getElementById('fGroup');
  if(grpEl.tagName==='SELECT'){grpEl.value=m.group||'';}else{grpEl.value=m.group||'';}
  document.getElementById('fFirma').value=m.firma||'';
  document.getElementById('fBirim').value=m.birim||'ADET';
  document.getElementById('fStok').value=m.stok||'';
  var tonajEl=document.getElementById('fTonaj');
  tonajEl.value=m.tonaj||'';
  document.getElementById('fGramaj').value=m.gramaj||'';
  document.getElementById('fCevrim').value=m.cevrim||'';
  document.getElementById('fPaket').value=m.paket||'';
  document.getElementById('fTaban').value=m.taban||'';
  document.getElementById('fAmbalaj').value=m.ambalaj||'';
  document.getElementById('malzBaslik').textContent='✏️ Malzeme Düzenle';
  document.getElementById('malzModal').style.display='flex';
}
function kaydet(){
  var ad=document.getElementById('fAd').value.trim();
  if(!ad){alert('Malzeme adı zorunlu');return;}
  var btn=document.getElementById('malzBtn');btn.disabled=true;btn.textContent='Kaydediliyor...';
  var d={
    islem:document.getElementById('malzId').value?'guncelle':'ekle',
    id:document.getElementById('malzId').value,
    tur:document.getElementById('fTur').value,
    group:document.getElementById('fGroup').value.trim(),
    firma:document.getElementById('fFirma').value.trim(),
    kod:document.getElementById('fKod').value.trim(),
    ad:ad,
    birim:document.getElementById('fBirim').value,
    stok:document.getElementById('fStok').value.trim(),
    tonaj:document.getElementById('fTonaj').value.trim(),
    gramaj:document.getElementById('fGramaj').value.trim(),
    cevrim:document.getElementById('fCevrim').value.trim(),
    paket:document.getElementById('fPaket').value.trim(),
    taban:document.getElementById('fTaban').value.trim(),
    ambalaj:document.getElementById('fAmbalaj').value.trim(),
    ekleyen:EKLEYEN
  };
  fetch(AJAX,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)})
  .then(function(r){return r.json();})
  .then(function(r){
    if(r.ok)location.reload();
    else{alert('Hata: '+(r.hata||'?'));btn.disabled=false;btn.textContent='💾 Kaydet';}
  }).catch(function(){alert('Bağlantı hatası');btn.disabled=false;btn.textContent='💾 Kaydet';});
}
function sil(id){
  if(!confirm('Bu malzeme silinsin mi?'))return;
  fetch(AJAX,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({islem:'sil',id:id})})
  .then(function(r){return r.json();})
  .then(function(r){if(r.ok)location.reload();else alert('Hata: '+(r.hata||'?'));});
}
</script>

<script>
$(document).ready(function(){
  if($.fn.DataTable.isDataTable('#tbl-malzeme'))return;
  var tbl = $('#tbl-malzeme').DataTable({
    paging:false,
    scrollX:true,
    scrollY:'580px',
    scrollCollapse:true,
    order:[[0,"asc"]],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'tbl-malzeme'},
      {extend:'print',text:'🖨 Yazdır',className:'btn-dt'}
    ],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(){
        var col=this;
        var th=$(col.footer());
        if(!th||!th.length)return;
        var label=th.text().trim();
        if(!label||label==='İşlem'||label==='#'){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'',true,false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'…':v)+'</option>');
        });
      });
    }
  });
});
</script>

