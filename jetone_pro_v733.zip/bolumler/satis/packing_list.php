<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();

// Filtreler
$search      = $_GET['search']   ?? '';
$sf          = $_GET['status']   ?? '';
$date_from   = $_GET['date_from']?? '';
$date_to     = $_GET['date_to']  ?? '';

$where = []; $params = [];
if ($search) {
    $where[] = "(packing_no LIKE ? OR irsaliye_no LIKE ? OR customer_name LIKE ?)";
    $params  = array_merge($params, ["%$search%","%$search%","%$search%"]);
}
if ($sf)        { $where[] = "status = ?";         $params[] = $sf; }
if ($date_from) { $where[] = "packing_date >= ?";  $params[] = $date_from; }
if ($date_to)   { $where[] = "packing_date <= ?";  $params[] = $date_to; }

$wsql   = $where ? 'WHERE '.implode(' AND ', $where) : '';
$stmt   = $db->prepare("SELECT * FROM packing_lists $wsql ORDER BY created_at DESC");
$stmt->execute($params);
$lists  = $stmt->fetchAll(PDO::FETCH_ASSOC);

$status_tr = ['draft'=>'Taslak','confirmed'=>'Onaylandı','shipped'=>'Sevk Edildi','completed'=>'Tamamlandı'];
$status_cls= ['draft'=>'#6B7280','confirmed'=>'#1D4ED8','shipped'=>'#D97706','completed'=>'#059669'];
?>
<style>
#plTbl th{background:#1E3A5F!important;color:#fff!important;}
#plTbl td,#plTbl th{border:1px solid #000!important;white-space:nowrap!important}
.pl-badge{padding:2px 10px;border-radius:50px;font-size:11px;font-weight:700;color:#fff;display:inline-block}
.pl-btn{padding:3px 7px;border:none;border-radius:4px;cursor:pointer;font-size:12px;color:#fff;margin:1px}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📦 Packing List Yönetimi</h1>
    <div class="s-yol">Satış / <b>Sevkiyat Listesi</b></div>
  </div>
  <button onclick="plYeni()" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
    ➕ Yeni Packing List
  </button>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <input type="hidden" name="sayfa" value="satis-packing-list">
    <div><label class="form-etiket">Arama</label><input type="text" class="form-alan" name="search" value="<?php echo htmlspecialchars($search);?>" placeholder="Packing No / İrsaliye / Firma" style="width:200px"></div>
    <div><label class="form-etiket">Durum</label>
      <select class="form-alan" name="status">
        <option value="">Tümü</option>
        <?php foreach($status_tr as $k=>$v):?><option value="<?php echo $k;?>" <?php echo $sf==$k?'selected':'';?>><?php echo $v;?></option><?php endforeach;?>
      </select>
    </div>
    <div><label class="form-etiket">Başlangıç</label><input type="date" class="form-alan" name="date_from" value="<?php echo $date_from;?>"></div>
    <div><label class="form-etiket">Bitiş</label><input type="date" class="form-alan" name="date_to" value="<?php echo $date_to;?>"></div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Filtrele</button>
    <a href="?sayfa=satis-packing-list" style="background:#6B7280;color:#fff;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<table id="plTbl" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Packing No</th><th>İrsaliye No</th><th>Tarih</th><th>Firma</th>
      <th>Paket</th><th>Net Ağırlık</th><th>Durum</th><th>İşlemler</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Packing No</th><th>İrsaliye No</th><th>Tarih</th><th>Firma</th>
      <th>Paket</th><th>Net Ağırlık</th><th>Durum</th><th></th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($lists as $r):?>
  <tr>
    <td><b><?php echo htmlspecialchars($r['packing_no']);?></b></td>
    <td><?php echo htmlspecialchars($r['irsaliye_no']);?></td>
    <td><?php echo date('d.m.Y',strtotime($r['packing_date']));?></td>
    <td><?php echo htmlspecialchars($r['customer_name']);?></td>
    <td style="text-align:center"><?php echo $r['total_packets'];?></td>
    <td style="text-align:right"><?php echo number_format($r['total_net_weight'],2,'.',',');?> kg</td>
    <td><span class="pl-badge" style="background:<?php echo $status_cls[$r['status']]??'#6B7280';?>"><?php echo $status_tr[$r['status']]??$r['status'];?></span></td>
    <td>
      <button class="pl-btn" style="background:#3B82F6" onclick="plGoruntule(<?php echo $r['id'];?>)" title="Görüntüle">👁</button>
      <?php if($r['status']==='draft'):?>
      <button class="pl-btn" style="background:#059669" onclick="plDuzenle(<?php echo $r['id'];?>)" title="Düzenle">✏️</button>
      <?php endif;?>
      <button class="pl-btn" style="background:#7C3AED" onclick="plYazdir(<?php echo $r['id'];?>)" title="Yazdır">🖨</button>
      <button class="pl-btn" style="background:#28A745" onclick="plPaletEtiketi(<?php echo $r['id'];?>)" title="Palet Etiketleri">🏷</button>
      <button class="pl-btn" style="background:#6366F1" onclick="plOzetRapor(<?php echo $r['id'];?>)" title="Özet Raporu">📋</button>
      <button class="pl-btn" style="background:#16A34A" onclick="plExcel(<?php echo $r['id'];?>)" title="Excel">📊</button>
      <select onchange="plDurumGuncelle(<?php echo $r['id'];?>,this.value)" style="font-size:11px;padding:2px 4px;border-radius:4px;border:1px solid #ccc;cursor:pointer">
        <?php foreach($status_tr as $k=>$v):?><option value="<?php echo $k;?>" <?php echo $r['status']==$k?'selected':'';?>><?php echo $v;?></option><?php endforeach;?>
      </select>
      <?php if($r['status']==='draft'):?>
      <button class="pl-btn" style="background:#DC2626" onclick="plSil(<?php echo $r['id'];?>)" title="Sil">🗑</button>
      <?php endif;?>
    </td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($lists)):?>
  <tr><td colspan="8" style="text-align:center;padding:30px;color:#888">Kayıt bulunamadı.</td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>

<!-- MODAL -->
<div id="plModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:1000;overflow-y:auto">
  <div style="background:#fff;margin:20px auto;max-width:98%;border-radius:10px;overflow:hidden">
    <div style="background:#1E3A5F;color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center">
      <h3 id="plModalBaslik" style="margin:0;font-size:16px">Yeni Packing List</h3>
      <button onclick="plModalKapat()" style="background:none;border:none;color:#fff;font-size:24px;cursor:pointer">×</button>
    </div>
    <div style="padding:16px">
      <input type="hidden" id="plId">
      <!-- Genel + Araç -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div class="kart" style="padding:12px">
          <div style="font-weight:700;font-size:12px;color:#1E3A5F;margin-bottom:8px">📋 Genel Bilgiler</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <div><label class="form-etiket">İrsaliye No *</label><input type="text" id="pl_irsaliye" class="form-alan"></div>
            <div><label class="form-etiket">Müşteri Adı *</label><input type="text" id="pl_musteri" class="form-alan"></div>
            <div><label class="form-etiket">Tarih *</label><input type="date" id="pl_tarih" class="form-alan" value="<?php echo date('Y-m-d');?>"></div>
            <div><label class="form-etiket">Sipariş No</label><input type="text" id="pl_siparis_no" class="form-alan"></div>
            <div style="grid-column:span 2"><label class="form-etiket">Referans No</label><input type="text" id="pl_ref_no" class="form-alan"></div>
          </div>
        </div>
        <div class="kart" style="padding:12px">
          <div style="font-weight:700;font-size:12px;color:#1E3A5F;margin-bottom:8px">🚛 Araç Bilgileri</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <div><label class="form-etiket">Araç Plakası</label><input type="text" id="pl_kamyon" class="form-alan"></div>
            <div><label class="form-etiket">Römork Plakası</label><input type="text" id="pl_romork" class="form-alan"></div>
            <div><label class="form-etiket">Şoför Adı</label><input type="text" id="pl_sofor" class="form-alan"></div>
            <div><label class="form-etiket">Şoför Telefon</label><input type="text" id="pl_sofor_tel" class="form-alan"></div>
            <div style="grid-column:span 2"><label class="form-etiket">Özel Bilgi</label><textarea id="pl_ozel" class="form-alan" rows="2"></textarea></div>
          </div>
        </div>
      </div>
      <!-- Ürün Tablosu -->
      <div class="kart" style="padding:0;overflow:hidden;margin-bottom:12px">
        <div style="background:#1E3A5F;color:#fff;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:700;font-size:12px">📦 Ürün Listesi</span>
          <button onclick="plSatirEkle()" style="background:#16A34A;color:#fff;border:none;padding:4px 10px;border-radius:4px;font-size:12px;cursor:pointer">+ Satır Ekle</button>
        </div>
        <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead>
            <tr style="background:#374151;color:#fff">
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">#</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Palet No</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Paket Mik.</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Birim Mik.</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Toplam Mik.</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Sipariş No</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Article No</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Açıklama</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Brüt kg</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Ürün Kodu</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Renk</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Net kg</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">En (cm)</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Boy (cm)</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Yük. (cm)</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">m³</th>
              <th style="padding:5px 6px;border:1px solid #4B5563;white-space:nowrap">Sil</th>
            </tr>
          </thead>
          <tbody id="plSatirlar"></tbody>
        </table>
        </div>
      </div>
      <!-- Toplamlar -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:10px">
        <div><label class="form-etiket">Toplam Paket</label><input type="number" id="pl_top_paket" class="form-alan" readonly></div>
        <div><label class="form-etiket">Toplam Brüt (kg)</label><input type="number" id="pl_top_brut" class="form-alan" readonly></div>
        <div><label class="form-etiket">Toplam Net (kg)</label><input type="number" id="pl_top_net" class="form-alan" readonly></div>
        <div><label class="form-etiket">CBM (m³)</label><input type="number" id="pl_top_cbm" class="form-alan" readonly></div>
      </div>
    </div>
    <div style="padding:12px 16px;background:#F9FAFB;display:flex;justify-content:flex-end;gap:8px;border-top:1px solid #E5E7EB">
      <button onclick="plModalKapat()" style="background:#6B7280;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">İptal</button>
      <button id="plKaydetBtn" onclick="plKaydet()" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">💾 Kaydet</button>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
$(document).ready(function(){
  document.title='Packing List';
  $('#plTbl').DataTable({
    initComplete:function(){
      this.api().columns([0,1,2,3,6]).every(function(){
        var col=this,th=$(col.footer());
        if(!th||!th.length)return;
        var sel=$('<select class="filtre"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>29)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
    scrollCollapse:true,scrollY:500,paging:false,scrollX:true,
    order:[[0,'desc']],dom:'Bfrtip',
    buttons:['copyHtml5','excelHtml5','print']
  });
});

let plSatirSayac=0;
let plReadonly=false;

function plYeni(){
  plReadonly=false;
  // Önceki görüntülemeden kalan disabled'ları kaldır
  document.querySelectorAll('#plModal input,#plModal textarea,#plModal select').forEach(function(el){el.disabled=false;});
  // Toplam alanları readonly kalsın
  ['pl_top_paket','pl_top_brut','pl_top_net','pl_top_cbm'].forEach(function(id){document.getElementById(id).readOnly=true;});
  document.getElementById('plModalBaslik').textContent='Yeni Packing List';
  document.getElementById('plId').value='';
  document.getElementById('pl_irsaliye').value='';
  document.getElementById('pl_musteri').value='';
  document.getElementById('pl_tarih').value='<?php echo date("Y-m-d");?>';
  document.getElementById('pl_siparis_no').value='';
  document.getElementById('pl_ref_no').value='';
  document.getElementById('pl_kamyon').value='';
  document.getElementById('pl_romork').value='';
  document.getElementById('pl_sofor').value='';
  document.getElementById('pl_sofor_tel').value='';
  document.getElementById('pl_ozel').value='';
  document.getElementById('plSatirlar').innerHTML='';
  plSatirSayac=0;
  plSatirEkle();
  document.getElementById('plKaydetBtn').style.display='inline-block';
  document.getElementById('plModal').style.display='block';
}

function plGoruntule(id){
  plReadonly=true;
  document.getElementById('plKaydetBtn').style.display='none';
  plVeriYukle(id, 'Görüntüle');
}

function plDuzenle(id){
  plReadonly=false;
  document.querySelectorAll('#plModal input,#plModal textarea,#plModal select').forEach(function(el){el.disabled=false;});
  ['pl_top_paket','pl_top_brut','pl_top_net','pl_top_cbm'].forEach(function(i){var e=document.getElementById(i);if(e)e.readOnly=true;});
  document.getElementById('plKaydetBtn').style.display='inline-block';
  plVeriYukle(id,'Düzenle');
}

function plVeriYukle(id,mod){
  document.getElementById('plModalBaslik').textContent='Packing List '+mod+' #'+id;
  $.post('<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',{action:'get',id:id},function(r){
    if(!r.success){alert('Hata: '+r.message);return;}
    var d=r.data;
    document.getElementById('plId').value=d.id;
    document.getElementById('pl_irsaliye').value=d.irsaliye_no||'';
    document.getElementById('pl_musteri').value=d.customer_name||'';
    document.getElementById('pl_tarih').value=d.packing_date||'';
    document.getElementById('pl_siparis_no').value=d.order_number||'';
    document.getElementById('pl_ref_no').value=d.reference_number||'';
    document.getElementById('pl_kamyon').value=d.truck_plate||'';
    document.getElementById('pl_romork').value=d.trailer_plate||'';
    document.getElementById('pl_sofor').value=d.driver_name||'';
    document.getElementById('pl_sofor_tel').value=d.driver_phone||'';
    document.getElementById('pl_ozel').value=d.special_info||'';
    document.getElementById('plSatirlar').innerHTML='';
    plSatirSayac=0;
    if(d.items&&d.items.length>0){
      d.items.forEach(function(item){
        plSatirEkle();
        var tr=document.querySelector('#plSatirlar tr:last-child');
        tr.querySelector('[name="palet_no"]').value=item.palet_no||1;
        tr.querySelector('[name="packet_qty"]').value=item.packet_quantity||'';
        tr.querySelector('[name="unit_qty"]').value=item.unit_quantity||'';
        tr.querySelector('[name="total_qty"]').value=item.total_quantity||'';
        tr.querySelector('[name="order_no"]').value=item.order_number||'';
        tr.querySelector('[name="article_no"]').value=item.article_no||'';
        tr.querySelector('[name="desc"]').value=item.description||'';
        tr.querySelector('[name="brut_kg"]').value=item.brut_weight||'';
        tr.querySelector('[name="prod_code"]').value=item.product_code||'';
        tr.querySelector('[name="colour"]').value=item.colour||'';
        tr.querySelector('[name="net_kg"]').value=item.net_weight||'';
        tr.querySelector('[name="width"]').value=item.width||100;
        tr.querySelector('[name="length"]').value=item.length||120;
        tr.querySelector('[name="height"]').value=item.height||230;
        plM3Hesapla(tr.querySelector('[name="width"]'));
      });
    } else { plSatirEkle(); }
    if(plReadonly){
      document.querySelectorAll('#plModal input,#plModal textarea,#plModal select:not([onchange*="plDurum"])').forEach(function(el){el.disabled=true;});
    }
    plToplamHesapla();
    document.getElementById('plModal').style.display='block';
  },'json').fail(function(){alert('Sunucu hatası');});
}

function plModalKapat(){
  document.getElementById('plModal').style.display='none';
}

function plSatirEkle(){
  plSatirSayac++;
  var n=plSatirSayac;
  var tr=document.createElement('tr');
  tr.innerHTML=`
    <td style="padding:3px 5px;border:1px solid #E2E8F0;text-align:center">${n}</td>
    <td style="padding:1px;min-width:55px"><input type="number" name="palet_no" value="${n}" class="form-alan" style="width:100%;min-width:50px;box-sizing:border-box" min="1"></td>
    <td style="padding:1px;min-width:75px"><input type="number" name="packet_qty" class="form-alan" style="width:100%;min-width:70px;box-sizing:border-box" oninput="plToplamHesapla()"></td>
    <td style="padding:1px;min-width:75px"><input type="number" name="unit_qty" class="form-alan" style="width:100%;min-width:70px;box-sizing:border-box" oninput="plToplamHesapla()"></td>
    <td style="padding:1px;min-width:85px"><input type="number" name="total_qty" class="form-alan" style="width:100%;min-width:80px;box-sizing:border-box" oninput="plToplamHesapla()" ondblclick="plOtoToplam(this)" title="Çift tık: otomatik hesapla"></td>
    <td style="padding:1px;min-width:100px"><input type="text" name="order_no" class="form-alan" style="width:100%;min-width:95px;box-sizing:border-box"></td>
    <td style="padding:1px;min-width:120px"><input type="text" name="article_no" class="form-alan" style="width:100%;min-width:115px;box-sizing:border-box"></td>
    <td style="padding:1px;min-width:200px"><input type="text" name="desc" class="form-alan" style="width:100%;min-width:195px;box-sizing:border-box"></td>
    <td style="padding:1px;min-width:80px"><input type="number" name="brut_kg" step="0.01" class="form-alan" style="width:100%;min-width:75px;box-sizing:border-box" oninput="plToplamHesapla()"></td>
    <td style="padding:1px;min-width:120px"><input type="text" name="prod_code" class="form-alan" style="width:100%;min-width:115px;box-sizing:border-box" onblur="plUrunAra(this)" placeholder="Kod gir..."></td>
    <td style="padding:1px;min-width:90px"><input type="text" name="colour" class="form-alan" style="width:100%;min-width:85px;box-sizing:border-box"></td>
    <td style="padding:1px;min-width:80px"><input type="number" name="net_kg" step="0.01" class="form-alan" style="width:100%;min-width:75px;box-sizing:border-box" oninput="plToplamHesapla()"></td>
    <td style="padding:1px;min-width:75px"><input type="number" name="width" step="0.1" value="100" class="form-alan" style="width:100%;min-width:70px;box-sizing:border-box" oninput="plM3Hesapla(this)"></td>
    <td style="padding:1px;min-width:75px"><input type="number" name="length" step="0.1" value="120" class="form-alan" style="width:100%;min-width:70px;box-sizing:border-box" oninput="plM3Hesapla(this)"></td>
    <td style="padding:1px;min-width:75px"><input type="number" name="height" step="0.1" value="230" class="form-alan" style="width:100%;min-width:70px;box-sizing:border-box" oninput="plM3Hesapla(this)"></td>
    <td style="padding:1px;min-width:80px"><input type="number" name="m3" step="0.001" class="form-alan" style="width:100%;min-width:75px;box-sizing:border-box" readonly></td>
    <td style="padding:1px;text-align:center;min-width:40px"><button type="button" onclick="plSatirSil(this)" style="background:#DC2626;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer">✕</button></td>
  `;
  document.getElementById('plSatirlar').appendChild(tr);
  plM3Hesapla(tr.querySelector('[name="width"]'));
  plSatirNoGuncelle();
}

function plSatirSil(btn){
  if(document.querySelectorAll('#plSatirlar tr').length<=1)return;
  btn.closest('tr').remove();
  plSatirNoGuncelle();
  plToplamHesapla();
}

function plSatirNoGuncelle(){
  document.querySelectorAll('#plSatirlar tr').forEach(function(tr,i){
    tr.cells[0].textContent=i+1;
  });
}

function plOtoToplam(el){
  var tr=el.closest('tr');
  var p=parseFloat(tr.querySelector('[name="packet_qty"]').value)||0;
  var u=parseFloat(tr.querySelector('[name="unit_qty"]').value)||0;
  el.value=p*u;
  plToplamHesapla();
}

function plM3Hesapla(el){
  var tr=el.closest('tr');
  var w=parseFloat(tr.querySelector('[name="width"]').value)||0;
  var l=parseFloat(tr.querySelector('[name="length"]').value)||0;
  var h=parseFloat(tr.querySelector('[name="height"]').value)||0;
  var m3=(w*l*h)/1000000;
  tr.querySelector('[name="m3"]').value=m3%1===0?m3.toString():m3.toFixed(3);
  plToplamHesapla();
}

function plUrunAra(el){
  var kod=el.value.trim();
  if(!kod)return;
  $.post('<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',{action:'search_product',product_code:kod},function(r){
    if(!r.success||!r.data)return;
    var tr=el.closest('tr');
    var d=r.data;
    if(d.article_no)   tr.querySelector('[name="article_no"]').value=d.article_no;
    if(d.description)  tr.querySelector('[name="desc"]').value=d.description;
    if(d.brut_weight)  tr.querySelector('[name="brut_kg"]').value=d.brut_weight;
    if(d.net_weight)   tr.querySelector('[name="net_kg"]').value=d.net_weight;
    if(d.colour)       tr.querySelector('[name="colour"]').value=d.colour;
    if(d.width)        tr.querySelector('[name="width"]').value=d.width;
    if(d.length)       tr.querySelector('[name="length"]').value=d.length;
    if(d.height)       tr.querySelector('[name="height"]').value=d.height;
    if(d.unit_quantity) tr.querySelector('[name="unit_qty"]').value=d.unit_quantity;
    if(d.packet_quantity) tr.querySelector('[name="packet_qty"]').value=d.packet_quantity;
    if(d.order_number) tr.querySelector('[name="order_no"]').value=d.order_number;
    plM3Hesapla(tr.querySelector('[name="width"]'));
    plToplamHesapla();
  },'json');
}

function plToplamHesapla(){
  var tp=0,tb=0,tn=0;
  document.querySelectorAll('#plSatirlar tr').forEach(function(tr){
    tp+=parseFloat(tr.querySelector('[name="packet_qty"]').value)||0;
    tb+=parseFloat(tr.querySelector('[name="brut_kg"]').value)||0;
    tn+=parseFloat(tr.querySelector('[name="net_kg"]').value)||0;
  });
  document.getElementById('pl_top_paket').value=tp;
  document.getElementById('pl_top_brut').value=tb.toFixed(2);
  document.getElementById('pl_top_net').value=tn.toFixed(2);
  document.getElementById('pl_top_cbm').value=((tn/1000)*1.2).toFixed(2);
}

function plKaydet(){
  var irsaliye=document.getElementById('pl_irsaliye').value.trim();
  var musteri=document.getElementById('pl_musteri').value.trim();
  var tarih=document.getElementById('pl_tarih').value;
  if(!irsaliye){alert('İrsaliye No zorunludur!');return;}
  if(!musteri){alert('Müşteri Adı zorunludur!');return;}
  if(!tarih){alert('Tarih zorunludur!');return;}

  var items=[];
  document.querySelectorAll('#plSatirlar tr').forEach(function(tr){
    items.push({
      palet_no:tr.querySelector('[name="palet_no"]').value||1,
      packet_quantity:tr.querySelector('[name="packet_qty"]').value||0,
      unit_quantity:tr.querySelector('[name="unit_qty"]').value||0,
      total_quantity:tr.querySelector('[name="total_qty"]').value||0,
      order_number:tr.querySelector('[name="order_no"]').value||'',
      article_no:tr.querySelector('[name="article_no"]').value||'',
      description:tr.querySelector('[name="desc"]').value||'',
      brut_weight:tr.querySelector('[name="brut_kg"]').value||0,
      product_code:tr.querySelector('[name="prod_code"]').value||'',
      colour:tr.querySelector('[name="colour"]').value||'',
      net_weight:tr.querySelector('[name="net_kg"]').value||0,
      width:tr.querySelector('[name="width"]').value||0,
      length:tr.querySelector('[name="length"]').value||0,
      height:tr.querySelector('[name="height"]').value||0,
      total_m3:tr.querySelector('[name="m3"]').value||0
    });
  });

  var id=document.getElementById('plId').value;
  $.ajax({
    url:'<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',
    method:'POST',
    data:{
      action:id?'update':'save',
      id:id||'',
      irsaliye_no:irsaliye,
      customer_name:musteri,
      packing_date:tarih,
      order_number:document.getElementById('pl_siparis_no').value,
      reference_number:document.getElementById('pl_ref_no').value,
      truck_plate:document.getElementById('pl_kamyon').value,
      trailer_plate:document.getElementById('pl_romork').value,
      driver_name:document.getElementById('pl_sofor').value,
      driver_phone:document.getElementById('pl_sofor_tel').value,
      special_info:document.getElementById('pl_ozel').value,
      total_packets:document.getElementById('pl_top_paket').value,
      total_brut_weight:document.getElementById('pl_top_brut').value,
      total_net_weight:document.getElementById('pl_top_net').value,
      items:JSON.stringify(items)
    },
    dataType:'json',
    success:function(r){
      if(r.success){alert(r.message);plModalKapat();location.reload();}
      else alert('Hata: '+r.message);
    },
    error:function(){alert('Sunucu hatası');}
  });
}

function plDurumGuncelle(id,status){
  $.post('<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',{action:'update_status',id:id,status:status},function(r){
    if(r.success)location.reload();
    else alert('Hata: '+r.message);
  },'json');
}

function plSil(id){
  if(!confirm('Bu packing list silinsin mi?'))return;
  $.post('<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',{action:'delete',id:id},function(r){
    if(r.success){alert(r.message);location.reload();}
    else alert('Hata: '+r.message);
  },'json');
}

// --- Yazdırma / Çıktılar ---
function plVeriAl(id,cb){
  $.post('<?php echo BASE_URL;?>/bolumler/satis/ajax/packing_ajax.php',{action:'get',id:id},function(r){
    if(r.success)cb(r.data); else alert('Hata: '+r.message);
  },'json');
}

function plBlobAc(html){
  var blob=new Blob([html],{type:'text/html;charset=utf-8'});
  var url=URL.createObjectURL(blob);
  var w=window.open(url,'_blank');
  if(!w){alert('Popup engelleyici aktif. Lütfen popup\'lara izin verin.');return;}
  w.onload=function(){setTimeout(function(){w.print();URL.revokeObjectURL(url);},400);};
}
function plYazdir(id){ plVeriAl(id,function(d){plBlobAc(plPrintHTML(d));}); }
function plPaletEtiketi(id){ plVeriAl(id,function(d){plBlobAc(plPaletHTML(d));}); }
function plOzetRapor(id){ plVeriAl(id,function(d){plBlobAc(plOzetHTML(d));}); }
function plExcel(id){ plVeriAl(id,function(d){plExcelIndir(d);}); }

function plPrintHTML(d){
  var rows='',tm3=0,tb=0,pallets=new Set();
  var cm={'BLACK':'#000','BLUE':'#1e40af','GREEN':'#16a34a','YELLOW':'#cbc12d','RED':'#dc2626','WHITE':'#555','GRAY':'#4b5563','GREY':'#4b5563','BROWN':'#92400e','ORANGE':'#ea580c','PURPLE':'#7c3aed','PINK':'#db2777','NATURAL':'#78716c','TRANSPARENT':'#9ca3af'};
  if(d.items){d.items.sort((a,b)=>(parseInt(a.palet_no)||999)-(parseInt(b.palet_no)||999));d.items.forEach(function(it,i){
    var m=parseFloat(it.total_m3||0);tm3+=m;tb+=parseFloat(it.brut_weight||0);
    pallets.add(parseInt(it.palet_no)||1);
    var c=cm[(it.colour||'').toUpperCase()]||'#000';
    rows+=`<tr style="color:${c}"><td>${it.palet_no||i+1}</td><td>${it.packet_quantity||''}</td><td>${it.unit_quantity||''}</td><td>${it.total_quantity||''}</td><td>${it.order_number||''}</td><td>${it.article_no||''}</td><td>${it.description||''}</td><td>${it.brut_weight||''}</td><td>${it.product_code||''}</td><td>${it.colour||''}</td><td>${it.net_weight||''}</td><td>${Math.floor(it.width||0)}x${Math.floor(it.length||0)}x${Math.floor(it.height||0)} cm</td><td>${m%1===0?m:m.toFixed(3)} m³</td></tr>`;
  });}
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>PACKING LIST - ${d.packing_no}</title><style>body{font-family:Arial,sans-serif;font-size:12px;margin:20px}.hdr{display:flex;justify-content:space-between;margin-bottom:15px;border-bottom:2px solid #000;padding-bottom:10px}table{width:100%;border-collapse:collapse;margin:15px 0}th,td{border:1px solid #000;padding:4px 6px;font-size:10px}th{background:#f0f0f0;font-weight:bold}.tot{display:flex;justify-content:space-between;margin-top:15px}</style></head><body><div class="hdr"><div><b style="font-size:22px;color:#1e3a8a">POLIZA</b><br>POLİZA ENDÜSTRİ A.Ş.</div><div style="text-align:center"><h2>PACKING LIST</h2><p>Date: ${new Date(d.packing_date).toLocaleDateString('en-GB')}</p></div><div style="text-align:right"><p><b>CUSTOMER:</b> ${d.customer_name}</p><p><b>Packing No:</b> ${d.packing_no}</p><p><b>İrsaliye No:</b> ${d.irsaliye_no}</p></div></div><table><thead><tr><th>Palet</th><th>Paket Mik.</th><th>Birim Mik.</th><th>Top. Mik.</th><th>Sipariş No</th><th>Article No</th><th>Açıklama</th><th>Brüt kg</th><th>Ürün Kodu</th><th>Renk</th><th>Net kg</th><th>Paket Boyutu</th><th>m³</th></tr></thead><tbody>${rows}</tbody></table><div class="tot"><div><p><b>TRUCK:</b> ${d.truck_plate||''}</p><p><b>DRIVER:</b> ${d.driver_name||''}</p><p><b>TOTAL PALLETS:</b> ${pallets.size}</p></div><div><p><b>TOTAL PACKETS:</b> ${d.total_packets}</p><p><b>TOTAL BRUT:</b> ${tb.toFixed(2)} kg</p><p><b>TOTAL NET:</b> ${d.total_net_weight} kg</p><p><b>TOTAL m³:</b> ${tm3%1===0?tm3:tm3.toFixed(3)} m³</p></div></div>${d.special_info?`<p><b>Special Info:</b> ${d.special_info}</p>`:''}</body></html>`;
}

function plPaletHTML(d){
  var labels='';
  if(d.items){
    var grp={};
    d.items.forEach(function(it){var k=it.palet_no||1;if(!grp[k])grp[k]=[];grp[k].push(it);});
    Object.keys(grp).sort((a,b)=>parseInt(a)-parseInt(b)).forEach(function(pn,idx){
      var items=grp[pn],tg=0,tn=0,fi=items[0];
      items.forEach(function(it){tg+=parseFloat(it.brut_weight||0);tn+=parseFloat(it.net_weight||0);});
      var ps=Math.floor(fi.width||0)+' X '+Math.floor(fi.length||0)+' X '+Math.floor(fi.height||0);
      var prods=items.map(function(it,i){
        return '<div style="padding:4px 0;border-bottom:'+(i<items.length-1?'1px dashed #ddd':'none')+'">'
          +'<b>Kod:</b> '+(it.product_code||'')+' &nbsp;|&nbsp; <b>Renk:</b> '+(it.colour||'')+'<br>'
          +'<b>Açıklama:</b> '+(it.description||'')+'<br>'
          +'<b>Paket:</b> '+(it.packet_quantity||0)+' &nbsp; <b>Brüt:</b> '+parseFloat(it.brut_weight||0).toFixed(2)+' kg &nbsp; <b>Net:</b> '+parseFloat(it.net_weight||0).toFixed(2)+' kg'
          +'</div>';
      }).join('');
      labels+='<div class="palet-label">'
        +'<div style="text-align:center;border-bottom:1px solid #000;padding-bottom:8px;margin-bottom:8px">'
          +'<div style="font-size:28px;font-weight:bold;color:#8B9DC3;letter-spacing:2px">POLİZA</div>'
          +'<div style="font-size:16px;font-weight:bold">POLIZA INDUSTRY INC.</div>'
          +'<div style="font-size:22px;font-weight:bold;margin-top:4px">'+ps+' CM</div>'
        +'</div>'
        +'<div style="display:flex;gap:8px;margin-bottom:8px">'
          +'<div style="flex:1;background:#fef3c7;padding:8px;border-radius:6px;border:1px solid #f59e0b">'
            +'<div style="font-size:11px;font-weight:bold">GROSS WEIGHT</div>'
            +'<div style="font-size:20px;font-weight:900;color:#b45309">'+tg.toFixed(2)+' kg</div>'
          +'</div>'
          +'<div style="flex:1;background:#dbeafe;padding:8px;border-radius:6px;border:1px solid #3b82f6">'
            +'<div style="font-size:11px;font-weight:bold">NET WEIGHT</div>'
            +'<div style="font-size:20px;font-weight:900;color:#1e40af">'+tn.toFixed(2)+' kg</div>'
          +'</div>'
        +'</div>'
        +'<div style="background:#e0e7ff;padding:8px;border-radius:6px;margin-bottom:8px;border:1px solid #6366f1">'
          +'<div style="font-size:48px;font-weight:900;color:#1e40af;line-height:1">PALLET: '+pn+'</div>'
          +'<div style="font-size:12px;margin-top:4px"><b>ORDER:</b> '+(fi.order_number||d.order_number||'')+'</div>'
        +'</div>'
        +'<div style="flex:1;background:#f9fafb;padding:8px;border-radius:6px;font-size:14px;border:1px solid #e5e7eb;overflow:hidden">'
          +'<div style="font-weight:bold;margin-bottom:6px;font-size:15px">PALET İÇERİĞİ:</div>'
          +prods
        +'</div>'
        +'<div style="text-align:center;font-weight:bold;font-size:13px;margin-top:8px;padding-top:6px;border-top:1px solid #000">ORIGIN: REPUBLIC OF TURKEY</div>'
        +'<div style="text-align:center;font-size:9px;color:#555;margin-top:3px">info@poliza.com.tr | www.poliza.com.tr | Tel: 0282 758 30 03<br>Yıldırım Beyazıt OSB Mah. 26.Sokak No.4/A ÇERKEZKÖY/TEKİRDAĞ</div>'
      +'</div>';
    });
  }
  return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>PALLET LABELS - '+d.packing_no+'</title>'
    +'<style>'
    +'*{box-sizing:border-box;margin:0;padding:0}'
    +'body{font-family:Arial,sans-serif;background:#fff}'
    +'.palet-label{'
      +'width:277mm;height:190mm;'
      +'border:2px solid #000;'
      +'padding:8mm;'
      +'display:flex;flex-direction:column;'
      +'page-break-after:always;'
      +'overflow:hidden;'
    +'}'
    +'.palet-label:last-child{page-break-after:auto}'
    +'@page{size:A4 landscape;margin:10mm}'
    +'@media print{'
      +'.palet-label{page-break-after:always;width:277mm;height:190mm}'
      +'.palet-label:last-child{page-break-after:auto}'
    +'}'
    +'</style>'
    +'</head><body>'+labels+'</body></html>';
}

function plOzetHTML(d){
  var grp={};
  if(d.items){d.items.forEach(function(it){var k=it.product_code||it.article_no||'?';if(!grp[k])grp[k]={code:k,desc:it.description||'',colour:it.colour||'',packets:0,qty:0,pallets:new Set()};grp[k].packets+=parseInt(it.packet_quantity)||0;grp[k].qty+=parseInt(it.total_quantity)||0;grp[k].pallets.add(it.palet_no||1);});}
  var rows='',tp=0,tq=0;
  Object.keys(grp).sort().forEach(function(k){var g=grp[k];tp+=g.packets;tq+=g.qty;rows+=`<tr><td><b>${g.code}</b></td><td>${g.desc}</td><td>${g.colour}</td><td style="text-align:center">${g.packets}</td><td style="text-align:center">${g.qty}</td><td style="text-align:center">${g.pallets.size}</td></tr>`;});
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>ÖZET - ${d.packing_no}</title><style>body{font-family:Arial,sans-serif;font-size:12px;margin:20px}.hdr{display:flex;justify-content:space-between;margin-bottom:15px;border-bottom:2px solid #000;padding-bottom:10px}table{width:100%;border-collapse:collapse;margin:15px 0}th,td{border:1px solid #000;padding:6px 8px;font-size:11px}th{background:#f0f0f0;font-weight:bold;text-align:center}</style></head><body><div class="hdr"><div><b style="font-size:22px;color:#1e3a8a">POLIZA</b><br>POLİZA ENDÜSTRİ A.Ş.</div><div style="text-align:center"><h2>ÖZET RAPORU</h2><p>${new Date(d.packing_date).toLocaleDateString('en-GB')}</p></div><div style="text-align:right"><p><b>CUSTOMER:</b> ${d.customer_name}</p><p><b>Packing No:</b> ${d.packing_no}</p><p><b>İrsaliye No:</b> ${d.irsaliye_no}</p></div></div><table><thead><tr><th>Ürün Kodu</th><th>Ürün Adı</th><th>Renk</th><th>Top. Paket</th><th>Top. Miktar</th><th>Palet Sayısı</th></tr></thead><tbody>${rows}</tbody></table><div style="margin-top:15px;padding:10px;background:#f8f9fa;display:flex;gap:30px"><b>TOPLAM PAKET: ${tp}</b><b>TOPLAM MİKTAR: ${tq}</b><b>ÜRÜN ÇEŞİDİ: ${Object.keys(grp).length}</b></div></body></html>`;
}

function plExcelIndir(d){
  var grp={};
  if(d.items){d.items.forEach(function(it){var k=it.product_code||it.article_no||'?';if(!grp[k])grp[k]={code:k,desc:it.description||'',colour:it.colour||'',packets:0,qty:0,pallets:new Set()};grp[k].packets+=parseInt(it.packet_quantity)||0;grp[k].qty+=parseInt(it.total_quantity)||0;grp[k].pallets.add(it.palet_no||1);});}
  var rows=[['POLİZA ENDÜSTRİ A.Ş.'],['ÖZET RAPORU'],[],['MÜŞTERİ:',d.customer_name],['PACKING NO:',d.packing_no],['İRSALİYE NO:',d.irsaliye_no],['TARİH:',new Date(d.packing_date).toLocaleDateString('tr-TR')],[],['Ürün Kodu','Ürün Adı','Renk','Toplam Paket','Toplam Miktar','Palet Sayısı']];
  var tp=0,tq=0;
  Object.keys(grp).sort().forEach(function(k){var g=grp[k];tp+=g.packets;tq+=g.qty;rows.push([g.code,g.desc,g.colour,g.packets,g.qty,g.pallets.size]);});
  rows.push([],['TOPLAM','','',tp,tq,Object.keys(grp).length]);
  var wb=XLSX.utils.book_new(),ws=XLSX.utils.aoa_to_sheet(rows);
  ws['!cols']=[{wch:15},{wch:40},{wch:12},{wch:15},{wch:15},{wch:12}];
  XLSX.utils.book_append_sheet(wb,ws,'Özet');
  XLSX.writeFile(wb,'Ozet_'+d.packing_no+'_'+new Date().toISOString().slice(0,10)+'.xlsx');
}
</script>
