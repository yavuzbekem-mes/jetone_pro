<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);

// Sipariş kodlarını çek
$siparisKodlari = [];
try {
    $s = $db->prepare("SELECT DISTINCT jit_sip_kodu FROM jit_siparis WHERE jit_sip_statu='Aktif' ORDER BY jit_sip_kodu ASC");
    $s->execute();
    $siparisKodlari = $s->fetchAll(PDO::FETCH_COLUMN);
} catch(Throwable $e){}

// Kart verisi — session'da sakla, her kart bağımsız
if(session_status()===PHP_SESSION_NONE) session_start();
if(!isset($_SESSION['jit_kartlar'])) $_SESSION['jit_kartlar']=[];

function getCardData($suffix, $siparisKodlari) {
    $key = 'kart_'.$suffix;
    // Bu kart için hesapla POST'u geldiyse session'ı güncelle
    if (isset($_POST['hesapla'.$suffix])) {
        $_SESSION['jit_kartlar'][$key] = [
            'kod'           => $_POST['jit_sip_kodu'.$suffix] ?? '',
            'uretim_miktar' => floatval($_POST['uretim_miktar'.$suffix] ?? 0),
            'pazar_calis'   => $_POST['pazar_calis'.$suffix] ?? 'hayir',
            'vardiya1'      => isset($_POST['vardiya1'.$suffix]),
            'vardiya2'      => isset($_POST['vardiya2'.$suffix]),
            'vardiya3'      => isset($_POST['vardiya3'.$suffix]),
            'hesapla'       => true,
        ];
    }
    // Session'da kayıtlı veri varsa onu döndür
    if (isset($_SESSION['jit_kartlar'][$key])) {
        return $_SESSION['jit_kartlar'][$key];
    }
    // İlk açılış
    return [
        'kod'           => count($siparisKodlari) > 0 ? $siparisKodlari[0] : '',
        'uretim_miktar' => 0,
        'pazar_calis'   => 'hayir',
        'vardiya1'      => false,
        'vardiya2'      => false,
        'vardiya3'      => false,
        'hesapla'       => false,
    ];
}
?>
<style>
.jit-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:18px;min-width:320px;flex:1 1 320px;max-width:480px}
.jit-kart h3{font-size:13px;font-weight:800;color:#1E3A5F;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #BFDBFE}
.jit-tbl{width:100%;border-collapse:collapse;font-size:11px}
.jit-tbl thead th{background:#1E3A5F;color:#fff;padding:5px 7px;border:1px solid #2d5986;white-space:nowrap;text-align:center}
.jit-tbl tbody td{padding:3px 6px;border-bottom:1px solid #F1F5F9;vertical-align:middle}
.jit-tbl tr.pazar-satir td{background:#FFFBEB!important}
.jit-tbl tr.stok-negatif td{background:#FEE2E2!important;font-weight:700}
.jit-tbl tr.stok-negatif td:last-child{color:#991B1B}
.jit-tbl tr:hover td{filter:brightness(.94)}
.jit-stok-info{background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:8px 12px;font-size:12px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">⏱ JIT Saatlik Kontrol</h1>
    <div class="s-yol">Satış / <b>JIT Saatlik Sipariş & Üretim</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?>
      <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger Yok</span><?php endif;?>
    </div>
  </div>
</div>

<div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-start">
<?php
for ($kartNo = 1; $kartNo <= 5; $kartNo++):
    $sfx = $kartNo > 1 ? $kartNo : '';
    $d   = getCardData($sfx, $siparisKodlari);

    // Tiger'dan stok çek
    $ilkStok = 0;
    if ($d['kod'] && $tiger_ok) {
        try {
            $ss = $tigerdb_pdo->prepare("SELECT ISNULL(SUM(LV.ONHAND),0) AS s FROM dbo.LG_222_ITEMS IT LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF WHERE IT.CODE=? AND IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 AND LV.INVENNO IN(0,1,5)");
            $ss->execute([$d['kod']]);
            $ilkStok = (int)$ss->fetchColumn();
        } catch(Throwable $e){}
    }

    // Saatlik sipariş verisi
    $sipArray = []; // [gun][saat] = miktar
    for ($g = 0; $g < 7; $g++) $sipArray[$g] = array_fill(0, 24, 0);

    if ($d['kod']) {
        try {
            $sq = $db->prepare("SELECT jit_sip_teslim_tarihi, jit_sip_saati, jit_sip_miktar, COALESCE(jit_sip_sevk_miktari,0) sevk FROM jit_siparis WHERE jit_sip_kodu=? AND jit_sip_statu='Aktif'");
            $sq->execute([$d['kod']]);
            $bugun = date('Y-m-d');
            foreach($sq->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $gf = (int)((strtotime($row['jit_sip_teslim_tarihi']) - strtotime($bugun)) / 86400);
                if ($gf >= 0 && $gf < 7) {
                    $saat = (int)substr($row['jit_sip_saati']??'00:00', 0, 2);
                    $kalan = max(0, floatval($row['jit_sip_miktar']) - floatval($row['sevk']));
                    if ($kalan > 0) $sipArray[$gf][$saat] += $kalan;
                }
            }
        } catch(Throwable $e){}
    }
?>
<div class="jit-kart">
  <h3>📊 Kart <?php echo $kartNo;?></h3>
  <form method="POST">
  <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px">
    <div style="display:flex;align-items:center;gap:8px">
      <label class="form-etiket" style="min-width:110px;margin:0">Sipariş Kodu:</label>
      <select name="jit_sip_kodu<?php echo $sfx;?>" class="form-alan" style="flex:1;font-size:12px">
        <?php if(empty($siparisKodlari)):?>
        <option value="">— Sipariş yok —</option>
        <?php else: foreach($siparisKodlari as $k):?>
        <option value="<?php echo htmlspecialchars($k);?>" <?php echo $k===$d['kod']?'selected':'';?>><?php echo htmlspecialchars($k);?></option>
        <?php endforeach; endif;?>
      </select>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <label class="form-etiket" style="min-width:110px;margin:0">Saatlik Üretim:</label>
      <input type="number" name="uretim_miktar<?php echo $sfx;?>" value="<?php echo $d['uretim_miktar'];?>" min="0" step="1" class="form-alan" style="flex:1;font-size:12px">
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <label class="form-etiket" style="min-width:110px;margin:0">Pazar Günü:</label>
      <select name="pazar_calis<?php echo $sfx;?>" class="form-alan" style="flex:1;font-size:12px" onchange="pazarToggle(this,'vrd<?php echo $sfx;?>')">
        <option value="hayir" <?php echo $d['pazar_calis']==='hayir'?'selected':'';?>>Çalışma Yok</option>
        <option value="evet" <?php echo $d['pazar_calis']==='evet'?'selected':'';?>>Çalışma Var</option>
      </select>
    </div>
    <div id="vrd<?php echo $sfx;?>" style="background:var(--bg);border:1px solid var(--kenar);border-radius:6px;padding:8px;display:<?php echo $d['pazar_calis']==='evet'?'block':'none';?>">
      <div style="font-size:11px;font-weight:700;color:var(--m2);margin-bottom:6px">Pazar Vardiyaları:</div>
      <div style="display:flex;flex-direction:column;gap:4px">
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer"><input type="checkbox" name="vardiya1<?php echo $sfx;?>" value="1" <?php echo $d['vardiya1']?'checked':'';?>><span>1. Vardiya (00-08)</span></label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer"><input type="checkbox" name="vardiya2<?php echo $sfx;?>" value="1" <?php echo $d['vardiya2']?'checked':'';?>><span>2. Vardiya (08-16)</span></label>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer"><input type="checkbox" name="vardiya3<?php echo $sfx;?>" value="1" <?php echo $d['vardiya3']?'checked':'';?>><span>3. Vardiya (16-24)</span></label>
      </div>
    </div>
    <button type="submit" name="hesapla<?php echo $sfx;?>"
      style="background:linear-gradient(135deg,#1E3A5F,#2d5986);color:#fff;border:none;padding:7px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      🔄 Hesapla
    </button>
  </div>

  <?php if($d['hesapla'] && $d['kod']):?>
  <div class="jit-stok-info">
    <span><b><?php echo htmlspecialchars($d['kod']);?></b></span>
    <span>Başlangıç Stok: <b style="color:#1E40AF"><?php echo number_format($ilkStok, 0, '', '');?></b></span>
    <button type="button" onclick="jitExcel(<?php echo $kartNo;?>)" style="background:#1D6F42;color:#fff;border:none;padding:3px 8px;border-radius:5px;font-size:11px;cursor:pointer">📊 Excel</button>
  </div>

  <div style="overflow-x:auto;overflow-y:auto;max-height:500px;border:1px solid var(--kenar);border-radius:6px">
  <table class="jit-tbl" id="jitTbl<?php echo $kartNo;?>">
    <thead><tr>
      <th>Tarih</th><th>Saat</th><th style="text-align:right">Sipariş</th>
      <th style="text-align:right">Üretim</th><th style="text-align:right">Stok</th>
    </tr></thead>
    <tbody>
    <?php
    $stok = $ilkStok;
    $bugun = date('Y-m-d');
    $suanSaat = (int)date('H');
    for ($g = 0; $g < 7; $g++):
        $gunTarih = date('Y-m-d', strtotime("+$g day"));
        $haftaGunu = (int)date('w', strtotime($gunTarih));
        $isPazar = $haftaGunu === 0;
        for ($i = 0; $i < 24; $i++):
            $siparis = $sipArray[$g][$i];

            // Üretim hesabı
            $uretim = 0;
            $hesaplaUretim = ($gunTarih > $bugun) || ($gunTarih === $bugun && $i >= $suanSaat);
            if ($hesaplaUretim) {
                $uretim = ($gunTarih === $bugun && $i === $suanSaat)
                    ? floor($d['uretim_miktar'] / 2)
                    : $d['uretim_miktar'];
                if ($isPazar) {
                    if ($d['pazar_calis'] === 'evet') {
                        $v1 = $i < 8 && $d['vardiya1'];
                        $v2 = $i >= 8 && $i < 16 && $d['vardiya2'];
                        $v3 = $i >= 16 && $d['vardiya3'];
                        if (!$v1 && !$v2 && !$v3) $uretim = 0;
                    } else {
                        $uretim = 0;
                    }
                }
            }

            $stok += $uretim - $siparis;

            $tr_class = '';
            if ($stok < 0) $tr_class = 'stok-negatif';
            elseif ($isPazar) $tr_class = 'pazar-satir';
            elseif ($g % 2 === 0) $tr_class = 'cift-gun';

            $siparis_str = $siparis > 0 ? number_format($siparis, 0, '', '') : '';
            $uretim_str  = $uretim > 0  ? number_format($uretim, 0, '', '') : '';
        ?>
        <tr class="<?php echo $tr_class;?>">
          <td style="white-space:nowrap;font-size:10px;color:var(--m2)"><?php echo date('d.m.Y', strtotime($gunTarih));?><?php echo $isPazar?' <span style="color:#D97706;font-weight:700;font-size:9px">PAZ</span>':'';?></td>
          <td style="text-align:center;font-weight:700;font-family:monospace"><?php echo str_pad($i,2,'0',STR_PAD_LEFT).':00';?></td>
          <td style="text-align:right;color:<?php echo $siparis>0?'#DC2626':'var(--m2)';?>"><?php echo $siparis_str;?></td>
          <td style="text-align:right;color:#059669"><?php echo $uretim_str;?></td>
          <td style="text-align:right;font-weight:700;color:<?php echo $stok<0?'#DC2626':'#059669';?>"><?php echo number_format($stok, 0, '', '');?></td>
        </tr>
        <?php endfor; endfor;?>
    </tbody>
  </table>
  </div>
  <?php elseif($d['hesapla']):?>
  <div style="background:#FEF3C7;border-radius:6px;padding:10px;font-size:12px;color:#92400E">Geçerli sipariş kodu seçiniz.</div>
  <?php endif;?>
  </form>
</div>
<?php endfor;?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
<script>
function pazarToggle(sel, divId) {
  document.getElementById(divId).style.display = sel.value === 'evet' ? 'block' : 'none';
}
async function jitExcel(n) {
  if (typeof ExcelJS === 'undefined') { alert('ExcelJS yüklenmedi'); return; }
  var tbl = document.getElementById('jitTbl' + n);
  if (!tbl) return;

  var wb = new ExcelJS.Workbook();
  var ws = wb.addWorksheet('JIT Saatlik');

  // Sütun genişlikleri
  ws.columns = [
    {width:12}, // Tarih
    {width:8},  // Saat
    {width:12}, // Sipariş
    {width:12}, // Üretim
    {width:14}, // Stok
  ];

  // Kenarlık tanımı
  var border = {
    top:{style:'thin',color:{argb:'FFBFDBFE'}},
    left:{style:'thin',color:{argb:'FFBFDBFE'}},
    bottom:{style:'thin',color:{argb:'FFBFDBFE'}},
    right:{style:'thin',color:{argb:'FFBFDBFE'}}
  };
  var borderBold = {
    top:{style:'medium',color:{argb:'FF1E3A5F'}},
    left:{style:'medium',color:{argb:'FF1E3A5F'}},
    bottom:{style:'medium',color:{argb:'FF1E3A5F'}},
    right:{style:'medium',color:{argb:'FF1E3A5F'}}
  };

  var rows = tbl.querySelectorAll('tr');
  rows.forEach(function(row, ri) {
    var cells = row.querySelectorAll('th,td');
    var isHeader = row.closest('thead') !== null;
    var rowData = [];
    var isBgKirmizi = row.classList.contains('stok-negatif');
    var isBgPazar   = row.classList.contains('pazar-satir');
    var isBgCift    = row.classList.contains('cift-gun');

    cells.forEach(function(cell, ci) {
      var txt = cell.innerText.replace('PAZ','').trim();
      var val;
      if (/^\d{2}\.\d{2}\.\d{4}$/.test(txt)) val = txt;
      else if (/^\d{2}:00$/.test(txt)) val = txt;
      else if (txt !== '' && /^-?\d+$/.test(txt.replace(/\./g,'').replace(',','.'))) {
        val = parseInt(txt.replace(/\./g,'').replace(',','.'), 10);
      } else val = txt;
      rowData.push(val);
    });

    var wsRow = ws.addRow(rowData);

    // Hücre stilleri
    wsRow.eachCell({includeEmpty:true}, function(cell, colNum) {
      cell.border = isHeader ? borderBold : border;
      cell.font = {name:'Calibri', size: isHeader ? 10 : 10, bold: isHeader};

      if (isHeader) {
        cell.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FF1E3A5F'}};
        cell.font = {name:'Calibri', size:10, bold:true, color:{argb:'FFFFFFFF'}};
        cell.alignment = {vertical:'middle', horizontal:'center'};
      } else if (isBgKirmizi) {
        // Stok negatif - kırmızı satır
        cell.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FFFEE2E2'}};
        if (colNum === 5) {
          cell.font = {name:'Calibri', size:10, bold:true, color:{argb:'FF991B1B'}};
        }
      } else if (isBgPazar) {
        // Pazar - sarı
        cell.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FFFFFBEB'}};
      } else if (isBgCift) {
        cell.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FFF8FAFC'}};
      } else {
        cell.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FFFFFFFF'}};
      }

      // Sayı hizalaması
      if (colNum >= 3) cell.alignment = {horizontal:'right'};
    });

    if (isHeader) wsRow.height = 18;
  });

  var buf = await wb.xlsx.writeBuffer();
  var blob = new Blob([buf], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'JIT_Saatlik_Kart' + n + '_' + new Date().toISOString().slice(0,10) + '.xlsx';
  a.click();
  URL.revokeObjectURL(url);
}
</script>
