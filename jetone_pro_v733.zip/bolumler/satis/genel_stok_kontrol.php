<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok = ($tigerdb_pdo !== null);
$today    = date('Y-m-d');
$end_date = date('Y-m-d', strtotime('+1 month'));
$tr_gun   = ['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'];

$tarih_kolonlari = [];
$d = $today;
while ($d <= $end_date) {
    $tarih_kolonlari[] = $d;
    $d = date('Y-m-d', strtotime('+1 day', strtotime($d)));
}

$firmalar = [];
try {
    $firmalar = $db->query("SELECT DISTINCT musteri_firma_adi FROM siparis WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL ORDER BY musteri_firma_adi")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {}

$secili_firma = $_POST['firma'] ?? '';
$buton        = '';
if (isset($_POST['tumu'])) { $secili_firma = '__TUMU__'; $buton = 'tumu'; }
elseif (isset($_POST['sor'])) { $buton = 'sor'; }

$satirlar = [];
$hata     = '';

if ($buton && ($secili_firma !== '' || $buton === 'tumu')) {
    try {
        $sql    = "SELECT DISTINCT sip_kodu FROM siparis WHERE sip_statu='Aktif'";
        $params = [];
        if ($secili_firma !== '__TUMU__') { $sql .= " AND musteri_firma_adi=?"; $params[] = $secili_firma; }
        $s = $db->prepare($sql); $s->execute($params);
        $kodlar = $s->fetchAll(PDO::FETCH_COLUMN);

        if ($kodlar && $tiger_ok) {
            $ph    = implode(',', array_fill(0, count($kodlar), '?'));
            $stoks = $tigerdb_pdo->prepare("SELECT IT.CODE k, IT.NAME n,
                ISNULL((SELECT SUM(ONHAND) FROM dbo.LV_222_02_STINVTOT WHERE STOCKREF=IT.LOGICALREF AND INVENNO IN(0,1,5)),0) s
                FROM dbo.LG_222_ITEMS IT
                WHERE IT.CODE IN($ph) AND IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0
                GROUP BY IT.CODE, IT.NAME, IT.LOGICALREF");
            $stoks->execute($kodlar);

            foreach ($stoks->fetchAll(PDO::FETCH_ASSOC) as $stok) {
                $kod = $stok['k'];
                $mik = (float)$stok['s'];

                $bsql = "SELECT COALESCE(SUM(CASE WHEN sip_sevk_miktari>0 THEN sip_miktar-sip_sevk_miktari ELSE sip_miktar END),0) FROM siparis WHERE sip_kodu=? AND sip_teslim_tarihi<? AND sip_statu='Aktif'";
                $bp   = [$kod, $today];
                if ($secili_firma !== '__TUMU__') { $bsql .= " AND musteri_firma_adi=?"; $bp[] = $secili_firma; }
                $b = $db->prepare($bsql); $b->execute($bp);
                $bakiye = (float)$b->fetchColumn();

                $gsql = "SELECT sip_teslim_tarihi t, SUM(CASE WHEN sip_sevk_miktari>0 THEN sip_miktar-sip_sevk_miktari ELSE sip_miktar END) m FROM siparis WHERE sip_kodu=? AND sip_teslim_tarihi>=? AND sip_statu='Aktif'";
                $gp   = [$kod, $today];
                if ($secili_firma !== '__TUMU__') { $gsql .= " AND musteri_firma_adi=?"; $gp[] = $secili_firma; }
                $gsql .= " GROUP BY sip_teslim_tarihi ORDER BY sip_teslim_tarihi";
                $g = $db->prepare($gsql); $g->execute($gp);
                $gun_sip = [];
                foreach ($g->fetchAll(PDO::FETCH_ASSOC) as $r) $gun_sip[$r['t']] = (float)$r['m'];

                $kalan   = $mik - $bakiye;
                $ilk_yet = null;
                $ilk_mik = 0;
                $tmp     = $kalan;
                foreach ($tarih_kolonlari as $t) {
                    $tmp -= ($gun_sip[$t] ?? 0);
                    if ($tmp < 0 && !$ilk_yet) { $ilk_yet = $t; $ilk_mik = abs($tmp); }
                }

                $satirlar[] = [
                    'kod'     => $kod,
                    'adi'     => $stok['n'],
                    'mik'     => $mik,
                    'bakiye'  => $bakiye,
                    'kalan'   => $kalan,
                    'top_sip' => $bakiye + array_sum(array_intersect_key($gun_sip, array_flip($tarih_kolonlari))),
                    'ilk_yet' => $ilk_yet,
                    'ilk_mik' => $ilk_mik,
                    'gun_sip' => $gun_sip,
                ];
            }

            usort($satirlar, function($a, $b) {
                if ($a['ilk_yet'] && !$b['ilk_yet']) return -1;
                if (!$a['ilk_yet'] && $b['ilk_yet']) return 1;
                if ($a['ilk_yet'] && $b['ilk_yet']) return strcmp($a['ilk_yet'], $b['ilk_yet']);
                return 0;
            });
        }
    } catch (Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#gskTbl th { background: #1E3A5F !important; color: #fff !important; }
#gskTbl td, #gskTbl th { border: 1px solid #000 !important;; white-space:nowrap !important; }
table.dataTable#gskTbl tbody tr.gsk-yet-satir td,
table.dataTable#gskTbl tbody tr.gsk-yet-satir.odd td,
table.dataTable#gskTbl tbody tr.gsk-yet-satir.even td { background: #FEE2E2 !important; }
table.dataTable#gskTbl tbody tr td.gsk-g,
table.dataTable#gskTbl tbody tr.odd td.gsk-g,
table.dataTable#gskTbl tbody tr.even td.gsk-g { background: #16A34A !important; color: #fff !important; }
table.dataTable#gskTbl tbody tr td.gsk-k,
table.dataTable#gskTbl tbody tr.odd td.gsk-k,
table.dataTable#gskTbl tbody tr.even td.gsk-k { background: #DC2626 !important; color: #fff !important; }
.gsk-yet { background:#FEE2E2; color:#991B1B; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:700; }
.gsk-ytr { background:#D1FAE5; color:#065F46; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:700; }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Genel Stok Kontrol</h1>
    <div class="s-yol">Satış / <b>Portal Sipariş Stok Kontrol</b>
      <?php if ($tiger_ok): ?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else: ?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger Yok</span><?php endif; ?>
    </div>
  </div>
</div>

<?php if ($hata): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata); ?></div>
<?php endif; ?>

<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div style="flex:1;min-width:220px">
      <label class="form-etiket">Firma</label>
      <select name="firma" class="form-alan">
        <option value="">— Firma Seçin —</option>
        <?php foreach ($firmalar as $f): ?>
        <option value="<?php echo htmlspecialchars($f); ?>" <?php echo $f === $secili_firma ? 'selected' : ''; ?>><?php echo htmlspecialchars($f); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" name="tumu" value="1" style="background:#1E40AF;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Tümünü Kontrol Et</button>
    <button type="submit" name="sor"  value="1" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Sorgula</button>
  </form>
</div>

<?php if ($buton && empty($satirlar) && !$hata): ?>
<div class="kart" style="padding:30px;text-align:center;color:#888">Sonuç bulunamadı.</div>
<?php endif; ?>

<?php if (!empty($satirlar)):
  $yet_say   = count(array_filter($satirlar, fn($r) => $r['ilk_yet']));
  $tamam_say = count($satirlar) - $yet_say;
?>
<div style="display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap">
  <div style="background:#FEF2F2;border:1px solid #FCA5A5;border-radius:8px;padding:8px 16px">
    <div style="font-size:22px;font-weight:900;color:#DC2626"><?php echo $yet_say; ?></div>
    <div style="font-size:11px;color:#991B1B;font-weight:600">⚠️ Stok Yetersiz</div>
  </div>
  <div style="background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:8px 16px">
    <div style="font-size:22px;font-weight:900;color:#16A34A"><?php echo $tamam_say; ?></div>
    <div style="font-size:11px;color:#065F46;font-weight:600">✅ Stok Yeterli</div>
  </div>
  <div style="background:#EFF6FF;border:1px solid #93C5FD;border-radius:8px;padding:8px 16px">
    <div style="font-size:22px;font-weight:900;color:#1E40AF"><?php echo count($satirlar); ?></div>
    <div style="font-size:11px;color:#1E40AF;font-weight:600">📦 Toplam Ürün</div>
  </div>
</div>

<div class="kart" style="overflow:hidden;padding:0">
<table id="gskTbl" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Stok Kodu</th>
      <th>Stok Adı</th>
      <th>Yetersiz Tarih</th>
      <th>Açıklama</th>
      <th>Stok</th>
      <th>Top. Sipariş</th>
      <th>Bakiye</th>
      <?php foreach ($tarih_kolonlari as $t): ?>
      <th><?php echo $tr_gun[date('w', strtotime($t))] . ' ' . date('d/m', strtotime($t)); ?></th>
      <?php endforeach; ?>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Yetersiz Tarih</th><th>Açıklama</th>
      <th>Stok</th><th>Top. Sipariş</th><th>Bakiye</th>
      <?php foreach ($tarih_kolonlari as $t): ?><th><?php echo date('d/m', strtotime($t)); ?></th><?php endforeach; ?>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach ($satirlar as $r):
    $sat_cls = $r['ilk_yet'] ? 'gsk-yet-satir' : '';
    $bak_cls = $r['kalan'] < 0 ? 'gsk-k' : 'gsk-g';
    $sort    = $r['ilk_yet'] ?? '9999-99-99';
    $rk      = ($r['kalan'] < 0);
  ?>
  <tr class="<?php echo $sat_cls; ?>">
    <td style="font-family:monospace;font-weight:700"><?php echo htmlspecialchars($r['kod']); ?></td>
    <td><?php echo htmlspecialchars($r['adi']); ?></td>
    <td data-order="<?php echo $sort; ?>" style="text-align:center">
      <?php if ($r['ilk_yet']): ?><span class="gsk-yet"><?php echo date('d.m.Y', strtotime($r['ilk_yet'])); ?></span>
      <?php else: ?><span class="gsk-ytr">✓ Yeterli</span><?php endif; ?>
    </td>
    <td style="font-size:11px;color:#666">
      <?php if ($r['ilk_yet']): ?>
        <?php echo date('d.m', strtotime($r['ilk_yet'])); ?>'de <b><?php echo number_format($r['ilk_mik'], 0, '', ''); ?></b> eksik
      <?php else: ?>Stok yeterli<?php endif; ?>
    </td>
    <td style="text-align:right;font-weight:700"><?php echo number_format($r['mik'], 0, '', ''); ?></td>
    <td style="text-align:right"><?php echo number_format($r['top_sip'], 0, '', ''); ?></td>
    <td class="<?php echo $bak_cls; ?>" style="text-align:center"><?php echo number_format($r['bakiye'], 0, '', ''); ?></td>
    <?php
    $rk = ($r['kalan'] < 0);
    foreach ($tarih_kolonlari as $t):
      $gs = $r['gun_sip'][$t] ?? 0;
      if (!$rk && $r['ilk_yet'] && $t >= $r['ilk_yet']) $rk = true;
      $tc = $rk ? 'gsk-k' : 'gsk-g';
    ?><td class="<?php echo $tc; ?>" style="text-align:center"><?php echo $gs > 0 ? number_format($gs, 0, '', '') : ''; ?></td>
    <?php endforeach; ?>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<script>
$(document).ready(function() {
  document.title = 'Genel Stok Kontrol';
  if (!$('#gskTbl tbody tr').length) return;
  $('#gskTbl').DataTable({
    initComplete: function () {
      this.api().columns([0,1,2,3,4,5,6]).every(function () {
        var column = this;
        var select = $('<select class="filtre"><option value=""></option></select>')
          .appendTo($(column.footer()).empty())
          .on('change', function () {
            var val = $.fn.dataTable.util.escapeRegex($(this).val());
            column.search(val ? '^' + val + '$' : '', true, false).draw();
          });
        column.data().unique().sort().each(function (d) {
          var val = $('<div/>').html(d).text();
          var filtremetin = val.length > 29 ? val.substr(0, 30) + '...' : val;
          select.append('<option value="' + val + '">' + filtremetin + '</option>');
        });
      });
    },
    language: { url: 'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollCollapse: true,
    scrollY: 600,
    paging: false,
    scrollX: true,
    order: [[2, 'asc']],
    dom: 'Bfrtip',
    buttons: ['copyHtml5', 'excelHtml5', 'pdfHtml5', 'print']
  });
});
</script>
