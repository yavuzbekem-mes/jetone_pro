<?php
ob_start();
// ── POST / AJAX ──────────────────────────────────────────────────────────────
if (!empty($_POST['sip_action'])) {
    ob_end_clean();
    error_reporting(0);
    require_once dirname(dirname(__DIR__)).'/core/config.php';
    require_once dirname(dirname(__DIR__)).'/core/db.php';
    require_once dirname(dirname(__DIR__)).'/core/auth.php';
    require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
    header('Content-Type: application/json; charset=utf-8');
    Auth::zorunlu();
    $action = $_POST['sip_action'];
    $kul_adi = trim(($_SESSION['kullanici']['ad_soyad'] ?? '') ?: ($_SESSION['kullanici']['email'] ?? 'sistem'));

    // İnline alan güncelle
    if ($action === 'guncelle') {
        $id  = (int)($_POST['id']??0);
        $col = trim($_POST['kolon']??'');
        $val = trim($_POST['deger']??'');
        $izin= ['sip_teslim_tarihi','sip_miktar','sip_sevk_miktari','son_irsaliye_no',
                 'son_irsaliye_2','gecikme_nedeni','sip_baslama_tarih','sip_aciliyet',
                 'sip_durum','sip_ucret','sip_detay'];
        if (!$id || !in_array($col,$izin)) { echo json_encode(['ok'=>false]); exit; }
        try {
            $db->prepare("UPDATE siparis SET `$col`=?,guncelleyen=? WHERE sip_id=?")
               ->execute([$val?:null, $kul_adi, $id]);
            $r=$db->prepare("SELECT sip_miktar,sip_sevk_miktari FROM siparis WHERE sip_id=?");
            $r->execute([$id]); $row=$r->fetch(PDO::FETCH_ASSOC);
            $kalan=floatval($row['sip_miktar']??0)-floatval($row['sip_sevk_miktari']??0);
            echo json_encode(['ok'=>true,'kalan'=>$kalan]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Sil
    if ($action === 'sil') {
        $id=(int)($_POST['id']??0);
        try { $db->prepare("DELETE FROM siparis WHERE sip_id=?")->execute([$id]); echo json_encode(['ok'=>true]); }
        catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Tamamlananları kapat
    if ($action === 'tamamla') {
        try {
            $n=$db->exec("UPDATE siparis SET sip_statu='Tamamlandi'
                WHERE sip_statu='Aktif' AND sip_miktar>0 AND sip_miktar<=sip_sevk_miktari");
            echo json_encode(['ok'=>true,'sayi'=>$n]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Firma toplu pasife al
    if ($action === 'firma_statu') {
        $firma=trim($_POST['firma']??''); $statu=trim($_POST['statu']??'Pasif');
        if(!$firma){ echo json_encode(['ok'=>false]); exit; }
        try {
            $s=$db->prepare("UPDATE siparis SET sip_statu=? WHERE musteri_firma_adi=? AND sip_statu='Aktif'");
            $s->execute([$statu,$firma]);
            echo json_encode(['ok'=>true,'sayi'=>$s->rowCount()]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // İrsaliyeleri düş
    if ($action === 'irsaliye_dus') {
        try {
            $dusulenler=$db->query("SELECT irsaliye_no FROM dusulen_irsaliyeler WHERE durum='aktif'")->fetchAll(PDO::FETCH_COLUMN);
            if(empty($dusulenler)){ echo json_encode(['ok'=>false,'hata'=>'Dusulecek irsaliye yok. Oncelikle Yeni Irsaliyeler sayfasindan irsaliye dusurun.']); exit; }
            if(!$tigerdb_pdo){ echo json_encode(['ok'=>false,'hata'=>'Tiger DB baglantisi yok']); exit; }
            $ph=implode(',',array_fill(0,count($dusulenler),'?'));
            $sql="SELECT CONVERT(VARCHAR,STF.FICHENO) n,IT.CODE k,CL.DEFINITION_ m,SUM(STL.AMOUNT) a
                FROM dbo.LG_222_01_STLINE STL WITH(NOLOCK)
                LEFT JOIN dbo.LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
                LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
                WHERE STF.FICHENO IN ($ph) AND IT.CODE IS NOT NULL GROUP BY STF.FICHENO,IT.CODE,CL.DEFINITION_
                UNION ALL
                SELECT CONVERT(VARCHAR,STF.FICHENO),IT.CODE,CL.DEFINITION_,SUM(STL.AMOUNT)
                FROM dbo.LG_222_02_STLINE STL WITH(NOLOCK)
                LEFT JOIN dbo.LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
                LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
                WHERE STF.FICHENO IN ($ph) AND IT.CODE IS NOT NULL GROUP BY STF.FICHENO,IT.CODE,CL.DEFINITION_";
            $s=$tigerdb_pdo->prepare($sql);
            $s->execute(array_merge($dusulenler,$dusulenler));
            $toplam=[]; $son_irs=[];
            foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r){
                $k=$r['k'].'|'.$r['m'];
                $toplam[$k]=($toplam[$k]??0)+floatval($r['a']);
                $son_irs[$k]=$r['n'];
            }
            $guncellenen=0;
            foreach($toplam as $k=>$mik){
                [$mal,$mus]=explode('|',$k,2); $kalan=$mik;
                $sips=$db->prepare("SELECT sip_id,sip_miktar,sip_sevk_miktari,
                    (sip_miktar-sip_sevk_miktari) km FROM siparis
                    WHERE sip_kodu=? AND sip_statu='Aktif' AND musteri_firma_adi=?
                    AND (sip_miktar-sip_sevk_miktari)>0
                    ORDER BY CASE WHEN sip_sevk_miktari>0 THEN 0 ELSE 1 END,
                    sip_teslim_tarihi ASC,sip_id ASC");
                $sips->execute([$mal,$mus]);
                foreach($sips->fetchAll(PDO::FETCH_ASSOC) as $sip){
                    if($kalan<=0) break;
                    $d=min($kalan,(float)$sip['km']);
                    if($d>0){
                        $db->prepare("UPDATE siparis SET sip_sevk_miktari=sip_sevk_miktari+?,
                            son_irsaliye_2=?,sip_baslama_tarih=CURDATE()
                            WHERE sip_id=?")->execute([$d,$son_irs[$k]??null,$sip['sip_id']]);
                        $kalan-=$d; $guncellenen++;
                    }
                }
            }
            $db->exec("UPDATE siparis SET sip_statu='Tamamlandi'
                WHERE sip_statu='Aktif' AND sip_miktar>0 AND sip_miktar<=sip_sevk_miktari");
            echo json_encode(['ok'=>true,'guncellenen'=>$guncellenen,'irs_sayi'=>count($dusulenler)]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // Excel yükle (BSH veya Portal)
    if ($action === 'excel_yukle') {
        $format = trim($_POST['format']??'portal'); // 'portal' veya 'bsh'
        $musteri= trim($_POST['musteri']??'');
        $ekleyen= $kul_adi;

        if (empty($_FILES['dosya']['tmp_name'])) { echo json_encode(['ok'=>false,'hata'=>'Dosya seçilmedi']); exit; }
        if ($_FILES['dosya']['size'] > 10*1024*1024) { echo json_encode(['ok'=>false,'hata'=>'Dosya 10MB den büyük']); exit; }

        require_once dirname(dirname(__DIR__)).'/core/SimpleXLSX.php';
        $xlsx = new SimpleXLSX($_FILES['dosya']['tmp_name']);
        if (!$xlsx->success()) { echo json_encode(['ok'=>false,'hata'=>'Excel okunamadı: '.$xlsx->error()]); exit; }

        $stmt=$db->prepare("INSERT INTO siparis (sip_no,sip_kodu,sip_baslik,sip_teslim_tarihi,sip_miktar,
            son_irsaliye_no,musteri_firma_adi,sip_aciliyet,sip_durum,sip_statu,sip_tarihi,
            ekleyen,sip_sevk_miktari) VALUES (?,?,?,?,?,?,?,?,?,?,CURDATE(),?,0)");

        $eklendi=0; $hatali=0; $row_n=0;
        foreach ($xlsx->rows() as $fields) {
            $row_n++;
            // BSH: 3. satırdan itibaren (ilk 2 başlık)
            // Portal: 4. satırdan itibaren (ilk 3 başlık)
            $skip = ($format==='bsh') ? 2 : 3;
            if ($row_n <= $skip) continue;

            if ($format === 'bsh') {
                // BSH: [0]=malzeme_kodu, [1]=adi, [2]=sip_kodu/no, [3]=tarih, [4]=miktar
                if (empty($fields[0])) continue;
                $sip_kodu  = trim($fields[0]??'');
                $sip_baslik= trim($fields[1]??'');
                $sip_no    = trim($fields[2]??'');
                $tarih_raw = trim($fields[3]??'');
                $miktar    = intval(preg_replace('/[^0-9]/','',$fields[4]??'0'));
                $son_irs   = null;
            } else {
                // Portal: [3]=malzeme, [4]=adi, [5]=sip_no, [6]=tarih, [7]=miktar, [9]=son_irs
                if (empty($fields[3])) continue;
                $sip_kodu  = trim($fields[3]??'');
                $sip_baslik= trim($fields[4]??'');
                $sip_no    = trim($fields[5]??'');
                $tarih_raw = trim($fields[6]??'');
                $miktar    = intval(preg_replace('/[^0-9]/','',$fields[7]??'0'));
                $son_irs   = trim($fields[9]??'') ?: null;
            }

            if (!$sip_kodu || $miktar < 1) { $hatali++; continue; }

            // Tarih parse
            $tarih = null;
            if ($tarih_raw) {
                // Excel serial number veya string tarih
                if (is_numeric($tarih_raw) && $tarih_raw > 40000) {
                    $unix = ($tarih_raw - 25569) * 86400;
                    $tarih = date('Y-m-d', $unix);
                } elseif (strtotime($tarih_raw)) {
                    $tarih = date('Y-m-d', strtotime($tarih_raw));
                }
            }

            $aciliyet = ($tarih && strtotime($tarih) < time()) ? 'Acil' : 'Normal';
            $firma_adi = $musteri ?: '';

            try {
                $stmt->execute([$sip_no,$sip_kodu,$sip_baslik,$tarih,$miktar,$son_irs,
                    $firma_adi,$aciliyet,'Yeni','Aktif',$ekleyen]);
                $eklendi++;
            } catch(Throwable $e){ $hatali++; }
        }
        echo json_encode(['ok'=>true,'eklendi'=>$eklendi,'hatali'=>$hatali]);
        exit;
    }

    // Mail gönder - beyaz yaka personele sipariş özeti
    if ($action === 'mail_gonder') {
        try {
            require_once dirname(dirname(__DIR__)).'/bolumler/idari/ajax/satin-smtp-send.php';

            // SMTP ayarları
            $smtp_ent=null;
            try {
                $smtp_ent=$db->query("SELECT host,port,kullanici,sifre,ek_parametreler FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
            } catch(Throwable $e2){}
            if (!$smtp_ent) { echo json_encode(['ok'=>false,'hata'=>'SMTP entegrasyonu tanımlanmamış.']); exit; }

            // Şifre çöz
            $key = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
            $sifre='';
            if (!empty($smtp_ent['sifre'])) {
                $enc_raw=trim($smtp_ent['sifre']);
                $dec1=@openssl_decrypt($enc_raw,'AES-256-CBC',$key,0,'1234567890123456');
                $dec2=@openssl_decrypt($enc_raw,'AES-256-CBC','jetone2024secretkey!!',0,'1234567890123456');
                if ($dec1!==false&&strlen($dec1)>0&&ctype_print($dec1)) $sifre=$dec1;
                elseif ($dec2!==false&&strlen($dec2)>0&&ctype_print($dec2)) $sifre=$dec2;
                else { $b64=@base64_decode($enc_raw,true); $sifre=($b64&&ctype_print($b64))?$b64:$enc_raw; }
            }

            $ekPar=json_decode($smtp_ent['ek_parametreler']??'{}',true)?:[];
            $host  =$smtp_ent['host']?:'localhost';
            $port  =(int)($smtp_ent['port']?:587);
            $user  =$smtp_ent['kullanici']??'';
            $enc   =$ekPar['smtp_secure']??($port==465?'ssl':'tls');
            $fromAd=$ekPar['smtp_from_name']??'Jetone ERP';

            // Beyaz yaka emailler
            $email_set=[];
            try {
                $beyazlar=$db->query("SELECT ad,soyad,email FROM personeller WHERE durum='aktif' AND kadro='beyaz_yaka' AND email IS NOT NULL AND email!='' AND email LIKE '%@%'")->fetchAll(PDO::FETCH_ASSOC);
                foreach($beyazlar as $u){
                    $m=trim(strtolower($u['email']));
                    if(filter_var($m,FILTER_VALIDATE_EMAIL)) $email_set[$m]=trim($u['ad'].' '.$u['soyad']);
                }
            } catch(Throwable $e4){}

            // Ekstra adres
            $ekstra=trim($_POST['ekstra_mail']??'');
            if($ekstra) foreach(explode(',',$ekstra) as $em){ $em=trim($em); if(filter_var($em,FILTER_VALIDATE_EMAIL)) $email_set[$em]='Manuel'; }

            if(empty($email_set)){ echo json_encode(['ok'=>false,'hata'=>'bos','mesaj'=>'Beyaz yaka personel email bulunamadı.']); exit; }

            $tarih=date('d.m.Y'); $saat=date('H:i');
            $gonderen_adi=$kul_adi;
            $konu="Sipariş Güncelleme Bildirimi — $tarih";

            // Özet verisi
            $ozet_json=json_decode($_POST['ozet_json']??'{}',true)?:[];

            $html='<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
body{font-family:Arial,sans-serif;font-size:12px;color:#1E293B;margin:0;padding:20px}
h2{color:#1E40AF;margin:0 0 6px 0;font-size:16px}
.sub{color:#64748B;font-size:11px;margin-bottom:16px}
table{border-collapse:collapse;width:100%;font-size:11px;margin-bottom:12px}
th{background:#1E40AF;color:#fff;padding:6px 10px;border:1px solid #2d5986;text-align:left}
td{padding:4px 8px;border:1px solid #E2E8F0;vertical-align:middle}
tr:nth-child(even) td{background:#F8FAFC}
.badge{padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700}
.acil{background:#FEE2E2;color:#991B1B}
.normal{background:#DBEAFE;color:#1E40AF}
.yetersiz{background:#FEE2E2;color:#991B1B}
.yeterli{background:#D1FAE5;color:#065F46}
.footer{color:#94A3B8;font-size:10px;margin-top:16px;border-top:1px solid #E2E8F0;padding-top:8px}
</style></head><body>';
            $html.="<h2>🛒 Sipariş Güncelleme Bildirimi</h2>";
            $html.="<div class='sub'>Güncelleyen: <b>$gonderen_adi</b> &nbsp;|&nbsp; Tarih: <b>$tarih $saat</b></div>";

            // Sadece bildirim - tablo yok
            $html.='<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:14px 18px;margin-bottom:16px">';
            $html.='<div style="font-size:14px;font-weight:700;color:#1E40AF;margin-bottom:6px">📋 Sipariş Listesi Güncellendi</div>';
            $html.='<div style="font-size:12px;color:#374151">Aktif sipariş listesi güncelleme işlemi yapılmıştır. Güncel siparişleri görmek için ERP sistemine giriş yapınız.</div>';
            $html.='</div>';

            $html.="<div class='footer'>Bu mail Jetone ERP tarafından otomatik gönderilmiştir — $tarih $saat</div>";
            $html.='</body></html>';

            $sonuc=satinSmtpSend($host,$port,$enc,$user,$sifre,$fromAd,array_keys($email_set),$konu,$html);
            if($sonuc['ok']) echo json_encode(['ok'=>true,'sayi'=>count($email_set)]);
            else echo json_encode(['ok'=>false,'hata'=>$sonuc['hata']??'Gönderilemedi']);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen islem']); exit;
}

// ── SAYFA ────────────────────────────────────────────────────────────────────
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

try { $db->exec("CREATE TABLE IF NOT EXISTS `siparis` (
    `sip_id` INT AUTO_INCREMENT PRIMARY KEY, `sip_statu` VARCHAR(10) DEFAULT 'Aktif',
    `musteri_firma_adi` VARCHAR(250) DEFAULT NULL, `sip_tarihi` DATE DEFAULT NULL,
    `ekleyen` VARCHAR(250) DEFAULT NULL, `guncelleyen` VARCHAR(250) DEFAULT NULL,
    `sip_no` VARCHAR(50) DEFAULT NULL, `sip_kodu` VARCHAR(255) NOT NULL DEFAULT '',
    `sip_baslik` VARCHAR(255) DEFAULT NULL, `sip_miktar` INT DEFAULT NULL,
    `sip_sevk_miktari` INT DEFAULT NULL, `sip_teslim_tarihi` DATE DEFAULT NULL,
    `son_irsaliye_no` VARCHAR(50) DEFAULT NULL, `son_irsaliye_2` VARCHAR(50) DEFAULT NULL,
    `sip_aciliyet` VARCHAR(100) DEFAULT 'Normal', `sip_durum` VARCHAR(100) DEFAULT 'Yeni',
    `sip_detay` TEXT DEFAULT NULL, `sip_ucret` DECIMAL(10,2) DEFAULT NULL,
    `sip_baslama_tarih` DATE DEFAULT NULL, `gecikme_nedeni` TEXT DEFAULT NULL,
    `dosya_yolu` VARCHAR(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci"); } catch(Throwable $e){}

$bugun = date('Y-m-d');
$tumunu = isset($_GET['tumunu']);

$siparisler=[];
try {
    $s=$db->query("SELECT * FROM siparis WHERE sip_statu='Aktif' ORDER BY sip_teslim_tarihi ASC, musteri_firma_adi ASC");
    $siparisler=$s->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){}

$stoklar=[];
if ($tigerdb_pdo) { try {
    $rows=$tigerdb_pdo->query("SELECT IT.CODE k, ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s FROM dbo.LG_222_ITEMS IT WITH(NOLOCK) LEFT JOIN dbo.LV_222_02_STINVTOT LV WITH(NOLOCK) ON LV.STOCKREF=IT.LOGICALREF WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r) $stoklar[$r['k']]=(float)$r['s'];
} catch(Throwable $e){} }

$tiger_cariler=[];
if ($tigerdb_pdo) { try {
    $tiger_cariler=$tigerdb_pdo->query("SELECT DISTINCT CL.CODE kod, CL.DEFINITION_ ad FROM dbo.LG_222_CLCARD CL WITH(NOLOCK) WHERE CL.CODE LIKE '120%' AND CL.DEFINITION_ IS NOT NULL ORDER BY CL.DEFINITION_ ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){} }

$firmalar=[];
try { $firmalar=$db->query("SELECT DISTINCT musteri_firma_adi FROM siparis WHERE sip_statu='Aktif' AND musteri_firma_adi IS NOT NULL ORDER BY musteri_firma_adi")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e){}

$rezervasyon=$stoklar;
foreach($siparisler as $sip){
    $k=floatval($sip['sip_miktar'])-floatval($sip['sip_sevk_miktari']);
    if(!isset($rezervasyon[$sip['sip_kodu']])) $rezervasyon[$sip['sip_kodu']]=0;
    $rezervasyon[$sip['sip_kodu']]-=$k;
}
?>
<style>
.sip-edit{border-bottom:1px dashed #94A3B8;cursor:text;display:inline-block;min-width:30px;padding:1px 2px;border-radius:2px}
.sip-edit:focus{outline:2px solid var(--t);background:#EFF6FF;border-bottom-color:transparent}
.sip-saving{background:#FEF9C3!important}
.sip-saved{background:#D1FAE5!important}
.sip-err{background:#FEE2E2!important;outline:2px solid #EF4444!important}
.gecmis-row>td{background:#FFF0F0!important}
.acil-row>td{background:#FFF5F5!important}
.bugun-row>td{background:#FFFBEB!important}
#sipIslemler{display:none;margin-bottom:12px}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🛒 Siparişler</h1>
    <div class="s-yol">Satış / <b>Aktif Siparişler</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo count($siparisler);?> kayıt</span>
    </div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
    <button onclick="sipTamamla()" style="background:#065F46;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">✅ Tamamla</button>
    <button onclick="sipIrsaliyeDus()" id="btnDus" style="background:#1E40AF;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">📥 İrsaliye Düş</button>
    <button onclick="sipMailGonder()" id="btnMail" style="background:#0369A1;color:#fff;border:none;padding:5px 10px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">✉ Mail</button>
    <button onclick="document.getElementById('sipIslemler').style.display=document.getElementById('sipIslemler').style.display==='none'?'block':'none'"
      style="background:var(--bg);border:1px solid var(--kenar);padding:5px 10px;border-radius:6px;font-size:12px;cursor:pointer">⚙️ İşlemler</button>
  </div>
</div>

<div id="sipIslemler">
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-bottom:4px">
  <div class="kart" style="padding:12px">
    <div style="font-weight:700;font-size:12px;margin-bottom:8px">🏢 Firmayı Kaldır</div>
    <select id="firmaSecim" class="form-alan" style="margin-bottom:8px">
      <option value="">Firma seçin...</option>
      <?php foreach($firmalar as $f):?><option><?php echo htmlspecialchars($f);?></option><?php endforeach;?>
    </select>
    <button onclick="sipFirmaStatu('Pasif')" style="background:#DC2626;color:#fff;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;width:100%">Siparişleri Kaldır</button>
  </div>
  <div class="kart" style="padding:12px">
    <div style="font-weight:700;font-size:12px;margin-bottom:4px">📊 Portal Yükle</div>
    <div style="font-size:10px;color:var(--m2);margin-bottom:6px">4=Malzeme, 7=Tarih, 8=Miktar</div>
    <select id="portalFirma" class="form-alan" style="margin-bottom:6px"><option value="">Firma...</option>
    <?php foreach($tiger_cariler as $tc):?><option value="<?php echo htmlspecialchars($tc['ad']);?>"><?php echo htmlspecialchars($tc['ad']);?></option><?php endforeach;?></select>
    <input type="file" id="portalDosya" accept=".xlsx" class="form-alan" style="margin-bottom:6px">
    <button onclick="sipExcelYukle('portal')" style="background:#1E40AF;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:11px;cursor:pointer;width:100%">📤 Yükle</button>
    <div id="portalSonuc" style="font-size:10px;display:none;margin-top:4px"></div>
  </div>
  <div class="kart" style="padding:12px">
    <div style="font-weight:700;font-size:12px;margin-bottom:4px">🏭 BSH Yükle</div>
    <div style="font-size:10px;color:var(--m2);margin-bottom:6px">1=Malzeme, 4=Tarih, 5=Miktar</div>
    <select id="bshFirma" class="form-alan" style="margin-bottom:6px"><option value="">Firma...</option>
    <?php foreach($tiger_cariler as $tc):?><option value="<?php echo htmlspecialchars($tc['ad']);?>"><?php echo htmlspecialchars($tc['ad']);?></option><?php endforeach;?></select>
    <input type="file" id="bshDosya" accept=".xlsx" class="form-alan" style="margin-bottom:6px">
    <button onclick="sipExcelYukle('bsh')" style="background:#7C3AED;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:11px;cursor:pointer;width:100%">📤 Yükle</button>
    <div id="bshSonuc" style="font-size:10px;display:none;margin-top:4px"></div>
  </div>
</div>
</div>

<?php if(!empty($siparisler)): ?>
<div class="kart" style="overflow:hidden">
<div style="overflow-x:auto">
<table class="tablo" id="tblSip" style="border-collapse:collapse">
  <thead>
    <tr>
      <th>#</th>
      <th>Stok Kodu</th>
      <th>Ürün Adı</th>
      <th>Sipariş No</th>
      <th>Teslim Tarihi ✏</th>
      <th style="text-align:right">Sipariş Miktarı ✏</th>
      <th>Son İrs. No</th>
      <th style="text-align:right">Sevk ✏</th>
      <th style="text-align:right">Kalan</th>
      <th>Firma</th>
      <th>Aciliyet</th>
      <th>Durum</th>
      <th>Gecikme Açık. ✏</th>
      <th style="text-align:right">Stok</th>
      <th style="text-align:right">Rezerv.</th>
      <th style="text-align:center">İşlem</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>#</th><th>Stok Kodu</th><th>Ürün Adı</th><th>Sipariş No</th>
      <th>Teslim Tarihi</th><th>Sipariş</th><th>Son İrs.</th>
      <th>Sevk</th><th>Kalan</th><th>Firma</th><th>Aciliyet</th>
      <th>Durum</th><th>Gecikme Açık.</th><th>Stok</th><th>Rezerv.</th><th></th>
    </tr>
  </tfoot>
  <tbody>
  <?php $say=0; foreach($siparisler as $sip):
      $say++;
      $kod   = $sip['sip_kodu'];
      $mik   = floatval($sip['sip_miktar']);
      $sevk  = floatval($sip['sip_sevk_miktari']);
      $kalan = $mik - $sevk;
      $stok  = $stoklar[$kod]??0;
      $rezv  = $rezervasyon[$kod]??0;
      $t     = $sip['sip_teslim_tarihi']??'';
      $is_gecmis = $t && $t < $bugun && $kalan>0;
      $is_bugun  = $t === $bugun;
      $is_acil   = $sip['sip_aciliyet']==='Acil';
      $row_class = $is_gecmis?'gecmis-row':($is_acil?'acil-row':($is_bugun?'bugun-row':''));
  ?>
  <tr class="<?php echo $row_class;?>" data-id="<?php echo $sip['sip_id'];?>">
    <td style="color:var(--m2);font-size:11px"><?php echo $say;?></td>
    <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($kod);?></code></td>
    <td style="white-space:nowrap"><?php echo htmlspecialchars($sip['sip_baslik']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['sip_no']??'');?></td>
    <td><span class="sip-edit" contenteditable="true" data-id="<?php echo $sip['sip_id'];?>" data-kolon="sip_teslim_tarihi" onblur="sipKaydet(this)"
      style="<?php echo $is_gecmis?'color:#DC2626;font-weight:700':($is_bugun?'color:#D97706;font-weight:700':'');?>"><?php echo htmlspecialchars($t);?></span></td>
    <td style="text-align:right"><span class="sip-edit" contenteditable="true" data-id="<?php echo $sip['sip_id'];?>" data-kolon="sip_miktar" onblur="sipKaydet(this)"><?php echo number_format($mik,0,',','.');?></span></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['son_irsaliye_no']??'');?></td>
    <td style="text-align:right"><span class="sip-edit" contenteditable="true" data-id="<?php echo $sip['sip_id'];?>" data-kolon="sip_sevk_miktari" onblur="sipKaydet(this)"><?php echo number_format($sevk,0,',','.');?></span></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $kalan>0?'#DC2626':'#059669';?>" id="kalan_<?php echo $sip['sip_id'];?>"><?php echo number_format($kalan,0,',','.');?></td>
    <td style="white-space:nowrap;font-size:12px"><?php echo htmlspecialchars($sip['musteri_firma_adi']??'');?></td>
    <td><?php if($is_acil):?><span style="background:#FEE2E2;color:#DC2626;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:700">Acil</span><?php else:?><span style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($sip['sip_aciliyet']??'');?></span><?php endif;?></td>
    <td><span style="background:#F1F5F9;color:#374151;padding:2px 6px;border-radius:4px;font-size:10px"><?php echo htmlspecialchars($sip['sip_durum']??'');?></span></td>
    <td><span class="sip-edit" contenteditable="true" data-id="<?php echo $sip['sip_id'];?>" data-kolon="gecikme_nedeni" onblur="sipKaydet(this)" style="white-space:normal;min-width:40px"><?php echo htmlspecialchars($sip['gecikme_nedeni']??'');?></span></td>
    <td style="text-align:right;font-size:12px;color:var(--m2)"><?php echo number_format($stok,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $rezv<0?'#DC2626':'#059669';?>"><?php echo number_format($rezv,0,',','.');?></td>
    <td style="text-align:center"><button onclick="sipSil(<?php echo $sip['sip_id'];?>,this)" style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:11px">🗑</button></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<?php else:?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:24px;text-align:center;color:var(--m2)">Aktif sipariş bulunamadı.</div>
<?php endif;?>

<script>
function sipPost(d,cb){
  var fd=new FormData();Object.entries(d).forEach(function(e){fd.append(e[0],e[1]||'');});
  fetch(window.location.href.split('?')[0]+'?sayfa=satis-siparisler',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb).catch(function(e){alert('Hata:'+e);});
}
function sipKaydet(el){
  var id=el.dataset.id,kolon=el.dataset.kolon;
  var deger=el.textContent.trim().replace(/\./g,'').replace(',','.');
  el.classList.add('sip-saving');
  sipPost({sip_action:'guncelle',id:id,kolon:kolon,deger:deger},function(d){
    el.classList.remove('sip-saving');
    if(d.ok){el.classList.add('sip-saved');setTimeout(function(){el.classList.remove('sip-saved');},1500);
      if(d.kalan!==undefined){var ke=document.getElementById('kalan_'+id);if(ke){var k=parseFloat(d.kalan);ke.textContent=k.toLocaleString('tr-TR',{maximumFractionDigits:0});ke.style.color=k>0?'#DC2626':'#059669';}}
    }else{el.classList.add('sip-err');setTimeout(function(){el.classList.remove('sip-err');},2000);}
  });
}
function sipSil(id,btn){
  if(!confirm('Siparişi silmek istediğinize emin misiniz?'))return;
  sipPost({sip_action:'sil',id:id},function(d){if(d.ok)btn.closest('tr').remove();else alert(d.hata||'');});
}
function sipTamamla(){
  if(!confirm('Tamamlananlar kaldırılacak.'))return;
  sipPost({sip_action:'tamamla'},function(d){if(d.ok){alert(d.sayi+' kaldırıldı.');location.reload();}else alert(d.hata||'');});
}
function sipIrsaliyeDus(){
  var btn=document.getElementById('btnDus');btn.disabled=true;btn.textContent='⏳';
  sipPost({sip_action:'irsaliye_dus'},function(d){
    btn.disabled=false;btn.textContent='📥 İrsaliye Düş';
    if(d.ok){alert(d.irs_sayi+' irsaliye işlendi.');location.reload();}else alert(d.hata||'');
  });
}
function sipMailGonder(ekstra){
  var btn=document.getElementById('btnMail');btn.disabled=true;btn.textContent='⏳';
  var fd=new FormData();fd.append('sip_action','mail_gonder');
  fd.append('ozet_json',JSON.stringify({toplam:<?php echo count($siparisler);?>,acil:0,yetersiz:0,tamamlanan:0}));
  if(ekstra)fd.append('ekstra_mail',ekstra);
  fetch(window.location.href.split('?')[0]+'?sayfa=satis-siparisler',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json()}).then(function(d){
    btn.disabled=false;btn.textContent='✉ Mail';
    if(d.ok)alert('✅ '+d.sayi+' alıcı');
    else if(d.hata==='bos'){var a=prompt(d.mesaj||'','');if(a)sipMailGonder(a);}
    else alert(d.hata||'');
  }).catch(function(e){btn.disabled=false;btn.textContent='✉ Mail';alert(e);});
}
function sipFirmaStatu(statu){
  var f=document.getElementById('firmaSecim').value;
  if(!f){alert('Firma seçin.');return;}
  if(!confirm(f+' → '+statu))return;
  sipPost({sip_action:'firma_statu',firma:f,statu:statu},function(d){if(d.ok){alert(d.sayi+' güncellendi.');location.reload();}else alert(d.hata||'');});
}
function sipExcelYukle(fmt){
  var dEl=document.getElementById(fmt+'Dosya'),fEl=document.getElementById(fmt+'Firma'),sEl=document.getElementById(fmt+'Sonuc');
  if(!dEl.files[0]){alert('Dosya seçin.');return;}if(!fEl.value){alert('Firma seçin.');return;}
  var fd=new FormData();fd.append('sip_action','excel_yukle');fd.append('format',fmt);fd.append('musteri',fEl.value);fd.append('dosya',dEl.files[0]);
  sEl.style.display='block';sEl.style.background='#FEF3C7';sEl.innerHTML='⏳ Yükleniyor...';
  fetch(window.location.href.split('?')[0]+'?sayfa=satis-siparisler',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(function(d){
    if(d.ok){sEl.style.background='#D1FAE5';sEl.innerHTML='✅ '+d.eklendi+' kayıt';dEl.value='';setTimeout(function(){location.reload();},1200);}
    else{sEl.style.background='#FEE2E2';sEl.innerHTML='❌ '+(d.hata||'');}
  });
}

$(document).ready(function(){
  if(!$.fn.DataTable||$.fn.DataTable.isDataTable('#tblSip'))return;
  if($('#tblSip tbody tr').length===0)return;
  $('#tblSip').DataTable({
    paging:false,autoWidth:false,scrollX:true,scrollY:'calc(100vh - 280px)',scrollCollapse:true,
    order:[[4,'asc']],
    columnDefs:[{orderable:false,targets:15}],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Siparisler',exportOptions:{columns:':not(:last-child)'}}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(idx){
        if(idx===15)return;
        var col=this,th=$(col.footer());
        if(!th||!th.length)return;
        var lbl=th.text().trim();if(!lbl){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>22?v.substr(0,22)+'...':v)+'</option>');});
      });
    }
  });
});
</script>
