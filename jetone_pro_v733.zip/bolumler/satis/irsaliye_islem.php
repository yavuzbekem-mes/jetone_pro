<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$action      = trim($_POST['action'] ?? '');
$irsaliye_no = trim($_POST['irsaliye_no'] ?? '');
$firma       = trim($_POST['firma'] ?? '');

if (!$action || !$irsaliye_no) {
    echo json_encode(['ok'=>false,'message'=>'Eksik parametre']);
    exit;
}

try {
    if ($action === 'dus') {
        // Tablo yoksa oluştur
        $db->exec("CREATE TABLE IF NOT EXISTS `dusulen_irsaliyeler` (
            `id`           INT AUTO_INCREMENT PRIMARY KEY,
            `irsaliye_no`  VARCHAR(50) NOT NULL,
            `firma`        VARCHAR(255) DEFAULT '',
            `durum`        ENUM('aktif','iptal') DEFAULT 'aktif',
            `olusturan_id` INT DEFAULT 0,
            `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_irsaliye` (`irsaliye_no`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");

        $stmt = $db->prepare("INSERT INTO dusulen_irsaliyeler (irsaliye_no, firma, durum, olusturan_id)
            VALUES (?, ?, 'aktif', ?)
            ON DUPLICATE KEY UPDATE firma=VALUES(firma), durum='aktif', guncelleme=NOW()");
        $stmt->execute([$irsaliye_no, $firma, $_SESSION['kullanici_id'] ?? 0]);
        echo json_encode(['ok'=>true,'message'=>"İrsaliye düşüldü: {$irsaliye_no}"]);

    } elseif ($action === 'iptal') {
        $stmt = $db->prepare("UPDATE dusulen_irsaliyeler SET durum='iptal', guncelleme=NOW() WHERE irsaliye_no=?");
        $stmt->execute([$irsaliye_no]);
        echo json_encode(['ok'=>true,'message'=>"İptal edildi: {$irsaliye_no}"]);

    } else {
        echo json_encode(['ok'=>false,'message'=>'Bilinmeyen işlem']);
    }
} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'message'=>'Hata: '.$e->getMessage()]);
}
exit;
