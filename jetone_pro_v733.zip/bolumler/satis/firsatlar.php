<?php require_once dirname(dirname(__DIR__)) . '/core/db.php'; require_once dirname(dirname(__DIR__)) . '/core/auth.php'; Auth::zorunlu(); ?>
<div class='s-bar'><div><h1 class='s-bas'>Satış — firsatlar</h1><div class='s-yol'>Satış & CRM / <b>firsatlar</b></div></div></div>
<div class='s-body'><div class='kart' style='padding:40px;text-align:center;color:var(--m2)'><div style='font-size:40px;margin-bottom:12px'>💼</div><div style='font-size:15px;font-weight:700'>Geliştirme Aşamasında</div></div></div>
