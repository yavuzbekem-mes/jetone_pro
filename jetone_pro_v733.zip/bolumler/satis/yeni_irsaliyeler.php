<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata = '';
$satirlar = []; // Her stok kalemi ayrı satır
$dusulen_set = [];

// Tablo yoksa oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `dusulen_irsaliyeler` (
        `id`           INT AUTO_INCREMENT PRIMARY KEY,
        `irsaliye_no`  VARCHAR(50) NOT NULL,
        `firma`        VARCHAR(255) DEFAULT '',
        `durum`        ENUM('aktif','iptal') DEFAULT 'aktif',
        `olusturan_id` INT DEFAULT 0,
        `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY `uk_irsaliye` (`irsaliye_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

// Düşülen irsaliyeleri çek
try {
    $rows = $db->query("SELECT irsaliye_no FROM dusulen_irsaliyeler WHERE durum='aktif'")->fetchAll(PDO::FETCH_COLUMN);
    $dusulen_set = array_flip($rows);
} catch(Throwable $e) {}

// JIT stok kodları (arka plan mavi)
$jit_stok_set = [];
try {
    $jit_rows = $db->query("SELECT stok_kodu FROM jit_dahil_kodlar2 WHERE durum='jit'")->fetchAll(PDO::FETCH_COLUMN);
    $jit_stok_set = array_flip($jit_rows);
} catch(Throwable $e) {}

// Tiger'dan son 1 aydaki toptan satış irsaliyeleri - her stok kalemi ayrı satır
if ($tiger_ok) {
    try {
        $sql = "SELECT
            CONVERT(VARCHAR,STF.FICHENO) AS irsaliye_no,
            CONVERT(VARCHAR,STL.DATE_,104) AS tarih,
            CL.DEFINITION_ AS musteri,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END AS stok_kodu,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END AS stok_adi,
            STL.AMOUNT AS miktar,
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,'') AS aciklama,
            ISNULL(STF.SPECODE,'') AS tur_kodu,
            '01' AS ambar,
            STL.DATE_ AS sort_tarih
        FROM dbo.LG_222_01_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.TRCODE IN (8)
          AND STL.DATE_ >= DATEADD(MONTH,-1,GETDATE())
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)

        UNION ALL

        SELECT
            CONVERT(VARCHAR,STF.FICHENO),
            CONVERT(VARCHAR,STL.DATE_,104),
            CL.DEFINITION_,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END,
            STL.AMOUNT,
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,''),
            ISNULL(STF.SPECODE,''),
            '02',
            STL.DATE_
        FROM dbo.LG_222_02_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.TRCODE IN (8)
          AND STL.DATE_ >= DATEADD(MONTH,-1,GETDATE())
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)

        ORDER BY sort_tarih DESC, irsaliye_no DESC";

        $satirlar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// Düşülmüş irsaliyeleri filtrele
$ham_satirlar = array_filter($satirlar, fn($r) => !isset($dusulen_set[$r['irsaliye_no']]));

// Aynı irsaliye + stok kodu kombinasyonlarını grupla, miktarları topla
$grup_map = [];
foreach ($ham_satirlar as $r) {
    $key = $r['irsaliye_no'] . '||' . ($r['stok_kodu']??'');
    if (!isset($grup_map[$key])) {
        $grup_map[$key] = $r;
        $grup_map[$key]['miktar'] = floatval($r['miktar']??0);
    } else {
        $grup_map[$key]['miktar'] += floatval($r['miktar']??0);
    }
}
$yeni_satirlar = array_values($grup_map);
?>
<style>
#tbl-yeni-irs th,#tbl-yeni-irs td,
#tbl-dusulen-irs th,#tbl-dusulen-irs td{border:1px solid #CBD5E1!important;}
#tbl-yeni-irs thead th,#tbl-dusulen-irs thead th{border-bottom:2px solid #94A3B8!important;}
</style>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📦 Yeni Satış İrsaliyeleri</h1>
    <div class="s-yol">Satış / <b>Düşülmemiş İrsaliyeler</b>
      <?php if($tiger_ok):?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <span style="font-size:11px;color:var(--m2);margin-left:3px">(<?php
        $benzersiz = count(array_unique(array_column(array_values($yeni_satirlar),'irsaliye_no')));
        echo $benzersiz;?> irsaliye, <?php echo count($yeni_satirlar);?> kalem)</span>
      <?php else:?>
      <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Bağlantı Yok</span>
      <?php endif;?>
    </div>
    <button onclick="irsHepsiniDus()" id="btnHepsiniDus"
      style="background:#DC2626;color:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">
      📥 Tümünü Düş
    </button>
  </div>
</div>

<div class="s-body">
<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php else:?>

<?php if(!empty($yeni_satirlar)): ?>
<div class="kart" style="overflow:hidden">
  <table class="tablo" id="tbl-yeni-irs" style="border-collapse:collapse">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="text-align:center;width:80px">İşlem</th>
        <th>İrsaliye No</th>
        <th>Tarih</th>
        <th>Müşteri</th>
        <th>Stok Kodu</th>
        <th>Stok Adı</th>
        <th style="text-align:right">Miktar</th>
        <th>Tür Kodu</th>
        <th>Açıklama</th>
        <th>Ambar</th>
      </tr>
    </thead>
    <tfoot>
      <tr><th></th><th>İrsaliye No</th><th>Tarih</th><th>Müşteri</th>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Miktar</th><th>Tür Kodu</th><th>Açıklama</th><th>Ambar</th></tr>
    </tfoot>
    <tbody>
    <?php
    $gosterilen_irs = []; // Düş butonu sadece ilk satırda
    foreach($yeni_satirlar as $r):
        $no     = $r['irsaliye_no'];
        $ilk_mi = !in_array($no, $gosterilen_irs);
        if ($ilk_mi) $gosterilen_irs[] = $no;
    ?>
    <?php $jit_bg = isset($jit_stok_set[$r['stok_kodu']??'']) ? 'background:#DBEAFE' : ''; ?>
    <tr data-no="<?php echo htmlspecialchars($no);?>" style="<?php echo $jit_bg;?>">
      <td style="text-align:center;white-space:nowrap">
        <?php if($ilk_mi): ?>
        <button onclick="irsDus(<?php echo htmlspecialchars(json_encode($no));?>,<?php echo htmlspecialchars(json_encode($r['musteri']??''));?>)"
          style="background:linear-gradient(135deg,#2d5986,#1e3a5f);color:#fff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
          📥 Düş
        </button>
        <?php endif;?>
      </td>
      <td style="font-weight:700;color:#0369A1;white-space:nowrap"><?php echo htmlspecialchars($no);?></td>
      <td style="font-size:11px;white-space:nowrap" data-order="<?php echo date('Y-m-d', strtotime($r['sort_tarih'] ?? $r['tarih'] ?? '1970-01-01'));?>"><?php echo htmlspecialchars($r['tarih']??'');?></td>
      <td style="white-space:nowrap"><?php echo htmlspecialchars($r['musteri']??'');?></td>
      <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']??'');?></code></td>
      <td style="white-space:nowrap"><?php echo htmlspecialchars($r['stok_adi']??'');?></td>
      <td style="text-align:right"><?php echo number_format((float)($r['miktar']??0),0,',','.');?></td>
      <td style="font-size:11px"><?php echo htmlspecialchars($r['tur_kodu']??'');?></td>
      <td style="font-size:11px;white-space:nowrap"><?php echo htmlspecialchars(trim($r['aciklama']??''));?></td>
      <td style="font-size:11px;text-align:center"><?php echo htmlspecialchars($r['ambar']??'');?></td>
    </tr>
    <?php endforeach;?>
    <?php if(empty($yeni_satirlar)):?>
    <?php endif; // empty satirlar ?>
    </tbody>
  </table>
</div>

<?php else: ?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:20px;text-align:center;color:var(--m2)">Düşülmemiş irsaliye bulunamadı.</div>
<?php endif;?>
<?php endif; // tiger_ok ?>
</div>

<script>
function irsHepsiniDus() {
  // Tablodaki tüm görünür irsaliye no'larını topla
  var irs_set = {};
  var irs_musteri = {};
  document.querySelectorAll('#tbl-yeni-irs tbody tr[data-no]').forEach(function(tr){
    var no = tr.dataset.no;
    if(!no || irs_set[no]) return;
    irs_set[no] = true;
    // Müşteri: 4. td (index 3)
    var musteri = tr.cells[3] ? tr.cells[3].textContent.trim() : '';
    irs_musteri[no] = musteri;
  });
  var nosArr = Object.keys(irs_set);
  if(!nosArr.length){ alert('Düşülecek irsaliye bulunamadı.'); return; }
  if(!confirm(nosArr.length + ' irsaliyeyi tümünü düşmek istediğinize emin misiniz?')) return;

  var btn = document.getElementById('btnHepsiniDus');
  btn.disabled = true; btn.textContent = '⏳ Düşülüyor...';

  // Sırayla hepsini düş
  var kalan = nosArr.slice();
  var basarili = 0, hatali = 0;

  function birDus() {
    if(!kalan.length) {
      btn.disabled = false; btn.textContent = '📥 Tümünü Düş';
      alert('✅ ' + basarili + ' irsaliye düşüldü' + (hatali > 0 ? ', ' + hatali + ' hata' : '') + '. Sayfa yenileniyor...');
      location.reload(); return;
    }
    var no = kalan.shift();
    var fd = new FormData();
    fd.append('action','dus'); fd.append('irsaliye_no',no); fd.append('firma',irs_musteri[no]||'');
    fetch('<?php echo BASE_URL;?>/bolumler/satis/irsaliye_islem.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(d){ if(d.ok) basarili++; else hatali++; birDus(); })
    .catch(function(){ hatali++; birDus(); });
  }
  birDus();
}

function irsDus(no, firma) {
  if(!confirm(no+' numaralı irsaliyeyi düşmek istediğinize emin misiniz?')) return;
  var fd=new FormData();
  fd.append('action','dus');
  fd.append('irsaliye_no',no);
  fd.append('firma',firma||'');
  fetch('<?php echo BASE_URL;?>/bolumler/satis/irsaliye_islem.php',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    if(d.ok){
      // Aynı irsaliye no'lu tüm satırları kaldır
      document.querySelectorAll('#tbl-yeni-irs tr[data-no="'+no+'"]').forEach(function(tr){tr.remove();});
      alert('✅ '+d.message);
    } else alert('❌ '+d.message);
  }).catch(function(e){alert('Hata: '+e);});
}

$(document).ready(function(){
  if(typeof $ === 'undefined' || !$.fn || !$.fn.DataTable) return;
  if(!$.fn.DataTable||$.fn.DataTable.isDataTable('#tbl-yeni-irs'))return;
  if($('#tbl-yeni-irs tbody tr').length===0)return; // Veri yok
  $('#tbl-yeni-irs').DataTable({
    paging:false,autoWidth:false,scrollY:'560px',scrollCollapse:true,
    order:[[1,'desc']],
    columnDefs:[{orderable:false,targets:0}],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Yeni_Irsaliyeler',exportOptions:{columns:':not(:first-child)'}}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(idx){
        var col=this,th=$(col.footer());
        if(!th||!th.length||idx===0)return;
        var lbl=th.text().trim();if(!lbl){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>25?v.substr(0,25)+'…':v)+'</option>');});
      });
    }
  });
});
</script>
