<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
set_time_limit(0);

// ── VERİ TOPLAMA ────────────────────────────────────────────────────────────
$bugun    = date('Y-m-d');
$hafta_bas= date('Y-m-d', strtotime('monday this week'));
$ay_bas   = date('Y-m-01');
$ay_son   = date('Y-m-t');

// Genel sipariş istatistikleri
$gen = [];
try {
    // Firma bazlı özet
    $gen['firmalar'] = $db->query("
        SELECT
            musteri_firma_adi AS firma,
            COUNT(*) AS toplam,
            SUM(CASE WHEN sip_statu='Aktif' THEN 1 ELSE 0 END) AS aktif,
            SUM(CASE WHEN sip_statu='Aktif' AND sip_aciliyet='Acil' THEN 1 ELSE 0 END) AS acil,
            SUM(CASE WHEN sip_statu='Aktif' THEN sip_miktar ELSE 0 END) AS toplam_miktar,
            SUM(CASE WHEN sip_statu='Aktif' THEN sip_sevk_miktari ELSE 0 END) AS sevk_miktar,
            SUM(CASE WHEN sip_statu='Aktif' THEN (sip_miktar-sip_sevk_miktari) ELSE 0 END) AS kalan_miktar,
            SUM(CASE WHEN sip_statu='Aktif' AND sip_teslim_tarihi < CURDATE() THEN 1 ELSE 0 END) AS gecikme_sayisi,
            SUM(CASE WHEN sip_statu='Aktif' AND sip_teslim_tarihi = CURDATE() THEN 1 ELSE 0 END) AS bugun_sayisi,
            SUM(CASE WHEN sip_statu='Aktif' AND sip_teslim_tarihi BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS hafta_sayisi,
            MIN(CASE WHEN sip_statu='Aktif' AND sip_teslim_tarihi>=CURDATE() THEN sip_teslim_tarihi END) AS en_yakin_teslim
        FROM siparis
        WHERE musteri_firma_adi IS NOT NULL
        GROUP BY musteri_firma_adi
        ORDER BY gecikme_sayisi DESC, acil DESC, kalan_miktar DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Günlük trend - son 30 gün
    $gen['gunluk'] = $db->query("
        SELECT
            sip_teslim_tarihi AS tarih,
            COUNT(*) AS siparis_sayisi,
            SUM(sip_miktar-sip_sevk_miktari) AS kalan_miktar
        FROM siparis
        WHERE sip_statu='Aktif'
          AND sip_teslim_tarihi BETWEEN DATE_SUB(CURDATE(),INTERVAL 30 DAY) AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)
        GROUP BY sip_teslim_tarihi
        ORDER BY sip_teslim_tarihi ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Özet rakamlar
    $gen['ozet'] = $db->query("
        SELECT
            COUNT(*) AS toplam,
            SUM(CASE WHEN sip_aciliyet='Acil' THEN 1 ELSE 0 END) AS acil,
            SUM(CASE WHEN sip_teslim_tarihi < CURDATE() THEN 1 ELSE 0 END) AS gecikme,
            SUM(CASE WHEN sip_teslim_tarihi = CURDATE() THEN 1 ELSE 0 END) AS bugun,
            SUM(CASE WHEN sip_teslim_tarihi BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS bu_hafta,
            SUM(sip_miktar-sip_sevk_miktari) AS toplam_kalan,
            COUNT(DISTINCT musteri_firma_adi) AS firma_sayisi
        FROM siparis WHERE sip_statu='Aktif'
    ")->fetch(PDO::FETCH_ASSOC);

} catch(Throwable $e){ $gen['hata']=$e->getMessage(); }

// JIT sipariş istatistikleri
$jit = [];
try {
    $jit['firmalar'] = $db->query("
        SELECT
            musteri_firma_adi AS firma,
            COUNT(*) AS toplam,
            SUM(CASE WHEN jit_sip_statu='Aktif' THEN 1 ELSE 0 END) AS aktif,
            SUM(CASE WHEN jit_sip_statu='Aktif' AND jit_sip_aciliyet='Acil' THEN 1 ELSE 0 END) AS acil,
            SUM(CASE WHEN jit_sip_statu='Aktif' THEN jit_sip_miktar ELSE 0 END) AS toplam_miktar,
            SUM(CASE WHEN jit_sip_statu='Aktif' THEN jit_sip_sevk_miktari ELSE 0 END) AS sevk_miktar,
            SUM(CASE WHEN jit_sip_statu='Aktif' THEN (jit_sip_miktar-jit_sip_sevk_miktari) ELSE 0 END) AS kalan_miktar,
            SUM(CASE WHEN jit_sip_statu='Aktif' AND jit_sip_teslim_tarihi < CURDATE() THEN 1 ELSE 0 END) AS gecikme_sayisi,
            SUM(CASE WHEN jit_sip_statu='Aktif' AND jit_sip_teslim_tarihi = CURDATE() THEN 1 ELSE 0 END) AS bugun_sayisi,
            SUM(CASE WHEN jit_sip_statu='Aktif' AND jit_sip_teslim_tarihi BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS hafta_sayisi,
            MIN(CASE WHEN jit_sip_statu='Aktif' AND jit_sip_teslim_tarihi>=CURDATE() THEN CONCAT(jit_sip_teslim_tarihi,' ',COALESCE(jit_sip_saati,'00:00')) END) AS en_yakin_teslim
        FROM jit_siparis
        WHERE musteri_firma_adi IS NOT NULL
        GROUP BY musteri_firma_adi
        ORDER BY gecikme_sayisi DESC, acil DESC, bugun_sayisi DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Bugünkü JIT sevkiyatlar (saatlik)
    $jit['bugun'] = $db->query("
        SELECT jit_sip_kodu, jit_sip_baslik,
               jit_sip_miktar AS miktar, jit_sip_sevk_miktari,
               (jit_sip_miktar-jit_sip_sevk_miktari) AS kalan,
               jit_sip_saati AS saat, jit_sip_aciliyet AS aciliyet,
               musteri_firma_adi AS firma
        FROM jit_siparis
        WHERE jit_sip_statu='Aktif' AND jit_sip_teslim_tarihi=CURDATE()
        ORDER BY jit_sip_saati ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // JIT özet
    $jit['ozet'] = $db->query("
        SELECT
            COUNT(*) AS toplam,
            SUM(CASE WHEN jit_sip_aciliyet='Acil' THEN 1 ELSE 0 END) AS acil,
            SUM(CASE WHEN jit_sip_teslim_tarihi < CURDATE() THEN 1 ELSE 0 END) AS gecikme,
            SUM(CASE WHEN jit_sip_teslim_tarihi = CURDATE() THEN 1 ELSE 0 END) AS bugun,
            SUM(CASE WHEN jit_sip_teslim_tarihi BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS bu_hafta,
            SUM(jit_sip_miktar-jit_sip_sevk_miktari) AS toplam_kalan,
            COUNT(DISTINCT musteri_firma_adi) AS firma_sayisi
        FROM jit_siparis WHERE jit_sip_statu='Aktif'
    ")->fetch(PDO::FETCH_ASSOC);

} catch(Throwable $e){ $jit['hata']=$e->getMessage(); }

// Aktif sekme
$sekme = $_GET['sekme'] ?? 'genel';
?>
<style>
.mst-sekme-bar{display:flex;gap:4px;background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:5px;margin-bottom:16px}
.mst-sekme{padding:7px 16px;border:none;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;color:var(--m2);background:none;transition:all .15s}
.mst-sekme.aktif{background:var(--t);color:#fff}
.ozet-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px}
.ozet-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:12px 14px;text-align:center}
.ozet-sayi{font-size:26px;font-weight:800;line-height:1}
.ozet-lbl{font-size:11px;color:var(--m2);margin-top:4px}
.firma-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:12px 16px;margin-bottom:10px}
.firma-ad{font-size:13px;font-weight:800;color:var(--m);margin-bottom:8px;display:flex;align-items:center;gap:8px}
.firma-metrik-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:8px}
.firma-metrik{text-align:center;padding:6px 4px;background:var(--bg);border-radius:6px}
.firma-metrik-sayi{font-size:15px;font-weight:800}
.firma-metrik-lbl{font-size:10px;color:var(--m2)}
.dikkat-badge{padding:3px 8px;border-radius:4px;font-size:10px;font-weight:700}
.uyari-kirmizi{background:#FEE2E2;color:#991B1B}
.uyari-sari{background:#FEF9C3;color:#854D0E}
.uyari-yesil{background:#D1FAE5;color:#065F46}
.uyari-mavi{background:#DBEAFE;color:#1E40AF}
.teslim-bar-wrap{background:#E2E8F0;border-radius:4px;height:6px;margin-top:6px}
.teslim-bar{height:6px;border-radius:4px;transition:width .3s}
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Sipariş Paneli</h1>
    <div class="s-yol">Satış / <b>Müşteri & Sipariş Analizi</b>
      <span style="font-size:11px;color:var(--m2);margin-left:8px"><?php echo date('d.m.Y');?></span>
    </div>
  </div>
</div>

<div class="s-body">

<!-- Sekme -->
<div class="mst-sekme-bar no-print">
  <button class="mst-sekme <?php echo $sekme==='genel'?'aktif':'';?>" onclick="mstSekme('genel',this)">📦 Genel Siparişler</button>
  <button class="mst-sekme <?php echo $sekme==='jit'?'aktif':'';?>" onclick="mstSekme('jit',this)">⚡ JIT Siparişler</button>
</div>

<!-- ══ GENEL SİPARİŞ PANELİ ══ -->
<div id="panel-genel" <?php if($sekme!=='genel') echo 'style="display:none"';?>>

<?php if(isset($gen['hata'])): ?>
<div style="background:#FEE2E2;padding:12px;border-radius:8px;color:#991B1B">❌ <?php echo htmlspecialchars($gen['hata']);?></div>
<?php else: $o=$gen['ozet']??[]; ?>

<!-- Özet Kartlar -->
<div class="ozet-grid">
  <div class="ozet-kart" style="border-color:<?php echo ($o['gecikme']??0)>0?'#EF4444':'var(--kenar)';?>">
    <div class="ozet-sayi" style="color:<?php echo ($o['gecikme']??0)>0?'#DC2626':'var(--m)';?>"><?php echo (int)($o['gecikme']??0);?></div>
    <div class="ozet-lbl">⚠️ Gecikmiş</div>
  </div>
  <div class="ozet-kart" style="border-color:<?php echo ($o['acil']??0)>0?'#F97316':'var(--kenar)';?>">
    <div class="ozet-sayi" style="color:#F97316"><?php echo (int)($o['acil']??0);?></div>
    <div class="ozet-lbl">🔴 Acil</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="color:#1E40AF"><?php echo (int)($o['bugun']??0);?></div>
    <div class="ozet-lbl">📅 Bugün Teslim</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="color:#065F46"><?php echo (int)($o['bu_hafta']??0);?></div>
    <div class="ozet-lbl">📆 Bu Hafta</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi"><?php echo (int)($o['toplam']??0);?></div>
    <div class="ozet-lbl">📦 Toplam Aktif</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi"><?php echo (int)($o['firma_sayisi']??0);?></div>
    <div class="ozet-lbl">🏢 Firma</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="font-size:18px"><?php echo number_format((float)($o['toplam_kalan']??0),0,',','.');?></div>
    <div class="ozet-lbl">📊 Kalan Miktar</div>
  </div>
</div>

<!-- Firma Kartları -->
<?php foreach(($gen['firmalar']??[]) as $f):
  $kalan = (float)($f['kalan_miktar']??0);
  $toplam = (float)($f['toplam_miktar']??0);
  $pct = $toplam>0 ? min(100, round(($f['sevk_miktar']??0)/$toplam*100)) : 0;
  $gecikme = (int)($f['gecikme_sayisi']??0);
  $acil = (int)($f['acil']??0);
  $bugun = (int)($f['bugun_sayisi']??0);
  $hafta = (int)($f['hafta_sayisi']??0);
  // Risk rengi
  if($gecikme>0||$acil>2){ $risk_bg='#FFF5F5'; $risk_brd='#FECACA'; }
  elseif($acil>0||$bugun>0){ $risk_bg='#FFFBEB'; $risk_brd='#FCD34D'; }
  else { $risk_bg='var(--yuzey)'; $risk_brd='var(--kenar)'; }
?>
<div class="firma-kart" style="background:<?php echo $risk_bg;?>;border-color:<?php echo $risk_brd;?>">
  <div class="firma-ad">
    <span><?php echo htmlspecialchars($f['firma']??'');?></span>
    <?php if($gecikme>0):?><span class="dikkat-badge uyari-kirmizi">⚠️ <?php echo $gecikme;?> Gecikme</span><?php endif;?>
    <?php if($acil>0):?><span class="dikkat-badge uyari-sari">🔴 <?php echo $acil;?> Acil</span><?php endif;?>
    <?php if($bugun>0):?><span class="dikkat-badge uyari-mavi">📅 <?php echo $bugun;?> Bugün</span><?php endif;?>
    <?php if($hafta>0&&$gecikme==0&&$acil==0):?><span class="dikkat-badge uyari-yesil">📆 <?php echo $hafta;?> Bu Hafta</span><?php endif;?>
  </div>
  <div class="firma-metrik-grid">
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo (int)($f['aktif']??0);?></div>
      <div class="firma-metrik-lbl">Aktif Sipariş</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:#DC2626"><?php echo number_format($kalan,0,',','.');?></div>
      <div class="firma-metrik-lbl">Kalan Adet</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:#065F46"><?php echo $pct;?>%</div>
      <div class="firma-metrik-lbl">Sevk Oranı</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:<?php echo $gecikme>0?'#DC2626':'var(--m)';?>"><?php echo $gecikme;?></div>
      <div class="firma-metrik-lbl">Gecikme</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo $bugun;?></div>
      <div class="firma-metrik-lbl">Bugün</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo $hafta;?></div>
      <div class="firma-metrik-lbl">Bu Hafta</div>
    </div>
  </div>
  <!-- Sevkiyat progress bar -->
  <div class="teslim-bar-wrap" style="margin-top:10px">
    <div class="teslim-bar" style="width:<?php echo $pct;?>%;background:<?php echo $pct>=80?'#22C55E':($pct>=50?'#F97316':'#EF4444');?>"></div>
  </div>
  <?php if(!empty($f['en_yakin_teslim'])):?>
  <div style="font-size:11px;color:var(--m2);margin-top:6px">En yakın teslim: <b><?php echo date('d.m.Y',strtotime($f['en_yakin_teslim']));?></b></div>
  <?php endif;?>
</div>
<?php endforeach;?>

<!-- Takvim görünümü - son 7 + gelecek 30 gün -->
<?php if(!empty($gen['gunluk'])): ?>
<div class="kart" style="padding:14px;margin-top:4px">
  <div style="font-weight:700;font-size:13px;margin-bottom:10px">📈 Teslim Takvimi (Son 30 — Gelecek 30 Gün)</div>
  <div style="overflow-x:auto">
  <table class="tablo" style="min-width:600px">
    <thead><tr><th>Tarih</th><th style="text-align:right">Sipariş</th><th style="text-align:right">Kalan Miktar</th><th>Yoğunluk</th></tr></thead>
    <tbody>
    <?php foreach($gen['gunluk'] as $g):
      $dt=$g['tarih'];
      $is_gecmis=strtotime($dt)<strtotime($bugun);
      $is_bugun=$dt===$bugun;
      $yog=min(100,(int)($g['siparis_sayisi']*8));
      $row_bg=$is_bugun?'background:#DBEAFE':($is_gecmis?'background:#FEF9C3':'');
    ?>
    <tr style="<?php echo $row_bg;?>">
      <td style="font-weight:<?php echo $is_bugun?'800':'400';?>"><?php echo date('d.m.Y D',strtotime($dt));?><?php if($is_bugun) echo ' <span style="background:#1E40AF;color:#fff;font-size:9px;padding:1px 5px;border-radius:3px">BUGÜN</span>';?></td>
      <td style="text-align:right;font-weight:700"><?php echo (int)$g['siparis_sayisi'];?></td>
      <td style="text-align:right"><?php echo number_format((float)$g['kalan_miktar'],0,',','.');?></td>
      <td>
        <div style="background:#E2E8F0;border-radius:3px;height:6px;width:150px">
          <div style="background:<?php echo $is_gecmis?'#94A3B8':($is_bugun?'#3B82F6':'#22C55E');?>;height:6px;border-radius:3px;width:<?php echo $yog;?>%"></div>
        </div>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
</div>
<?php endif;?>

<?php endif; // hata ?>
</div>

<!-- ══ JIT SİPARİŞ PANELİ ══ -->
<div id="panel-jit" <?php if($sekme!=='jit') echo 'style="display:none"';?>>

<?php if(isset($jit['hata'])): ?>
<div style="background:#FEE2E2;padding:12px;border-radius:8px;color:#991B1B">❌ <?php echo htmlspecialchars($jit['hata']);?></div>
<?php else: $jo=$jit['ozet']??[]; ?>

<!-- JIT Özet -->
<div class="ozet-grid">
  <div class="ozet-kart" style="border-color:<?php echo ($jo['gecikme']??0)>0?'#EF4444':'var(--kenar)';?>">
    <div class="ozet-sayi" style="color:<?php echo ($jo['gecikme']??0)>0?'#DC2626':'var(--m)';?>"><?php echo (int)($jo['gecikme']??0);?></div>
    <div class="ozet-lbl">⚠️ Gecikmiş</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="color:#1E40AF"><?php echo (int)($jo['bugun']??0);?></div>
    <div class="ozet-lbl">⚡ Bugün JIT</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="color:#065F46"><?php echo (int)($jo['bu_hafta']??0);?></div>
    <div class="ozet-lbl">📆 Bu Hafta</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi"><?php echo (int)($jo['toplam']??0);?></div>
    <div class="ozet-lbl">📦 Toplam</div>
  </div>
  <div class="ozet-kart">
    <div class="ozet-sayi" style="font-size:18px"><?php echo number_format((float)($jo['toplam_kalan']??0),0,',','.');?></div>
    <div class="ozet-lbl">📊 Kalan Miktar</div>
  </div>
</div>

<!-- Bugünkü JIT - saatlik -->
<?php if(!empty($jit['bugun'])): ?>
<div class="kart" style="padding:14px;margin-bottom:14px">
  <div style="font-weight:700;font-size:13px;margin-bottom:10px;color:#1E40AF">⚡ Bugün Teslim Edilecek JIT Siparişler</div>
  <table class="tablo">
    <thead><tr><th>Saat</th><th>Firma</th><th>Stok Kodu</th><th>Stok Adı</th><th style="text-align:right">Miktar</th><th style="text-align:right">Kalan</th><th>Öncelik</th></tr></thead>
    <tbody>
    <?php foreach($jit['bugun'] as $j):
      $kalan_pct=$j['miktar']>0?min(100,round($j['kalan']/$j['miktar']*100)):0;
    ?>
    <tr style="<?php echo $j['aciliyet']==='Acil'?'background:#FFF5F5':'';?>">
      <td style="font-weight:800;color:#1E40AF"><?php echo htmlspecialchars($j['saat']??'—');?></td>
      <td style="font-size:12px"><?php echo htmlspecialchars($j['firma']??'');?></td>
      <td><code style="font-size:11px;background:var(--bg);padding:1px 4px;border-radius:3px"><?php echo htmlspecialchars($j['jit_sip_kodu']??'');?></code></td>
      <td style="font-size:12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo htmlspecialchars($j['jit_sip_baslik']??'');?></td>
      <td style="text-align:right"><?php echo number_format((float)$j['miktar'],0,',','.');?></td>
      <td style="text-align:right;font-weight:700;color:<?php echo $j['kalan']>0?'#DC2626':'#059669';?>"><?php echo number_format((float)$j['kalan'],0,',','.');?></td>
      <td><span class="dikkat-badge <?php echo $j['aciliyet']==='Acil'?'uyari-kirmizi':'uyari-yesil';?>"><?php echo htmlspecialchars($j['aciliyet']??'Normal');?></span></td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div style="background:#D1FAE5;border:1px solid #86EFAC;border-radius:8px;padding:12px;margin-bottom:14px;color:#065F46;font-weight:600">✅ Bugün teslim edilecek JIT siparişi yok.</div>
<?php endif;?>

<!-- JIT Firma Kartları -->
<?php foreach(($jit['firmalar']??[]) as $f):
  $kalan=(float)($f['kalan_miktar']??0);
  $toplam=(float)($f['toplam_miktar']??0);
  $pct=$toplam>0?min(100,round(($f['sevk_miktar']??0)/$toplam*100)):0;
  $gecikme=(int)($f['gecikme_sayisi']??0);
  $bugun=(int)($f['bugun_sayisi']??0);
  $hafta=(int)($f['hafta_sayisi']??0);
  if($gecikme>0){ $risk_bg='#FFF5F5'; $risk_brd='#FECACA'; }
  elseif($bugun>0){ $risk_bg='#EFF6FF'; $risk_brd='#93C5FD'; }
  else { $risk_bg='var(--yuzey)'; $risk_brd='var(--kenar)'; }
?>
<div class="firma-kart" style="background:<?php echo $risk_bg;?>;border-color:<?php echo $risk_brd;?>">
  <div class="firma-ad">
    <span>⚡ <?php echo htmlspecialchars($f['firma']??'');?></span>
    <?php if($gecikme>0):?><span class="dikkat-badge uyari-kirmizi">⚠️ <?php echo $gecikme;?> Gecikme</span><?php endif;?>
    <?php if($bugun>0):?><span class="dikkat-badge uyari-mavi">⚡ <?php echo $bugun;?> Bugün</span><?php endif;?>
    <?php if($hafta>0&&$gecikme==0):?><span class="dikkat-badge uyari-yesil">📆 <?php echo $hafta;?> Bu Hafta</span><?php endif;?>
  </div>
  <div class="firma-metrik-grid">
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo (int)($f['aktif']??0);?></div>
      <div class="firma-metrik-lbl">Aktif</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:#DC2626"><?php echo number_format($kalan,0,',','.');?></div>
      <div class="firma-metrik-lbl">Kalan Adet</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:#065F46"><?php echo $pct;?>%</div>
      <div class="firma-metrik-lbl">Sevk Oranı</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo $bugun;?></div>
      <div class="firma-metrik-lbl">Bugün</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi"><?php echo $hafta;?></div>
      <div class="firma-metrik-lbl">Bu Hafta</div>
    </div>
    <div class="firma-metrik">
      <div class="firma-metrik-sayi" style="color:<?php echo $gecikme>0?'#DC2626':'var(--m)';?>"><?php echo $gecikme;?></div>
      <div class="firma-metrik-lbl">Gecikme</div>
    </div>
  </div>
  <div class="teslim-bar-wrap" style="margin-top:10px">
    <div class="teslim-bar" style="width:<?php echo $pct;?>%;background:<?php echo $pct>=80?'#22C55E':($pct>=50?'#F97316':'#EF4444');?>"></div>
  </div>
  <?php if(!empty($f['en_yakin_teslim'])):?>
  <div style="font-size:11px;color:var(--m2);margin-top:6px">En yakın sevkiyat: <b><?php echo substr($f['en_yakin_teslim'],0,16);?></b></div>
  <?php endif;?>
</div>
<?php endforeach;?>

<?php endif; // jit hata ?>
</div>

</div><!-- s-body -->

<script>
function mstSekme(id, el) {
  ['genel','jit'].forEach(function(s){
    document.getElementById('panel-'+s).style.display = s===id ? 'block' : 'none';
    var btn=document.querySelector('.mst-sekme[onclick*="\''+s+'\'"]');
    if(btn) btn.classList.toggle('aktif', s===id);
  });
}
</script>
