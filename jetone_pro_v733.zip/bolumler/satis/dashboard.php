<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$bugun     = date('Y-m-d');
$yarin     = date('Y-m-d', strtotime('+1 day'));
$bir_ay    = date('Y-m-d', strtotime('+1 month'));
$yirmidort = date('Y-m-d H:i:s', strtotime('+24 hours'));

// Kart verileri
function db_tek($db, $sql, $params=[]) {
    try { $s=$db->prepare($sql); $s->execute($params); return $s->fetch(PDO::FETCH_ASSOC)??[]; }
    catch(Throwable $e){ return []; }
}
function db_liste($db, $sql, $params=[]) {
    try { $s=$db->prepare($sql); $s->execute($params); return $s->fetchAll(PDO::FETCH_ASSOC); }
    catch(Throwable $e){ return []; }
}

$bugun_kart    = db_tek($db,"SELECT COUNT(*) c,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$yarin_kart    = db_tek($db,"SELECT COUNT(*) c,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$yarin]);
$geciken_kart  = db_tek($db,"SELECT COUNT(*) c,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$jit_kart      = db_tek($db,"SELECT COUNT(*) c,SUM(jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0)) m FROM jit_siparis WHERE jit_sip_statu='Aktif' AND CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati)<=? AND (jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0))>0",[$yirmidort]);

// Listeler
$bugun_liste  = db_liste($db,"SELECT musteri_firma_adi,COUNT(*) c,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 GROUP BY musteri_firma_adi ORDER BY m DESC LIMIT 8",[$bugun]);
$geciken_liste= db_liste($db,"SELECT musteri_firma_adi,COUNT(*) c,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 GROUP BY musteri_firma_adi ORDER BY m DESC LIMIT 8",[$bugun]);
$jit_liste    = db_liste($db,"SELECT jit_sip_kodu,jit_sip_aciliyet,jit_sip_teslim_tarihi,jit_sip_saati,CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati) tz,(jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0)) m FROM jit_siparis WHERE jit_sip_statu='Aktif' AND CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati)<=? AND (jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0))>0 ORDER BY tz ASC LIMIT 15",[$yirmidort]);

// Tiger'dan stok çek (JIT kodları için)
$jit_stoklar = [];
if($tigerdb_pdo && !empty($jit_liste)){
    $jit_kodlar = array_unique(array_column($jit_liste,'jit_sip_kodu'));
    try {
        $ph = implode(',', array_fill(0, count($jit_kodlar), '?'));
        $ss = $tigerdb_pdo->prepare("SELECT IT.CODE k, ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s FROM dbo.LG_222_ITEMS IT LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF WHERE IT.CODE IN($ph) AND IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE");
        $ss->execute($jit_kodlar);
        foreach($ss->fetchAll(PDO::FETCH_ASSOC) as $r) $jit_stoklar[$r['k']]=(float)$r['s'];
    } catch(Throwable $e){}
}
// Kümülatif stok hesapla (saatlik sıraya göre)
$jit_kumulatif = $jit_stoklar;
$jit_sip_kalan = []; // [index => kumulatif_kalan]
foreach($jit_liste as $i => $r){
    $kod = $r['jit_sip_kodu'];
    if(!isset($jit_kumulatif[$kod])) $jit_kumulatif[$kod]=0;
    $jit_kumulatif[$kod] -= (float)$r['m'];
    $jit_sip_kalan[$i] = $jit_kumulatif[$kod];
}

// Grafik: firma dağılımı
$firma_data   = db_liste($db,"SELECT musteri_firma_adi,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND sip_teslim_tarihi<=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 GROUP BY musteri_firma_adi ORDER BY m DESC LIMIT 6",[$bir_ay]);

// Grafik: son 7 gün
$haftalik = [];
for($i=6;$i>=0;$i--) {
    $t=date('Y-m-d',strtotime("-$i day"));
    $r=db_tek($db,"SELECT COALESCE(SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)),0) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=?",[$t]);
    $haftalik[]=[(int)(strpos('0123456',(string)date('w',strtotime($t)))!==false?date('w',strtotime($t)):0),$t,(float)($r['m']??0)];
}
$gun_adlari=['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'];
$hafta_labels=array_map(fn($h)=>$gun_adlari[date('w',strtotime($h[1]))].' '.date('d/m',strtotime($h[1])),$haftalik);
$hafta_data=array_map(fn($h)=>$h[2],$haftalik);

// Araçlar
$arac_son = [];
try {
    $arr=$db->query("SELECT * FROM arac_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach($arr as $a){ $p=$a['plaka']; if(!isset($arac_son[$p])||strtotime($a['c_zaman'])>strtotime($arac_son[$p]['c_zaman'])) $arac_son[$p]=$a; }
} catch(Throwable $e){}

$araclar=[
    ['plaka'=>'59 JD 820','tip'=>'KAMYON','marka'=>'MERCEDES'],
    ['plaka'=>'59 AIR 496','tip'=>'KAMYON','marka'=>'İVECO'],
    ['plaka'=>'59 AT 979','tip'=>'KAMYONET','marka'=>'FORD'],
    ['plaka'=>'59 JF 911','tip'=>'TİCARİ','marka'=>'FİORİNO'],
];
?>
<style>
.db-kart{border-radius:12px;padding:18px 20px;display:flex;justify-content:space-between;align-items:center;position:relative;overflow:hidden}
.db-kart::after{content:'';position:absolute;right:-12px;bottom:-12px;width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.12)}
.db-kart-val{font-size:30px;font-weight:900;color:#fff;line-height:1}
.db-kart-lbl{font-size:13px;font-weight:700;color:rgba(255,255,255,.9);margin-bottom:4px}
.db-kart-alt{font-size:11px;color:rgba(255,255,255,.75);margin-top:3px}
.db-kart-ikon{width:46px;height:46px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.db-grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px}
.db-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
.db-grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px}
@media(max-width:900px){.db-grid-4{grid-template-columns:1fr 1fr}.db-grid-2{grid-template-columns:1fr}.db-grid-3{grid-template-columns:1fr 1fr}}
@media(max-width:540px){.db-grid-4{grid-template-columns:1fr}.db-grid-3{grid-template-columns:1fr}}
.db-tablo{width:100%;border-collapse:collapse;font-size:12px}
.db-tablo th{background:#1E3A5F;color:#fff;padding:7px 10px;text-align:left;font-weight:700;white-space:nowrap}
.db-tablo td{padding:6px 10px;border-bottom:1px solid var(--kenar);white-space:nowrap}
.db-tablo tbody tr:hover td{background:var(--bg)}
.arac-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:12px}
.arac-disari{border-left:4px solid #DC2626;background:#FFF5F5}
.arac-iceri{border-left:4px solid #16A34A;background:#F0FDF4}
.badge-acil{background:#DC2626;color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:8px}
.badge-normal{background:#3B82F6;color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:8px}
.db-chart-wrap{background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:14px}
.db-chart-wrap h4{font-size:13px;font-weight:700;color:var(--m);margin-bottom:12px}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">📊 Satış Dashboard</h1>
    <div class="s-yol">Satış / <b>Genel Özet</b> · <?php echo date('d.m.Y H:i');?></div>
  </div>
  <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:5px 12px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
</div>

<!-- KPI Kartları -->
<div class="db-grid-4">
  <div class="db-kart" style="background:linear-gradient(135deg,#1E40AF,#2563EB)">
    <div>
      <div class="db-kart-lbl">Bugünkü Sevkiyat</div>
      <div style="display:flex;align-items:baseline;gap:6px">
        <div class="db-kart-val"><?php echo (int)($bugun_kart['c']??0);?></div>
        <div style="font-size:12px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="db-kart-alt"><?php echo number_format((float)($bugun_kart['m']??0),0,'','.');?> adet toplam</div>
    </div>
    <div class="db-kart-ikon">
      <svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
  </div>
  <div class="db-kart" style="background:linear-gradient(135deg,#065F46,#16A34A)">
    <div>
      <div class="db-kart-lbl">Yarınki Sevkiyat</div>
      <div style="display:flex;align-items:baseline;gap:6px">
        <div class="db-kart-val"><?php echo (int)($yarin_kart['c']??0);?></div>
        <div style="font-size:12px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="db-kart-alt"><?php echo number_format((float)($yarin_kart['m']??0),0,'','.');?> adet toplam</div>
    </div>
    <div class="db-kart-ikon">
      <svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
    </div>
  </div>
  <div class="db-kart" style="background:linear-gradient(135deg,#991B1B,#DC2626)">
    <div>
      <div class="db-kart-lbl">Geciken Siparişler</div>
      <div style="display:flex;align-items:baseline;gap:6px">
        <div class="db-kart-val"><?php echo (int)($geciken_kart['c']??0);?></div>
        <div style="font-size:12px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="db-kart-alt"><?php echo number_format((float)($geciken_kart['m']??0),0,'','.');?> adet toplam</div>
    </div>
    <div class="db-kart-ikon">
      <svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
    </div>
  </div>
  <div class="db-kart" style="background:linear-gradient(135deg,#92400E,#D97706)">
    <div>
      <div class="db-kart-lbl">JIT (24 Saat)</div>
      <div style="display:flex;align-items:baseline;gap:6px">
        <div class="db-kart-val"><?php echo (int)($jit_kart['c']??0);?></div>
        <div style="font-size:12px;color:rgba(255,255,255,.8);font-weight:600">satır</div>
      </div>
      <div class="db-kart-alt"><?php echo number_format((float)($jit_kart['m']??0),0,'','.');?> adet toplam</div>
    </div>
    <div class="db-kart-ikon">
      <svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
    </div>
  </div>
</div>

<!-- Araçlar -->
<?php if(!empty($araclar)):?>
<div class="db-grid-4" style="margin-bottom:14px">
<?php foreach($araclar as $ar):
    $son=$arac_son[$ar['plaka']]??null;
    $disari=$son&&empty($son['g_zaman']);
    $cls=$disari?'arac-disari':'arac-iceri';
?>
<div class="arac-kart <?php echo $cls;?>">
  <div style="display:flex;justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:800;font-size:13px;color:var(--m)"><?php echo $ar['plaka'];?></div>
      <div style="font-size:10px;color:var(--m2)"><?php echo $ar['marka'];?> · <?php echo $ar['tip'];?></div>
    </div>
    <span style="background:<?php echo $disari?'#DC2626':'#16A34A';?>;color:#fff;font-size:10px;font-weight:700;padding:2px 7px;border-radius:8px"><?php echo $disari?'Dışarıda':'İçeride';?></span>
  </div>
  <?php if($son):?>
  <div style="margin-top:8px;font-size:11px;color:var(--m2);line-height:1.6">
    <?php if($disari):?>
    <div>🏢 <?php echo htmlspecialchars(mb_strimwidth($son['firma']??'',0,28,'…'));?></div>
    <div>🕐 Çıkış: <?php echo $son['c_zaman']?date('d.m H:i',strtotime($son['c_zaman'])):'—';?></div>
    <?php if(!empty($son['irsaliye'])):?><div>📄 <?php echo htmlspecialchars($son['irsaliye']);?></div><?php endif;?>
    <?php else:?>
    <div>🔄 Son: <?php echo htmlspecialchars(mb_strimwidth($son['firma']??'',0,28,'…'));?></div>
    <div>🕐 Giriş: <?php echo $son['g_zaman']?date('d.m H:i',strtotime($son['g_zaman'])):'—';?></div>
    <?php endif;?>
    <?php if(!empty($son['soför_adı'])):?><div>👤 <?php echo htmlspecialchars($son['soför_adı']);?></div><?php endif;?>
  </div>
  <?php endif;?>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<!-- Grafikler -->
<div class="db-grid-2">
  <div class="db-chart-wrap">
    <h4>📈 Son 7 Günlük Sevkiyat</h4>
    <div style="position:relative;height:200px;width:100%">
      <canvas id="dbHaftaChart"></canvas>
    </div>
  </div>
  <div class="db-chart-wrap">
    <h4>🏢 Firma Bazlı Dağılım (1 Ay)</h4>
    <div style="position:relative;height:200px;width:100%">
      <canvas id="dbFirmaChart"></canvas>
    </div>
  </div>
</div>

<!-- Tablolar -->
<div class="db-grid-3">
  <!-- Bugün -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#1E3A5F;color:#fff;padding:10px 14px;font-size:13px;font-weight:700">📦 Bugünkü Sevkiyatlar</div>
    <?php if(empty($bugun_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">Bugün için sipariş yok</div>
    <?php else:?>
    <table class="db-tablo">
      <thead><tr><th>Firma</th><th style="text-align:center">Sipariş</th><th style="text-align:right">Miktar</th></tr></thead>
      <tbody>
      <?php foreach($bugun_liste as $r):?>
      <tr>
        <td style="font-size:11px"><?php echo htmlspecialchars($r['musteri_firma_adi']);?></td>
        <td style="text-align:center;font-weight:700"><?php echo $r['c'];?></td>
        <td style="text-align:right;font-weight:700;color:#1E40AF"><?php echo number_format((float)$r['m'],0,'','.');?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    <?php endif;?>
  </div>

  <!-- Geciken -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#991B1B;color:#fff;padding:10px 14px;font-size:13px;font-weight:700">⚠️ Geciken Sevkiyatlar</div>
    <?php if(empty($geciken_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">✅ Geciken sipariş yok</div>
    <?php else:?>
    <table class="db-tablo">
      <thead><tr><th>Firma</th><th style="text-align:center">Sipariş</th><th style="text-align:right">Miktar</th></tr></thead>
      <tbody>
      <?php foreach($geciken_liste as $r):?>
      <tr style="background:#FFF5F5">
        <td style="font-size:11px"><?php echo htmlspecialchars($r['musteri_firma_adi']);?></td>
        <td style="text-align:center;font-weight:700;color:#DC2626"><?php echo $r['c'];?></td>
        <td style="text-align:right;font-weight:700;color:#DC2626"><?php echo number_format((float)$r['m'],0,'','.');?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    <?php endif;?>
  </div>

  <!-- JIT -->
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#92400E;color:#fff;padding:10px 14px;font-size:13px;font-weight:700">⚡ Acil JIT (24 Saat)</div>
    <?php if(empty($jit_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">24 saat içinde JIT yok</div>
    <?php else:?>
    <table class="db-tablo">
      <thead><tr>
        <th>Stok Kodu</th><th>Durum</th><th>Teslim</th>
        <th style="text-align:right">Miktar</th><th style="text-align:right">Stok Durum</th>
      </tr></thead>
      <tbody>
      <?php
      $simdi = time();
      $bugun_str = date('Y-m-d');
      $yarin_str = date('Y-m-d', strtotime('+1 day'));
      foreach($jit_liste as $i => $r):
        $teslim_ts = strtotime($r['tz']);
        $dk_kalan  = (int)(($teslim_ts - $simdi) / 60);
        $saat_kalan = $dk_kalan / 60;
        // Durum etiketi
        if($dk_kalan < 0){
          $durum_html = '<span style="background:#991B1B;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px">⛔ GEÇTİ</span>';
          $satir_bg = 'background:#FFF0F0';
        } elseif($saat_kalan <= 8 && $r['jit_sip_teslim_tarihi']===$bugun_str){
          $durum_html = '<span style="background:#D97706;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px">⚡ BUGÜN '.round($saat_kalan,1).'s</span>';
          $satir_bg = 'background:#FFFBEB';
        } elseif($r['jit_sip_teslim_tarihi']===$bugun_str){
          $durum_html = '<span style="background:#2563EB;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px">📦 BUGÜN</span>';
          $satir_bg = '';
        } elseif($r['jit_sip_teslim_tarihi']===$yarin_str){
          $durum_html = '<span style="background:#7C3AED;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px">📅 YARIN</span>';
          $satir_bg = '';
        } else {
          $durum_html = '<span style="background:#6B7280;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px">🕐 '.date('d.m',strtotime($r['jit_sip_teslim_tarihi'])).'</span>';
          $satir_bg = '';
        }
        // Stok yeterlilik
        $k = $jit_sip_kalan[$i] ?? 0;
        if(!isset($jit_stoklar[$r['jit_sip_kodu']])){
          $stok_html = '<span style="color:#6B7280;font-size:10px">—</span>';
        } elseif($k >= 0){
          $stok_html = '<span style="color:#16A34A;font-weight:700;font-size:11px">✓ '.number_format($k,0,'','.').'</span>';
        } else {
          $stok_html = '<span style="color:#DC2626;font-weight:700;font-size:11px">⚠ '.number_format($k,0,'','.').'</span>';
          $satir_bg = $satir_bg ?: 'background:#FFF5F5';
        }
      ?>
      <tr style="<?php echo $satir_bg;?>">
        <td><span style="font-family:monospace;font-weight:700;font-size:11px"><?php echo htmlspecialchars($r['jit_sip_kodu']);?></span></td>
        <td><?php echo $durum_html;?></td>
        <td style="font-size:11px;font-weight:600"><?php echo date('d.m H:i',$teslim_ts);?></td>
        <td style="text-align:right;font-weight:700"><?php echo number_format((float)$r['m'],0,'','.');?></td>
        <td style="text-align:right"><?php echo $stok_html;?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    <?php endif;?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function(){
  // Önceki instance'ları temizle
  if(window._dbChart1){window._dbChart1.destroy();window._dbChart1=null;}
  if(window._dbChart2){window._dbChart2.destroy();window._dbChart2=null;}

  var ctx1=document.getElementById('dbHaftaChart');
  if(ctx1){
    window._dbChart1=new Chart(ctx1,{type:'bar',data:{
      labels:<?php echo json_encode($hafta_labels,JSON_UNESCAPED_UNICODE);?>,
      datasets:[{label:'Sipariş Miktarı',data:<?php echo json_encode($hafta_data);?>,
        backgroundColor:'rgba(37,99,235,.7)',borderColor:'#1E40AF',borderWidth:1,borderRadius:4}]
    },options:{responsive:true,maintainAspectRatio:false,animation:false,
      plugins:{legend:{display:false}},
      scales:{y:{beginAtZero:true,ticks:{font:{size:10}}}}}});
  }
  var ctx2=document.getElementById('dbFirmaChart');
  var fl=<?php echo json_encode(array_column($firma_data,'musteri_firma_adi'),JSON_UNESCAPED_UNICODE);?>;
  var fd=<?php echo json_encode(array_map(fn($r)=>(float)$r['m'],$firma_data));?>;
  if(ctx2&&fl.length){
    window._dbChart2=new Chart(ctx2,{type:'doughnut',data:{
      labels:fl,
      datasets:[{data:fd,backgroundColor:['#2563EB','#DC2626','#16A34A','#D97706','#7C3AED','#0891B2'],borderWidth:2}]
    },options:{responsive:true,maintainAspectRatio:false,animation:false,
      plugins:{legend:{position:'right',labels:{font:{size:10},boxWidth:12}}}}});
  }
})();
</script>
