<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';
$satirlar = [];

if ($tiger_ok) {
    try {
        $sql = "SELECT
            CONVERT(VARCHAR,STF.FICHENO) AS irsaliye_no,
            CONVERT(VARCHAR,STL.DATE_,104) AS tarih,
            CL.DEFINITION_ AS musteri,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END AS stok_kodu,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END AS stok_adi,
            SUM(STL.AMOUNT) AS miktar,
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,'') AS aciklama,
            ISNULL(STF.SPECODE,'') AS tur_kodu,
            CASE STF.TRCODE
                WHEN 2 THEN 'Perakende Satış İade'
                WHEN 3 THEN 'Toptan Satış İade'
                WHEN 4 THEN 'Konsinye Çıkış İade'
                ELSE 'Diğer'
            END AS irs_turu,
            '02' AS ambar,
            STL.DATE_ AS sort_tarih
        FROM dbo.LG_222_02_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.TRCODE IN (2,3,4)
          AND YEAR(STL.DATE_) = YEAR(GETDATE())
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)
        GROUP BY STL.DATE_, STF.FICHENO, CL.DEFINITION_,
            IT.CODE, IT.NAME, SRV.CODE, SRV.DEFINITION_,
            STF.GENEXP1, STF.GENEXP2, STF.SPECODE, STF.TRCODE

        UNION ALL

        SELECT
            CONVERT(VARCHAR,STF.FICHENO),
            CONVERT(VARCHAR,STL.DATE_,104),
            CL.DEFINITION_,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END,
            SUM(STL.AMOUNT),
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,''),
            ISNULL(STF.SPECODE,''),
            CASE STF.TRCODE
                WHEN 2 THEN 'Perakende Satış İade'
                WHEN 3 THEN 'Toptan Satış İade'
                WHEN 4 THEN 'Konsinye Çıkış İade'
                ELSE 'Diğer'
            END,
            '01',
            STL.DATE_
        FROM dbo.LG_222_01_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.TRCODE IN (2,3,4)
          AND YEAR(STL.DATE_) = YEAR(GETDATE())
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)
        GROUP BY STL.DATE_, STF.FICHENO, CL.DEFINITION_,
            IT.CODE, IT.NAME, SRV.CODE, SRV.DEFINITION_,
            STF.GENEXP1, STF.GENEXP2, STF.SPECODE, STF.TRCODE

        ORDER BY sort_tarih DESC, irsaliye_no DESC";

        $stmt     = $tigerdb_pdo->query($sql);
        $satirlar = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// Grupla: aynı irsaliye + stok kodu → miktar topla
$grup_map = [];
foreach ($satirlar as $r) {
    $key = $r['irsaliye_no'] . '||' . ($r['stok_kodu'] ?? '');
    if (!isset($grup_map[$key])) {
        $grup_map[$key] = $r;
        $grup_map[$key]['miktar'] = floatval($r['miktar'] ?? 0);
    } else {
        $grup_map[$key]['miktar'] += floatval($r['miktar'] ?? 0);
    }
}
$satirlar = array_values($grup_map);
$benzersiz = count(array_unique(array_column($satirlar, 'irsaliye_no')));
?>
<style>
#tblIadeIrs th { background:#1E3A5F !important; color:#fff !important; }
#tblIadeIrs td, #tblIadeIrs th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">↩️ Satış İade İrsaliyeleri</h1>
    <div class="s-yol">Satış / <b>İade İrsaliyeleri</b>
      <?php if($tiger_ok):?>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <span style="font-size:11px;color:var(--m2);margin-left:3px">
        (<?php echo $benzersiz;?> irsaliye, <?php echo count($satirlar);?> kalem — <?php echo date('Y');?>)
      </span>
      <?php else:?>
      <span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span>
      <?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>

<?php if(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;border:1px solid #FECACA;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php elseif(empty($satirlar)):?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:30px;text-align:center;color:var(--m2)">İade irsaliyesi bulunamadı.</div>
<?php else:?>

<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblIadeIrs" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>İrsaliye No</th>
      <th>Tarih</th>
      <th>Müşteri</th>
      <th>Stok Kodu</th>
      <th>Stok Adı</th>
      <th>Miktar</th>
      <th>İrsaliye Türü</th>
      <th>Tür Kodu</th>
      <th>Açıklama</th>
      <th>Ambar</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>İrsaliye No</th><th>Tarih</th><th>Müşteri</th>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Miktar</th>
      <th>İrsaliye Türü</th><th>Tür Kodu</th><th>Açıklama</th><th>Ambar</th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($satirlar as $r):?>
  <tr>
    <td style="font-weight:700;color:#0369A1"><?php echo htmlspecialchars($r['irsaliye_no']);?></td>
    <td data-order="<?php echo date('Y-m-d', strtotime($r['sort_tarih'] ?? $r['tarih'] ?? '1970-01-01'));?>"><?php echo htmlspecialchars($r['tarih'] ?? '');?></td>
    <td><?php echo htmlspecialchars($r['musteri'] ?? '');?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu'] ?? '');?></code></td>
    <td><?php echo htmlspecialchars($r['stok_adi'] ?? '');?></td>
    <td style="text-align:right"><?php echo number_format((float)($r['miktar'] ?? 0), 0, ',', '.');?></td>
    <td><span style="background:#FEF2F2;color:#991B1B;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['irs_turu'] ?? '');?></span></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['tur_kodu'] ?? '');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars(trim($r['aciklama'] ?? ''));?></td>
    <td style="text-align:center;font-size:11px"><?php echo htmlspecialchars($r['ambar'] ?? '');?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<?php endif;?>

<script>
$(document).ready(function(){
  if(!$('#tblIadeIrs tbody tr').length) return;
  $('#tblIadeIrs').DataTable({
    initComplete: function(){
      this.api().columns().every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change', function(){
            var v=$.fn.dataTable.util.escapeRegex($(this).val());
            col.search(v?'^'+v+'$':'', true, false).draw();
          });
        col.data().unique().sort().each(function(d){
          var v=$('<div/>').html(d).text();
          if(v.length>29) v=v.substr(0,30)+'...';
          sel.append('<option value="'+v+'">'+v+'</option>');
        });
      });
    },
    language: { url: 'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollCollapse: true,
    scrollY: 600,
    paging: false,
    scrollX: true,
    order: [[1, 'desc']],
    dom: 'Bfrtip',
    buttons: [
      { extend:'excelHtml5', text:'📊 Excel', className:'btn-dt', filename:'Iade_Irsaliyeler' },
      'print'
    ]
  });
});
</script>
