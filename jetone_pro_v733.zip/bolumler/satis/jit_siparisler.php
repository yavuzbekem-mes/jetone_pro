<?php
ob_start();
// ── POST / AJAX ──────────────────────────────────────────────────────────────
if (!empty($_POST['jit_action'])) {
    ob_end_clean();
    error_reporting(0);
    require_once dirname(dirname(__DIR__)).'/core/config.php';
    require_once dirname(dirname(__DIR__)).'/core/db.php';
    require_once dirname(dirname(__DIR__)).'/core/auth.php';
    require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
    header('Content-Type: application/json; charset=utf-8');
    Auth::zorunlu();
    $action = $_POST['jit_action'];
    $kul_adi = trim(($_SESSION['kullanici']['ad_soyad']??'')?: ($_SESSION['kullanici']['email']??'sistem'));

    // İnline sevk güncelle
    if ($action === 'guncelle') {
        $id  = (int)($_POST['id']??0);
        $col = trim($_POST['kolon']??'');
        $val = trim($_POST['deger']??'');
        $izin = ['jit_sip_sevk_miktari','jit_son_irsaliye_no','jit_son_irsaliye_2',
                 'jit_gecikme_nedeni','sip_baslama_tarih','jit_sip_miktar','jit_sip_teslim_tarihi','jit_sip_saati'];
        if(!$id||!in_array($col,$izin)){echo json_encode(['ok'=>false]);exit;}
        try {
            $db->prepare("UPDATE jit_siparis SET `$col`=?,guncelleyen=? WHERE jit_sip_id=?")
               ->execute([$val?:null,$kul_adi,$id]);
            $r=$db->prepare("SELECT jit_sip_miktar,jit_sip_sevk_miktari FROM jit_siparis WHERE jit_sip_id=?");
            $r->execute([$id]); $row=$r->fetch(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'kalan'=>floatval($row['jit_sip_miktar']??0)-floatval($row['jit_sip_sevk_miktari']??0)]);
        } catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    // Sil
    if ($action === 'sil') {
        $id=(int)($_POST['id']??0);
        try{$db->prepare("DELETE FROM jit_siparis WHERE jit_sip_id=?")->execute([$id]);echo json_encode(['ok'=>true]);}
        catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    // Tamamlananları kapat
    if ($action === 'tamamla') {
        try{
            $n=$db->exec("UPDATE jit_siparis SET jit_sip_statu='Tamamlandi' WHERE jit_sip_statu='Aktif' AND jit_sip_miktar>0 AND jit_sip_miktar<=jit_sip_sevk_miktari");
            echo json_encode(['ok'=>true,'sayi'=>$n]);
        }catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    // Tümünü kaldır (Pasif yap)
    if ($action === 'tumunu_kaldir') {
        try{
            $n=$db->exec("UPDATE jit_siparis SET jit_sip_statu='Pasif' WHERE jit_sip_statu='Aktif'");
            echo json_encode(['ok'=>true,'sayi'=>$n]);
        }catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    // İrsaliyeleri düş
    if ($action === 'irsaliye_dus') {
        try {
            $dusulenler=$db->query("SELECT irsaliye_no FROM dusulen_irsaliyeler WHERE durum='aktif'")->fetchAll(PDO::FETCH_COLUMN);
            if(empty($dusulenler)){echo json_encode(['ok'=>false,'hata'=>'Dusulecek irsaliye yok. Once Yeni Irsaliyeler sayfasindan irsaliye dusurun.']);exit;}
            if(!$tigerdb_pdo){echo json_encode(['ok'=>false,'hata'=>'Tiger DB baglantisi yok']);exit;}
            $ph=implode(',',array_fill(0,count($dusulenler),'?'));
            $sql="SELECT CONVERT(VARCHAR,STF.FICHENO) n,IT.CODE k,SUM(STL.AMOUNT) a
                FROM dbo.LG_222_01_STLINE STL WITH(NOLOCK)
                LEFT JOIN dbo.LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
                WHERE STF.FICHENO IN ($ph) AND IT.CODE IS NOT NULL GROUP BY STF.FICHENO,IT.CODE
                UNION ALL
                SELECT CONVERT(VARCHAR,STF.FICHENO),IT.CODE,SUM(STL.AMOUNT)
                FROM dbo.LG_222_02_STLINE STL WITH(NOLOCK)
                LEFT JOIN dbo.LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
                LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
                WHERE STF.FICHENO IN ($ph) AND IT.CODE IS NOT NULL GROUP BY STF.FICHENO,IT.CODE";
            $s=$tigerdb_pdo->prepare($sql);
            $s->execute(array_merge($dusulenler,$dusulenler));
            $toplam=[];$son_irs=[];
            foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r){
                $toplam[$r['k']]=($toplam[$r['k']]??0)+floatval($r['a']);
                $son_irs[$r['k']]=$r['n'];
            }
            $guncellenen=0;
            foreach($toplam as $mal=>$mik){
                $kalan=$mik;
                $sips=$db->prepare("SELECT jit_sip_id,jit_sip_miktar,jit_sip_sevk_miktari,
                    (jit_sip_miktar-jit_sip_sevk_miktari) km FROM jit_siparis
                    WHERE jit_sip_kodu=? AND jit_sip_statu='Aktif'
                    AND (jit_sip_miktar-jit_sip_sevk_miktari)>0
                    ORDER BY CASE WHEN jit_sip_sevk_miktari>0 THEN 0 ELSE 1 END,
                    jit_sip_teslim_tarihi ASC,jit_sip_saati ASC,jit_sip_id ASC");
                $sips->execute([$mal]);
                foreach($sips->fetchAll(PDO::FETCH_ASSOC) as $sip){
                    if($kalan<=0)break;
                    $d=min($kalan,(float)$sip['km']);
                    if($d>0){
                        $db->prepare("UPDATE jit_siparis SET jit_sip_sevk_miktari=jit_sip_sevk_miktari+?,
                            jit_son_irsaliye_2=?,sip_baslama_tarih=CURDATE()
                            WHERE jit_sip_id=?")->execute([$d,$son_irs[$mal]??null,$sip['jit_sip_id']]);
                        $kalan-=$d;$guncellenen++;
                    }
                }
            }
            $db->exec("UPDATE jit_siparis SET jit_sip_statu='Tamamlandi' WHERE jit_sip_statu='Aktif' AND jit_sip_miktar>0 AND jit_sip_miktar<=jit_sip_sevk_miktari");
            echo json_encode(['ok'=>true,'guncellenen'=>$guncellenen,'irs_sayi'=>count($dusulenler)]);
        }catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    // Excel yükle
    if ($action === 'excel_yukle') {
        $musteri=trim($_POST['musteri']??'ARÇELİK');
        if(empty($_FILES['dosya']['tmp_name'])){echo json_encode(['ok'=>false,'hata'=>'Dosya seçilmedi']);exit;}
        require_once dirname(dirname(__DIR__)).'/core/SimpleXLSX.php';
        $xlsx=new SimpleXLSX($_FILES['dosya']['tmp_name']);
        if(!$xlsx->success()){echo json_encode(['ok'=>false,'hata'=>'Excel okunamadi: '.$xlsx->error()]);exit;}
        $stmt=$db->prepare("INSERT INTO jit_siparis
            (jit_sip_statu,musteri_firma_adi,jit_sip_tarihi,jit_sip_saati,ekleyen,
            jit_sip_kodu,jit_sip_baslik,jit_sip_miktar,jit_sip_sevk_miktari,
            jit_sip_teslim_tarihi,jit_son_irsaliye_no,jit_sip_aciliyet,jit_sip_durum)
            VALUES ('Aktif',?,CURDATE(),?,?,?,?,?,?,?,?,?,?)");
        $eklendi=0;$hatali=0;$rn=0;
        foreach($xlsx->rows() as $f){
            $rn++;if($rn<=1)continue; // ilk satır başlık
            if(empty($f[0]))continue;
            // Excel kolon sırası: [0]=kodu,[1]=baslik,[2]=tarih,[3]=saat,[4]=sipNo,[5]=miktar,[7]=son_irs,[8]=sevk
            $tarih=null;
            $tr=trim($f[2]??'');
            if($tr){
                if(is_numeric($tr)&&$tr>40000) $tarih=date('Y-m-d',($tr-25569)*86400);
                elseif(strtotime($tr)) $tarih=date('Y-m-d',strtotime($tr));
            }
            if(!$tarih){$hatali++;continue;}
            $saat_raw=trim($f[3]??'00:00');
            // Excel saat formatı: 0.875 gibi ondalık ise HH:MM'e çevir
            if(is_numeric($saat_raw) && strpos($saat_raw,':')===false){
                $total_min=(int)round(floatval($saat_raw)*24*60);
                $saat=sprintf('%02d:%02d',(int)floor($total_min/60),$total_min%60);
            } else {
                // Zaten HH:MM formatında, sadece ilk 5 karakter al
                $saat=substr($saat_raw,0,5);
            }
            $miktar=intval(preg_replace('/[^0-9]/','',($f[5]??'0')));
            $sevk=intval(preg_replace('/[^0-9]/','',($f[8]??'0')));
            $son_irs=trim($f[7]??'')?:null;
            $aciliyet=(strtotime($tarih)<time())?'Acil':'Normal';
            try{
                $stmt->execute([$musteri,$saat,$kul_adi,trim($f[0]),trim($f[1]??''),$miktar,$sevk,$tarih,$son_irs,$aciliyet,'Yeni']);
                $eklendi++;
            }catch(Throwable $e){$hatali++;}
        }
        echo json_encode(['ok'=>true,'eklendi'=>$eklendi,'hatali'=>$hatali]);
        exit;
    }

    // Mail gönder
    if ($action === 'mail_gonder') {
        try {
            require_once dirname(dirname(__DIR__)).'/bolumler/idari/ajax/satin-smtp-send.php';
            $smtp_ent=null;
            try{$smtp_ent=$db->query("SELECT host,port,kullanici,sifre,ek_parametreler FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);}catch(Throwable $e2){}
            if(!$smtp_ent){echo json_encode(['ok'=>false,'hata'=>'SMTP entegrasyonu tanimlanmamis.']);exit;}
            $key=defined('SIFRELE_KEY')?SIFRELE_KEY:'jetone_key_2024';
            $sifre='';
            if(!empty($smtp_ent['sifre'])){
                $enc=trim($smtp_ent['sifre']);
                $d1=@openssl_decrypt($enc,'AES-256-CBC',$key,0,'1234567890123456');
                $d2=@openssl_decrypt($enc,'AES-256-CBC','jetone2024secretkey!!',0,'1234567890123456');
                if($d1!==false&&strlen($d1)>0&&ctype_print($d1))$sifre=$d1;
                elseif($d2!==false&&strlen($d2)>0&&ctype_print($d2))$sifre=$d2;
                else{$b64=@base64_decode($enc,true);$sifre=($b64&&ctype_print($b64))?$b64:$enc;}
            }
            $ekPar=json_decode($smtp_ent['ek_parametreler']??'{}',true)?:[];
            $host=$smtp_ent['host']?:'localhost';$port=(int)($smtp_ent['port']?:587);
            $user=$smtp_ent['kullanici']??'';
            $enc2=$ekPar['smtp_secure']??($port==465?'ssl':'tls');
            $fromAd=$ekPar['smtp_from_name']??'Jetone ERP';
            $email_set=[];
            try{
                $beyazlar=$db->query("SELECT ad,soyad,email FROM personeller WHERE durum='aktif' AND kadro='beyaz_yaka' AND email IS NOT NULL AND email!='' AND email LIKE '%@%'")->fetchAll(PDO::FETCH_ASSOC);
                foreach($beyazlar as $u){$m=trim(strtolower($u['email']));if(filter_var($m,FILTER_VALIDATE_EMAIL))$email_set[$m]=trim($u['ad'].' '.$u['soyad']);}
            }catch(Throwable $e4){}
            $ekstra=trim($_POST['ekstra_mail']??'');
            if($ekstra)foreach(explode(',',$ekstra) as $em){$em=trim($em);if(filter_var($em,FILTER_VALIDATE_EMAIL))$email_set[$em]='Manuel';}
            if(empty($email_set)){echo json_encode(['ok'=>false,'hata'=>'bos','mesaj'=>'Beyaz yaka personel email bulunamadi.']);exit;}
            $tarih=date('d.m.Y');$saat=date('H:i');
            $konu="JIT Sipariş Güncelleme Bildirimi — $tarih";
            $ozet=json_decode($_POST['ozet_json']??'{}',true)?:[];
            $html='<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;font-size:12px;color:#1E293B;padding:20px}h2{color:#065F46;margin:0 0 6px 0;font-size:16px}.sub{color:#64748B;font-size:11px;margin-bottom:16px}table{border-collapse:collapse;width:100%;font-size:11px;margin-bottom:12px}th{background:#065F46;color:#fff;padding:6px 10px;border:1px solid #047857;text-align:left}td{padding:4px 8px;border:1px solid #E2E8F0}tr:nth-child(even) td{background:#F0FDF4}.footer{color:#94A3B8;font-size:10px;margin-top:16px;border-top:1px solid #E2E8F0;padding-top:8px}</style></head><body>';
            $html.="<h2>⚡ JIT Sipariş Güncelleme Bildirimi</h2>";
            $html.="<div class='sub'>Güncelleyen: <b>$kul_adi</b> &nbsp;|&nbsp; Tarih: <b>$tarih $saat</b></div>";
            if(!empty($ozet)){
                $html.='<table style="width:auto;margin-bottom:14px"><tr><th>Toplam</th><th>Acil</th><th>Yetersiz</th><th>Tamamlanan</th></tr><tr>';
                $html.='<td style="text-align:center;font-weight:700">'.(int)($ozet['toplam']??0).'</td>';
                $html.='<td style="text-align:center;color:#DC2626;font-weight:700">'.(int)($ozet['acil']??0).'</td>';
                $html.='<td style="text-align:center;color:#DC2626;font-weight:700">'.(int)($ozet['yetersiz']??0).'</td>';
                $html.='<td style="text-align:center;color:#059669;font-weight:700">'.(int)($ozet['tamamlanan']??0).'</td>';
                $html.='</tr></table>';
            }
            $tablo_html=$_POST['tablo_html']??'';
            if($tablo_html)$html.=$tablo_html;
            $html.="<div class='footer'>Jetone ERP — $tarih $saat</div></body></html>";
            $sonuc=satinSmtpSend($host,$port,$enc2,$user,$sifre,$fromAd,array_keys($email_set),$konu,$html);
            if($sonuc['ok'])echo json_encode(['ok'=>true,'sayi'=>count($email_set)]);
            else echo json_encode(['ok'=>false,'hata'=>$sonuc['hata']??'Gonderilemedi']);
        }catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen islem']);exit;
}

// ── SAYFA ────────────────────────────────────────────────────────────────────
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

// Tablo kontrolü
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `jit_siparis` (
        `jit_sip_id`           INT AUTO_INCREMENT PRIMARY KEY,
        `jit_sip_statu`        VARCHAR(20)   DEFAULT 'Aktif',
        `musteri_isim`         VARCHAR(250)  DEFAULT NULL,
        `musteri_firma_adi`    VARCHAR(250)  DEFAULT NULL,
        `musteri_mail`         VARCHAR(250)  DEFAULT NULL,
        `jit_sip_tarihi`       DATE          DEFAULT NULL,
        `jit_sip_saati`        VARCHAR(10)   DEFAULT '00:00',
        `ekleyen`              VARCHAR(250)  DEFAULT NULL,
        `guncelleyen`          VARCHAR(250)  DEFAULT NULL,
        `jit_sip_kodu`         VARCHAR(255)  NOT NULL,
        `jit_sip_baslik`       VARCHAR(255)  DEFAULT NULL,
        `jit_sip_miktar`       INT           DEFAULT 0,
        `jit_sip_sevk_miktari` INT           DEFAULT 0,
        `jit_sip_teslim_tarihi` DATE         DEFAULT NULL,
        `jit_son_irsaliye_no`  VARCHAR(50)   DEFAULT NULL,
        `jit_son_irsaliye_2`   VARCHAR(50)   DEFAULT NULL,
        `jit_sip_aciliyet`     VARCHAR(100)  DEFAULT 'Normal',
        `jit_sip_durum`        VARCHAR(100)  DEFAULT 'Yeni',
        `jit_sip_detay`        MEDIUMTEXT    DEFAULT NULL,
        `sip_ucret`            DECIMAL(10,2) DEFAULT NULL,
        `sip_baslama_tarih`    DATE          DEFAULT NULL,
        `jit_gecikme_nedeni`   VARCHAR(250)  DEFAULT NULL,
        `jit_dosya_yolu`       VARCHAR(500)  DEFAULT NULL,
        INDEX `idx_kodu`       (`jit_sip_kodu`),
        INDEX `idx_statu`      (`jit_sip_statu`),
        INDEX `idx_teslim`     (`jit_sip_teslim_tarihi`,`jit_sip_saati`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e){}

// Tarih filtresi
// Tüm aktif siparişler - tarih filtresi yok
try {
    $s=$db->query("SELECT * FROM jit_siparis WHERE jit_sip_statu='Aktif' ORDER BY jit_sip_teslim_tarihi ASC, jit_sip_saati ASC");
    $siparisler=$s->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $siparisler=[]; }

// Tiger stok
$stoklar=[];
if ($tigerdb_pdo) {
    try {
        $rows=$tigerdb_pdo->query("SELECT IT.CODE k, ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s
            FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
            LEFT JOIN dbo.LV_222_02_STINVTOT LV WITH(NOLOCK) ON LV.STOCKREF=IT.LOGICALREF
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE"
        )->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as $r) $stoklar[$r['k']]=(float)$r['s'];
    } catch(Throwable $e){}
}

// Rezervasyon — SAATLİK KÜMÜLATİF
// Siparişler tarih+saat sırasıyla işlenir, her sipariş için o ana kadar kalan stok hesaplanır
// Siparişleri önce tarih+saat sırala
$siparisler_sirali = $siparisler;
usort($siparisler_sirali, function($a, $b) {
    $ta = ($a['jit_sip_teslim_tarihi']??'9999-12-31') . ' ' . ($a['jit_sip_saati']??'00:00');
    $tb = ($b['jit_sip_teslim_tarihi']??'9999-12-31') . ' ' . ($b['jit_sip_saati']??'00:00');
    return strcmp($ta, $tb);
});

// Her stok kodu için kalan stoku kümülatif hesapla
$stok_kalan = $stoklar; // Başlangıç stoku
$sip_rezerv  = [];       // [sip_id => kalan_stok_o_an]

$sip_tuketim = []; // [sip_id => bu siparişe kadar tüketilen toplam]
foreach($siparisler_sirali as $sip){
    $id  = $sip['jit_sip_id'];
    $kod = $sip['jit_sip_kodu'];
    $kalan_sip = max(0, floatval($sip['jit_sip_miktar']) - floatval($sip['jit_sip_sevk_miktari']??0));
    if(!isset($stok_kalan[$kod])) $stok_kalan[$kod] = 0;
    $stok_kalan[$kod] -= $kalan_sip;
    $sip_rezerv[$id]   = $stok_kalan[$kod]; // Bu siparişten sonra kalan stok
    // Bu siparişe kadar birikmiş tüketim = başlangıç stoku - kalan
    $baslangic = $stoklar[$kod] ?? 0;
    $sip_tuketim[$id]  = $baslangic - $stok_kalan[$kod]; // = toplam tüketilen
}

// Geriye dönük uyumluluk için $rezervasyon (stok kodu bazlı toplam)
$rezervasyon = $stoklar;
foreach($siparisler as $sip){
    $kod = $sip['jit_sip_kodu'];
    $kalan = floatval($sip['jit_sip_miktar']) - floatval($sip['jit_sip_sevk_miktari']);
    if(!isset($rezervasyon[$kod])) $rezervasyon[$kod] = 0;
    $rezervasyon[$kod] -= $kalan;
}
?>
<style>
#tblJit tbody tr td:first-child { border-left: 4px solid transparent; }
table.dataTable tbody tr[style*='FEE2E2'] td,
table.dataTable tbody tr.odd[style*='FEE2E2'] td,
table.dataTable tbody tr.even[style*='FEE2E2'] td {
    background-color: #FEE2E2 !important;
}
.jit-edit{cursor:text;border-bottom:1px dashed #94A3B8;min-width:30px;display:inline-block;padding:1px 2px;border-radius:2px}
.jit-edit:focus{outline:2px solid #059669;background:#F0FDF4;border-bottom-color:transparent;padding:1px 4px}
.jit-saving{background:#FEF9C3!important}
.jit-saved {background:#D1FAE5!important;transition:background .5s}
.jit-err   {background:#FEE2E2!important;outline:2px solid #EF4444!important}
#jitFiltrePaneli{display:none}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">⚡ JIT / KMI Siparişleri</h1>
    <div class="s-yol">Satış / <b>Saatlik JIT Siparişleri</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo count($siparisler);?> kayıt</span>
    </div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
    <button onclick="jitTamamla()"
      style="background:#065F46;color:#fff;border:none;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">✅ Tamamlananları Kaldır</button>
    <button onclick="jitTumunuKaldir()"
      style="background:#DC2626;color:#fff;border:none;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">🗑 Tümünü Kaldır</button>
    <button onclick="jitIrsaliyeDus()" id="btnJitDus"
      style="background:#1E40AF;color:#fff;border:none;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">📥 İrsaliyeleri Düş</button>
    <button onclick="jitMailGonder()" id="btnJitMail"
      style="background:#0369A1;color:#fff;border:none;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">✉ Mail Gönder</button>
    <button onclick="document.getElementById('jitFiltrePaneli').style.display=document.getElementById('jitFiltrePaneli').style.display==='none'?'block':'none'"
      style="background:var(--bg);border:1px solid var(--kenar);padding:5px 11px;border-radius:6px;font-size:12px;cursor:pointer">⚙️ İşlemler</button>
  </div>
</div>

<!-- İşlemler Paneli -->
<div id="jitFiltrePaneli" style="display:none;padding-bottom:10px">
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px">

  <!-- Excel Yükle -->
  <div class="kart" style="padding:12px">
    <div style="font-weight:700;font-size:13px;margin-bottom:10px">📊 JIT Excel Yükle</div>
    <div style="font-size:11px;color:var(--m2);margin-bottom:8px">Kolon sırası: 1=Kodu, 2=Ad, 3=Tarih, 4=Saat, 5=SipNo, 6=Miktar, 8=Son İrs, 9=Sevk<br>İlk satır başlık, atlanır.</div>
    <label class="form-etiket">Firma</label>
    <input type="text" id="jitFirma" class="form-alan" value="ARÇELİK" style="margin-bottom:8px" placeholder="Firma adı...">
    <label class="form-etiket">Excel Dosyası (.xlsx)</label>
    <input type="file" id="jitDosya" accept=".xlsx,.xls" class="form-alan" style="margin-bottom:8px">
    <button onclick="jitExcelYukle()"
      style="background:#7C3AED;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;width:100%">📤 Yükle</button>
    <div id="jitExcelSonuc" style="margin-top:8px;font-size:11px;display:none"></div>
  </div>

</div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
<div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 220px)">
<table class="tablo" id="tblJit">
  <thead style="position:sticky;top:0;z-index:2">
    <tr>
      <th>#</th>
      <th>Önem</th>
      <th>Ürün Kodu</th>
      <th>Ürün Adı</th>
      <th>Teslim Tarihi ✏</th>
      <th>Saati ✏</th>
      <th>Son İrs. No</th>
      <th style="text-align:right">Sipariş ✏</th>
      <th style="text-align:right">Sevk ✏</th>
      <th style="text-align:right">Kalan</th>
      <th>Firma</th>
      <th style="text-align:right">Stok</th>
      <th style="text-align:right">Top. Rez.</th>
      <th style="text-align:right">Kümülatif</th>
      <th>Yeterlilik</th>
      <th>Başlama Tarihi</th>
      <th style="text-align:right">Gecikme</th>
      <th>Son İrs. No 2</th>
      <th style="text-align:center">İşlem</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>#</th><th>Önem</th><th>Ürün Kodu</th><th>Ürün Adı</th>
      <th>Teslim Tarihi</th><th>Saat</th><th>Son İrs. No</th>
      <th>Sipariş</th><th>Sevk</th><th>Kalan</th><th>Firma</th>
      <th>Stok</th><th>Toplam Rez.</th><th>Kümülatif Kalan</th><th>Yeterlilik</th>
      <th>Başlama</th><th>Gecikme</th><th>Son İrs. No 2</th><th></th>
    </tr>
  </tfoot>
  <tbody>
  <?php
  $say=0;
  foreach($siparisler as $sip):
      $say++;
      $kod  = $sip['jit_sip_kodu'];
      $mik  = floatval($sip['jit_sip_miktar']);
      $sevk = floatval($sip['jit_sip_sevk_miktari']);
      $kalan= $mik-$sevk;
      $stok = $stoklar[$kod]??0;
      $rezerv=$rezervasyon[$kod]??0;
      // SAATLİK KÜMÜLATİF: bu siparişten sonra kalan stok
      $sip_id_cur = $sip['jit_sip_id'];
      $kumulatif_kalan = $sip_rezerv[$sip_id_cur] ?? $rezerv;
      $yeterli = $kumulatif_kalan >= 0 ? 'Yeterli' : 'Yetersiz';

      // Gecikme: teslim tarihi+saati ile şimdi arasındaki fark (dakika hassasiyetli)
      $gecikme='';
      if(!empty($sip['jit_sip_teslim_tarihi'])&&!empty($sip['jit_sip_saati'])){
          $teslim=strtotime($sip['jit_sip_teslim_tarihi'].' '.$sip['jit_sip_saati']);
          $diff_dk=(int)round((time()-$teslim)/60);
          if($diff_dk>0) $gecikme='+'.$diff_dk.'dk';
          elseif($diff_dk<0) $gecikme=$diff_dk.'dk';
      } elseif(!empty($sip['sip_baslama_tarih'])&&!empty($sip['jit_sip_teslim_tarihi'])){
          $gecikme=(int)((strtotime($sip['sip_baslama_tarih'])-strtotime($sip['jit_sip_teslim_tarihi']))/86400).'gün';
      }

      $satir_bg = $yeterli==='Yetersiz' ? 'background:#FEE2E2;border-left:4px solid #DC2626' : 'border-left:4px solid transparent';
      // Kümülatif açık gösterimi
      $acik_miktar = $kumulatif_kalan < 0 ? abs($kumulatif_kalan) : 0;
      $acil_stl=$sip['jit_sip_aciliyet']==='Acil'?'color:#DC2626;font-weight:800':'';
      $gec_stl=strpos($gecikme,'+')===0?'color:#DC2626;font-weight:700':'color:#059669';
  ?>
  <tr data-id="<?php echo $sip['jit_sip_id'];?>" style="<?php echo $satir_bg;?>">
    <td><?php echo $say;?></td>
    <td style="<?php echo $acil_stl;?>"><?php echo htmlspecialchars($sip['jit_sip_aciliyet']??'');?></td>
    <td><code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($kod);?></code></td>
    <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo htmlspecialchars($sip['jit_sip_baslik']??'');?>"><?php echo htmlspecialchars($sip['jit_sip_baslik']??'');?></td>

    <td><span class="jit-edit" contenteditable="true"
        data-id="<?php echo $sip['jit_sip_id'];?>" data-kolon="jit_sip_teslim_tarihi"
        onblur="jitKaydet(this)"><?php echo htmlspecialchars($sip['jit_sip_teslim_tarihi']??'');?></span></td>

    <td style="font-weight:700;color:#065F46"><span class="jit-edit" contenteditable="true"
        data-id="<?php echo $sip['jit_sip_id'];?>" data-kolon="jit_sip_saati"
        onblur="jitKaydet(this)"><?php echo htmlspecialchars($sip['jit_sip_saati']??'');?></span></td>

    <td style="font-size:11px"><?php echo htmlspecialchars($sip['jit_son_irsaliye_no']??'');?></td>

    <td style="text-align:right"><span class="jit-edit" contenteditable="true"
        data-id="<?php echo $sip['jit_sip_id'];?>" data-kolon="jit_sip_miktar"
        onblur="jitKaydet(this)"><?php echo number_format($mik,0,',','.');?></span></td>

    <td style="text-align:right"><span class="jit-edit" contenteditable="true"
        data-id="<?php echo $sip['jit_sip_id'];?>" data-kolon="jit_sip_sevk_miktari"
        onblur="jitKaydet(this)"><?php echo number_format($sevk,0,',','.');?></span></td>

    <td style="text-align:right;font-weight:700;color:<?php echo $kalan>0?'#DC2626':'#059669';?>"
        id="jit_kalan_<?php echo $sip['jit_sip_id'];?>"><?php echo number_format($kalan,0,',','.');?></td>

    <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo htmlspecialchars($sip['musteri_firma_adi']??'');?></td>
    <td style="text-align:right;color:var(--m2)"><?php echo number_format($stok,0,',','.');?></td>
    <?php $tuketim = $sip_tuketim[$sip_id_cur] ?? 0; ?>
    <td style="text-align:right;font-weight:700;color:var(--m2)"><?php echo number_format($tuketim,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $kumulatif_kalan<0?'#DC2626':'#059669';?>"><?php echo $kumulatif_kalan<0?('⚠ '.number_format(abs($kumulatif_kalan),0,',','.')):number_format($kumulatif_kalan,0,',','.');?></td>
    <td><span style="background:<?php echo $yeterli==='Yeterli'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $yeterli==='Yeterli'?'#065F46':'#991B1B';?>;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700"><?php echo $yeterli;?></span></td>

    <td style="font-size:11px"><?php echo htmlspecialchars($sip['sip_baslama_tarih']??'');?></td>
    <td style="<?php echo $gec_stl;?>;font-size:11px;text-align:right"><?php echo $gecikme ?: '—';?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['jit_son_irsaliye_2']??'');?></td>

    <td style="text-align:center">
      <button onclick="jitSil(<?php echo $sip['jit_sip_id'];?>,this)"
        style="background:#FEE2E2;color:#991B1B;border:none;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:11px;font-weight:700">🗑</button>
    </td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($siparisler)):?>
  <tr><td colspan="18" style="text-align:center;padding:40px;color:var(--m2)">
    Aktif JIT siparişi bulunamadı.
  </td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>
</div>

<script>
function jitPost(d,cb){
  var fd=new FormData();
  Object.entries(d).forEach(function(kv){fd.append(kv[0],kv[1]||'');});
  var url=window.location.href.split('?')[0]+'?sayfa=satis-jit';
  fetch(url,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb)
  .catch(function(e){alert('Sunucu hatasi: '+e);});
}

function jitKaydet(el){
  var id=el.dataset.id,kolon=el.dataset.kolon;
  var deger=el.textContent.trim().replace(/\./g,'').replace(',','.');
  el.classList.add('jit-saving');
  jitPost({jit_action:'guncelle',id:id,kolon:kolon,deger:deger},function(d){
    el.classList.remove('jit-saving');
    if(d.ok){
      el.classList.add('jit-saved');
      setTimeout(function(){el.classList.remove('jit-saved');},1500);
      if(d.kalan!==undefined){
        var ke=document.getElementById('jit_kalan_'+id);
        if(ke){var k=parseFloat(d.kalan);ke.textContent=k.toLocaleString('tr-TR',{maximumFractionDigits:0});ke.style.color=k>0?'#DC2626':'#059669';}
      }
    } else {
      el.classList.add('jit-err');
      setTimeout(function(){el.classList.remove('jit-err');},2000);
    }
  });
}

function jitSil(id,btn){
  if(!confirm('Bu JIT siparisini silmek istediginize emin misiniz?'))return;
  jitPost({jit_action:'sil',id:id},function(d){
    if(d.ok){var tr=btn.closest('tr');if(tr)tr.remove();}
    else alert('Silinemedi: '+(d.hata||''));
  });
}

function jitTamamla(){
  if(!confirm('jit_sip_miktar <= jit_sip_sevk_miktari olan siparisler Tamamlandi yapilacak.'))return;
  jitPost({jit_action:'tamamla'},function(d){
    if(d.ok){alert(d.sayi+' siparis tamamlandi.');location.reload();}
    else alert('Hata: '+(d.hata||''));
  });
}

function jitTumunuKaldir(){
  if(!confirm('TUM aktif JIT siparisleri Pasif yapilacak. Emin misiniz?'))return;
  jitPost({jit_action:'tumunu_kaldir'},function(d){
    if(d.ok){alert(d.sayi+' siparis pasife alindi.');location.reload();}
    else alert('Hata: '+(d.hata||''));
  });
}

function jitIrsaliyeDus(){
  if(!confirm('Dusulen irsaliyeler tablosundaki irsaliyeler JIT siparislerine islenecek.'))return;
  var btn=document.getElementById('btnJitDus');
  btn.disabled=true;btn.textContent='Isleniyor...';
  jitPost({jit_action:'irsaliye_dus'},function(d){
    btn.disabled=false;btn.textContent='Irsaliyeleri Dus';
    if(d.ok){alert(d.irs_sayi+' irsaliye, '+d.guncellenen+' satira islendi.');location.reload();}
    else alert('Hata: '+(d.hata||''));
  });
}

function jitExcelYukle(){
  var dosya=document.getElementById('jitDosya').files[0];
  var firma=document.getElementById('jitFirma').value;
  var sonuc=document.getElementById('jitExcelSonuc');
  if(!dosya){alert('Dosya seçin.');return;}
  if(!firma){alert('Firma adı girin.');return;}
  var fd=new FormData();
  fd.append('jit_action','excel_yukle');
  fd.append('musteri',firma);
  fd.append('dosya',dosya);
  sonuc.style.display='block';sonuc.style.background='#FEF3C7';sonuc.innerHTML='Yukleniyor...';
  var url=window.location.href.split('?')[0]+'?sayfa=satis-jit';
  fetch(url,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    if(d.ok){sonuc.style.background='#D1FAE5';sonuc.innerHTML=''+d.eklendi+' kayit eklendi'+(d.hatali>0?' ('+d.hatali+' hatali)':'');document.getElementById('jitDosya').value='';setTimeout(function(){location.reload();},2000);}
    else{sonuc.style.background='#FEE2E2';sonuc.innerHTML=''+d.hata;}
  }).catch(function(e){sonuc.style.background='#FEE2E2';sonuc.innerHTML=''+e;});
}

function jitMailGonder(ekstra){
  var btn=document.getElementById('btnJitMail');
  btn.disabled=true;btn.textContent='Gonderiyor...';
  var rows=document.querySelectorAll('#tblJit tbody tr');
  var toplam=0,acil=0,yetersiz=0,tamamlanan=0;
  rows.forEach(function(tr){
    if(tr.cells.length<5)return;toplam++;
    if((tr.cells[1]||{}).textContent.trim()==='Acil')acil++;
    if(tr.querySelector('[style*="FEE2E2"]')&&tr.querySelector('[style*="FEE2E2"]').textContent.trim()==='Yetersiz')yetersiz++;
    if(tr.querySelector('[style*="D1FAE5"]')&&tr.querySelector('[style*="D1FAE5"]').textContent.trim()==='Yeterli'&&parseFloat((tr.cells[9]||{}).textContent||1)<=0)tamamlanan++;
  });
  var th='<table style="border-collapse:collapse;width:100%;font-size:11px"><thead><tr>';
  document.querySelectorAll('#tblJit thead tr:first-child th').forEach(function(t,i){if(i===17)return;th+='<th style="background:#065F46;color:#fff;padding:5px 8px;border:1px solid #047857;white-space:nowrap">'+t.textContent.replace(/✏/g,'').trim()+'</th>';});
  th+='</tr></thead><tbody>';
  rows.forEach(function(tr){
    if(tr.cells.length<5)return;var bg=tr.style.background||'';var row='<tr>';
    Array.from(tr.cells).forEach(function(td,i){if(i===17)return;row+='<td style="padding:3px 7px;border:1px solid #E2E8F0;background:'+bg+'">'+td.textContent.trim()+'</td>';});
    th+=row+'</tr>';
  });
  th+='</tbody></table>';
  var fd=new FormData();
  fd.append('jit_action','mail_gonder');
  fd.append('ozet_json',JSON.stringify({toplam:toplam,acil:acil,yetersiz:yetersiz,tamamlanan:tamamlanan}));
  fd.append('tablo_html',th);
  if(ekstra)fd.append('ekstra_mail',ekstra);
  var url=window.location.href.split('?')[0]+'?sayfa=satis-jit';
  fetch(url,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(d){
    btn.disabled=false;btn.textContent='Mail Gonder';
    if(d.ok)alert('Mail gonderildi: '+d.sayi+' alici');
    else if(d.hata==='bos'){var a=prompt((d.mesaj||'Email bulunamadi.')+' Manuel adres:','');if(a&&a.trim())jitMailGonder(a.trim());else alert('Mail gonderilmedi.');}
    else alert('Hata: '+d.hata);
  }).catch(function(e){btn.disabled=false;btn.textContent='Mail Gonder';alert('Hata: '+e);});
}

$(document).ready(function(){
  if(typeof $ === 'undefined'||!$.fn||!$.fn.DataTable)return;
  if($.fn.DataTable.isDataTable('#tblJit'))return;
  if($('#tblJit tbody tr').length===0)return;
  $('#tblJit').DataTable({
    paging:false,autoWidth:false,scrollX:true,
    scrollY:'calc(100vh - 260px)',scrollCollapse:true,
    order:[[4,'asc'],[5,'asc']],
    columnDefs:[{orderable:false,targets:17},{className:'dt-body-right',targets:[7,8,9,11,12]}],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'Excel',className:'btn-dt',filename:'JIT_Siparisler',
      exportOptions:{columns:':not(:last-child)',format:{body:function(data){var c=data.replace(/<[^>]*>/g,'').trim();return /^[\d\.]+$/.test(c.replace(/\s/g,''))?c.replace(/\./g,''):c;}}}}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(idx){
        if(idx===17)return;
        var col=this,th=$(col.footer());if(!th||!th.length)return;
        var lbl=th.text().trim();if(!lbl){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>')
          .appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>22?v.substr(0,22)+'...':v)+'</option>');});
      });
    }
  });
});
</script>
