<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
require_once dirname(dirname(__DIR__)) . '/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata = '';
$dusulen_map = []; // [irsaliye_no => db_row]
$satirlar = []; // Tiger'dan her kalem ayrı satır

// Düşülen kayıtları çek
try {
    $rows = $db->query("SELECT * FROM dusulen_irsaliyeler WHERE durum='aktif' ORDER BY olusturma DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) $dusulen_map[$r['irsaliye_no']] = $r;
} catch(Throwable $e) {}

// JIT stok kodları (arka plan mavi)
$jit_stok_set = [];
try {
    $jit_rows = $db->query("SELECT stok_kodu FROM jit_dahil_kodlar2 WHERE durum='jit'")->fetchAll(PDO::FETCH_COLUMN);
    $jit_stok_set = array_flip($jit_rows);
} catch(Throwable $e) {}

// Tiger'dan kalem detayları - GROUP BY yok, her satır ayrı
if ($tiger_ok && !empty($dusulen_map)) {
    try {
        $nos = array_keys($dusulen_map);
        $ph  = implode(',', array_fill(0, count($nos), '?'));
        $sql = "SELECT
            CONVERT(VARCHAR,STF.FICHENO) AS irsaliye_no,
            CONVERT(VARCHAR,STL.DATE_,104) AS tarih,
            CL.DEFINITION_ AS musteri,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END AS stok_kodu,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END AS stok_adi,
            STL.AMOUNT AS miktar,
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,'') AS aciklama,
            ISNULL(STF.SPECODE,'') AS tur_kodu,
            '01' AS ambar,
            STL.DATE_ AS sort_tarih
        FROM dbo.LG_222_01_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_01_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.FICHENO IN ($ph)
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)
        UNION ALL
        SELECT
            CONVERT(VARCHAR,STF.FICHENO),
            CONVERT(VARCHAR,STL.DATE_,104),
            CL.DEFINITION_,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END,
            STL.AMOUNT,
            ISNULL(STF.GENEXP1,'') + ' ' + ISNULL(STF.GENEXP2,''),
            ISNULL(STF.SPECODE,''),
            '02',
            STL.DATE_
        FROM dbo.LG_222_02_STLINE STL WITH(NOLOCK)
        LEFT JOIN dbo.LG_222_02_STFICHE STF WITH(NOLOCK) ON STF.LOGICALREF=STL.STFICHEREF
        LEFT JOIN dbo.LG_222_ITEMS IT WITH(NOLOCK) ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN dbo.LG_222_SRVCARD SRV WITH(NOLOCK) ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN dbo.LG_222_CLCARD CL WITH(NOLOCK) ON CL.LOGICALREF=STL.CLIENTREF
        WHERE STF.FICHENO IN ($ph)
          AND (IT.CODE IS NOT NULL OR SRV.CODE IS NOT NULL)
        ORDER BY sort_tarih DESC, irsaliye_no DESC";
        $s = $tigerdb_pdo->prepare($sql);
        $s->execute(array_merge($nos, $nos));
        $satirlar = $s->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// Tiger'da olmayan düşülen irsaliyeleri de ekle (DB kaydından)
$tiger_irs_set = array_flip(array_unique(array_column($satirlar, 'irsaliye_no')));
foreach ($dusulen_map as $no => $dbr) {
    if (!isset($tiger_irs_set[$no])) {
        $satirlar[] = [
            'irsaliye_no' => $no,
            'tarih'       => '—',
            'musteri'     => $dbr['firma'] ?? '—',
            'stok_kodu'   => '—',
            'stok_adi'    => '—',
            'miktar'      => '—',
            'tur_kodu'    => '—',
            'aciklama'    => '—',
            'ambar'       => '—',
        ];
    }
}

// Aynı irsaliye + stok kodu kombinasyonlarını grupla, miktarları topla
$grup_map = [];
foreach ($satirlar as $r) {
    $key = $r['irsaliye_no'] . '||' . ($r['stok_kodu']??'');
    if (!isset($grup_map[$key])) {
        $grup_map[$key] = $r;
        $grup_map[$key]['miktar'] = is_numeric($r['miktar']??'') ? floatval($r['miktar']) : $r['miktar'];
    } else {
        if (is_numeric($r['miktar']??'')) {
            $grup_map[$key]['miktar'] = floatval($grup_map[$key]['miktar']) + floatval($r['miktar']);
        }
    }
}
$satirlar = array_values($grup_map);
?>
<style>
#tbl-yeni-irs th,#tbl-yeni-irs td,
#tbl-dusulen-irs th,#tbl-dusulen-irs td{border:1px solid #CBD5E1!important;}
#tbl-yeni-irs thead th,#tbl-dusulen-irs thead th{border-bottom:2px solid #94A3B8!important;}
</style>
<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">✅ Düşülen Satış İrsaliyeleri</h1>
    <div class="s-yol">Satış / <b>Düşülen İrsaliyeler</b>
      <span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">(<?php echo count($dusulen_map);?> irsaliye, <?php echo count($satirlar);?> kalem)</span>
    </div>
  </div>
</div>

<div class="s-body">
<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px;border-radius:8px;margin-bottom:12px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>

<?php if(!empty($satirlar)): ?>
<div class="kart" style="overflow:hidden">
  <table class="tablo" id="tbl-dusulen-irs" style="border-collapse:collapse">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="text-align:center;width:80px">İşlem</th>
        <th>İrsaliye No</th>
        <th>İrs. Tarihi</th>
        <th>Müşteri</th>
        <th>Stok Kodu</th>
        <th>Stok Adı</th>
        <th style="text-align:right">Miktar</th>
        <th>Tür Kodu</th>
        <th>Açıklama</th>
        <th>Ambar</th>
        <th>Düşme Tarihi</th>
      </tr>
    </thead>
    <tfoot>
      <tr><th></th><th>İrsaliye No</th><th>Tarih</th><th>Müşteri</th>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Miktar</th><th>Tür Kodu</th>
      <th>Açıklama</th><th>Ambar</th><th>Düşme Tarihi</th></tr>
    </tfoot>
    <tbody>
    <?php
    $gosterilen_irs = [];
    foreach($satirlar as $r):
        $no     = $r['irsaliye_no'];
        $dbr    = $dusulen_map[$no] ?? null;
        $ilk_mi = !in_array($no, $gosterilen_irs);
        if ($ilk_mi) $gosterilen_irs[] = $no;
    ?>
    <?php $row_bg = isset($jit_stok_set[$r['stok_kodu']??'']) ? '#DBEAFE' : '#F0FDF4'; ?>
    <tr data-no="<?php echo htmlspecialchars($no);?>" style="background:<?php echo $row_bg;?>">
      <td style="text-align:center;white-space:nowrap">
        <?php if($ilk_mi): ?>
        <button onclick="irsIptal(<?php echo htmlspecialchars(json_encode($no));?>)"
          style="background:#DC2626;color:#fff;border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">
          ↩ İptal
        </button>
        <?php endif;?>
      </td>
      <td style="font-weight:700;color:#0369A1;white-space:nowrap"><?php echo htmlspecialchars($no);?></td>
      <td style="font-size:11px;white-space:nowrap"><?php echo htmlspecialchars($r['tarih']??'');?></td>
      <td style="white-space:nowrap"><?php echo htmlspecialchars($r['musteri']??'');?></td>
      <td><code style="background:rgba(0,0,0,.05);padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']??'');?></code></td>
      <td style="white-space:nowrap"><?php echo htmlspecialchars($r['stok_adi']??'');?></td>
      <td style="text-align:right"><?php echo is_numeric($r['miktar']??'') ? number_format((float)$r['miktar'],0,',','.') : ($r['miktar']??'—');?></td>
      <td style="font-size:11px"><?php echo htmlspecialchars($r['tur_kodu']??'');?></td>
      <td style="font-size:11px;white-space:nowrap"><?php echo htmlspecialchars(trim($r['aciklama']??''));?></td>
      <td style="font-size:11px;text-align:center"><?php echo htmlspecialchars($r['ambar']??'');?></td>
      <td style="font-size:11px;color:#64748B;white-space:nowrap"><?php echo $dbr && $dbr['olusturma'] ? date('d.m.Y H:i', strtotime($dbr['olusturma'])) : '—';?></td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:20px;text-align:center;color:var(--m2)">Düşülen irsaliye bulunamadı.</div>
<?php endif;?>
</div>

<script>
function irsIptal(no) {
  if(!confirm(no+' numaralı irsaliye iptal edilsin mi? Yeni listesine geri döner.')) return;
  var fd=new FormData();
  fd.append('action','iptal');
  fd.append('irsaliye_no',no);
  fetch('<?php echo BASE_URL;?>/bolumler/satis/irsaliye_islem.php',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();})
  .then(function(d){
    if(d.ok){
      document.querySelectorAll('#tbl-dusulen-irs tr[data-no="'+no+'"]').forEach(function(tr){tr.remove();});
      alert('✅ '+d.message);
    } else alert('❌ '+d.message);
  }).catch(function(e){alert('Hata: '+e);});
}

$(document).ready(function(){
  if(typeof $ === 'undefined' || !$.fn || !$.fn.DataTable) return;
  if(!$.fn.DataTable||$.fn.DataTable.isDataTable('#tbl-dusulen-irs'))return;
  if($('#tbl-dusulen-irs tbody tr').length===0)return; // Veri yok
  $('#tbl-dusulen-irs').DataTable({
    paging:false,autoWidth:false,scrollY:'560px',scrollCollapse:true,
    order:[[10,'desc']],
    columnDefs:[{orderable:false,targets:0}],
    dom:'Bfrtip',
    buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Dusulen_Irsaliyeler',exportOptions:{columns:':not(:first-child)'}}],
    language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json'},
    initComplete:function(){
      this.api().columns().every(function(idx){
        var col=this,th=$(col.footer());
        if(!th||!th.length||idx===0)return;
        var lbl=th.text().trim();if(!lbl){th.empty();return;}
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+(v.length>25?v.substr(0,25)+'…':v)+'</option>');});
      });
    }
  });
});
</script>
