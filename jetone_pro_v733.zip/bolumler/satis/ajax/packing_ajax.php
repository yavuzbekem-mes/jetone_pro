<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
ob_end_clean();
Auth::zorunlu();

header('Content-Type: application/json');
error_reporting(0);

$action = $_POST['action'] ?? '';

try {
    switch($action) {
        case 'save':     echo json_encode(plKaydet($_POST)); break;
        case 'update':   echo json_encode(plGuncelle($_POST)); break;
        case 'get':      echo json_encode(plGetir($_POST['id'])); break;
        case 'delete':   echo json_encode(plSil($_POST['id'])); break;
        case 'search_product': echo json_encode(plUrunAra($_POST['product_code'])); break;
        default: echo json_encode(['success'=>false,'message'=>'Geçersiz işlem']);
    }
} catch(Throwable $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}

function plNoUret() {
    global $db;
    $year = date('Y');
    $stmt = $db->prepare("SELECT last_number FROM packing_sequence WHERE year=?");
    $stmt->execute([$year]);
    $row = $stmt->fetch();
    if (!$row) {
        $db->prepare("INSERT INTO packing_sequence (year,last_number) VALUES (?,1)")->execute([$year]);
        $no = 1;
    } else {
        $no = $row['last_number'] + 1;
        $db->prepare("UPDATE packing_sequence SET last_number=? WHERE year=?")->execute([$no,$year]);
    }
    return sprintf("PL%s%04d", $year, $no);
}

function plKaydet($d) {
    global $db;
    if (empty($d['irsaliye_no'])) throw new Exception('İrsaliye No zorunludur');
    if (empty($d['customer_name'])) throw new Exception('Müşteri Adı zorunludur');
    if (empty($d['packing_date'])) throw new Exception('Tarih zorunludur');

    $db->beginTransaction();
    try {
        $pno = plNoUret();
        $cbm = (floatval($d['total_net_weight']??0)/1000)*1.2;
        $stmt = $db->prepare("INSERT INTO packing_lists (packing_no,irsaliye_no,customer_name,packing_date,order_number,reference_number,truck_plate,trailer_plate,driver_name,driver_phone,special_info,total_packets,total_brut_weight,total_net_weight,total_cbm,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$pno,$d['irsaliye_no'],$d['customer_name'],$d['packing_date'],$d['order_number']??'',$d['reference_number']??'',$d['truck_plate']??'',$d['trailer_plate']??'',$d['driver_name']??'',$d['driver_phone']??'',$d['special_info']??'',intval($d['total_packets']??0),floatval($d['total_brut_weight']??0),floatval($d['total_net_weight']??0),$cbm,$_SESSION['kullanici_id']]);
        $pid = $db->lastInsertId();
        plItemsKaydet($pid, $d['items']??'');
        $db->commit();
        return ['success'=>true,'message'=>"Packing List $pno kaydedildi",'packing_no'=>$pno];
    } catch(Throwable $e) { $db->rollBack(); throw $e; }
}

function plGuncelle($d) {
    global $db;
    if (empty($d['id'])) throw new Exception('ID eksik');
    $cbm = (floatval($d['total_net_weight']??0)/1000)*1.2;
    $db->beginTransaction();
    try {
        $db->prepare("UPDATE packing_lists SET irsaliye_no=?,customer_name=?,packing_date=?,order_number=?,reference_number=?,truck_plate=?,trailer_plate=?,driver_name=?,driver_phone=?,special_info=?,total_packets=?,total_brut_weight=?,total_net_weight=?,total_cbm=?,updated_at=NOW() WHERE id=?")->execute([$d['irsaliye_no']??'',$d['customer_name']??'',$d['packing_date']??date('Y-m-d'),$d['order_number']??'',$d['reference_number']??'',$d['truck_plate']??'',$d['trailer_plate']??'',$d['driver_name']??'',$d['driver_phone']??'',$d['special_info']??'',intval($d['total_packets']??0),floatval($d['total_brut_weight']??0),floatval($d['total_net_weight']??0),$cbm,$d['id']]);
        $db->prepare("DELETE FROM packing_list_items WHERE packing_list_id=?")->execute([$d['id']]);
        plItemsKaydet($d['id'], $d['items']??'');
        $db->commit();
        return ['success'=>true,'message'=>'Packing List güncellendi'];
    } catch(Throwable $e) { $db->rollBack(); throw $e; }
}

function plItemsKaydet($pid, $items_json) {
    global $db;
    if (empty($items_json)) return;
    $items = json_decode($items_json, true);
    if (!$items) return;
    $stmt = $db->prepare("INSERT INTO packing_list_items (packing_list_id,item_row,palet_no,packet_quantity,unit_quantity,total_quantity,order_number,article_no,description,brut_weight,product_code,colour,net_weight,width,length,height,total_m3) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach($items as $i => $it) {
        $stmt->execute([$pid,$i+1,$it['palet_no']??1,$it['packet_quantity']??0,$it['unit_quantity']??0,$it['total_quantity']??0,$it['order_number']??'',$it['article_no']??'',$it['description']??'',$it['brut_weight']??0,$it['product_code']??'',$it['colour']??'',$it['net_weight']??0,$it['width']??0,$it['length']??0,$it['height']??0,$it['total_m3']??0]);
    }
}

function plGetir($id) {
    global $db;
    $stmt = $db->prepare("SELECT * FROM packing_lists WHERE id=?");
    $stmt->execute([$id]);
    $pl = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$pl) throw new Exception('Packing list bulunamadı');
    $stmt = $db->prepare("SELECT * FROM packing_list_items WHERE packing_list_id=? ORDER BY item_row");
    $stmt->execute([$id]);
    $pl['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return ['success'=>true,'data'=>$pl];
}

function plSil($id) {
    global $db;
    $stmt = $db->prepare("SELECT status FROM packing_lists WHERE id=?");
    $stmt->execute([$id]);
    $status = $stmt->fetchColumn();
    if ($status !== 'draft') throw new Exception('Sadece taslak durumundaki kayıtlar silinebilir');
    $db->prepare("DELETE FROM packing_lists WHERE id=?")->execute([$id]);
    return ['success'=>true,'message'=>'Packing List silindi'];
}

function plDurumGuncelle($id, $status) {
    global $db;
    $stmt = $db->prepare("SELECT status FROM packing_lists WHERE id=?");
    $stmt->execute([$id]);
    $old = $stmt->fetchColumn();
    $db->prepare("UPDATE packing_lists SET status=?,updated_at=NOW() WHERE id=?")->execute([$status,$id]);
    $db->prepare("INSERT INTO packing_list_status_log (packing_list_id,old_status,new_status,changed_by) VALUES (?,?,?,?)")->execute([$id,$old,$status,$_SESSION['kullanici_id']]);
    return ['success'=>true,'message'=>'Durum güncellendi'];
}

function plUrunAra($product_code) {
    global $db;
    if (empty($product_code)) return ['success'=>false,'data'=>null];

    // packing_list_items tablosundan bu product_code ile en son kullanılan satırı getir
    $stmt = $db->prepare("
        SELECT product_code, article_no, description, colour,
               brut_weight, net_weight, width, length, height,
               unit_quantity, packet_quantity, order_number
        FROM packing_list_items
        WHERE product_code = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([trim($product_code)]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        return ['success'=>true,'data'=>$row];
    }

    // article_no ile de dene
    $stmt = $db->prepare("
        SELECT product_code, article_no, description, colour,
               brut_weight, net_weight, width, length, height,
               unit_quantity, packet_quantity, order_number
        FROM packing_list_items
        WHERE article_no = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([trim($product_code)]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return ['success'=>true,'data'=>$row ?: null];
}
