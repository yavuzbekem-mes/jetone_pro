<?php
ob_start();
if (!empty($_POST['tl_action'])) {
    ob_end_clean();
    error_reporting(0);
    require_once dirname(dirname(__DIR__)).'/core/config.php';
    require_once dirname(dirname(__DIR__)).'/core/db.php';
    require_once dirname(dirname(__DIR__)).'/core/auth.php';
    header('Content-Type: application/json; charset=utf-8');
    Auth::zorunlu();
    $action = $_POST['tl_action'];

    if ($action === 'olustur') {
        try {
            $arac_kapasiteler = json_decode($_POST['arac_kapasiteler']??'[]', true);
            if (empty($arac_kapasiteler)) { echo json_encode(['ok'=>false,'hata'=>'Araç kapasitesi girilmedi']); exit; }

            // Önceki listeyi temizle
            $db->exec("TRUNCATE TABLE toplama_listesi_detay");

            $onceki_max_id = 0;
            $sonuclar = [];

            foreach ($arac_kapasiteler as $arac_idx => $kapasite_str) {
                $arac_no   = $arac_idx + 1;
                $taban_say = (int)filter_var($kapasite_str, FILTER_SANITIZE_NUMBER_INT);
                if ($taban_say < 1) continue;

                // Kolon adı: 5_taban, 10_taban, 15_taban, 18_taban
                $col_taban = $taban_say . '_taban';

                // Siparişleri çek - önceki araçtan kalan + yeni siparişler
                $sql = "SELECT
                    j.jit_sip_id,
                    j.jit_sip_kodu,
                    j.jit_sip_baslik AS malzeme_adi,
                    j.jit_sip_miktar,
                    COALESCE(j.jit_sip_sevk_miktari,0) AS sevk,
                    k2.paket_miktari,
                    k2.`$col_taban` AS taban_hedef,
                    k2.kasa_tipi,
                    j.jit_sip_teslim_tarihi,
                    j.jit_sip_saati,
                    COALESCE(prev.kalan_miktar, j.jit_sip_miktar - COALESCE(j.jit_sip_sevk_miktari,0)) AS islenecek_miktar
                FROM jit_siparis j
                INNER JOIN jit_dahil_kodlar2 k2 ON k2.stok_kodu COLLATE utf8mb4_unicode_ci = j.jit_sip_kodu COLLATE utf8mb4_unicode_ci
                LEFT JOIN (
                    SELECT siparis_id, kalan_miktar
                    FROM toplama_listesi_detay
                    WHERE arac_no = ? AND kalan_miktar > 0
                ) prev ON prev.siparis_id = j.jit_sip_id
                WHERE j.jit_sip_statu = 'Aktif'
                  AND k2.`$col_taban` > 0
                  AND (
                    prev.siparis_id IS NOT NULL
                    OR j.jit_sip_id > ?
                  )
                ORDER BY j.jit_sip_teslim_tarihi ASC, j.jit_sip_saati ASC, j.jit_sip_id ASC";

                $s = $db->prepare($sql);
                $s->execute([$arac_no - 1, $onceki_max_id]);
                $siparisler = $s->fetchAll(PDO::FETCH_ASSOC);

                $birikim_taban = 0.0;
                $arac_max_id   = $onceki_max_id;

                foreach ($siparisler as $sip) {
                    if ($birikim_taban >= 1.0) break;

                    $islenecek  = floatval($sip['islenecek_miktar']);
                    $taban_hdf  = floatval($sip['taban_hedef']);
                    $paket_mik  = max(1, (int)$sip['paket_miktari']);

                    if ($islenecek <= 0 || $taban_hdf <= 0) continue;

                    $kalan_kap  = 1.0 - $birikim_taban;
                    $maks_miktar= $kalan_kap * $taban_hdf;

                    // Kaç kasa sığar?
                    $maks_kasa  = (int)floor($maks_miktar / $paket_mik);
                    if ($maks_kasa < 1) {
                        // Kesri varsa en az 1 kasa ekle, %1 tolerans
                        if ($kalan_kap * $taban_hdf >= $paket_mik * 0.99) $maks_kasa = 1;
                        else continue;
                    }

                    // Bu sipariş için gereken toplam kasa
                    $gerekli_kasa = (int)ceil($islenecek / $paket_mik);
                    $kasa_adedi   = min($gerekli_kasa, $maks_kasa);

                    // 0.9+ ise 1 ekstra kasa ekle (taşıma toleransı)
                    if ($birikim_taban >= 0.9 && $kasa_adedi < $gerekli_kasa) {
                        $ekstra_taban = $paket_mik / $taban_hdf;
                        if ($birikim_taban + ($kasa_adedi + 1) * ($paket_mik / $taban_hdf) <= 1.01) {
                            $kasa_adedi++;
                        }
                    }

                    $alinacak   = $kasa_adedi * $paket_mik;
                    $kalan_mik  = max(0, $islenecek - $alinacak);
                    $kul_taban  = $alinacak / $taban_hdf;

                    $db->prepare("INSERT INTO toplama_listesi_detay
                        (siparis_id,arac_no,malzeme_kodu,malzeme_adi,kasa_tipi,
                         toplam_miktar,kalan_miktar,alinacak_miktar,kasa_miktari,
                         kasa_adedi,taban_hedef,taban_kullanim,birikimli_taban,
                         teslim_tarihi,teslim_saati)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([
                        $sip['jit_sip_id'], $arac_no,
                        $sip['jit_sip_kodu'], $sip['malzeme_adi'], $sip['kasa_tipi']??'',
                        $islenecek, $kalan_mik, $alinacak, $paket_mik,
                        $kasa_adedi, $taban_hdf, $kul_taban,
                        $birikim_taban + $kul_taban,
                        $sip['jit_sip_teslim_tarihi'], $sip['jit_sip_saati']
                    ]);

                    $birikim_taban += $kul_taban;
                    if ($sip['jit_sip_id'] > $arac_max_id) $arac_max_id = $sip['jit_sip_id'];
                }

                // Bu araçtaki tamamen kapanan siparişlerin max id'sini kaydet
                $row = $db->query("SELECT MAX(siparis_id) mx FROM toplama_listesi_detay WHERE arac_no=$arac_no AND kalan_miktar=0")->fetch(PDO::FETCH_ASSOC);
                $onceki_max_id = max($onceki_max_id, (int)($row['mx']??0));

                // Sonuçları çek
                $rows = $db->query("SELECT * FROM toplama_listesi_detay WHERE arac_no=$arac_no ORDER BY teslim_tarihi ASC, teslim_saati ASC")->fetchAll(PDO::FETCH_ASSOC);
                $sonuclar[$arac_no] = [
                    'kapasite' => $kapasite_str,
                    'taban'    => $taban_say,
                    'satirlar' => $rows,
                    'birikim'  => $birikim_taban,
                ];
            }
            echo json_encode(['ok'=>true,'sonuclar'=>$sonuclar]);
        } catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false]); exit;
}

require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
Auth::zorunlu();

// Tabloları oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `jit_dahil_kodlar2` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `stok_kodu` VARCHAR(100) NOT NULL,
        `durum` VARCHAR(50) NOT NULL,
        `kasa_tipi` VARCHAR(50) DEFAULT NULL,
        `paket_miktari` INT DEFAULT NULL,
        `taban_miktari` INT DEFAULT NULL,
        `5_taban` INT DEFAULT NULL,
        `10_taban` INT DEFAULT NULL,
        `15_taban` INT DEFAULT NULL,
        `18_taban` INT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS `toplama_listesi_detay` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `siparis_id` INT DEFAULT NULL,
        `arac_no` INT DEFAULT NULL,
        `malzeme_kodu` VARCHAR(100) DEFAULT NULL,
        `malzeme_adi` VARCHAR(300) DEFAULT NULL,
        `kasa_tipi` VARCHAR(100) DEFAULT NULL,
        `toplam_miktar` DECIMAL(14,2) DEFAULT 0,
        `kalan_miktar` DECIMAL(14,2) DEFAULT 0,
        `alinacak_miktar` DECIMAL(14,2) DEFAULT 0,
        `kasa_miktari` INT DEFAULT NULL,
        `kasa_adedi` INT DEFAULT NULL,
        `taban_hedef` DECIMAL(14,4) DEFAULT 0,
        `taban_kullanim` DECIMAL(14,4) DEFAULT 0,
        `birikimli_taban` DECIMAL(14,4) DEFAULT 0,
        `teslim_tarihi` DATE DEFAULT NULL,
        `teslim_saati` VARCHAR(10) DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_arac` (`arac_no`),
        INDEX `idx_siparis` (`siparis_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch(Throwable $e){}

// Kapasite seçenekleri
$kapasite_secenekler = ['5 TABAN', '10 TABAN', '15 TABAN', '18 TABAN'];
?>
<style>
.tl-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:14px;margin-bottom:16px}
.tl-arac-baslik{font-size:14px;font-weight:800;color:#1E40AF;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #BFDBFE}
.tl-table{width:100%;border-collapse:collapse;font-size:12px}
.tl-table th{background:#1E40AF;color:#fff;padding:6px 10px;border:1px solid #2d5986;text-align:left;white-space:nowrap}
.tl-table td{padding:5px 9px;border:1px solid #E2E8F0;vertical-align:middle}
.tl-table tr:nth-child(even) td{background:#F8FAFC}
.tl-table tfoot td{background:#1E3A5F;color:#fff;font-weight:700;border:1px solid #2d5986}
.tl-imza{border:1px solid #E2E8F0;border-radius:8px;padding:12px 16px;margin-top:12px}
.tl-imza-satir{display:flex;align-items:center;margin-bottom:10px}
.tl-imza-satir:last-child{margin-bottom:0}
.tl-imza-etiket{font-weight:600;font-size:13px;width:160px;flex-shrink:0}
.tl-imza-cizgi{flex:1;border-bottom:2px solid #94A3B8;margin-left:8px;min-height:22px}
@media print{
  .no-print{display:none!important}
  .panel-icerik{margin-left:0!important}
  .kart{box-shadow:none!important;border:none!important}
}
</style>

<div class="s-bar no-print" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🚛 JIT Toplama Listesi</h1>
    <div class="s-yol">Satış / <b>Araç Yükleme Planı</b></div>
  </div>
</div>

<!-- Araç Kapasite Formu -->
<div class="kart no-print" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:13px;margin-bottom:12px">🚛 Araç Kapasitelerini Girin</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:14px" id="aracFormu">
    <?php for($i=1;$i<=3;$i++): ?>
    <div>
      <label class="form-etiket"><?php echo $i;?>. Araç</label>
      <select id="arac<?php echo $i;?>" class="form-alan">
        <option value="">— Araç Yok —</option>
        <?php foreach($kapasite_secenekler as $k): ?>
        <option value="<?php echo $k;?>"><?php echo $k;?></option>
        <?php endforeach;?>
      </select>
    </div>
    <?php endfor;?>
  </div>
  <button onclick="tlOlustur()" id="btnTlOlustur"
    style="background:linear-gradient(135deg,#1E40AF,#1e3a5f);color:#fff;border:none;padding:8px 20px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">
    🚛 Toplama Listesi Oluştur
  </button>
  <span id="tlDurum" style="margin-left:12px;font-size:12px;color:var(--m2)"></span>
</div>

<!-- Sonuçlar -->
<div id="tlSonuclar"></div>

<script>
function tlPost(d,cb){
  var fd=new FormData();
  Object.entries(d).forEach(function(e){fd.append(e[0],typeof e[1]==='object'?JSON.stringify(e[1]):e[1]);});
  fetch(window.location.href,{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb).catch(function(e){alert('Hata:'+e);});
}

function tlOlustur(){
  var kapasiteler=[];
  for(var i=1;i<=3;i++){
    var v=document.getElementById('arac'+i).value;
    if(v) kapasiteler.push(v);
  }
  if(!kapasiteler.length){alert('En az bir araç kapasitesi seçin.');return;}

  var btn=document.getElementById('btnTlOlustur');
  var dur=document.getElementById('tlDurum');
  btn.disabled=true; btn.textContent='⏳ Hesaplanıyor...';
  dur.textContent='';

  tlPost({tl_action:'olustur',arac_kapasiteler:kapasiteler},function(d){
    btn.disabled=false; btn.textContent='🚛 Toplama Listesi Oluştur';
    if(!d.ok){alert('Hata: '+(d.hata||''));return;}

    var html='';
    Object.keys(d.sonuclar).forEach(function(aracNo){
      var arac=d.sonuclar[aracNo];
      if(!arac.satirlar||!arac.satirlar.length){html+='<div class="tl-kart"><p style="color:var(--m2)">'+aracNo+'. Araç için sipariş bulunamadı.</p></div>';return;}

      // Gruplama
      var gruplar={};
      arac.satirlar.forEach(function(r){
        var k=r.malzeme_kodu;
        if(!gruplar[k]) gruplar[k]={malzeme_kodu:k,malzeme_adi:r.malzeme_adi,kasa_tipi:r.kasa_tipi,alinacak:0,kasa_adedi:0,taban:0};
        gruplar[k].alinacak+=parseFloat(r.alinacak_miktar);
        gruplar[k].kasa_adedi+=parseInt(r.kasa_adedi);
        gruplar[k].taban+=parseFloat(r.taban_kullanim);
      });

      // İlk sipariş tarihi/saati
      var ilk=arac.satirlar[0];
      var ilkTarih=ilk.teslim_tarihi?ilk.teslim_tarihi.replace(/-/g,'.'):'';
      var ilkSaat=ilk.teslim_saati||'';

      var birikim=parseFloat(arac.birikim||0);
      var pct=Math.min(100,Math.round(birikim*100));

      html+='<div class="tl-kart" id="tlArac'+aracNo+'">';
      html+='<div class="tl-arac-baslik">🚛 '+aracNo+'. Araç — '+arac.kapasite;
      if(ilkTarih) html+=' &nbsp;|&nbsp; <span style="font-size:12px;font-weight:600;color:#374151">İlk Sevk: '+ilkTarih+' '+ilkSaat+'</span>';
      html+='</div>';

      // Doluluk barı
      html+='<div style="background:#E2E8F0;border-radius:6px;height:10px;margin-bottom:12px"><div style="background:linear-gradient(90deg,#22C55E,#F97316 80%,#EF4444);width:'+pct+'%;height:10px;border-radius:6px"></div></div>';
      html+='<div style="font-size:11px;color:var(--m2);margin-bottom:10px">Araç doluluk: <b>%'+pct+'</b></div>';

      // Tablo
      html+='<div style="overflow-x:auto"><table class="tl-table">';
      html+='<thead><tr><th>Ürün Kodu</th><th>Ürün Adı</th><th>Kasa Tipi</th><th style="text-align:right">Toplam Kalan</th><th style="text-align:right">Alınacak</th><th style="text-align:right">Toplam Kasa</th><th style="text-align:right">Araç Kap.</th><th>TOPLANAN</th><th>K-550</th><th>MAVİ</th><th>PALET</th><th>SEPERATÖR</th></tr></thead>';
      html+='<tbody>';
      var topKalan=0,topKasa=0,topTaban=0;
      Object.values(gruplar).forEach(function(g){
        topKalan+=g.alinacak; topKasa+=g.kasa_adedi; topTaban+=g.taban;
        html+='<tr>';
        html+='<td style="font-weight:700">'+g.malzeme_kodu+'</td>';
        html+='<td>'+g.malzeme_adi+'</td>';
        html+='<td style="font-size:11px">'+g.kasa_tipi+'</td>';
        html+='<td style="text-align:right">'+Math.round(g.alinacak).toLocaleString('tr-TR')+'</td>';
        html+='<td style="text-align:right;font-weight:700">'+Math.round(g.alinacak).toLocaleString('tr-TR')+'</td>';
        html+='<td style="text-align:right">'+g.kasa_adedi+'</td>';
        html+='<td style="text-align:right">'+g.taban.toFixed(2).replace('.',',')+'</td>';
        html+='<td></td><td></td><td></td><td></td><td></td>';
        html+='</tr>';
      });
      html+='</tbody>';
      html+='<tfoot><tr><td>—</td><td>TOPLAM</td><td></td>';
      html+='<td style="text-align:right">'+Math.round(topKalan).toLocaleString('tr-TR')+'</td>';
      html+='<td style="text-align:right">'+Math.round(topKalan).toLocaleString('tr-TR')+'</td>';
      html+='<td style="text-align:right">'+topKasa+'</td>';
      html+='<td style="text-align:right">'+topTaban.toFixed(2).replace('.',',')+'</td>';
      html+='<td></td><td></td><td></td><td></td><td></td>';
      html+='</tr></tfoot>';
      html+='</table></div>';

      // İmza alanı
      html+='<div class="tl-imza">';
      ['Toplayan Personel','Kontrol Eden','İrsaliye No','Araç Plakası'].forEach(function(lbl){
        html+='<div class="tl-imza-satir"><span class="tl-imza-etiket">'+lbl+':</span><div class="tl-imza-cizgi">&nbsp;</div></div>';
      });
      html+='</div>';

      // Yazdır butonu
      html+='<div class="no-print" style="text-align:right;margin-top:10px">';
      html+='<button onclick="tlYazdir('+aracNo+')" style="background:#374151;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer">🖨 '+aracNo+'. Aracı Yazdır</button>';
      html+='</div>';
      html+='</div>';
    });

    document.getElementById('tlSonuclar').innerHTML=html;
    dur.textContent='✅ Oluşturuldu';
  });
}

function tlYazdir(aracNo){
  // Diğer araçları gizle
  document.querySelectorAll('[id^="tlArac"]').forEach(function(el){
    el.style.display=el.id==='tlArac'+aracNo?'':'none';
  });
  window.print();
  document.querySelectorAll('[id^="tlArac"]').forEach(function(el){el.style.display='';});
}
</script>
