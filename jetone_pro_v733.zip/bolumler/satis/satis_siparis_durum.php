<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
set_time_limit(0);

$tiger_ok = ($tigerdb_pdo !== null);
$hata     = '';

$currentYear  = (int)date('Y');
$currentMonth = (int)date('m');
$selYear      = isset($_POST['year'])  ? (int)$_POST['year']  : $currentYear;
$selMonth     = isset($_POST['month']) ? (int)$_POST['month'] : $currentMonth;

$years  = range($currentYear, $currentYear - 4);
$months = [1=>'Ocak',2=>'Şubat',3=>'Mart',4=>'Nisan',5=>'Mayıs',6=>'Haziran',
           7=>'Temmuz',8=>'Ağustos',9=>'Eylül',10=>'Ekim',11=>'Kasım',12=>'Aralık'];
$baslik = ($months[$selMonth] ?? '') . ' ' . $selYear;

$satis   = [];
$siparis = [];
$combined = [];
$sip_hata = '';
$sip_kayit = 0;

$jit_kodlar = [];
try { $jit_kodlar = $db->query("SELECT stok_kodu FROM jit_dahil_kodlar")->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $e){}

// 1) Tiger - Gerçekleşen Satışlar
if ($tiger_ok) {
    try {
        $tpl = "SELECT
            CL.DEFINITION_ musteri,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.CODE ELSE SRV.CODE END stok_kodu,
            CASE WHEN IT.CODE IS NOT NULL THEN IT.NAME ELSE SRV.DEFINITION_ END stok_adi,
            SUM(STL.AMOUNT) miktar
        FROM LG_222_{D}_STLINE STL WITH(NOLOCK)
        LEFT JOIN LG_222_ITEMS IT ON IT.LOGICALREF=STL.STOCKREF AND STL.LINETYPE=0
        LEFT JOIN LG_222_SRVCARD SRV ON SRV.LOGICALREF=STL.STOCKREF
        LEFT JOIN LG_222_CLCARD CL ON CL.LOGICALREF=STL.CLIENTREF
        LEFT JOIN LG_222_{D}_STFICHE STF ON STF.LOGICALREF=STL.STFICHEREF
        WHERE STF.TRCODE=8 AND STL.YEAR_=? AND STL.MONTH_=?
        GROUP BY CL.DEFINITION_,IT.CODE,SRV.CODE,IT.NAME,SRV.DEFINITION_";

        foreach (['01','02'] as $d) {
            $rows = $tigerdb_pdo->prepare(str_replace('{D}', $d, $tpl));
            $rows->execute([$selYear, $selMonth]);
            foreach ($rows->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $k = $r['musteri'].'§'.$r['stok_kodu'];
                if (!isset($satis[$k])) $satis[$k] = ['musteri'=>$r['musteri'],'stok_kodu'=>$r['stok_kodu'],'stok_adi'=>$r['stok_adi'],'satis'=>0];
                $satis[$k]['satis'] += floatval($r['miktar']);
            }
        }
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// 2) MySQL - Açık Siparişler
try {
    $st = $db->prepare("SELECT musteri_firma_adi musteri, sip_kodu stok_kodu, sip_baslik stok_adi,
        SUM(sip_miktar - sip_sevk_miktari) kalan
        FROM siparis
        WHERE sip_statu='Aktif'
          AND YEAR(sip_teslim_tarihi)=?
          AND MONTH(sip_teslim_tarihi)=?
          AND (sip_miktar - sip_sevk_miktari) > 0
        GROUP BY musteri_firma_adi, sip_kodu, sip_baslik");
    $st->execute([$selYear, $selMonth]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $k = $r['musteri'].'§'.$r['stok_kodu'];
        if (!isset($siparis[$k])) $siparis[$k] = ['musteri'=>$r['musteri'],'stok_kodu'=>$r['stok_kodu'],'stok_adi'=>$r['stok_adi'],'siparis'=>0];
        $siparis[$k]['siparis'] += floatval($r['kalan']);
        $sip_kayit++;
    }
} catch(Throwable $e) { $sip_hata = $e->getMessage(); }

// 3) Birleştir
$allKeys = array_unique(array_merge(array_keys($satis), array_keys($siparis)));
foreach ($allKeys as $k) {
    $s  = $satis[$k]   ?? null;
    $sp = $siparis[$k] ?? null;
    $sa = $s  ? $s['satis']   : 0;
    $si = $sp ? $sp['siparis'] : 0;
    $combined[$k] = [
        'musteri'   => $s['musteri']   ?? $sp['musteri'],
        'stok_kodu' => $s['stok_kodu'] ?? $sp['stok_kodu'],
        'stok_adi'  => $s['stok_adi']  ?? $sp['stok_adi'],
        'satis'     => $sa,
        'siparis'   => $si,
        'toplam'    => $sa + $si,
    ];
}
usort($combined, fn($a,$b) => strcmp($a['musteri'],$b['musteri']) ?: strcmp($a['stok_kodu'],$b['stok_kodu']));

$gtSatis = $gtSiparis = $gtToplam = 0;
foreach ($combined as $r) { $gtSatis+=$r['satis']; $gtSiparis+=$r['siparis']; $gtToplam+=$r['toplam']; }
?>
<style>
#tblSSD th { background:#1E3A5F !important; color:#fff !important; }
#tblSSD td, #tblSSD th { border:1px solid #000 !important; white-space:nowrap !important; }
#tblSSD .col-s  { background:#DBEAFE !important; }
#tblSSD .col-sp { background:#FEF9C3 !important; }
#tblSSD .col-t  { background:#DCFCE7 !important; }
#tblSSD .col-s.jit-row, #tblSSD .col-sp.jit-row, #tblSSD .col-t.jit-row { background:#ADD8E6 !important; }
table.dataTable#tblSSD tbody tr.jit-row td { background:#ADD8E6 !important; }
table.dataTable#tblSSD tbody tr.jit-row td.col-s  { background:#93C5FD !important; }
table.dataTable#tblSSD tbody tr.jit-row td.col-sp { background:#FDE047 !important; }
table.dataTable#tblSSD tbody tr.jit-row td.col-t  { background:#86EFAC !important; }
table.dataTable#tblSSD tbody tr td.col-s  { background:#DBEAFE !important; }
table.dataTable#tblSSD tbody tr td.col-sp { background:#FEF9C3 !important; }
table.dataTable#tblSSD tbody tr td.col-t  { background:#DCFCE7 !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">📊 Satış + Sipariş Durumu</h1>
    <div class="s-yol">Satış / <b>Firma Bazlı Satış &amp; Açık Sipariş Özeti</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Yıl</label>
      <select name="year" class="form-alan">
        <?php foreach($years as $y):?><option value="<?php echo $y;?>" <?php echo $y==$selYear?'selected':'';?>><?php echo $y;?></option><?php endforeach;?>
      </select>
    </div>
    <div>
      <label class="form-etiket">Ay</label>
      <select name="month" class="form-alan">
        <?php foreach($months as $n=>$ad):?><option value="<?php echo $n;?>" <?php echo $n==$selMonth?'selected':'';?>><?php echo $ad;?></option><?php endforeach;?>
      </select>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Getir</button>
  </form>
</div>

<!-- Bilgi Mesajları -->
<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px">❌ Tiger Hata: <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if($sip_hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-bottom:10px">❌ Sipariş Hata: <?php echo htmlspecialchars($sip_hata);?></div>
<?php elseif($sip_kayit===0):?>
<div style="background:#FFFBEB;color:#92400E;padding:10px 14px;border-radius:8px;margin-bottom:10px">ℹ️ <b><?php echo $baslik;?></b> döneminde teslim tarihi olan aktif sipariş bulunamadı.</div>
<?php else:?>
<div style="background:#F0FDF4;color:#166534;padding:10px 14px;border-radius:8px;margin-bottom:10px">✅ <?php echo $sip_kayit;?> sipariş kalemi yüklendi.</div>
<?php endif;?>

<!-- Özet Kartlar -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
  <div style="background:#DBEAFE;border:1px solid #93C5FD;border-radius:8px;padding:10px 18px">
    <div style="font-size:22px;font-weight:900;color:#1D4ED8"><?php echo number_format($gtSatis,0,'','.');?></div>
    <div style="font-size:11px;color:#1E40AF;font-weight:600">📦 Toplam Satış</div>
  </div>
  <div style="background:#FEF9C3;border:1px solid #FDE047;border-radius:8px;padding:10px 18px">
    <div style="font-size:22px;font-weight:900;color:#A16207"><?php echo number_format($gtSiparis,0,'','.');?></div>
    <div style="font-size:11px;color:#854D0E;font-weight:600">🕐 Toplam Açık Sipariş</div>
  </div>
  <div style="background:#DCFCE7;border:1px solid #86EFAC;border-radius:8px;padding:10px 18px">
    <div style="font-size:22px;font-weight:900;color:#15803D"><?php echo number_format($gtToplam,0,'','.');?></div>
    <div style="font-size:11px;color:#166534;font-weight:600">✅ Genel Toplam</div>
  </div>
  <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:10px 18px">
    <div style="font-size:22px;font-weight:900;color:#1E40AF"><?php echo count($combined);?></div>
    <div style="font-size:11px;color:#1D4ED8;font-weight:600">🔢 Kombinasyon</div>
  </div>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblSSD" style="width:100%;border-collapse:collapse">
  <thead>
    <tr>
      <th>Müşteri Adı</th>
      <th>Stok Kodu</th>
      <th>Stok Adı</th>
      <th class="col-s" style="text-align:center" title="Seçili ayda faturalanan miktar">📦 Satılan</th>
      <th class="col-sp" style="text-align:center" title="Henüz teslim edilmemiş açık sipariş">🕐 Açık Sipariş</th>
      <th class="col-t" style="text-align:center" title="Satılan + Açık Sipariş">✅ Toplam</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Müşteri Adı</th><th>Stok Kodu</th><th>Stok Adı</th>
      <th class="col-s">📦 Satılan</th>
      <th class="col-sp">🕐 Açık Sipariş</th>
      <th class="col-t">✅ Toplam</th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach($combined as $r):
    $jit = in_array($r['stok_kodu'], $jit_kodlar) ? 'jit-row' : '';
  ?>
  <tr class="<?php echo $jit;?>">
    <td style="font-weight:700"><?php echo htmlspecialchars($r['musteri']);?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['stok_kodu']);?></code></td>
    <td><?php echo htmlspecialchars($r['stok_adi']);?></td>
    <td class="col-s" style="text-align:right;font-weight:700"><?php echo $r['satis']>0 ? number_format($r['satis'],0,'','') : '<span style="color:#94A3B8">—</span>';?></td>
    <td class="col-sp" style="text-align:right;font-weight:700"><?php echo $r['siparis']>0 ? number_format($r['siparis'],0,'','') : '<span style="color:#94A3B8">—</span>';?></td>
    <td class="col-t" style="text-align:right;font-weight:700"><?php echo number_format($r['toplam'],0,'','');?></td>
  </tr>
  <?php endforeach;?>
  <?php if(empty($combined)):?>
  <tr><td colspan="6" style="text-align:center;padding:30px;color:#888">Seçilen dönem için veri bulunamadı.</td></tr>
  <?php endif;?>
  </tbody>
</table>
</div>
</div>

<script>
$(document).ready(function(){
  if(!$('#tblSSD tbody tr').length || $('#tblSSD tbody td[colspan]').length) return;
  $('#tblSSD').DataTable({
    initComplete: function(){
      this.api().columns([0,1,2]).every(function(){
        var col=this, th=$(col.footer());
        if(!th||!th.length) return;
        var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
          .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
        col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>29)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
      });
    },
    language:{ url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json' },
    scrollCollapse:true, scrollY:600, paging:false, scrollX:true,
    order:[[0,'asc']],
    dom:'Bfrtip',
    buttons:[
      {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Satis_Siparis_<?php echo $selYear."_".$selMonth;?>'},
      'print'
    ]
  });
});
</script>
