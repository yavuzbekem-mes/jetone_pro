<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

// ── AJAX ──────────────────────────────────────────────────────────────────────
if (!empty($_POST['tkl_action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['tkl_action'];
    $kul = Auth::kullanici();
    $kul_adi = trim(($kul['ad_soyad']??'') ?: ($kul['email']??'Kullanıcı'));

    // Tablo garantisi
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `teklifler` (
            `id`           INT AUTO_INCREMENT PRIMARY KEY,
            `teklif_no`    VARCHAR(30) NOT NULL,
            `durum`        ENUM('Taslak','Gönderildi','Onaylandı','Reddedildi','İptal') DEFAULT 'Taslak',
            `musteri_kodu` VARCHAR(50) DEFAULT NULL,
            `musteri_adi`  VARCHAR(300) DEFAULT NULL,
            `musteri_email`VARCHAR(300) DEFAULT NULL,
            `gecerlilik`   DATE DEFAULT NULL,
            `notlar`       TEXT DEFAULT NULL,
            `olusturan`    VARCHAR(200) DEFAULT NULL,
            `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_no` (`teklif_no`), INDEX `idx_durum` (`durum`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
        $db->exec("CREATE TABLE IF NOT EXISTS `teklif_kalemleri` (
            `id`          INT AUTO_INCREMENT PRIMARY KEY,
            `teklif_id`   INT NOT NULL,
            `stok_kodu`   VARCHAR(100) DEFAULT NULL,
            `stok_adi`    VARCHAR(300) DEFAULT NULL,
            `miktar`      DECIMAL(14,2) DEFAULT 0,
            `birim`       VARCHAR(20) DEFAULT 'Adet',
            `birim_fiyat` DECIMAL(14,4) DEFAULT 0,
            `iskonto`     DECIMAL(5,2) DEFAULT 0,
            `kdv`         DECIMAL(5,2) DEFAULT 18,
            `toplam`      DECIMAL(14,2) DEFAULT 0,
            `sira`        INT DEFAULT 0,
            INDEX `idx_teklif` (`teklif_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    } catch(Throwable $e){}

    // ── Yeni teklif numarası üret
    if ($action === 'yeni_no') {
        $yil = date('Y'); $ay = date('m');
        try {
            $son = $db->query("SELECT teklif_no FROM teklifler WHERE teklif_no LIKE 'TKL-$yil$ay-%' ORDER BY id DESC LIMIT 1")->fetchColumn();
            $sira = $son ? ((int)substr($son,-4)+1) : 1;
        } catch(Throwable $e){ $sira=1; }
        echo json_encode(['ok'=>true,'no'=>'TKL-'.$yil.$ay.'-'.str_pad($sira,4,'0',STR_PAD_LEFT)]);
        exit;
    }

    // ── Cari ara (Tiger)
    if ($action === 'cari_ara') {
        $q = trim($_POST['q']??'');
        if (!$tigerdb_pdo || strlen($q)<2) { echo json_encode(['ok'=>true,'liste',[]]); exit; }
        try {
            $stmt = $tigerdb_pdo->prepare("SELECT TOP 20 CL.CODE kod, CL.DEFINITION_ ad, ISNULL(CL.EMAILADDR,'') email FROM dbo.LG_222_CLCARD CL WHERE (CL.DEFINITION_ LIKE ? OR CL.CODE LIKE ?) AND CL.ACTIVE=0 ORDER BY CL.DEFINITION_ ASC");
            $stmt->execute(["%$q%","%$q%"]);
            echo json_encode(['ok'=>true,'liste'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Stok ara (Tiger)
    if ($action === 'stok_ara') {
        $q = trim($_POST['q']??'');
        if (!$tigerdb_pdo || strlen($q)<2) { echo json_encode(['ok'=>true,'liste'=>[]]); exit; }
        try {
            $stmt = $tigerdb_pdo->prepare("SELECT TOP 20 IT.CODE kod, IT.NAME ad, ISNULL(IT.UNITSETREF,0) birim FROM dbo.LG_222_ITEMS IT WHERE (IT.CODE LIKE ? OR IT.NAME LIKE ?) AND IT.ACTIVE=0 AND IT.CARDTYPE NOT IN(4,22) ORDER BY IT.CODE ASC");
            $stmt->execute(["%$q%","%$q%"]);
            echo json_encode(['ok'=>true,'liste'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Teklif kaydet
    if ($action === 'kaydet') {
        $data = json_decode($_POST['data']??'{}', true);
        if (!$data) { echo json_encode(['ok'=>false,'hata'=>'Veri yok']); exit; }
        try {
            $id = (int)($data['id']??0);
            if ($id) {
                $db->prepare("UPDATE teklifler SET musteri_kodu=?,musteri_adi=?,musteri_email=?,gecerlilik=?,notlar=?,durum=?,guncelleme=NOW() WHERE id=?")
                  ->execute([$data['musteri_kodu']??null,$data['musteri_adi']??null,$data['musteri_email']??null,
                    $data['gecerlilik']??null,$data['notlar']??null,$data['durum']??'Taslak',$id]);
            } else {
                $db->prepare("INSERT INTO teklifler(teklif_no,durum,musteri_kodu,musteri_adi,musteri_email,gecerlilik,notlar,olusturan) VALUES(?,?,?,?,?,?,?,?)")
                  ->execute([$data['teklif_no']??'TKL-YNI','Taslak',$data['musteri_kodu']??null,$data['musteri_adi']??null,
                    $data['musteri_email']??null,$data['gecerlilik']??null,$data['notlar']??null,$kul_adi]);
                $id = (int)$db->lastInsertId();
            }
            // Kalemleri sil ve yeniden ekle
            $db->prepare("DELETE FROM teklif_kalemleri WHERE teklif_id=?")->execute([$id]);
            $ins = $db->prepare("INSERT INTO teklif_kalemleri(teklif_id,stok_kodu,stok_adi,miktar,birim,birim_fiyat,iskonto,kdv,toplam,sira) VALUES(?,?,?,?,?,?,?,?,?,?)");
            foreach(($data['kalemler']??[]) as $i=>$k){
                $mik=(float)($k['miktar']??0); $fiy=(float)($k['birim_fiyat']??0);
                $isk=(float)($k['iskonto']??0); $kdv=(float)($k['kdv']??18);
                $top = $mik * $fiy * (1-$isk/100);
                $ins->execute([$id,$k['stok_kodu']??null,$k['stok_adi']??null,$mik,$k['birim']??'Adet',$fiy,$isk,$kdv,$top,$i+1]);
            }
            echo json_encode(['ok'=>true,'id'=>$id]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Teklif sil
    if ($action === 'sil') {
        $id=(int)($_POST['id']??0);
        try {
            $db->prepare("UPDATE teklifler SET durum='İptal' WHERE id=?")->execute([$id]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Durum güncelle
    if ($action === 'durum') {
        try {
            $db->prepare("UPDATE teklifler SET durum=? WHERE id=?")->execute([$_POST['durum']??'Taslak',(int)$_POST['id']]);
            echo json_encode(['ok'=>true]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Teklif detay getir
    if ($action === 'getir') {
        $id=(int)($_POST['id']??0);
        try {
            $t=$db->prepare("SELECT * FROM teklifler WHERE id=? LIMIT 1"); $t->execute([$id]); $t=$t->fetch(PDO::FETCH_ASSOC);
            $k=$db->prepare("SELECT * FROM teklif_kalemleri WHERE teklif_id=? ORDER BY sira ASC"); $k->execute([$id]); $k=$k->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['ok'=>true,'teklif'=>$t,'kalemler'=>$k]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    // ── Mail gönder
    if ($action === 'mail') {
        $id=(int)($_POST['id']??0);
        try {
            require_once dirname(dirname(__DIR__)).'/bolumler/idari/ajax/satin-smtp-send.php';
            $smtp=$db->query("SELECT host,port,kullanici,sifre,ek_parametreler FROM entegrasyonlar WHERE tip='smtp' AND aktif=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
            if (!$smtp) { echo json_encode(['ok'=>false,'hata'=>'SMTP entegrasyonu tanımlanmamış']); exit; }

            $t=$db->prepare("SELECT * FROM teklifler WHERE id=? LIMIT 1"); $t->execute([$id]); $t=$t->fetch(PDO::FETCH_ASSOC);
            $kalemler=$db->prepare("SELECT * FROM teklif_kalemleri WHERE teklif_id=? ORDER BY sira ASC"); $kalemler->execute([$id]); $kalemler=$kalemler->fetchAll(PDO::FETCH_ASSOC);

            // Ekstra alıcılar
            $alicilar = [];
            if ($t['musteri_email']) foreach(explode(',',$t['musteri_email']) as $e){ $e=trim($e); if(filter_var($e,FILTER_VALIDATE_EMAIL)) $alicilar[$e]=$t['musteri_adi']??''; }
            $ekstra = trim($_POST['ekstra_mail']??'');
            if($ekstra) foreach(explode(',',$ekstra) as $e){ $e=trim($e); if(filter_var($e,FILTER_VALIDATE_EMAIL)) $alicilar[$e]=''; }
            if(empty($alicilar)){ echo json_encode(['ok'=>false,'hata'=>'bos','mesaj'=>'Alıcı e-posta adresi girilmedi. Manuel adres ekleyin.']); exit; }

            // Toplam hesapla
            $genel_toplam=0; $kdv_toplam=0;
            foreach($kalemler as $k){ $genel_toplam+=$k['toplam']; $kdv_toplam+=$k['toplam']*($k['kdv']/100); }

            // HTML teklif
            $kalem_html='';
            foreach($kalemler as $i=>$k){
                $kalem_html.='<tr style="'.($i%2?'background:#F8FAFC':'').'">'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px">'.htmlspecialchars($k['stok_kodu']??'').'</td>'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px">'.htmlspecialchars($k['stok_adi']??'').'</td>'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:center">'.number_format($k['miktar'],0,',','.').' '.$k['birim'].'</td>'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:right">'.number_format($k['birim_fiyat'],2,',','.').'₺</td>'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:center">%'.$k['iskonto'].'</td>'
                    .'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:right;font-weight:700">'.number_format($k['toplam'],2,',','.').'₺</td>'
                    .'</tr>';
            }

            $firma_adi = $AYARLAR['firma_adi']??'Jetone';
            $tarih_str = date('d.m.Y');
            $html='<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="margin:0;padding:0;background:#F1F5F9;font-family:\'Segoe UI\',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#F1F5F9;padding:30px 0">
<tr><td>
<table width="620" cellpadding="0" cellspacing="0" align="center" style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.08)">
  <!-- Header -->
  <tr><td style="background:linear-gradient(135deg,#1E3A5F,#2d5986);padding:28px 32px">
    <table width="100%"><tr>
      <td><div style="font-size:22px;font-weight:900;color:#fff;letter-spacing:-0.5px">'.$firma_adi.'</div>
        <div style="color:rgba(255,255,255,.65);font-size:12px;margin-top:2px">Satış Teklifi</div></td>
      <td align="right">
        <div style="background:rgba(255,255,255,.15);border-radius:8px;padding:8px 14px;display:inline-block">
          <div style="color:#fff;font-size:11px;opacity:.75">Teklif No</div>
          <div style="color:#fff;font-size:16px;font-weight:800;letter-spacing:1px">'.htmlspecialchars($t['teklif_no']).'</div>
        </div>
      </td>
    </tr></table>
  </td></tr>
  <!-- Müşteri & Tarih -->
  <tr><td style="padding:24px 32px;border-bottom:1px solid #E2E8F0">
    <table width="100%"><tr>
      <td width="50%" style="vertical-align:top">
        <div style="font-size:10px;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">Sayın</div>
        <div style="font-size:15px;font-weight:700;color:#1E293B">'.htmlspecialchars($t['musteri_adi']??'').'</div>
        <div style="font-size:12px;color:#64748B;margin-top:2px">'.htmlspecialchars($t['musteri_email']??'').'</div>
      </td>
      <td width="50%" align="right" style="vertical-align:top">
        <div style="font-size:11px;color:#64748B">Tarih: <b>'.$tarih_str.'</b></div>
        '.($t['gecerlilik']?'<div style="font-size:11px;color:#64748B;margin-top:3px">Geçerlilik: <b>'.date('d.m.Y',strtotime($t['gecerlilik'])).'</b></div>':'').'
      </td>
    </tr></table>
  </td></tr>
  <!-- Kalemler -->
  <tr><td style="padding:24px 32px">
    <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
      <thead><tr style="background:#1E3A5F">
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:left;border:1px solid #2d5986">Stok Kodu</th>
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:left;border:1px solid #2d5986">Ürün Adı</th>
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:center;border:1px solid #2d5986">Miktar</th>
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:right;border:1px solid #2d5986">Birim Fiyat</th>
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:center;border:1px solid #2d5986">İskonto</th>
        <th style="padding:9px 10px;color:#fff;font-size:11px;font-weight:700;text-align:right;border:1px solid #2d5986">Toplam</th>
      </tr></thead>
      <tbody>'.$kalem_html.'</tbody>
    </table>
    <!-- Toplamlar -->
    <table align="right" cellpadding="0" cellspacing="0" style="margin-top:16px;min-width:260px">
      <tr><td style="padding:5px 10px;font-size:12px;color:#64748B">Ara Toplam</td>
          <td style="padding:5px 10px;font-size:12px;font-weight:600;text-align:right">'.number_format($genel_toplam,2,',','.').'₺</td></tr>
      <tr><td style="padding:5px 10px;font-size:12px;color:#64748B">KDV</td>
          <td style="padding:5px 10px;font-size:12px;font-weight:600;text-align:right">'.number_format($kdv_toplam,2,',','.').'₺</td></tr>
      <tr style="background:#1E3A5F"><td style="padding:9px 14px;font-size:13px;font-weight:700;color:#fff;border-radius:6px 0 0 6px">GENEL TOPLAM</td>
          <td style="padding:9px 14px;font-size:15px;font-weight:900;color:#fff;text-align:right;border-radius:0 6px 6px 0">'.number_format($genel_toplam+$kdv_toplam,2,',','.').'₺</td></tr>
    </table>
  </td></tr>
  '.($t['notlar']?'<tr><td style="padding:0 32px 24px"><div style="background:#F8FAFC;border-left:3px solid #2d5986;border-radius:0 6px 6px 0;padding:12px 16px;font-size:12px;color:#475569"><b>Not:</b> '.nl2br(htmlspecialchars($t['notlar'])).'</div></td></tr>':'').'
  <!-- Footer -->
  <tr><td style="background:#F8FAFC;padding:16px 32px;border-top:1px solid #E2E8F0">
    <div style="font-size:11px;color:#94A3B8;text-align:center">'.$firma_adi.' · Bu teklif '.htmlspecialchars($t['teklif_no']).' numarası ile düzenlenmiştir.</div>
  </td></tr>
</table></td></tr></table></body></html>';

            // SMTP şifre çöz
            $key = defined('SIFRELE_KEY') ? SIFRELE_KEY : 'jetone_key_2024';
            $sifre=''; $enc_raw=trim($smtp['sifre']??'');
            if($enc_raw){
                $d1=@openssl_decrypt($enc_raw,'AES-256-CBC',$key,0,'1234567890123456');
                $d2=@openssl_decrypt($enc_raw,'AES-256-CBC','jetone2024secretkey!!',0,'1234567890123456');
                if($d1&&ctype_print($d1))$sifre=$d1; elseif($d2&&ctype_print($d2))$sifre=$d2;
                else{$b=@base64_decode($enc_raw,true);$sifre=($b&&ctype_print($b))?$b:$enc_raw;}
            }
            $ekPar=json_decode($smtp['ek_parametreler']??'{}',true)?:[];
            $host=$smtp['host']?:'localhost'; $port=(int)($smtp['port']?:587);
            $user=$smtp['kullanici']??''; $enc2=$ekPar['smtp_secure']??($port==465?'ssl':'tls');
            $fromAd=$ekPar['smtp_from_name']??$firma_adi;

            $gonuldu=0;
            foreach($alicilar as $email=>$ad){
                $g=smtp_mail_gonder($host,$port,$user,$sifre,$enc2,$user,$fromAd,$email,$ad?$ad:$email,
                    'Teklif: '.htmlspecialchars($t['teklif_no']).' — '.$firma_adi,$html);
                if($g) $gonuldu++;
            }
            // Durumu güncelle
            $db->prepare("UPDATE teklifler SET durum='Gönderildi' WHERE id=?")->execute([$id]);
            echo json_encode(['ok'=>true,'sayi'=>$gonuldu]);
        } catch(Throwable $e){ echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
        exit;
    }

    echo json_encode(['ok'=>false,'hata'=>'Bilinmeyen action']); exit;
}

// ── SAYFA ────────────────────────────────────────────────────────────────────
// Tabloları oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `teklifler` (`id` INT AUTO_INCREMENT PRIMARY KEY,`teklif_no` VARCHAR(30) NOT NULL,`durum` ENUM('Taslak','Gönderildi','Onaylandı','Reddedildi','İptal') DEFAULT 'Taslak',`musteri_kodu` VARCHAR(50) DEFAULT NULL,`musteri_adi` VARCHAR(300) DEFAULT NULL,`musteri_email` VARCHAR(300) DEFAULT NULL,`gecerlilik` DATE DEFAULT NULL,`notlar` TEXT DEFAULT NULL,`olusturan` VARCHAR(200) DEFAULT NULL,`olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,`guncelleme` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS `teklif_kalemleri` (`id` INT AUTO_INCREMENT PRIMARY KEY,`teklif_id` INT NOT NULL,`stok_kodu` VARCHAR(100) DEFAULT NULL,`stok_adi` VARCHAR(300) DEFAULT NULL,`miktar` DECIMAL(14,2) DEFAULT 0,`birim` VARCHAR(20) DEFAULT 'Adet',`birim_fiyat` DECIMAL(14,4) DEFAULT 0,`iskonto` DECIMAL(5,2) DEFAULT 0,`kdv` DECIMAL(5,2) DEFAULT 18,`toplam` DECIMAL(14,2) DEFAULT 0,`sira` INT DEFAULT 0,INDEX `idx_teklif`(`teklif_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
    // Kolon eksikse ekle (eski tablo için)
    // Eksik kolonları ekle (her MySQL sürümüyle uyumlu - hata fırlatsa da devam et)
    foreach(['gecerlilik DATE DEFAULT NULL','musteri_email VARCHAR(300) DEFAULT NULL','musteri_kodu VARCHAR(50) DEFAULT NULL','notlar TEXT DEFAULT NULL'] as $_col)
        try { $db->exec("ALTER TABLE teklifler ADD COLUMN $_col"); } catch(Throwable $e2){}
} catch(Throwable $e){}

// Tiger'dan cari listesi
$tiger_cariler_tkl=[];
if ($tigerdb_pdo) { try {
    $tiger_cariler_tkl=$tigerdb_pdo->query("SELECT TOP 500 CL.CODE kod, CL.DEFINITION_ ad, ISNULL(CL.EMAILADDR,'') email FROM dbo.LG_222_CLCARD CL WITH(NOLOCK) WHERE CL.ACTIVE=0 AND CL.DEFINITION_ IS NOT NULL AND CL.DEFINITION_<>'' ORDER BY CL.DEFINITION_ ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){} }

// Tiger'dan stok listesi - sadece mamul (CARDTYPE=3) ve yarımamul (CARDTYPE=2)
$tiger_stoklar_tkl=[];
if ($tigerdb_pdo) { try {
    $tiger_stoklar_tkl=$tigerdb_pdo->query("SELECT TOP 2000 IT.CODE kod, IT.NAME ad FROM dbo.LG_222_ITEMS IT WITH(NOLOCK) WHERE IT.ACTIVE=0 AND IT.CARDTYPE IN(2,3) AND IT.NAME IS NOT NULL ORDER BY IT.CODE ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){} }

$teklifler=[];
try { $teklifler=$db->query("SELECT t.*,(SELECT COUNT(*) FROM teklif_kalemleri WHERE teklif_id=t.id) kalem_sayisi FROM teklifler t WHERE t.durum!='İptal' ORDER BY t.olusturma DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e){}

$durum_renk=['Taslak'=>['#FEF3C7','#92400E'],'Gönderildi'=>['#DBEAFE','#1E40AF'],'Onaylandı'=>['#D1FAE5','#065F46'],'Reddedildi'=>['#FEE2E2','#991B1B'],'İptal'=>['#F1F5F9','#64748B']];
?>
<style>
/* ── Teklifler ── */
.tkl-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:900;display:none;align-items:center;justify-content:center;padding:16px}
.tkl-modal-bg.ac{display:flex}
.tkl-modal{background:#fff;border-radius:16px;width:100%;max-width:860px;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 24px 80px rgba(0,0,0,.2)}
.tkl-modal-head{padding:16px 22px;border-bottom:1px solid #E2E8F0;display:flex;align-items:center;gap:12px;background:#1E3A5F;border-radius:16px 16px 0 0}
.tkl-modal-body{padding:22px;overflow-y:auto;flex:1}
.tkl-modal-foot{padding:14px 22px;border-top:1px solid #E2E8F0;display:flex;gap:8px;justify-content:flex-end;background:#F8FAFC}

/* Kalem tablosu */
.kalem-tbl{width:100%;border-collapse:collapse;font-size:12px}
.kalem-tbl th{background:#1E3A5F;color:#fff;padding:7px 10px;text-align:left;font-weight:600;white-space:nowrap}
.kalem-tbl td{padding:5px 7px;border-bottom:1px solid #F1F5F9;vertical-align:middle}
.kalem-tbl tr:hover td{background:#F8FAFC}
.kalem-input{border:1px solid #E2E8F0;border-radius:5px;padding:4px 7px;font-size:12px;font-family:inherit;width:100%;box-sizing:border-box}
.kalem-input:focus{outline:2px solid #2d5986;border-color:transparent}

/* Autocomplete */
.ac-wrap{position:relative}
.ac-liste{position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #E2E8F0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.12);z-index:1000;max-height:240px;overflow-y:auto;display:none}
.ac-item{padding:8px 12px;cursor:pointer;font-size:12px;border-bottom:1px solid #F1F5F9}
.ac-item:hover{background:#EFF6FF}
.ac-item b{color:#1E40AF}
.ac-item small{color:#94A3B8;display:block;font-size:10px}

/* Durum badge */
.dur-badge{padding:3px 8px;border-radius:5px;font-size:10px;font-weight:700;white-space:nowrap}

/* Preview irsaliye stili */
.prev-wrap{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;overflow:hidden}
.prev-head{background:linear-gradient(135deg,#1E3A5F,#2d5986);padding:20px 24px;color:#fff}

/* Teklif listesi satır */
.tkl-satir{display:grid;grid-template-columns:120px 1fr 180px 120px 80px 80px;align-items:center;gap:0;border-bottom:1px solid #F1F5F9;padding:10px 14px;transition:background .1s}
.tkl-satir:hover{background:#F8FAFC}
.tkl-satir-head{background:#F1F5F9;font-size:10px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.5px;border-radius:8px 8px 0 0}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">💼 Teklifler</h1>
    <div class="s-yol">Satış / <b>Teklif Yönetimi</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo count($teklifler);?> teklif</span>
    </div>
  </div>
  <button onclick="tklYeni()" style="background:linear-gradient(135deg,#1E3A5F,#2d5986);color:#fff;border:none;padding:8px 18px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">
    + Yeni Teklif
  </button>
</div>

<!-- Teklif Listesi -->
<div class="kart" style="overflow:hidden">
  <?php if(empty($teklifler)):?>
  <div style="padding:48px;text-align:center;color:var(--m2)">
    <div style="font-size:40px;margin-bottom:10px">📄</div>
    <div style="font-weight:700">Henüz teklif yok</div>
    <div style="font-size:12px;margin-top:4px">Yeni Teklif butonuna tıklayarak başlayın</div>
  </div>
  <?php else:?>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-teklifler">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th style="width:140px">Teklif No</th>
        <th>Müşteri</th>
        <th style="width:80px;text-align:center">Kalem</th>
        <th style="width:130px">Oluşturulma</th>
        <th style="width:110px">Geçerlilik</th>
        <th style="width:100px;text-align:center">Durum</th>
        <th style="width:130px;text-align:center">İşlemler</th>
      </tr>
    </thead>
    <tfoot><tr>
      <th>Teklif No</th><th>Müşteri</th><th>Kalem</th>
      <th>Oluşturulma</th><th>Geçerlilik</th><th>Durum</th><th></th>
    </tr></tfoot>
    <tbody>
    <?php foreach($teklifler as $t):
      $dr=$durum_renk[$t['durum']]??['#F1F5F9','#374151'];
    ?>
    <tr>
      <td><code style="background:var(--bg);padding:2px 7px;border-radius:4px;font-weight:800;color:#1E3A5F;font-size:12px;letter-spacing:.3px"><?php echo htmlspecialchars($t['teklif_no']);?></code></td>
      <td style="font-weight:600;color:var(--m)"><?php echo htmlspecialchars($t['musteri_adi']??'—');?></td>
      <td style="text-align:center"><span style="background:#EDE9FE;color:#5B21B6;font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px"><?php echo $t['kalem_sayisi'];?> kalem</span></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo $t['olusturma']?date('d.m.Y H:i',strtotime($t['olusturma'])):'—';?></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo !empty($t['gecerlilik'])?date('d.m.Y',strtotime($t['gecerlilik'])):'—';?></td>
      <td style="text-align:center"><span class="dur-badge" style="background:<?php echo $dr[0];?>;color:<?php echo $dr[1];?>"><?php echo $t['durum'];?></span></td>
      <td style="text-align:center;white-space:nowrap">
        <button onclick="tklDuzenle(<?php echo $t['id'];?>)" title="Düzenle"
          style="background:#EFF6FF;color:#1E40AF;border:1px solid #BFDBFE;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">✏ Düzenle</button>
        <button onclick="tklOnizle(<?php echo $t['id'];?>)" title="Önizle"
          style="background:#F0FDF4;color:#065F46;border:1px solid #BBF7D0;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">👁 Görüntüle</button>
        <button onclick="tklMailAc(<?php echo $t['id'];?>,'<?php echo htmlspecialchars(addslashes($t['musteri_email']??''));?>')" title="Mail Gönder"
          style="background:#DBEAFE;color:#1E40AF;border:1px solid #93C5FD;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">✉ Mail</button>
        <button onclick="tklSil(<?php echo $t['id'];?>,this)" title="Sil"
          style="background:#FEE2E2;color:#991B1B;border:1px solid #FCA5A5;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">🗑 Sil</button>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

<!-- ── FORM MODAL ── -->
<div class="tkl-modal-bg" id="tklModal">
<div class="tkl-modal">
  <div class="tkl-modal-head">
    <span style="font-size:18px">💼</span>
    <div>
      <div style="font-size:14px;font-weight:800;color:#fff" id="tklModalBaslik">Yeni Teklif</div>
      <div style="font-size:11px;color:rgba(255,255,255,.6)" id="tklModalNo">—</div>
    </div>
    <button onclick="tklKapat()" style="margin-left:auto;background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div class="tkl-modal-body">
    <input type="hidden" id="tklId">
    <input type="hidden" id="tklNo">

    <!-- Müşteri -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
      <div>
        <label class="form-etiket">Müşteri <span style="color:#EF4444">*</span></label>
        <?php if(!empty($tiger_cariler_tkl)):?>
        <select id="tklMusteriSelect" class="form-alan" onchange="cariSecDropdown(this)">
          <option value="">— Cari Seçin —</option>
          <?php foreach($tiger_cariler_tkl as $c_item):?>
          <option value="<?php echo htmlspecialchars($c_item['ad']);?>"
            data-kod="<?php echo htmlspecialchars($c_item['kod']);?>"
            data-email="<?php echo htmlspecialchars($c_item['email']);?>">
            <?php echo htmlspecialchars($c_item['ad']);?> — <?php echo htmlspecialchars($c_item['kod']);?>
          </option>
          <?php endforeach;?>
        </select>
        <?php else:?>
        <div style="font-size:10px;color:#F97316;margin-bottom:4px">⚠️ Tiger bağlantısı yok — manuel girin</div>
        <input type="text" id="tklMusteriSelect" class="form-alan" placeholder="Firma adı giriniz">
        <?php endif;?>
        <input type="hidden" id="tklMusteriKodu">
      </div>
      <div>
        <label class="form-etiket">E-posta (virgülle ayırın)</label>
        <input type="text" id="tklEmail" class="form-alan" placeholder="musteri@firma.com">
      </div>
      <div>
        <label class="form-etiket">Geçerlilik Tarihi</label>
        <input type="date" id="tklGecerlilik" class="form-alan">
      </div>
      <div>
        <label class="form-etiket">Durum</label>
        <select id="tklDurum" class="form-alan">
          <option value="Taslak">Taslak</option>
          <option value="Gönderildi">Gönderildi</option>
          <option value="Onaylandı">Onaylandı</option>
          <option value="Reddedildi">Reddedildi</option>
        </select>
      </div>
    </div>

    <!-- Kalemler -->
    <div style="font-weight:700;font-size:12px;color:var(--m);margin-bottom:8px">📦 Ürün Kalemleri</div>
    <table class="kalem-tbl" id="kalemTbl">
      <thead>
        <tr>
          <th style="width:200px">Stok Kodu / Adı</th>
          <th style="width:80px">Miktar</th>
          <th style="width:70px">Birim</th>
          <th style="width:100px">Birim Fiyat</th>
          <th style="width:70px">İskonto%</th>
          <th style="width:70px">KDV%</th>
          <th style="width:90px">Toplam</th>
          <th style="width:36px"></th>
        </tr>
      </thead>
      <tbody id="kalemBody"></tbody>
      <tfoot>
        <tr>
          <td colspan="9" style="padding:8px 0">
            <button onclick="kalemEkle()" style="background:#EFF6FF;color:#1E40AF;border:1px dashed #93C5FD;padding:5px 14px;border-radius:6px;font-size:12px;cursor:pointer;width:100%">+ Kalem Ekle</button>
          </td>
        </tr>
        <tr id="toplamSatir" style="display:none">
          <td colspan="6"></td>
          <td colspan="2" style="text-align:right;font-size:11px;color:var(--m2);padding:4px 7px">
            Ara Toplam: <b id="araToplam">0,00₺</b><br>
            KDV: <b id="kdvToplam">0,00₺</b>
          </td>
          <td></td>
        </tr>
        <tr id="genelToplam" style="display:none">
          <td colspan="6"></td>
          <td colspan="2" style="text-align:right;padding:6px 7px;background:#1E3A5F;border-radius:6px">
            <span style="font-size:11px;color:rgba(255,255,255,.7)">Genel Toplam</span><br>
            <span style="font-size:16px;font-weight:900;color:#fff" id="genelToplamVal">0,00₺</span>
          </td>
          <td></td>
        </tr>
      </tfoot>
    </table>

    <!-- Notlar -->
    <div style="margin-top:14px">
      <label class="form-etiket">Notlar / Özel Koşullar</label>
      <textarea id="tklNotlar" class="form-alan" rows="3" placeholder="Teklif şartları, teslimat bilgisi..."></textarea>
    </div>
  </div>
  <div class="tkl-modal-foot">
    <button onclick="tklKaydet('Taslak')" id="btnTaslak" style="background:var(--bg);border:1px solid var(--kenar);color:var(--m);padding:8px 18px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer">💾 Taslak Kaydet</button>
    <button onclick="tklKaydet('Gönderildi')" id="btnGonder" style="background:linear-gradient(135deg,#1E3A5F,#2d5986);color:#fff;border:none;padding:8px 22px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✉ Kaydet & Gönder</button>
  </div>
</div>
</div>

<!-- ── ÖNİZLEME MODAL ── -->
<div class="tkl-modal-bg" id="tklPrevModal">
<div class="tkl-modal" style="max-width:700px">
  <div class="tkl-modal-head">
    <span style="font-size:18px">👁</span>
    <div style="font-size:14px;font-weight:800;color:#fff">Teklif Önizleme</div>
    <button onclick="document.getElementById('tklPrevModal').classList.remove('ac')" style="margin-left:auto;background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div class="tkl-modal-body" id="tklPrevIcerik"></div>
</div>
</div>

<!-- ── MAIL MODAL ── -->
<div class="tkl-modal-bg" id="tklMailModal">
<div class="tkl-modal" style="max-width:440px">
  <div class="tkl-modal-head">
    <span style="font-size:18px">✉️</span>
    <div style="font-size:14px;font-weight:800;color:#fff">Teklif Gönder</div>
    <button onclick="document.getElementById('tklMailModal').classList.remove('ac')" style="margin-left:auto;background:rgba(255,255,255,.15);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">✕</button>
  </div>
  <div class="tkl-modal-body">
    <input type="hidden" id="mailTklId">
    <label class="form-etiket">Alıcı E-postalar</label>
    <textarea id="mailAlici" class="form-alan" rows="3" placeholder="musteri@firma.com, baska@mail.com"></textarea>
    <div style="font-size:11px;color:var(--m2);margin-top:4px">Virgülle ayırarak birden fazla alıcı ekleyebilirsiniz</div>
  </div>
  <div class="tkl-modal-foot">
    <button onclick="document.getElementById('tklMailModal').classList.remove('ac')" style="background:var(--bg);border:1px solid var(--kenar);color:var(--m);padding:8px 18px;border-radius:8px;font-size:12px;cursor:pointer">İptal</button>
    <button onclick="tklMailGonder()" id="btnMailGonder" style="background:#1E40AF;color:#fff;border:none;padding:8px 22px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer">✉ Gönder</button>
  </div>
</div>
</div>

<script>
var _cariTimer=null, _stokTimer=null, _aktifKalemIdx=-1;
var _STOKLAR = <?php echo json_encode(array_map(function($s){ return ['kod'=>$s['kod'],'ad'=>$s['ad']]; }, $tiger_stoklar_tkl), JSON_UNESCAPED_UNICODE); ?>;
var _firma_adi = '<?php echo htmlspecialchars(addslashes($AYARLAR['firma_adi']??'Jetone'));?>';

function tklPost(d,cb){
  var fd=new FormData();
  Object.entries(d).forEach(function(e){fd.append(e[0],typeof e[1]==='object'?JSON.stringify(e[1]):e[1]);});
  fetch(window.location.href.split('?')[0]+'?sayfa=satis-teklifler',{method:'POST',body:fd,credentials:'same-origin'})
  .then(function(r){return r.json();}).then(cb).catch(function(e){alert('Hata:'+e);});
}

// ── SİL ──
function tklSil(id,btn){
  if(!confirm('Bu teklifi silmek istediğinize emin misiniz?'))return;
  tklPost({tkl_action:'sil',id:id},function(d){
    if(d.ok) btn.closest('.tkl-satir').remove();
    else alert('Hata: '+(d.hata||''));
  });
}

// ── YENİ TEKLİF ──
function tklYeni(){
  tklPost({tkl_action:'yeni_no'},function(d){
    document.getElementById('tklId').value='';
    document.getElementById('tklNo').value=d.no||'TKL-YNI';
    document.getElementById('tklModalBaslik').textContent='Yeni Teklif';
    document.getElementById('tklModalNo').textContent=d.no||'';
    var selEl=document.getElementById('tklMusteriSelect');if(selEl&&selEl.tagName==='SELECT')selEl.selectedIndex=0;else if(selEl)selEl.value='';

    document.getElementById('tklMusteriKodu').value='';
    document.getElementById('tklEmail').value='';
    document.getElementById('tklGecerlilik').value='';
    document.getElementById('tklDurum').value='Taslak';
    document.getElementById('tklNotlar').value='';
    document.getElementById('kalemBody').innerHTML='';
    document.getElementById('toplamSatir').style.display='none';
    document.getElementById('genelToplam').style.display='none';
    document.getElementById('tklModal').classList.add('ac');
    kalemEkle();
  });
}

// ── DÜZENLE ──
function tklDuzenle(id){
  tklPost({tkl_action:'getir',id:id},function(d){
    if(!d.ok){alert(d.hata||'');return;}
    var t=d.teklif;
    document.getElementById('tklId').value=t.id;
    document.getElementById('tklNo').value=t.teklif_no;
    document.getElementById('tklModalBaslik').textContent='Teklif Düzenle';
    document.getElementById('tklModalNo').textContent=t.teklif_no;
    var selEl2=document.getElementById('tklMusteriSelect');
    if(selEl2&&selEl2.tagName==='SELECT'){
      for(var oi=0;oi<selEl2.options.length;oi++){if(selEl2.options[oi].value===(t.musteri_adi||'')){selEl2.selectedIndex=oi;break;}}
    } else if(selEl2){ selEl2.value=t.musteri_adi||''; }

    document.getElementById('tklMusteriKodu').value=t.musteri_kodu||'';
    document.getElementById('tklEmail').value=t.musteri_email||'';
    document.getElementById('tklGecerlilik').value=t.gecerlilik||'';
    document.getElementById('tklDurum').value=t.durum||'Taslak';
    document.getElementById('tklNotlar').value=t.notlar||'';
    document.getElementById('kalemBody').innerHTML='';
    (d.kalemler||[]).forEach(function(k){ kalemEkle(k); });
    if(!d.kalemler||!d.kalemler.length) kalemEkle();
    toplamHesapla();
    document.getElementById('tklModal').classList.add('ac');
  });
}

// ── KAYDET ──
function tklKaydet(durum){
  var _mSel=document.getElementById('tklMusteriSelect');
  var musteriAdi=(_mSel&&_mSel.tagName==='SELECT'?(_mSel.options[_mSel.selectedIndex]?_mSel.options[_mSel.selectedIndex].value:''):(_mSel?_mSel.value:'')).trim();
  document.getElementById('tklMusteriKodu').value=(_mSel&&_mSel.tagName==='SELECT'&&_mSel.options[_mSel.selectedIndex])?(_mSel.options[_mSel.selectedIndex].dataset.kod||''):document.getElementById('tklMusteriKodu').value;
  if(!musteriAdi){alert('Müşteri seçiniz.');return;}
  var kalemler=[];
  document.querySelectorAll('#kalemBody tr').forEach(function(tr){
    // Stok select varsa ondan al, yoksa hidden inputtan
    var secEl=tr.querySelector('.k-stok-sec');
    var kod='', adi='';
    if(secEl&&secEl.value){
      var opt=secEl.options[secEl.selectedIndex];
      kod=secEl.value; adi=opt?opt.dataset.ad||'':'';
    } else {
      var kodEl=tr.querySelector('.k-kod'); var adiEl=tr.querySelector('.k-adi');
      kod=kodEl?kodEl.value.trim():''; adi=adiEl?adiEl.value.trim():'';
    }
    if(!kod&&!adi) return;
    kalemler.push({
      stok_kodu:kod, stok_adi:adi,
      miktar:tr.querySelector('.k-mik').value||1,
      birim:tr.querySelector('.k-bir').value||'Adet',
      birim_fiyat:tr.querySelector('.k-fiy').value||0,
      iskonto:tr.querySelector('.k-isk').value||0,
      kdv:tr.querySelector('.k-kdv').value||18,
    });
  });
  var data={
    id:document.getElementById('tklId').value||0,
    teklif_no:document.getElementById('tklNo').value,
    durum:durum,
    musteri_kodu:document.getElementById('tklMusteriKodu').value,
    musteri_adi:musteriAdi,
    musteri_email:document.getElementById('tklEmail').value,
    gecerlilik:document.getElementById('tklGecerlilik').value,
    notlar:document.getElementById('tklNotlar').value,
    kalemler:kalemler
  };
  var btn=document.getElementById(durum==='Taslak'?'btnTaslak':'btnGonder');
  btn.disabled=true;
  tklPost({tkl_action:'kaydet',data:data},function(d){
    btn.disabled=false;
    if(!d.ok){alert('Hata: '+(d.hata||''));return;}
    if(durum==='Gönderildi'){
      tklMailAc(d.id, document.getElementById('tklEmail').value);
    }
    tklKapat();
    location.reload();
  });
}

function tklKapat(){document.getElementById('tklModal').classList.remove('ac');}

// ── ÖNİZLE ──
function tklOnizle(id){
  tklPost({tkl_action:'getir',id:id},function(d){
    if(!d.ok){alert(d.hata||'');return;}
    var t=d.teklif, ks=d.kalemler||[];
    var genel=0,kdvT=0;
    var kalemHtml='';
    ks.forEach(function(k,i){
      genel+=parseFloat(k.toplam||0);
      kdvT+=parseFloat(k.toplam||0)*(parseFloat(k.kdv||0)/100);
      kalemHtml+='<tr style="'+(i%2?'background:#F8FAFC':'')+'">'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px">'+_esc(k.stok_kodu||'')+'</td>'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px">'+_esc(k.stok_adi||'')+'</td>'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:center">'+_fmt(k.miktar)+' '+k.birim+'</td>'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:right">'+_fmtF(k.birim_fiyat)+'₺</td>'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:center">%'+k.iskonto+'</td>'
        +'<td style="padding:7px 10px;border:1px solid #E2E8F0;font-size:12px;text-align:right;font-weight:700">'+_fmtF(k.toplam)+'₺</td>'
        +'</tr>';
    });
    var html='<div class="prev-wrap">'
      +'<div class="prev-head"><div style="display:flex;justify-content:space-between;align-items:center">'
      +'<div><div style="font-size:20px;font-weight:900;letter-spacing:-0.5px">'+_esc(_firma_adi)+'</div>'
      +'<div style="opacity:.65;font-size:11px;margin-top:2px">Satış Teklifi</div></div>'
      +'<div style="background:rgba(255,255,255,.15);border-radius:8px;padding:8px 14px;text-align:right">'
      +'<div style="font-size:10px;opacity:.7">Teklif No</div>'
      +'<div style="font-size:15px;font-weight:800;letter-spacing:1px">'+_esc(t.teklif_no)+'</div></div></div></div>'
      +'<div style="padding:18px 22px;border-bottom:1px solid #E2E8F0;display:flex;justify-content:space-between">'
      +'<div><div style="font-size:10px;font-weight:700;color:#94A3B8;text-transform:uppercase;margin-bottom:4px">Sayın</div>'
      +'<div style="font-size:14px;font-weight:700">'+_esc(t.musteri_adi||'—')+'</div>'
      +'<div style="font-size:11px;color:#64748B">'+_esc(t.musteri_email||'')+'</div></div>'
      +'<div style="text-align:right;font-size:11px;color:#64748B">'
      +(t.gecerlilik?'<div>Geçerlilik: <b>'+_tarih(t.gecerlilik)+'</b></div>':'')+'</div></div>'
      +'<div style="padding:18px 22px">'
      +'<table style="width:100%;border-collapse:collapse"><thead><tr style="background:#1E3A5F">'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:left">Stok Kodu</th>'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:left">Ürün Adı</th>'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:center">Miktar</th>'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:right">Birim Fiyat</th>'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:center">İskonto</th>'
      +'<th style="padding:8px 10px;color:#fff;font-size:11px;border:1px solid #2d5986;text-align:right">Toplam</th>'
      +'</tr></thead><tbody>'+kalemHtml+'</tbody></table>'
      +'<div style="display:flex;justify-content:flex-end;margin-top:14px">'
      +'<table style="min-width:240px"><tr><td style="padding:4px 10px;font-size:12px;color:#64748B">Ara Toplam</td><td style="padding:4px 10px;font-size:12px;font-weight:600;text-align:right">'+_fmtF(genel)+'₺</td></tr>'
      +'<tr><td style="padding:4px 10px;font-size:12px;color:#64748B">KDV</td><td style="padding:4px 10px;font-size:12px;font-weight:600;text-align:right">'+_fmtF(kdvT)+'₺</td></tr>'
      +'<tr style="background:#1E3A5F"><td style="padding:8px 14px;color:#fff;font-weight:700;border-radius:6px 0 0 6px">Genel Toplam</td>'
      +'<td style="padding:8px 14px;color:#fff;font-size:15px;font-weight:900;text-align:right;border-radius:0 6px 6px 0">'+_fmtF(genel+kdvT)+'₺</td></tr>'
      +'</table></div>'
      +(t.notlar?'<div style="margin-top:14px;background:#F8FAFC;border-left:3px solid #2d5986;padding:10px 14px;font-size:12px;color:#475569;border-radius:0 6px 6px 0"><b>Not:</b> '+_esc(t.notlar)+'</div>':'')
      +'</div></div>';
    document.getElementById('tklPrevIcerik').innerHTML=html;
    document.getElementById('tklPrevModal').classList.add('ac');
  });
}

// ── MAIL AÇ ──
function tklMailAc(id, email){
  document.getElementById('mailTklId').value=id;
  document.getElementById('mailAlici').value=email||'';
  document.getElementById('tklMailModal').classList.add('ac');
}

// ── MAIL GÖNDER ──
function tklMailGonder(){
  var id=document.getElementById('mailTklId').value;
  var alici=document.getElementById('mailAlici').value.trim();
  var btn=document.getElementById('btnMailGonder');
  btn.disabled=true; btn.textContent='⏳ Gönderiliyor...';
  tklPost({tkl_action:'mail',id:id,ekstra_mail:alici},function(d){
    btn.disabled=false; btn.textContent='✉ Gönder';
    if(d.ok){alert('✅ '+d.sayi+' alıcıya gönderildi.');document.getElementById('tklMailModal').classList.remove('ac');location.reload();}
    else if(d.hata==='bos'){alert(d.mesaj||'Alıcı adresi giriniz.');}
    else alert('Hata: '+(d.hata||''));
  });
}

// ── CARİ ARAMA ──
function cariAra(q){
  clearTimeout(_cariTimer);
  if(q.length<2){document.getElementById('cariListe').style.display='none';return;}
  _cariTimer=setTimeout(function(){
    tklPost({tkl_action:'cari_ara',q:q},function(d){
      var liste=document.getElementById('cariListe');
      if(!d.ok||!d.liste||!d.liste.length){liste.style.display='none';return;}
      liste.innerHTML=d.liste.map(function(c){
        return '<div class="ac-item" onclick="cariSec(\''+_esc(c.kod)+'\',\''+_esc(c.ad)+'\',\''+_esc(c.email)+'\')">'
          +'<b>'+_esc(c.ad)+'</b><small>'+_esc(c.kod)+(c.email?' · '+c.email:'')+'</small></div>';
      }).join('');
      liste.style.display='block';
    });
  },300);
}
function cariSec(kod,ad,email){
  document.getElementById('tklMusteriKodu').value=kod;
  if(email&&!document.getElementById('tklEmail').value) document.getElementById('tklEmail').value=email;
  document.getElementById('cariListe').style.display='none';
}
document.addEventListener('click',function(e){
  if(!e.target.closest('.ac-wrap')) document.getElementById('cariListe').style.display='none';
});

// ── KALEM ──
var _kalemIdx=0;
function kalemEkle(veri){
  var idx=_kalemIdx++;
  var tr=document.createElement('tr');
  tr.dataset.idx=idx;
  var kod=veri?veri.stok_kodu||'':'';
  var adi=veri?veri.stok_adi||'':'';
  var mik=veri?veri.miktar||1:1;
  var bir=veri?veri.birim||'Adet':'Adet';
  var fiy=veri?veri.birim_fiyat||0:0;
  var isk=veri?veri.iskonto||0:0;
  var kdv=veri?veri.kdv||18:18;
  var stokOpts='<option value="">— Stok Seçin —</option>'
    +_STOKLAR.map(function(s){return'<option value="'+_esc(s.kod)+'" data-ad="'+_esc(s.ad)+'" '+(s.kod===kod?'selected':'')+'>'+_esc(s.kod)+' — '+_esc(s.ad.substring(0,40))+'</option>';}).join('');
  tr.innerHTML=''
    +'<td style="padding:4px 6px">'
    +(_STOKLAR.length
      ?'<input class="kalem-input k-stok-ara" placeholder="🔍 Stok ara..." oninput="stokFiltrele(this)" style="width:100%;margin-bottom:2px;font-size:11px">'
       +'<select class="kalem-input k-stok-sec" style="width:100%;font-size:11px" onchange="stokSec(this)" size="3">'+stokOpts+'</select>'
      :'<input class="kalem-input k-kod" value="'+_esc(kod)+'" placeholder="Stok kodu" style="width:100%;margin-bottom:2px">'
        +'<input class="kalem-input k-adi" value="'+_esc(adi)+'" placeholder="Ürün adı" style="width:100%">'
    )
    +'</td>'
    +'<td><input class="kalem-input k-mik" type="number" value="'+mik+'" min="0" oninput="toplamHesapla()" style="text-align:right"></td>'
    +'<td><input class="kalem-input k-bir" value="'+_esc(bir)+'" style="text-align:center"></td>'
    +'<td><input class="kalem-input k-fiy" type="number" value="'+fiy+'" min="0" step="0.01" oninput="toplamHesapla()" style="text-align:right"></td>'
    +'<td><input class="kalem-input k-isk" type="number" value="'+isk+'" min="0" max="100" oninput="toplamHesapla()" style="text-align:center"></td>'
    +'<td><input class="kalem-input k-kdv" type="number" value="'+kdv+'" min="0" oninput="toplamHesapla()" style="text-align:center"></td>'
    +'<td><span class="k-top" style="font-size:12px;font-weight:700;color:#1E3A5F;display:block;text-align:right;padding:0 7px">—</span></td>'
    +'<td><button onclick="this.closest(\'tr\').remove();toplamHesapla()" style="background:#FEE2E2;color:#991B1B;border:none;width:28px;height:28px;border-radius:5px;cursor:pointer;font-size:14px">×</button></td>';
  document.getElementById('kalemBody').appendChild(tr);
  toplamHesapla();
}

function stokAra(input,idx){
  clearTimeout(_stokTimer);
  var q=input.value.trim();
  _aktifKalemIdx=idx;
  if(q.length<2){document.getElementById('stokListe'+idx).style.display='none';return;}
  _stokTimer=setTimeout(function(){
    tklPost({tkl_action:'stok_ara',q:q},function(d){
      var liste=document.getElementById('stokListe'+idx);
      if(!d.ok||!d.liste||!d.liste.length){liste.style.display='none';return;}
      liste.innerHTML=d.liste.map(function(s){
        return '<div class="ac-item" onclick="stokSec('+idx+',\''+_esc(s.kod)+'\',\''+_esc(s.ad)+'\')">'
          +'<b>'+_esc(s.kod)+'</b><small>'+_esc(s.ad)+'</small></div>';
      }).join('');
      liste.style.display='block';
    });
  },250);
}
function stokSec(idx,kod,ad){
  var tr=document.querySelector('#kalemBody tr[data-idx="'+idx+'"]');
  if(!tr) return;
  tr.querySelector('.k-kod').value=kod;
  tr.querySelector('.k-adi').value=ad;
  var l=document.getElementById('stokListe'+idx);
  if(l) l.style.display='none';
}
document.addEventListener('click',function(e){
  if(!e.target.closest('.ac-wrap')) document.querySelectorAll('.ac-liste').forEach(function(l){l.style.display='none';});
});

function toplamHesapla(){
  var ara=0,kdvT=0;
  document.querySelectorAll('#kalemBody tr').forEach(function(tr){
    var mik=parseFloat(tr.querySelector('.k-mik').value||0);
    var fiy=parseFloat(tr.querySelector('.k-fiy').value||0);
    var isk=parseFloat(tr.querySelector('.k-isk').value||0);
    var kdv=parseFloat(tr.querySelector('.k-kdv').value||18);
    var top=mik*fiy*(1-isk/100);
    ara+=top; kdvT+=top*(kdv/100);
    tr.querySelector('.k-top').textContent=_fmtF(top)+'₺';
  });
  var kalemSay=document.querySelectorAll('#kalemBody tr').length;
  document.getElementById('toplamSatir').style.display=kalemSay?'':'none';
  document.getElementById('genelToplam').style.display=kalemSay?'':'none';
  document.getElementById('araToplam').textContent=_fmtF(ara)+'₺';
  document.getElementById('kdvToplam').textContent=_fmtF(kdvT)+'₺';
  document.getElementById('genelToplamVal').textContent=_fmtF(ara+kdvT)+'₺';
}

// Yardımcılar
function _esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function _fmt(n){return parseFloat(n||0).toLocaleString('tr-TR',{maximumFractionDigits:0});}
function _fmtF(n){return parseFloat(n||0).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2});}
function _tarih(s){if(!s)return'';var p=s.split('-');return p[2]+'.'+p[1]+'.'+p[0];}
</script>
