<?php
/**
 * JETONE.PRO — Sayım Listesi (MES)
 * panel.php: 'depo-sayim-listesi' => 'bolumler/depo/sayim_listesi.php'
 */
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$kul     = Auth::kullanici();
$kul_mail = $kul['email'] ?? '';
$mes_ok  = ($mes_pdo !== null);

// Yetki kontrolü (işlem butonları için)
$yetkili_kullanicilar = ['planlama@poliza.com.tr','yavuzbekem@gmail.com'];
$yetkili = in_array($kul_mail, $yetkili_kullanicilar);

$mesaj = '';
$mesaj_tip = '';

// POST işlemleri
if ($mes_ok && isset($_POST['operation']) && !empty($_POST['sayim_adi_islem'])) {
    $sayim_adi = $_POST['sayim_adi_islem'];
    $ambar_no  = (int)($_POST['ambar_no'] ?? 2);
    try {
        switch ($_POST['operation']) {
            case 'pasif_yap':
                $stmt = $mes_pdo->prepare("UPDATE P SET P.AKTIF = 1
                    FROM MES.dbo.PAKETLER P
                    WHERE P.STOK_KODU IN (SELECT STOK_KODU FROM dbo.SAYIM_TABLOSU WHERE SAYIM_ADI=:s)
                    AND P.AMBAR IN (SELECT DISTINCT AMBAR_NO FROM dbo.SAYIM_TABLOSU WHERE SAYIM_ADI=:s2 AND AMBAR_NO IS NOT NULL)");
                $stmt->execute(['s'=>$sayim_adi,'s2'=>$sayim_adi]);
                $mesaj = "Pasif yapılan paket sayısı: ".$stmt->rowCount(); $mesaj_tip='ok'; break;

            case 'aktif_yap':
                $stmt = $mes_pdo->prepare("UPDATE P SET P.AKTIF = 0
                    FROM MES.dbo.PAKETLER P
                    WHERE P.PAKET_NO IN (SELECT PAKET_NO FROM dbo.SAYIM_TABLOSU WHERE SAYIM_ADI=:s AND PAKET_NO IS NOT NULL)");
                $stmt->execute(['s'=>$sayim_adi]);
                $mesaj = "Aktif yapılan paket sayısı: ".$stmt->rowCount(); $mesaj_tip='ok'; break;

            case 'ambar_guncelle':
                $stmt = $mes_pdo->prepare("UPDATE P SET P.AMBAR=:a
                    FROM MES.dbo.PAKETLER P
                    WHERE P.PAKET_NO IN (SELECT PAKET_NO FROM dbo.SAYIM_TABLOSU WHERE SAYIM_ADI=:s AND PAKET_NO IS NOT NULL)");
                $stmt->execute(['s'=>$sayim_adi,'a'=>$ambar_no]);
                $mesaj = "Paketlerde ambar güncellenen: ".$stmt->rowCount(); $mesaj_tip='ok'; break;

            case 'sayim_ambar_guncelle':
                $stmt = $mes_pdo->prepare("UPDATE S SET S.AMBAR_NO=:a FROM dbo.SAYIM_TABLOSU S WHERE S.SAYIM_ADI=:s AND S.PAKET_NO IS NOT NULL");
                $stmt->execute(['s'=>$sayim_adi,'a'=>$ambar_no]);
                $mesaj = "Sayım tablosunda ambar güncellenen: ".$stmt->rowCount(); $mesaj_tip='ok'; break;

            case 'stok_yeri_guncelle':
                $stmt = $mes_pdo->prepare("UPDATE P SET P.STOK_YERI=S.STOK_YERI
                    FROM MES.dbo.PAKETLER P
                    INNER JOIN dbo.SAYIM_TABLOSU S ON P.PAKET_NO=S.PAKET_NO
                    WHERE S.SAYIM_ADI=:s AND S.PAKET_NO IS NOT NULL AND S.STOK_YERI IS NOT NULL");
                $stmt->execute(['s'=>$sayim_adi]);
                $mesaj = "Stok yeri güncellenen: ".$stmt->rowCount(); $mesaj_tip='ok'; break;
        }
    } catch (Throwable $e) {
        $mesaj = "Hata: ".$e->getMessage(); $mesaj_tip='hata';
    }
}

// Sayım listesi
$sayimlar = [];
if ($mes_ok) {
    try {
        $sayimlar = $mes_pdo->query("SELECT TOP 1000 ID,SAYIM_ADI,SAYIM_TARIHI,AKTIF FROM dbo.SAYIMLAR ORDER BY ID DESC")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e){}
}

$selected = $_POST['sayim_adi'] ?? $_GET['sayim_adi'] ?? '';
$tablo_verileri = [];
$sayim_yuzde_bilgileri = [];
$debug = [];

if ($mes_ok && $selected) {
    try {
        // Detay kayıtlar
        $stmt = $mes_pdo->prepare("SELECT ID,PAKET_NO,STOK_KODU,STOK_ADI,
            CONVERT(decimal(18,2),REPLACE(MIKTAR,',','.')) AS MIKTAR,
            BIRIM,LOT_NO,STOK_YERI,EKLENME_TARIHI,AMBAR_NO,EKLEYEN,SAYIM_ADI,
            (SELECT STGRPCODE FROM TIGERDB.dbo.LG_222_ITEMS WHERE CODE=dbo.SAYIM_TABLOSU.STOK_KODU) AS GRUP_KODU,
            (SELECT TRACKTYPE FROM TIGERDB.dbo.LG_222_ITEMS WHERE CODE=dbo.SAYIM_TABLOSU.STOK_KODU) AS TAKIP
            FROM dbo.SAYIM_TABLOSU WHERE SAYIM_ADI=:s");
        $stmt->execute(['s'=>$selected]);
        $tablo_verileri = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Tiger stoklar
        $tiger_stoklar = $tigerdb_pdo->query("SELECT IT.CODE AS KOD, IT.NAME AS AD, IT.STGRPCODE AS GRUP,
            SUM(CASE WHEN LV.INVENNO=0 THEN ISNULL(LV.ONHAND,0) ELSE 0 END) AS MERKEZ,
            SUM(CASE WHEN LV.INVENNO=1 THEN ISNULL(LV.ONHAND,0) ELSE 0 END) AS URETIM
            FROM dbo.LG_222_ITEMS IT
            LEFT OUTER JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF AND LV.INVENNO IN(0,1)
            WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 AND IT.CODE IS NOT NULL AND IT.CODE!=''
            GROUP BY IT.CODE,IT.NAME,IT.STGRPCODE")->fetchAll(PDO::FETCH_ASSOC);

        $debug['tiger_kod'] = count($tiger_stoklar);
        $debug['merkez'] = array_sum(array_column($tiger_stoklar,'MERKEZ'));
        $debug['uretim'] = array_sum(array_column($tiger_stoklar,'URETIM'));

        // Sayım miktarları
        $stmt2 = $mes_pdo->prepare("SELECT S.STOK_KODU,S.STOK_ADI,
            SUM(CONVERT(decimal(18,2),REPLACE(S.MIKTAR,',','.'))) AS TOPLAM,
            (SELECT IT.STGRPCODE FROM TIGERDB.dbo.LG_222_ITEMS IT WHERE IT.CODE=S.STOK_KODU) AS GRUP,
            (SELECT IT.NAME FROM TIGERDB.dbo.LG_222_ITEMS IT WHERE IT.CODE=S.STOK_KODU) AS TIGER_AD
            FROM dbo.SAYIM_TABLOSU S WHERE S.SAYIM_ADI=:s GROUP BY S.STOK_KODU,S.STOK_ADI");
        $stmt2->execute(['s'=>$selected]);
        $sayim_map = [];
        foreach ($stmt2->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $sayim_map[$r['STOK_KODU']] = ['toplam'=>(float)$r['TOPLAM'],'ad'=>$r['STOK_ADI'],'tiger_ad'=>$r['TIGER_AD'],'grup'=>$r['GRUP']];
        }

        // Yüzde hesapla
        foreach ($tiger_stoklar as $st) {
            $kod   = $st['KOD'];
            $mer   = (float)$st['MERKEZ'];
            $ure   = (float)$st['URETIM'];
            $top   = $mer + $ure;
            $say   = isset($sayim_map[$kod]) ? $sayim_map[$kod]['toplam'] : 0;
            $yuzde = $top > 0 ? round($say*100/$top, 2) : 0;
            $sayim_yuzde_bilgileri[] = ['kod'=>$kod,'ad'=>$st['AD'],'grup'=>$st['GRUP'],'merkez'=>$mer,'uretim'=>$ure,'toplam'=>$top,'sayim'=>$say,'yuzde'=>$yuzde];
            unset($sayim_map[$kod]);
        }
        foreach ($sayim_map as $kod => $v) {
            $sayim_yuzde_bilgileri[] = ['kod'=>$kod,'ad'=>$v['tiger_ad']?:$v['ad'],'grup'=>$v['grup']?:'—','merkez'=>0,'uretim'=>0,'toplam'=>0,'sayim'=>$v['toplam'],'yuzde'=>0];
        }

        usort($sayim_yuzde_bilgileri, function($a,$b){
            $as = $a['toplam']==0?4:($a['yuzde']>=100?1:($a['yuzde']>0?2:3));
            $bs = $b['toplam']==0?4:($b['yuzde']>=100?1:($b['yuzde']>0?2:3));
            if ($as!=$bs) return $as<=>$bs;
            return $b['yuzde']<=>$a['yuzde'];
        });

    } catch(Throwable $e){ $mesaj="Sorgu hatası: ".$e->getMessage(); $mesaj_tip='hata'; }
}

// Özet
$ts = $sayim_yuzde_bilgileri;
$s_tam   = count(array_filter($ts,fn($r)=>$r['yuzde']>=100));
$s_kismi = count(array_filter($ts,fn($r)=>$r['yuzde']>0&&$r['yuzde']<100));
$s_hic   = count(array_filter($ts,fn($r)=>$r['yuzde']==0&&$r['toplam']>0));
$s_yok   = count(array_filter($ts,fn($r)=>$r['toplam']==0&&$r['sayim']>0));
$t_depo  = array_sum(array_column($ts,'toplam'));
$t_sayim = array_sum(array_column($ts,'sayim'));
$g_yuzde = $t_depo>0?round($t_sayim*100/$t_depo,2):0;
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📋 Sayım Listesi</h1>
    <div class="s-yol">Depo / <b>Sayım Listesi</b>
      <?php if($mes_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● MES DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if (!$mes_ok): ?>
<div class="kart" style="padding:16px;background:#FEF2F2;color:#7F1D1D">MES veritabanı bağlantısı kurulamadı.</div>
<?php else: ?>

<!-- Sayım seçimi -->
<div class="kart" style="padding:14px;margin-bottom:14px">
  <form method="POST" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
    <label class="form-et" style="margin:0;white-space:nowrap">Sayım Seçin:</label>
    <select name="sayim_adi" class="form-alan" style="min-width:260px;font-size:13px" onchange="this.form.submit()">
      <option value="">— Sayım seçin —</option>
      <?php foreach ($sayimlar as $s): ?>
      <option value="<?= htmlspecialchars($s['SAYIM_ADI']) ?>" <?= $s['SAYIM_ADI']===$selected?'selected':'' ?>>
        <?= htmlspecialchars($s['SAYIM_ADI']) ?>
        <?= $s['AKTIF']?'':'(Pasif)' ?>
      </option>
      <?php endforeach; ?>
    </select>
    <?php if ($selected): ?>
    <span style="font-size:12px;color:var(--m2)"><?= count($tablo_verileri) ?> kayıt</span>
    <?php endif; ?>
  </form>
</div>

<?php if ($mesaj): ?>
<div class="kart" style="padding:12px 16px;margin-bottom:12px;
     background:<?= $mesaj_tip==='ok'?'#D1FAE5':'#FEF2F2' ?>;
     color:<?= $mesaj_tip==='ok'?'#065F46':'#7F1D1D' ?>;
     border-left:4px solid <?= $mesaj_tip==='ok'?'#22C55E':'#EF4444' ?>">
  <?= htmlspecialchars($mesaj) ?>
</div>
<?php endif; ?>

<?php if ($selected && !empty($sayim_yuzde_bilgileri)): ?>

<!-- Debug -->
<div style="background:#EFF6FF;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#1D4ED8">
  <strong>Tiger stok özeti:</strong>
  Merkez: <?= number_format($debug['merkez'],0,',','.') ?> |
  Üretim: <?= number_format($debug['uretim'],0,',','.') ?> |
  Toplam: <?= number_format($debug['merkez']+$debug['uretim'],0,',','.') ?> |
  <?= $debug['tiger_kod'] ?> kod
</div>

<!-- Özet Kartlar -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px" class="sy-grid">
  <?php foreach ([
    [$g_yuzde.'%','Genel Sayım Oranı','#2563EB',number_format($t_sayim,0,',','.').' / '.number_format($t_depo,0,',','.')],
    [$s_tam,     'Tamamen Sayılan',   '#22C55E','≥ %100'],
    [$s_kismi,   'Kısmen Sayılan',    '#D97706','%0–100 arası'],
    [$s_hic,     'Hiç Sayılmayan',    '#EF4444','Stokta var, sayılmadı'],
  ] as $k): ?>
  <div class="kart" style="padding:12px;border-left:4px solid <?= $k[2] ?>;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $k[2] ?>"><?= $k[0] ?></div>
    <div style="font-size:11px;font-weight:700"><?= $k[1] ?></div>
    <div style="font-size:10px;color:var(--m2)"><?= $k[3] ?></div>
  </div>
  <?php endforeach; ?>
</div>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px" class="sy-grid">
  <?php foreach ([
    [$s_yok,                                          'Stokta Yok Sayıldı','#7C3AED','Sistemde kayıt yok'],
    [count($ts)-$s_tam-$s_kismi-$s_hic-$s_yok,       'Stokta Yok Sayılmadı','#94A3B8',''],
    [number_format($t_sayim,0,',','.'),               'Toplam Sayım Miktarı','#0F766E','adet/kg'],
    [count($ts),                                      'Toplam Kod Sayısı','#374151',''],
  ] as $k): ?>
  <div class="kart" style="padding:12px;border-left:4px solid <?= $k[2] ?>;text-align:center">
    <div style="font-size:22px;font-weight:900;color:<?= $k[2] ?>"><?= $k[0] ?></div>
    <div style="font-size:11px;font-weight:700"><?= $k[1] ?></div>
    <?php if($k[3]): ?><div style="font-size:10px;color:var(--m2)"><?= $k[3] ?></div><?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Sekmeler -->
<div style="display:flex;gap:4px;border-bottom:2px solid var(--kenar);margin-bottom:16px">
  <button onclick="tabGoster('detay')" id="stab_detay"
          style="padding:7px 16px;border:none;background:var(--t);color:#fff;border-radius:6px 6px 0 0;font-weight:700;font-size:13px;cursor:pointer;margin-bottom:-2px">
    📄 Sayım Detayı
  </button>
  <button onclick="tabGoster('yuzde')" id="stab_yuzde"
          style="padding:7px 16px;border:none;background:var(--kenar-a);color:var(--m);border-radius:6px 6px 0 0;font-weight:700;font-size:13px;cursor:pointer;margin-bottom:-2px">
    📊 Tamamlanma Yüzdesi
  </button>
</div>

<!-- Sekme: Sayım Detayı -->
<div id="stab_detay_icerik">
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto">
<table id="tblSayimDetay" style="width:100%">
  <thead>
    <tr>
      <?php foreach(array_keys($tablo_verileri[0]??['Veri'=>'']) as $col): ?>
      <th><?= htmlspecialchars($col) ?></th>
      <?php endforeach; ?>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <?php foreach(array_keys($tablo_verileri[0]??['Veri'=>'']) as $col): ?>
      <th><?= htmlspecialchars($col) ?></th>
      <?php endforeach; ?>
    </tr>
  </tfoot>
  <tbody>
    <?php foreach ($tablo_verileri as $row): ?>
    <tr>
      <?php foreach ($row as $v): ?><td><?= htmlspecialchars($v ?? '') ?></td><?php endforeach; ?>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
</div>

<!-- Sekme: Yüzde -->
<div id="stab_yuzde_icerik" style="display:none">
<div class="kart" style="padding:0;overflow:hidden">
<div style="overflow-x:auto">
<table id="tblSayimYuzde" style="width:100%">
  <thead>
    <tr>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Grup</th>
      <th>Merkez</th><th>Üretim</th><th>Toplam Depo</th>
      <th>Sayılan</th><th>Yüzde</th><th>Durum</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>Stok Kodu</th><th>Stok Adı</th><th>Grup</th>
      <th>Merkez</th><th>Üretim</th><th>Toplam Depo</th>
      <th>Sayılan</th><th>Yüzde</th><th>Durum</th>
    </tr>
  </tfoot>
  <tbody>
  <?php foreach ($sayim_yuzde_bilgileri as $r):
    $bg = $r['toplam']==0?'#EFF6FF':($r['yuzde']==0?'#FFF5F5':($r['yuzde']>=100?'#F0FDF4':'#FFFBEB'));
    if($r['toplam']==0&&$r['sayim']==0)$bg='';
    $durum = $r['toplam']==0
      ? ($r['sayim']>0?'🔍 Stokta Yok Sayıldı':'➖ Stokta Yok')
      : ($r['yuzde']>100?'📈 Sayım Fazlası':($r['yuzde']==100?'✅ Tamamlandı':($r['yuzde']>0?'⚠️ Kısmen':'❌ Sayılmadı')));
  ?>
  <tr style="background:<?= $bg ?>">
    <td style="font-family:monospace;font-weight:700"><?= htmlspecialchars($r['kod']) ?></td>
    <td><?= htmlspecialchars($r['ad']) ?></td>
    <td><?= htmlspecialchars($r['grup']) ?></td>
    <td style="text-align:right"><?= number_format($r['merkez'],2,',','.') ?></td>
    <td style="text-align:right"><?= number_format($r['uretim'],2,',','.') ?></td>
    <td style="text-align:right;font-weight:700"><?= number_format($r['toplam'],2,',','.') ?></td>
    <td style="text-align:right"><?= number_format($r['sayim'],2,',','.') ?></td>
    <td style="text-align:center">
      <?php if($r['toplam']==0): ?>
        <span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#EFF6FF;color:#2563EB;font-weight:700">Stokta Yok</span>
      <?php else: ?>
        <span style="font-size:11px;font-weight:800;padding:2px 8px;border-radius:10px;
          background:<?= $r['yuzde']>=100?'#D1FAE5':($r['yuzde']>0?'#FDE68A':'#FECACA') ?>;
          color:<?= $r['yuzde']>=100?'#065F46':($r['yuzde']>0?'#78350F':'#7F1D1D') ?>">
          %<?= $r['yuzde'] ?>
        </span>
      <?php endif; ?>
    </td>
    <td><?= $durum ?></td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
</div>

<?php endif; // selected && yuzde ?>

<!-- İşlem Butonları (yetkili kullanıcılar) -->
<?php if ($selected && $yetkili): ?>
<div class="kart" style="padding:18px;margin-top:16px">
  <div style="font-weight:800;font-size:14px;margin-bottom:14px;color:var(--t)">
    ⚙️ Sayım İşlemleri — <span style="color:#2563EB"><?= htmlspecialchars($selected) ?></span>
  </div>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px">

    <!-- Paketleri Pasif Yap -->
    <form method="POST" onsubmit="return confirm('Sayılan kodların paketlerini pasif yapmak istediğinizden emin misiniz?')">
      <input type="hidden" name="sayim_adi" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="sayim_adi_islem" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="operation" value="pasif_yap">
      <button type="submit" class="btn btn-sm" style="width:100%;padding:10px;background:#DC2626;color:#fff;border:none;border-radius:var(--r);font-weight:700;cursor:pointer">
        🔴 Paketleri Pasif Yap
      </button>
      <div style="font-size:10px;color:var(--m3);margin-top:3px;text-align:center">Sayılan kodların tüm paketlerini pasif yapar</div>
    </form>

    <!-- Paketleri Aktif Yap -->
    <form method="POST" onsubmit="return confirm('Sayılan paketleri aktif yapmak istediğinizden emin misiniz?')">
      <input type="hidden" name="sayim_adi" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="sayim_adi_islem" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="operation" value="aktif_yap">
      <button type="submit" class="btn btn-sm" style="width:100%;padding:10px;background:#22C55E;color:#fff;border:none;border-radius:var(--r);font-weight:700;cursor:pointer">
        🟢 Paketleri Aktif Yap
      </button>
      <div style="font-size:10px;color:var(--m3);margin-top:3px;text-align:center">Sayılan paket numaralarını aktif yapar</div>
    </form>

    <!-- Paketlerde Ambar Güncelle -->
    <form method="POST" onsubmit="return confirm('Paketlerde ambar numarasını güncellemek istediğinizden emin misiniz?')">
      <input type="hidden" name="sayim_adi" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="sayim_adi_islem" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="operation" value="ambar_guncelle">
      <div style="display:flex;gap:6px">
        <input type="number" name="ambar_no" value="2" min="0" max="99"
               class="form-alan" style="width:70px;font-size:13px;text-align:center">
        <button type="submit" style="flex:1;padding:10px;background:#2563EB;color:#fff;border:none;border-radius:var(--r);font-weight:700;cursor:pointer">
          📦 Paketlerde Ambar Güncelle
        </button>
      </div>
    </form>

    <!-- Sayımda Ambar Güncelle -->
    <form method="POST" onsubmit="return confirm('Sayım tablosunda ambar numarasını güncellemek istediğinizden emin misiniz?')">
      <input type="hidden" name="sayim_adi" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="sayim_adi_islem" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="operation" value="sayim_ambar_guncelle">
      <div style="display:flex;gap:6px">
        <input type="number" name="ambar_no" value="2" min="0" max="99"
               class="form-alan" style="width:70px;font-size:13px;text-align:center">
        <button type="submit" style="flex:1;padding:10px;background:#0EA5E9;color:#fff;border:none;border-radius:var(--r);font-weight:700;cursor:pointer">
          🗃️ Sayımda Ambar Güncelle
        </button>
      </div>
    </form>

    <!-- Stok Yeri Güncelle -->
    <form method="POST" onsubmit="return confirm('Stok yerini güncellemek istediğinizden emin misiniz?')">
      <input type="hidden" name="sayim_adi" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="sayim_adi_islem" value="<?= htmlspecialchars($selected) ?>">
      <input type="hidden" name="operation" value="stok_yeri_guncelle">
      <button type="submit" style="width:100%;padding:10px;background:#D97706;color:#fff;border:none;border-radius:var(--r);font-weight:700;cursor:pointer">
        📍 Stok Yerini Güncelle
      </button>
      <div style="font-size:10px;color:var(--m3);margin-top:3px;text-align:center">Sayım tablosundaki stok yerine göre paketleri günceller</div>
    </form>

  </div>
</div>
<?php elseif ($selected && !$yetkili): ?>
<div class="kart" style="padding:12px 16px;background:#FFFBEB;color:#78350F;border-left:4px solid #D97706;margin-top:16px;font-size:13px">
  ⚠️ <strong>Yetkisiz:</strong> Sayım işlemleri sadece yetkili personel tarafından yapılabilir.
</div>
<?php endif; ?>

<?php endif; // mes_ok ?>
</div><!-- /s-body -->

<style>
@media(max-width:700px){ .sy-grid{grid-template-columns:repeat(2,1fr)!important} }
#tblSayimDetay thead th, #tblSayimDetay tfoot th,
#tblSayimYuzde thead th, #tblSayimYuzde tfoot th {
    background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;
    white-space:nowrap;border-right:1px solid #2D4E7A
}
#tblSayimDetay tbody td, #tblSayimYuzde tbody td {
    padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px
}
#tblSayimDetay tfoot select, #tblSayimYuzde tfoot select {
    width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg)
}
</style>

<script>
var stabs = ['detay','yuzde'];
function tabGoster(id) {
    stabs.forEach(function(s){
        document.getElementById('stab_'+s+'_icerik').style.display = s===id?'block':'none';
        var btn = document.getElementById('stab_'+s);
        if(btn){ btn.style.background=s===id?'var(--t)':'var(--kenar-a)'; btn.style.color=s===id?'#fff':'var(--m)'; }
    });
}

$(document).ready(function(){
    $('#tblSayimDetay').DataTable({
        initComplete: function(){
            this.api().columns().every(function(){
                var col=this, sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty())
                    .on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
                col.data().unique().sort().each(function(d){ var v=$('<div/>').html(d).text(); sel.append('<option value="'+v+'">'+(v.length>28?v.substr(0,28)+'...':v)+'</option>'); });
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'450px', paging:false, scrollX:true,
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Sayim_Detay_<?= date("Ymd") ?>'},
            {extend:'print',text:'🖨️ Yazdır'}
        ]
    });

    $('#tblSayimYuzde').DataTable({
        initComplete: function(){
            this.api().columns([0,1,2,7,8]).every(function(){
                var col=this, sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty())
                    .on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
                col.data().unique().sort().each(function(d){ var v=$('<div/>').html(d).text(); sel.append('<option value="'+v+'">'+v+'</option>'); });
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'450px', paging:false, scrollX:true,
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Sayim_Yuzde_<?= date("Ymd") ?>'},
            {extend:'print',text:'🖨️ Yazdır'}
        ]
    });
});
</script>
