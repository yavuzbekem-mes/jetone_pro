<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$bugun = date('Y-m-d');
$siparisler = [];
try {
    $siparisler = $db->query("SELECT * FROM jit_siparis WHERE jit_sip_statu='Aktif' ORDER BY jit_sip_teslim_tarihi ASC, jit_sip_saati ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

$stoklar = [];
if ($tigerdb_pdo) { try {
    $rows = $tigerdb_pdo->query("SELECT IT.CODE k, ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s
        FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
        LEFT JOIN dbo.LV_222_02_STINVTOT LV WITH(NOLOCK) ON LV.STOCKREF=IT.LOGICALREF
        WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r) $stoklar[$r['k']] = (float)$r['s'];
} catch(Throwable $e) {} }

// Saatlik kümülatif rezervasyon
$siparisler_sirali = $siparisler;
usort($siparisler_sirali, function($a,$b){
    $ta=($a['jit_sip_teslim_tarihi']??'9999-12-31').' '.($a['jit_sip_saati']??'00:00');
    $tb=($b['jit_sip_teslim_tarihi']??'9999-12-31').' '.($b['jit_sip_saati']??'00:00');
    return strcmp($ta,$tb);
});
$stok_kalan=$stoklar; $sip_rezerv=[]; $sip_tuketim=[];
foreach($siparisler_sirali as $sip){
    $id=$sip['jit_sip_id']; $kod=$sip['jit_sip_kodu'];
    $kalan_sip=max(0,floatval($sip['jit_sip_miktar'])-floatval($sip['jit_sip_sevk_miktari']??0));
    if(!isset($stok_kalan[$kod])) $stok_kalan[$kod]=0;
    $stok_kalan[$kod]-=$kalan_sip;
    $sip_rezerv[$id]=$stok_kalan[$kod];
    $sip_tuketim[$id]=($stoklar[$kod]??0)-$stok_kalan[$kod];
}
?>
<style>
#tblJitDepo th { background:#1E3A5F !important; color:#fff !important; }
#tblJitDepo td, #tblJitDepo th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">⚡ JIT / KMI Siparişleri</h1>
    <div class="s-yol">Depo / <b>JIT Aktif Siparişler</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo count($siparisler);?> kayıt</span>
    </div>
  </div>
</div>

<?php if(empty($siparisler)):?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:24px;text-align:center;color:var(--m2)">Aktif JIT siparişi bulunamadı.</div>
<?php else:?>
<div class="kart" style="overflow:hidden;padding:0">
<table id="tblJitDepo" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>#</th><th>Önem</th><th>Ürün Kodu</th><th>Ürün Adı</th>
    <th>Teslim Tarihi</th><th>Saati</th><th>Son İrs. No</th>
    <th style="text-align:right">Sipariş</th><th style="text-align:right">Sevk</th>
    <th style="text-align:right">Kalan</th><th>Firma</th>
    <th style="text-align:right">Stok</th><th style="text-align:right">Top. Rez.</th>
    <th style="text-align:right">Kümülatif</th><th>Yeterlilik</th>
    <th>Başlama Tarihi</th><th>Gecikme</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Önem</th><th>Ürün Kodu</th><th>Ürün Adı</th>
    <th>Teslim Tarihi</th><th>Saati</th><th>Son İrs. No</th>
    <th>Sipariş</th><th>Sevk</th><th>Kalan</th><th>Firma</th>
    <th>Stok</th><th>Top. Rez.</th><th>Kümülatif</th><th>Yeterlilik</th>
    <th>Başlama</th><th>Gecikme</th>
  </tr></tfoot>
  <tbody>
  <?php $say=0; foreach($siparisler as $sip):
    $say++;
    $id   = $sip['jit_sip_id'];
    $kod  = $sip['jit_sip_kodu'];
    $mik  = floatval($sip['jit_sip_miktar']);
    $sevk = floatval($sip['jit_sip_sevk_miktari']);
    $kalan= $mik - $sevk;
    $stok = $stoklar[$kod] ?? 0;
    $kumul= $sip_rezerv[$id] ?? 0;
    $tuket= $sip_tuketim[$id] ?? 0;
    $yeterli = $kumul >= 0 ? 'Yeterli' : 'Yetersiz';
    $acil = $sip['jit_sip_aciliyet'] === 'Acil';
    $gecikme = '';
    if (!empty($sip['jit_sip_teslim_tarihi']) && !empty($sip['jit_sip_saati'])) {
        $teslim = strtotime($sip['jit_sip_teslim_tarihi'].' '.$sip['jit_sip_saati']);
        $diff_dk = (int)round((time()-$teslim)/60);
        if ($diff_dk > 0) $gecikme = '+'.$diff_dk.'dk';
        elseif ($diff_dk < 0) $gecikme = $diff_dk.'dk';
    }
    $row_bg = $yeterli==='Yetersiz' ? 'background:#FFF1F2;border-left:4px solid #DC2626' : 'border-left:4px solid transparent';
  ?>
  <tr style="<?php echo $row_bg;?>">
    <td style="color:#94A3B8;font-size:11px;text-align:center"><?php echo $say;?></td>
    <td style="<?php echo $acil?'color:#DC2626;font-weight:800':'color:#94A3B8';?>"><?php echo htmlspecialchars($sip['jit_sip_aciliyet']??'');?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($kod);?></code></td>
    <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($sip['jit_sip_baslik']??'');?></td>
    <td data-order="<?php echo $sip['jit_sip_teslim_tarihi']??'';?>" style="font-weight:600"><?php echo $sip['jit_sip_teslim_tarihi']?date('d.m.Y',strtotime($sip['jit_sip_teslim_tarihi'])):'-';?></td>
    <td style="font-weight:700;color:#065F46"><?php echo htmlspecialchars($sip['jit_sip_saati']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['jit_son_irsaliye_no']??'');?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format($mik,0,',','.');?></td>
    <td style="text-align:right"><?php echo number_format($sevk,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $kalan>0?'#DC2626':'#059669';?>"><?php echo number_format($kalan,0,',','.');?></td>
    <td style="font-size:12px;max-width:140px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($sip['musteri_firma_adi']??'');?></td>
    <td style="text-align:right;color:#64748B"><?php echo number_format($stok,0,',','.');?></td>
    <td style="text-align:right;color:#64748B"><?php echo number_format($tuket,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $kumul<0?'#DC2626':'#059669';?>">
      <?php echo $kumul<0?('⚠ '.number_format(abs($kumul),0,',','.')):number_format($kumul,0,',','.');?></td>
    <td><span style="background:<?php echo $yeterli==='Yeterli'?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $yeterli==='Yeterli'?'#065F46':'#991B1B';?>;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700"><?php echo $yeterli;?></span></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['sip_baslama_tarih']??'');?></td>
    <td style="font-weight:700;color:<?php echo str_starts_with($gecikme,'+')?'#DC2626':'#059669';?>"><?php echo $gecikme;?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
    if(!$('#tblJitDepo tbody tr').length) return;
    $('#tblJitDepo').DataTable({
        initComplete: function(){
            this.api().columns([1,2,4,10,14]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        paging:false, scrollX:true, scrollY:'calc(100vh - 260px)', scrollCollapse:true,
        order:[[4,'asc'],[5,'asc']],
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'JIT_Listesi',
            exportOptions:{format:{body:function(d,r,c,node){var clean=$('<div/>').html(d).text().trim();clean=clean.replace(/\./g,'').replace(/,/g,'.');var n=parseFloat(clean);return isNaN(n)?$('<div/>').html(d).text().trim():n;}}}
        },'print']
    });
});
</script>
