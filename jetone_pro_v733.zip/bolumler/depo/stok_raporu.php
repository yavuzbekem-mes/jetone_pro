<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$tiger_ok = ($tigerdb_pdo !== null);
$hata = '';
$sonuclar = [];
if ($tiger_ok) {
    try {
        $sql = "SELECT [MALZEME OZEL KOD],[GRUP KODU],[MALZEME KODU],[MALZEME ADI],
            ISNULL(FORMAT([Merkez],'N0','de-DE'),0) AS [Merkez],
            ISNULL(FORMAT([Üretim],'N0','de-DE'),0) AS [Üretim],
            ISNULL(FORMAT([BSH],'N0','de-DE'),0) AS [BSH],
            ISNULL(FORMAT([Karantina],'N0','de-DE'),0) AS [Karantina],
            ISNULL(FORMAT([Kırma],'N0','de-DE'),0) AS [Kırma],
            ISNULL(FORMAT([Emanet],'N0','de-DE'),0) AS [Emanet],
            ISNULL(FORMAT([Takım Boz],'N0','de-DE'),0) AS [Takım Boz]
        FROM (
            SELECT IT.SPECODE [MALZEME OZEL KOD], IT.STGRPCODE [GRUP KODU],
                IT.CODE [MALZEME KODU], IT.NAME [MALZEME ADI],
                CAP.NAME [AMBAR ADI], SUM(LV.ONHAND) [Stok Miktarı]
            FROM dbo.LG_222_ITEMS IT
            LEFT JOIN dbo.LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF
            LEFT JOIN dbo.L_CAPIWHOUSE CAP ON CAP.NR=LV.INVENNO
            WHERE IT.CARDTYPE NOT IN (4,22) AND IT.CANCONFIGURE=0
              AND CAP.FIRMNR=222 AND LV.INVENNO IN (0,1,5,2,3,4,98)
            GROUP BY IT.SPECODE,IT.CODE,IT.NAME,IT.LOGICALREF,CAP.NR,CAP.NAME,IT.STGRPCODE
        ) AS src
        PIVOT (SUM([Stok Miktarı]) FOR [AMBAR ADI] IN ([Merkez],[Üretim],[BSH],[Karantina],[Kırma],[Emanet],[Takım Boz])) AS piv
        WHERE [GRUP KODU] IN ('Ambalaj','Plastik HM','Mamül','Yarımamül','Masterbatch','Yardımcı Malz.')";
        $sonuclar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblStok th { background:#1E3A5F !important; color:#fff !important; }
#tblStok td, #tblStok th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>
<div class="s-bar">
  <div><h1 class="s-bas">📦 Stok Raporu</h1>
    <div class="s-yol">Depo / <b>Ambar Bazlı Stok</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php endif;?>
    </div>
  </div>
</div>
<?php if($hata):?><div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div><?php endif;?>
<?php if(!$tiger_ok):?><div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div><?php else:?>
<!-- Detay Modal -->
<div id="detayModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)this.style.display='none'">
  <div style="background:#fff;border-radius:10px;width:900px;max-width:100%;max-height:90vh;overflow-y:auto">
    <div style="background:#1E3A5F;color:#fff;padding:12px 18px;border-radius:10px 10px 0 0;display:flex;align-items:center;justify-content:space-between">
      <span id="detayBaslik" style="font-weight:700;font-size:13px">Malzeme Detayı</span>
      <button onclick="document.getElementById('detayModal').style.display='none'" style="background:rgba(255,255,255,.15);border:none;color:#fff;width:26px;height:26px;border-radius:5px;cursor:pointer">✕</button>
    </div>
    <div id="detayIcerik" style="padding:16px">Yükleniyor...</div>
  </div>
</div>
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblStok" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:60px;text-align:center">Detay</th>
    <th>Özel Kod</th><th>Grup</th><th>Malzeme Kodu</th><th>Malzeme Adı</th>
    <th style="text-align:right">Merkez</th><th style="text-align:right">Üretim</th>
    <th style="text-align:right">BSH</th><th style="text-align:right">Karantina</th>
    <th style="text-align:right">Kırma</th><th style="text-align:right">Emanet</th>
    <th style="text-align:right">Takım Boz</th>
  </tr></thead>
  <tfoot><tr>
    <th>Detay</th><th>Özel Kod</th><th>Grup</th><th>Malzeme Kodu</th><th>Malzeme Adı</th>
    <th>Merkez</th><th>Üretim</th><th>BSH</th><th>Karantina</th><th>Kırma</th><th>Emanet</th><th>Takım Boz</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($sonuclar as $r):?>
  <tr>
    <td style="text-align:center">
      <button onclick="stokDetay('<?php echo htmlspecialchars(addslashes($r['MALZEME KODU']));?>','<?php echo htmlspecialchars(addslashes($r['MALZEME ADI']));?>')"
        style="background:#1E3A5F;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:11px;cursor:pointer">🔍</button>
    </td>
    <td><?php echo htmlspecialchars($r['MALZEME OZEL KOD']??'');?></td>
    <td><?php echo htmlspecialchars($r['GRUP KODU']??'');?></td>
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['MALZEME KODU']??'');?></code></td>
    <td><?php echo htmlspecialchars($r['MALZEME ADI']??'');?></td>
    <?php foreach(['Merkez','Üretim','BSH','Karantina','Kırma','Emanet','Takım Boz'] as $amb):?>
    <td style="text-align:right;font-weight:<?php echo ($r[$amb]??'0')!=='0'?'700':'400';?>;color:<?php echo ($r[$amb]??'0')!=='0'?'#1D4ED8':'#94A3B8';?>"><?php echo $r[$amb]??'0';?></td>
    <?php endforeach;?>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<script>
function stokDetay(kod, ad) {
    document.getElementById('detayBaslik').textContent = '🔍 ' + kod + ' — ' + ad;
    document.getElementById('detayIcerik').innerHTML = '<div style="text-align:center;padding:30px">⏳ Yükleniyor...</div>';
    document.getElementById('detayModal').style.display = 'flex';
    fetch('<?php echo BASE_URL;?>/bolumler/depo/ajax/stok_detay_ajax.php', {
        method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'kod='+encodeURIComponent(kod)
    }).then(r=>r.text()).then(html=>{ document.getElementById('detayIcerik').innerHTML=html; })
      .catch(()=>{ document.getElementById('detayIcerik').innerHTML='<div style="color:#DC2626">Hata oluştu.</div>'; });
}
$(document).ready(function(){
    $('#tblStok').DataTable({
        initComplete:function(){
            this.api().columns([1,2,3]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
        columnDefs:[{orderable:false,targets:0}],
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Stok_Raporu',
            exportOptions:{format:{body:function(data,r,c,node){var clean=$('<div/>').html(data).text().trim();clean=clean.replace(/\./g,'').replace(/,/g,'.');var num=parseFloat(clean);return isNaN(num)?$('<div/>').html(data).text().trim():num;}}}
        },'print']
    });
});
</script>
<?php endif;?>
