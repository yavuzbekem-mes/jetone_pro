<?php
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/baglanlogo.php';
header('Content-Type: text/html; charset=utf-8');
Auth::zorunlu();
$kod = trim($_POST['kod']??'');
if (!$kod || !$tigerdb_pdo) { echo '<div style="color:#DC2626">Geçersiz istek.</div>'; exit; }
try {
    $sql = "SELECT F.DATE_ tarih, F.FICHENO fis_no,
        CASE F.TRCODE WHEN 1 THEN 'Satınalma İrs.' WHEN 6 THEN 'İade İrs.' WHEN 7 THEN 'Üretim Giriş'
            WHEN 8 THEN 'Transfer' WHEN 9 THEN 'Müşteri İrs.' WHEN 25 THEN 'Ambar Transfer' ELSE CAST(F.TRCODE AS VARCHAR) END islem,
        CASE L.IOCODE WHEN 1 THEN '➕ Giriş' WHEN 2 THEN '➖ Çıkış' ELSE '-' END giris_cikis,
        L.AMOUNT miktar,
        CAP.NAME ambar
        FROM LG_222_02_STLINE L WITH(NOLOCK)
        LEFT JOIN LG_222_02_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_ITEMS IT WITH(NOLOCK) ON L.STOCKREF=IT.LOGICALREF
        LEFT JOIN L_CAPIWHOUSE CAP WITH(NOLOCK) ON CAP.NR=L.SOURCEINDEX AND CAP.FIRMNR=222
        WHERE IT.CODE=? AND L.CANCELLED=0
        ORDER BY F.DATE_ DESC";
    $st = $tigerdb_pdo->prepare($sql);
    $st->execute([$kod]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) { echo '<div style="padding:20px;text-align:center;color:#888">Hareket kaydı bulunamadı.</div>'; exit; }
    echo '<table style="width:100%;border-collapse:collapse;font-size:12px">';
    echo '<thead><tr>';
    foreach(['Tarih','Fiş No','İşlem','G/Ç','Miktar','Ambar'] as $h)
        echo '<th style="background:#1E3A5F;color:#fff;padding:6px 10px;border:1px solid #2d5986;white-space:nowrap">'.htmlspecialchars($h).'</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $i=>$r) {
        $bg = $i%2===0?'#F8FAFC':'#fff';
        $gc_color = strpos($r['giris_cikis'],'Giriş')!==false ? '#16A34A' : '#DC2626';
        echo '<tr style="background:'.$bg.'">';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;white-space:nowrap">'.date('d.m.Y',strtotime($r['tarih'])).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;font-weight:700">'.htmlspecialchars($r['fis_no']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0">'.htmlspecialchars($r['islem']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;font-weight:700;color:'.$gc_color.'">'.htmlspecialchars($r['giris_cikis']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;text-align:right;font-weight:700">'.number_format(floatval($r['miktar']),0,'','.').'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0">'.htmlspecialchars($r['ambar']??'-').'</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
} catch(Throwable $e) { echo '<div style="color:#DC2626">Hata: '.htmlspecialchars($e->getMessage()).'</div>'; }
