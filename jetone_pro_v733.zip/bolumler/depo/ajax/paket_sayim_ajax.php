<?php
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/baglanlogo.php';
header('Content-Type: application/json; charset=utf-8');

// Hata çıktısını engelle — sadece JSON dön
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

Auth::zorunlu();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['paket_no'])) {
    ob_end_clean();
    echo json_encode(['ok'=>false,'msg'=>'Geçersiz istek.']);
    exit;
}

$paket_no = trim($_POST['paket_no'] ?? '');
$ambar    = trim($_POST['ambar']    ?? '');
$raf_yeri = strtoupper(trim($_POST['raf_yeri'] ?? ''));

// Validasyon
if (empty($paket_no)) { ob_end_clean(); echo json_encode(['ok'=>false,'msg'=>'Paket numarası boş olamaz.']); exit; }
if ($ambar === '')    { ob_end_clean(); echo json_encode(['ok'=>false,'msg'=>'Ambar seçimi yapılmadı.']);    exit; }
if (empty($raf_yeri)) { ob_end_clean(); echo json_encode(['ok'=>false,'msg'=>'Raf yeri boş olamaz.']);      exit; }

if (!$mes_pdo) {
    ob_end_clean();
    echo json_encode(['ok'=>false,'msg'=>'MES veritabanı bağlantısı kurulamadı.']);
    exit;
}

try {
    // 1. Paketin varlığını ve aktif durumunu kontrol et
    $st = $mes_pdo->prepare("SELECT STOK_KODU, STOK_ADI, MIKTAR, STOK_YERI, AMBAR, AKTIF FROM MES..PAKETLER WHERE PAKET_NO=?");
    $st->execute([$paket_no]);
    $paket = $st->fetch(PDO::FETCH_ASSOC);

    if (!$paket) {
        ob_end_clean();
        echo json_encode(['ok'=>false,'msg'=>"Paket bulunamadı: $paket_no"]);
        exit;
    }

    // AKTIF=0 → aktif (normal durum), AKTIF=1 → pasif (sayıma hazır)
    // Orijinal mantık: AKTIF='0' ise zaten aktif → hata
    // Sayım için AKTIF=1 (pasif yapılmış) olmalı
    if ((string)$paket['AKTIF'] === '0') {
        ob_end_clean();
        echo json_encode(['ok'=>false,'msg'=>"Bu paket zaten aktif durumda (AKTIF=0). Sayım için önce pasif yapın: $paket_no"]);
        exit;
    }

    // 2. Paketi güncelle: AKTIF=0 yap, ambar ve raf yerini set et
    $upd = $mes_pdo->prepare("UPDATE MES..PAKETLER SET AKTIF=0, AMBAR=?, STOK_YERI=? WHERE PAKET_NO=?");
    $upd->execute([(int)$ambar, $raf_yeri, $paket_no]);

    if ($upd->rowCount() === 0) {
        ob_end_clean();
        echo json_encode(['ok'=>false,'msg'=>"Güncelleme başarısız: $paket_no"]);
        exit;
    }

    // 3. Güncel veriyi çek ve döndür
    $sel = $mes_pdo->prepare("SELECT PAKET_NO, STOK_KODU, STOK_ADI, MIKTAR, STOK_YERI, AMBAR FROM MES..PAKETLER WHERE PAKET_NO=?");
    $sel->execute([$paket_no]);
    $row = $sel->fetch(PDO::FETCH_ASSOC);

    ob_end_clean();
    echo json_encode([
        'ok'   => true,
        'data' => [
            'paket_no'  => $row['PAKET_NO']  ?? $paket_no,
            'stok_kodu' => $row['STOK_KODU'] ?? $paket['STOK_KODU'],
            'stok_adi'  => $row['STOK_ADI']  ?? $paket['STOK_ADI'] ?? '',
            'miktar'    => floatval($row['MIKTAR'] ?? $paket['MIKTAR']),
            'raf_yeri'  => $row['STOK_YERI'] ?? $raf_yeri,
            'ambar'     => $row['AMBAR']      ?? $ambar,
        ]
    ]);

} catch(Throwable $e) {
    ob_end_clean();
    echo json_encode(['ok'=>false,'msg'=>'Veritabanı hatası: '.$e->getMessage()]);
}
