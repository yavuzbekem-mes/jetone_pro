<?php
require_once dirname(dirname(dirname(__DIR__))).'/core/config.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/db.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))).'/core/baglanlogo.php';
header('Content-Type: text/html; charset=utf-8');
Auth::zorunlu();
$kod = trim($_POST['stok_kodu']??'');
$bas = $_POST['tarih_bas']??date('Y-01-01');
$bit = $_POST['tarih_bit']??date('Y-m-d');
if (!$kod || !$tigerdb_pdo) { echo '<div style="color:#DC2626;padding:14px">Geçersiz istek veya Tiger DB yok.</div>'; exit; }
try {
    $sql = "SELECT FORMAT(F.DATE_,'dd.MM.yyyy') tarih,F.FICHENO fis_no,
        CASE F.TRCODE WHEN 1 THEN 'Satınalma İrs.' WHEN 6 THEN 'İade İrs.' WHEN 7 THEN 'Üretim Giriş'
            WHEN 8 THEN 'Transfer' WHEN 9 THEN 'Müşteri İrs.' WHEN 25 THEN 'Ambar Transfer'
            WHEN 12 THEN 'Sarf' WHEN 10 THEN 'Üretim Çıkış' ELSE CAST(F.TRCODE AS VARCHAR) END islem_turu,
        CASE L.IOCODE WHEN 1 THEN 'Giriş' WHEN 2 THEN 'Çıkış' ELSE '-' END giris_cikis,
        L.AMOUNT miktar, CAP.NAME ambar,
        CL.DEFINITION_ cari
        FROM LG_222_02_STLINE L WITH(NOLOCK)
        LEFT JOIN LG_222_02_STFICHE F WITH(NOLOCK) ON L.STFICHEREF=F.LOGICALREF
        LEFT JOIN LG_222_ITEMS IT WITH(NOLOCK) ON L.STOCKREF=IT.LOGICALREF
        LEFT JOIN L_CAPIWHOUSE CAP WITH(NOLOCK) ON CAP.NR=L.SOURCEINDEX AND CAP.FIRMNR=222
        LEFT JOIN LG_222_CLCARD CL WITH(NOLOCK) ON F.CLIENTREF=CL.LOGICALREF
        WHERE IT.CODE=? AND L.CANCELLED=0 AND CAST(F.DATE_ AS DATE) BETWEEN ? AND ?
        ORDER BY F.DATE_ DESC";
    $st = $tigerdb_pdo->prepare($sql);
    $st->execute([$kod,$bas,$bit]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) { echo '<div style="padding:30px;text-align:center;color:#888">Bu dönemde hareket bulunamadı.</div>'; exit; }
    echo '<div style="padding:8px 12px;background:#EFF6FF;border-bottom:1px solid #BFDBFE;font-weight:700;font-size:12px;color:#1E3A5F">';
    echo '↕ '.htmlspecialchars($kod).' — '.count($rows).' hareket kaydı</div>';
    echo '<div style="overflow-x:auto"><table id="tblHareket" style="width:100%;border-collapse:collapse;font-size:11px">';
    echo '<thead><tr>';
    foreach(['Tarih','Fiş No','İşlem Türü','G/Ç','Miktar','Ambar','Cari'] as $h)
        echo '<th style="background:#1E3A5F;color:#fff;padding:6px 10px;border:1px solid #2d5986;white-space:nowrap">'.htmlspecialchars($h).'</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $i=>$r) {
        $bg=$i%2===0?'#F8FAFC':'#fff';
        $gc=$r['giris_cikis']==='Giriş'?'#16A34A':'#DC2626';
        echo '<tr style="background:'.$bg.'">';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;white-space:nowrap">'.htmlspecialchars($r['tarih']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;font-weight:700">'.htmlspecialchars($r['fis_no']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0">'.htmlspecialchars($r['islem_turu']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;font-weight:700;color:'.$gc.'">'.htmlspecialchars($r['giris_cikis']).'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;text-align:right;font-weight:700">'.number_format(floatval($r['miktar']),0,'','.').'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0">'.htmlspecialchars($r['ambar']??'-').'</td>';
        echo '<td style="padding:5px 10px;border:1px solid #E2E8F0;font-size:10px">'.htmlspecialchars($r['cari']??'').'</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
    echo '<script>if($.fn.DataTable&&!$.fn.DataTable.isDataTable("#tblHareket")){$("#tblHareket").DataTable({scrollCollapse:true,scrollY:"400px",paging:false,scrollX:true,language:{url:"https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json"},dom:"Bfrtip",buttons:[{extend:"excelHtml5",text:"📊 Excel",className:"btn-dt"},"print"]});}</script>';
} catch(Throwable $e) { echo '<div style="color:#DC2626;padding:14px">Hata: '.htmlspecialchars($e->getMessage()).'</div>'; }
