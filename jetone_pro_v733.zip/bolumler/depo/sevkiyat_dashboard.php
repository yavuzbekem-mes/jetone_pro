<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$bugun     = date('Y-m-d');
$yarin     = date('Y-m-d', strtotime('+1 day'));
$bir_hafta = date('Y-m-d', strtotime('+7 days'));
$yirmidort = date('Y-m-d H:i:s', strtotime('+24 hours'));

function dep_tek($db,$sql,$p=[]){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetch(PDO::FETCH_ASSOC)??[];}catch(Throwable $e){return[];}}
function dep_liste($db,$sql,$p=[]){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return[];}}

// ── KPI Kartlar
$bugun_kart   = dep_tek($db,"SELECT COUNT(*) c, SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$yarin_kart   = dep_tek($db,"SELECT COUNT(*) c, SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$yarin]);
$geciken_kart = dep_tek($db,"SELECT COUNT(*) c, SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$hafta_kart   = dep_tek($db,"SELECT COUNT(*) c, SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi) BETWEEN ? AND ? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun,$bir_hafta]);
$jit_kart     = dep_tek($db,"SELECT COUNT(*) c, SUM(jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0)) m FROM jit_siparis WHERE jit_sip_statu='Aktif' AND CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati)<=? AND (jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0))>0",[$yirmidort]);

// ── Tablo listeleri
$bugun_liste   = dep_liste($db,"SELECT musteri_firma_adi,sip_kodu,sip_baslik,sip_teslim_tarihi,(sip_miktar-COALESCE(sip_sevk_miktari,0)) kalan FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 ORDER BY musteri_firma_adi,sip_teslim_tarihi",[$bugun]);
$yarin_liste   = dep_liste($db,"SELECT musteri_firma_adi,sip_kodu,sip_baslik,sip_teslim_tarihi,(sip_miktar-COALESCE(sip_sevk_miktari,0)) kalan FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 ORDER BY musteri_firma_adi,sip_teslim_tarihi",[$yarin]);
$geciken_liste = dep_liste($db,"SELECT musteri_firma_adi,sip_kodu,sip_baslik,sip_teslim_tarihi,(sip_miktar-COALESCE(sip_sevk_miktari,0)) kalan, DATEDIFF(CURDATE(),DATE(sip_teslim_tarihi)) gecikme FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 ORDER BY sip_teslim_tarihi ASC",[$bugun]);
$jit_liste     = dep_liste($db,"SELECT jit_sip_kodu,jit_sip_teslim_tarihi,jit_sip_saati,CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati) tz,(jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0)) m FROM jit_siparis WHERE jit_sip_statu='Aktif' AND CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati)<=? AND (jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0))>0 ORDER BY tz ASC LIMIT 15",[$yirmidort]);
$hafta_liste   = dep_liste($db,"SELECT DATE(sip_teslim_tarihi) t, COUNT(*) c, SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi) BETWEEN ? AND ? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 GROUP BY DATE(sip_teslim_tarihi) ORDER BY t",[$bugun,$bir_hafta]);

// ── Tiger JIT stok
$jit_stoklar = [];
if($tigerdb_pdo && !empty($jit_liste)){
    $jit_kodlar=array_unique(array_column($jit_liste,'jit_sip_kodu'));
    try{
        $ph=implode(',',array_fill(0,count($jit_kodlar),'?'));
        $ss=$tigerdb_pdo->prepare("SELECT IT.CODE k,ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s FROM LG_222_ITEMS IT LEFT JOIN LV_222_02_STINVTOT LV ON LV.STOCKREF=IT.LOGICALREF WHERE IT.CODE IN($ph) AND IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE");
        $ss->execute($jit_kodlar);
        foreach($ss->fetchAll(PDO::FETCH_ASSOC) as $r) $jit_stoklar[$r['k']]=(float)$r['s'];
    }catch(Throwable $e){}
}
$jit_kumulatif=$jit_stoklar; $jit_sip_kalan=[];
foreach($jit_liste as $i=>$r){$kod=$r['jit_sip_kodu'];if(!isset($jit_kumulatif[$kod]))$jit_kumulatif[$kod]=0;$jit_kumulatif[$kod]-=(float)$r['m'];$jit_sip_kalan[$i]=$jit_kumulatif[$kod];}

// ── Araçlar
$arac_son=[];
try{$arr=$db->query("SELECT * FROM guv_arac_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);foreach($arr as $a){$p=$a['plaka'];if(!isset($arac_son[$p])||strtotime($a['c_zaman'])>strtotime($arac_son[$p]['c_zaman']))$arac_son[$p]=$a;}}catch(Throwable $e){}
$araclar=[
    ['plaka'=>'59 JD 820','tip'=>'KAMYON','marka'=>'MERCEDES'],
    ['plaka'=>'59 AIR 496','tip'=>'KAMYON','marka'=>'İVECO'],
    ['plaka'=>'59 AT 979','tip'=>'KAMYONET','marka'=>'FORD'],
    ['plaka'=>'59 JF 911','tip'=>'TİCARİ','marka'=>'FİORİNO'],
];

// ── Grafik: haftalık dağılım
$gun_adlari=['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'];
$hafta_labels=[]; $hafta_data=[];
foreach($hafta_liste as $r){
    $hafta_labels[]=$gun_adlari[date('w',strtotime($r['t']))].' '.date('d/m',strtotime($r['t']));
    $hafta_data[]=(float)$r['m'];
}
// ── Grafik: firma bazlı
$firma_data=dep_liste($db,"SELECT musteri_firma_adi,SUM(sip_miktar-COALESCE(sip_sevk_miktari,0)) m FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi) BETWEEN ? AND ? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 GROUP BY musteri_firma_adi ORDER BY m DESC LIMIT 6",[$bugun,$bir_hafta]);
?>
<style>
.dep-kart{border-radius:12px;padding:16px 18px;display:flex;justify-content:space-between;align-items:center;position:relative;overflow:hidden}
.dep-kart::after{content:'';position:absolute;right:-12px;bottom:-12px;width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.12)}
.dep-kart-val{font-size:28px;font-weight:900;color:#fff;line-height:1}
.dep-kart-lbl{font-size:12px;font-weight:700;color:rgba(255,255,255,.9);margin-bottom:3px}
.dep-kart-alt{font-size:11px;color:rgba(255,255,255,.75);margin-top:3px}
.dep-kart-ikon{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:20px}
.dep-g5{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:14px}
.dep-g2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
.dep-g4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px}
.dep-mini{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:10px;margin-bottom:14px}
@media(max-width:1100px){.dep-g5{grid-template-columns:1fr 1fr 1fr}}
@media(max-width:700px){.dep-g5{grid-template-columns:1fr 1fr}.dep-g2{grid-template-columns:1fr}.dep-g4{grid-template-columns:1fr 1fr}.dep-mini{grid-template-columns:1fr 1fr}}
.dep-tablo{width:100%;border-collapse:collapse;font-size:11px}
.dep-tablo th{background:#1E3A5F;color:#fff;padding:6px 10px;text-align:left;font-weight:700;white-space:nowrap;border:1px solid #2d5986}
.dep-tablo td{padding:5px 10px;border-bottom:1px solid #F1F5F9;white-space:nowrap}
.dep-tablo tbody tr:hover td{background:#F8FAFC}
.arac-kart{border-radius:10px;padding:11px;border:1px solid #E2E8F0}
.arac-disari{border-left:4px solid #DC2626;background:#FFF5F5}
.arac-iceri{border-left:4px solid #16A34A;background:#F0FDF4}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div>
    <h1 class="s-bas">🚛 Sevkiyat Dashboard</h1>
    <div class="s-yol">Depo / <b>Sevkiyat Özet</b> · <?php echo date('d.m.Y H:i');?></div>
  </div>
  <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:5px 12px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
</div>

<!-- KPI Kartlar -->
<div class="dep-g5">
  <div class="dep-kart" style="background:linear-gradient(135deg,#1E40AF,#2563EB)">
    <div>
      <div class="dep-kart-lbl">Bugünkü Sevkiyat</div>
      <div style="display:flex;align-items:baseline;gap:5px">
        <div class="dep-kart-val"><?php echo (int)($bugun_kart['c']??0);?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="dep-kart-alt"><?php echo number_format((float)($bugun_kart['m']??0),0,'','.');?> adet</div>
    </div>
    <div class="dep-kart-ikon">📦</div>
  </div>
  <div class="dep-kart" style="background:linear-gradient(135deg,#065F46,#16A34A)">
    <div>
      <div class="dep-kart-lbl">Yarınki Sevkiyat</div>
      <div style="display:flex;align-items:baseline;gap:5px">
        <div class="dep-kart-val"><?php echo (int)($yarin_kart['c']??0);?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="dep-kart-alt"><?php echo number_format((float)($yarin_kart['m']??0),0,'','.');?> adet</div>
    </div>
    <div class="dep-kart-ikon">📅</div>
  </div>
  <div class="dep-kart" style="background:linear-gradient(135deg,#991B1B,#DC2626)">
    <div>
      <div class="dep-kart-lbl">Geciken Siparişler</div>
      <div style="display:flex;align-items:baseline;gap:5px">
        <div class="dep-kart-val"><?php echo (int)($geciken_kart['c']??0);?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="dep-kart-alt"><?php echo number_format((float)($geciken_kart['m']??0),0,'','.');?> adet</div>
    </div>
    <div class="dep-kart-ikon">⚠️</div>
  </div>
  <div class="dep-kart" style="background:linear-gradient(135deg,#1E3A5F,#0369A1)">
    <div>
      <div class="dep-kart-lbl">Bu Hafta Beklenen</div>
      <div style="display:flex;align-items:baseline;gap:5px">
        <div class="dep-kart-val"><?php echo (int)($hafta_kart['c']??0);?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.8);font-weight:600">sipariş</div>
      </div>
      <div class="dep-kart-alt"><?php echo number_format((float)($hafta_kart['m']??0),0,'','.');?> adet</div>
    </div>
    <div class="dep-kart-ikon">📊</div>
  </div>
  <div class="dep-kart" style="background:linear-gradient(135deg,#92400E,#D97706)">
    <div>
      <div class="dep-kart-lbl">JIT (24 Saat)</div>
      <div style="display:flex;align-items:baseline;gap:5px">
        <div class="dep-kart-val"><?php echo (int)($jit_kart['c']??0);?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.8);font-weight:600">satır</div>
      </div>
      <div class="dep-kart-alt"><?php echo number_format((float)($jit_kart['m']??0),0,'','.');?> adet</div>
    </div>
    <div class="dep-kart-ikon">⚡</div>
  </div>
</div>

<!-- Araçlar -->
<div class="dep-g4" style="margin-bottom:14px">
<?php foreach($araclar as $ar):
    $son=$arac_son[$ar['plaka']]??null;
    $disari=$son&&empty($son['g_zaman']);
    $cls=$disari?'arac-disari':'arac-iceri';
?>
<div class="arac-kart <?php echo $cls;?>">
  <div style="display:flex;justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:800;font-size:12px;color:var(--m)"><?php echo $ar['plaka'];?></div>
      <div style="font-size:10px;color:var(--m2)"><?php echo $ar['marka'];?> · <?php echo $ar['tip'];?></div>
    </div>
    <span style="background:<?php echo $disari?'#DC2626':'#16A34A';?>;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:6px"><?php echo $disari?'Dışarıda':'İçeride';?></span>
  </div>
  <?php if($son):?>
  <div style="margin-top:6px;font-size:10px;color:var(--m2);line-height:1.7">
    <?php if($disari):?>
    <div>🏢 <?php echo htmlspecialchars(mb_strimwidth($son['firma']??'',0,26,'…'));?></div>
    <div>🕐 Çıkış: <?php echo $son['c_zaman']?date('d.m H:i',strtotime($son['c_zaman'])):'—';?></div>
    <?php
    $irs_dur = $son['irsaliye_durumu']??'irsaliyeli';
    $irs_no  = $son['irsaliye_no']??'';
    if ($irs_dur==='irsaliyesiz'):?>
    <div>📋 <span style="color:#D97706;font-weight:700">İrsaliyesiz</span></div>
    <?php elseif($irs_no):?>
    <div>📄 <span style="font-family:monospace;font-weight:700;color:#2563EB"><?php echo htmlspecialchars($irs_no);?></span></div>
    <?php endif;?>
    <?php else:?>
    <div>🔄 Son: <?php echo htmlspecialchars(mb_strimwidth($son['firma']??'',0,26,'…'));?></div>
    <div>🕐 Giriş: <?php echo $son['g_zaman']?date('d.m H:i',strtotime($son['g_zaman'])):'—';?></div>
    <?php endif;?>
    <?php if(!empty($son['sofor_adi'])):?><div>👤 <?php echo htmlspecialchars($son['sofor_adi']);?></div><?php endif;?>
  </div>
  <?php endif;?>
</div>
<?php endforeach;?>
</div>

<!-- Grafikler -->
<div class="dep-g2">
  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:12px">
    <div style="font-weight:700;font-size:12px;color:var(--m);margin-bottom:10px">📈 Bu Hafta Günlük Sevkiyat Dağılımı</div>
    <div style="position:relative;height:170px"><canvas id="depHaftaChart"></canvas></div>
  </div>
  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:12px">
    <div style="font-weight:700;font-size:12px;color:var(--m);margin-bottom:10px">🏢 Firma Bazlı Bu Hafta Dağılımı</div>
    <div style="position:relative;height:170px"><canvas id="depFirmaChart"></canvas></div>
  </div>
</div>

<!-- Tablolar: Bugün + Yarın -->
<div class="dep-g2" style="margin-bottom:14px">
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#1E3A5F;color:#fff;padding:9px 14px;font-size:12px;font-weight:700">
      📦 Bugünkü Sevkiyatlar
      <span style="background:rgba(255,255,255,.2);padding:1px 7px;border-radius:8px;font-size:10px;margin-left:6px"><?php echo count($bugun_liste);?></span>
    </div>
    <?php if(empty($bugun_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">Bugün için sipariş yok</div>
    <?php else:?>
    <div style="overflow-x:auto;max-height:280px;overflow-y:auto">
    <table class="dep-tablo">
      <thead><tr><th>Firma</th><th>Sipariş Kodu</th><th>Ürün</th><th style="text-align:right">Kalan</th></tr></thead>
      <tbody>
      <?php foreach($bugun_liste as $r):?>
      <tr>
        <td style="font-size:10px;max-width:130px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['musteri_firma_adi']??'',0,22,'…'));?></td>
        <td><code style="background:#EFF6FF;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700;color:#1D4ED8"><?php echo htmlspecialchars($r['sip_kodu']??'');?></code></td>
        <td style="font-size:10px;max-width:120px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['sip_baslik']??'',0,20,'…'));?></td>
        <td style="text-align:right;font-weight:700;color:#1E40AF"><?php echo number_format((float)$r['kalan'],0,'','.');?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    </div>
    <?php endif;?>
  </div>

  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#065F46;color:#fff;padding:9px 14px;font-size:12px;font-weight:700">
      📅 Yarınki Sevkiyatlar
      <span style="background:rgba(255,255,255,.2);padding:1px 7px;border-radius:8px;font-size:10px;margin-left:6px"><?php echo count($yarin_liste);?></span>
    </div>
    <?php if(empty($yarin_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">Yarın için sipariş yok</div>
    <?php else:?>
    <div style="overflow-x:auto;max-height:280px;overflow-y:auto">
    <table class="dep-tablo">
      <thead><tr><th>Firma</th><th>Sipariş Kodu</th><th>Ürün</th><th style="text-align:right">Kalan</th></tr></thead>
      <tbody>
      <?php foreach($yarin_liste as $r):?>
      <tr>
        <td style="font-size:10px;max-width:130px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['musteri_firma_adi']??'',0,22,'…'));?></td>
        <td><code style="background:#F0FDF4;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700;color:#16A34A"><?php echo htmlspecialchars($r['sip_kodu']??'');?></code></td>
        <td style="font-size:10px;max-width:120px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['sip_baslik']??'',0,20,'…'));?></td>
        <td style="text-align:right;font-weight:700;color:#16A34A"><?php echo number_format((float)$r['kalan'],0,'','.');?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    </div>
    <?php endif;?>
  </div>
</div>

<!-- Tablolar: Geciken + JIT -->
<div class="dep-g2">
  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#991B1B;color:#fff;padding:9px 14px;font-size:12px;font-weight:700">
      ⚠️ Geciken Sevkiyatlar
      <span style="background:rgba(255,255,255,.2);padding:1px 7px;border-radius:8px;font-size:10px;margin-left:6px"><?php echo count($geciken_liste);?></span>
    </div>
    <?php if(empty($geciken_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">✅ Geciken sipariş yok</div>
    <?php else:?>
    <div style="overflow-x:auto;max-height:280px;overflow-y:auto">
    <table class="dep-tablo">
      <thead><tr><th>Firma</th><th>Sipariş Kodu</th><th>Termin</th><th style="text-align:center">Gecikme</th><th style="text-align:right">Kalan</th></tr></thead>
      <tbody>
      <?php foreach($geciken_liste as $r):
        $g=(int)($r['gecikme']??0);
        $gc_bg=$g>7?'#FEE2E2':($g>3?'#FEF9C3':'');
      ?>
      <tr style="background:<?php echo $gc_bg;?>">
        <td style="font-size:10px;max-width:120px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['musteri_firma_adi']??'',0,20,'…'));?></td>
        <td><code style="background:#FEE2E2;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700;color:#991B1B"><?php echo htmlspecialchars($r['sip_kodu']??'');?></code></td>
        <td style="font-size:10px"><?php echo $r['sip_teslim_tarihi']?date('d.m.Y',strtotime($r['sip_teslim_tarihi'])):'—';?></td>
        <td style="text-align:center"><span style="background:<?php echo $g>7?'#DC2626':($g>3?'#D97706':'#6B7280');?>;color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:8px"><?php echo $g;?>g</span></td>
        <td style="text-align:right;font-weight:700;color:#DC2626"><?php echo number_format((float)$r['kalan'],0,'','.');?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    </div>
    <?php endif;?>
  </div>

  <div class="kart" style="padding:0;overflow:hidden">
    <div style="background:#92400E;color:#fff;padding:9px 14px;font-size:12px;font-weight:700">
      ⚡ JIT (24 Saat)
      <span style="background:rgba(255,255,255,.2);padding:1px 7px;border-radius:8px;font-size:10px;margin-left:6px"><?php echo count($jit_liste);?></span>
    </div>
    <?php if(empty($jit_liste)):?>
    <div style="padding:20px;text-align:center;color:var(--m2);font-size:12px">24 saat içinde JIT yok</div>
    <?php else:?>
    <div style="overflow-x:auto;max-height:280px;overflow-y:auto">
    <table class="dep-tablo">
      <thead><tr><th>Stok Kodu</th><th>Teslim</th><th>Kalan</th><th style="text-align:right">Miktar</th><th style="text-align:right">Stok</th></tr></thead>
      <tbody>
      <?php $simdi=time();
      foreach($jit_liste as $i=>$r):
        $ts=strtotime($r['tz']); $dk=($ts-$simdi)/60; $sh=$dk/60;
        if($dk<0){$badge='<span style="background:#991B1B;color:#fff;font-size:9px;font-weight:700;padding:1px 5px;border-radius:4px">GEÇTİ</span>';$rbg='#FFF0F0';}
        elseif($sh<=4){$badge='<span style="background:#D97706;color:#fff;font-size:9px;font-weight:700;padding:1px 5px;border-radius:4px">'.round($sh,1).'s</span>';$rbg='#FFFBEB';}
        else{$badge='<span style="background:#2563EB;color:#fff;font-size:9px;font-weight:700;padding:1px 5px;border-radius:4px">BUGÜN</span>';$rbg='';}
        $k=$jit_sip_kalan[$i]??0;
        $stok_html=!isset($jit_stoklar[$r['jit_sip_kodu']])?'<span style="color:#6B7280;font-size:10px">—</span>':($k>=0?'<span style="color:#16A34A;font-weight:700;font-size:10px">✓'.number_format($k,0,'','.').'</span>':'<span style="color:#DC2626;font-weight:700;font-size:10px">⚠'.number_format($k,0,'','.').'</span>');
      ?>
      <tr style="background:<?php echo $rbg;?>">
        <td><code style="font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['jit_sip_kodu']);?></code></td>
        <td><?php echo $badge;?></td>
        <td style="font-size:10px"><?php echo date('d.m H:i',$ts);?></td>
        <td style="text-align:right;font-weight:700;font-size:11px"><?php echo number_format((float)$r['m'],0,'','.');?></td>
        <td style="text-align:right"><?php echo $stok_html;?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
    </div>
    <?php endif;?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function(){
    if(window._depChart1){window._depChart1.destroy();window._depChart1=null;}
    if(window._depChart2){window._depChart2.destroy();window._depChart2=null;}
    var c1=document.getElementById('depHaftaChart');
    if(c1&&<?php echo json_encode(!empty($hafta_data));?>){
        window._depChart1=new Chart(c1,{type:'bar',data:{
            labels:<?php echo json_encode($hafta_labels,JSON_UNESCAPED_UNICODE);?>,
            datasets:[{label:'Adet',data:<?php echo json_encode($hafta_data);?>,backgroundColor:'rgba(37,99,235,.7)',borderColor:'#1E40AF',borderWidth:1,borderRadius:4}]
        },options:{responsive:true,maintainAspectRatio:false,animation:false,
            plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{font:{size:10}}},x:{ticks:{font:{size:10}}}}}});
    }
    var c2=document.getElementById('depFirmaChart');
    var fl=<?php echo json_encode(array_column($firma_data,'musteri_firma_adi'),JSON_UNESCAPED_UNICODE);?>;
    var fd=<?php echo json_encode(array_map(fn($r)=>(float)$r['m'],$firma_data));?>;
    if(c2&&fl.length){
        window._depChart2=new Chart(c2,{type:'doughnut',data:{
            labels:fl,
            datasets:[{data:fd,backgroundColor:['#2563EB','#DC2626','#16A34A','#D97706','#7C3AED','#0891B2'],borderWidth:2}]
        },options:{responsive:true,maintainAspectRatio:false,animation:false,
            plugins:{legend:{position:'right',labels:{font:{size:10},boxWidth:12}}}}});
    }
})();
</script>
