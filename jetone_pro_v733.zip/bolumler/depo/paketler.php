<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$mes_ok    = ($mes_pdo !== null);
$paket_no  = trim($_POST['paket_no']  ?? $_GET['paket_no']  ?? '');
$stok_kodu = trim($_POST['stok_kodu'] ?? $_GET['stok_kodu'] ?? '');
$sonuclar  = [];
$hata      = '';
$mesaj     = '';

// AKTIF toggle
if (isset($_POST['update_id']) && $mes_ok) {
    $uid = (int)$_POST['update_id'];
    try {
        $sel = $mes_pdo->prepare("SELECT AKTIF FROM MES..PAKETLER WHERE ID=?");
        $sel->execute([$uid]);
        $cur = $sel->fetchColumn();
        $yeni = ($cur == 0) ? 1 : 0;
        $mes_pdo->prepare("UPDATE MES..PAKETLER SET AKTIF=? WHERE ID=?")->execute([$yeni, $uid]);
        $mesaj = "ID=$uid → AKTIF değeri ".($yeni==1?'Pasif (1)':'Aktif (0)')." yapıldı.";
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

// Arama
if ($mes_ok && ($paket_no || $stok_kodu)) {
    try {
        $sql = "SELECT ID,PAKET_NO,STOK_KODU,STOK_ADI,MIKTAR,BIRIM,URETIM_EMRI_NO,
            CONVERT(varchar,URETIM_TARIHI,104) URETIM_TARIHI,
            AKTIF,ANA_PAKET_NO,CALISAN,ETIKET_TURU,ANA_HAMMADDE,
            STOK_YERI,EKLEYEN,FIS_NO,
            CONVERT(varchar,KALITE_TARIHI,104) KALITE_TARIHI,
            CONVERT(varchar,EKLENME_TARIHI,120) EKLENME_TARIHI,
            KAYIT_TURU,AMBAR
            FROM MES..PAKETLER WHERE 1=1";
        $params = [];
        if ($paket_no)  { $sql .= " AND PAKET_NO=?";  $params[] = $paket_no; }
        if ($stok_kodu) { $sql .= " AND STOK_KODU=?"; $params[] = $stok_kodu; }
        $sql .= " ORDER BY EKLENME_TARIHI DESC";
        $st = $mes_pdo->prepare($sql);
        $st->execute($params);
        $sonuclar = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}

$ambar_adlari = [0=>'Merkez',1=>'Üretim',2=>'Karantina',3=>'Kırma',4=>'Emanet',5=>'BSH',98=>'Takım Boz'];
?>
<style>
#tblPaketler th { background:#1E3A5F !important; color:#fff !important; }
#tblPaketler td, #tblPaketler th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📦 Paketler</h1>
    <div class="s-yol">Depo / <b>MES Paket Sorgulama</b>
      <?php if($mes_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● MES DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>
<?php if($mesaj):?>
<div style="background:#D1FAE5;color:#065F46;padding:10px;border-radius:8px;margin-bottom:10px;font-weight:600">✅ <?php echo htmlspecialchars($mesaj);?></div>
<?php endif;?>
<?php if(!$mes_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ MES veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<!-- Arama Formu -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div>
      <label class="form-etiket">Paket No</label>
      <input type="text" name="paket_no" class="form-alan"
        value="<?php echo htmlspecialchars($paket_no);?>" placeholder="Paket No girin...">
    </div>
    <div>
      <label class="form-etiket">Stok Kodu</label>
      <input type="text" name="stok_kodu" class="form-alan"
        value="<?php echo htmlspecialchars($stok_kodu);?>" placeholder="Stok kodu girin...">
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Ara</button>
    <?php if($paket_no||$stok_kodu):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-paketler"
       style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
    <?php endif;?>
  </form>
</div>

<!-- Tablo -->
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblPaketler" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th style="width:90px;text-align:center">İşlem</th>
    <th>ID</th><th>Paket No</th><th>Stok Kodu</th><th>Stok Adı</th>
    <th style="text-align:right">Miktar</th><th>Birim</th>
    <th>Üretim Emri</th><th>Üretim Tarihi</th>
    <th style="text-align:center">Aktif</th>
    <th>Ana Paket</th><th>Çalışan</th><th>Etiket Türü</th>
    <th>Ana Hammadde</th><th>Stok Yeri</th><th>Ekleyen</th>
    <th>Fiş No</th><th>Kalite Tarihi</th><th>Eklenme Tarihi</th>
    <th>Kayıt Türü</th><th>Ambar</th>
  </tr></thead>
  <tfoot><tr>
    <th>İşlem</th><th>ID</th><th>Paket No</th><th>Stok Kodu</th><th>Stok Adı</th>
    <th>Miktar</th><th>Birim</th><th>Üretim Emri</th><th>Üretim Tarihi</th>
    <th>Aktif</th><th>Ana Paket</th><th>Çalışan</th><th>Etiket Türü</th>
    <th>Ana Hammadde</th><th>Stok Yeri</th><th>Ekleyen</th>
    <th>Fiş No</th><th>Kalite Tarihi</th><th>Eklenme Tarihi</th>
    <th>Kayıt Türü</th><th>Ambar</th>
  </tr></tfoot>
  <tbody>
  <?php if(empty($sonuclar)&&($paket_no||$stok_kodu)):?>
  <tr><td colspan="21" style="text-align:center;padding:30px;color:#888">Sonuç bulunamadı.</td></tr>
  <?php elseif(empty($sonuclar)):?>
  <tr><td colspan="21" style="text-align:center;padding:30px;color:#94A3B8;font-style:italic">Paket no veya stok kodu ile arama yapın.</td></tr>
  <?php else: foreach($sonuclar as $r):
    $aktif = (int)($r['AKTIF']??0);
    $row_bg = $aktif===0 ? '' : 'background:#F8FAFC';
  ?>
  <tr style="<?php echo $row_bg;?>">
    <td style="text-align:center">
      <form method="POST" style="display:inline">
        <input type="hidden" name="paket_no"  value="<?php echo htmlspecialchars($paket_no);?>">
        <input type="hidden" name="stok_kodu" value="<?php echo htmlspecialchars($stok_kodu);?>">
        <input type="hidden" name="update_id" value="<?php echo $r['ID'];?>">
        <button type="submit"
          style="background:<?php echo $aktif===0?'#DC2626':'#16A34A';?>;color:#fff;border:none;padding:4px 10px;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer">
          <?php echo $aktif===0?'Pasif Yap':'Aktif Yap';?>
        </button>
      </form>
    </td>
    <td style="color:#64748B;font-size:11px"><?php echo $r['ID'];?></td>
    <td style="font-weight:700"><code style="background:#EFF6FF;padding:1px 5px;border-radius:3px;font-size:11px;color:#1D4ED8"><?php echo htmlspecialchars($r['PAKET_NO']??'');?></code></td>
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format(floatval($r['MIKTAR']??0),0,'','.');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['BIRIM']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['URETIM_EMRI_NO']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['URETIM_TARIHI']??'');?></td>
    <td style="text-align:center">
      <span style="background:<?php echo $aktif===0?'#D1FAE5':'#FEE2E2';?>;color:<?php echo $aktif===0?'#065F46':'#991B1B';?>;padding:2px 8px;border-radius:100px;font-size:10px;font-weight:700">
        <?php echo $aktif===0?'✅ Aktif':'⛔ Pasif';?>
      </span>
    </td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['ANA_PAKET_NO']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['CALISAN']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['ETIKET_TURU']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['ANA_HAMMADDE']??'');?></td>
    <td style="font-weight:600;color:#0369A1"><?php echo htmlspecialchars($r['STOK_YERI']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['EKLEYEN']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['FIS_NO']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['KALITE_TARIHI']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['EKLENME_TARIHI']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['KAYIT_TURU']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($ambar_adlari[(int)($r['AMBAR']??-1)] ?? $r['AMBAR'] ?? '');?></td>
  </tr>
  <?php endforeach; endif;?>
  </tbody>
</table>
</div>
</div>
<script>
$(document).ready(function(){
    if($('#tblPaketler tbody tr td').length > 1 && !$('#tblPaketler tbody tr td[colspan]').length) {
        $('#tblPaketler').DataTable({
            initComplete:function(){
                this.api().columns([2,3,9,14,15,19,20]).every(function(){
                    var col=this,th=$(col.footer());if(!th||!th.length)return;
                    var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                        .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                    col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
                });
            },
            language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
            scrollCollapse:true, scrollY:'500px', paging:false, scrollX:true,
            columnDefs:[{orderable:false,targets:0}],
            dom:'Bfrtip',
            buttons:[
                {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Paketler',
                    exportOptions:{format:{body:function(data,r,c,node){
                        var v=$('<div/>').html(data).text().trim();
                        if(c===0) return '';
                        var n=parseFloat(v.replace(/\./g,'').replace(',','.'));
                        return isNaN(n)?v:n;
                    }}}
                },'print'
            ]
        });
    }
});
</script>
<?php endif;?>
