<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$tiger_ok = ($tigerdb_pdo !== null);
$stok_listesi = [];
if ($tiger_ok) {
    try {
        $sl = $tigerdb_pdo->query("SELECT IT.CODE,IT.NAME FROM LG_222_ITEMS IT WHERE IT.CARDTYPE NOT IN (4,22) AND IT.CANCONFIGURE=0 ORDER BY IT.CODE");
        $stok_listesi = $sl->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {}
}
?>
<div class="s-bar">
  <div><h1 class="s-bas">↕ Stok Hareketleri</h1>
    <div class="s-yol">Depo / <b>Hareket Raporu</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>
<div class="kart" style="padding:14px;margin-bottom:12px">
  <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
    <div style="flex:1;min-width:280px">
      <label class="form-etiket">Stok Kodu</label>
      <select id="shrStokKodu" class="form-alan">
        <option value="">— Stok Kodu Seçin —</option>
        <?php foreach($stok_listesi as $s):?>
        <option value="<?php echo htmlspecialchars($s['CODE'],ENT_QUOTES);?>"><?php echo htmlspecialchars($s['CODE'],ENT_QUOTES);?> — <?php echo htmlspecialchars($s['NAME'],ENT_QUOTES);?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div><label class="form-etiket">Başlangıç</label><input type="date" id="shrBas" class="form-alan" value="<?php echo date('Y-01-01');?>"></div>
    <div><label class="form-etiket">Bitiş</label><input type="date" id="shrBit" class="form-alan" value="<?php echo date('Y-m-d');?>"></div>
    <div style="align-self:flex-end"><button id="shrBtnCek" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Hareketleri Çek</button></div>
  </div>
</div>
<div id="shrSonuc">
  <div style="text-align:center;padding:60px;color:#94A3B8">
    <div style="font-size:40px;opacity:.3;margin-bottom:12px">📦</div>
    <div>Stok kodu seçip <b>Hareketleri Çek</b> butonuna tıklayın.</div>
  </div>
</div>
<script>
$(document).ready(function(){
    if(typeof $.fn.select2==='function') {
        $('#shrStokKodu').select2({placeholder:'— Stok Kodu Seçin —',allowClear:true,width:'100%',
            language:{noResults:function(){return 'Sonuç yok';}}});
    }
    $('#shrBtnCek').on('click', function(){
        var kod=$('#shrStokKodu').val();
        var bas=$('#shrBas').val();
        var bit=$('#shrBit').val();
        if(!kod){alert('Lütfen stok kodu seçin.');return;}
        $('#shrSonuc').html('<div style="text-align:center;padding:40px"><div class="dt-yuk">⏳</div><p style="color:#64748B;margin-top:8px;font-size:12px">Veriler yükleniyor...</p></div>');
        $.ajax({
            url:'<?php echo BASE_URL;?>/bolumler/depo/ajax/stok_hareket_ajax.php',
            method:'POST', data:{stok_kodu:kod,tarih_bas:bas,tarih_bit:bit},
            success:function(html){$('#shrSonuc').html(html);},
            error:function(xhr,s,e){$('#shrSonuc').html('<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:8px">❌ Hata: '+e+'</div>');}
        });
    });
});
</script>
