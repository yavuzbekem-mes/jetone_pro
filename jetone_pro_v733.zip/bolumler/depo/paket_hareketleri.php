<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$tiger_ok = ($tigerdb_pdo !== null);
$paket_no  = trim($_POST['paket_no']??$_GET['paket_no']??'');
$stok_kodu = trim($_POST['stok_kodu']??$_GET['stok_kodu']??'');
$sonuclar  = []; $hata = '';
if ($tiger_ok && ($paket_no||$stok_kodu)) {
    try {
        $sql = "SELECT * FROM (
            SELECT 'AMBAR TRANSFERİ' KAYIT_TURU,
                CASE WHEN STL.SPECODE='' THEN USR.USERNAME ELSE STF.DOCODE END EKLEYEN_KISI,
                STF.FICHENO FIS_NO, FORMAT(STF.DATE_,'dd.MM.yyyy') FIS_TARIHI,
                IT.CODE STOK_KODU, IT.NAME STOK_ADI,
                CASE WHEN STL.SPECODE='' THEN 'LOGO TRANSFER' ELSE STL.SPECODE END PAKET_NO,
                CASE STL.DESTINDEX WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                    WHEN 3 THEN 'KIRMA' WHEN 4 THEN 'EMANET' WHEN 5 THEN 'BSH' WHEN 98 THEN 'TAKIM BOZ' ELSE '' END CIKIS_AMBARI,
                CASE STL.SOURCEINDEX WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                    WHEN 3 THEN 'KIRMA' WHEN 4 THEN 'EMANET' WHEN 5 THEN 'BSH' WHEN 98 THEN 'TAKIM BOZ' ELSE '' END GIRIS_AMBARI
            FROM LG_222_02_STLINE STL WITH(NOLOCK)
            LEFT JOIN LG_222_02_STFICHE STF WITH(NOLOCK) ON STL.STFICHEREF=STF.LOGICALREF
            LEFT JOIN LG_222_ITEMS IT WITH(NOLOCK) ON STL.STOCKREF=IT.LOGICALREF
            LEFT JOIN L_CAPIUSER USR WITH(NOLOCK) ON STF.CAPIBLOCK_CREATEDBY=USR.NR
            WHERE STL.TRCODE IN (8,25) AND STL.IOCODE=2
              AND STF.DATE_>='2026-01-01'
              AND (:p1='' OR STL.SPECODE=:p2)
              AND (:p3='' OR IT.CODE=:p4)
            UNION ALL
            SELECT PKT.HAREKET_TURU KAYIT_TURU, PKT.EKLEYEN_KISI,
                CASE WHEN PKT.HAREKET_TURU='RAF ADRESLEME' THEN 'RAF ADRESLEME'
                    ELSE (SELECT S.FICHENO FROM LG_222_02_STFICHE S WHERE S.LOGICALREF=PKT.LOGO_FIS_ID) END FIS_NO,
                FORMAT(PKT.EKLENME_TARIHI,'dd.MM.yyyy') FIS_TARIHI,
                PKT.STOK_KODU, PKT.STOK_TANIMI STOK_ADI, PKT.PAKET_NO,
                CASE (SELECT S.SOURCEINDEX FROM LG_222_02_STFICHE S WHERE S.LOGICALREF=PKT.LOGO_FIS_ID)
                    WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                    WHEN 3 THEN 'KIRMA' WHEN 4 THEN 'EMANET' WHEN 5 THEN 'BSH' WHEN 98 THEN 'TAKIM BOZ' ELSE '' END CIKIS_AMBARI,
                NULL GIRIS_AMBARI
            FROM MES..PAKET_HAREKETLERI PKT
            WHERE PKT.PAKET_NO<>'TOPLAM' AND PKT.EKLENME_TARIHI>='2026-01-01'
              AND (:p5='' OR PKT.PAKET_NO=:p6)
              AND (:p7='' OR PKT.STOK_KODU=:p8)
        ) combined ORDER BY FIS_TARIHI ASC";
        $st = $tigerdb_pdo->prepare($sql);
        $st->execute([$paket_no,$paket_no,$stok_kodu,$stok_kodu,$paket_no,$paket_no,$stok_kodu,$stok_kodu]);
        $sonuclar = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblPaket th { background:#1E3A5F !important; color:#fff !important; }
#tblPaket td, #tblPaket th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>
<div class="s-bar">
  <div><h1 class="s-bas">📦 Paket Hareketleri</h1>
    <div class="s-yol">Depo / <b>Paket Hareket Raporu</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>
<?php if($hata):?><div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div><?php endif;?>
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div><label class="form-etiket">Paket No</label>
      <input type="text" name="paket_no" class="form-alan" value="<?php echo htmlspecialchars($paket_no);?>" placeholder="Paket no..."></div>
    <div><label class="form-etiket">Stok Kodu</label>
      <input type="text" name="stok_kodu" class="form-alan" value="<?php echo htmlspecialchars($stok_kodu);?>" placeholder="Stok kodu..."></div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Ara</button>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-paket-hareketler" style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
  </form>
  <div style="font-size:11px;color:#64748B;margin-top:6px">Not: 01.01.2026 tarihi ve sonrasına ait kayıtlar gösterilmektedir.</div>
</div>
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblPaket" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>Kayıt Türü</th><th>Ekleyen Kişi</th><th>Fiş No</th><th>Fiş Tarihi</th>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Paket No</th>
    <th>Çıkış Ambarı</th><th>Giriş Ambarı</th>
  </tr></thead>
  <tfoot><tr>
    <th>Kayıt Türü</th><th>Ekleyen</th><th>Fiş No</th><th>Tarih</th>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Paket No</th><th>Çıkış</th><th>Giriş</th>
  </tr></tfoot>
  <tbody>
  <?php if(empty($sonuclar)):?>
  <tr><td colspan="9" style="text-align:center;padding:30px;color:#888">Paket no veya stok kodu ile arama yapın.</td></tr>
  <?php else: foreach($sonuclar as $r):
    $tur = $r['KAYIT_TURU']??'';
    $tur_color = str_contains($tur,'TRANSFER')?'#0369A1':(str_contains($tur,'RAF')?'#16A34A':'#7C3AED');
  ?>
  <tr>
    <td><span style="background:<?php echo $tur_color;?>1a;color:<?php echo $tur_color;?>;padding:2px 8px;border-radius:100px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($tur);?></span></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($r['EKLEYEN_KISI']??'');?></td>
    <td style="font-weight:700"><?php echo htmlspecialchars($r['FIS_NO']??'');?></td>
    <td><?php echo htmlspecialchars($r['FIS_TARIHI']??'');?></td>
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td style="font-weight:600;color:#0369A1"><?php echo htmlspecialchars($r['PAKET_NO']??'');?></td>
    <td style="color:#DC2626;font-weight:600"><?php echo htmlspecialchars($r['CIKIS_AMBARI']??'');?></td>
    <td style="color:#16A34A;font-weight:600"><?php echo htmlspecialchars($r['GIRIS_AMBARI']??'');?></td>
  </tr>
  <?php endforeach; endif;?>
  </tbody>
</table>
</div>
</div>
<script>
$(document).ready(function(){
    if($('#tblPaket tbody tr td').length > 1) {
        $('#tblPaket').DataTable({
            initComplete:function(){
                this.api().columns([0,1,4,6,7,8]).every(function(){
                    var col=this,th=$(col.footer());if(!th||!th.length)return;
                    var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                        .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                    col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
                });
            },
            language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
            scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
            dom:'Bfrtip',
            buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Paket_Hareketleri'},'print']
        });
    }
});
</script>
