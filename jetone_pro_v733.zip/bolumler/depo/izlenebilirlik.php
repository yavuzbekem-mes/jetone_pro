<?php
/**
 * JETONE.PRO — Paket İzlenebilirlik
 * panel.php: 'depo-izlenebilirlik' => 'bolumler/depo/izlenebilirlik.php'
 */
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$mes_ok    = ($mes_pdo !== null);
$tiger_ok  = ($tigerdb_pdo !== null);
$paket_no  = trim($_POST['paket_no'] ?? $_GET['paket_no'] ?? '');
$sonuclar  = [];
$hata      = '';

if ($mes_ok && $paket_no) {
    try {
        $sql = "SELECT
    P.ID, P.PAKET_NO, P.STOK_KODU, P.STOK_ADI, P.MIKTAR, P.BIRIM,
    P.URETIM_EMRI_NO, P.URETIM_TARIHI, P.AKTIF, P.ANA_PAKET_NO,
    P.CALISAN, P.ETIKET_TURU, P.ANA_HAMMADDE, P.STOK_YERI,
    P.EKLEYEN, P.FIS_NO, P.KALITE_TARIHI, P.EKLENME_TARIHI,
    P.KAYIT_TURU, P.AMBAR,
    YEAR(P.URETIM_TARIHI) AS YIL,
    MONTH(P.URETIM_TARIHI) AS AY,
    DAY(P.URETIM_TARIHI) AS GUN,

    SF1.FICHENO        AS URETIM_FIS_NO_LOGO,
    SARF.FICHENO       AS SARF_FIS_NO,
    SARF.DATE_         AS SARF_TARIHI,
    IT.CODE            AS SARF_MALZEME_KODU,
    IT.NAME            AS SARF_MALZEME_ADI,
    SL.AMOUNT          AS SARF_MIKTARI,
    (SELECT TOP 1 P2.PAKET_NO FROM dbo.PAKETLER P2 WHERE P2.STOK_KODU=IT.CODE ORDER BY P2.EKLENME_TARIHI DESC) AS SARF_LOT_NO,
    LOT.CODE           AS LOT_NO,

    SATINALMA_GIRIS.Irsaliye_Tarihi   AS GIRIS_FIS_TARIHI,
    SATINALMA_GIRIS.Irsaliye_No       AS GIRIS_FISI_NO,
    SATINALMA_GIRIS.Irsaliye_Turu     AS FIS_TURU,
    SATINALMA_GIRIS.Tedarikci_Tanimi,
    SATINALMA_GIRIS.Satinalma_Miktari,
    SATINALMA_GIRIS.Birim_Fiyat,
    SATINALMA_GIRIS.Toplam_Tutar,
    SATINALMA_GIRIS.LotNo             AS IRSALIYE_LOT_NO

FROM dbo.PAKETLER AS P
LEFT JOIN TIGERDB.dbo.LG_222_02_STFICHE AS SF1
    ON P.FIS_NO=SF1.FICHENO AND SF1.TRCODE=13 AND SF1.PRODSTAT=0 AND SF1.PORDERFICHENO=P.URETIM_EMRI_NO
LEFT JOIN TIGERDB.dbo.LG_222_02_STFICHE AS SARF
    ON SF1.FICHENO=SARF.UGIRTRACKINGNO AND SARF.TRCODE=12 AND SARF.PRODSTAT=0
LEFT JOIN TIGERDB.dbo.LG_222_02_STLINE AS SL  ON SL.STFICHEREF=SARF.LOGICALREF
LEFT JOIN TIGERDB.dbo.LG_222_ITEMS AS IT       ON SL.STOCKREF=IT.LOGICALREF
LEFT JOIN TIGERDB.dbo.LG_222_02_SLTRANS AS SLT ON SLT.STTRANSREF=SL.LOGICALREF
LEFT JOIN TIGERDB.dbo.LG_222_02_SERILOTN AS LOT ON SLT.SLREF=LOT.LOGICALREF
LEFT JOIN (
    SELECT ITEMS.CODE AS Malzeme_Kodu,
        STFICHE.DATE_ AS Irsaliye_Tarihi, STFICHE.FICHENO AS Irsaliye_No,
        CLCARD.DEFINITION_ AS Tedarikci_Tanimi,
        SUM(STLINE.AMOUNT) AS Satinalma_Miktari,
        STLINE.PRICE AS Birim_Fiyat, STLINE.TOTAL AS Toplam_Tutar,
        STLINE.SPECODE2 AS LotNo,
        CASE STFICHE.TRCODE
            WHEN 1 THEN 'Satinalma Irsaliyesi' WHEN 5 THEN 'Konsinye Giris'
            WHEN 6 THEN 'Iade Irsaliyesi'       WHEN 26 THEN 'Mustahsil Irsaliyesi'
            WHEN 34 THEN 'Numune Giris'          ELSE 'Diger'
        END AS Irsaliye_Turu,
        ROW_NUMBER() OVER(PARTITION BY ITEMS.CODE ORDER BY STFICHE.DATE_ DESC, STFICHE.FICHENO DESC) AS RN
    FROM TIGERDB.dbo.LG_222_02_STLINE STLINE WITH(NOLOCK)
    LEFT JOIN TIGERDB.dbo.LG_222_02_STFICHE STFICHE WITH(NOLOCK) ON STLINE.STFICHEREF=STFICHE.LOGICALREF
    LEFT JOIN TIGERDB.dbo.LG_222_CLCARD CLCARD WITH(NOLOCK)      ON CLCARD.LOGICALREF=STFICHE.CLIENTREF
    LEFT JOIN TIGERDB.dbo.LG_222_ITEMS ITEMS WITH(NOLOCK)        ON ITEMS.LOGICALREF=STLINE.STOCKREF
    WHERE STLINE.LINETYPE IN(0,1) AND STLINE.CANCELLED=0 AND STFICHE.TRCODE IN(1,5,6,10,26,34)
    GROUP BY ITEMS.CODE,STFICHE.DATE_,STFICHE.FICHENO,CLCARD.DEFINITION_,STLINE.PRICE,STLINE.TOTAL,STLINE.SPECODE2,STFICHE.TRCODE
) AS SATINALMA_GIRIS ON SATINALMA_GIRIS.Malzeme_Kodu=IT.CODE AND SATINALMA_GIRIS.RN=1

WHERE P.PAKET_NO=:paket_no
ORDER BY P.PAKET_NO";

        $stmt = $mes_pdo->prepare($sql);
        $stmt->execute(['paket_no' => $paket_no]);
        $sonuclar = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
        $hata = $e->getMessage();
    }
}

// Sonuçtan ana bilgileri çıkar
$paket = !empty($sonuclar) ? $sonuclar[0] : null;
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">🔎 Paket İzlenebilirlik</h1>
    <div class="s-yol">Depo / <b>İzlenebilirlik</b>
      <?php if($mes_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES</span><?php endif;?>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#2563EB;font-weight:700;margin-left:6px">● Tiger</span><?php endif;?>
    </div>
  </div>
</div>

<div class="s-body">

<?php if (!$mes_ok): ?>
<div class="kart" style="padding:16px;background:#FEF2F2;color:#7F1D1D">MES veritabanı bağlantısı yok.</div>
<?php else: ?>

<!-- Arama -->
<div class="kart" style="padding:14px;margin-bottom:14px">
  <form method="POST" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <label class="form-et" style="margin:0">Paket No:</label>
    <input type="text" name="paket_no" value="<?= htmlspecialchars($paket_no) ?>"
           class="form-alan" style="width:220px;font-size:13px;font-family:monospace"
           placeholder="Paket numarası girin..." autofocus>
    <button type="submit" class="btn btn-t btn-sm" style="padding:6px 20px">🔍 Ara</button>
    <?php if($paket_no): ?>
    <a href="?sayfa=depo-izlenebilirlik" class="btn btn-b btn-sm">✕ Temizle</a>
    <?php endif; ?>
  </form>
</div>

<?php if ($hata): ?>
<div class="kart" style="padding:12px 16px;background:#FEF2F2;color:#7F1D1D;border-left:4px solid #EF4444">
  <strong>Hata:</strong> <?= htmlspecialchars($hata) ?>
</div>
<?php elseif ($paket_no && empty($sonuclar)): ?>
<div class="kart" style="padding:30px;text-align:center;color:var(--m3)">
  <div style="font-size:32px;margin-bottom:10px">🔍</div>
  <div style="font-size:14px;font-weight:600">"<?= htmlspecialchars($paket_no) ?>" için kayıt bulunamadı</div>
</div>

<?php elseif ($paket): ?>

<!-- Paket Başlık Kartı -->
<div class="kart" style="padding:16px;margin-bottom:14px;border-left:4px solid <?= $paket['AKTIF']?'#22C55E':'#EF4444' ?>">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
    <div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
        <span style="font-size:22px;font-weight:900;font-family:monospace;color:var(--t)"><?= htmlspecialchars($paket['PAKET_NO']) ?></span>
        <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;
              background:<?= $paket['AKTIF']?'#D1FAE5':'#FEE2E2' ?>;
              color:<?= $paket['AKTIF']?'#065F46':'#991B1B' ?>">
          <?= $paket['AKTIF']?'● Aktif':'● Pasif' ?>
        </span>
      </div>
      <div style="font-size:16px;font-weight:700;color:var(--t)"><?= htmlspecialchars($paket['STOK_ADI']) ?></div>
      <div style="font-size:13px;color:var(--m2);margin-top:2px;font-family:monospace"><?= htmlspecialchars($paket['STOK_KODU']) ?></div>
    </div>
    <div style="text-align:right">
      <div style="font-size:24px;font-weight:900;color:#2563EB"><?= htmlspecialchars($paket['MIKTAR']) ?> <span style="font-size:14px"><?= htmlspecialchars($paket['BIRIM']) ?></span></div>
      <div style="font-size:11px;color:var(--m2)">Ambar: <?= htmlspecialchars($paket['AMBAR'] ?? '—') ?></div>
    </div>
  </div>
</div>

<!-- Detay Grid -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px" class="iz-grid">

  <!-- Paket Bilgileri -->
  <div class="kart" style="padding:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t);border-bottom:2px solid #2563EB;padding-bottom:6px">
      📦 Paket Bilgileri
    </div>
    <table style="width:100%;font-size:12px;border-collapse:collapse">
      <?php
      $paket_alanlar = [
        ['Paket No',         'PAKET_NO'],
        ['Ana Paket No',     'ANA_PAKET_NO'],
        ['Stok Kodu',        'STOK_KODU'],
        ['Stok Adı',         'STOK_ADI'],
        ['Miktar',           'MIKTAR'],
        ['Birim',            'BIRIM'],
        ['Etiket Türü',      'ETIKET_TURU'],
        ['Kayıt Türü',       'KAYIT_TURU'],
        ['Stok Yeri',        'STOK_YERI'],
        ['Ambar',            'AMBAR'],
        ['Ana Hammadde',     'ANA_HAMMADDE'],
        ['Ekleyen',          'EKLEYEN'],
        ['Eklenme Tarihi',   'EKLENME_TARIHI'],
        ['Kalite Tarihi',    'KALITE_TARIHI'],
      ];
      foreach ($paket_alanlar as $alan): ?>
      <tr>
        <td style="padding:5px 8px;color:var(--m2);width:42%;border-bottom:1px solid var(--kenar)"><?= $alan[0] ?></td>
        <td style="padding:5px 8px;font-weight:600;border-bottom:1px solid var(--kenar)"><?= htmlspecialchars($paket[$alan[1]] ?? '—') ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <!-- Üretim Bilgileri -->
  <div class="kart" style="padding:14px">
    <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t);border-bottom:2px solid #7C3AED;padding-bottom:6px">
      🏭 Üretim ve Giriş Bilgileri
    </div>
    <table style="width:100%;font-size:12px;border-collapse:collapse">
      <?php
      $uretim_alanlar = [
        ['Üretim Emri No',   'URETIM_EMRI_NO'],
        ['Üretim Tarihi',    'URETIM_TARIHI'],
        ['Çalışan',          'CALISAN'],
        ['Fiş No',           'FIS_NO'],
        ['Logo Üretim Fiş',  'URETIM_FIS_NO_LOGO'],
        ['Sarf Fiş No',      'SARF_FIS_NO'],
        ['Sarf Tarihi',      'SARF_TARIHI'],
        ['Sarf Malzeme',     'SARF_MALZEME_KODU'],
        ['Sarf Malzeme Adı', 'SARF_MALZEME_ADI'],
        ['Sarf Miktarı',     'SARF_MIKTARI'],
        ['Lot No',           'LOT_NO'],
        ['Sarf Lot No',      'SARF_LOT_NO'],
      ];
      foreach ($uretim_alanlar as $alan): ?>
      <tr>
        <td style="padding:5px 8px;color:var(--m2);width:42%;border-bottom:1px solid var(--kenar)"><?= $alan[0] ?></td>
        <td style="padding:5px 8px;font-weight:600;border-bottom:1px solid var(--kenar)"><?= htmlspecialchars($paket[$alan[1]] ?? '—') ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

</div><!-- /iz-grid -->

<!-- Satınalma Giriş Bilgileri -->
<?php if (!empty($paket['GIRIS_FISI_NO']) || !empty($paket['GIRIS_FIS_TARIHI'])): ?>
<div class="kart" style="padding:14px;margin-bottom:14px">
  <div style="font-weight:800;font-size:13px;margin-bottom:12px;color:var(--t);border-bottom:2px solid #0F766E;padding-bottom:6px">
    🛒 Satınalma Giriş Bilgileri (Hammadde)
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
    <?php foreach ([
      ['Giriş Fiş Tarihi',  'GIRIS_FIS_TARIHI'],
      ['Giriş Fiş No',      'GIRIS_FISI_NO'],
      ['Fiş Türü',          'FIS_TURU'],
      ['Tedarikçi',         'Tedarikci_Tanimi'],
      ['Satınalma Miktarı', 'Satinalma_Miktari'],
      ['Birim Fiyat',       'Birim_Fiyat'],
      ['Toplam Tutar',      'Toplam_Tutar'],
      ['İrsaliye Lot No',   'IRSALIYE_LOT_NO'],
    ] as $alan): ?>
    <div style="background:var(--kenar-a);border-radius:8px;padding:8px 12px">
      <div style="font-size:10px;color:var(--m2)"><?= $alan[0] ?></div>
      <div style="font-weight:700;font-size:13px;color:var(--t)"><?= htmlspecialchars($paket[$alan[1]] ?? '—') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Tüm sütunlar tablosu (ham veri) -->
<div class="kart" style="padding:0;overflow:hidden">
  <div style="padding:12px 16px;border-bottom:1px solid var(--kenar);font-weight:800;font-size:13px;color:var(--t)">
    📋 Tüm Kolon Verileri (<?= count($sonuclar) ?> satır)
  </div>
  <div style="overflow-x:auto">
  <table id="tblIzlenebilir" style="width:100%">
    <thead>
      <tr>
        <?php foreach (array_keys($sonuclar[0]) as $col): ?>
        <th><?= htmlspecialchars($col) ?></th>
        <?php endforeach; ?>
      </tr>
    </thead>
    <tfoot>
      <tr>
        <?php foreach (array_keys($sonuclar[0]) as $col): ?>
        <th><?= htmlspecialchars($col) ?></th>
        <?php endforeach; ?>
      </tr>
    </tfoot>
    <tbody>
      <?php foreach ($sonuclar as $row): ?>
      <tr>
        <?php foreach ($row as $v): ?>
        <td><?= htmlspecialchars($v ?? '') ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<?php elseif (!$paket_no): ?>
<!-- Başlangıç ekranı -->
<div class="kart" style="padding:40px;text-align:center;color:var(--m3)">
  <div style="font-size:48px;margin-bottom:14px">🔎</div>
  <div style="font-size:16px;font-weight:700;color:var(--m)">Paket numarası girerek izlenebilirlik sorgulayın</div>
  <div style="font-size:12px;margin-top:6px">Paket üretimden hammaddeye kadar tüm izini görebilirsiniz</div>
</div>
<?php endif; ?>

<?php endif; // mes_ok ?>
</div><!-- /s-body -->

<style>
@media(max-width:700px){ .iz-grid{grid-template-columns:1fr!important} }
#tblIzlenebilir thead th, #tblIzlenebilir tfoot th {
    background:#1E3A5F;color:#fff;padding:8px 12px;font-size:11px;font-weight:700;
    white-space:nowrap;border-right:1px solid #2D4E7A
}
#tblIzlenebilir tbody td { padding:6px 12px;border-bottom:1px solid var(--kenar);font-size:12px }
#tblIzlenebilir tfoot select { width:100%;font-size:10px;padding:2px 4px;border:1px solid var(--kenar);border-radius:4px;background:var(--kart-bg) }
</style>

<script>
$(document).ready(function(){
    <?php if(!empty($sonuclar)): ?>
    $('#tblIzlenebilir').DataTable({
        initComplete: function(){
            this.api().columns().every(function(){
                var col=this, sel=$('<select><option value=""></option></select>').appendTo($(col.footer()).empty())
                    .on('change',function(){ var v=$.fn.dataTable.util.escapeRegex($(this).val()); col.search(v?'^'+v+'$':'',true,false).draw(); });
                col.data().unique().sort().each(function(d){ var v=$('<div/>').html(d).text(); sel.append('<option value="'+v+'">'+(v.length>25?v.substr(0,25)+'...':v)+'</option>'); });
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true, scrollY:'380px', paging:false, scrollX:true,
        dom:'Bfrtip',
        buttons:[
            {extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Izlenebilirlik_<?= addslashes($paket_no) ?>_<?= date("Ymd") ?>'},
            {extend:'print',text:'🖨️ Yazdır'}
        ]
    });
    <?php endif; ?>
});
</script>
