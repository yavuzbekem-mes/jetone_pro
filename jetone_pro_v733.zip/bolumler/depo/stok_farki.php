<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$tiger_ok  = ($tigerdb_pdo !== null);
$stok_kodu = trim($_POST['stok_kodu'] ?? '');
$results1  = $results2 = [];
$hata      = '';

if ($tiger_ok && $stok_kodu !== '') {
    try {
        $like = '%' . $stok_kodu . '%';

        // Tablo 1: Logo vs MES genel karşılaştırma
        $sql1 = "SELECT
            T1.STOK_KODU, T1.STOK_ADI,
            CASE T1.AMBAR_NO
                WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                WHEN 3 THEN 'KIRMA'  WHEN 4 THEN 'EMANET'  WHEN 5 THEN 'BSH'
                WHEN 98 THEN 'TAKIM BOZ' ELSE CAST(T1.AMBAR_NO AS VARCHAR) END AS AMBAR,
            T1.LOGO_STOK_MIKTARI,
            ISNULL(T2.MES_STOK_MIKTARI, 0) AS MES_STOK_MIKTARI,
            T1.LOGO_STOK_MIKTARI - ISNULL(T2.MES_STOK_MIKTARI, 0) AS FARK
        FROM (
            SELECT IT.CODE STOK_KODU, IT.NAME STOK_ADI, STV.INVENNO AMBAR_NO,
                SUM(STV.ONHAND) LOGO_STOK_MIKTARI
            FROM LV_222_02_STINVTOT STV
            LEFT JOIN LG_222_ITEMS IT ON STV.STOCKREF=IT.LOGICALREF
            WHERE STV.INVENNO<>-1 AND IT.CODE LIKE ?
            GROUP BY IT.CODE, IT.NAME, STV.INVENNO
        ) T1
        LEFT JOIN (
            SELECT STOK_KODU, AMBAR, SUM(MIKTAR) MES_STOK_MIKTARI
            FROM MES..PAKETLER WHERE AKTIF=0 AND STOK_KODU LIKE ?
            GROUP BY STOK_KODU, AMBAR
        ) T2 ON T1.STOK_KODU=T2.STOK_KODU AND T1.AMBAR_NO=T2.AMBAR";

        $st1 = $tigerdb_pdo->prepare($sql1);
        $st1->execute([$like, $like]);
        $results1 = $st1->fetchAll(PDO::FETCH_ASSOC);

        // Tablo 2: Paket detay
        $sql2 = "SELECT IT.CODE STOK_KODU, IT.NAME STOK_ADI,
                CASE STV.INVENNO
                    WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                    WHEN 3 THEN 'KIRMA'  WHEN 4 THEN 'EMANET'  WHEN 5 THEN 'BSH'
                    WHEN 98 THEN 'TAKIM BOZ' ELSE CAST(STV.INVENNO AS VARCHAR) END AMBAR,
                SUM(STV.ONHAND) LOGO_MIKTAR, 0 MES_MIKTAR, '' PAKET_NO, '' RAF_YERİ
            FROM LV_222_02_STINVTOT STV
            LEFT JOIN LG_222_ITEMS IT ON STV.STOCKREF=IT.LOGICALREF
            WHERE STV.INVENNO<>-1 AND IT.CODE LIKE ?
            GROUP BY IT.CODE, IT.NAME, STV.INVENNO
            UNION ALL
            SELECT P.STOK_KODU, P.STOK_ADI,
                CASE P.AMBAR
                    WHEN 0 THEN 'MERKEZ' WHEN 1 THEN 'ÜRETİM' WHEN 2 THEN 'KARANTİNA'
                    WHEN 3 THEN 'KIRMA'  WHEN 4 THEN 'EMANET'  WHEN 5 THEN 'BSH'
                    WHEN 98 THEN 'TAKIM BOZ' ELSE CAST(P.AMBAR AS VARCHAR) END AMBAR,
                0 LOGO_MIKTAR, P.MIKTAR MES_MIKTAR, P.PAKET_NO, ISNULL(P.STOK_YERI,'') RAF_YERİ
            FROM MES..PAKETLER P
            WHERE P.AKTIF=0 AND P.STOK_KODU LIKE ?
            ORDER BY STOK_KODU, AMBAR, PAKET_NO";

        $st2 = $tigerdb_pdo->prepare($sql2);
        $st2->execute([$like, $like]);
        $results2 = $st2->fetchAll(PDO::FETCH_ASSOC);

    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblFark1 th, #tblFark2 th { background:#1E3A5F !important; color:#fff !important; }
#tblFark1 td, #tblFark1 th,
#tblFark2 td, #tblFark2 th { border:1px solid #000 !important; white-space:nowrap !important; }
.renk-esit    { background:#D1FAE5 !important; }
.renk-logo    { background:#FEF9C3 !important; }
.renk-mes     { background:#FED7AA !important; }
.renk-tek     { background:#FEE2E2 !important; }
.renk-fark    { background:#DBEAFE !important; }
</style>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚖️ Logo — MES Stok Farkı</h1>
    <div class="s-yol">Depo / <b>Stok Karşılaştırma</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if($hata):?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div>
<?php endif;?>

<!-- Arama formu -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
    <div style="flex:1;min-width:220px">
      <label class="form-etiket">Stok Kodu (LIKE araması)</label>
      <input type="text" name="stok_kodu" class="form-alan"
        value="<?php echo htmlspecialchars($stok_kodu);?>"
        placeholder="Ör: 2988 veya TEKMELIK..." autofocus>
    </div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 20px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Ara</button>
    <?php if($stok_kodu!==''):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-stok-farki" style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
    <?php endif;?>
  </form>
</div>

<!-- Renk açıklama -->
<?php if(!empty($results1)):?>
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;font-size:11px">
  <span style="background:#D1FAE5;padding:3px 10px;border-radius:6px;font-weight:600">🟢 Eşit</span>
  <span style="background:#FEF9C3;padding:3px 10px;border-radius:6px;font-weight:600">🟡 Logo > MES</span>
  <span style="background:#FED7AA;padding:3px 10px;border-radius:6px;font-weight:600">🟠 Logo < MES</span>
  <span style="background:#FEE2E2;padding:3px 10px;border-radius:6px;font-weight:600">🔴 Sadece birinde var</span>
</div>

<!-- TABLO 1: Genel Karşılaştırma -->
<div style="font-weight:700;font-size:12px;color:#1E3A5F;margin-bottom:6px">📊 Genel Stok Karşılaştırması</div>
<div class="kart" style="overflow:hidden;padding:0;margin-bottom:14px">
<div style="overflow-x:auto">
<table id="tblFark1" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th>
    <th style="text-align:right">Logo Miktar</th>
    <th style="text-align:right">MES Miktar</th>
    <th style="text-align:right">Fark</th>
  </tr></thead>
  <tfoot><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th>
    <th>Logo Miktar</th><th>MES Miktar</th><th>Fark</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($results1 as $r):
    $logo  = (float)($r['LOGO_STOK_MIKTARI']??0);
    $mes   = (float)($r['MES_STOK_MIKTARI']??0);
    $fark  = (float)($r['FARK']??0);
    if (($logo==0&&$mes>0)||($logo>0&&$mes==0)) $rc='renk-tek';
    elseif ($logo==$mes)  $rc='renk-esit';
    elseif ($logo>$mes)   $rc='renk-logo';
    else                  $rc='renk-mes';
  ?>
  <tr class="<?php echo $rc;?>">
    <td><code style="background:rgba(255,255,255,.6);padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($r['AMBAR']??'');?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format($logo,0,'','.');?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format($mes,0,'','.');?></td>
    <td style="text-align:right;font-weight:900;color:<?php echo $fark==0?'#16A34A':($fark>0?'#D97706':'#DC2626');?>">
      <?php echo ($fark>0?'+':'').number_format($fark,0,'','.');?>
    </td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>

<!-- TABLO 2: Paket Detay -->
<div style="font-weight:700;font-size:12px;color:#1E3A5F;margin-bottom:6px">📦 Paket Detayları</div>
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblFark2" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th>
    <th style="text-align:right">Logo Miktar</th>
    <th style="text-align:right">MES Miktar</th>
    <th>Paket No</th><th>Raf Yeri</th>
  </tr></thead>
  <tfoot><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th>
    <th>Logo</th><th>MES</th><th>Paket No</th><th>Raf</th>
  </tr></tfoot>
  <tbody>
  <?php foreach($results2 as $r):
    $logo_m = (float)($r['LOGO_MIKTAR']??0);
    $mes_m  = (float)($r['MES_MIKTAR']??0);
    $bg     = $logo_m>0?'':'background:#F0FDF4'; // MES satırları hafif yeşil
  ?>
  <tr style="<?php echo $bg;?>">
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td style="font-weight:600"><?php echo htmlspecialchars($r['AMBAR']??'');?></td>
    <td style="text-align:right;font-weight:<?php echo $logo_m>0?'700':'400';?>;color:<?php echo $logo_m>0?'#1D4ED8':'#94A3B8';?>">
      <?php echo $logo_m>0?number_format($logo_m,0,'','.'):'-';?></td>
    <td style="text-align:right;font-weight:<?php echo $mes_m>0?'700':'400';?>;color:<?php echo $mes_m>0?'#16A34A':'#94A3B8';?>">
      <?php echo $mes_m>0?number_format($mes_m,0,'','.'):'-';?></td>
    <td style="color:#0369A1;font-weight:600"><?php echo htmlspecialchars($r['PAKET_NO']??'');?></td>
    <td style="color:#7C3AED;font-size:11px"><?php echo htmlspecialchars($r['RAF_YERİ']??'');?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
</div>
<?php elseif($stok_kodu!==''&&!$hata):?>
<div style="background:#F1F5F9;padding:30px;text-align:center;color:#888;border-radius:8px">
  <div style="font-size:32px;margin-bottom:8px">🔍</div>
  "<?php echo htmlspecialchars($stok_kodu);?>" için sonuç bulunamadı.
</div>
<?php elseif(!$tiger_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div>
<?php else:?>
<div style="background:#F1F5F9;padding:40px;text-align:center;color:#94A3B8;border-radius:10px">
  <div style="font-size:40px;margin-bottom:10px">⚖️</div>
  <div style="font-weight:600">Stok kodu girerek Logo ve MES stok miktarlarını karşılaştırın.</div>
  <div style="font-size:11px;margin-top:4px">LIKE araması — kısmi eşleşme desteklenir</div>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
    <?php if(!empty($results1)):?>
    $('#tblFark1').DataTable({
        initComplete:function(){
            this.api().columns([0,2]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'400px',paging:false,scrollX:true,
        order:[[5,'asc']],
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Stok_Farki',
            exportOptions:{format:{body:function(data,r,c,node){var clean=$('<div/>').html(data).text().trim();clean=clean.replace(/\+/g,'').replace(/\./g,'').replace(/,/g,'.');var num=parseFloat(clean);return isNaN(num)?$('<div/>').html(data).text().trim():num;}}}
        },'print']
    });
    $('#tblFark2').DataTable({
        initComplete:function(){
            this.api().columns([0,2,5,6]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'400px',paging:false,scrollX:true,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Paket_Detay'},'print']
    });
    <?php endif;?>
});
</script>
