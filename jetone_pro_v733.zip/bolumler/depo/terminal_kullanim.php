<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$tiger_ok = ($tigerdb_pdo !== null);
$sonuclar = []; $hata = '';
$gunler = [];
for ($i=0;$i<=14;$i++) $gunler[] = date('Y-m-d',strtotime("-$i days"));
if ($tiger_ok) {
    try {
        $case_parts = [];
        foreach ($gunler as $gun) {
            $label = date('d.m.Y',strtotime($gun));
            $case_parts[] = "COUNT(DISTINCT CASE WHEN CAST(FIS_TARIHI AS DATE)='$gun' THEN FIS_NO END) AS [$label]";
        }
        $sql = "SELECT EKLEYEN_KISI, ".implode(',',$case_parts).",
            COUNT(DISTINCT CASE WHEN CAST(FIS_TARIHI AS DATE)>=CAST(DATEADD(DAY,-30,GETDATE()) AS DATE) THEN FIS_NO END) AS [Son 30 Gün]
            FROM MES_PAKET_HAREKETLERI_RAPORU
            WHERE FIS_TARIHI>=DATEADD(DAY,-30,GETDATE())
            GROUP BY EKLEYEN_KISI ORDER BY EKLEYEN_KISI";
        $sonuclar = $tigerdb_pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblTerminal th { background:#1E3A5F !important; color:#fff !important; }
#tblTerminal td, #tblTerminal th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>
<div class="s-bar">
  <div><h1 class="s-bas">📟 Terminal Kullanım Oranı</h1>
    <div class="s-yol">Depo / <b>Kullanıcı Bazlı Terminal Aktivite</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>
<?php if($hata):?><div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div><?php endif;?>
<?php if(!$tiger_ok):?><div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ Tiger DB bağlantısı yok.</div><?php else:?>
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblTerminal" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <?php if(!empty($sonuclar)): foreach(array_keys($sonuclar[0]) as $col):?>
    <th><?php echo htmlspecialchars($col);?></th>
    <?php endforeach; endif;?>
  </tr></thead>
  <tfoot><tr>
    <?php if(!empty($sonuclar)): foreach(array_keys($sonuclar[0]) as $col):?>
    <th><?php echo htmlspecialchars($col);?></th>
    <?php endforeach; endif;?>
  </tr></tfoot>
  <tbody>
  <?php if(empty($sonuclar)):?>
  <tr><td colspan="20" style="text-align:center;padding:30px;color:#888">Veri bulunamadı.</td></tr>
  <?php else: foreach($sonuclar as $r):?>
  <tr>
    <?php $first=true; foreach($r as $key=>$val):
      $style = $first?'font-weight:700':'text-align:center;color:'.((int)$val>0?'#1D4ED8':'#94A3B8').';font-weight:'.((int)$val>0?'700':'400');
    ?>
    <td style="<?php echo $style;?>"><?php echo htmlspecialchars($val??'0');?></td>
    <?php $first=false; endforeach;?>
  </tr>
  <?php endforeach; endif;?>
  </tbody>
</table>
</div>
</div>
<script>
$(document).ready(function(){
    $('#tblTerminal').DataTable({
        initComplete:function(){
            this.api().columns([0]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Terminal_Kullanim'},'print']
    });
});
</script>
<?php endif;?>
