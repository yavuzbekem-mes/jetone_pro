<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

// AJAX isteği
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['stok_kodu']) && !isset($_POST['_sayfa'])) {
    header('Content-Type: application/json; charset=utf-8');
    $stok = trim($_POST['stok_kodu']??'');
    if (!$stok) { echo json_encode(['ok'=>false,'msg'=>'Stok kodu boş olamaz.']); exit; }
    if (!$mes_pdo) { echo json_encode(['ok'=>false,'msg'=>'MES DB bağlantısı yok.']); exit; }
    try {
        $st = $mes_pdo->prepare("UPDATE MES.dbo.PAKETLER SET AKTIF=1 WHERE STOK_KODU=? AND AKTIF=0");
        $st->execute([$stok]);
        $cnt = $st->rowCount();
        if ($cnt > 0) echo json_encode(['ok'=>true,'msg'=>"$cnt adet aktif paket pasif yapıldı.",'sayi'=>$cnt]);
        else          echo json_encode(['ok'=>false,'msg'=>'Bu stok koduna ait aktif paket bulunamadı.']);
    } catch(Throwable $e) {
        echo json_encode(['ok'=>false,'msg'=>'Hata: '.$e->getMessage()]);
    }
    exit;
}

$mes_ok = ($mes_pdo !== null);
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🔇 Aktif Paketleri Pasif Et</h1>
    <div class="s-yol">Depo / Sayım / <b>Paket Pasif İşlemi</b>
      <?php if($mes_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● MES DB</span>
      <?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● MES DB Yok</span><?php endif;?>
    </div>
  </div>
</div>

<?php if(!$mes_ok):?>
<div style="background:#FEE2E2;color:#991B1B;padding:14px;border-radius:10px">⚠️ MES veritabanı bağlantısı kurulamadı.</div>
<?php else:?>

<div class="kart" style="max-width:520px;padding:20px">
  <div style="font-size:13px;font-weight:700;color:#1E3A5F;margin-bottom:14px">📋 Paket Pasif İşlemi</div>

  <div style="background:#FEF9C3;border:1px solid #FDE68A;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:12px;color:#92400E">
    ⚠️ Bu işlem, girilen stok koduna ait <strong>tüm aktif paketleri</strong> pasif (AKTIF=1) yapacaktır.
    Sayım başlatmadan önce çalıştırın.
  </div>

  <div id="pasifMesaj" style="display:none;margin-bottom:12px"></div>

  <div style="display:flex;gap:10px;align-items:flex-end">
    <div style="flex:1">
      <label class="form-etiket">Stok Kodu *</label>
      <input type="text" id="pasifStokKodu" class="form-alan" placeholder="Ör: 2988080600" autofocus
        style="text-transform:uppercase">
    </div>
    <button id="pasifBtn" onclick="paketPasifEt()"
      style="background:#DC2626;color:#fff;border:none;padding:9px 18px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap">
      🔇 Pasif Et
    </button>
  </div>
  <div style="margin-top:8px;font-size:11px;color:#64748B">
    Tüm ambarlardaki aktif paketler pasife alınır. Bu işlem geri alınamaz.
  </div>
</div>

<div class="kart" style="max-width:520px;padding:16px;margin-top:12px">
  <div style="font-size:12px;font-weight:700;color:#1E3A5F;margin-bottom:10px">📊 Son Pasif İşlemleri</div>
  <div id="sonIslemler" style="font-size:12px;color:#64748B;font-style:italic">
    Henüz işlem yapılmadı.
  </div>
</div>

<script>
var _islemGecmis = [];
function paketPasifEt() {
    var kod = document.getElementById('pasifStokKodu').value.trim().toUpperCase();
    if (!kod) { alert('Stok kodu giriniz.'); return; }
    if (!confirm('⚠️ "' + kod + '" stok koduna ait TÜM aktif paketler pasif yapılacak.\n\nDevam etmek istiyor musunuz?')) return;

    var btn = document.getElementById('pasifBtn');
    btn.disabled = true; btn.textContent = '⏳ İşleniyor...';
    document.getElementById('pasifMesaj').style.display = 'none';

    fetch('<?php echo BASE_URL;?>/panel.php?sayfa=depo-paket-pasif', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'stok_kodu=' + encodeURIComponent(kod)
    })
    .then(r => r.json())
    .then(d => {
        btn.disabled = false; btn.textContent = '🔇 Pasif Et';
        var mesaj = document.getElementById('pasifMesaj');
        mesaj.style.display = 'block';
        if (d.ok) {
            mesaj.innerHTML = '<div style="background:#D1FAE5;color:#065F46;padding:10px 14px;border-radius:8px;font-weight:700">✅ ' + d.msg + '</div>';
            document.getElementById('pasifStokKodu').value = '';
            _islemGecmis.unshift({kod: kod, msg: d.msg, zaman: new Date().toLocaleTimeString('tr-TR')});
            renderGecmis();
        } else {
            mesaj.innerHTML = '<div style="background:#FEF9C3;color:#92400E;padding:10px 14px;border-radius:8px;font-weight:600">⚠️ ' + d.msg + '</div>';
        }
        document.getElementById('pasifStokKodu').focus();
    })
    .catch(e => {
        btn.disabled = false; btn.textContent = '🔇 Pasif Et';
        alert('Bağlantı hatası: ' + e);
    });
}
function renderGecmis() {
    var el = document.getElementById('sonIslemler');
    if (!_islemGecmis.length) { el.innerHTML = '<span style="font-style:italic">Henüz işlem yok.</span>'; return; }
    el.innerHTML = _islemGecmis.slice(0,5).map(function(i){
        return '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #F1F5F9">'
            + '<span><code style="background:#FEE2E2;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700">'+i.kod+'</code> — '+i.msg+'</span>'
            + '<span style="color:#94A3B8;font-size:10px">'+i.zaman+'</span></div>';
    }).join('');
}
document.getElementById('pasifStokKodu').addEventListener('keydown', function(e){
    if(e.key==='Enter') paketPasifEt();
});
</script>
<?php endif;?>
