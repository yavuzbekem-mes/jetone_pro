<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();

$bugun = date('Y-m-d');
$siparisler = [];
try {
    $siparisler = $db->query("SELECT * FROM siparis WHERE sip_statu='Aktif' ORDER BY sip_teslim_tarihi ASC, musteri_firma_adi ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}

$stoklar = [];
if ($tigerdb_pdo) { try {
    $rows = $tigerdb_pdo->query("SELECT IT.CODE k, ISNULL(SUM(CASE WHEN LV.INVENNO IN(0,1,5) THEN LV.ONHAND ELSE 0 END),0) s
        FROM dbo.LG_222_ITEMS IT WITH(NOLOCK)
        LEFT JOIN dbo.LV_222_02_STINVTOT LV WITH(NOLOCK) ON LV.STOCKREF=IT.LOGICALREF
        WHERE IT.CARDTYPE NOT IN(4,22) AND IT.CANCONFIGURE=0 GROUP BY IT.CODE")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r) $stoklar[$r['k']] = (float)$r['s'];
} catch(Throwable $e) {} }

$rezervasyon = $stoklar;
foreach($siparisler as $sip) {
    $k = floatval($sip['sip_miktar']) - floatval($sip['sip_sevk_miktari']);
    if (!isset($rezervasyon[$sip['sip_kodu']])) $rezervasyon[$sip['sip_kodu']] = 0;
    $rezervasyon[$sip['sip_kodu']] -= $k;
}
?>
<style>
#tblDepSip th { background:#1E3A5F !important; color:#fff !important; }
#tblDepSip td, #tblDepSip th { border:1px solid #000 !important; white-space:nowrap !important; }
.gecmis-bg { background:#FFF1F2 !important; }
.acil-bg { background:#FFF7ED !important; }
.bugun-bg { background:#FFFBEB !important; }
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:6px">
  <div style="min-width:0;flex:1">
    <h1 class="s-bas">🛒 Sipariş Listesi</h1>
    <div class="s-yol">Depo / <b>Aktif Siparişler</b>
      <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo count($siparisler);?> kayıt</span>
    </div>
  </div>
</div>

<?php if(empty($siparisler)):?>
<div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:24px;text-align:center;color:var(--m2)">Aktif sipariş bulunamadı.</div>
<?php else:?>
<div class="kart" style="overflow:hidden;padding:0">
<table id="tblDepSip" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>#</th>
    <th>Stok Kodu</th>
    <th>Ürün Adı</th>
    <th>Sipariş No</th>
    <th>Teslim Tarihi</th>
    <th style="text-align:right">Sipariş Mik.</th>
    <th>Son İrs. No</th>
    <th style="text-align:right">Sevk</th>
    <th style="text-align:right">Kalan</th>
    <th>Firma</th>
    <th>Aciliyet</th>
    <th>Durum</th>
    <th>Gecikme Açık.</th>
    <th style="text-align:right">Stok</th>
    <th style="text-align:right">Rezerv.</th>
  </tr></thead>
  <tfoot><tr>
    <th>#</th><th>Stok Kodu</th><th>Ürün Adı</th><th>Sipariş No</th>
    <th>Teslim Tarihi</th><th>Sipariş</th><th>Son İrs.</th>
    <th>Sevk</th><th>Kalan</th><th>Firma</th><th>Aciliyet</th>
    <th>Durum</th><th>Gecikme Açık.</th><th>Stok</th><th>Rezerv.</th>
  </tr></tfoot>
  <tbody>
  <?php $say=0; foreach($siparisler as $sip):
    $say++;
    $kod   = $sip['sip_kodu'];
    $mik   = floatval($sip['sip_miktar']);
    $sevk  = floatval($sip['sip_sevk_miktari']);
    $kalan = $mik - $sevk;
    $stok  = $stoklar[$kod] ?? 0;
    $rezv  = $rezervasyon[$kod] ?? 0;
    $t     = $sip['sip_teslim_tarihi'] ?? '';
    $gecmis = $t && $t < $bugun && $kalan > 0;
    $acil   = $sip['sip_aciliyet'] === 'Acil';
    $bg     = $gecmis ? 'gecmis-bg' : ($acil ? 'acil-bg' : ($t===$bugun ? 'bugun-bg' : ''));
  ?>
  <tr class="<?php echo $bg;?>">
    <td style="color:#94A3B8;font-size:11px;text-align:center"><?php echo $say;?></td>
    <td><code style="background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700"><?php echo htmlspecialchars($kod);?></code></td>
    <td><?php echo htmlspecialchars($sip['sip_baslik']??'');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['sip_no']??'');?></td>
    <td style="font-weight:<?php echo $gecmis?'700':'400';?>;color:<?php echo $gecmis?'#DC2626':($t===$bugun?'#D97706':'inherit');?>"
        data-order="<?php echo $t;?>"><?php echo $t?date('d.m.Y',strtotime($t)):'-';?></td>
    <td style="text-align:right;font-weight:600"><?php echo number_format($mik,0,',','.');?></td>
    <td style="font-size:11px"><?php echo htmlspecialchars($sip['son_irsaliye_no']??'');?></td>
    <td style="text-align:right"><?php echo number_format($sevk,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $kalan>0?'#DC2626':'#059669';?>"><?php echo number_format($kalan,0,',','.');?></td>
    <td style="font-size:12px"><?php echo htmlspecialchars($sip['musteri_firma_adi']??'');?></td>
    <td><?php if($acil):?><span style="background:#FEE2E2;color:#DC2626;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:700">🔴 Acil</span><?php else:?><span style="font-size:11px;color:#94A3B8"><?php echo htmlspecialchars($sip['sip_aciliyet']??'');?></span><?php endif;?></td>
    <td><span style="background:#F1F5F9;padding:2px 6px;border-radius:4px;font-size:10px"><?php echo htmlspecialchars($sip['sip_durum']??'');?></span></td>
    <td style="font-size:11px;color:#64748B;max-width:200px;white-space:normal"><?php echo htmlspecialchars($sip['gecikme_nedeni']??'');?></td>
    <td style="text-align:right;font-size:12px;color:#64748B"><?php echo number_format($stok,0,',','.');?></td>
    <td style="text-align:right;font-weight:700;color:<?php echo $rezv<0?'#DC2626':'#059669';?>"><?php echo number_format($rezv,0,',','.');?></td>
  </tr>
  <?php endforeach;?>
  </tbody>
</table>
</div>
<?php endif;?>

<script>
$(document).ready(function(){
    if(!$('#tblDepSip tbody tr').length) return;
    $('#tblDepSip').DataTable({
        initComplete: function(){
            this.api().columns([1,3,5,9,10,11]).every(function(){
                var col=this,th=$(col.footer());if(!th||!th.length)return;
                var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                    .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
            });
        },
        language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
        paging:false, scrollX:true, scrollY:'calc(100vh - 260px)', scrollCollapse:true,
        order:[[4,'asc']],
        dom:'Bfrtip',
        buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Siparis_Listesi',
            exportOptions:{format:{body:function(d,r,c,node){var clean=$('<div/>').html(d).text().trim();clean=clean.replace(/\./g,'').replace(/,/g,'.');var n=parseFloat(clean);return isNaN(n)?$('<div/>').html(d).text().trim():n;}}}
        },'print']
    });
});
</script>
