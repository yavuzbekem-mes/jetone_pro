<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$mes_ok = ($mes_pdo !== null);
?>
<style>
/* ── Terminal / Mobil Layout ────────────────────── */
.ps-wrap {
    max-width: 520px;
    margin: 0 auto;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
.ps-header {
    background: #1E3A5F;
    color: #fff;
    border-radius: 12px;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;
}
.ps-header-title { font-size: 16px; font-weight: 800; }
.ps-header-sub   { font-size: 11px; opacity: .75; margin-top: 2px; }
.ps-stat-row {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 8px;
    margin-bottom: 12px;
}
.ps-stat {
    background: #fff;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    padding: 10px;
    text-align: center;
}
.ps-stat .v { font-size: 26px; font-weight: 900; color: #1E3A5F; line-height: 1; }
.ps-stat .l { font-size: 10px; font-weight: 700; color: #64748B; margin-top: 3px; text-transform: uppercase; letter-spacing: .4px; }
.ps-stat.hata .v { color: #DC2626; }
.ps-card {
    background: #fff;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 10px;
}
.ps-card-title {
    font-size: 11px;
    font-weight: 700;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: .6px;
    margin-bottom: 10px;
}
.ps-field { margin-bottom: 10px; }
.ps-field label {
    display: block;
    font-size: 11px;
    font-weight: 700;
    color: #374151;
    margin-bottom: 5px;
    text-transform: uppercase;
    letter-spacing: .4px;
}
.ps-field select, .ps-field input {
    width: 100%;
    border: 2px solid #E2E8F0;
    border-radius: 8px;
    padding: 12px 14px;
    font-size: 15px;
    font-weight: 600;
    outline: none;
    transition: border-color .15s, box-shadow .15s;
    background: #fff;
    -webkit-appearance: none;
    box-sizing: border-box;
}
.ps-field select:focus, .ps-field input:focus {
    border-color: #1E3A5F;
    box-shadow: 0 0 0 3px rgba(30,58,95,.12);
}
.ps-input-paket {
    border-color: #1E3A5F !important;
    font-size: 18px !important;
    font-weight: 700 !important;
    text-align: center;
    letter-spacing: 1px;
}
.ps-input-paket::placeholder { color: #CBD5E1; font-weight: 400; font-size: 14px; letter-spacing: 0; }
.ps-msg {
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 13px;
    font-weight: 700;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
    animation: psFadeIn .2s ease;
}
@keyframes psFadeIn { from{opacity:0;transform:translateY(-4px)} to{opacity:1;transform:translateY(0)} }
.ps-msg.ok  { background: #D1FAE5; color: #065F46; border: 1px solid #86EFAC; }
.ps-msg.err { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
.ps-msg.warn{ background: #FEF9C3; color: #854D0E; border: 1px solid #FDE68A; }
.ps-btn-row { display: flex; gap: 8px; margin-top: 12px; }
.ps-btn {
    flex: 1;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: opacity .15s;
}
.ps-btn:active { opacity: .8; }
.ps-btn.primary   { background: #1E3A5F; color: #fff; }
.ps-btn.danger    { background: #DC2626; color: #fff; }
.ps-btn.success   { background: #16A34A; color: #fff; }
.ps-btn.secondary { background: #F1F5F9; border: 1px solid #E2E8F0; color: #374151; }
/* Liste */
.ps-liste {
    background: #fff;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    overflow: hidden;
    margin-top: 12px;
}
.ps-liste-header {
    background: #1E3A5F;
    color: #fff;
    padding: 10px 14px;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.ps-liste-item {
    display: flex;
    align-items: center;
    padding: 10px 14px;
    border-bottom: 1px solid #F1F5F9;
    gap: 10px;
    transition: background .1s;
}
.ps-liste-item:last-child { border-bottom: none; }
.ps-liste-item:active { background: #F8FAFC; }
.ps-liste-sira {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #EFF6FF;
    color: #1D4ED8;
    font-size: 10px;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
.ps-liste-bilgi { flex: 1; min-width: 0; }
.ps-liste-paket { font-size: 12px; font-weight: 800; color: #1E3A5F; }
.ps-liste-kod   { font-size: 11px; color: #64748B; margin-top: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ps-liste-sag   { text-align: right; flex-shrink: 0; }
.ps-liste-miktar{ font-size: 16px; font-weight: 900; color: #1D4ED8; }
.ps-liste-raf   { font-size: 10px; color: #16A34A; font-weight: 700; }
.ps-liste-sil   {
    width: 28px; height: 28px;
    border-radius: 6px;
    background: #FEE2E2;
    border: none;
    color: #DC2626;
    font-size: 14px;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.ps-bos {
    padding: 40px 20px;
    text-align: center;
    color: #94A3B8;
}
.ps-bos-ikon { font-size: 40px; opacity: .4; margin-bottom: 8px; }
.ps-bos-yazi { font-size: 13px; font-weight: 600; }
.ps-toplam {
    padding: 12px 14px;
    background: #F8FAFC;
    border-top: 2px solid #E2E8F0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.ps-toplam-lbl  { font-size: 12px; font-weight: 700; color: #374151; }
.ps-toplam-val  { font-size: 20px; font-weight: 900; color: #1E3A5F; }
/* Kilitleme göstergesi */
.ps-kilit-badge {
    display: inline-flex; align-items: center; gap: 4px;
    background: rgba(255,255,255,.15);
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
}
.ps-kilit-badge.kilitli  { background: rgba(220,38,38,.3); }
.ps-kilit-badge.acik     { background: rgba(22,163,74,.3); }
@media (max-width: 540px) {
    .ps-wrap { padding: 0 4px; }
    .ps-stat .v { font-size: 22px; }
}
</style>

<div class="ps-wrap">

  <?php if(!$mes_ok): ?>
  <div class="ps-msg err">⚠️ MES veritabanı bağlantısı kurulamadı.</div>
  <?php else: ?>

  <!-- Header -->
  <div class="ps-header">
    <div>
      <div class="ps-header-title">📱 Paket Sayım</div>
      <div class="ps-header-sub">Paket okut → Raf yerleştir</div>
    </div>
    <div id="psKilitBadge" class="ps-kilit-badge acik">🔓 Açık</div>
  </div>

  <!-- İstatistikler -->
  <div class="ps-stat-row">
    <div class="ps-stat">
      <div class="v" id="statPaket">0</div>
      <div class="l">Paket</div>
    </div>
    <div class="ps-stat">
      <div class="v" id="statMiktar">0</div>
      <div class="l">Toplam</div>
    </div>
    <div class="ps-stat hata">
      <div class="v" id="statHata">0</div>
      <div class="l">Hata</div>
    </div>
  </div>

  <!-- Mesaj alanı -->
  <div id="psMesaj" style="display:none"></div>

  <!-- Parametreler kartı -->
  <div class="ps-card">
    <div class="ps-card-title">⚙️ Sayım Parametreleri</div>

    <div class="ps-field">
      <label>Ambar</label>
      <select id="psAmbar">
        <option value="0">0 — Merkez</option>
        <option value="1">1 — Üretim</option>
        <option value="5">5 — BSH</option>
        <option value="4">4 — Kırma</option>
        <option value="3">3 — Karantina</option>
        <option value="2">2 — Emanet</option>
        <option value="98">98 — Takım Boz</option>
      </select>
    </div>

    <div class="ps-field">
      <label>Raf Yeri</label>
      <input type="text" id="psRaf" maxlength="8" placeholder="Ör: A-01-01"
        style="text-transform:uppercase" autocomplete="off">
    </div>

    <div class="ps-field">
      <label>Paket No — Enter ile Okut</label>
      <input type="text" id="psPaket" class="ps-input-paket"
        placeholder="Barkod okutun..." autocomplete="off" autocorrect="off"
        spellcheck="false" inputmode="text">
    </div>
  </div>

  <!-- Butonlar -->
  <div class="ps-btn-row">
    <button class="ps-btn secondary" onclick="psTemizle()">🗑 Temizle</button>
    <button class="ps-btn success" onclick="psExcel()">📊 Excel</button>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-paket-pasif"
       class="ps-btn danger" style="text-decoration:none">🔇 Pasif Et</a>
  </div>

  <!-- Liste -->
  <div class="ps-liste" id="psListe">
    <div class="ps-liste-header">
      <span>📋 Okutulan Paketler</span>
      <span id="psListeSayac" style="background:rgba(255,255,255,.2);padding:2px 8px;border-radius:8px;font-size:11px">0</span>
    </div>
    <div id="psListeBody">
      <div class="ps-bos">
        <div class="ps-bos-ikon">📦</div>
        <div class="ps-bos-yazi">Henüz paket okutulmadı</div>
      </div>
    </div>
    <div class="ps-toplam" id="psToplam" style="display:none">
      <span class="ps-toplam-lbl">TOPLAM MİKTAR</span>
      <span class="ps-toplam-val" id="psTotalMiktar">0</span>
    </div>
  </div>

  <?php endif; ?>
</div><!-- ps-wrap -->

<script>
var _psSatirlar = [];
var _psHata = 0;
var _psIslemde = false;
var AJAX_URL = '<?php echo BASE_URL;?>/bolumler/depo/ajax/paket_sayim_ajax.php';
var AMBAR_ADLARI = {0:'Merkez',1:'Üretim',2:'Karantina',3:'Kırma',4:'Emanet',5:'BSH',98:'Takım Boz'};

function psGuncelle() {
    var toplam = _psSatirlar.reduce(function(s,r){return s+parseFloat(r.miktar||0);},0);
    document.getElementById('statPaket').textContent  = _psSatirlar.length;
    document.getElementById('statMiktar').textContent = toplam.toLocaleString('tr-TR',{maximumFractionDigits:0});
    document.getElementById('statHata').textContent   = _psHata;
    document.getElementById('psListeSayac').textContent = _psSatirlar.length;
    document.getElementById('psTotalMiktar').textContent = toplam.toLocaleString('tr-TR',{maximumFractionDigits:0});
    document.getElementById('psToplam').style.display = _psSatirlar.length ? 'flex' : 'none';
}

function psRenderListe() {
    var body = document.getElementById('psListeBody');
    if (!_psSatirlar.length) {
        body.innerHTML = '<div class="ps-bos"><div class="ps-bos-ikon">📦</div><div class="ps-bos-yazi">Henüz paket okutulmadı</div></div>';
        return;
    }
    body.innerHTML = _psSatirlar.slice().reverse().map(function(r,ri){
        var i = _psSatirlar.length - 1 - ri;
        return '<div class="ps-liste-item">'
          + '<div class="ps-liste-sira">'+(i+1)+'</div>'
          + '<div class="ps-liste-bilgi">'
          +   '<div class="ps-liste-paket">'+esc(r.paket_no)+'</div>'
          +   '<div class="ps-liste-kod">'+esc(r.stok_kodu)+' — '+esc(r.stok_adi||'')+'</div>'
          + '</div>'
          + '<div class="ps-liste-sag">'
          +   '<div class="ps-liste-miktar">'+parseFloat(r.miktar||0).toLocaleString('tr-TR',{maximumFractionDigits:0})+'</div>'
          +   '<div class="ps-liste-raf">📍 '+esc(r.raf_yeri)+'</div>'
          + '</div>'
          + '<button class="ps-liste-sil" onclick="psSil('+i+')" title="Sil">✕</button>'
          + '</div>';
    }).join('');
}

function esc(s) { var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

function psMesaj(msg, tip, sure) {
    var el = document.getElementById('psMesaj');
    el.style.display = 'flex';
    el.innerHTML = '<div class="ps-msg '+tip+'" style="width:100%;margin-bottom:0">'+msg+'</div>';
    clearTimeout(el._t);
    el._t = setTimeout(function(){ el.style.display='none'; }, sure||2500);
}

function psSil(i) {
    _psSatirlar.splice(i,1);
    psRenderListe(); psGuncelle();
}

function psTemizle() {
    if (!_psSatirlar.length || confirm('Listeyi temizlemek istiyor musunuz?')) {
        _psSatirlar=[]; _psHata=0; psRenderListe(); psGuncelle();
    }
}

// Paket okut
document.getElementById('psPaket').addEventListener('keydown', function(e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    var paket_no = this.value.trim();
    if (!paket_no) return;
    if (_psIslemde) return;

    var raf   = document.getElementById('psRaf').value.trim().toUpperCase();
    var ambar = document.getElementById('psAmbar').value;

    if (!raf) {
        psMesaj('⚠️ Önce raf yeri girin!','warn');
        document.getElementById('psRaf').focus();
        return;
    }

    // Tekrar kontrol
    if (_psSatirlar.find(function(r){ return r.paket_no===paket_no; })) {
        psMesaj('⚠️ Bu paket zaten okutulmuş: '+paket_no,'warn');
        this.value=''; return;
    }

    _psIslemde = true;
    var inp = this;
    inp.disabled = true;
    inp.placeholder = '⏳ Kontrol ediliyor...';

    // Kilitle badge
    document.getElementById('psKilitBadge').className = 'ps-kilit-badge kilitli';
    document.getElementById('psKilitBadge').textContent = '🔒 İşleniyor';

    fetch(AJAX_URL, {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'paket_no='+encodeURIComponent(paket_no)+'&ambar='+encodeURIComponent(ambar)+'&raf_yeri='+encodeURIComponent(raf)
    })
    .then(function(r){ return r.json(); })
    .then(function(d) {
        _psIslemde = false;
        inp.disabled = false;
        inp.value = '';
        inp.placeholder = 'Barkod okutun...';
        document.getElementById('psKilitBadge').className = 'ps-kilit-badge acik';
        document.getElementById('psKilitBadge').textContent = '🔓 Açık';

        if (d.ok) {
            _psSatirlar.push(d.data);
            psRenderListe(); psGuncelle();
            psMesaj('✅ '+esc(d.data.paket_no)+' — <b>'+esc(d.data.stok_kodu)+'</b> ('+parseFloat(d.data.miktar).toLocaleString('tr-TR',{maximumFractionDigits:0})+')', 'ok', 2000);
        } else {
            _psHata++; psGuncelle();
            psMesaj('❌ '+esc(d.msg), 'err', 4000);
        }
        inp.focus();
    })
    .catch(function(e) {
        _psIslemde = false;
        inp.disabled = false; inp.value = ''; inp.placeholder='Barkod okutun...';
        document.getElementById('psKilitBadge').className = 'ps-kilit-badge acik';
        document.getElementById('psKilitBadge').textContent = '🔓 Açık';
        _psHata++; psGuncelle();
        psMesaj('❌ Bağlantı hatası', 'err', 4000);
        inp.focus();
    });
});

// RAF büyük harf
document.getElementById('psRaf').addEventListener('input', function(){
    this.value = this.value.toUpperCase();
});

// Excel
function psExcel() {
    if (!_psSatirlar.length) { psMesaj('⚠️ Liste boş.','warn'); return; }
    if (typeof XLSX === 'undefined') { psMesaj('❌ Excel kütüphanesi yüklenemedi.','err'); return; }
    var bas = [['#','Paket No','Stok Kodu','Stok Adı','Miktar','Raf Yeri','Ambar']];
    var rows = _psSatirlar.map(function(r,i){
        return [i+1,r.paket_no,r.stok_kodu,r.stok_adi||'',parseFloat(r.miktar||0),r.raf_yeri,AMBAR_ADLARI[parseInt(r.ambar)]||r.ambar];
    });
    var toplam = _psSatirlar.reduce(function(s,r){return s+parseFloat(r.miktar||0);},0);
    rows.push(['','','','TOPLAM',toplam,'','']);
    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.aoa_to_sheet(bas.concat(rows));
    ws['!cols'] = [{wch:5},{wch:18},{wch:18},{wch:38},{wch:12},{wch:10},{wch:12}];
    XLSX.utils.book_append_sheet(wb, ws, 'Paket Sayım');
    var t = new Date().toISOString().slice(0,16).replace(/[T:]/g,'-');
    XLSX.writeFile(wb, 'Paket_Sayim_'+t+'.xlsx');
}

// Sayfa yüklenince paket inputa odaklan
window.addEventListener('load', function(){
    var el = document.getElementById('psPaket');
    if (el) el.focus();
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
