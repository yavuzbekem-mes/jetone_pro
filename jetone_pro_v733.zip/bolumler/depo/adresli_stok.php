<?php
require_once dirname(dirname(__DIR__)).'/core/config.php';
require_once dirname(dirname(__DIR__)).'/core/db.php';
require_once dirname(dirname(__DIR__)).'/core/auth.php';
require_once dirname(dirname(__DIR__)).'/core/baglanlogo.php';
Auth::zorunlu();
$tiger_ok = ($tigerdb_pdo !== null);
$stok_kodu = trim($_POST['stok_kodu']??'');
$paket_no  = trim($_POST['paket_no']??'');
$raf_yeri  = trim($_POST['raf_yeri']??'');
$ambar     = $_POST['ambar']??'';
$list_all  = isset($_POST['list_all']);
$sonuclar  = []; $hata = '';

if ($tiger_ok && ($list_all||$stok_kodu||$paket_no||$raf_yeri||$ambar!=='')) {
    try {
        $sql = "SELECT P.STOK_KODU,P.STOK_ADI,WS.NAME AS AMBAR,P.STOK_YERI AS RAF_YERI,
            SUM(P.MIKTAR) AS MIKTAR,P.PAKET_NO,P.ANA_HAMMADDE AS LOT_NO,P.AMBAR AS AMBAR_NO
            FROM MES.dbo.PAKETLER P
            INNER JOIN dbo.L_CAPIWHOUSE WS ON P.AMBAR=WS.NR AND WS.FIRMNR=222
            WHERE P.AKTIF=0";
        if (!$list_all) {
            if ($stok_kodu) $sql .= " AND P.STOK_KODU LIKE :stok_kodu";
            if ($paket_no)  $sql .= " AND P.PAKET_NO LIKE :paket_no";
            if ($raf_yeri)  $sql .= " AND P.STOK_YERI LIKE :raf_yeri";
            if ($ambar!=='')$sql .= " AND P.AMBAR=:ambar";
        }
        $sql .= " GROUP BY P.STOK_KODU,P.STOK_ADI,P.PAKET_NO,WS.NAME,P.ANA_HAMMADDE,P.STOK_YERI,P.AMBAR";
        $st = $tigerdb_pdo->prepare($sql);
        if (!$list_all) {
            if ($stok_kodu) $st->bindValue(':stok_kodu','%'.$stok_kodu.'%');
            if ($paket_no)  $st->bindValue(':paket_no','%'.$paket_no.'%');
            if ($raf_yeri)  $st->bindValue(':raf_yeri','%'.$raf_yeri.'%');
            if ($ambar!=='')$st->bindValue(':ambar',$ambar);
        }
        $st->execute();
        $sonuclar = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { $hata = $e->getMessage(); }
}
?>
<style>
#tblAdresli th { background:#1E3A5F !important; color:#fff !important; }
#tblAdresli td, #tblAdresli th { border:1px solid #000 !important; white-space:nowrap !important; }
</style>
<div class="s-bar">
  <div><h1 class="s-bas">📍 Adresli Stok Raporu</h1>
    <div class="s-yol">Depo / <b>Raf Adresi Bazlı Stok</b>
      <?php if($tiger_ok):?><span style="font-size:11px;color:#065F46;font-weight:700;margin-left:8px">● Tiger DB</span><?php else:?><span style="font-size:11px;color:#EF4444;font-weight:700;margin-left:8px">● Tiger DB Yok</span><?php endif;?>
    </div>
  </div>
</div>
<?php if($hata):?><div style="background:#FEE2E2;color:#991B1B;padding:10px;border-radius:8px;margin-bottom:10px">❌ <?php echo htmlspecialchars($hata);?></div><?php endif;?>
<!-- Filtre -->
<div class="kart" style="padding:12px;margin-bottom:12px">
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div><label class="form-etiket">Stok Kodu</label>
      <input type="text" name="stok_kodu" class="form-alan" value="<?php echo htmlspecialchars($stok_kodu);?>" placeholder="Stok kodu..."></div>
    <div><label class="form-etiket">Paket No</label>
      <input type="text" name="paket_no" class="form-alan" value="<?php echo htmlspecialchars($paket_no);?>" placeholder="Paket no..."></div>
    <div><label class="form-etiket">Raf Yeri</label>
      <input type="text" name="raf_yeri" class="form-alan" value="<?php echo htmlspecialchars($raf_yeri);?>" placeholder="Raf yeri..."></div>
    <div><label class="form-etiket">Ambar</label>
      <select name="ambar" class="form-alan">
        <option value="">Tüm Ambarlar</option>
        <option value="0" <?php echo $ambar==='0'?'selected':'';?>>Merkez</option>
        <option value="1" <?php echo $ambar==='1'?'selected':'';?>>Üretim</option>
        <option value="5" <?php echo $ambar==='5'?'selected':'';?>>BSH</option>
        <option value="4" <?php echo $ambar==='4'?'selected':'';?>>Kırma</option>
        <option value="3" <?php echo $ambar==='3'?'selected':'';?>>Karantina</option>
      </select></div>
    <button type="submit" style="background:#1E3A5F;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">🔍 Ara</button>
    <button type="submit" name="list_all" value="1" style="background:#0369A1;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">📋 Tümünü Listele</button>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-adresli-stok" style="background:#F1F5F9;border:1px solid #E2E8F0;color:#374151;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none">✕ Temizle</a>
  </form>
</div>
<div class="kart" style="overflow:hidden;padding:0">
<div style="overflow-x:auto">
<table id="tblAdresli" style="width:100%;border-collapse:collapse">
  <thead><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th><th>Raf Yeri</th>
    <th style="text-align:right">Miktar</th><th>Paket No</th><th>Lot No</th><th>Ambar No</th>
  </tr></thead>
  <tfoot><tr>
    <th>Stok Kodu</th><th>Stok Adı</th><th>Ambar</th><th>Raf Yeri</th>
    <th>Miktar</th><th>Paket No</th><th>Lot No</th><th>Ambar No</th>
  </tr></tfoot>
  <tbody>
  <?php if(empty($sonuclar)):?>
  <tr><td colspan="8" style="text-align:center;padding:30px;color:#888">Filtreleme yapın veya "Tümünü Listele" butonuna tıklayın.</td></tr>
  <?php else: foreach($sonuclar as $r):?>
  <tr>
    <td><code style="background:#F1F5F9;padding:1px 4px;border-radius:3px;font-size:10px;font-weight:700"><?php echo htmlspecialchars($r['STOK_KODU']??'');?></code></td>
    <td><?php echo htmlspecialchars($r['STOK_ADI']??'');?></td>
    <td><?php echo htmlspecialchars($r['AMBAR']??'');?></td>
    <td style="font-weight:600;color:#0369A1"><?php echo htmlspecialchars($r['RAF_YERI']??'');?></td>
    <td style="text-align:right;font-weight:700"><?php echo number_format(floatval($r['MIKTAR']??0),0,'','.');?></td>
    <td><?php echo htmlspecialchars($r['PAKET_NO']??'');?></td>
    <td><?php echo htmlspecialchars($r['LOT_NO']??'');?></td>
    <td style="text-align:center;color:#64748B;font-size:11px"><?php echo htmlspecialchars($r['AMBAR_NO']??'');?></td>
  </tr>
  <?php endforeach; endif;?>
  </tbody>
</table>
</div>
</div>
<script>
$(document).ready(function(){
    if($('#tblAdresli tbody tr td').length > 1) {
        $('#tblAdresli').DataTable({
            initComplete:function(){
                this.api().columns([0,2,3]).every(function(){
                    var col=this,th=$(col.footer());if(!th||!th.length)return;
                    var sel=$('<select class="dt-filtre-sel"><option value=""></option></select>').appendTo(th.empty())
                        .on('change',function(){var v=$.fn.dataTable.util.escapeRegex($(this).val());col.search(v?'^'+v+'$':'',true,false).draw();});
                    col.data().unique().sort().each(function(d){var v=$('<div/>').html(d).text();if(v.length>30)v=v.substr(0,30)+'...';sel.append('<option value="'+v+'">'+v+'</option>');});
                });
            },
            language:{url:'https://cdn.datatables.net/plug-ins/1.10.20/i18n/Turkish.json'},
            scrollCollapse:true,scrollY:'500px',paging:false,scrollX:true,
            dom:'Bfrtip',
            buttons:[{extend:'excelHtml5',text:'📊 Excel',className:'btn-dt',filename:'Adresli_Stok'},'print']
        });
    }
});
</script>
