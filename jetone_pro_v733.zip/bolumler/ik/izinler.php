<?php
/**
 * İK — İzin Talepleri
 * bolumler/ik/izinler.php
 */
if (!Auth::yetkiKontrol('ik','goruntule')) { echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>'; return; }
$durum=$_GET['durum']??'bekliyor';
$where=$durum?"WHERE i.durum=?":"WHERE 1=1"; $params=$durum?[$durum]:[];
try {
    $stmt=$db->prepare("SELECT COUNT(*) FROM izin_talepleri i $where"); $stmt->execute($params); $toplam=(int)$stmt->fetchColumn();
    $stmt2=$db->prepare("SELECT i.*, CONCAT(p.ad,' ',p.soyad) personel_adi, p.sicil_no, CONCAT(o.ad,' ',o.soyad) onaylayan_adi FROM izin_talepleri i LEFT JOIN personeller p ON i.personel_id=p.id LEFT JOIN kullanicilar o ON i.onaylayan_id=o.id $where ORDER BY i.olusturma DESC ");
    $stmt2->execute($params); $izinler=$stmt2->fetchAll();
    $sayilar=$db->query("SELECT durum,COUNT(*) n FROM izin_talepleri GROUP BY durum")->fetchAll(PDO::FETCH_KEY_PAIR);
} catch(Throwable $e){ $izinler=[]; $toplam=0; $sayilar=[]; }
$durumlar=['bekliyor'=>['⏳','#FEF0C7','#B45309'],'onaylandi'=>['✅','#D1FADF','#0A8F4E'],'reddedildi'=>['❌','#FEE4E2','#F04438'],'iptal'=>['🚫','#F4F5F7','#667085']];
$turler=['yillik'=>'Yıllık İzin','hastalik'=>'Hastalık','mazeret'=>'Mazeret','ucretsiz'=>'Ücretsiz','dogum'=>'Doğum','olum'=>'Vefat'];
?>
<div class="s-bar">
  <div><h1 class="s-bas">İzin Talepleri</h1><div class="s-yol">İnsan Kaynakları / <b>İzin Talepleri</b></div></div>
  <div style="display:flex;align-items:center;gap:8px">
    <div id="dt-toolbar-dt-izinler" style="display:inline-flex;align-items:center;gap:6px"></div>
    <button onclick="dtExcelIndir('dt-izinler','IzinTalepleri',{tip:'izinler'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;display:inline-flex;align-items:center;gap:5px">📊 Excel</button>
  </div>
</div>
<div class="s-body">
  <div style="display:flex;gap:0;border-bottom:1px solid var(--kenar);background:var(--yuzey);border-radius:var(--r-lg) var(--r-lg) 0 0;overflow:hidden">
    <?php foreach ([''=>'Tümü','bekliyor'=>'Bekliyor','onaylandi'=>'Onaylanan','reddedildi'=>'Reddedilen'] as $k=>$v): ?>
    <a href="?sayfa=ik-izinler&durum=<?php echo $k; ?>" style="padding:11px 16px;font-size:13px;font-weight:600;color:<?php echo $k===$durum?'var(--t)':'var(--m2)'; ?>;border-bottom:2px solid <?php echo $k===$durum?'var(--t)':'transparent'; ?>;text-decoration:none;white-space:nowrap"><?php echo $v; ?><?php echo isset($sayilar[$k])&&$sayilar[$k]>0?" <span style='background:var(--t);color:#fff;font-size:10px;padding:1px 7px;border-radius:20px'>{$sayilar[$k]}</span>":''; ?></a>
    <?php endforeach; ?>
  </div>
  <div class="kart" style="border-radius:0 0 var(--r-lg) var(--r-lg);overflow:hidden">
    <div style="overflow-y:auto;max-height:calc(100vh - 260px)">
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="dt-izinler">
      <thead style="position:sticky;top:0;z-index:2"><tr><th>Personel</th><th>İzin Türü</th><th>Başlangıç</th><th>Bitiş</th><th>Gün</th><th>Durum</th><th>İşlemler</th></tr></thead>
      <tbody>
        <?php if(empty($izinler)): ?><tr><td colspan="7" style="text-align:center;padding:30px;color:var(--m2)">Kayıt bulunamadı.</td></tr>
        <?php else: foreach($izinler as $iz): $dr=$durumlar[$iz['durum']]??['?','#F4F5F7','#667085']; ?>
        <tr>
          <td><div style="font-weight:700"><?php echo htmlspecialchars($iz['personel_adi']??'—'); ?></div><div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($iz['sicil_no']??''); ?></div></td>
          <td><?php echo $turler[$iz['izin_turu']]??$iz['izin_turu']; ?></td>
          <td style="font-size:12px"><?php echo date('d.m.Y',strtotime($iz['baslangic'])); ?></td>
          <td style="font-size:12px"><?php echo date('d.m.Y',strtotime($iz['bitis'])); ?></td>
          <td style="font-weight:700;color:var(--t)"><?php echo $iz['gun_sayisi']; ?> gün</td>
          <td><span class="roz" style="background:<?php echo $dr[1]; ?>;color:<?php echo $dr[2]; ?>"><?php echo $dr[0]; ?> <?php echo ucfirst($iz['durum']); ?></span></td>
          <td><?php if($iz['durum']==='bekliyor'&&Auth::yetkiKontrol('ik','duzenle')): ?>
          <button class="btn btn-sm" style="background:#D1FADF;color:#0A8F4E;border:none;cursor:pointer" onclick="izinIslem(<?php echo $iz['id']; ?>,'onayla')">✓</button>
          <button class="btn btn-sm" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer;margin-left:4px" onclick="izinIslem(<?php echo $iz['id']; ?>,'reddet')">✗</button>
          <?php else: ?><span style="font-size:11px;color:var(--m3)"><?php echo $iz['onay_tarihi']?date('d.m.Y',strtotime($iz['onay_tarihi'])):'—'; ?></span><?php endif; ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table></div>
</div>
</div>
</div>
<script>
function izinIslem(id,islem){
  if(!confirm('Bu işlemi onaylamak istiyor musunuz?'))return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/izin-onayla.php',{id,islem}).then(r=>{
    JT.bildirim(r.ok?'İşlem başarılı!':(r.hata||'Hata'),r.ok?'basari':'hata');
    if(r.ok)setTimeout(()=>location.reload(),1000);
  });
}
</script>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-izinler');});
</script>