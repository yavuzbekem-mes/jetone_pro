<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

$id = (int)($_GET['id'] ?? 0);
$k = null; $mevcut_nedenler = [];
if ($id) {
    $q = $db->prepare("SELECT it.*, p.kadro, p.unvan FROM ihtar_tutanaklar it JOIN personeller p ON it.personel_id=p.id WHERE it.id=? LIMIT 1");
    $q->execute([$id]); $k = $q->fetch();
    if ($k && $k['nedenler']) $mevcut_nedenler = json_decode($k['nedenler'], true) ?: [];
}

$personeller = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, p.sicil_no, p.kadro, p.unvan, d.ad dept_adi FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.durum='aktif' ORDER BY p.ad")->fetchAll();

$nedenler_listesi = [
    'Mola saatleri dışında görev yerini terk etmek.',
    'Mola saatleri dışında cep telefonu ile görüşme yapmak.',
    'Amirlere ve arkadaşlarına karşı gelmek ve tehdit içeren söylemde bulunmak.',
    'Makine ve techizatlara zarar vermek.',
    'İş sağlığı ve güvenliği kurallarına uymamak.',
    'İş yerinde alkollü ve sarhoş olmak.',
    "4857 sayılı kanunun 25/A maddesi: Ödevli bulunduğu görevleri yapmaması.",
    'Hatalı üretim / işlem yapmak.',
];
$v = function($f,$d='') use ($k) { return htmlspecialchars($k[$f] ?? $d); };
?>
<div class="s-bar">
  <div><h1 class="s-bas"><?php echo $id?'İhtar Düzenle':'Yeni İhtar Tutanağı'; ?></h1>
  <div class="s-yol">İK / <a href="?sayfa=ik-ihtar-listesi" style="color:var(--t);text-decoration:none">İhtar Tutanakları</a></div></div>
  <a href="?sayfa=ik-ihtar-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Geri</a>
</div>
<div class="s-body">
<form id="ihtarForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">👤 Personel Bilgileri</div>
  <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:12px">
    <div>
      <label class="form-etiket">Personel <span style="color:#EF4444">*</span></label>
      <select class="form-alan" name="personel_id" id="personelSec" onchange="personelDoldur(this)" required>
        <option value="">— Personel Seçiniz —</option>
        <?php foreach ($personeller as $p): ?>
        <option value="<?php echo $p['id']; ?>"
          data-kadro="<?php echo htmlspecialchars($p['kadro']??''); ?>"
          data-unvan="<?php echo htmlspecialchars($p['unvan']??''); ?>"
          data-dept="<?php echo htmlspecialchars($p['dept_adi']??''); ?>"
          <?php echo ($k['personel_id']??'')==$p['id']?'selected':''; ?>>
          <?php echo htmlspecialchars($p['ad_soyad'].' ('.$p['sicil_no'].')'); ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div><label class="form-etiket">Bölüm</label><input class="form-alan" id="perBolum" readonly style="background:var(--bg)" value="<?php echo $v('bolum'); ?>"></div>
    <div><label class="form-etiket">Kadro</label><input class="form-alan" id="perKadro" readonly style="background:var(--bg)" value="<?php echo $v('kadro'); ?>"></div>
    <div><label class="form-etiket">Ünvan</label><input class="form-alan" id="perUnvan" readonly style="background:var(--bg)" value="<?php echo $v('unvan'); ?>"></div>
  </div>
</div>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">📋 Form Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
    <div><label class="form-etiket">İhtar Tarihi <span style="color:#EF4444">*</span></label><input type="date" class="form-alan" name="ihtar_tarihi" value="<?php echo $v('ihtar_tarihi',date('Y-m-d')); ?>" required></div>
    <div><label class="form-etiket">Tebliğ Eden</label><input class="form-alan" name="teblig_eden" value="<?php echo $v('teblig_eden'); ?>" placeholder="Ad Soyad"></div>
    <div><label class="form-etiket">Şahit</label><input class="form-alan" name="sabit" value="<?php echo $v('sabit'); ?>" placeholder="Ad Soyad"></div>
  </div>
</div>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">⚠️ İhtar Nedenleri</div>
  <div style="display:grid;gap:8px">
    <?php foreach ($nedenler_listesi as $i => $neden): ?>
    <label id="nLbl<?php echo $i; ?>" style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1.5px solid var(--kenar);border-radius:10px;cursor:pointer;<?php echo in_array($i,$mevcut_nedenler)?'border-color:#F97316;background:#FFF7ED':''; ?>">
      <input type="checkbox" name="nedenler[]" value="<?php echo $i; ?>" <?php echo in_array($i,$mevcut_nedenler)?'checked':''; ?> onchange="nedenRenk(<?php echo $i; ?>,this)" style="width:18px;height:18px;accent-color:#F97316;flex-shrink:0;margin-top:1px">
      <span style="font-size:13px;line-height:1.5"><?php echo htmlspecialchars($neden); ?></span>
    </label>
    <?php endforeach; ?>
    <?php $diger_i = count($nedenler_listesi); ?>
    <label id="nLbl<?php echo $diger_i; ?>" style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1.5px solid var(--kenar);border-radius:10px;cursor:pointer;<?php echo in_array($diger_i,$mevcut_nedenler)?'border-color:#F97316;background:#FFF7ED':''; ?>">
      <input type="checkbox" name="nedenler[]" value="<?php echo $diger_i; ?>" <?php echo in_array($diger_i,$mevcut_nedenler)?'checked':''; ?> onchange="nedenRenk(<?php echo $diger_i; ?>,this);document.getElementById('digerAlan').style.display=this.checked?'block':'none'" style="width:18px;height:18px;accent-color:#F97316;flex-shrink:0;margin-top:1px">
      <span style="font-size:13px">Diğer</span>
    </label>
    <div id="digerAlan" style="<?php echo in_array($diger_i,$mevcut_nedenler)?'display:block':'display:none'; ?>">
      <input class="form-alan" name="diger_neden" value="<?php echo $v('diger_neden'); ?>" placeholder="Diğer nedeni açıklayınız...">
    </div>
  </div>
</div>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">📝 Savunma ve Karar</div>
  <div style="display:grid;gap:12px">
    <div><label class="form-etiket">Savunma Açıklaması</label><textarea class="form-alan" name="savunma" rows="4" placeholder="Personelin savunmasını yazınız..."><?php echo $v('savunma'); ?></textarea></div>
    <div><label class="form-etiket">Karar</label><textarea class="form-alan" name="karar" rows="3" placeholder="Verilen kararı yazınız..."><?php echo $v('karar'); ?></textarea></div>
    <div><label class="form-etiket">Durum</label>
      <select class="form-alan" name="durum">
        <option value="bekliyor" <?php echo ($k['durum']??'bekliyor')==='bekliyor'?'selected':''; ?>>⏳ Bekliyor</option>
        <option value="savunma_alindi" <?php echo ($k['durum']??'')==='savunma_alindi'?'selected':''; ?>>📝 Savunma Alındı</option>
        <option value="kapatildi" <?php echo ($k['durum']??'')==='kapatildi'?'selected':''; ?>>✅ Kapatıldı</option>
      </select>
    </div>
  </div>
</div>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">🖊 Yetkili İmzalar</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
    <div><label class="form-etiket">İnsan Kaynakları Sorumlusu</label><input class="form-alan" name="ik_sorumlu" value="<?php echo $v('ik_sorumlu'); ?>" placeholder="Ad Soyad"></div>
    <div><label class="form-etiket">Fabrika Müdürü</label><input class="form-alan" name="fabrika_mudur" value="<?php echo $v('fabrika_mudur'); ?>" placeholder="Ad Soyad"></div>
    <div><label class="form-etiket">Kaydeden</label><input class="form-alan" value="<?php echo htmlspecialchars($user['ad_soyad']??''); ?>" readonly style="background:var(--bg);color:var(--m2)"></div>
  </div>
</div>

<div style="display:flex;gap:10px;justify-content:flex-end">
  <a href="?sayfa=ik-ihtar-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:12px 24px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px">İptal</a>
  <button type="button" onclick="kaydet()" id="kaydetBtn" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:12px 28px;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit">💾 Kaydet</button>
</div>
</form>
</div>
<script>
function personelDoldur(sel) {
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('perBolum').value = opt.dataset.dept||'';
    document.getElementById('perKadro').value = opt.dataset.kadro||'';
    document.getElementById('perUnvan').value = opt.dataset.unvan||'';
}
function nedenRenk(i,cb) {
    var l = document.getElementById('nLbl'+i);
    l.style.borderColor = cb.checked?'#F97316':'var(--kenar)';
    l.style.background = cb.checked?'#FFF7ED':'';
}
function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled=true; btn.textContent='Kaydediliyor...';
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/ihtar-kaydet.php',{method:'POST',body:new FormData(document.getElementById('ihtarForm')),credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){
        btn.disabled=false; btn.textContent='💾 Kaydet';
        if(r.ok) location.href='?sayfa=ik-ihtar-detay&id='+r.id;
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){btn.disabled=false;btn.textContent='💾 Kaydet';alert('Bağlantı hatası');});
}
<?php if($k && $k['personel_id']): ?>personelDoldur(document.getElementById('personelSec'));<?php endif; ?>
</script>
