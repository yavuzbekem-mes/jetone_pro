<?php
/**
 * İK — Personel Profil Sayfası
 * bolumler/ik/personel-profil.php
 */
if (!Auth::yetkiKontrol('ik', 'goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    echo '<div class="s-bar"><div class="s-bas">Hata</div></div><div class="s-body"><div class="kart" style="padding:30px;text-align:center;color:var(--m2)">Personel ID eksik.</div></div>';
    return;
}

// Ana personel verisi
try {
    $stmt = $db->prepare("
        SELECT p.*,
               d.ad  departman_adi,
               CONCAT(y.ad,' ',y.soyad) yonetici_adi,
               y.pozisyon yonetici_pozisyon,
               pk.kullanici_adi portal_kul_adi,
               pk.son_giris    portal_son_giris,
               pk.durum        portal_durum,
               per_portal.sifre_degistirildi
        FROM personeller p
        LEFT JOIN departmanlar d  ON p.departman_id  = d.id
        LEFT JOIN personeller  y  ON p.yonetici_id   = y.id
        LEFT JOIN portal_kullanicilari pk ON pk.tip='personel' AND pk.ilgili_id = p.id
        LEFT JOIN personeller per_portal ON per_portal.id = p.id
        WHERE p.id = ?
        LIMIT 1
    ");
    $stmt->execute([$id]);
    $p = $stmt->fetch();
} catch (Exception $e) { $p = null; }

if (!$p) {
    echo '<div class="s-bar"><div class="s-bas">Bulunamadı</div></div><div class="s-body"><div class="kart" style="padding:30px;text-align:center;color:var(--m2)">Personel bulunamadı.</div></div>';
    return;
}

// Ek veriler
try {
    $izin_bakiye = 14; // Gerçek hesap için izin tablosu sorgulanabilir
    $izin_kullanan = $db->prepare("SELECT COALESCE(SUM(gun_sayisi),0) FROM izin_talepleri WHERE personel_id=? AND durum='onaylandi' AND YEAR(baslangic)=YEAR(NOW()) AND izin_turu='yillik'");
    $izin_kullanan->execute([$id]);
    $kullanan_gun = (float)$izin_kullanan->fetchColumn();

    $son_izinler = $db->prepare("SELECT * FROM izin_talepleri WHERE personel_id=? ORDER BY olusturma DESC LIMIT 5");
    $son_izinler->execute([$id]);
    $izinler = $son_izinler->fetchAll();

    $belgeler = $db->prepare("SELECT * FROM personel_belgeler WHERE personel_id=? ORDER BY olusturma DESC");
    $belgeler->execute([$id]);
    $belgeler = $belgeler->fetchAll();

    // Tüm zimmetler — hem zimmetli hem iade hem kayıp
    $zimmetler = $db->prepare("SELECT * FROM personel_zimmetler WHERE personel_id=? ORDER BY teslim_tarihi DESC");
    $zimmetler->execute([$id]);
    $zimmetler = $zimmetler->fetchAll();

    $devam_son7 = $db->prepare("SELECT * FROM devam_kayitlari WHERE personel_id=? AND tarih >= DATE_SUB(CURDATE(),INTERVAL 7 DAY) ORDER BY tarih DESC");
    $devam_son7->execute([$id]);
    $devam = $devam_son7->fetchAll();

    $calisma_ay = $db->prepare("SELECT COALESCE(SUM(calisma_suresi),0) FROM devam_kayitlari WHERE personel_id=? AND MONTH(tarih)=MONTH(NOW()) AND YEAR(tarih)=YEAR(NOW())");
    $calisma_ay->execute([$id]);
    $ay_calisma = (float)$calisma_ay->fetchColumn();
} catch (Exception $e) {
    $izinler = $belgeler = $zimmetler = $devam = [];
    $kullanan_gun = $ay_calisma = 0;
}

// Kıdem hesabı
$kidem_yil = $kidem_ay = 0;
if ($p['ise_baslama']) {
    $bas = new DateTime($p['ise_baslama']);
    $bitis = $p['cikis_tarihi'] ? new DateTime($p['cikis_tarihi']) : new DateTime();
    $fark = $bas->diff($bitis);
    $kidem_yil = $fark->y;
    $kidem_ay  = $fark->m;
}

$durumRenk = [
    'aktif'   => ['bg'=>'#D1FADF','renk'=>'#0A8F4E','ikon'=>'✓'],
    'izinli'  => ['bg'=>'#FEF0C7','renk'=>'#B45309','ikon'=>'🏖'],
    'ayrıldı' => ['bg'=>'#FEE4E2','renk'=>'#F04438','ikon'=>'✗'],
];
$dr = $durumRenk[$p['durum']] ?? ['bg'=>'#F4F5F7','renk'=>'#667085','ikon'=>'?'];

function goster($deger, $varsayilan = '—') {
    return $deger ? htmlspecialchars($deger) : $varsayilan;
}
function tarih_goster($t) {
    return $t ? date('d.m.Y', strtotime($t)) : '—';
}
?>

<!-- ═══════ ÜSTTEKI BAŞLIK ═══════ -->
<div class="s-bar" style="flex-wrap:wrap;gap:10px">
  <div style="display:flex;align-items:center;gap:14px">
    <!-- Avatar -->
    <?php if ($p['foto']): ?>
    <img src="<?php echo BASE_URL; ?>/bolumler/ik/resimler/<?php echo goster($p['foto']); ?>"
         style="width:56px;height:56px;border-radius:14px;object-fit:cover;flex-shrink:0">
    <?php else: ?>
    <div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,var(--t),var(--t-k));display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;flex-shrink:0">
      <?php echo mb_strtoupper(mb_substr($p['ad'],0,1).mb_substr($p['soyad'],0,1)); ?>
    </div>
    <?php endif; ?>
    <div>
      <div style="display:flex;align-items:center;gap:8px">
        <h1 class="s-bas" style="margin:0"><?php echo goster($p['ad'].' '.$p['soyad']); ?></h1>
        <span class="roz" style="background:<?php echo $dr['bg']; ?>;color:<?php echo $dr['renk']; ?>"><?php echo $dr['ikon']; ?> <?php echo ucfirst($p['durum']); ?></span>
      </div>
      <div style="font-size:13px;color:var(--m2);margin-top:3px">
        <?php echo goster($p['pozisyon']); ?>
        <?php if ($p['departman_adi']): ?>
        &nbsp;·&nbsp; <?php echo goster($p['departman_adi']); ?>
        <?php endif; ?>
        &nbsp;·&nbsp; <span style="color:var(--t);font-weight:700"><?php echo goster($p['sicil_no']); ?></span>
      </div>
    </div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-left:auto">
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personeller" class="btn btn-b">← Liste</a>
    <?php if (Auth::yetkiKontrol('ik','duzenle')): ?>
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personel-duzenle&id=<?php echo $id; ?>" class="btn btn-b">✏️ Düzenle</a>
    <?php endif; ?>
    <?php if (Auth::yetkiKontrol('ik','duzenle') && $p['durum'] !== 'ayrıldı'): ?>
    <button class="btn" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer" onclick="cikisModalAc()">🚪 İşten Çıkış</button>
    <?php endif; ?>
    <div style="position:relative">
      <button class="btn btn-b" onclick="document.getElementById('islemMenu').classList.toggle('goster')">⋯ İşlemler</button>
      <div id="islemMenu" style="display:none;position:absolute;right:0;top:calc(100% + 4px);background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:6px;min-width:200px;z-index:100;box-shadow:var(--golge-lg)">
        <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-izinler&personel_id=<?php echo $id; ?>" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--r);color:var(--m);text-decoration:none;font-size:13px;transition:.15s" onmouseover="this.style.background='var(--kenar-a)'" onmouseout="this.style.background=''">🏖 İzin Talepleri</a>
        <button onclick="portalSifreReset()" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--r);color:var(--m);background:none;border:none;cursor:pointer;font-size:13px;width:100%;text-align:left" onmouseover="this.style.background='var(--kenar-a)'" onmouseout="this.style.background=''">🔑 Portal Şifre Sıfırla</button>
        <button onclick="togglePortalErisim()" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--r);color:var(--m);background:none;border:none;cursor:pointer;font-size:13px;width:100%;text-align:left" onmouseover="this.style.background='var(--kenar-a)'" onmouseout="this.style.background=''">🔐 Portal Erişimi Aç/Kapat</button>
        <hr style="margin:4px 0;border-color:var(--kenar)">
        <?php if ($p['durum']==='ayrıldı'): ?>
        <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;font-size:11px;color:var(--m3)">🔒 Yasal arşiv: 10 yıl saklanır</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <button onclick="dtExcelIndir('tbl-personel_profil','Personel_Profil')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- ═══════ KPI KARTLAR ═══════ -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px">
  <div class="kpi-k"><div class="kpi-ikon" style="background:#FEF3E8">📅</div><div class="kpi-val"><?php echo $kidem_yil; ?> yıl <?php echo $kidem_ay; ?> ay</div><div class="kpi-et">Kıdem</div></div>
  <div class="kpi-k"><div class="kpi-ikon" style="background:#D1FADF">🏖</div><div class="kpi-val"><?php echo ($izin_bakiye - $kullanan_gun); ?> / <?php echo $izin_bakiye; ?></div><div class="kpi-et">Kalan İzin Günü</div></div>
  <div class="kpi-k"><div class="kpi-ikon" style="background:#E0F2FE">⏱</div><div class="kpi-val"><?php echo round($ay_calisma, 1); ?> sa</div><div class="kpi-et">Bu Ay Çalışma</div></div>
  <div class="kpi-k" id="kpiMaasKart" style="cursor:pointer" onclick="finansalToggle()">
    <div style="display:flex;align-items:center;justify-content:space-between">
      <div class="kpi-ikon" style="background:#FEE4E2">💰</div>
      <span id="kpiGozBtn" title="Göster/Gizle" style="font-size:16px;color:var(--m3)">🙈</span>
    </div>
    <div class="kpi-val" id="kpiMaasVal">₺ •••••</div>
    <div class="kpi-et">Net Maaş <span style="font-size:10px;color:var(--m3)">(tıkla)</span></div>
  </div>
</div>

<!-- ═══════ SEKMELER ═══════ -->
<div class="profil-sekme-nav">
  <button class="ps aktif" onclick="profilSekme('ozet',this)">📋 Özet</button>
  <button class="ps" onclick="profilSekme('kisisel',this)">👤 Kişisel</button>
  <button class="ps" onclick="profilSekme('ozluk',this)">📁 Özlük Dosyası</button>
  <button class="ps" onclick="profilSekme('izin',this)">🏖 İzin</button>
  <button class="ps" onclick="profilSekme('devam',this)">✅ Devam</button>
  <button class="ps" onclick="profilSekme('zimmet',this)">📦 Zimmet</button>
  <button class="ps" onclick="profilSekme('portal',this)">🔐 Portal</button>
  <button class="ps" onclick="profilSekme('bordrolar',this)">💰 Bordrolar</button>
</div>

<!-- ═══════ ÖZET SEKMESİ ═══════ -->
<div class="profil-panel aktif" id="pp-ozet">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

    <!-- Sol: Temel Bilgiler -->
    <div style="display:flex;flex-direction:column;gap:14px">
      <div class="kart">
        <div class="kart-ust"><div class="kart-bas">👤 Temel Bilgiler</div></div>
        <div class="bilgi-grid">
          <?php
          $bilgiler = [
            'Sicil No'       => $p['sicil_no'],
            'Ad Soyad'       => $p['ad'].' '.$p['soyad'],
            'T.C. Kimlik'    => $p['tc_kimlik'] ? substr($p['tc_kimlik'],0,3).'*****'.substr($p['tc_kimlik'],-3) : null,
            'Doğum Tarihi'   => tarih_goster($p['dogum_tarihi']),
            'Cinsiyet'       => $p['cinsiyet']==1?'Erkek':($p['cinsiyet']==2?'Kadın':null),
            'Medeni Durum'   => $p['medeni_durum'] ?? null,
            'Kan Grubu'      => $p['kan_grubu'] ?? null,
            'Uyruk'          => $p['uyruk'] ?? null,
          ];
          foreach ($bilgiler as $k=>$v): if (!$v) continue; ?>
          <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="kart">
        <div class="kart-ust"><div class="kart-bas">🏢 İş Bilgileri</div></div>
        <div class="bilgi-grid">
          <?php
          $is_bilgi = [
            'Departman'       => $p['departman_adi'],
            'Pozisyon'        => $p['pozisyon'],
            'Unvan'           => $p['unvan'] ?? null,
            'Yönetici'        => $p['yonetici_adi'] ?? null,
            'Çalışma Şekli'   => $p['calısma_tipi'] ? str_replace('_',' ', ucfirst($p['calısma_tipi'])) : null,
            'Sözleşme Tipi'   => $p['is_sozlesmesi_tipi'] ? str_replace('_',' ', ucfirst($p['is_sozlesmesi_tipi'])) : null,
            'İşe Başlama'     => tarih_goster($p['ise_baslama']),
            'Deneme Bitiş'    => tarih_goster($p['deneme_bitis'] ?? null),
            'Taşeron Firma'   => $p['tedarikci_firma'] ?? null,
            'Çalışma Yeri'    => $p['calisma_yeri'] ?? null,
          ];
          foreach ($is_bilgi as $k=>$v): if (!$v || $v==='—') continue; ?>
          <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Sağ: İletişim + Finansal + Son İzinler -->
    <div style="display:flex;flex-direction:column;gap:14px">
      <div class="kart">
        <div class="kart-ust"><div class="kart-bas">📞 İletişim</div></div>
        <div class="bilgi-grid">
          <?php
          $iletisim = [
            'Cep Tel'     => $p['telefon'],
            'İş Tel'      => $p['tel_is'] ?? null,
            'E-posta'     => $p['email'],
            'İl / İlçe'   => ($p['il'] ?? null) ? ($p['il'].($p['ilce']?' / '.$p['ilce']:'')) : null,
            'Adres'       => $p['adres'] ?? null,
          ];
          foreach ($iletisim as $k=>$v): if (!$v) continue; ?>
          <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars(mb_substr($v,0,40)); ?></span></div>
          <?php endforeach; ?>
          <?php if ($p['acil_kisi_ad'] ?? null): ?>
          <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--kenar)">
            <div style="font-size:11px;font-weight:700;color:var(--m3);text-transform:uppercase;margin-bottom:5px">Acil Durum</div>
            <div style="font-size:13px"><b><?php echo goster($p['acil_kisi_ad']); ?></b> — <?php echo goster($p['acil_kisi_yakinlik']); ?></div>
            <div style="font-size:12px;color:var(--m2)"><?php echo goster($p['acil_kisi_tel']); ?></div>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="kart" id="finansalKart">
        <div class="kart-ust">
          <div class="kart-bas">💰 Finansal</div>
          <button onclick="finansalToggle()" id="finansalGozBtn"
            style="display:flex;align-items:center;gap:6px;padding:5px 12px;border:1.5px solid var(--kenar);border-radius:var(--r);background:var(--bg);cursor:pointer;font-size:12.5px;font-weight:600;color:var(--m2);font-family:inherit;transition:all .15s"
            onmouseover="this.style.borderColor='var(--t)';this.style.color='var(--t)'"
            onmouseout="this.style.borderColor='var(--kenar)';this.style.color='var(--m2)'">
            <span id="gozIkon">🙈</span> <span id="gozYazi">Göster</span>
          </button>
        </div>
        <!-- Maskeli görünüm (varsayılan) -->
        <div id="finansalMaskeli" class="bilgi-grid">
          <?php
          $fin_etiketler = ['Net Maaş','Brüt Maaş','Yol Ücreti','Yemek Ücreti','Banka','IBAN'];
          foreach ($fin_etiketler as $fet): ?>
          <div class="bilgi-sat">
            <span class="bilgi-k"><?php echo $fet; ?></span>
            <span class="bilgi-v" style="letter-spacing:2px;color:var(--m3);user-select:none">•••••</span>
          </div>
          <?php endforeach; ?>
        </div>
        <!-- Gerçek veriler (gizli) -->
        <div id="finansalGercek" class="bilgi-grid" style="display:none">
          <?php
          $finansal = [
            'Net Maaş'      => $p['maas']             ? '₺'.number_format($p['maas'],2,',','.')         : '—',
            'Brüt Maaş'     => ($p['brut_maas']??0)   ? '₺'.number_format($p['brut_maas'],2,',','.')    : '—',
            'Yol Ücreti'    => ($p['yol_ucreti']??0)  ? '₺'.number_format($p['yol_ucreti'],2,',','.')   : '—',
            'Yemek Ücreti'  => ($p['yemek_ucreti']??0)? '₺'.number_format($p['yemek_ucreti'],2,',','.') : '—',
            'Banka'         => $p['banka_adi'] ?? '—',
            'IBAN'          => ($p['banka_iban']??null) ? $p['banka_iban'] : '—',
          ];
          foreach ($finansal as $k=>$v): ?>
          <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if (!empty($izinler)): ?>
      <div class="kart">
        <div class="kart-ust"><div class="kart-bas">🏖 Son İzinler</div></div>
        <?php
        $izDurum = ['bekliyor'=>['#FEF0C7','#B45309'],'onaylandi'=>['#D1FADF','#0A8F4E'],'reddedildi'=>['#FEE4E2','#F04438']];
        foreach ($izinler as $iz):
          $idr = $izDurum[$iz['durum']] ?? ['#F4F5F7','#667085'];
        ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--kenar)">
          <div>
            <div style="font-size:13px;font-weight:600"><?php echo $iz['gun_sayisi']; ?> gün — <?php echo ucfirst($iz['izin_turu']); ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo tarih_goster($iz['baslangic']); ?> – <?php echo tarih_goster($iz['bitis']); ?></div>
          </div>
          <span class="roz" style="background:<?php echo $idr[0]; ?>;color:<?php echo $idr[1]; ?>;font-size:10px"><?php echo ucfirst($iz['durum']); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ═══════ KİŞİSEL SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-kisisel">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🎓 Eğitim Bilgileri</div></div>
      <div class="bilgi-grid">
        <?php
        $egitim = [
          'Eğitim Seviyesi' => $p['egitim_seviyesi'] ? ucfirst(str_replace('_',' ',$p['egitim_seviyesi'])) : null,
          'Okul / Üniversite'=> $p['okul_adi'] ?? null,
          'Bölüm'            => $p['bolum'] ?? null,
          'Mezuniyet Yılı'   => $p['mezuniyet_yili'] ?? null,
        ];
        foreach ($egitim as $k=>$v): if (!$v) continue; ?>
        <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🪖 Askerlik & Diğer</div></div>
      <div class="bilgi-grid">
        <?php
        $diger = [
          'Askerlik'       => $p['askerlik_durumu'] ? ucfirst(str_replace('_',' ',$p['askerlik_durumu'])) : null,
          'Askerlik Tarihi'=> tarih_goster($p['askerlik_tarihi'] ?? null),
          'SGK No'         => $p['sgk_no'] ?? null,
          'Çocuk Sayısı'   => $p['cocuk_sayisi'] ?? null,
          'Engellilik'     => ($p['engellilik_durumu']??0) ? 'Var — %'.($p['engellilik_orani']??0) : 'Yok',
          'Ayakkabı No'    => $p['ayakkabi_no'] ?? null,
          'Üst Beden'      => $p['ust_beden'] ?? null,
          'Pantolon Beden' => $p['pantolon_beden'] ?? null,
        ];
        foreach ($diger as $k=>$v): if (!$v || $v==='—') continue; ?>
        <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🏥 Sağlık & İSG</div></div>
      <div class="bilgi-grid">
        <?php
        $saglik = [
          'Sağlık Raporu'  => ($p['saglik_raporu_var']??0) ? '✓ Mevcut' : '✗ Henüz alınmadı',
          'İSG Eğitim'     => tarih_goster($p['isg_egitim_tarihi'] ?? null),
          'İSG Süresi'     => ($p['isg_egitim_sure']??0) ? ($p['isg_egitim_sure'].' saat') : null,
        ];
        foreach ($saglik as $k=>$v): if (!$v || $v==='—') continue; ?>
        <div class="bilgi-sat"><span class="bilgi-k"><?php echo $k; ?></span><span class="bilgi-v"><?php echo htmlspecialchars($v); ?></span></div>
        <?php endforeach; ?>
        <?php if ($p['notlar'] ?? null): ?>
        <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--kenar)">
          <div style="font-size:11px;font-weight:700;color:var(--m3);text-transform:uppercase;margin-bottom:5px">Notlar</div>
          <div style="font-size:13px;color:var(--m2)"><?php echo nl2br(htmlspecialchars($p['notlar'])); ?></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- ═══════ ÖZLÜK DOSYASI SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-ozluk">
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:14px">
    <div class="kart">
      <div class="kart-ust">
        <div class="kart-bas">📁 Özlük Belgeler</div>
        <?php if (Auth::yetkiKontrol('ik','ekle')): ?>
        <button class="btn btn-t btn-sm" onclick="belgeEkleModal()">+ Belge Ekle</button>
        <?php endif; ?>
      </div>
      <?php
      $kat_ad = ['kisisel'=>'👤 Kişisel','egitim'=>'🎓 Eğitim','is_iliskisi'=>'📋 İş İlişkisi','saglik'=>'🏥 Sağlık','is_sureci'=>'⚙️ İş Süreci','ayrilik'=>'🚪 Ayrılış'];
      $gruplanan = [];
      foreach ($belgeler as $b) {
          $gruplanan[$b['kategori']][] = $b;
      }
      if (empty($belgeler)):
      ?>
      <div style="padding:40px;text-align:center;color:var(--m2)">
        <div style="font-size:36px;margin-bottom:10px">📁</div>
        <div style="font-size:14px;font-weight:600;margin-bottom:4px">Henüz belge eklenmemiş</div>
        <div style="font-size:12px">+ Belge Ekle butonuyla dosya yükleyebilirsiniz</div>
      </div>
      <?php else: foreach ($gruplanan as $kat=>$blist): ?>
      <div style="margin-bottom:16px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3);margin-bottom:7px;padding-bottom:5px;border-bottom:1px solid var(--kenar)"><?php echo $kat_ad[$kat] ?? ucfirst($kat); ?></div>
        <?php foreach ($blist as $b):
          // Güvenli URL oluştur - dosya_yolu örn: P-00016_16/kisisel/20260315_abc_BelgeAdi.pdf
          $dosya_url = null;
          if ($b['dosya_yolu']) {
              // Path traversal engellemek için kontrol
              $temiz_yol = str_replace(array('..', '//', chr(92)), '', $b['dosya_yolu']);
              $dosya_url = BASE_URL . '/bolumler/ik/personel_belgeleri/' . htmlspecialchars($temiz_yol);
          }
          $uzanti = $b['dosya_adi'] ? strtolower(pathinfo($b['dosya_adi'], PATHINFO_EXTENSION)) : '';
          $resim_mi = in_array($uzanti, ['jpg','jpeg','png','gif','webp']);
          $pdf_mi   = $uzanti === 'pdf';
          $ikon = $pdf_mi ? '📕' : ($resim_mi ? '🖼️' : ($b['dosya_yolu'] ? '📄' : '☑️'));
          $renk_bg = $pdf_mi ? '#FEE4E2' : ($resim_mi ? '#E0F2FE' : '#F4F5F7');
        ?>
        <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg);border:1px solid var(--kenar);border-radius:var(--r);margin-bottom:6px;transition:border-color .15s"
             onmouseover="this.style.borderColor='var(--t)'" onmouseout="this.style.borderColor='var(--kenar)'">
          <!-- İkon -->
          <div style="width:36px;height:36px;border-radius:8px;background:<?php echo $renk_bg; ?>;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">
            <?php echo $ikon; ?>
          </div>
          <!-- Bilgi -->
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($b['belge_adi']); ?></div>
            <div style="font-size:11px;color:var(--m2);display:flex;gap:8px;flex-wrap:wrap;margin-top:2px">
              <?php if ($b['dosya_adi']): ?>
              <span>📎 <?php echo htmlspecialchars(mb_substr($b['dosya_adi'], 16)); ?></span>
              <?php endif; ?>
              <?php if ($b['gecerlilik']): ?>
              <span>📅 <?php echo tarih_goster($b['gecerlilik']); ?></span>
              <?php endif; ?>
              <?php if ($b['notlar']): ?>
              <span>💬 <?php echo htmlspecialchars(mb_substr($b['notlar'],0,30)); ?>...</span>
              <?php endif; ?>
            </div>
          </div>
          <!-- Butonlar -->
          <div style="display:flex;gap:4px;flex-shrink:0">
            <?php if ($dosya_url && $resim_mi): ?>
            <button class="btn btn-sm btn-b" onclick="belgeOnizle('<?php echo $dosya_url; ?>','<?php echo htmlspecialchars($b['belge_adi']); ?>','resim')" title="Görüntüle">🔍</button>
            <?php endif; ?>
            <?php if ($dosya_url && $pdf_mi): ?>
            <button class="btn btn-sm btn-b" onclick="belgeOnizle('<?php echo $dosya_url; ?>','<?php echo htmlspecialchars($b['belge_adi']); ?>','pdf')" title="PDF Görüntüle">🔍</button>
            <?php endif; ?>
            <?php if ($dosya_url): ?>
            <a href="<?php echo $dosya_url; ?>" download target="_blank" class="btn btn-sm btn-b" title="İndir">⬇️</a>
            <?php endif; ?>
            <?php if (Auth::yetkiKontrol('ik','sil')): ?>
            <button class="btn btn-sm" style="background:#FEE4E2;color:#F04438;border:none;cursor:pointer" onclick="belgeSil(<?php echo $b['id']; ?>)" title="Sil">🗑</button>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; endif; ?>
    </div>
    <!-- Özlük kontrol listesi -->
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">✅ Kontrol Listesi</div></div>
      <?php
      $kontrol = [
        'Nüfus Cüzdanı Fotokopisi' => false,
        'İkametgah Belgesi'        => false,
        'Vesikalık Fotoğraf'       => !empty($p['foto']),
        'Adli Sicil Kaydı'         => false,
        'Diploma Fotokopisi'       => false,
        'İş Sözleşmesi'            => false,
        'SGK İşe Giriş Bildirgesi' => !empty($p['sgk_no']),
        'Sağlık Raporu'            => (bool)($p['saglik_raporu_var']??0),
        'İSG Eğitim Belgesi'       => !empty($p['isg_egitim_tarihi']),
        'Zimmet Formu'             => !empty($zimmetler),
      ];
      // Veritabanındaki belgelerden tamamlananları işaretle
      foreach ($belgeler as $b) {
          if (isset($kontrol[$b['belge_adi']])) $kontrol[$b['belge_adi']] = true;
      }
      $tamamlanan = count(array_filter($kontrol));
      $toplam_kl  = count($kontrol);
      $oran = round($tamamlanan / $toplam_kl * 100);
      ?>
      <div style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;font-size:13px;font-weight:700;margin-bottom:5px">
          <span>Tamamlanan</span><span style="color:var(--t)"><?php echo $tamamlanan; ?> / <?php echo $toplam_kl; ?></span>
        </div>
        <div style="height:6px;background:var(--kenar);border-radius:3px;overflow:hidden">
          <div style="width:<?php echo $oran; ?>%;height:100%;background:<?php echo $oran>=80?'var(--bas)':($oran>=50?'var(--uya)':'var(--hat)'); ?>;border-radius:3px;transition:width .5s"></div>
        </div>
      </div>
      <?php foreach ($kontrol as $kalem=>$tamam): ?>
      <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:12.5px">
        <span style="width:18px;height:18px;border-radius:4px;background:<?php echo $tamam?'var(--bas)':'var(--kenar)'; ?>;display:flex;align-items:center;justify-content:center;font-size:10px;color:<?php echo $tamam?'#fff':'var(--m3)'; ?>;flex-shrink:0"><?php echo $tamam?'✓':'○'; ?></span>
        <span style="color:<?php echo $tamam?'var(--m)':'var(--m2)'; ?>;<?php echo $tamam?'':'opacity:.7'; ?>"><?php echo htmlspecialchars($kalem); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ═══════ DEVAM SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-devam">
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">✅ Son 7 Gün Devam Durumu</div></div>
    <?php if (empty($devam)): ?>
    <div style="padding:30px;text-align:center;color:var(--m2)">Devam kaydı bulunamadı</div>
    <?php else: ?>
    <table class="tablo" id="tbl-personel_profil">
      <thead><tr><th>Tarih</th><th>Giriş</th><th>Çıkış</th><th>Çalışma</th><th>Giriş Tipi</th><th>Durum</th></tr></thead>
      <tbody>
      <?php
      $devamRenk = ['geldi'=>['#D1FADF','#0A8F4E'],'gelmedi'=>['#FEE4E2','#F04438'],'izinli'=>['#FEF0C7','#B45309'],'gecikti'=>['#FEF0C7','#B45309'],'eksik'=>['#FEE4E2','#F04438']];
      foreach ($devam as $dv):
        $dvr = $devamRenk[$dv['durum']] ?? ['#F4F5F7','#667085'];
      ?>
      <tr>
        <td><?php echo date('d.m.Y D',strtotime($dv['tarih'])); ?></td>
        <td><?php echo $dv['giris_saati'] ? date('H:i',strtotime($dv['giris_saati'])) : '—'; ?></td>
        <td><?php echo $dv['cikis_saati'] ? date('H:i',strtotime($dv['cikis_saati'])) : '—'; ?></td>
        <td><?php echo $dv['calisma_suresi'] ? round($dv['calisma_suresi'],1).' sa' : '—'; ?></td>
        <td style="font-size:12px;color:var(--m2)"><?php echo ucfirst($dv['giris_tipi'] ?? '—'); ?></td>
        <td><span class="roz" style="background:<?php echo $dvr[0]; ?>;color:<?php echo $dvr[1]; ?>"><?php echo ucfirst($dv['durum']); ?></span></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- ═══════ ZİMMET SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-zimmet">
  <div class="kart">
    <div class="kart-ust">
      <div class="kart-bas">📦 Zimmetli Eşyalar</div>
      <?php if (Auth::yetkiKontrol('ik','ekle')): ?>
      <button class="btn btn-t btn-sm" onclick="zimmetEkleModal()">+ Zimmet Ekle</button>
      <?php endif; ?>
    </div>
    <?php if (empty($zimmetler)): ?>
    <div style="padding:30px;text-align:center;color:var(--m2)">Aktif zimmet kaydı yok</div>
    <?php else: ?>
    <?php
    $zimmet_durum_renk = [
      'zimmetli' => ['bg'=>'#D1FADF','renk'=>'#0A8F4E','ikon'=>'✓','etiket'=>'Zimmetli'],
      'iade'     => ['bg'=>'#E0F2FE','renk'=>'#0284C7','ikon'=>'↩','etiket'=>'İade Alındı'],
      'kayip'    => ['bg'=>'#FEE4E2','renk'=>'#F04438','ikon'=>'⚠','etiket'=>'Kayıp'],
    ];
    $aktif_zimmet = count(array_filter($zimmetler, fn($z)=>$z['durum']==='zimmetli'));
    $iade_zimmet  = count(array_filter($zimmetler, fn($z)=>$z['durum']==='iade'));
    ?>
    <!-- Özet sayaçlar -->
    <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
      <div style="background:#D1FADF;border-radius:var(--r);padding:8px 14px;font-size:12px;font-weight:700;color:#0A8F4E">
        ✓ Zimmetli: <?php echo $aktif_zimmet; ?>
      </div>
      <div style="background:#E0F2FE;border-radius:var(--r);padding:8px 14px;font-size:12px;font-weight:700;color:#0284C7">
        ↩ İade Alınan: <?php echo $iade_zimmet; ?>
      </div>
    </div>
    <table class="tablo">
      <thead>
        <tr>
          <th>Kalem</th>
          <th>Seri No</th>
          <th>Miktar</th>
          <th>Teslim Tarihi</th>
          <th>İade Tarihi</th>
          <th>Durum</th>
          <th>İşlem</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($zimmetler as $z):
        $zdr = $zimmet_durum_renk[$z['durum']] ?? ['bg'=>'#F4F5F7','renk'=>'#667085','ikon'=>'?','etiket'=>$z['durum']];
        $satir_stil = $z['durum']==='iade' ? 'opacity:.7' : '';
      ?>
      <tr style="<?php echo $satir_stil; ?>">
        <td>
          <div style="font-weight:700"><?php echo htmlspecialchars($z['kalem']); ?></div>
          <?php if ($z['notlar']): ?>
          <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars(mb_substr($z['notlar'],0,50)); ?></div>
          <?php endif; ?>
        </td>
        <td style="font-size:12px;color:var(--m2);font-family:monospace"><?php echo htmlspecialchars($z['seri_no'] ?? '—'); ?></td>
        <td><?php echo $z['miktar']; ?> <?php echo htmlspecialchars($z['birim']); ?></td>
        <td style="font-size:12px"><?php echo tarih_goster($z['teslim_tarihi']); ?></td>
        <td style="font-size:12px;color:#0284C7"><?php echo $z['iade_tarihi'] ? tarih_goster($z['iade_tarihi']) : '—'; ?></td>
        <td>
          <span class="roz" style="background:<?php echo $zdr['bg']; ?>;color:<?php echo $zdr['renk']; ?>">
            <?php echo $zdr['ikon']; ?> <?php echo $zdr['etiket']; ?>
          </span>
        </td>
        <td>
          <?php if ($z['durum']==='zimmetli' && Auth::yetkiKontrol('ik','duzenle')): ?>
          <button class="btn btn-sm btn-b" onclick="zimmetIade(<?php echo $z['id']; ?>)" title="İade Al">↩ İade Al</button>
          <?php elseif ($z['durum']==='iade'): ?>
          <span style="font-size:11px;color:var(--m3)">✓ Tamamlandı</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- ═══════ İZİN SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-izin">
  <div class="kart">
    <div class="kart-ust">
      <div class="kart-bas">🏖 İzin Geçmişi</div>
      <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-izinler" class="btn btn-b btn-sm">Tüm İzinler</a>
    </div>
    <!-- İzin bakiye çubuğu -->
    <div style="background:var(--bg);border-radius:var(--r);padding:14px;margin-bottom:14px;display:flex;gap:24px;flex-wrap:wrap">
      <div style="text-align:center"><div style="font-size:28px;font-weight:800;color:var(--t)"><?php echo $izin_bakiye; ?></div><div style="font-size:11px;color:var(--m2)">Toplam Hak</div></div>
      <div style="text-align:center"><div style="font-size:28px;font-weight:800;color:var(--bas)"><?php echo $izin_bakiye - $kullanan_gun; ?></div><div style="font-size:11px;color:var(--m2)">Kalan</div></div>
      <div style="text-align:center"><div style="font-size:28px;font-weight:800;color:var(--mavi)"><?php echo $kullanan_gun; ?></div><div style="font-size:11px;color:var(--m2)">Kullanılan</div></div>
      <div style="flex:1;display:flex;align-items:center">
        <div style="width:100%;height:8px;background:var(--kenar);border-radius:4px;overflow:hidden">
          <div style="width:<?php echo $izin_bakiye>0?round($kullanan_gun/$izin_bakiye*100):0; ?>%;height:100%;background:var(--mavi);border-radius:4px"></div>
        </div>
      </div>
    </div>
    <?php if (empty($izinler)): ?>
    <div style="padding:20px;text-align:center;color:var(--m2)">İzin kaydı yok</div>
    <?php else: ?>
    <table class="tablo">
      <thead><tr><th>İzin Türü</th><th>Başlangıç</th><th>Bitiş</th><th>Gün</th><th>Durum</th></tr></thead>
      <tbody>
      <?php
      $izDurum = ['bekliyor'=>['#FEF0C7','#B45309'],'onaylandi'=>['#D1FADF','#0A8F4E'],'reddedildi'=>['#FEE4E2','#F04438'],'iptal'=>['#F4F5F7','#667085']];
      $turler=['yillik'=>'Yıllık','hastalik'=>'Hastalık','mazeret'=>'Mazeret','ucretsiz'=>'Ücretsiz','dogum'=>'Doğum','olum'=>'Vefat'];
      foreach ($izinler as $iz):
        $idr = $izDurum[$iz['durum']] ?? ['#F4F5F7','#667085'];
      ?>
      <tr>
        <td><?php echo $turler[$iz['izin_turu']] ?? $iz['izin_turu']; ?></td>
        <td><?php echo tarih_goster($iz['baslangic']); ?></td>
        <td><?php echo tarih_goster($iz['bitis']); ?></td>
        <td style="font-weight:700;color:var(--t)"><?php echo $iz['gun_sayisi']; ?> gün</td>
        <td><span class="roz" style="background:<?php echo $idr[0]; ?>;color:<?php echo $idr[1]; ?>"><?php echo ucfirst($iz['durum']); ?></span></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<!-- ═══════ PORTAL SEKMESİ ═══════ -->
<div class="profil-panel" id="pp-portal">
  <?php
  $portal_aktif   = (int)($p['portal_durum'] ?? $p['portal_aktif'] ?? 1);
  $sifre_degisti  = (int)($p['sifre_degistirildi'] ?? 0);
  $portal_kul_adi = $p['portal_kul_adi'] ?? $p['sicil_no'];
  $son_giris      = $p['portal_son_giris'] ? date('d.m.Y H:i', strtotime($p['portal_son_giris'])) : null;
  ?>
  <!-- Ana erişim durum kartı -->
  <div id="portalDurumKart" style="border-radius:var(--r-lg);border:2px solid <?php echo $portal_aktif ? '#12B76A' : '#F04438'; ?>;background:<?php echo $portal_aktif ? '#F0FFF4' : '#FFF0F0'; ?>;padding:20px;margin-bottom:14px;display:flex;align-items:center;gap:20px;flex-wrap:wrap">
    <div style="width:56px;height:56px;border-radius:14px;background:<?php echo $portal_aktif ? '#D1FADF' : '#FEE4E2'; ?>;display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0" id="portalDurumIkon">
      <?php echo $portal_aktif ? '🔓' : '🔒'; ?>
    </div>
    <div style="flex:1">
      <div style="font-size:18px;font-weight:800;color:<?php echo $portal_aktif ? '#0A8F4E' : '#F04438'; ?>" id="portalDurumYazi">
        <?php echo $portal_aktif ? 'Portal Erişimi Açık' : 'Portal Erişimi Kapalı'; ?>
      </div>
      <div style="font-size:13px;color:var(--m2);margin-top:3px" id="portalDurumAlt">
        <?php if ($portal_aktif): ?>
          Personel portala giriş yapabilir
          <?php echo $son_giris ? '— Son giriş: '.$son_giris : '— Henüz giriş yapılmadı'; ?>
        <?php else: ?>
          Personelin portal erişimi engellenmiş
        <?php endif; ?>
      </div>
    </div>
    <!-- Toggle switch -->
    <div style="display:flex;flex-direction:column;align-items:center;gap:6px">
      <div id="portalToggleSwitch"
           onclick="togglePortalErisim()"
           style="width:52px;height:28px;border-radius:14px;background:<?php echo $portal_aktif ? '#12B76A' : '#D1D5DB'; ?>;cursor:pointer;position:relative;transition:background .3s;flex-shrink:0"
           title="<?php echo $portal_aktif ? 'Erişimi Kapat' : 'Erişimi Aç'; ?>">
        <div id="portalToggleKnob" style="position:absolute;top:3px;<?php echo $portal_aktif ? 'right:3px' : 'left:3px'; ?>;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 2px 4px rgba(0,0,0,.2);transition:all .3s"></div>
      </div>
      <span id="portalToggleEtiket" style="font-size:10px;font-weight:700;color:<?php echo $portal_aktif ? '#12B76A' : '#9CA3AF'; ?>"><?php echo $portal_aktif ? 'AÇ​IK' : 'KAPALI'; ?></span>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <!-- Sol: bilgiler -->
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📋 Hesap Bilgileri</div></div>
      <div class="bilgi-grid">
        <div class="bilgi-sat">
          <span class="bilgi-k">Kullanıcı Adı</span>
          <span class="bilgi-v" style="font-family:monospace;font-size:15px;font-weight:800;color:var(--t);background:var(--t-a);padding:3px 8px;border-radius:5px">
            <?php echo htmlspecialchars($portal_kul_adi); ?>
          </span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Erişim Durumu</span>
          <span id="portalErişimRoz" class="roz" style="background:<?php echo $portal_aktif ? '#D1FADF' : '#FEE4E2'; ?>;color:<?php echo $portal_aktif ? '#0A8F4E' : '#F04438'; ?>">
            <?php echo $portal_aktif ? '✓ Aktif — Giriş Yapabilir' : '✗ Pasif — Giriş Yapamaz'; ?>
          </span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Şifre Durumu</span>
          <span class="roz" style="background:<?php echo $sifre_degisti ? '#D1FADF' : '#FEF0C7'; ?>;color:<?php echo $sifre_degisti ? '#0A8F4E' : '#B45309'; ?>">
            <?php echo $sifre_degisti ? '✓ Kullanıcı şifresini değiştirdi' : '⚠️ İlk şifre henüz değiştirilmedi'; ?>
          </span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Son Giriş</span>
          <span class="bilgi-v"><?php echo $son_giris ?? 'Henüz giriş yapılmadı'; ?></span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Portal URL</span>
          <a href="<?php echo BASE_URL; ?>/portal/personel/giris.php" target="_blank" style="font-size:12px;color:var(--t)">portal/personel/giris.php ↗</a>
        </div>
      </div>
    </div>

    <!-- Sağ: işlemler -->
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">⚙️ Portal İşlemleri</div></div>
      <div style="display:flex;flex-direction:column;gap:10px">

        <!-- Erişim toggle butonu -->
        <button id="portalErisimBtn" onclick="togglePortalErisim()"
          style="display:flex;align-items:center;gap:12px;padding:13px 16px;border-radius:var(--r-lg);border:2px solid <?php echo $portal_aktif ? '#FCA5A5' : '#86EFAC'; ?>;background:<?php echo $portal_aktif ? '#FFF0F0' : '#F0FFF4'; ?>;cursor:pointer;font-family:inherit;transition:all .2s;width:100%">
          <span style="font-size:22px"><?php echo $portal_aktif ? '🔒' : '🔓'; ?></span>
          <div style="text-align:left">
            <div style="font-size:13px;font-weight:700;color:<?php echo $portal_aktif ? '#F04438' : '#12B76A'; ?>"><?php echo $portal_aktif ? 'Erişimi Kapat' : 'Erişimi Aç'; ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo $portal_aktif ? 'Personel portala giremez' : 'Personel portala girebilir'; ?></div>
          </div>
        </button>

        <!-- Şifre sıfırla -->
        <button onclick="portalSifreReset()"
          style="display:flex;align-items:center;gap:12px;padding:13px 16px;border-radius:var(--r-lg);border:2px solid var(--kenar);background:var(--bg);cursor:pointer;font-family:inherit;transition:all .2s;width:100%"
          onmouseover="this.style.borderColor='var(--t)'" onmouseout="this.style.borderColor='var(--kenar)'">
          <span style="font-size:22px">🔑</span>
          <div style="text-align:left">
            <div style="font-size:13px;font-weight:700;color:var(--m)">Şifre Sıfırla</div>
            <div style="font-size:11px;color:var(--m2)">Yeni tek kullanımlık şifre oluştur</div>
          </div>
        </button>

        <!-- Portale git -->
        <a href="<?php echo BASE_URL; ?>/portal/personel/giris.php" target="_blank"
          style="display:flex;align-items:center;gap:12px;padding:13px 16px;border-radius:var(--r-lg);border:2px solid var(--kenar);background:var(--bg);cursor:pointer;font-family:inherit;transition:all .2s;text-decoration:none"
          onmouseover="this.style.borderColor='var(--mavi)'" onmouseout="this.style.borderColor='var(--kenar)'">
          <span style="font-size:22px">↗️</span>
          <div style="text-align:left">
            <div style="font-size:13px;font-weight:700;color:var(--m)">Personel Portalını Aç</div>
            <div style="font-size:11px;color:var(--m2)">Yeni sekmede aç</div>
          </div>
        </a>
      </div>
    </div>
  </div>

  <!-- ── ERP PANELİ ERİŞİM BÖLÜMÜ ── -->
  <?php
  // Bu personelin ERP kullanıcısı var mı?
  $erp_kul = null;
  try {
      $per_email = $p['email'] ?? '';
      $stmt_erp = $db->prepare("SELECT id,email,rol_id,durum,son_giris,sifre_degistirildi FROM kullanicilar WHERE email=? LIMIT 1");
      $stmt_erp->execute([$per_email]);
      $erp_kul = $stmt_erp->fetch();
      // Email bulunamazsa sicil tabanlı e-posta dene
      if (!$erp_kul) {
          $sicil_email = strtolower(str_replace('-','.',$p['sicil_no']??'')) . '@jetone.pro';
          $stmt_erp->execute([$sicil_email]);
          $erp_kul = $stmt_erp->fetch();
      }
      // Rol adını al
      if ($erp_kul) {
          $rol_stmt = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
          $rol_stmt->execute([$erp_kul['rol_id']]);
          $erp_kul['rol_adi'] = $rol_stmt->fetchColumn() ?: '—';
      }
  } catch (Exception $e) { $erp_kul = null; }
  ?>

  <div style="margin-top:14px;border:2px solid <?php echo $erp_kul ? '#BFDBFE' : '#E4E7EC'; ?>;border-radius:var(--r-lg);overflow:hidden">

    <!-- Başlık -->
    <div style="background:<?php echo $erp_kul ? '#EFF6FF' : '#F9FAFB'; ?>;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid <?php echo $erp_kul ? '#BFDBFE' : '#E4E7EC'; ?>">
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:20px"><?php echo $erp_kul ? '🖥️' : '🚫'; ?></span>
        <div>
          <div style="font-size:14px;font-weight:700;color:<?php echo $erp_kul ? '#1D4ED8' : '#374151'; ?>">ERP Yönetim Paneli Erişimi</div>
          <div style="font-size:12px;color:var(--m2)"><?php echo $erp_kul ? 'Bu personelin ERP hesabı mevcut' : 'Bu personelin ERP hesabı bulunmuyor'; ?></div>
        </div>
      </div>
      <?php if ($erp_kul): ?>
      <span class="roz" style="background:<?php echo $erp_kul['durum'] ? '#D1FADF' : '#FEE4E2'; ?>;color:<?php echo $erp_kul['durum'] ? '#0A8F4E' : '#F04438'; ?>">
        <?php echo $erp_kul['durum'] ? '✓ Aktif' : '✗ Pasif'; ?>
      </span>
      <?php else: ?>
      <span class="roz" style="background:#F3F4F6;color:#6B7280">Hesap Yok</span>
      <?php endif; ?>
    </div>

    <?php if ($erp_kul): ?>
    <!-- ERP Hesap Bilgileri -->
    <div style="padding:16px 18px;display:grid;grid-template-columns:1fr 1fr;gap:14px">
      <div class="bilgi-grid">
        <div class="bilgi-sat">
          <span class="bilgi-k">E-posta</span>
          <span class="bilgi-v" style="font-family:monospace;font-size:13px;font-weight:700;color:#1D4ED8">
            <?php echo htmlspecialchars($erp_kul['email']); ?>
          </span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Rol</span>
          <span class="roz" style="background:#EFF6FF;color:#1D4ED8"><?php echo htmlspecialchars($erp_kul['rol_adi']); ?></span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Şifre Durumu</span>
          <span class="roz" style="background:<?php echo ($erp_kul['sifre_degistirildi']??1) ? '#D1FADF' : '#FEF0C7'; ?>;color:<?php echo ($erp_kul['sifre_degistirildi']??1) ? '#0A8F4E' : '#B45309'; ?>">
            <?php echo ($erp_kul['sifre_degistirildi']??1) ? '✓ Değiştirildi' : '⚠️ İlk Şifre'; ?>
          </span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">Son Giriş</span>
          <span class="bilgi-v"><?php echo $erp_kul['son_giris'] ? date('d.m.Y H:i',strtotime($erp_kul['son_giris'])) : 'Henüz giriş yapılmadı'; ?></span>
        </div>
        <div class="bilgi-sat">
          <span class="bilgi-k">ERP URL</span>
          <a href="<?php echo BASE_URL; ?>/giris.php" target="_blank" style="font-size:12px;color:#2563EB">giris.php ↗</a>
        </div>
      </div>
      <!-- ERP İşlemleri -->
      <div style="display:flex;flex-direction:column;gap:8px">
        <button onclick="erpSifreReset(<?php echo $erp_kul['id']; ?>)"
          style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:var(--r);border:1.5px solid #BFDBFE;background:#EFF6FF;cursor:pointer;font-family:inherit;transition:all .2s;width:100%;text-align:left"
          onmouseover="this.style.borderColor='#2563EB'" onmouseout="this.style.borderColor='#BFDBFE'">
          <span style="font-size:18px">🔑</span>
          <div>
            <div style="font-size:12px;font-weight:700;color:#1D4ED8">ERP Şifre Sıfırla</div>
            <div style="font-size:11px;color:var(--m2)">Yeni geçici şifre oluştur</div>
          </div>
        </button>
        <button onclick="erpErisimToggleBtn(<?php echo $erp_kul['id']; ?>, <?php echo $erp_kul['durum']; ?>)"
          id="erpDurumBtn"
          style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:var(--r);border:1.5px solid <?php echo $erp_kul['durum'] ? '#FCA5A5' : '#86EFAC'; ?>;background:<?php echo $erp_kul['durum'] ? '#FFF0F0' : '#F0FFF4'; ?>;cursor:pointer;font-family:inherit;transition:all .2s;width:100%;text-align:left"
          onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
          <span style="font-size:18px"><?php echo $erp_kul['durum'] ? '🔒' : '🔓'; ?></span>
          <div>
            <div style="font-size:12px;font-weight:700;color:<?php echo $erp_kul['durum'] ? '#F04438' : '#12B76A'; ?>"><?php echo $erp_kul['durum'] ? 'Erişimi Kapat' : 'Erişimi Aç'; ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo $erp_kul['durum'] ? 'ERP girişini engelle' : 'ERP girişine izin ver'; ?></div>
          </div>
        </button>
        <a href="<?php echo BASE_URL; ?>/giris.php" target="_blank"
          style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:var(--r);border:1.5px solid var(--kenar);background:var(--bg);cursor:pointer;font-family:inherit;transition:all .2s;text-decoration:none"
          onmouseover="this.style.borderColor='#2563EB'" onmouseout="this.style.borderColor='var(--kenar)'">
          <span style="font-size:18px">↗️</span>
          <div>
            <div style="font-size:12px;font-weight:700;color:var(--m)">ERP Panelini Aç</div>
            <div style="font-size:11px;color:var(--m2)">Yeni sekmede</div>
          </div>
        </a>
      </div>
    </div>
    <?php else: ?>
    <!-- ERP Hesabı Yok — Oluştur -->
    <div style="padding:20px 18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
      <div style="font-size:13px;color:var(--m2)">Bu personel için ERP paneli hesabı oluşturabilirsiniz.</div>
      <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personel-duzenle&id=<?php echo $id; ?>" class="btn btn-b btn-sm">
        + ERP Erişimi Ver
      </a>
    </div>
    <?php endif; ?>
  </div>
</div>

</div><!-- s-body -->

<!-- ═══════ BELGE ÖNİZLEME MODALI ═══════ -->
<div id="onizleModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)onizleKapat()">
  <div class="modal" style="max-width:860px;width:95vw">
    <div class="modal-header">
      <div><div class="modal-baslik" id="onizleBaslik">Belge Görüntüle</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-b btn-sm" onclick="document.getElementById('onizleModal').querySelector('iframe,img').src && window.open(document.getElementById('onizleModal').querySelector('iframe')?.src || document.getElementById('onizleModal').querySelector('img')?.src,'_blank')" title="Yeni sekmede aç">↗</button>
        <button class="modal-kapat" onclick="onizleKapat()">✕</button>
      </div>
    </div>
    <div class="modal-body" style="padding:16px">
      <div id="onizleIcerik" style="min-height:200px;display:flex;align-items:center;justify-content:center"></div>
    </div>
  </div>
</div>

<!-- ═══════ ÇIKIŞ MODALI ═══════ -->
<div id="cikisModal" class="modal-overlay" style="display:none">
  <div class="modal" style="max-width:480px">
    <div class="modal-header" style="background:linear-gradient(135deg,#FEE4E2,var(--yuzey))">
      <div><div class="modal-baslik" style="color:var(--hat)">🚪 İşten Çıkış İşlemi</div><div class="modal-alt"><?php echo goster($p['ad'].' '.$p['soyad']); ?></div></div>
      <button class="modal-kapat" onclick="document.getElementById('cikisModal').style.display='none'">✕</button>
    </div>
    <div class="modal-body">
      <div style="background:#FEE4E2;border-radius:var(--r);padding:10px 14px;margin-bottom:14px;font-size:13px;color:var(--hat)">
        ⚠️ Bu işlem personelin durumunu "Ayrıldı" olarak güncelleyecek ve portal erişimini kapatacaktır.
      </div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Çıkış Tarihi <span class="zorunlu">*</span></label>
          <input type="date" class="form-alan" id="cikisTarihi" value="<?php echo date('Y-m-d'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Ayrılış Nedeni <span class="zorunlu">*</span></label>
          <select class="form-alan" id="cikisNedeni">
            <option value="">— Seçin —</option>
            <?php foreach(['İstifa','Sözleşme Sona Ermesi','Emeklilik','İşveren Feshi','Anlaşmalı Fesih','Askerlik','Vefat','Diğer'] as $n): ?>
            <option value="<?php echo $n; ?>"><?php echo $n; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup form-span-2">
          <label class="form-et">Açıklama / Not</label>
          <textarea class="form-alan" id="cikisAciklama" rows="2" placeholder="İhbar süresi, kıdem tazminatı durumu..."></textarea>
        </div>
        <div class="form-grup form-span-2">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" id="cikisPortalKapat" checked style="accent-color:var(--hat);width:15px;height:15px">
            Portal erişimini kapat
          </label>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-b" onclick="document.getElementById('cikisModal').style.display='none'">İptal</button>
      <button class="btn" style="background:var(--hat);color:#fff" onclick="cikisKaydet()">🚪 Çıkışı Kaydet</button>
    </div>
  </div>
</div>

<!-- ═══════ BELGE EKLE MODALI ═══════ -->
<div id="belgeModal" class="modal-overlay" style="display:none">
  <div class="modal" style="max-width:440px">
    <div class="modal-header"><div><div class="modal-baslik">📄 Belge Ekle</div></div><button class="modal-kapat" onclick="document.getElementById('belgeModal').style.display='none'">✕</button></div>
    <div class="modal-body">
      <?php
      // Mevcut belgeler — tamamlanan işaretle
      $mevcutBelgeAdlari = array_column($belgeler, 'belge_adi');
      $belgeListesi = [
        'kisisel'     => ['Nüfus Cüzdanı Fotokopisi','İkametgah Belgesi','Vesikalık Fotoğraf','Adli Sicil Kaydı'],
        'egitim'      => ['Diploma Fotokopisi','Sertifika','Özgeçmiş (CV)'],
        'is_iliskisi' => ['İş Sözleşmesi','SGK İşe Giriş Bildirgesi','Aile Durum Bildirim Formu','Askerlik Durum Belgesi'],
        'saglik'      => ['Sağlık Raporu','İSG Eğitim Belgesi','İSG Taahhütnamesi'],
        'is_sureci'   => ['Zimmet Formu','İşe Giriş Oryantasyon Tutanağı','Gizlilik Sözleşmesi','Performans Değerlendirmesi'],
        'ayrilik'     => ['İşten Ayrılış Bildirgesi','İbraname','İstifa Dilekçesi','Kıdem Tazminatı Belgesi'],
      ];
      ?>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Kategori</label>
          <select class="form-alan" id="belgeKat" onchange="belgeleriniGuncelle()">
            <option value="kisisel">👤 Kişisel</option>
            <option value="egitim">🎓 Eğitim</option>
            <option value="is_iliskisi">📋 İş İlişkisi</option>
            <option value="saglik">🏥 Sağlık</option>
            <option value="is_sureci">⚙️ İş Süreci</option>
            <option value="ayrilik">🚪 Ayrılış</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Geçerlilik Tarihi</label>
          <input type="date" class="form-alan" id="belgeGecerlilik">
        </div>
        <div class="form-grup form-span-2">
          <label class="form-et">Belge Adı <span class="zorunlu">*</span></label>
          <select class="form-alan" id="belgeAdi" onchange="belgeSecimiDegisti()">
            <option value="">— Belge Seçin —</option>
            <?php foreach ($belgeListesi['kisisel'] as $b): ?>
            <option value="<?php echo htmlspecialchars($b); ?>" data-kat="kisisel"
              <?php echo in_array($b,$mevcutBelgeAdlari)?'style="color:var(--bas)"':''; ?>>
              <?php echo in_array($b,$mevcutBelgeAdlari)?'✓ ':''; ?><?php echo htmlspecialchars($b); ?>
            </option>
            <?php endforeach; ?>
          </select>
          <!-- Özel belge adı (seçeneklerde yoksa) -->
          <input type="text" class="form-alan" id="belgeAdiOzel"
                 placeholder="Veya buraya yazın..."
                 style="margin-top:6px"
                 style="display:none;margin-top:6px" oninput="if(this.value) document.getElementById('belgeAdi').value=''">
        </div>
      </div>
      <!-- Tüm belgeler JSON — JS için -->
      <script>
      var BELGE_LISTESI = <?php echo json_encode($belgeListesi, JSON_UNESCAPED_UNICODE); ?>;
      var MEVCUT_BELGELER = <?php echo json_encode($mevcutBelgeAdlari, JSON_UNESCAPED_UNICODE); ?>;
      </script>
      <!-- Dosya yükleme alanı -->
      <div class="form-grup">
        <label class="form-et">Dosya Yükle <span style="font-size:11px;color:var(--m2);font-weight:400">(PDF, JPG, PNG — max 10MB)</span></label>
        <div id="dosyaAlani" onclick="document.getElementById('belgeDosya').click()"
             style="border:2px dashed var(--kenar);border-radius:var(--r);padding:20px;text-align:center;cursor:pointer;transition:all .15s;background:var(--bg)"
             onmouseover="this.style.borderColor='var(--t)';this.style.background='var(--t-a)'"
             onmouseout="this.style.borderColor='var(--kenar)';this.style.background='var(--bg)'">
          <div style="font-size:28px;margin-bottom:6px">📎</div>
          <div id="dosyaMetin" style="font-size:13px;color:var(--m2)">Dosya seçmek için tıklayın veya sürükleyin</div>
          <div style="font-size:11px;color:var(--m3);margin-top:3px">PDF • JPG • PNG • max 10MB</div>
        </div>
        <input type="file" id="belgeDosya" accept=".pdf,.jpg,.jpeg,.png" style="display:none"
               onchange="dosyaSecildi(this)">
      </div>
      <div class="form-grup">
        <label class="form-et">Notlar</label>
        <textarea class="form-alan" id="belgeNot" rows="2" placeholder="İsteğe bağlı açıklama..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-b" onclick="belgModalKapat()">İptal</button>
      <button class="btn btn-t" id="belgeKaydetBtn" onclick="belgeYukle()">💾 Kaydet</button>
    </div>
  </div>
</div>

<!-- ═══════ ZİMMET EKLE MODALI ═══════ -->
<div id="zimmetModal" class="modal-overlay" style="display:none">
  <div class="modal" style="max-width:440px">
    <div class="modal-header"><div><div class="modal-baslik">📦 Zimmet Ekle</div></div><button class="modal-kapat" onclick="document.getElementById('zimmetModal').style.display='none'">✕</button></div>
    <div class="modal-body">
      <div class="form-grid-2">
        <div class="form-grup form-span-2">
          <label class="form-et">Kalem / Ürün Adı <span class="zorunlu">*</span></label>
          <input type="text" class="form-alan" id="zimmetKalem" placeholder="Örn: Laptop, İş Kıyafeti, Kart">
        </div>
        <div class="form-grup">
          <label class="form-et">Seri No</label>
          <input type="text" class="form-alan" id="zimmetSeri">
        </div>
        <div class="form-grup">
          <label class="form-et">Teslim Tarihi</label>
          <input type="date" class="form-alan" id="zimmetTarih" value="<?php echo date('Y-m-d'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Miktar</label>
          <input type="number" class="form-alan" id="zimmetMiktar" value="1" min="1">
        </div>
        <div class="form-grup">
          <label class="form-et">Birim</label>
          <select class="form-alan" id="zimmetBirim">
            <option>adet</option><option>çift</option><option>takım</option><option>paket</option>
          </select>
        </div>
        <div class="form-grup form-span-2">
          <label class="form-et">Notlar</label>
          <textarea class="form-alan" id="zimmetNot" rows="2"></textarea>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-b" onclick="document.getElementById('zimmetModal').style.display='none'">İptal</button>
      <button class="btn btn-t" onclick="zimmetKaydet()">💾 Kaydet</button>
    </div>
  </div>
</div>

<style>
.kpi-k{background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:14px;display:flex;flex-direction:column;gap:6px}
.kpi-ikon{width:38px;height:38px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px}
.kpi-val{font-size:20px;font-weight:800;letter-spacing:-.5px}
.kpi-et{font-size:12px;color:var(--m2)}
.profil-sekme-nav{display:flex;gap:2px;background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:6px;margin-bottom:14px;overflow-x:auto;flex-wrap:nowrap}
.ps{padding:8px 14px;border:none;background:none;cursor:pointer;border-radius:var(--r);font-size:13px;font-weight:600;color:var(--m2);transition:all .15s;white-space:nowrap;font-family:inherit}
.ps:hover{background:var(--kenar-a);color:var(--m)}
.ps.aktif{background:var(--t);color:#fff}
.profil-panel{display:none}
.profil-panel.aktif{display:block;animation:gir .2s ease}
@keyframes gir{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.bilgi-grid{display:flex;flex-direction:column;gap:0}
.bilgi-sat{display:flex;align-items:flex-start;padding:7px 0;border-bottom:1px solid var(--kenar);font-size:13px}
.bilgi-sat:last-child{border-bottom:none}
.bilgi-k{width:130px;flex-shrink:0;color:var(--m2);font-size:12.5px}
.bilgi-v{flex:1;font-weight:600;color:var(--m);word-break:break-word}
.form-grid-2 .form-span-2{grid-column:span 2}
</style>

<script>
var PERSONEL_ID = <?php echo $id; ?>;

// Sekme geçişleri
function profilSekme(id, btn) {
  document.querySelectorAll('.profil-panel').forEach(function(p){ p.classList.remove('aktif'); });
  document.querySelectorAll('.ps').forEach(function(b){ b.classList.remove('aktif'); });
  document.getElementById('pp-'+id).classList.add('aktif');
  btn.classList.add('aktif');
}

// Menü kapat (dışına tıklama)
document.addEventListener('click', function(e) {
  var menu = document.getElementById('islemMenu');
  if (menu && !e.target.closest('[onclick*="islemMenu"]') && !menu.contains(e.target)) {
    menu.style.display = 'none';
  }
});

// İşten Çıkış
function cikisModalAc() {
  document.getElementById('cikisModal').style.display = 'flex';
  document.getElementById('islemMenu').style.display = 'none';
}

function cikisKaydet() {
  var tarih  = document.getElementById('cikisTarihi').value;
  var neden  = document.getElementById('cikisNedeni').value;
  var aciklama = document.getElementById('cikisAciklama').value;
  var portal = document.getElementById('cikisPortalKapat').checked ? 1 : 0;

  if (!tarih || !neden) { alert('Çıkış tarihi ve nedeni zorunludur.'); return; }

  var btn = event.target;
  btn.disabled = true; btn.textContent = '⏳ Kaydediliyor...';

  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-cikis.php',
    {id: PERSONEL_ID, cikis_tarihi: tarih, cikis_nedeni: neden, aciklama: aciklama, portal_kapat: portal}
  ).then(function(r) {
    if (r.ok) {
      JT.bildirim(r.mesaj || 'Çıkış işlemi kaydedildi.', 'basari');
      setTimeout(function(){ location.reload(); }, 1500);
    } else {
      btn.disabled=false; btn.textContent='🚪 Çıkışı Kaydet';
      JT.bildirim(r.hata || 'Hata oluştu', 'hata');
    }
  });
}

// Portal şifre sıfırla
function portalSifreReset() {
  if (!confirm('Portal şifresi sıfırlanacak. Yeni şifre size gösterilecek. Onaylıyor musunuz?')) return;
  document.getElementById('islemMenu').style.display = 'none';
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-portal-islem.php',
    {id: PERSONEL_ID, islem: 'sifre_sifirla'}
  ).then(function(r) {
    if (r.ok) {
      alert('✅ Yeni şifre: ' + r.yeni_sifre + '\n\nPersonele bildirin. İlk girişte değiştirmesi gerekecek.');
      location.reload();
    } else { JT.bildirim(r.hata || 'Hata', 'hata'); }
  });
}

// Portal erişim aç/kapat — sayfa yenilemeden canlı güncelleme
function togglePortalErisim() {
  var menu = document.getElementById('islemMenu');
  if (menu) menu.style.display = 'none';

  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-portal-islem.php',
    {id: PERSONEL_ID, islem: 'toggle_erisim'}
  ).then(function(r) {
    if (!r.ok) { JT.bildirim(r.hata || 'Hata', 'hata'); return; }

    var aktif = r.aktif;  // true = açık, false = kapalı

    // ── Büyük durum kartı ──
    var kart  = document.getElementById('portalDurumKart');
    var ikon  = document.getElementById('portalDurumIkon');
    var yazi  = document.getElementById('portalDurumYazi');
    var alt   = document.getElementById('portalDurumAlt');

    if (kart) {
      kart.style.border = '2px solid ' + (aktif ? '#12B76A' : '#F04438');
      kart.style.background = aktif ? '#F0FFF4' : '#FFF0F0';
    }
    if (ikon) {
      ikon.style.background = aktif ? '#D1FADF' : '#FEE4E2';
      ikon.textContent = aktif ? '🔓' : '🔒';
    }
    if (yazi) {
      yazi.style.color = aktif ? '#0A8F4E' : '#F04438';
      yazi.textContent = aktif ? 'Portal Erişimi Açık' : 'Portal Erişimi Kapalı';
    }
    if (alt) {
      alt.textContent = aktif
        ? 'Personel portala giriş yapabilir'
        : 'Personelin portal erişimi engellenmiş';
    }

    // ── Toggle switch ──
    var sw    = document.getElementById('portalToggleSwitch');
    var knob  = document.getElementById('portalToggleKnob');
    var etiket= document.getElementById('portalToggleEtiket');
    if (sw)  { sw.style.background = aktif ? '#12B76A' : '#D1D5DB'; }
    if (knob) {
      if (aktif) { knob.style.right='3px'; knob.style.left='auto'; }
      else       { knob.style.left='3px';  knob.style.right='auto'; }
    }
    if (etiket) {
      etiket.style.color = aktif ? '#12B76A' : '#9CA3AF';
      etiket.textContent = aktif ? 'AÇIK' : 'KAPALI';
    }

    // ── Rozet ──
    var roz = document.getElementById('portalErişimRoz');
    if (roz) {
      roz.style.background = aktif ? '#D1FADF' : '#FEE4E2';
      roz.style.color      = aktif ? '#0A8F4E' : '#F04438';
      roz.textContent      = aktif ? '✓ Aktif — Giriş Yapabilir' : '✗ Pasif — Giriş Yapamaz';
    }

    // ── İşlem butonu ──
    var btn = document.getElementById('portalErisimBtn');
    if (btn) {
      btn.style.borderColor = aktif ? '#FCA5A5' : '#86EFAC';
      btn.style.background  = aktif ? '#FFF0F0' : '#F0FFF4';
      btn.querySelector('span').textContent = aktif ? '🔒' : '🔓';
      var divler = btn.querySelectorAll('div');
      if (divler[0]) {
        divler[0].style.color  = aktif ? '#F04438' : '#12B76A';
        divler[0].textContent  = aktif ? 'Erişimi Kapat' : 'Erişimi Aç';
      }
      if (divler[1]) {
        divler[1].textContent = aktif ? 'Personel portala giremez' : 'Personel portala girebilir';
      }
    }

    JT.bildirim(r.mesaj, 'basari');
  });
}

// Belge ekle
function belgeEkleModal() {
  document.getElementById('belgeModal').style.display = 'flex';
  belgeleriniGuncelle(); // Kategori başlangıç listesi
}

// Kategori değişince select'i güncelle
function belgeleriniGuncelle() {
  var kat = document.getElementById('belgeKat').value;
  var sel = document.getElementById('belgeAdi');
  var liste = BELGE_LISTESI[kat] || [];

  sel.innerHTML = '<option value="">— Belge Seçin —</option>';
  liste.forEach(function(b) {
    var tamam = MEVCUT_BELGELER.indexOf(b) !== -1;
    var opt = document.createElement('option');
    opt.value = b;
    opt.textContent = (tamam ? '✓ ' : '') + b;
    if (tamam) opt.style.color = 'var(--bas)';
    sel.appendChild(opt);
  });
  sel.innerHTML += '<option value="__ozel__">✏️ Diğer / Özel ad...</option>';
}

// Selectbox değişince
function belgeSecimiDegisti() {
  var sel  = document.getElementById('belgeAdi');
  var ozel = document.getElementById('belgeAdiOzel');
  if (sel.value === '__ozel__') {
    ozel.style.display = 'block';
    ozel.focus();
    sel.value = '';
  } else if (sel.value) {
    ozel.style.display = 'none';
    ozel.value = '';
  }
}

function belgModalKapat() {
  document.getElementById('belgeModal').style.display = 'none';
  document.getElementById('belgeDosya').value = '';
  document.getElementById('belgeAdi').value = '';
  document.getElementById('belgeAdiOzel').value = '';
  document.getElementById('dosyaMetin').textContent = 'Dosya seçmek için tıklayın veya sürükleyin';
  document.getElementById('dosyaAlani').style.borderColor = 'var(--kenar)';
  document.getElementById('dosyaAlani').style.background = 'var(--bg)';
}

function dosyaSecildi(inp) {
  if (!inp.files || !inp.files[0]) return;
  var f = inp.files[0];
  var maxMB = 10;
  if (f.size > maxMB * 1024 * 1024) {
    alert('Dosya ' + maxMB + 'MB sınırını aşıyor.');
    inp.value = ''; return;
  }
  document.getElementById('dosyaMetin').innerHTML = '✅ <b>' + f.name + '</b> (' + (f.size/1024/1024).toFixed(2) + ' MB)';
  document.getElementById('dosyaAlani').style.borderColor = 'var(--bas)';
  document.getElementById('dosyaAlani').style.background = '#F0FFF4';
  // Belge adı boşsa dosya adından özel alana doldur
  var selectEl = document.getElementById('belgeAdi');
  var ozelEl   = document.getElementById('belgeAdiOzel');
  if (!selectEl.value && !ozelEl.value) {
    ozelEl.value = f.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  }
}

function belgeYukle() {
  var selectVal = document.getElementById('belgeAdi').value.trim();
  var ozelVal   = document.getElementById('belgeAdiOzel').value.trim();
  var adi = ozelVal || selectVal;
  if (!adi) { alert('Lütfen listeden bir belge seçin veya belge adı yazın.'); return; }

  var btn = document.getElementById('belgeKaydetBtn');
  btn.disabled = true; btn.textContent = '⏳ Yükleniyor...';

  var formData = new FormData();
  formData.append('personel_id', PERSONEL_ID);
  formData.append('kategori',    document.getElementById('belgeKat').value);
  formData.append('belge_adi',   adi);
  formData.append('gecerlilik',  document.getElementById('belgeGecerlilik').value);
  formData.append('notlar',      document.getElementById('belgeNot').value);
  var dosyaInp = document.getElementById('belgeDosya');
  if (dosyaInp.files && dosyaInp.files[0]) {
    formData.append('dosya', dosyaInp.files[0]);
  }

  fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-belge-yukle.php', {
    method: 'POST',
    headers: {'X-Requested-With': 'XMLHttpRequest'},
    body: formData
  })
  .then(function(r){ return r.json(); })
  .then(function(r) {
    btn.disabled = false; btn.textContent = '💾 Kaydet';
    if (r.ok) {
      JT.bildirim('Belge kaydedildi!', 'basari');
      belgModalKapat();
      setTimeout(function(){ location.reload(); }, 800);
    } else { JT.bildirim(r.hata || 'Hata', 'hata'); }
  })
  .catch(function(e) {
    btn.disabled = false; btn.textContent = '💾 Kaydet';
    JT.bildirim('Bağlantı hatası', 'hata');
  });
}

function belgeSil(id) {
  if (!confirm('Bu belgeyi silmek istediğinize emin misiniz?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-belge-sil.php', {id: id}).then(function(r) {
    if (r.ok) { JT.bildirim('Belge silindi.', 'basari'); setTimeout(function(){ location.reload(); }, 800); }
    else { JT.bildirim(r.hata, 'hata'); }
  });
}

// Zimmet ekle
function zimmetEkleModal() { document.getElementById('zimmetModal').style.display = 'flex'; }

function zimmetKaydet() {
  var kalem = document.getElementById('zimmetKalem').value.trim();
  if (!kalem) { alert('Kalem adı zorunlu.'); return; }
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-zimmet-kaydet.php', {
    personel_id: PERSONEL_ID,
    kalem: kalem,
    seri_no: document.getElementById('zimmetSeri').value,
    teslim_tarihi: document.getElementById('zimmetTarih').value,
    miktar: document.getElementById('zimmetMiktar').value,
    birim: document.getElementById('zimmetBirim').value,
    notlar: document.getElementById('zimmetNot').value
  }).then(function(r) {
    if (r.ok) { JT.bildirim('Zimmet eklendi!', 'basari'); setTimeout(function(){ location.reload(); }, 1000); }
    else { JT.bildirim(r.hata || 'Hata', 'hata'); }
  });
}

function zimmetIade(id) {
  if (!confirm('Bu zimmet iade alındı olarak işaretlensin mi?\n\nKayıt silinmeyecek, "İade Alındı" olarak görünecektir.')) return;

  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-zimmet-iade.php', {id: id}).then(function(r) {
    if (!r.ok) { JT.bildirim(r.hata || 'Hata', 'hata'); return; }

    // Butonu bul ve satırı canlı güncelle — sayfa yenilemek yerine
    var btn = document.querySelector('button[onclick*="zimmetIade(' + id + ')"]');
    if (btn) {
      var tr = btn.closest('tr');
      if (tr) {
        // Durum rozeti güncelle
        var rozEl = tr.querySelector('.roz');
        if (rozEl) {
          rozEl.style.background = '#E0F2FE';
          rozEl.style.color = '#0284C7';
          rozEl.textContent = '↩ İade Alındı';
        }
        // İade tarihi sütununu güncelle
        var tdler = tr.querySelectorAll('td');
        if (tdler[4]) tdler[4].textContent = r.iade_tarihi || 'Bugün';

        // Satırı soluklaştır
        tr.style.opacity = '0.7';

        // Butonu "Tamamlandı" olarak değiştir
        btn.outerHTML = '<span style="font-size:11px;color:var(--m3)">✓ Tamamlandı</span>';
      }
    }

    JT.bildirim(r.mesaj || 'İade kaydedildi.', 'basari');
  });
}

// Personel silme YASAK
function personelSil() {
  alert('⛔ Personel kaydı silinemez.\n\nYasal zorunluluk gereği:\n• SGK: 10 yıl\n• İSG: 15 yıl\n• Vergi: 5 yıl\n\n"İşten Çıkış" işlemi kullanın.');
}

// ── ERP Şifre Sıfırla ─────────────────────────────────
function erpSifreReset(erpKulId) {
  if (!confirm('ERP şifresi sıfırlanacak. Yeni şifre gösterilecek. Onaylıyor musunuz?')) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',
    {islem: 'sifre_sifirla', erp_kul_id: erpKulId, personel_id: PERSONEL_ID}
  ).then(function(r) {
    if (r.ok) {
      alert('✅ Yeni ERP Şifre: ' + r.yeni_sifre + '\n\nE-posta: ' + r.email + '\n\nPersonele bildirin. İlk girişte değiştirmesi gerekecek.');
      location.reload();
    } else { JT.bildirim(r.hata || 'Hata', 'hata'); }
  });
}

// ── ERP Erişim Aç/Kapat ───────────────────────────────
function erpErisimToggleBtn(erpKulId, mevcutDurum) {
  var eylem = mevcutDurum ? 'kapat' : 'ac';
  var mesaj = mevcutDurum ? 'ERP erişimi kapatılsın mı?' : 'ERP erişimi açılsın mı?';
  if (!confirm(mesaj)) return;
  JT.ajax('<?php echo BASE_URL; ?>/bolumler/ik/ajax/erp-kullanici-islem.php',
    {islem: 'toggle_erisim', erp_kul_id: erpKulId, personel_id: PERSONEL_ID}
  ).then(function(r) {
    if (r.ok) { JT.bildirim(r.mesaj, 'basari'); setTimeout(function(){ location.reload(); }, 800); }
    else { JT.bildirim(r.hata || 'Hata', 'hata'); }
  });
}

// ── Belge Önizleme ─────────────────────────────────────
function belgeOnizle(url, ad, tip) {
  var modal = document.getElementById('onizleModal');
  var baslik = document.getElementById('onizleBaslik');
  var icerik = document.getElementById('onizleIcerik');
  if (!modal) return;

  baslik.textContent = ad;
  if (tip === 'resim') {
    icerik.innerHTML = '<img src="'+url+'" style="max-width:100%;max-height:70vh;border-radius:8px;display:block;margin:0 auto" alt="'+ad+'">';
  } else if (tip === 'pdf') {
    icerik.innerHTML = '<iframe src="'+url+'" style="width:100%;height:70vh;border:none;border-radius:8px"></iframe>';
  }
  modal.style.display = 'flex';
}

function onizleKapat() {
  var modal = document.getElementById('onizleModal');
  if (modal) {
    modal.style.display = 'none';
    document.getElementById('onizleIcerik').innerHTML = '';
  }
}

// ── Finansal Gizle/Göster ──────────────────────────────
var finansalGorunur = false;
var GERCEK_MAAS = '₺<?php echo number_format($p["maas"]??0, 0, ",", "."); ?>';

function finansalToggle() {
  finansalGorunur = !finansalGorunur;
  var maskeli  = document.getElementById('finansalMaskeli');
  var gercek   = document.getElementById('finansalGercek');
  var gozIkon  = document.getElementById('gozIkon');
  var gozYazi  = document.getElementById('gozYazi');
  var kpiVal   = document.getElementById('kpiMaasVal');
  var kpiGoz   = document.getElementById('kpiGozBtn');

  if (finansalGorunur) {
    if (maskeli) maskeli.style.display = 'none';
    if (gercek)  gercek.style.display  = 'flex';
    if (gercek)  gercek.style.flexDirection = 'column';
    if (gozIkon) gozIkon.textContent  = '👁';
    if (gozYazi) gozYazi.textContent  = 'Gizle';
    if (kpiVal)  kpiVal.textContent   = GERCEK_MAAS;
    if (kpiGoz)  kpiGoz.textContent   = '👁';
  } else {
    if (maskeli) maskeli.style.display = 'flex';
    if (maskeli) maskeli.style.flexDirection = 'column';
    if (gercek)  gercek.style.display  = 'none';
    if (gozIkon) gozIkon.textContent  = '🙈';
    if (gozYazi) gozYazi.textContent  = 'Göster';
    if (kpiVal)  kpiVal.textContent   = '₺ •••••';
    if (kpiGoz)  kpiGoz.textContent   = '🙈';
  }
}
</script>


<!-- BORDROLAR PANEL -->
<div class="profil-panel" id="pp-bordrolar">
  <div class="kart">
    <div class="kart-ust" style="display:flex;align-items:center;justify-content:space-between">
      <div class="kart-bas">Bordrolar</div>
      <button onclick="profilBordroYukleModal()" style="background:var(--t);color:#fff;border:none;padding:8px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Bordro Yukle</button>
    </div>
    <div id="profilBordroListe" style="padding:8px 0">
      <p style="color:var(--m2);text-align:center;padding:20px">Yukleniyor...</p>
    </div>
  </div>
</div>

<div id="profilYukleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:16px;width:min(440px,100%);box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <h3 style="font-size:15px;font-weight:800">Bordro Yukle</h3>
      <button onclick="document.getElementById('profilYukleModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">X</button>
    </div>
    <div style="padding:22px">
      <input type="hidden" id="profilBordroPerId" value="<?php echo $id; ?>">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <div>
          <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:5px">AY</label>
          <select id="profilBordroAy" style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:14px">
            <?php for($bm=1;$bm<=12;$bm++): $bn=['','Ocak','Subat','Mart','Nisan','Mayis','Haziran','Temmuz','Agustos','Eylul','Ekim','Kasim','Aralik'][$bm]; ?><option value="<?php echo $bm; ?>" <?php echo $bm==date('n')?'selected':''; ?>><?php echo $bn; ?></option><?php endfor; ?>
          </select>
        </div>
        <div>
          <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:5px">YIL</label>
          <select id="profilBordroYil" style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:14px">
            <?php for($by=date('Y');$by>=(date('Y')-3);$by--): ?><option value="<?php echo $by; ?>"><?php echo $by; ?></option><?php endfor; ?>
          </select>
        </div>
      </div>
      <div style="margin-bottom:16px">
        <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:5px">PDF</label>
        <input type="file" id="profilBordroDosya" accept=".pdf" style="width:100%;padding:10px;border:2px dashed var(--kenar);border-radius:8px;font-family:inherit;font-size:13px;box-sizing:border-box">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <button type="button" onclick="document.getElementById('profilYukleModal').style.display='none'" style="padding:12px;background:var(--bg);border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Iptal</button>
        <button type="button" onclick="profilBordroGonder()" id="profilYukBtn" style="padding:12px;background:var(--t);color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Yukle</button>
      </div>
    </div>
  </div>
</div>

<script>
var PROFIL_PER_ID = <?php echo (int)$id; ?>;
var PROFIL_BASE = '<?php echo BASE_URL; ?>';

function profilBordroYukle() {
  fetch(PROFIL_BASE+'/bolumler/ik/ajax/profil-bordro-listesi.php?personel_id='+PROFIL_PER_ID, {credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){
      var el = document.getElementById('profilBordroListe');
      if (!el) return;
      if (!r.ok || !r.bordrolar || !r.bordrolar.length) {
        el.innerHTML = '<p style="color:var(--m2);text-align:center;padding:20px">Henuz bordro yuklenmemis</p>';
        return;
      }
      var html = '<table class="tablo"><thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)"><tr><th>Ay/Yil</th><th>Dosya</th><th>Tarih</th><th style="width:80px;text-align:center">Islem</th></tr></thead><tbody>';
      r.bordrolar.forEach(function(b) {
        html += '<tr><td style="font-weight:700">'+b.ay_yil+'</td>'
          +'<td><a href="'+b.url+'" target="_blank" style="color:#1D4ED8;font-weight:600;font-size:13px">'+b.dosya_adi+'</a></td>'
          +'<td style="font-size:12px;color:var(--m2)">'+b.tarih+'</td>'
          +'<td style="text-align:center"><button onclick="profilBordroSil('+b.id+')" style="width:28px;height:28px;border-radius:6px;background:#FEE2E2;color:#EF4444;border:none;cursor:pointer;font-size:13px">X</button></td></tr>';
      });
      html += '</tbody></table>';
      el.innerHTML = html;
    }).catch(function(){ document.getElementById('profilBordroListe').innerHTML='<p style="color:red;padding:20px">Yuklenemedi</p>'; });
}
function profilBordroYukleModal() { document.getElementById('profilYukleModal').style.display='flex'; }
function profilBordroGonder() {
  var btn=document.getElementById('profilYukBtn');
  var dosya=document.getElementById('profilBordroDosya').files[0];
  if (!dosya) { alert('PDF secin'); return; }
  var fd=new FormData();
  fd.append('personel_id',PROFIL_PER_ID);
  fd.append('ay',document.getElementById('profilBordroAy').value);
  fd.append('yil',document.getElementById('profilBordroYil').value);
  fd.append('bordro_pdf',dosya);
  btn.disabled=true; btn.textContent='Yukleniyor...';
  fetch(PROFIL_BASE+'/bolumler/ik/ajax/bordro-yukle.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){
      btn.disabled=false; btn.textContent='Yukle';
      if(r.ok){document.getElementById('profilYukleModal').style.display='none';document.getElementById('profilBordroDosya').value='';profilBordroYukle();}
      else{alert('Hata: '+(r.hata||'?'));}
    }).catch(function(){btn.disabled=false;btn.textContent='Yukle';});
}
function profilBordroSil(id) {
  if (!confirm('Silinsin mi?')) return;
  fetch(PROFIL_BASE+'/bolumler/ik/ajax/profil-bordro-sil.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:id})})
    .then(function(r){return r.json();}).then(function(r){ if(r.ok) profilBordroYukle(); });
}
document.addEventListener('DOMContentLoaded',function(){
  var _o=window.profilSekme;
  if(typeof _o==='function'){
    window.profilSekme=function(id,el){_o(id,el);if(id==='bordrolar')profilBordroYukle();};
  }
});
</script>
