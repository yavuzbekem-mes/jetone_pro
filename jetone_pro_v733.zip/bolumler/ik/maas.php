<?php
/**
 * İK — Fazla Mesai Kayıtları
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','goruntule')) { echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>'; return; }

$ay   = (int)($_GET['ay']   ?? date('n'));
$yil  = (int)($_GET['yil']  ?? date('Y'));
$dept = (int)($_GET['dept'] ?? 0);
$aylar=['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];

// Fazla mesai = 8 saati aşan çalışma (devam_kayitlari'ndan hesapla)
// Normal mesai: 08:00–16:00 = 8 saat; fazla = calisma_suresi - 8
try {
    $deptlar = $db->query("SELECT id,ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();

    // Beyaz yaka için 10 saat, diğerleri için 8 saat eşiği
    $where = ["MONTH(dk.tarih)=?","YEAR(dk.tarih)=?","dk.durum='geldi'",
              "dk.calisma_suresi > IF(p.vardiya_tipi='beyaz', 10, 8)"];
    $params = [$ay,$yil];
    if ($dept) { $where[]="p.departman_id=?"; $params[]=$dept; }
    $w = implode(' AND ',$where);

    $q=$db->prepare("SELECT dk.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no, p.brut_maas,
        d.ad dept_adi, p.vardiya_tipi, (dk.calisma_suresi - 8) AS fazla_sure
        FROM devam_kayitlari dk
        JOIN personeller p ON dk.personel_id=p.id
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE $w ORDER BY dk.tarih DESC, p.ad");
    $q->execute($params); $kayitlar=$q->fetchAll();

    // Personel bazlı özet
    $perOzet=[];
    foreach($kayitlar as $k){
        $pid=$k['personel_id'];
        if(!isset($perOzet[$pid])){
            $perOzet[$pid]=['per_adi'=>$k['per_adi'],'sicil_no'=>$k['sicil_no'],'dept_adi'=>$k['dept_adi'],'brut_maas'=>(float)$k['brut_maas'],'toplam_fazla'=>0,'gun_say'=>0];
        }
        $perOzet[$pid]['toplam_fazla']+=(float)$k['fazla_sure'];
        $perOzet[$pid]['gun_say']++;
    }

    // Saat ücret hesabı (Brüt / 225 = saatlik ücret)
    $toplam_fazla_saat = array_sum(array_column($kayitlar,'fazla_sure'));
    $toplam_odeme = 0;
    foreach($perOzet as &$po){
        $saatlik = $po['brut_maas'] > 0 ? $po['brut_maas'] / 225 : 0;
        $po['saat_ucreti'] = round($saatlik,2);
        $po['fazla_odeme'] = round($saatlik * $po['toplam_fazla'] * 1.5, 2); // %50 fazla mesai zammı
        $toplam_odeme += $po['fazla_odeme'];
    }
} catch(Throwable $e){ $kayitlar=[]; $perOzet=[]; $toplam_fazla_saat=0; $toplam_odeme=0; $deptlar=[]; }
?>
<div class="s-bar">
  <div><h1 class="s-bas">⏰ Fazla Mesai</h1><div class="s-yol">İnsan Kaynakları / <b>Fazla Mesai</b></div></div>
  <div style="display:flex;align-items:center;gap:8px">
    <div id="dt-toolbar-dt-mesai" style="display:inline-flex;align-items:center;gap:6px"></div>
    <button onclick="dtExcelIndir('dt-mesai','FazlaMesai',{tip:'mesai'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;display:inline-flex;align-items:center;gap:5px">📊 Excel</button>
  </div>
</div>
<div class="s-body">
  <!-- Özet kartlar -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px">
    <div style="background:#FEF3E8;border-radius:12px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:900;color:#B45309"><?php echo count($kayitlar); ?></div><div style="font-size:11px;font-weight:700;color:#B45309">Fazla Mesai Günü</div></div>
    <div style="background:#DBEAFE;border-radius:12px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:900;color:#1E40AF"><?php echo count($perOzet); ?></div><div style="font-size:11px;font-weight:700;color:#1E40AF">Personel</div></div>
    <div style="background:#D1FAE5;border-radius:12px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:900;color:#065F46"><?php echo number_format($toplam_fazla_saat,1); ?></div><div style="font-size:11px;font-weight:700;color:#065F46">Toplam Saat</div></div>
    <div style="background:#F3E8FF;border-radius:12px;padding:16px;text-align:center"><div style="font-size:24px;font-weight:900;color:#6D28D9">₺<?php echo number_format($toplam_odeme,0,'.',','); ?></div><div style="font-size:11px;font-weight:700;color:#6D28D9">Tahmini Ödeme</div></div>
  </div>
  <!-- Filtreler -->
  <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
    <input type="hidden" name="sayfa" value="ik-mesai">
    <select name="ay" class="form-alan" style="width:110px" onchange="this.form.submit()"><?php for($m=1;$m<=12;$m++):?><option value="<?php echo $m; ?>" <?php echo $m==$ay?'selected':''; ?>><?php echo $aylar[$m]; ?></option><?php endfor;?></select>
    <select name="yil" class="form-alan" style="width:90px" onchange="this.form.submit()"><?php for($y=date('Y');$y>=date('Y')-3;$y--):?><option value="<?php echo $y; ?>" <?php echo $y==$yil?'selected':''; ?>><?php echo $y; ?></option><?php endfor;?></select>
    <select name="dept" class="form-alan" style="width:160px" onchange="this.form.submit()"><option value="0">Tüm Departmanlar</option><?php foreach($deptlar as $d):?><option value="<?php echo $d['id']; ?>" <?php echo $d['id']==$dept?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option><?php endforeach;?></select>
  </form>

  <!-- Personel Özet Tablosu -->
  <?php if(!empty($perOzet)):?>
  <div class="kart" style="margin-bottom:16px;overflow:hidden">
    <div class="kart-ust"><div class="kart-bas">👥 Personel Özeti — <?php echo $aylar[$ay]; ?> <?php echo $yil; ?></div></div>
    <div style="overflow-y:auto;max-height:280px"><div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 300px)"><table class="tablo" id="dt-mesai">
      <thead style="position:sticky;top:0;z-index:2"><tr><th>Personel</th><th>Departman</th><th style="text-align:center">Gün</th><th style="text-align:center">Toplam Saat</th><th style="text-align:right">Saatlik Ücret</th><th style="text-align:right">Fazla Mesai Ödeme (%50)</th></tr></thead>
      <tbody>
        <?php foreach($perOzet as $po):?>
        <tr>
          <td><div style="font-weight:700"><?php echo htmlspecialchars($po['per_adi']); ?></div><div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($po['sicil_no']??''); ?></div></td>
          <td style="font-size:12px"><?php echo htmlspecialchars($po['dept_adi']??'—'); ?></td>
          <td style="text-align:center"><span style="background:#FEF3E8;color:#B45309;font-size:12px;font-weight:700;padding:2px 10px;border-radius:10px"><?php echo $po['gun_say']; ?></span></td>
          <td style="text-align:center;font-weight:700;color:#1E40AF"><?php echo number_format($po['toplam_fazla'],1); ?> sa</td>
          <td style="text-align:right;font-size:12px;color:var(--m2)">₺<?php echo number_format($po['saat_ucreti'],2); ?></td>
          <td style="text-align:right;font-weight:800;color:#6D28D9">₺<?php echo number_format($po['fazla_odeme'],2,'.',','); ?></td>
        </tr>
        <?php endforeach;?>
        <tr style="background:#F9FAFB;font-weight:800">
          <td colspan="3">TOPLAM</td>
          <td style="text-align:center;color:#1E40AF"><?php echo number_format($toplam_fazla_saat,1); ?> sa</td>
          <td></td>
          <td style="text-align:right;color:#6D28D9">₺<?php echo number_format($toplam_odeme,2,'.',','); ?></td>
        </tr>
      </tbody>
    </table></div>
  </div>
  <?php endif;?>

  <!-- Detay Kayıtlar -->
  <div class="kart" style="overflow:hidden">
    <div class="kart-ust"><div class="kart-bas">📋 Günlük Detay</div></div>
    <table class="tablo">
      <thead style="position:sticky;top:0;z-index:2"><tr><th>Personel</th><th>Tarih</th><th>Giriş</th><th>Çıkış</th><th style="text-align:center">Normal Süre</th><th style="text-align:center">Fazla Mesai</th></tr></thead>
      <tbody>
        <?php foreach($kayitlar as $k):?>
        <tr>
          <td><div style="font-weight:700"><?php echo htmlspecialchars($k['per_adi']); ?></div><div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($k['dept_adi']??''); ?></div></td>
          <td style="font-size:13px"><?php echo date('d.m.Y D',strtotime($k['tarih'])); ?></td>
          <td style="font-family:monospace;font-weight:700"><?php echo $k['giris_saati']?date('H:i',strtotime($k['giris_saati'])):'—'; ?></td>
          <td style="font-family:monospace;font-weight:700"><?php echo $k['cikis_saati']?date('H:i',strtotime($k['cikis_saati'])):'—'; ?></td>
          <td style="text-align:center"><?php echo ($k['vardiya_tipi']??'')==='beyaz'?'10.0 sa':'8.0 sa'; ?></td>
          <td style="text-align:center"><span style="background:#F3E8FF;color:#6D28D9;font-size:12px;font-weight:800;padding:3px 10px;border-radius:10px">+<?php echo number_format($k['fazla_sure'],1); ?> sa</span></td>
        </tr>
        <?php endforeach;?>
        <?php if(empty($kayitlar)):?><tr><td colspan="6" style="text-align:center;padding:30px;color:var(--m2)">Bu ay fazla mesai kaydı bulunamadı.</td></tr><?php endif;?>
      </tbody>
    </table>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-mesai');});
</script>