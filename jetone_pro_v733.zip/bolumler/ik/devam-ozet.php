<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$tarih = $_GET['tarih'] ?? date('Y-m-d');
$tarih = date('Y-m-d', strtotime($tarih)); // sanitize

// Önceki / sonraki gün
$onceki = date('Y-m-d', strtotime($tarih.' -1 day'));
$sonraki = date('Y-m-d', strtotime($tarih.' +1 day'));
$bugun = date('Y-m-d');

$gun_tr = ['Mon'=>'Pazartesi','Tue'=>'Salı','Wed'=>'Çarşamba','Thu'=>'Perşembe','Fri'=>'Cuma','Sat'=>'Cumartesi','Sun'=>'Pazar'];
$gun_adi = $gun_tr[date('D', strtotime($tarih))] ?? '';

// Tüm aktif personel
$tum_personel = [];
$devam_kayitlari = [];
$vardiya_ozet = [];

try {
    // Aktif personel + vardiya tipi
    $tum_personel = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, p.sicil_no,
        p.vardiya_tipi, p.aktif_vardiya, d.ad dept_adi
        FROM personeller p
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.durum='aktif'
        ORDER BY p.vardiya_tipi, p.aktif_vardiya, p.ad")->fetchAll();

    // O günün devam kayıtları
    $dq = $db->prepare("SELECT dk.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no,
        p.vardiya_tipi, p.aktif_vardiya, d.ad dept_adi
        FROM devam_kayitlari dk
        JOIN personeller p ON dk.personel_id=p.id
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE dk.tarih=? ORDER BY p.vardiya_tipi, p.aktif_vardiya, p.ad");
    $dq->execute([$tarih]);
    $dk_rows = $dq->fetchAll();

    // ID ile indexle
    foreach ($dk_rows as $row) {
        $devam_kayitlari[$row['personel_id']] = $row;
    }

    // Vardiya özet
    $vardiya_tanimlari = [
        'beyaz' => ['ad'=>'Beyaz Yaka', 'saat'=>'08:00–18:00', 'renk'=>'#D1FAE5', 'renk_k'=>'#065F46'],
        'tek'   => ['ad'=>'Tek Vardiya', 'saat'=>'08:00–16:00', 'renk'=>'#FEF3C7', 'renk_k'=>'#92400E'],
        '3lu_1' => ['ad'=>'1. Vardiya',  'saat'=>'08:00–16:00', 'renk'=>'#DBEAFE', 'renk_k'=>'#1E40AF'],
        '3lu_2' => ['ad'=>'2. Vardiya',  'saat'=>'16:00–00:00', 'renk'=>'#EDE9FE', 'renk_k'=>'#5B21B6'],
        '3lu_3' => ['ad'=>'3. Vardiya',  'saat'=>'00:00–08:00', 'renk'=>'#F3E8FF', 'renk_k'=>'#6D28D9'],
    ];

    foreach ($tum_personel as $per) {
        $vt = $per['vardiya_tipi'] ?? 'tek';
        $av = (int)($per['aktif_vardiya'] ?? 0);
        $v_key = ($vt === '3lu') ? "3lu_$av" : $vt;
        if (!isset($vardiya_ozet[$v_key])) {
            $vd = $vardiya_tanimlari[$v_key] ?? ['ad'=>ucfirst($vt),'saat'=>'','renk'=>'#F3F4F6','renk_k'=>'#374151'];
            $vardiya_ozet[$v_key] = array_merge($vd, ['toplam'=>0,'geldi'=>0,'gelmedi'=>0,'izinli'=>0,'gecikti'=>0,'personeller'=>[]]);
        }
        $dk = $devam_kayitlari[$per['id']] ?? null;
        $durum = $dk ? $dk['durum'] : 'gelmedi';
        $vardiya_ozet[$v_key]['toplam']++;
        if (isset($vardiya_ozet[$v_key][$durum])) $vardiya_ozet[$v_key][$durum]++;
        $vardiya_ozet[$v_key]['personeller'][] = array_merge($per, ['dk'=>$dk, 'dk_durum'=>$durum]);
    }

} catch(Throwable $e) {}

// Genel özet
$toplam_personel = count($tum_personel);
$toplam_geldi    = count(array_filter($devam_kayitlari, function($d){ return $d['durum']==='geldi'; }));
$toplam_gelmedi  = count(array_filter($devam_kayitlari, function($d){ return $d['durum']==='gelmedi'; }));
$toplam_gecikti  = count(array_filter($devam_kayitlari, function($d){ return $d['durum']==='gecikti'; }));
$toplam_izinli   = count(array_filter($devam_kayitlari, function($d){ return $d['durum']==='izinli'; }));
$toplam_kayitsiz = $toplam_personel - count($devam_kayitlari);
?>
<div class="s-bar">
  <div><h1 class="s-bas">📊 Günlük Devam Özeti</h1><div class="s-yol">İnsan Kaynakları / <b>Günlük Özet</b></div></div>
  <button onclick="dtExcelIndir('ozet-tablo','GunlukDevamOzeti')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Tarih navigasyonu -->
<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
  <a href="?sayfa=ik-devam-ozet&tarih=<?php echo $onceki; ?>" style="background:var(--kart);border:1.5px solid var(--kenar);border-radius:8px;width:38px;height:38px;display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:18px;color:var(--m)">◀</a>
  <div style="flex:1;text-align:center">
    <div style="font-size:18px;font-weight:900"><?php echo $gun_adi.', '.date('d',strtotime($tarih)).' '.['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'][(int)date('m',strtotime($tarih))].' '.date('Y',strtotime($tarih)); ?></div>
    <?php if ($tarih === $bugun): ?><div style="font-size:11px;color:#F97316;font-weight:700">● BUGÜN</div><?php endif; ?>
  </div>
  <a href="?sayfa=ik-devam-ozet&tarih=<?php echo $sonraki; ?>" style="background:var(--kart);border:1.5px solid var(--kenar);border-radius:8px;width:38px;height:38px;display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:18px;color:var(--m)">▶</a>
  <input type="date" value="<?php echo $tarih; ?>" onchange="location.href='?sayfa=ik-devam-ozet&tarih='+this.value" class="form-alan" style="width:150px">
  <?php if ($tarih !== $bugun): ?><a href="?sayfa=ik-devam-ozet" style="font-size:12px;color:var(--t);font-weight:700;text-decoration:none">Bugüne Dön →</a><?php endif; ?>
</div>

<!-- Genel özet -->
<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:16px">
  <?php foreach([
    ['Toplam Personel', $toplam_personel, '👥', '#F3F4F6', '#374151'],
    ['Geldi', $toplam_geldi, '✅', '#D1FAE5', '#065F46'],
    ['Gelmedi', $toplam_gelmedi + $toplam_kayitsiz, '❌', '#FEE2E2', '#991B1B'],
    ['Geç Geldi', $toplam_gecikti, '⚠️', '#FEF3C7', '#B45309'],
    ['İzinli', $toplam_izinli, '🏖', '#FEF3C7', '#92400E'],
    ['Kayıt Yok', $toplam_kayitsiz, '❓', '#F1F5F9', '#64748B'],
  ] as [$et,$say,$ikon,$bg,$fg]): ?>
  <div style="background:<?php echo $bg; ?>;border-radius:12px;padding:14px;text-align:center">
    <div style="font-size:24px;font-weight:900;color:<?php echo $fg; ?>"><?php echo $say; ?></div>
    <div style="font-size:11px;font-weight:700;color:<?php echo $fg; ?>"><?php echo $ikon.' '.$et; ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Vardiyalara göre kartlar -->
<?php foreach ($vardiya_ozet as $vkey => $vo): ?>
<div class="kart" style="overflow:hidden;margin-bottom:14px">
  <!-- Vardiya başlık -->
  <div style="background:<?php echo $vo['renk']; ?>;padding:12px 16px;display:flex;align-items:center;justify-content:space-between">
    <div>
      <span style="font-size:15px;font-weight:800;color:<?php echo $vo['renk_k']; ?>"><?php echo htmlspecialchars($vo['ad']); ?></span>
      <span style="font-size:12px;color:<?php echo $vo['renk_k']; ?>;opacity:.8;margin-left:8px;font-family:monospace"><?php echo $vo['saat']; ?></span>
    </div>
    <div style="display:flex;gap:12px;font-size:12px;font-weight:700">
      <span style="color:#065F46">✅ <?php echo $vo['geldi']; ?> Geldi</span>
      <span style="color:#991B1B">❌ <?php echo ($vo['gelmedi'] + ($vo['toplam'] - $vo['geldi'] - $vo['gelmedi'] - $vo['izinli'] - $vo['gecikti'])); ?> Gelmedi</span>
      <?php if ($vo['gecikti']): ?><span style="color:#B45309">⚠️ <?php echo $vo['gecikti']; ?> Geç</span><?php endif; ?>
      <?php if ($vo['izinli']): ?><span style="color:#92400E">🏖 <?php echo $vo['izinli']; ?> İzin</span><?php endif; ?>
      <span style="color:<?php echo $vo['renk_k']; ?>;opacity:.7"><?php echo $vo['toplam']; ?> toplam</span>
    </div>
  </div>

  <!-- İlerleme çubuğu -->
  <?php $pct = $vo['toplam'] > 0 ? round($vo['geldi'] / $vo['toplam'] * 100) : 0; ?>
  <div style="height:4px;background:#E5E7EB">
    <div style="height:4px;background:#10B981;width:<?php echo $pct; ?>%;transition:width .3s"></div>
  </div>

  <!-- Personel listesi -->
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="ozet-tablo">
    <thead><tr>
      <th>Personel</th><th>Departman</th>
      <th style="width:75px;text-align:center">Giriş</th>
      <th style="width:75px;text-align:center">Çıkış</th>
      <th style="width:70px;text-align:center">Süre</th>
      <th style="width:110px">Durum</th>
    </tr></thead>
    <tbody>
    <?php foreach ($vo['personeller'] as $per):
      $dk = $per['dk'];
      $dur = $per['dk_durum'];
      $dr_map = ['geldi'=>['✅','#D1FAE5','#065F46','Geldi'],
                 'gelmedi'=>['❌','#FEE2E2','#991B1B','Gelmedi'],
                 'izinli'=>['🏖','#FEF3C7','#92400E','İzinli'],
                 'gecikti'=>['⚠️','#FEF3C7','#B45309','Geç Geldi'],
                 'eksik'=>['❓','#F3F4F6','#6B7280','Eksik']];
      [$ikon,$bg,$fg,$lbl] = $dk ? ($dr_map[$dur] ?? ['❓','#F3F4F6','#6B7280','?']) : ['—','#F1F5F9','#94A3B8','Kayıt Yok'];
    ?>
    <tr style="<?php echo !$dk?'opacity:.6':''; ?>">
      <td style="white-space:nowrap">
        <span style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($per['ad_soyad']); ?></span>
        <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo htmlspecialchars($per['sicil_no']??''); ?></span>
      </td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($per['dept_adi']??'—'); ?></td>
      <td style="text-align:center;font-family:monospace;font-weight:700;color:#065F46">
        <?php echo $dk&&$dk['giris_saati']?date('H:i',strtotime($dk['giris_saati'])):'—'; ?>
      </td>
      <td style="text-align:center;font-family:monospace;font-weight:700;color:#991B1B">
        <?php echo $dk&&$dk['cikis_saati']?date('H:i',strtotime($dk['cikis_saati'])):'—'; ?>
      </td>
      <td style="text-align:center;font-size:12px;font-weight:700">
        <?php echo $dk&&$dk['calisma_suresi']?number_format($dk['calisma_suresi'],1).'s':'—'; ?>
      </td>
      <td>
        <span style="background:<?php echo $bg; ?>;color:<?php echo $fg; ?>;font-size:11px;font-weight:700;padding:3px 8px;border-radius:20px">
          <?php echo $ikon.' '.$lbl; ?>
        </span>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endforeach; ?>

<?php if (empty($vardiya_ozet)): ?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m2)">
  <div style="font-size:32px;margin-bottom:8px">👥</div>
  <div>Aktif personel bulunamadı.</div>
</div>
<?php endif; ?>

</div>
