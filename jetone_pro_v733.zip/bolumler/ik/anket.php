<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

// Tüm yanıtlar
try {
    $yanitlar = $db->query("SELECT ay.*, pk.ad_soyad portal_adi, p.ad, p.soyad, d.ad dept_adi
        FROM anket_yanitlar ay
        LEFT JOIN portal_kullanicilari pk ON ay.portal_kul_id = pk.id
        LEFT JOIN personeller p ON pk.ilgili_id = p.id
        LEFT JOIN departmanlar d ON p.departman_id = d.id
        ORDER BY ay.olusturma DESC")->fetchAll();
    $toplam = count($yanitlar);

    // Aylık memnuniyet hesapla
    $aylik_veri = [];
    $tum_soru_k = ['a1','a2','a3','a4','a5','a6','a7',
        'b8','b9','b10','b11','b12','b13','b14','b15','b16','b17','b18','b19','b20','b21','b22','b23',
        'c24','c25','c26','c27','c28','c29','c30'];
    foreach ($yanitlar as $y) {
        $ay_key = date('Y-m', strtotime($y['olusturma']));
        if (!isset($aylik_veri[$ay_key])) $aylik_veri[$ay_key] = ['toplam'=>0,'puan_toplam'=>0,'katilim'=>0];
        $vals = array_filter(array_map(function($k) use ($y){ return (int)($y[$k]??0); }, $tum_soru_k), function($v){ return $v > 0; });
        if (count($vals) > 0) {
            $aylik_veri[$ay_key]['puan_toplam'] += array_sum($vals) / count($vals);
            $aylik_veri[$ay_key]['katilim']++;
        }
    }
    foreach ($aylik_veri as $k => &$v) {
        $v['ort'] = $v['katilim'] > 0 ? round($v['puan_toplam'] / $v['katilim'], 2) : 0;
        $v['yuzde'] = (int)round(($v['ort'] / 4) * 100);
    }
    unset($v);
    ksort($aylik_veri);
} catch (Throwable $e) { $yanitlar = []; $toplam = 0; $aylik_veri = []; }

// Tüm sorular
$sorular = [
    'A' => [
        'a1'=>'Yönetim çalışanların fikir ve önerilerine önem vermektedir',
        'a2'=>'İdari personelin çalışanlara karşı tutum ve davranışları olumludur',
        'a3'=>'Sosyal etkinlikler yeterlidir',
        'a4'=>'Sağlık hizmetleri yeterlidir',
        'a5'=>'Çalışanlar fikirleriyle alınan kararlara katılmaktadır',
        'a6'=>'Çalışanlara haklarını kullanma fırsatları sunulmaktadır',
        'a7'=>'Firma içinde çalışanların güvenliği sağlanmaktadır',
    ],
    'B' => [
        'b8'=>'Yemekler kalitelidir (tadı, temizliği, görünümü)',
        'b9'=>'Yemek çeşitleri (menüsü) uygundur',
        'b10'=>'Yemekhanenin fiziki koşulları uygundur',
        'b11'=>'Personel maaşı ve mesaileri zamanında yatırılmaktadır',
        'b12'=>'Personel servis araçları yeterli sayıdadır',
        'b13'=>'Servis şoförleri araçları trafik kurallarına uygun kullanmaktadır',
        'b14'=>'Personel servis araçlarının içi temiz ve bakımlıdır',
        'b15'=>'Servis araçlarının modelleri ve tipleri uygundur',
        'b16'=>'Servis araçları düzenli olarak duraklara gelmektedir',
        'b17'=>'Duş, tuvalet ve lavabolar yeterli sayıdadır',
        'b18'=>'Duş, tuvalet ve lavaboların bakım ve temizlikleri yeterlidir',
        'b19'=>'Çalışma ortamı/alanı düzenli ve temizdir',
        'b20'=>'Çalışılan yerlerin aydınlatılması yeterlidir',
        'b21'=>'İşletme içinde ısıtma yeterlidir',
        'b22'=>'İşletme içinde havalandırma yeterlidir',
        'b23'=>'İş sağlığı ve güvenliği KKD\'leri yeterlidir',
    ],
    'C' => [
        'c24'=>'Firmada verilen eğitimler öğrenmemize katkıda bulunmaktadır',
        'c25'=>'Bölüm amiri/sorumluları çalışanlara objektif davranır',
        'c26'=>'İşe başlamadan önce iş eğitimleri ve kriterler açıklanır',
        'c27'=>'Bölüm amiri/sorumlusu bana gerekli zamanı ayırmaktadır',
        'c28'=>'Belirlenen saatlerde ilgili kişilerle sorunlarımı görüşebiliyorum',
        'c29'=>'Çalışanlar yaptığı işin öneminin ve anlamının farkındadır',
        'c30'=>'Çalışanlar, kalite hedeflerinin başarılmasına katkılarının farkındadır',
    ],
];

// Her soru için ortalama hesapla
$ortalamalar = [];
$tum_anahtarlar = array_merge(array_keys($sorular['A']), array_keys($sorular['B']), array_keys($sorular['C']));
foreach ($tum_anahtarlar as $k) {
    $vals = array_filter(array_column($yanitlar, $k), function($v){ return $v !== null && $v > 0; });
    $ortalamalar[$k] = count($vals) > 0 ? round(array_sum($vals)/count($vals), 2) : null;
}

// Genel ortalama
$genel_ort = count(array_filter($ortalamalar)) > 0
    ? round(array_sum(array_filter($ortalamalar)) / count(array_filter($ortalamalar)), 2)
    : 0;
// 4 üzerinden → 100 üzerinden yüzde
$genel_yuzde = $genel_ort ? (int)round(($genel_ort / 4) * 100) : 0;

$puan_renk = function($ort) {
    if (!$ort) return ['#F3F4F6','#6B7280'];
    if ($ort >= 3.5) return ['#D1FAE5','#065F46'];
    if ($ort >= 2.5) return ['#FEF3C7','#92400E'];
    return ['#FEE2E2','#991B1B'];
};

$bolum_renk = ['A'=>'#3B82F6','B'=>'#10B981','C'=>'#8B5CF6'];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">😊 Memnuniyet Anketi Sonuçları</h1>
    <div class="s-yol">İnsan Kaynakları / <b>Anket Analizi</b></div>
  </div>

  <button onclick="dtExcelIndir('tbl-anket','Anket')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <div class="kart" style="padding:16px;text-align:center">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Toplam Katılım</div>
    <div style="font-size:32px;font-weight:900;color:var(--t)"><?php echo $toplam; ?></div>
    <div style="font-size:12px;color:var(--m2)">personel yanıtladı</div>
  </div>
  <?php
  $anonim_say = count(array_filter($yanitlar, function($y){ return $y['anonim']; }));
  $isimli_say = $toplam - $anonim_say;
  ?>
  <div class="kart" style="padding:16px;text-align:center">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Anonim</div>
    <div style="font-size:32px;font-weight:900;color:#6B7280"><?php echo $anonim_say; ?></div>
    <div style="font-size:12px;color:var(--m2)">gizli yanıt</div>
  </div>
  <div class="kart" style="padding:16px;text-align:center">
    <div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">İsimli</div>
    <div style="font-size:32px;font-weight:900;color:#2563EB"><?php echo $isimli_say; ?></div>
    <div style="font-size:12px;color:var(--m2)">kimlikli yanıt</div>
  </div>
  <?php $gc = $puan_renk($genel_ort); ?>
  <div class="kart" style="padding:16px;text-align:center;background:<?php echo $gc[0]; ?>;position:relative;overflow:hidden">
    <div style="font-size:11px;color:<?php echo $gc[1]; ?>;font-weight:700;text-transform:uppercase;margin-bottom:4px">Memnuniyet Oranı</div>
    <div style="font-size:38px;font-weight:900;color:<?php echo $gc[1]; ?>"><?php echo $genel_yuzde ?: '—'; ?><?php if($genel_yuzde): ?>%<?php endif; ?></div>
    <div style="font-size:12px;color:<?php echo $gc[1]; ?>;margin-bottom:8px"><?php echo $genel_ort ?: '—'; ?> / 4.00 puan</div>
    <?php if ($genel_yuzde): ?>
    <div style="background:rgba(0,0,0,.1);border-radius:20px;height:8px;overflow:hidden">
      <div style="width:<?php echo $genel_yuzde; ?>%;background:<?php echo $gc[1]; ?>;height:100%;border-radius:20px;transition:width 1s"></div>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($toplam === 0): ?>
<div class="kart" style="padding:40px;text-align:center;color:var(--m2)">
  <div style="font-size:48px;margin-bottom:12px">📋</div>
  <div style="font-size:16px;font-weight:700">Henüz anket yanıtı yok</div>
  <div style="font-size:13px;margin-top:6px">Personeller portal üzerinden anketi doldurdukça sonuçlar burada görünecek.</div>
</div>
<?php else: ?>

<!-- Bölüm bazlı soru ortalamaları -->
<?php foreach ($sorular as $bolum => $sorular_b):
  $bolum_adlari = ['A'=>'Bölüm A — İşletmeden Memnuniyet','B'=>'Bölüm B — Personele Sağlanan Hizmetler','C'=>'Bölüm C — Ölçme ve Değerlendirme'];
  $bolum_vals = array_filter(array_map(function($k) use ($ortalamalar){ return $ortalamalar[$k]; }, array_keys($sorular_b)));
  $bolum_ort = count($bolum_vals) > 0 ? round(array_sum($bolum_vals)/count($bolum_vals),2) : 0;
  $bc = $puan_renk($bolum_ort);
?>
<div class="kart" style="overflow:hidden;margin-bottom:14px">
  <div class="kart-ust" style="background:<?php echo $bc[0]; ?>;display:flex;justify-content:space-between;align-items:center">
    <div class="kart-bas" style="color:<?php echo $bc[1]; ?>"><?php echo $bolum_adlari[$bolum]; ?></div>
    <div style="font-size:18px;font-weight:900;color:<?php echo $bc[1]; ?>">
      <?php if($bolum_ort): echo '%'.round(($bolum_ort/4)*100).' — '; endif; ?><?php echo $bolum_ort ?: '—'; ?> / 4.00
    </div>
  </div>
  <table style="width:100%;border-collapse:collapse;font-size:13px">
    <thead>
      <tr style="background:#F9FAFB">
        <th style="padding:8px 16px;text-align:left;font-size:11px;font-weight:700;color:var(--m2);border-bottom:1px solid var(--kenar)">#</th>
        <th style="padding:8px 16px;text-align:left;font-size:11px;font-weight:700;color:var(--m2);border-bottom:1px solid var(--kenar)">SORU</th>
        <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:700;color:#EF4444;border-bottom:1px solid var(--kenar);width:70px">Az (1)</th>
        <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:700;color:#F59E0B;border-bottom:1px solid var(--kenar);width:70px">Orta (2)</th>
        <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:700;color:#3B82F6;border-bottom:1px solid var(--kenar);width:70px">İyi (3)</th>
        <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:700;color:#10B981;border-bottom:1px solid var(--kenar);width:80px">Çok İyi (4)</th>
        <th style="padding:8px 16px;text-align:center;font-size:11px;font-weight:700;color:var(--m2);border-bottom:1px solid var(--kenar);width:100px">ORTALAMA</th>
        <th style="padding:8px 16px;border-bottom:1px solid var(--kenar);width:160px"></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($sorular_b as $k => $soru_adi):
        $no = preg_replace('/[a-z]/','', $k);
        $sayilar = [1=>0,2=>0,3=>0,4=>0];
        foreach ($yanitlar as $y) { $v = (int)($y[$k]??0); if ($v >= 1 && $v <= 4) $sayilar[$v]++; }
        $cevap_say = array_sum($sayilar);
        $ort = $ortalamalar[$k];
        $rc = $puan_renk($ort);
      ?>
      <tr style="border-bottom:1px solid var(--kenar)">
        <td style="padding:10px 16px;color:var(--m2);font-weight:700"><?php echo $no; ?></td>
        <td style="padding:10px 16px;font-weight:500"><?php echo htmlspecialchars($soru_adi); ?></td>
        <?php foreach ([1,2,3,4] as $puan): $s = $sayilar[$puan]; ?>
        <td style="padding:10px 12px;text-align:center;font-weight:<?php echo $s>0?'700':'400'; ?>;color:<?php echo $s>0?'var(--m)':'var(--m2)'; ?>"><?php echo $s ?: '—'; ?></td>
        <?php endforeach; ?>
        <td style="padding:10px 16px;text-align:center">
          <?php if ($ort): ?>
          <span style="background:<?php echo $rc[0]; ?>;color:<?php echo $rc[1]; ?>;font-weight:800;padding:4px 10px;border-radius:20px;font-size:13px"><?php echo $ort; ?></span>
          <?php else: ?><span style="color:var(--m2)">—</span><?php endif; ?>
        </td>
        <td style="padding:10px 16px">
          <?php if ($cevap_say > 0):
            $bar_w = round(($ort / 4) * 100);
            $bar_renk = $ort >= 3.5 ? '#10B981' : ($ort >= 2.5 ? '#F59E0B' : '#EF4444');
          ?>
          <div style="background:var(--kenar);border-radius:4px;height:8px;overflow:hidden">
            <div style="width:<?php echo $bar_w; ?>%;background:<?php echo $bar_renk; ?>;height:100%;border-radius:4px;transition:width .3s"></div>
          </div>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endforeach; ?>

<!-- Açık uçlu yanıtlar -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="kart" style="padding:16px">
    <div class="kart-bas" style="margin-bottom:12px">😊 En Mutlu Eden Nedenler</div>
    <?php
    $mutlular = [];
    foreach ($yanitlar as $y) {
      foreach (['mutlu1','mutlu2','mutlu3'] as $mk) {
        if (!empty(trim($y[$mk]??''))) $mutlular[] = ['adi'=>$y['anonim']?'Anonim':htmlspecialchars($y['ad_soyad']??($y['portal_adi']??'?')), 'metin'=>$y[$mk]];
      }
    }
    if (empty($mutlular)): ?>
    <div style="color:var(--m2);font-size:13px;font-style:italic">Henüz yanıt yok.</div>
    <?php else: foreach (array_slice($mutlular,0,20) as $m): ?>
    <div style="padding:8px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2);font-size:11px"><?php echo $m['adi']; ?>:</span><br>
      <span style="font-weight:500"><?php echo htmlspecialchars($m['metin']); ?></span>
    </div>
    <?php endforeach; endif; ?>
  </div>
  <div class="kart" style="padding:16px">
    <div class="kart-bas" style="margin-bottom:12px">😟 En Çok Yakınılan Nedenler</div>
    <?php
    $sikayetler = [];
    foreach ($yanitlar as $y) {
      foreach (['sikayet1','sikayet2','sikayet3'] as $sk) {
        if (!empty(trim($y[$sk]??''))) $sikayetler[] = ['adi'=>$y['anonim']?'Anonim':htmlspecialchars($y['ad_soyad']??($y['portal_adi']??'?')), 'metin'=>$y[$sk]];
      }
    }
    if (empty($sikayetler)): ?>
    <div style="color:var(--m2);font-size:13px;font-style:italic">Henüz yanıt yok.</div>
    <?php else: foreach (array_slice($sikayetler,0,20) as $s): ?>
    <div style="padding:8px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2);font-size:11px"><?php echo $s['adi']; ?>:</span><br>
      <span style="font-weight:500"><?php echo htmlspecialchars($s['metin']); ?></span>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- Yanıt listesi -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust" style="display:flex;justify-content:space-between;align-items:center">
    <div class="kart-bas">Tüm Yanıtlar (<?php echo $toplam; ?>)</div>
  </div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-anket" style="width:100%">
    <thead>
      <tr>
        <th>Tarih</th><th>Personel</th><th>Departman</th>
        <th style="text-align:center">Böl. A Ort.</th>
        <th style="text-align:center">Böl. B Ort.</th>
        <th style="text-align:center">Böl. C Ort.</th>
        <th style="text-align:center">Genel</th>
        <th style="text-align:center">Detay</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($yanitlar as $y):
      $a_vals = array_filter(array_map(function($k) use ($y){ return (int)($y[$k]??0); }, array_keys($sorular['A'])), function($v){ return $v>0; });
      $b_vals = array_filter(array_map(function($k) use ($y){ return (int)($y[$k]??0); }, array_keys($sorular['B'])), function($v){ return $v>0; });
      $c_vals = array_filter(array_map(function($k) use ($y){ return (int)($y[$k]??0); }, array_keys($sorular['C'])), function($v){ return $v>0; });
      $a_ort = count($a_vals)>0 ? round(array_sum($a_vals)/count($a_vals),1) : null;
      $b_ort = count($b_vals)>0 ? round(array_sum($b_vals)/count($b_vals),1) : null;
      $c_ort = count($c_vals)>0 ? round(array_sum($c_vals)/count($c_vals),1) : null;
      $all = array_filter([$a_ort,$b_ort,$c_ort]);
      $g_ort = count($all)>0 ? round(array_sum($all)/count($all),1) : null;
      $gc2 = $puan_renk($g_ort);
      $per_adi = $y['anonim'] ? '<span style="color:var(--m2)">Anonim</span>' : htmlspecialchars($y['ad_soyad'] ?: ($y['portal_adi'] ?: 'Bilinmiyor'));
    ?>
    <tr>
      <td style="font-size:12px"><?php echo date('d.m.Y H:i',strtotime($y['olusturma'])); ?></td>
      <td><?php echo $per_adi; ?></td>
      <td style="font-size:12px"><?php echo htmlspecialchars($y['departman'] ?: ($y['dept_adi'] ?: '—')); ?></td>
      <?php foreach ([$a_ort,$b_ort,$c_ort] as $ort_v):
        $rc2 = $puan_renk($ort_v);
      ?>
      <td style="text-align:center"><span style="background:<?php echo $rc2[0]; ?>;color:<?php echo $rc2[1]; ?>;font-size:12px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $ort_v ?: '—'; ?></span></td>
      <?php endforeach; ?>
      <td style="text-align:center">
        <?php if($g_ort): $gyp = round(($g_ort/4)*100); ?>
        <span style="background:<?php echo $gc2[0]; ?>;color:<?php echo $gc2[1]; ?>;font-size:12px;font-weight:800;padding:3px 10px;border-radius:20px"><?php echo '%'.$gyp; ?></span>
        <?php else: ?>—<?php endif; ?>
      </td>
      <td style="text-align:center">
        <button onclick="detayGoster(<?php echo $y['id']; ?>)" style="background:var(--bg);border:1px solid var(--kenar);padding:3px 10px;border-radius:6px;font-size:11px;cursor:pointer;font-family:inherit">Detay</button>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<?php endif; ?>

<?php if (!empty($aylik_veri)): ?>
<!-- Aylık Memnuniyet Trendi -->
<div class="kart" style="padding:20px;margin-top:16px">
  <div class="kart-bas" style="margin-bottom:16px">📈 Aylık Memnuniyet Trendi</div>

  <!-- Bar chart -->
  <div style="display:flex;align-items:flex-end;gap:8px;height:180px;padding:0 4px;margin-bottom:12px">
    <?php
    $ay_adlari = ['01'=>'Oca','02'=>'Şub','03'=>'Mar','04'=>'Nis','05'=>'May','06'=>'Haz','07'=>'Tem','08'=>'Ağu','09'=>'Eyl','10'=>'Eki','11'=>'Kas','12'=>'Ara'];
    foreach ($aylik_veri as $ay_key => $v):
        $parts = explode('-', $ay_key);
        $ay_ad = ($ay_adlari[$parts[1]] ?? $parts[1]).' '.$parts[0];
        $yuzde = $v['yuzde'];
        if ($yuzde >= 80) { $bar_renk = '#10B981'; $bg_renk = '#D1FAE5'; }
        elseif ($yuzde >= 60) { $bar_renk = '#3B82F6'; $bg_renk = '#DBEAFE'; }
        elseif ($yuzde >= 40) { $bar_renk = '#F59E0B'; $bg_renk = '#FEF3C7'; }
        else { $bar_renk = '#EF4444'; $bg_renk = '#FEE2E2'; }
        $bar_height = max(20, round($yuzde * 1.5)); // max 150px
    ?>
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;min-width:0">
      <div style="font-size:12px;font-weight:800;color:<?php echo $bar_renk; ?>"><?php echo $yuzde; ?>%</div>
      <div style="width:100%;background:<?php echo $bg_renk; ?>;border-radius:8px 8px 0 0;height:<?php echo $bar_height; ?>px;position:relative;display:flex;align-items:flex-end;justify-content:center;overflow:hidden">
        <div style="width:100%;background:<?php echo $bar_renk; ?>;height:<?php echo $bar_height; ?>px;border-radius:8px 8px 0 0;opacity:.8"></div>
      </div>
      <div style="font-size:10px;color:var(--m2);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%"><?php echo $ay_ad; ?></div>
      <div style="font-size:10px;color:var(--m2)"><?php echo $v['katilim']; ?> kişi</div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Referans çizgiler -->
  <div style="border-top:1px dashed var(--kenar);padding-top:12px;display:flex;gap:16px;flex-wrap:wrap">
    <?php foreach ($aylik_veri as $ay_key => $v):
        $parts = explode('-', $ay_key);
        $ay_ad = ($ay_adlari[$parts[1]] ?? $parts[1]).' '.$parts[0];
        if ($v['yuzde'] >= 80) { $c_bg='#D1FAE5'; $c_rk='#065F46'; $etiket='Çok İyi'; }
        elseif ($v['yuzde'] >= 60) { $c_bg='#DBEAFE'; $c_rk='#1E40AF'; $etiket='İyi'; }
        elseif ($v['yuzde'] >= 40) { $c_bg='#FEF3C7'; $c_rk='#92400E'; $etiket='Orta'; }
        else { $c_bg='#FEE2E2'; $c_rk='#991B1B'; $etiket='Düşük'; }
    ?>
    <div style="display:flex;align-items:center;gap:8px;background:var(--bg);border-radius:10px;padding:8px 12px;border:1px solid var(--kenar)">
      <span style="font-size:13px;color:var(--m2)"><?php echo $ay_ad; ?></span>
      <span style="font-size:18px;font-weight:900;color:<?php echo $c_rk; ?>"><?php echo $v['yuzde']; ?>%</span>
      <span style="background:<?php echo $c_bg; ?>;color:<?php echo $c_rk; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $etiket; ?></span>
      <span style="font-size:11px;color:var(--m2)"><?php echo $v['katilim']; ?> katılımcı</span>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

</div>

<script>
var YANITLAR = <?php echo json_encode($yanitlar, JSON_UNESCAPED_UNICODE); ?>;
var SORULAR  = <?php echo json_encode(array_merge(...array_values($sorular)), JSON_UNESCAPED_UNICODE); ?>;

function detayGoster(id) {
    var y = YANITLAR.find(function(r){ return r.id == id; });
    if (!y) return;
    var html = '<div style="max-height:70vh;overflow-y:auto;padding:4px">';
    html += '<div style="font-size:15px;font-weight:800;margin-bottom:12px">'+(y.anonim?'Anonim Yanıt':(y.ad_soyad||y.portal_adi||'?'))+'</div>';
    Object.keys(SORULAR).forEach(function(k) {
        var v = y[k];
        if (!v) return;
        var puan_et = {1:'Az',2:'Orta',3:'İyi',4:'Çok İyi'};
        var renk = v>=4?'#065F46':v>=3?'#1E40AF':v>=2?'#92400E':'#991B1B';
        var bg   = v>=4?'#D1FAE5':v>=3?'#DBEAFE':v>=2?'#FEF3C7':'#FEE2E2';
        html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #F3F4F6;font-size:12px">';
        html += '<span style="flex:1;padding-right:10px">'+SORULAR[k]+'</span>';
        html += '<span style="background:'+bg+';color:'+renk+';font-weight:700;padding:2px 8px;border-radius:20px;white-space:nowrap">'+puan_et[v]+'</span>';
        html += '</div>';
    });
    ['mutlu1','mutlu2','mutlu3'].forEach(function(k,i){
        if (y[k]) html += '<div style="padding:6px 0;font-size:12px"><span style="color:#6B7280">Mutlu '+(i+1)+':</span> '+y[k]+'</div>';
    });
    ['sikayet1','sikayet2','sikayet3'].forEach(function(k,i){
        if (y[k]) html += '<div style="padding:6px 0;font-size:12px"><span style="color:#6B7280">Şikayet '+(i+1)+':</span> '+y[k]+'</div>';
    });
    if (y.genel_oneri) html += '<div style="padding:8px 0;font-size:12px"><strong>Genel Öneri:</strong> '+y.genel_oneri+'</div>';
    html += '</div>';

    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;display:flex;align-items:center;justify-content:center';
    modal.onclick = function(e){ if(e.target===modal) modal.remove(); };
    modal.innerHTML = '<div style="background:var(--yuzey);border-radius:16px;padding:24px;width:600px;max-width:95vw;max-height:85vh;overflow-y:auto">'+html+'<button onclick="this.closest(\'div[style]\').remove()" style="margin-top:14px;background:var(--bg);border:1.5px solid var(--kenar);padding:8px 20px;border-radius:8px;font-weight:600;cursor:pointer;font-family:inherit;width:100%">Kapat</button></div>';
    document.body.appendChild(modal);
}
</script>
