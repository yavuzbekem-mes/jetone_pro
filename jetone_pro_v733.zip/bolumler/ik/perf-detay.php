<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$id=(int)($_GET['id']??0);
if(!$id){header('Location:?sayfa=ik-perf-listesi');exit;}
try { $q=$db->prepare("SELECT pd.*,CONCAT(p.ad,' ',p.soyad) per_adi,p.sicil_no,d.ad dept_adi FROM performans_degerlendirme pd JOIN personeller p ON pd.personel_id=p.id LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE pd.id=? LIMIT 1");
$q->execute([$id]);$d=$q->fetch(); } catch (Throwable $e) { echo '<div class="s-bar"><div class="s-bas">Tablo henüz oluşturulmadı. Lütfen tablo_guncelle.php çalıştırın.</div></div>'; return; }
if(!$d){echo '<div class="s-bar"><div class="s-bas">Bulunamadı</div></div>';return;}

function puan_badge($p){
    if(!$p) return '<span style="color:var(--m2)">—</span>';
    $r=[1=>['#FEE2E2','#991B1B','Yetersiz'],2=>['#FEF3C7','#92400E','Gelişmeli'],3=>['#DBEAFE','#1E40AF','Yeterli'],4=>['#D1FAE5','#065F46','Mükemmel']][$p]??['#F3F4F6','#374151',$p];
    return '<span style="background:'.$r[0].';color:'.$r[1].';font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">'.$p.' — '.$r[2].'</span>';
}
function genel_sinif($p){
    if($p>=85)return['#D1FAE5','#065F46','Mükemmel'];
    if($p>=70)return['#DBEAFE','#1E40AF','İyi'];
    if($p>=50)return['#FEF3C7','#92400E','Gelişmeli'];
    return['#FEE2E2','#991B1B','Yetersiz'];
}
$pc=genel_sinif($d['genel_toplam']??0);
$bolumler=[
    ['K','1 — Kişisel Kriterler','#3B82F6','toplam_k',32,['k11'=>'İşyeri Kurallarına Uyum','k12'=>'Öğrenme ve Gelişme','k13'=>'Kurumsal Kültür','k14'=>'İnisiyatif','k15'=>'Ekip Çalışması','k16'=>'İşe Merak','k17'=>'Kişisel Bakım','k18'=>'İSG Uyumu']],
    ['D','2 — Davranışsal Kriterler','#10B981','toplam_d',44,['d21'=>'Değişime Uyum','d22'=>'Güvenilirlik','d23'=>'Sorumluluk','d24'=>'Kendini Geliştirme','d25'=>'İletişim','d26'=>'Yeni Fikirler','d27'=>'Problem Çözme','d28'=>'Devam/Mesai','d29'=>'Strese Dayanıklılık','d210'=>'Sosyal İlişkiler','d211'=>'Konsantrasyon']],
    ['T','3 — Teknik Kriterler','#8B5CF6','toplam_t',24,['t31'=>'Mesleki Bilgi','t32'=>'Makine/Ekipman','t33'=>'İş Disiplini','t34'=>'Farklı İşler','t35'=>'Doğru/Tam İş','t36'=>'Kalite ve Verim']],
];
?>
<div class="s-bar">
  <div><h1 class="s-bas">Performans Değerlendirmesi</h1>
  <div class="s-yol">İK / <a href="?sayfa=ik-perf-listesi" style="color:var(--t);text-decoration:none">Değerlendirmeler</a></div></div>
  <div style="display:flex;gap:8px">
    <span style="background:<?php echo $pc[0];?>;color:<?php echo $pc[1];?>;font-size:14px;font-weight:900;padding:8px 16px;border-radius:20px"><?php echo ($d['genel_toplam']??0);?>/100 — <?php echo $pc[2];?></span>
    <a href="?sayfa=ik-perf-form&id=<?php echo $id;?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">✏️ Düzenle</a>
    <a href="?sayfa=ik-perf-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Liste</a>
  </div>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="kart" style="padding:16px">
    <div class="kart-bas" style="margin-bottom:10px">👤 Çalışan Bilgileri</div>
    <?php foreach([['Adı Soyadı',$d['per_adi']],['Sicil No',$d['sicil_no']??'—'],['Bölüm',$d['dept_adi']??'—'],['Ünvan',$d['unvan']??'—']] as [$k,$v]):?>
    <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:13px"><span style="color:var(--m2)"><?php echo $k;?></span><span style="font-weight:600"><?php echo htmlspecialchars($v);?></span></div>
    <?php endforeach;?>
  </div>
  <div class="kart" style="padding:16px">
    <div class="kart-bas" style="margin-bottom:10px">🧑‍💼 Değerlendiren</div>
    <?php foreach([['Adı Soyadı',$d['degerlendiren']??'—'],['Bölümü',$d['deg_bolum']??'—'],['Ünvanı',$d['deg_unvan']??'—'],['Tarih',date('d.m.Y',strtotime($d['degerlendirme_tarihi']))],['Hazırlayan',$d['hazirlayan']??'—'],['Onaylayan',$d['onaylayan']??'—']] as [$k,$v]):?>
    <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:13px"><span style="color:var(--m2)"><?php echo $k;?></span><span style="font-weight:600"><?php echo htmlspecialchars($v);?></span></div>
    <?php endforeach;?>
  </div>
</div>

<?php foreach($bolumler as [$hrf,$bas,$rk,$tk,$maks,$kriterler]):
  $top=$d[$tk]??0; $yuzde=$maks>0?round(($top/$maks)*100):0;?>
<div class="kart" style="overflow:hidden;margin-bottom:12px">
  <div style="padding:12px 16px;background:<?php echo $rk;?>;color:#fff;display:flex;justify-content:space-between">
    <span style="font-weight:800"><?php echo $bas;?></span>
    <span><?php echo $top;?>/<?php echo $maks;?> — %<?php echo $yuzde;?></span>
  </div>
  <div style="background:rgba(0,0,0,.05);height:4px"><div style="width:<?php echo $yuzde;?>%;background:<?php echo $rk;?>;height:100%"></div></div>
  <table style="width:100%;border-collapse:collapse;font-size:13px">
    <?php foreach($kriterler as $key=>$kriter_adi):?>
    <tr style="border-bottom:1px solid var(--kenar)">
      <td style="padding:8px 16px;color:var(--m2);font-size:11px;font-weight:700;white-space:nowrap"><?php echo strtoupper($key);?></td>
      <td style="padding:8px 16px;flex:1"><?php echo htmlspecialchars($kriter_adi);?></td>
      <td style="padding:8px 16px;text-align:right"><?php echo puan_badge((int)($d[$key]??0));?></td>
    </tr>
    <?php endforeach;?>
  </table>
</div>
<?php endforeach;?>

<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:10px;margin-top:4px">
  <?php foreach([['Kişisel','toplam_k','#3B82F6',32],['Davranışsal','toplam_d','#10B981',44],['Teknik','toplam_t','#8B5CF6',24]] as [$et,$k,$rk,$maks]):
    $t=$d[$k]??0;?>
  <div class="kart" style="padding:14px;text-align:center">
    <div style="font-size:11px;color:var(--m2);margin-bottom:4px"><?php echo $et;?> /<?php echo $maks;?></div>
    <div style="font-size:24px;font-weight:900;color:<?php echo $rk;?>"><?php echo $t;?></div>
  </div>
  <?php endforeach;?>
  <div class="kart" style="padding:14px;text-align:center;background:<?php echo $pc[0];?>">
    <div style="font-size:11px;color:<?php echo $pc[1];?>;margin-bottom:4px">GENEL TOPLAM /100</div>
    <div style="font-size:28px;font-weight:900;color:<?php echo $pc[1];?>"><?php echo $d['genel_toplam']??0;?></div>
  </div>
</div>
</div>
