<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

try {
    $duyurular = $db->query("SELECT d.*, 
        CONCAT(k.ad,' ',k.soyad) olusturan_adi,
        (SELECT COUNT(*) FROM duyuru_okunanlar WHERE duyuru_id=d.id) okunma_say
        FROM duyurular d
        LEFT JOIN kullanicilar k ON d.olusturan_id=k.id
        ORDER BY d.olusturma DESC")->fetchAll();
} catch (Throwable $e) { $duyurular = []; }

$departmanlar = $db->query("SELECT id, ad FROM departmanlar ORDER BY ad")->fetchAll();

$oncelik_cfg = [
    'normal'  => ['#F3F4F6','#6B7280','📋 Normal'],
    'onemli'  => ['#DBEAFE','#1E40AF','⭐ Önemli'],
    'acil'    => ['#FEE2E2','#991B1B','🚨 Acil'],
];
$hedef_cfg = [
    'herkese'    => ['#D1FAE5','#065F46','👥 Herkese'],
    'departman'  => ['#EDE9FE','#5B21B6','🏢 Departman'],
    'kadro'      => ['#FEF3C7','#92400E','👔 Kadro'],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">📢 Duyurular</h1>
    <div class="s-yol">İK / <b>Duyuru Yönetimi</b></div>
  </div>
  <a href="?sayfa=ik-duyuru-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Duyuru</a>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php
  $toplam = count($duyurular);
  $aktif  = count(array_filter($duyurular, function($d){ return $d['aktif']; }));
  $acil   = count(array_filter($duyurular, function($d){ return $d['oncelik']==='acil' && $d['aktif']; }));
  $toplam_okuma = array_sum(array_column($duyurular,'okunma_say'));
  ?>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Toplam</div><div style="font-size:28px;font-weight:900;color:var(--t)"><?php echo $toplam; ?></div></div>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Aktif</div><div style="font-size:28px;font-weight:900;color:#059669"><?php echo $aktif; ?></div></div>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Acil</div><div style="font-size:28px;font-weight:900;color:#EF4444"><?php echo $acil; ?></div></div>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);font-weight:700;text-transform:uppercase;margin-bottom:4px">Toplam Okunma</div><div style="font-size:28px;font-weight:900;color:#7C3AED"><?php echo $toplam_okuma; ?></div></div>
</div>

<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Tüm Duyurular</div></div>
  <?php if (empty($duyurular)): ?>
  <div style="text-align:center;padding:40px;color:var(--m2)">Henüz duyuru yok.</div>
  <?php else: ?>
  <div style="display:grid;gap:0">
    <?php foreach ($duyurular as $d):
      $oc = $oncelik_cfg[$d['oncelik']] ?? $oncelik_cfg['normal'];
      $hc = $hedef_cfg[$d['hedef']] ?? $hedef_cfg['herkese'];
      $aktif_mi = $d['aktif'];
      $bugun = date('Y-m-d');
      $gecmis = $d['bitis'] && $d['bitis'] < $bugun;
    ?>
    <div style="padding:16px;border-bottom:1px solid var(--kenar);<?php echo (!$aktif_mi||$gecmis)?'opacity:.6':''; ?>">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap">
            <span style="background:<?php echo $oc[0]; ?>;color:<?php echo $oc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $oc[2]; ?></span>
            <span style="background:<?php echo $hc[0]; ?>;color:<?php echo $hc[1]; ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px"><?php echo $hc[2]; ?></span>
            <?php if (!$aktif_mi): ?><span style="background:#F3F4F6;color:#6B7280;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">⏸ Pasif</span><?php endif; ?>
            <?php if ($gecmis): ?><span style="background:#FEE2E2;color:#991B1B;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px">⌛ Süresi Doldu</span><?php endif; ?>
          </div>
          <div style="font-size:16px;font-weight:800;margin-bottom:4px"><?php echo htmlspecialchars($d['baslik']); ?></div>
          <div style="font-size:13px;color:var(--m2);line-height:1.5"><?php echo htmlspecialchars(mb_substr($d['icerik'],0,150)).(mb_strlen($d['icerik'])>150?'...':''); ?></div>
          <div style="margin-top:8px;font-size:11px;color:var(--m2);display:flex;gap:16px;flex-wrap:wrap">
            <span>📅 <?php echo date('d.m.Y H:i',strtotime($d['olusturma'])); ?></span>
            <?php if ($d['baslangic']): ?><span>🟢 <?php echo date('d.m.Y',strtotime($d['baslangic'])); ?></span><?php endif; ?>
            <?php if ($d['bitis']): ?><span>🔴 <?php echo date('d.m.Y',strtotime($d['bitis'])); ?></span><?php endif; ?>
            <span>👁 <?php echo $d['okunma_say']; ?> okunma</span>
            <span>✍️ <?php echo htmlspecialchars($d['olusturan_adi']??''); ?></span>
          </div>
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0">
          <a href="?sayfa=ik-duyuru-form&id=<?php echo $d['id']; ?>" style="width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:8px;text-decoration:none" title="Düzenle">✏️</a>
          <button onclick="aktifToggle(<?php echo $d['id']; ?>,<?php echo $d['aktif']?1:0; ?>)" style="width:32px;height:32px;background:<?php echo $aktif_mi?'#D1FAE5':'#F3F4F6'; ?>;color:<?php echo $aktif_mi?'#065F46':'#6B7280'; ?>;border:none;border-radius:8px;cursor:pointer;font-size:14px" title="<?php echo $aktif_mi?'Pasif yap':'Aktif yap'; ?>"><?php echo $aktif_mi?'✅':'⏸'; ?></button>
          <button onclick="sil(<?php echo $d['id']; ?>)" style="width:32px;height:32px;background:#FEE2E2;color:#EF4444;border:none;border-radius:8px;cursor:pointer;font-size:14px" title="Sil">🗑</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
</div>

<script>
function aktifToggle(id, mevcut) {
    var fd = new FormData(); fd.append('id',id); fd.append('aktif', mevcut?0:1);
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/duyuru-aktif.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){if(r.ok)location.reload();else alert(r.hata);});
}
function sil(id) {
    if(!confirm('Bu duyuru silinsin mi?')) return;
    var fd=new FormData(); fd.append('id',id);
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/duyuru-sil.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){if(r.ok)location.reload();else alert(r.hata);});
}
</script>
