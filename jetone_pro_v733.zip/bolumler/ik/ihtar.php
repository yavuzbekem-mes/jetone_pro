<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

try {
    $ihtarlar = $db->query(
        "SELECT it.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no,
            d.ad dept_adi, p.kadro, p.unvan
         FROM ihtar_tutanaklar it
         JOIN personeller p ON it.personel_id = p.id
         LEFT JOIN departmanlar d ON p.departman_id = d.id
         ORDER BY it.ihtar_tarihi DESC"
    )->fetchAll();
} catch (Throwable $e) { $ihtarlar = []; }

$toplam = count($ihtarlar);
$acik   = count(array_filter($ihtarlar, function($i){ return $i['durum']==='acik'; }));
$sv_bek = count(array_filter($ihtarlar, function($i){ return $i['durum']==='savunma_bekleniyor'; }));
$kapali = count(array_filter($ihtarlar, function($i){ return $i['durum']==='kapali'; }));

// Personel bazlı ihtar sayısı (analiz)
$per_sayac = [];
foreach ($ihtarlar as $i) {
    $k = $i['personel_id'];
    if (!isset($per_sayac[$k])) $per_sayac[$k] = ['adi'=>$i['per_adi'],'sayi'=>0,'dept'=>$i['dept_adi']];
    $per_sayac[$k]['sayi']++;
}
usort($per_sayac, function($a,$b){ return $b['sayi']-$a['sayi']; });

// Neden analizi
$nedenler_cfg = [
    'neden_mola'   => 'Mola dışı görev yeri terk',
    'neden_telefon'=> 'Mola dışı cep telefonu',
    'neden_amire'  => 'Amire/arkadaşa karşı gelme',
    'neden_makine' => 'Makine/teçhizata zarar',
    'neden_isg'    => 'İSG kurallarına uymama',
    'neden_alkol'  => 'İşyerinde alkollü olma',
    'neden_gorev'  => '4857/25-A Görevi yapmama',
    'neden_hatali' => 'Hatalı üretim/işlem',
    'neden_diger'  => 'Diğer',
];
$neden_sayac = array_fill_keys(array_keys($nedenler_cfg), 0);
foreach ($ihtarlar as $i) {
    foreach (array_keys($nedenler_cfg) as $k) {
        if ($i[$k]) $neden_sayac[$k]++;
    }
}
arsort($neden_sayac);

$durum_cfg = [
    'acik'               => ['#DBEAFE','#1E40AF','Açık'],
    'savunma_bekleniyor' => ['#FEF3C7','#92400E','Savunma Bekleniyor'],
    'kapali'             => ['#F3F4F6','#6B7280','Kapandı'],
];
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">⚠️ İhtar Tutanakları</h1>
    <div class="s-yol">İnsan Kaynakları / <b>İhtar</b></div>
  </div>
  <a href="?sayfa=ik-ihtar-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Tutanak</a>

  <button onclick="dtExcelIndir('tbl-ihtar','Ihtar')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php foreach ([['Toplam','#6B7280',$toplam,'📋'],['Açık','#1E40AF',$acik,'🔵'],['Savunma Bekleniyor','#92400E',$sv_bek,'⏳'],['Kapandı','#065F46',$kapali,'✅']] as [$et,$rk,$say,$ik]): ?>
  <div class="kart" style="padding:14px;text-align:center">
    <div style="font-size:22px"><?php echo $ik; ?></div>
    <div style="font-size:26px;font-weight:900;color:<?php echo $rk; ?>"><?php echo $say; ?></div>
    <div style="font-size:12px;color:var(--m2)"><?php echo $et; ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">

<!-- Neden analizi -->
<div class="kart" style="padding:18px">
  <div class="kart-bas" style="margin-bottom:14px">📊 En Sık İhtar Nedenleri</div>
  <?php if (empty($ihtarlar)): ?>
  <div style="color:var(--m2);font-size:13px">Henüz ihtar yok.</div>
  <?php else: $max = max($neden_sayac) ?: 1; foreach ($neden_sayac as $k=>$say): if (!$say) continue; ?>
  <div style="margin-bottom:10px">
    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
      <span><?php echo $nedenler_cfg[$k]; ?></span>
      <strong><?php echo $say; ?></strong>
    </div>
    <div style="background:var(--kenar);border-radius:4px;height:8px">
      <div style="width:<?php echo round($say/$max*100); ?>%;background:#F97316;height:100%;border-radius:4px"></div>
    </div>
  </div>
  <?php endforeach; endif; ?>
</div>

<!-- Personel bazlı -->
<div class="kart" style="padding:18px">
  <div class="kart-bas" style="margin-bottom:14px">👤 En Çok İhtar Alan Personel</div>
  <?php if (empty($per_sayac)): ?>
  <div style="color:var(--m2);font-size:13px">Henüz ihtar yok.</div>
  <?php else: foreach (array_slice($per_sayac,0,8) as $p): ?>
  <div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--kenar)">
    <span style="width:28px;height:28px;background:<?php echo $p['sayi']>=3?'#FEE2E2':($p['sayi']>=2?'#FEF3C7':'#F3F4F6'); ?>;color:<?php echo $p['sayi']>=3?'#991B1B':($p['sayi']>=2?'#92400E':'#374151'); ?>;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;flex-shrink:0"><?php echo $p['sayi']; ?></span>
    <div style="flex:1;min-width:0">
      <div style="font-size:13px;font-weight:700"><?php echo htmlspecialchars($p['adi']); ?></div>
      <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($p['dept']??''); ?></div>
    </div>
    <span style="font-size:11px;color:var(--m2)"><?php echo $p['sayi']; ?> ihtar</span>
  </div>
  <?php endforeach; endif; ?>
</div>

</div>

<!-- Liste -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Tutanak Listesi (<?php echo $toplam; ?>)</div></div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-ihtar" style="width:100%">
    <thead><tr>
      <th style="width:130px">Tutanak No</th>
      <th>Personel</th>
      <th>Departman</th>
      <th style="width:110px">İhtar Tarihi</th>
      <th>Nedenler</th>
      <th style="width:110px">Savunma</th>
      <th style="width:110px;text-align:center">Durum</th>
      <th style="width:80px;text-align:center">İşlem</th>
    </tr></thead>
    <tbody>
      <?php if (empty($ihtarlar)): ?>
      <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--m2)">Henüz ihtar tutanağı eklenmemiş.</td></tr>
      <?php else: foreach ($ihtarlar as $i):
        $dc = $durum_cfg[$i['durum']] ?? ['#F3F4F6','#374151',$i['durum']];
        // Aktif nedenleri listele
        $aktif_nedenler = [];
        foreach ($nedenler_cfg as $k=>$et) { if ($i[$k]) $aktif_nedenler[] = $et; }
        if ($i['neden_diger'] && $i['neden_diger_acik']) $aktif_nedenler[] = $i['neden_diger_acik'];
      ?>
      <tr style="cursor:pointer" onclick="location.href='?sayfa=ik-ihtar-form&id=<?php echo $i['id']; ?>'">
        <td style="font-weight:800;color:var(--t);font-size:13px"><?php echo htmlspecialchars($i['tutanak_no']); ?></td>
        <td>
          <div style="font-weight:700"><?php echo htmlspecialchars($i['per_adi']); ?></div>
          <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($i['sicil_no']??''); ?></div>
        </td>
        <td style="font-size:13px"><?php echo htmlspecialchars($i['dept_adi']??'—'); ?></td>
        <td style="font-size:13px"><?php echo date('d.m.Y',strtotime($i['ihtar_tarihi'])); ?></td>
        <td style="font-size:12px;max-width:220px">
          <?php echo htmlspecialchars(implode(', ', array_slice($aktif_nedenler,0,2))); ?>
          <?php if (count($aktif_nedenler)>2): ?><span style="color:var(--m2)"> +<?php echo count($aktif_nedenler)-2; ?></span><?php endif; ?>
        </td>
        <td style="font-size:12px">
          <?php if ($i['savunma']): ?>
          <span style="color:#065F46;font-size:11px;font-weight:700">✓ Var</span>
          <?php else: ?>
          <span style="color:#9CA3AF;font-size:11px">Bekleniyor</span>
          <?php endif; ?>
        </td>
        <td style="text-align:center">
          <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px"><?php echo $dc[2]; ?></span>
        </td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <button onclick="silOnay(<?php echo $i['id']; ?>, '<?php echo htmlspecialchars($i['tutanak_no'],ENT_QUOTES); ?>')"
            style="background:#FEE2E2;color:#EF4444;border:none;padding:4px 10px;border-radius:6px;font-size:12px;cursor:pointer;font-family:inherit">Sil</button>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
</div>

</div>

<script>
function silOnay(id, no) {
    if (!confirm(no + ' numaralı tutanak silinsin mi?')) return;
    var fd = new FormData(); fd.append('id', id);
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/ihtar-sil.php', {
        method:'POST', body:fd, credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload();
        else alert(r.hata);
    });
}
</script>
