<?php
/**
 * İK — Bordro Yönetimi
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}

// Tablo oluştur
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `bordro_dosyalar` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `personel_id` INT NOT NULL,
        `ay` TINYINT NOT NULL,
        `yil` SMALLINT NOT NULL,
        `dosya_adi` VARCHAR(300) NOT NULL,
        `dosya_yol` VARCHAR(500) NOT NULL,
        `yukleyen_id` INT DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pid (personel_id),
        INDEX idx_ay_yil (ay,yil)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // UNIQUE key varsa kaldır (eski versiyondan)
    try { $db->exec("ALTER TABLE bordro_dosyalar DROP INDEX uk_per_ay_yil"); } catch(Throwable $e){}
} catch(Throwable $e) {}

$UPLOAD_DIR = ROOT_DIR . '/uploads/bordrolar/';
if (!is_dir($UPLOAD_DIR)) mkdir($UPLOAD_DIR, 0755, true);

// Silme işlemi
$sil_mesaj = null;
if (isset($_GET['sil']) && Auth::yetkiKontrol('ik','duzenle')) {
    $sil_id = (int)$_GET['sil'];
    try {
        $d = $db->prepare("SELECT dosya_yol FROM bordro_dosyalar WHERE id=? LIMIT 1");
        $d->execute([$sil_id]); $row = $d->fetch();
        if ($row && file_exists($UPLOAD_DIR.$row['dosya_yol'])) @unlink($UPLOAD_DIR.$row['dosya_yol']);
        $db->prepare("DELETE FROM bordro_dosyalar WHERE id=?")->execute([$sil_id]);
        $sil_mesaj = 'silindi';
    } catch(Throwable $e){ $sil_mesaj = 'hata'; }
}

$ay    = (int)($_GET['ay']   ?? date('n'));
$yil   = (int)($_GET['yil']  ?? date('Y'));
$dept  = (int)($_GET['dept'] ?? 0);
$aylar = ['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$BORDRO_HATA = null;

try {
    $deptlar = $db->query("SELECT id,ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();
    $where = ["p.durum='aktif'"]; $params = [];
    if ($dept) { $where[] = "p.departman_id=?"; $params[] = $dept; }
    // Her personelin seçili ay/yıl bordrosunu getir
    // Aynı ay/yıl için birden fazla varsa en son olanı al
    $q = $db->prepare("SELECT p.id, p.sicil_no, CONCAT(p.ad,' ',p.soyad) per_adi,
        d.ad dept_adi, p.brut_maas,
        bf.id bdosya_id, bf.dosya_adi, bf.ay b_ay, bf.yil b_yil, bf.olusturma yuklenme_tarihi
        FROM personeller p
        LEFT JOIN departmanlar d ON p.departman_id = d.id
        LEFT JOIN bordro_dosyalar bf ON bf.id = (
            SELECT id FROM bordro_dosyalar
            WHERE personel_id=p.id AND ay=? AND yil=?
            ORDER BY olusturma DESC LIMIT 1
        )
        WHERE " . implode(' AND ', $where) . " ORDER BY p.ad");
    $q->execute(array_merge([$ay, $yil], $params));
    $personeller = $q->fetchAll();
    $yuklenen = count(array_filter($personeller, function($p){ return !empty($p['bdosya_id']); }));
} catch(Throwable $e) {
    $personeller = []; $yuklenen = 0; $deptlar = [];
    $BORDRO_HATA = $e->getMessage();
}

$base = BASE_URL;
?>
<?php if ($sil_mesaj === 'silindi'): ?>
<script>location.replace('?sayfa=ik-bordro&ay=<?php echo $ay; ?>&yil=<?php echo $yil; ?>');</script>
<?php endif; ?>
<?php if ($BORDRO_HATA): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:10px 16px;border-radius:8px;margin:10px;font-size:13px">
    DB Hatasi: <?php echo htmlspecialchars($BORDRO_HATA); ?>
</div>
<?php endif; ?>

<div class="s-bar">
    <div>
        <h1 class="s-bas">Bordro Yonetimi</h1>
        <div class="s-yol">Insan Kaynaklari / <b>Bordro</b></div>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
        <div id="dt-toolbar-dt-bordro" style="display:inline-flex;align-items:center;gap:6px"></div>
        <button onclick="dtExcelIndir('dt-bordro','BordroListesi',{tip:'bordro'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;display:inline-flex;align-items:center;gap:5px">Excel</button>
    </div>
</div>

<div class="s-body">
    <!-- Ozet + Filtreler -->
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px;background:var(--yuzey);border-radius:var(--r-lg);padding:14px 16px;box-shadow:var(--golge)">
        <span style="background:#D1FAE5;color:#065F46;font-size:13px;font-weight:700;padding:5px 12px;border-radius:8px">
            <?php echo $yuklenen; ?> Yuklendi
        </span>
        <span style="background:#FEE2E2;color:#991B1B;font-size:13px;font-weight:700;padding:5px 12px;border-radius:8px">
            <?php echo count($personeller)-$yuklenen; ?> Bekliyor
        </span>
        <div style="margin-left:auto;display:flex;gap:6px;align-items:center;flex-wrap:wrap">
            <form method="GET" style="display:flex;gap:6px;align-items:center">
                <input type="hidden" name="sayfa" value="ik-bordro">
                <select name="ay" onchange="this.form.submit()" style="padding:7px 10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
                    <?php for($m=1;$m<=12;$m++): ?>
                    <option value="<?php echo $m; ?>" <?php echo $m==$ay?'selected':''; ?>><?php echo $aylar[$m]; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="yil" onchange="this.form.submit()" style="padding:7px 10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
                    <?php for($y=date('Y');$y>=date('Y')-3;$y--): ?>
                    <option value="<?php echo $y; ?>" <?php echo $y==$yil?'selected':''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="dept" onchange="this.form.submit()" style="padding:7px 10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px">
                    <option value="0">Tum Departmanlar</option>
                    <?php foreach($deptlar as $d): ?>
                    <option value="<?php echo $d['id']; ?>" <?php echo $d['id']==$dept?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
    </div>

    <!-- Tablo -->
    <div class="kart" style="overflow:hidden">
        <div style="overflow-y:auto;max-height:calc(100vh - 220px)">
        <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="dt-bordro" style="width:100%">
            <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
                <tr>
                    <th>Personel</th>
                    <th>Departman</th>
                    <th>Brut Maas</th>
                    <th><?php echo $aylar[$ay]; ?> <?php echo $yil; ?> Bordrosu</th>
                    <th style="width:90px;text-align:center">Islem</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($personeller)): ?>
                <tr><td colspan="5" style="text-align:center;padding:30px;color:var(--m2)">Kayit bulunamadi.</td></tr>
                <?php else: ?>
                <?php foreach($personeller as $p): ?>
                <tr>
                    <td>
                        <div style="font-weight:700"><?php echo htmlspecialchars($p['per_adi']); ?></div>
                        <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($p['sicil_no']??''); ?></div>
                    </td>
                    <td style="font-size:13px"><?php echo htmlspecialchars($p['dept_adi']??''); ?></td>
                    <td style="font-weight:700">
                        <?php echo number_format((float)$p['brut_maas'],2,'.',','); ?> TL
                    </td>
                    <td>
                        <?php if($p['bdosya_id']): ?>
                        <div style="display:flex;align-items:center;gap:8px">
                            <button onclick="pdfGoster('<?php echo $base; ?>/uploads/bordrolar/<?php echo rawurlencode($p['dosya_adi']); ?>','<?php echo htmlspecialchars($p['per_adi'],ENT_QUOTES); ?>')"
                                style="background:none;border:none;padding:0;cursor:pointer;font-size:13px;color:#1D4ED8;font-weight:700;display:inline-flex;align-items:center;gap:5px;font-family:inherit">
                                <?php echo htmlspecialchars($p['dosya_adi']); ?>
                            </button>
                            <span style="font-size:11px;color:var(--m2)"><?php echo date('d.m.Y',strtotime($p['yuklenme_tarihi'])); ?></span>
                        </div>
                        <?php else: ?>
                        <span style="background:#FEE2E2;color:#991B1B;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">Yuklenmedi</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align:center">
                        <div style="display:inline-flex;gap:4px">
                            <?php if($p['bdosya_id']): ?>
                            <button onclick="pdfGoster('<?php echo $base; ?>/uploads/bordrolar/<?php echo rawurlencode($p['dosya_adi']); ?>','<?php echo htmlspecialchars($p['per_adi'],ENT_QUOTES); ?>')"
                                title="Goruntule" style="width:30px;height:30px;border-radius:6px;background:#EFF6FF;color:#1D4ED8;border:none;cursor:pointer;font-size:14px;display:inline-flex;align-items:center;justify-content:center">
                                👁
                            </button>
                            <a href="?sayfa=ik-bordro&ay=<?php echo $ay; ?>&yil=<?php echo $yil; ?>&sil=<?php echo $p['bdosya_id']; ?>"
                                onclick="return confirm('Bordro silinsin mi?')" title="Sil"
                                style="width:30px;height:30px;border-radius:6px;background:#FEE2E2;color:#EF4444;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;font-size:14px">
                                🗑
                            </a>
                            <?php endif; ?>
                            <button onclick="bordroYukleModal(<?php echo $p['id']; ?>,'<?php echo htmlspecialchars($p['per_adi'],ENT_QUOTES); ?>')"
                                title="Yukle" style="width:30px;height:30px;border-radius:6px;background:#FEF3E8;color:#B45309;border:none;cursor:pointer;font-size:14px;display:inline-flex;align-items:center;justify-content:center">
                                📤
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table></div>
</div>
</div>
</div>

<!-- PDF Modal -->
<div id="pdfModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:2000;flex-direction:column">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 20px;background:#1E293B">
        <h3 id="pdfModalBaslik" style="color:#fff;font-size:15px;font-weight:700;margin:0"></h3>
        <div style="display:flex;gap:8px">
            <a id="pdfIndir" href="#" style="background:rgba(255,255,255,.15);color:#fff;padding:7px 14px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600">Indir</a>
            <button onclick="pdfKapat()" style="background:rgba(255,255,255,.15);color:#fff;border:none;padding:7px 14px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;font-family:inherit">Kapat</button>
        </div>
    </div>
    <iframe id="pdfFrame" src="" style="flex:1;border:none;width:100%;background:#525659"></iframe>
</div>

<!-- Upload Modal -->
<div id="yukleModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
    <div style="background:#fff;border-radius:16px;width:min(460px,100%);box-shadow:0 20px 60px rgba(0,0,0,.2)">
        <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
            <h3 style="font-size:15px;font-weight:800">Bordro Yukle</h3>
            <button onclick="document.getElementById('yukleModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">X</button>
        </div>
        <form id="yukleForm" style="padding:22px">
            <input type="hidden" id="yukPerId" name="personel_id">
            <div id="yukPerAdi" style="font-weight:800;font-size:15px;margin-bottom:16px;color:var(--t)"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">AY</label>
                    <select id="yukAy" name="ay" style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:14px">
                        <?php for($m=1;$m<=12;$m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo $m==$ay?'selected':''; ?>><?php echo $aylar[$m]; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">YIL</label>
                    <select id="yukYil" name="yil" style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:14px">
                        <?php for($y=date('Y');$y>=date('Y')-3;$y--): ?>
                        <option value="<?php echo $y; ?>" <?php echo $y==$yil?'selected':''; ?>><?php echo $y; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div style="margin-bottom:16px">
                <label style="display:block;font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:5px">PDF</label>
                <input type="file" id="yukDosya" name="bordro_pdf" accept=".pdf" required
                    style="width:100%;padding:10px;border:2px dashed var(--kenar);border-radius:8px;font-family:inherit;font-size:13px;cursor:pointer;box-sizing:border-box">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                <button type="button" onclick="document.getElementById('yukleModal').style.display='none'" style="padding:12px;background:var(--bg);border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Iptal</button>
                <button type="button" onclick="bordroGonder()" id="yukBtn" style="padding:12px;background:linear-gradient(135deg,var(--t),var(--tk));color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">Yukle</button>
            </div>
        </form>
    </div>
</div>

<script>
var BORDRO_BASE = '<?php echo BASE_URL; ?>';

function pdfGoster(url, baslik) {
    var el;
    el = document.getElementById('pdfModalBaslik'); if(el) el.textContent = baslik||'';
    el = document.getElementById('pdfFrame'); if(el) el.src = url;
    el = document.getElementById('pdfIndir'); if(el) { el.href = url; el.download = (baslik||'bordro').replace(/[^a-zA-Z0-9_-]/g,'_')+'.pdf'; }
    el = document.getElementById('pdfModal'); if(el) el.style.display = 'flex';
}
function pdfKapat() {
    var el = document.getElementById('pdfFrame'); if(el) el.src='';
    el = document.getElementById('pdfModal'); if(el) el.style.display = 'none';
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') pdfKapat(); });

function bordroYukleModal(pid, perAdi) {
    document.getElementById('yukPerId').value = pid;
    document.getElementById('yukPerAdi').textContent = perAdi;
    document.getElementById('yukleModal').style.display = 'flex';
}

function bordroGonder() {
    var btn = document.getElementById('yukBtn');
    var fd  = new FormData();
    fd.append('personel_id', document.getElementById('yukPerId').value);
    fd.append('ay',  document.getElementById('yukAy').value);
    fd.append('yil', document.getElementById('yukYil').value);
    var dosya = document.getElementById('yukDosya').files[0];
    if (!dosya) { alert('PDF dosyasi secin'); return; }
    fd.append('bordro_pdf', dosya);
    btn.disabled = true; btn.textContent = 'Yukleniyor...';
    fetch(BORDRO_BASE+'/bolumler/ik/ajax/bordro-yukle.php', {method:'POST', body:fd, credentials:'same-origin'})
        .then(function(r){ return r.json(); }).then(function(r){
            btn.disabled = false; btn.textContent = 'Yukle';
            if (r.ok) {
                document.getElementById('yukleModal').style.display = 'none';
                var ay  = document.getElementById('yukAy').value;
                var yil = document.getElementById('yukYil').value;
                location.href = '?sayfa=ik-bordro&ay='+ay+'&yil='+yil;
            } else { alert('Hata: '+(r.hata||'Bilinmeyen')); }
        }).catch(function(){ btn.disabled=false; btn.textContent='Yukle'; alert('Baglanti hatasi'); });
}

document.addEventListener('DOMContentLoaded', function(){ dtInit('dt-bordro'); });
</script>
