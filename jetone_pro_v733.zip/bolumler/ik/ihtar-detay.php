<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ?sayfa=ik-ihtar-listesi'); exit; }
$q = $db->prepare("SELECT it.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no, d.ad dept_adi FROM ihtar_tutanaklar it JOIN personeller p ON it.personel_id=p.id LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE it.id=? LIMIT 1");
$q->execute([$id]); $k = $q->fetch();
if (!$k) { echo '<div class="s-bar"><div class="s-bas">Bulunamadı</div></div>'; return; }

$nedenler = json_decode($k['nedenler'] ?? '[]', true) ?: [];
$nedenler_listesi = [
    'Mola saatleri dışında görev yerini terk etmek.',
    'Mola saatleri dışında cep telefonu ile görüşme yapmak.',
    'Amirlere ve arkadaşlarına karşı gelmek ve tehdit içeren söylemde bulunmak.',
    'Makine ve techizatlara zarar vermek.',
    'İş sağlığı ve güvenliği kurallarına uymamak.',
    'İş yerinde alkollü ve sarhoş olmak.',
    "4857 sayılı kanunun 25/A maddesi: Ödevli bulunduğu görevleri yapmaması.",
    'Hatalı üretim / işlem yapmak.',
];
$durum_cfg = [
    'bekliyor'       => ['#FEF3C7','#92400E','⏳ Bekliyor'],
    'savunma_alindi' => ['#DBEAFE','#1E40AF','📝 Savunma Alındı'],
    'kapatildi'      => ['#D1FAE5','#065F46','✅ Kapatıldı'],
];
$dc = $durum_cfg[$k['durum']] ?? ['#F3F4F6','#374151',$k['durum']];
?>
<div class="s-bar">
  <div><h1 class="s-bas" style="font-family:monospace"><?php echo htmlspecialchars($k['tutanak_no']); ?></h1>
  <div class="s-yol">İK / <a href="?sayfa=ik-ihtar-listesi" style="color:var(--t);text-decoration:none">İhtar Tutanakları</a> / <b><?php echo htmlspecialchars($k['tutanak_no']); ?></b></div></div>
  <div style="display:flex;gap:8px;align-items:center">
    <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:13px;font-weight:700;padding:6px 14px;border-radius:20px"><?php echo $dc[2]; ?></span>
    <a href="?sayfa=ik-ihtar-form&id=<?php echo $id; ?>" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">✏️ Düzenle</a>
    <a href="?sayfa=ik-ihtar-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Liste</a>
  </div>
</div>

<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">

  <div class="kart" style="padding:18px">
    <div class="kart-bas" style="margin-bottom:12px">👤 Personel Bilgileri</div>
    <?php foreach ([
      ['Personel',htmlspecialchars($k['per_adi'])],
      ['Sicil No',htmlspecialchars($k['sicil_no']??'—')],
      ['Bölüm',htmlspecialchars($k['dept_adi']??$k['bolum']??'—')],
      ['Kadro',htmlspecialchars($k['kadro']??'—')],
      ['Ünvan',htmlspecialchars($k['unvan']??'—')],
    ] as [$et,$val]): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $et; ?></span><span style="font-weight:600"><?php echo $val; ?></span>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="kart" style="padding:18px">
    <div class="kart-bas" style="margin-bottom:12px">📋 Form Bilgileri</div>
    <?php foreach ([
      ['Tutanak No',htmlspecialchars($k['tutanak_no'])],
      ['İhtar Tarihi',date('d.m.Y',strtotime($k['ihtar_tarihi']))],
      ['Tebliğ Eden',htmlspecialchars($k['teblig_eden']??'—')],
      ['Şahit',htmlspecialchars($k['sabit']??'—')],
      ['İK Sorumlusu',htmlspecialchars($k['ik_sorumlu']??'—')],
      ['Fabrika Müdürü',htmlspecialchars($k['fabrika_mudur']??'—')],
    ] as [$et,$val]): ?>
    <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--kenar);font-size:13px">
      <span style="color:var(--m2)"><?php echo $et; ?></span><span style="font-weight:600"><?php echo $val; ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="kart" style="padding:18px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:12px">⚠️ İhtar Nedenleri</div>
  <div style="display:grid;gap:8px">
    <?php foreach ($nedenler as $ni):
      $metin = isset($nedenler_listesi[$ni]) ? $nedenler_listesi[$ni] : 'Diğer';
      $goster = ($ni >= count($nedenler_listesi) && $k['diger_neden']) ? $metin.': '.$k['diger_neden'] : $metin;
    ?>
    <div style="display:flex;align-items:flex-start;gap:10px;padding:12px;background:#FFF7ED;border:1.5px solid #F97316;border-radius:10px">
      <span style="color:#F97316;font-size:16px;flex-shrink:0">⚠</span>
      <span style="font-size:13px"><?php echo htmlspecialchars($goster); ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="kart" style="padding:18px">
    <div class="kart-bas" style="margin-bottom:10px">📝 Savunma</div>
    <?php if ($k['savunma']): ?>
    <div style="font-size:13px;line-height:1.6;color:var(--m)"><?php echo nl2br(htmlspecialchars($k['savunma'])); ?></div>
    <?php if ($k['savunma_tarihi']): ?>
    <div style="font-size:11px;color:var(--m2);margin-top:8px">Tarih: <?php echo date('d.m.Y H:i',strtotime($k['savunma_tarihi'])); ?></div>
    <?php endif; ?>
    <?php else: ?>
    <div style="color:var(--m2);font-size:13px;font-style:italic">Henüz savunma girilmedi.</div>
    <?php if ($k['durum']==='bekliyor'): ?>
    <div style="margin-top:10px;padding:10px;background:#FEF3C7;border-radius:8px;font-size:12px;color:#92400E">Personel portalından savunma bekliyor.</div>
    <?php endif; ?>
    <?php endif; ?>
  </div>
  <div class="kart" style="padding:18px">
    <div class="kart-bas" style="margin-bottom:10px">⚖️ Karar</div>
    <?php if ($k['karar']): ?>
    <div style="font-size:13px;line-height:1.6;color:var(--m)"><?php echo nl2br(htmlspecialchars($k['karar'])); ?></div>
    <?php else: ?>
    <div style="color:var(--m2);font-size:13px;font-style:italic">Henüz karar girilmedi.</div>
    <?php endif; ?>
  </div>
</div>
</div>
