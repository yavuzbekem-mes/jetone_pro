<?php
/**
 * İK — Öneri & Şikayet Yönetimi
 * bolumler/ik/oneri-sikayet.php
 */
if (!Auth::yetkiKontrol('ik','goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>'; return;
}

$durum   = $_GET['durum'] ?? '';
$tip     = $_GET['tip']   ?? '';

$where_parts = ['1=1'];
$params = [];
if ($durum) { $where_parts[]='os.durum=?'; $params[]=$durum; }
if ($tip)   { $where_parts[]='os.tip=?';   $params[]=$tip; }
$where = 'WHERE '.implode(' AND ',$where_parts);

try {
    // Tablo yoksa oluştur
    $db->exec("CREATE TABLE IF NOT EXISTS `oneri_sikayet` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `personel_id` INT NOT NULL,
        `tip` VARCHAR(20) DEFAULT 'oneri',
        `konu` VARCHAR(200) NOT NULL,
        `aciklama` TEXT,
        `durum` VARCHAR(30) DEFAULT 'bekliyor',
        `anonim` TINYINT(1) DEFAULT 0,
        `odul_hakki` TINYINT(1) DEFAULT 0,
        `odul_tutari` DECIMAL(10,2) DEFAULT 0,
        `inceleme_notu` TEXT,
        `inceleme_tarihi` DATETIME DEFAULT NULL,
        `inceleyici_id` INT DEFAULT NULL,
        `olusturma` DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pid (personel_id), INDEX idx_d (durum), INDEX idx_t (tip)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $c=$db->prepare("SELECT COUNT(*) FROM oneri_sikayet os $where");
    $c->execute($params); $toplam=(int)$c->fetchColumn();

    $q=$db->prepare("SELECT os.*, 
        CASE WHEN os.anonim=1 THEN 'Anonim' ELSE CONCAT(p.ad,' ',p.soyad) END personel_adi,
        p.sicil_no, p.id per_id,
        CONCAT(k.ad,' ',COALESCE(k.soyad,'')) inceleyici_adi
        FROM oneri_sikayet os
        LEFT JOIN personeller p ON os.personel_id=p.id
        LEFT JOIN kullanicilar k ON os.inceleyici_id=k.id
        $where ORDER BY os.olusturma DESC");
    $q->execute($params); $oneri_list=$q->fetchAll();

    $sayilar=$db->query("SELECT durum,COUNT(*) n FROM oneri_sikayet GROUP BY durum")->fetchAll(PDO::FETCH_KEY_PAIR);
    $tipler =$db->query("SELECT tip,COUNT(*) n FROM oneri_sikayet GROUP BY tip")->fetchAll(PDO::FETCH_KEY_PAIR);
} catch(Throwable $e){ $oneri_list=[]; $toplam=0; $sayilar=[]; $tipler=[]; }

$durum_renk=['bekliyor'=>['⏳','#FEF0C7','#B45309'],'incelemede'=>['🔍','#DBEAFE','#1E40AF'],'onaylandi'=>['✅','#D1FADF','#0A8F4E'],'reddedildi'=>['❌','#FEE4E2','#F04438'],'uygulandi'=>['🎯','#D1FADF','#0A8F4E']];
$tip_tr=['oneri'=>'💡 Öneri','sikayet'=>'📢 Şikayet','dilek'=>'🙏 Dilek'];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">Öneri & Şikayet</h1>
    <div class="s-yol">İnsan Kaynakları / <b>Öneri & Şikayet</b></div>
  </div>
  <div style="display:flex;align-items:center;gap:8px">
    <div id="dt-toolbar-dt-oneri" style="display:inline-flex;align-items:center;gap:6px"></div>
    <button onclick="dtExcelIndir('dt-oneri','OneriSikayet',{tip:'oneri'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;display:inline-flex;align-items:center;gap:5px">📊 Excel</button>
  </div>
</div>

<!-- Özet kartlar -->
<div class="s-body" style="padding-bottom:8px">
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px">
    <?php
    $ozet_data=[
        ['Toplam',$toplam,'📋','#F3F4F6','#374151'],
        ['Bekliyor',$sayilar['bekliyor']??0,'⏳','#FEF0C7','#B45309'],
        ['İncelemede',$sayilar['incelemede']??0,'🔍','#DBEAFE','#1E40AF'],
        ['Onaylanan',$sayilar['onaylandi']??0,'✅','#D1FADF','#0A8F4E'],
        ['Reddedilen',$sayilar['reddedildi']??0,'❌','#FEE4E2','#F04438'],
    ];
    foreach ($ozet_data as [$et,$say,$ikon,$bg,$fg]):
    ?>
    <div style="background:<?php echo $bg; ?>;border-radius:12px;padding:14px;text-align:center">
      <div style="font-size:20px;margin-bottom:4px"><?php echo $ikon; ?></div>
      <div style="font-size:22px;font-weight:900;color:<?php echo $fg; ?>"><?php echo $say; ?></div>
      <div style="font-size:11px;font-weight:700;color:<?php echo $fg; ?>;opacity:.8"><?php echo $et; ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Filtre tabları -->
<div class="s-body" style="padding-top:0">
  <div style="display:flex;gap:0;border-bottom:1px solid var(--kenar);background:var(--yuzey);border-radius:var(--r-lg) var(--r-lg) 0 0;overflow:hidden;overflow-x:auto">
    <?php foreach([''=>'Tümü','bekliyor'=>'Bekliyor','incelemede'=>'İncelemede','onaylandi'=>'Onaylanan','reddedildi'=>'Reddedilen','uygulandi'=>'Uygulandı'] as $k=>$v): ?>
    <a href="?sayfa=ik-oneri&durum=<?php echo $k; ?>" style="padding:11px 14px;font-size:13px;font-weight:600;color:<?php echo $k===$durum?'var(--t)':'var(--m2)'; ?>;border-bottom:2px solid <?php echo $k===$durum?'var(--t)':'transparent'; ?>;text-decoration:none;white-space:nowrap">
      <?php echo $v; ?><?php echo isset($sayilar[$k])&&$sayilar[$k]>0?" <span style='background:var(--t);color:#fff;font-size:10px;padding:1px 6px;border-radius:20px'>{$sayilar[$k]}</span>":''; ?>
    </a>
    <?php endforeach; ?>
  </div>

  <div class="kart" style="border-radius:0 0 var(--r-lg) var(--r-lg);overflow:hidden">
    <?php if(empty($oneri_list)): ?>
    <div style="text-align:center;padding:40px;color:var(--m2)">
      <div style="font-size:36px;margin-bottom:8px">📭</div>
      Bu kategoride kayıt bulunamadı.
    </div>
    <?php else: ?>
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="dt-oneri">
      <thead style="position:sticky;top:0;z-index:2">
        <tr>
          <th>Personel</th>
          <th>Tür</th>
          <th>Konu</th>
          <th>Tarih</th>
          <th>Durum</th>
          <th style="width:120px;text-align:center">İşlem</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($oneri_list as $o):
          [$ikon,$bg,$fg]=$durum_renk[$o['durum']]??['❓','#F3F4F6','#6B7280'];
        ?>
        <tr>
          <td>
            <div style="font-weight:600"><?php echo htmlspecialchars($o['personel_adi']); ?></div>
            <?php if(!$o['anonim']): ?><div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($o['sicil_no']??''); ?></div><?php endif; ?>
            <?php if($o['anonim']): ?><span style="font-size:10px;background:#F3F4F6;padding:1px 6px;border-radius:6px;color:#6B7280">Anonim</span><?php endif; ?>
          </td>
          <td><?php echo $tip_tr[$o['tip']]??$o['tip']; ?></td>
          <td>
            <div style="font-weight:600;max-width:220px"><?php echo htmlspecialchars($o['konu']); ?></div>
            <?php if($o['odul_hakki']): ?>
            <span style="font-size:10px;background:#FEF3E8;color:#B45309;padding:1px 6px;border-radius:6px;font-weight:700">🏆 ₺<?php echo number_format($o['odul_tutari'],0,'.',','); ?> Ödül</span>
            <?php endif; ?>
          </td>
          <td style="font-size:12px;color:var(--m2)"><?php echo date('d.m.Y',strtotime($o['olusturma'])); ?></td>
          <td>
            <span style="background:<?php echo $bg; ?>;color:<?php echo $fg; ?>;font-size:11px;font-weight:700;padding:3px 8px;border-radius:8px">
              <?php echo $ikon; ?> <?php echo ucfirst($o['durum']); ?>
            </span>
          </td>
          <td style="text-align:center;white-space:nowrap;padding:8px 12px">
            <div style="display:inline-flex;gap:4px;align-items:center;flex-wrap:nowrap">
              <button onclick="oneriDetay(<?php echo $o['id']; ?>)" title="Detay" style="width:30px;height:30px;border-radius:6px;background:#EFF6FF;color:#1D4ED8;border:none;cursor:pointer;font-size:15px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">👁</button>
              <?php if($o['durum']==='bekliyor'||$o['durum']==='incelemede'): ?>
              <button onclick="oneriIslem(<?php echo $o['id']; ?>,'onayla')" title="Onayla" style="width:30px;height:30px;border-radius:6px;background:#D1FADF;color:#0A8F4E;border:none;cursor:pointer;font-size:15px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">✅</button>
              <button onclick="oneriIslem(<?php echo $o['id']; ?>,'reddet')" title="Reddet" style="width:30px;height:30px;border-radius:6px;background:#FEE4E2;color:#F04438;border:none;cursor:pointer;font-size:15px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">❌</button>
              <?php endif; ?>
              <?php if($o['durum']==='onaylandi'): ?>
              <button onclick="oneriIslem(<?php echo $o['id']; ?>,'uygula')" title="Uygulandı" style="width:30px;height:30px;border-radius:6px;background:#FEF0C7;color:#B45309;border:none;cursor:pointer;font-size:15px;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0">🎯</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>

<!-- Detay Modalı -->
<div id="oneriModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:16px;width:min(540px,100%);max-height:85vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:20px 24px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <h3 style="font-size:16px;font-weight:800" id="modalBaslik">Detay</h3>
      <button onclick="document.getElementById('oneriModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer;color:var(--m2)">✕</button>
    </div>
    <div id="modalIcerik" style="padding:24px"></div>
  </div>
</div>

<script>
// Tum oneri verileri
const oneriVeri = <?php echo json_encode(array_map(function($o){return [
    'id'=>$o['id'],'konu'=>$o['konu'],'aciklama'=>$o['aciklama'],
    'tip'=>$o['tip'],'durum'=>$o['durum'],'personel_adi'=>$o['personel_adi'],
    'sicil_no'=>isset($o['sicil_no'])?$o['sicil_no']:'','anonim'=>(bool)$o['anonim'],
    'odul_hakki'=>(bool)$o['odul_hakki'],'odul_tutari'=>$o['odul_tutari'],
    'inceleme_notu'=>isset($o['inceleme_notu'])?$o['inceleme_notu']:'','tarih'=>date('d.m.Y H:i',strtotime($o['olusturma']))
];},$oneri_list),JSON_UNESCAPED_UNICODE); ?>;

function oneriDetay(id){
    const o=oneriVeri.find(x=>x.id==id);
    if(!o) return;
    const tipTr={oneri:'💡 Öneri',sikayet:'📢 Şikayet',dilek:'🙏 Dilek'};
    document.getElementById('modalBaslik').textContent=tipTr[o.tip]||o.tip;
    const odulHtml=o.odul_hakki?`<div style="background:#FEF3E8;border-radius:8px;padding:10px 12px;margin-top:10px"><b style="color:#B45309">🏆 Öneri Ödülü:</b> <span style="color:#B45309">₺${parseFloat(o.odul_tutari).toLocaleString('tr-TR')}</span></div>`:'';
    const notHtml=o.inceleme_notu?`<div style="margin-top:12px"><div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:4px">İNCELEME NOTU</div><div style="background:#F9FAFB;border-radius:8px;padding:10px 12px;font-size:13px;border-left:3px solid var(--t)">${o.inceleme_notu}</div></div>`:'';
    document.getElementById('modalIcerik').innerHTML=`
        <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">PERSONEL</div>
        <div style="font-weight:700">${o.personel_adi}${o.anonim?' <span style="font-size:10px;background:#F3F4F6;padding:1px 6px;border-radius:6px">Anonim</span>':''}</div>
        <div style="font-size:12px;color:var(--m2)">${o.tarih}</div></div>
        <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">KONU</div>
        <div style="font-weight:700;font-size:15px">${o.konu}</div></div>
        <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;color:var(--m2);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px">AÇIKLAMA</div>
        <div style="font-size:13px;line-height:1.6;background:#F9FAFB;padding:12px;border-radius:8px">${o.aciklama}</div></div>
        ${odulHtml}${notHtml}
        ${(o.durum==='bekliyor'||o.durum==='incelemede')?`
        <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--kenar)">
          <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px">HIZLI İŞLEM</div>
          <textarea id="modalNot" placeholder="İnceleme notu (isteğe bağlı)..." style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:13px;resize:vertical;min-height:70px;outline:none;margin-bottom:10px"></textarea>
          ${o.tip==='oneri'?`<label style="display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:13px;cursor:pointer"><input type="checkbox" id="odul_ver" style="accent-color:var(--t)"> <span>₺2.500 öneri ödülü ver</span></label>`:''}
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <button onclick="oneriIslemModal(${o.id},'onayla')" style="padding:10px;background:#D1FADF;color:#0A8F4E;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">✅ Onayla</button>
            <button onclick="oneriIslemModal(${o.id},'reddet')" style="padding:10px;background:#FEE4E2;color:#F04438;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">❌ Reddet</button>
          </div>
        </div>`:''}
        ${o.durum==='onaylandi'?`
        <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--kenar)">
          <button onclick="oneriIslemModal(${o.id},'uygula')" style="width:100%;padding:12px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit">🎯 Uygulandı Olarak İşaretle</button>
        </div>`:''}`;
    document.getElementById('oneriModal').style.display='flex';
}

function oneriIslem(id, islem){
    const o = oneriVeri.find(x=>x.id==id)||{};
    const not = prompt(islem==='reddet'?'Red sebebi (isteğe bağlı):':'İnceleme notu (isteğe bağlı):')||'';
    const odul = (islem==='onayla' && o.tip==='oneri') ? confirm('₺2.500 öneri ödülü ver?') : false;
    gonderIslem(id, islem, not, odul);
}

function oneriIslemModal(id, islem){
    const not = document.getElementById('modalNot')?.value||'';
    const odul = document.getElementById('odul_ver')?.checked||false;
    gonderIslem(id, islem, not, odul);
}

function gonderIslem(id, islem, not, odul){
    fetch(BASE_URL+'/bolumler/ik/ajax/oneri-islem.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id,islem,not,odul})
    }).then(r=>r.json()).then(r=>{
        if(r.ok){
            document.getElementById('oneriModal').style.display='none';
            location.reload();
        } else { alert('Hata: '+(r.hata||'Bilinmeyen')); }
    }).catch(()=>alert('Bağlantı hatası'));
}
</script>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-oneri');});
</script>