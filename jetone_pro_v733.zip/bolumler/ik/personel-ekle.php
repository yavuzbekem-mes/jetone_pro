<?php
/**
 * İK — Personel Ekle / Düzenle
 * bolumler/ik/personel-ekle.php
 */
if (!Auth::yetkiKontrol('ik', 'ekle')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}

$duzenle_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$personel   = null;

if ($duzenle_id) {
    try {
        $stmt = $db->prepare("SELECT * FROM personeller WHERE id=? LIMIT 1");
        $stmt->execute([$duzenle_id]);
        $personel = $stmt->fetch();
    } catch (Exception $e) {}
}

// Yardımcı veriler
try {
    $departmanlar = $db->query("SELECT id, ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();
    $yoneticiler  = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad, pozisyon FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();
} catch (Exception $e) {
    $departmanlar = []; $yoneticiler = [];
}

// Otomatik sicil no üret
function yeni_sicil_no($db) {
    try {
        $son = $db->query("SELECT MAX(CAST(SUBSTRING(sicil_no,3) AS UNSIGNED)) FROM personeller WHERE sicil_no LIKE 'P-%'")->fetchColumn();
        return 'P-' . str_pad(((int)$son) + 1, 5, '0', STR_PAD_LEFT);
    } catch (Exception $e) {
        return 'P-00001';
    }
}

$yeni_sicil = $duzenle_id ? ($personel['sicil_no'] ?? '') : yeni_sicil_no($db);

function val($personel, $key, $default = '') {
    if (!$personel) return $default;
    return htmlspecialchars($personel[$key] ?? $default);
}
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $duzenle_id ? '✏️ Personel Düzenle' : '➕ Personel Ekle'; ?></h1>
    <div class="s-yol">İnsan Kaynakları / Personeller / <b><?php echo $duzenle_id ? 'Düzenle' : 'Yeni Kayıt'; ?></b></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personeller" class="btn btn-b">← Listeye Dön</a>
  </div>
</div>

<div class="s-body">
<form id="personelForm" novalidate>
  <input type="hidden" name="id" value="<?php echo $duzenle_id; ?>">

  <!-- ── SEKME NAVİGASYONU ─────────────────────────── -->
  <div class="form-sekme-nav">
    <button type="button" class="fsn aktif" onclick="sekmeGit(1,this)" data-sekme="1">
      <span class="fsn-no">1</span><span class="fsn-ad">Kişisel Bilgiler</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(2,this)" data-sekme="2">
      <span class="fsn-no">2</span><span class="fsn-ad">Organizasyonel</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(3,this)" data-sekme="3">
      <span class="fsn-no">3</span><span class="fsn-ad">Eğitim & Askerlik</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(4,this)" data-sekme="4">
      <span class="fsn-no">4</span><span class="fsn-ad">İletişim & Acil</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(5,this)" data-sekme="5">
      <span class="fsn-no">5</span><span class="fsn-ad">İş & SGK</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(6,this)" data-sekme="6">
      <span class="fsn-no">6</span><span class="fsn-ad">Finansal</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(7,this)" data-sekme="7">
      <span class="fsn-no">7</span><span class="fsn-ad">Sağlık & İSG</span>
    </button>
    <div class="fsn-cizgi"></div>
    <button type="button" class="fsn" onclick="sekmeGit(8,this)" data-sekme="8">
      <span class="fsn-no">8</span><span class="fsn-ad">Özlük Dosyası</span>
    </button>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 1 — KİŞİSEL BİLGİLER
  ════════════════════════════════════════════ -->
  <div class="form-sekme aktif" id="sekme-1">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">👤 Kişisel Bilgiler</div></div>

      <!-- Fotoğraf + sicil -->
      <div style="display:flex;gap:24px;margin-bottom:20px;align-items:flex-start">
        <div style="flex-shrink:0;text-align:center">
          <div id="fotoOnizleme" style="width:100px;height:110px;border-radius:10px;background:var(--t-a);border:2px dashed var(--t);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;font-size:24px;overflow:hidden" onclick="document.getElementById('fotoInput').click()">
            <?php if ($personel && $personel['foto']): ?>
            <img src="<?php echo BASE_URL; ?>/bolumler/ik/resimler/<?php echo val($personel,'foto'); ?>" style="width:100%;height:100%;object-fit:cover">
            <?php else: ?>
            📷<div style="font-size:10px;margin-top:4px;color:var(--m2)">Fotoğraf Yükle</div>
            <?php endif; ?>
          </div>
          <input type="file" id="fotoInput" name="foto" accept="image/*" style="display:none" onchange="onizleFoto(this)">
          <div style="font-size:10px;color:var(--m3);margin-top:4px">JPG, PNG max 2MB</div>
        </div>
        <div style="flex:1">
          <div class="form-grid-3">
            <div class="form-grup">
              <label class="form-et">Sicil No <span class="zorunlu">*</span></label>
              <input type="text" class="form-alan" name="sicil_no" value="<?php echo $duzenle_id ? val($personel,'sicil_no') : $yeni_sicil; ?>" required>
            </div>
            <div class="form-grup">
              <label class="form-et">T.C. Kimlik No</label>
              <input type="text" class="form-alan" name="tc_kimlik" value="<?php echo val($personel,'tc_kimlik'); ?>" maxlength="11" placeholder="11 haneli">
            </div>
            <div class="form-grup">
              <label class="form-et">Uyruk</label>
              <input type="text" class="form-alan" name="uyruk" value="<?php echo val($personel,'uyruk','T.C.'); ?>">
            </div>
          </div>
        </div>
      </div>

      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Ad <span class="zorunlu">*</span></label>
          <input type="text" class="form-alan" name="ad" value="<?php echo val($personel,'ad'); ?>" required>
        </div>
        <div class="form-grup">
          <label class="form-et">Soyad <span class="zorunlu">*</span></label>
          <input type="text" class="form-alan" name="soyad" value="<?php echo val($personel,'soyad'); ?>" required>
        </div>
        <div class="form-grup">
          <label class="form-et">Cinsiyet</label>
          <select class="form-alan" name="cinsiyet">
            <option value="">— Seçin —</option>
            <option value="1" <?php echo ($personel['cinsiyet']??'')=='1'?'selected':''; ?>>Erkek</option>
            <option value="2" <?php echo ($personel['cinsiyet']??'')=='2'?'selected':''; ?>>Kadın</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Doğum Tarihi</label>
          <input type="date" class="form-alan" name="dogum_tarihi" value="<?php echo val($personel,'dogum_tarihi'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Doğum Yeri</label>
          <input type="text" class="form-alan" name="dogum_yeri" value="<?php echo val($personel,'dogum_yeri'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Kan Grubu</label>
          <select class="form-alan" name="kan_grubu">
            <option value="">— Seçin —</option>
            <?php foreach(['A+','A-','B+','B-','AB+','AB-','0+','0-'] as $k): ?>
            <option value="<?php echo $k; ?>" <?php echo ($personel['kan_grubu']??'')===$k?'selected':''; ?>><?php echo $k; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Medeni Durum</label>
          <select class="form-alan" name="medeni_durum">
            <option value="">— Seçin —</option>
            <option value="bekâr"     <?php echo ($personel['medeni_durum']??'')==='bekâr'?'selected':''; ?>>Bekâr</option>
            <option value="evli"      <?php echo ($personel['medeni_durum']??'')==='evli'?'selected':''; ?>>Evli</option>
            <option value="boşanmış"  <?php echo ($personel['medeni_durum']??'')==='boşanmış'?'selected':''; ?>>Boşanmış</option>
            <option value="dul"       <?php echo ($personel['medeni_durum']??'')==='dul'?'selected':''; ?>>Dul</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Çocuk Sayısı</label>
          <input type="number" class="form-alan" name="cocuk_sayisi" value="<?php echo val($personel,'cocuk_sayisi','0'); ?>" min="0" max="20">
        </div>
      </div>

      <!-- Engellilik -->
      <div style="background:var(--bg);border-radius:var(--r);padding:14px;margin-bottom:4px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:10px;text-transform:uppercase">Engellilik Durumu</div>
        <div class="form-grid-3">
          <div class="form-grup">
            <label class="form-et">Engellilik</label>
            <select class="form-alan" name="engellilik_durumu">
              <option value="0" <?php echo !($personel['engellilik_durumu']??0)?'selected':''; ?>>Yok</option>
              <option value="1" <?php echo ($personel['engellilik_durumu']??0)?'selected':''; ?>>Var</option>
            </select>
          </div>
          <div class="form-grup">
            <label class="form-et">Engellilik Oranı (%)</label>
            <input type="number" class="form-alan" name="engellilik_orani" value="<?php echo val($personel,'engellilik_orani','0'); ?>" min="0" max="100">
          </div>
        </div>
      </div>

      <!-- Fiziksel ölçüler -->
      <div style="background:var(--bg);border-radius:var(--r);padding:14px;margin-top:14px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:10px;text-transform:uppercase">👕 Kıyafet / İSG Ölçüleri</div>
        <div class="form-grid-3">
          <div class="form-grup">
            <label class="form-et">Ayakkabı No</label>
            <select class="form-alan" name="ayakkabi_no">
              <option value="">— Seçin —</option>
              <?php for($i=36;$i<=46;$i++) echo "<option value='$i' ".((($personel['ayakkabi_no']??'')==$i)?'selected':'').">$i</option>"; ?>
            </select>
          </div>
          <div class="form-grup">
            <label class="form-et">Üst Beden</label>
            <select class="form-alan" name="ust_beden">
              <option value="">— Seçin —</option>
              <?php foreach(['XS','S','M','L','XL','XXL','3XL'] as $b): ?>
              <option value="<?php echo $b; ?>" <?php echo ($personel['ust_beden']??'')===$b?'selected':''; ?>><?php echo $b; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-grup">
            <label class="form-et">Pantolon Beden</label>
            <input type="text" class="form-alan" name="pantolon_beden" value="<?php echo val($personel,'pantolon_beden'); ?>" placeholder="Örn: 32/34">
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 2 — ORGANİZASYONEL
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-2">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🏢 Organizasyonel Bilgiler</div></div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Departman <span class="zorunlu">*</span></label>
          <select class="form-alan" name="departman_id" required>
            <option value="">— Departman Seçin —</option>
            <?php foreach ($departmanlar as $d): ?>
            <option value="<?php echo $d['id']; ?>" <?php echo ($personel['departman_id']??'')==$d['id']?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Pozisyon <span class="zorunlu">*</span></label>
          <input type="text" class="form-alan" name="pozisyon" value="<?php echo val($personel,'pozisyon'); ?>" required placeholder="Örn: Üretim Operatörü">
        </div>
        <div class="form-grup">
          <label class="form-et">Unvan</label>
          <input type="text" class="form-alan" name="unvan" value="<?php echo val($personel,'unvan'); ?>" placeholder="Örn: Takım Lideri">
        </div>
        <div class="form-grup">
          <label class="form-et">Kadro <span class="zorunlu">*</span></label>
          <select class="form-alan" name="kadro">
            <option value="">— Kadro Seçin —</option>
            <option value="beyaz_yaka"  <?php echo ($personel['kadro']??'')==='beyaz_yaka'?'selected':''; ?>>👔 Beyaz Yaka</option>
            <option value="endirekt"    <?php echo ($personel['kadro']??'')==='endirekt'?'selected':''; ?>>🔧 Endirekt (Mavi Yaka)</option>
            <option value="direkt"      <?php echo ($personel['kadro']??'')==='direkt'?'selected':''; ?>>🏭 Direkt (Üretim)</option>
            <option value="stajyer"     <?php echo ($personel['kadro']??'')==='stajyer'?'selected':''; ?>>🎓 Stajyer</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Bağlı Yönetici</label>
          <select class="form-alan" name="yonetici_id">
            <option value="">— Yönetici Seçin —</option>
            <?php foreach ($yoneticiler as $y): ?>
            <?php if ($duzenle_id && $y['id'] == $duzenle_id) continue; ?>
            <option value="<?php echo $y['id']; ?>" <?php echo ($personel['yonetici_id']??'')==$y['id']?'selected':''; ?>>
              <?php echo htmlspecialchars($y['ad_soyad']); ?> — <?php echo htmlspecialchars($y['pozisyon'] ?? ''); ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Çalışma Şekli</label>
          <select class="form-alan" name="calısma_tipi">
            <option value="tam_zamanli"  <?php echo ($personel['calısma_tipi']??'')==='tam_zamanli'?'selected':''; ?>>Tam Zamanlı</option>
            <option value="yari_zamanli" <?php echo ($personel['calısma_tipi']??'')==='yari_zamanli'?'selected':''; ?>>Yarı Zamanlı</option>
            <option value="uzaktan"      <?php echo ($personel['calısma_tipi']??'')==='uzaktan'?'selected':''; ?>>Uzaktan (Remote)</option>
            <option value="hibrit"       <?php echo ($personel['calısma_tipi']??'')==='hibrit'?'selected':''; ?>>Hibrit</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Vardiya Sistemi <span class="zorunlu">*</span></label>
          <select class="form-alan" name="vardiya_tipi" id="vardiyaTipiSel" onchange="vardiyaTipiDegis(this.value)">
            <option value="">— Seçin —</option>
            <option value="beyaz"  <?php echo ($personel['vardiya_tipi']??'')==='beyaz'?'selected':''; ?>>&#128197; Beyaz Yaka (08:00&#8211;18:00)</option>
            <option value="tek"    <?php echo ($personel['vardiya_tipi']??'')==='tek'?'selected':''; ?>>&#128197; Tek Vardiya (08:00&#8211;16:00)</option>
            <option value="3lu"    <?php echo ($personel['vardiya_tipi']??'')==='3lu'?'selected':''; ?>>&#128260; 3'lu Vardiya Sistemi</option>
          </select>
        </div>
        <div class="form-grup" id="aktifVardiyaGrup" style="<?php echo ($personel['vardiya_tipi']??'')==='3lu'?'':'display:none'; ?>">
          <label class="form-et">Aktif Vardiya (3'lü Sistem)</label>
          <select class="form-alan" name="aktif_vardiya">
            <option value="">— Başlangıç Vardiyası —</option>
            <option value="1" <?php echo ($personel['aktif_vardiya']??'')==='1'?'selected':''; ?>>1. Vardiya  08:00 – 16:00</option>
            <option value="2" <?php echo ($personel['aktif_vardiya']??'')==='2'?'selected':''; ?>>2. Vardiya  16:00 – 00:00</option>
            <option value="3" <?php echo ($personel['aktif_vardiya']??'')==='3'?'selected':''; ?>>3. Vardiya  00:00 – 08:00</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Servis Durağı</label>
          <select class="form-alan" name="servis_durak">
            <option value="">— Servis Kullanmıyor —</option>
            <option value="cerkezkoy"  <?php echo ($personel['servis_durak']??'')==='cerkezkoy'?'selected':''; ?>>🚌 Çerkezköy</option>
            <option value="kizilpinar" <?php echo ($personel['servis_durak']??'')==='kizilpinar'?'selected':''; ?>>🚌 Kızılpınar</option>
            <option value="kapakli"    <?php echo ($personel['servis_durak']??'')==='kapakli'?'selected':''; ?>>🚌 Kapaklı</option>
            <option value="karaagac"   <?php echo ($personel['servis_durak']??'')==='karaagac'?'selected':''; ?>>🚌 Karaağaç</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Çalışma Yeri / Lokasyon</label>
          <input type="text" class="form-alan" name="calisma_yeri" value="<?php echo val($personel,'calisma_yeri'); ?>" placeholder="Örn: Ana Fabrika, Depo B">
        </div>
        <div class="form-grup form-span-2">
          <label class="form-et">Taşeron / Tedarikçi Firma <span style="font-size:11px;color:var(--m2);font-weight:400">(Dışarıdan temin edilen personel için)</span></label>
          <input type="text" class="form-alan" name="tedarikci_firma" value="<?php echo val($personel,'tedarikci_firma'); ?>" placeholder="Taşeron firma adı">
        </div>
      </div>

      <div style="background:var(--bg);border-radius:var(--r);padding:14px;margin-top:14px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:10px;text-transform:uppercase">📅 İşe Giriş Bilgileri</div>
        <div class="form-grid-3">
          <div class="form-grup">
            <label class="form-et">İşe Başlama Tarihi <span class="zorunlu">*</span></label>
            <input type="date" class="form-alan" name="ise_baslama" value="<?php echo val($personel,'ise_baslama'); ?>" required>
          </div>
          <div class="form-grup">
            <label class="form-et">Deneme Süresi Bitiş</label>
            <input type="date" class="form-alan" name="deneme_bitis" value="<?php echo val($personel,'deneme_bitis'); ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">İş Sözleşmesi Tipi</label>
            <select class="form-alan" name="is_sozlesmesi_tipi">
              <option value="belirsiz_sureli" <?php echo ($personel['is_sozlesmesi_tipi']??'belirsiz_sureli')==='belirsiz_sureli'?'selected':''; ?>>Belirsiz Süreli</option>
              <option value="belirli_sureli"  <?php echo ($personel['is_sozlesmesi_tipi']??'')==='belirli_sureli'?'selected':''; ?>>Belirli Süreli</option>
              <option value="kismi_sureli"    <?php echo ($personel['is_sozlesmesi_tipi']??'')==='kismi_sureli'?'selected':''; ?>>Kısmi Süreli</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 3 — EĞİTİM & ASKERLİK
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-3">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🎓 Eğitim Bilgileri</div></div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Eğitim Seviyesi</label>
          <select class="form-alan" name="egitim_seviyesi">
            <option value="">— Seçin —</option>
            <?php
            $seviyeler = ['ilkokul'=>'İlkokul','ortaokul'=>'Ortaokul','lise'=>'Lise','onlisans'=>'Ön Lisans','lisans'=>'Lisans','yukseklisans'=>'Yüksek Lisans','doktora'=>'Doktora'];
            foreach ($seviyeler as $k=>$v):
            ?>
            <option value="<?php echo $k; ?>" <?php echo ($personel['egitim_seviyesi']??'')===$k?'selected':''; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">Mezuniyet Yılı</label>
          <input type="number" class="form-alan" name="mezuniyet_yili" value="<?php echo val($personel,'mezuniyet_yili'); ?>" min="1960" max="<?php echo date('Y'); ?>" placeholder="<?php echo date('Y'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">Okul / Üniversite Adı</label>
          <input type="text" class="form-alan" name="okul_adi" value="<?php echo val($personel,'okul_adi'); ?>" placeholder="Örn: Gazi Üniversitesi">
        </div>
        <div class="form-grup">
          <label class="form-et">Bölüm / Alan</label>
          <input type="text" class="form-alan" name="bolum" value="<?php echo val($personel,'bolum'); ?>" placeholder="Örn: Makine Mühendisliği">
        </div>
      </div>
    </div>

    <div class="kart" style="margin-top:14px">
      <div class="kart-ust"><div class="kart-bas">🪖 Askerlik Durumu</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Askerlik Durumu</label>
          <select class="form-alan" name="askerlik_durumu" id="askerlikDurum" onchange="askerlikGoster()">
            <option value="">— Seçin —</option>
            <option value="yapildi"    <?php echo ($personel['askerlik_durumu']??'')==='yapildi'?'selected':''; ?>>Yapıldı</option>
            <option value="muaf"       <?php echo ($personel['askerlik_durumu']??'')==='muaf'?'selected':''; ?>>Muaf</option>
            <option value="tecilli"    <?php echo ($personel['askerlik_durumu']??'')==='tecilli'?'selected':''; ?>>Tecilli</option>
            <option value="yapilmadi"  <?php echo ($personel['askerlik_durumu']??'')==='yapilmadi'?'selected':''; ?>>Yapılmadı</option>
            <option value="kadin"      <?php echo ($personel['askerlik_durumu']??'')==='kadin'?'selected':''; ?>>Kadın Personel</option>
          </select>
        </div>
        <div class="form-grup" id="askerlikTarihGrup" style="<?php echo in_array($personel['askerlik_durumu']??'', ['yapildi','tecilli']) ? '' : 'display:none'; ?>">
          <label class="form-et">Terhis / Tecil Tarihi</label>
          <input type="date" class="form-alan" name="askerlik_tarihi" value="<?php echo val($personel,'askerlik_tarihi'); ?>">
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 4 — İLETİŞİM & ACİL DURUM
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-4">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📞 İletişim Bilgileri</div></div>
      <div class="form-grid-2">
        <div class="form-grup">
          <label class="form-et">Cep Telefonu <span class="zorunlu">*</span></label>
          <input type="tel" class="form-alan" name="telefon" value="<?php echo val($personel,'telefon'); ?>" required placeholder="05XX XXX XX XX">
        </div>
        <div class="form-grup">
          <label class="form-et">İş Telefonu</label>
          <input type="tel" class="form-alan" name="tel_is" value="<?php echo val($personel,'tel_is'); ?>" placeholder="0XXX XXX XX XX">
        </div>
        <div class="form-grup">
          <label class="form-et">E-posta (Kişisel)</label>
          <input type="email" class="form-alan" name="email" value="<?php echo val($personel,'email'); ?>" placeholder="ad.soyad@gmail.com">
        </div>
      </div>
      <div class="form-grid-3" style="margin-top:8px">
        <div class="form-grup form-span-3">
          <label class="form-et">İkametgah Adresi</label>
          <textarea class="form-alan" name="adres" rows="2" placeholder="Sokak, mahalle, bina no..."><?php echo val($personel,'adres'); ?></textarea>
        </div>
        <div class="form-grup">
          <label class="form-et">İl</label>
          <input type="text" class="form-alan" name="il" value="<?php echo val($personel,'il'); ?>" placeholder="İstanbul">
        </div>
        <div class="form-grup">
          <label class="form-et">İlçe</label>
          <input type="text" class="form-alan" name="ilce" value="<?php echo val($personel,'ilce'); ?>" placeholder="Kadıköy">
        </div>
        <div class="form-grup">
          <label class="form-et">Posta Kodu</label>
          <input type="text" class="form-alan" name="posta_kodu" value="<?php echo val($personel,'posta_kodu'); ?>" placeholder="34XXX" maxlength="5">
        </div>
      </div>
    </div>

    <div class="kart" style="margin-top:14px">
      <div class="kart-ust">
        <div class="kart-bas">🚨 Acil Durum İletişim</div>
        <span style="font-size:12px;color:var(--m2)">Kaza / hastalık durumunda aranacak kişi</span>
      </div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Ad Soyad</label>
          <input type="text" class="form-alan" name="acil_kisi_ad" value="<?php echo val($personel,'acil_kisi_ad'); ?>" placeholder="Yakın adı">
        </div>
        <div class="form-grup">
          <label class="form-et">Telefon</label>
          <input type="tel" class="form-alan" name="acil_kisi_tel" value="<?php echo val($personel,'acil_kisi_tel'); ?>" placeholder="05XX XXX XX XX">
        </div>
        <div class="form-grup">
          <label class="form-et">Yakınlık Derecesi</label>
          <select class="form-alan" name="acil_kisi_yakinlik">
            <option value="">— Seçin —</option>
            <?php foreach(['Eş','Anne','Baba','Kardeş','Çocuk','Diğer Akraba','Arkadaş'] as $y): ?>
            <option value="<?php echo $y; ?>" <?php echo ($personel['acil_kisi_yakinlik']??'')===$y?'selected':''; ?>><?php echo $y; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 5 — İŞ & SGK
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-5">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📋 SGK & Yasal Bilgiler</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">SGK Numarası</label>
          <input type="text" class="form-alan" name="sgk_no" value="<?php echo val($personel,'sgk_no'); ?>" placeholder="Sigorta sicil no">
        </div>
        <div class="form-grup">
          <label class="form-et">Durum</label>
          <select class="form-alan" name="durum">
            <option value="aktif"   <?php echo ($personel['durum']??'aktif')==='aktif'?'selected':''; ?>>✓ Aktif</option>
            <option value="izinli"  <?php echo ($personel['durum']??'')==='izinli'?'selected':''; ?>>🏖 İzinli</option>
            <option value="ayrıldı" <?php echo ($personel['durum']??'')==='ayrıldı'?'selected':''; ?>>✗ Ayrıldı</option>
          </select>
        </div>
      </div>
      <div id="ayrilikBilgileri" style="<?php echo ($personel['durum']??'')==='ayrıldı' ? '' : 'display:none'; ?>;background:var(--hat-a);border-radius:var(--r);padding:14px;margin-top:8px">
        <div style="font-size:12px;font-weight:700;color:var(--hat);margin-bottom:10px">İşten Ayrılış Bilgileri</div>
        <div class="form-grid-2">
          <div class="form-grup">
            <label class="form-et">Çıkış Tarihi</label>
            <input type="date" class="form-alan" name="cikis_tarihi" value="<?php echo val($personel,'cikis_tarihi'); ?>">
          </div>
          <div class="form-grup">
            <label class="form-et">Ayrılış Nedeni</label>
            <select class="form-alan" name="cikis_nedeni">
              <option value="">— Seçin —</option>
              <?php foreach(['İstifa','Sözleşme Sona Ermesi','Emeklilik','İşveren Feshi','Askerlik','Vefat','Diğer'] as $n): ?>
              <option value="<?php echo $n; ?>" <?php echo ($personel['cikis_nedeni']??'')===$n?'selected':''; ?>><?php echo $n; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>
    </div>

    <!-- Personel Portal Hesabı -->
    <div class="kart" style="margin-top:14px">
      <div class="kart-ust"><div class="kart-bas">🧑‍💼 Personel Portalı Erişimi</div></div>

      <div style="background:var(--t-a);border:1px solid #FED7AA;border-radius:var(--r);padding:14px;margin-bottom:16px;display:flex;gap:12px">
        <span style="font-size:20px;flex-shrink:0">ℹ️</span>
        <div style="font-size:13px;color:var(--m2)">
          Personel portalı <b>her zaman oluşturulur</b>. Kullanıcı adı sicil no, ilk şifre tek kullanımlıktır.<br>
          İlk girişte şifre değiştirmesi zorunludur.
        </div>
      </div>

      <div class="form-grid-2" style="margin-bottom:4px">
        <div class="form-grup">
          <label class="form-et">Portal Erişim Durumu</label>
          <select class="form-alan" name="portal_aktif">
            <option value="1" <?php echo ($personel['portal_aktif']??1)==1?'selected':''; ?>>✓ Aktif — Hemen giriş yapabilir</option>
            <option value="0" <?php echo ($personel['portal_aktif']??1)==0?'selected':''; ?>>⏸ Pasif — Şimdilik kapalı</option>
          </select>
        </div>
        <?php if (!$duzenle_id): ?>
        <div class="form-grup">
          <label class="form-et">Personel Portal İlk Şifre</label>
          <input type="text" class="form-alan" id="portalIlkSifre" placeholder="Otomatik üretilecek"
                 style="background:var(--bg);color:var(--m3);cursor:default" readonly
                 title="Kayıt sonrası gösterilecek">
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- ERP Panel Hesabı -->
    <div class="kart" style="margin-top:14px">
      <div class="kart-ust">
        <div class="kart-bas">🖥️ ERP Yönetim Paneli Erişimi</div>
        <span class="roz" style="background:#FEF0C7;color:#B45309;font-size:11px">Opsiyonel</span>
      </div>

      <div style="background:#F0F4FF;border:1px solid #C7D7FD;border-radius:var(--r);padding:14px;margin-bottom:16px;display:flex;gap:12px">
        <span style="font-size:20px;flex-shrink:0">💡</span>
        <div style="font-size:13px;color:#3730A3">
          Bu personele <b>ERP yönetim paneline</b> giriş izni vermek istiyorsanız aşağıdaki seçeneği aktif edin.<br>
          İlk girişte şifre değiştirmesi istenecektir. Kullanıcı adı e-posta adresidir.
        </div>
      </div>

      <!-- Ana Toggle -->
      <div id="erpErisimToggleKutu"
           style="display:flex;align-items:center;justify-content:space-between;padding:16px;border:2px solid var(--kenar);border-radius:var(--r-lg);cursor:pointer;transition:all .2s;margin-bottom:14px"
           onclick="erpErisimToggle()"
           onmouseover="this.style.borderColor='var(--mavi)'"
           onmouseout="document.getElementById('erpErisimAktif').value=='1'?this.style.borderColor='#3B82F6':this.style.borderColor='var(--kenar)'">
        <div style="display:flex;align-items:center;gap:12px">
          <div id="erpToggleIkon" style="width:46px;height:46px;border-radius:12px;background:#F0F4FF;display:flex;align-items:center;justify-content:center;font-size:22px;transition:background .2s">🔒</div>
          <div>
            <div id="erpToggleYazi" style="font-size:14px;font-weight:700;color:var(--m)">ERP Panel Erişimi Verilmeyecek</div>
            <div id="erpToggleAlt" style="font-size:12px;color:var(--m2)">Personel sadece personel portalına erişebilir</div>
          </div>
        </div>
        <!-- Switch -->
        <div id="erpSwitch" style="width:48px;height:26px;background:#D1D5DB;border-radius:13px;position:relative;transition:background .2s;flex-shrink:0">
          <div id="erpSwitchKnob" style="position:absolute;top:3px;left:3px;width:20px;height:20px;background:#fff;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,.2);transition:left .2s"></div>
        </div>
      </div>
      <input type="hidden" name="erp_erisim_aktif" id="erpErisimAktif" value="0">

      <!-- ERP Ayar Detayları — gizli, toggle açınca gelir -->
      <div id="erpErisimDetay" style="display:none">
        <div style="border:1px solid #C7D7FD;border-radius:var(--r-lg);padding:16px;background:#F8FAFF">
          <div class="form-grid-2">
            <div class="form-grup">
              <label class="form-et">ERP Kullanıcı Rolü <span class="zorunlu">*</span></label>
              <select class="form-alan" name="erp_rol_id" id="erpRolId">
                <option value="">— Rol Seçin —</option>
                <?php
                try {
                    $roller = $db->query("SELECT id, ad FROM roller ORDER BY id")->fetchAll();
                    foreach ($roller as $rol):
                ?>
                <option value="<?php echo $rol['id']; ?>"><?php echo htmlspecialchars($rol['ad']); ?></option>
                <?php endforeach; } catch (Exception $e) {} ?>
              </select>
            </div>
            <div class="form-grup">
              <label class="form-et">ERP E-posta (Kullanıcı Adı)</label>
              <input type="email" class="form-alan" name="erp_email" id="erpEmail"
                     placeholder="personel@firma.com">
              <div style="font-size:11px;color:var(--m2);margin-top:3px">Boş bırakılırsa personel e-postası kullanılır</div>
            </div>
            <?php if (!$duzenle_id): ?>
            <div class="form-grup form-span-2">
              <label class="form-et">ERP İlk Şifre</label>
              <input type="text" class="form-alan" id="erpIlkSifre" placeholder="Otomatik üretilecek"
                     style="background:var(--bg);color:var(--m3)" readonly>
              <div style="font-size:11px;color:var(--m2);margin-top:3px">İlk girişte şifre değiştirmesi zorunlu olacak</div>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 6 — FİNANSAL
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-6">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">💰 Maaş & Yan Haklar</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Net Maaş (₺)</label>
          <input type="number" class="form-alan" name="maas" value="<?php echo val($personel,'maas','0'); ?>" step="0.01" min="0" placeholder="0.00">
        </div>
        <div class="form-grup">
          <label class="form-et">Brüt Maaş (₺)</label>
          <input type="number" class="form-alan" name="brut_maas" value="<?php echo val($personel,'brut_maas','0'); ?>" step="0.01" min="0" placeholder="0.00">
        </div>
        <div class="form-grup">
          <label class="form-et">Yol Ücreti (₺/ay)</label>
          <input type="number" class="form-alan" name="yol_ucreti" value="<?php echo val($personel,'yol_ucreti','0'); ?>" step="0.01" min="0" placeholder="0.00">
        </div>
        <div class="form-grup">
          <label class="form-et">Yemek Ücreti (₺/ay)</label>
          <input type="number" class="form-alan" name="yemek_ucreti" value="<?php echo val($personel,'yemek_ucreti','0'); ?>" step="0.01" min="0" placeholder="0.00">
        </div>
      </div>
    </div>

    <div class="kart" style="margin-top:14px">
      <div class="kart-ust"><div class="kart-bas">🏦 Banka Bilgileri</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Banka Adı</label>
          <select class="form-alan" name="banka_adi">
            <option value="">— Seçin —</option>
            <?php foreach(['Ziraat Bankası','Halkbank','Vakıfbank','İş Bankası','Yapı Kredi','Garanti BBVA','Akbank','Denizbank','QNB Finansbank','ING','HSBC','TEB','Odeabank','Şekerbank','Diğer'] as $b): ?>
            <option value="<?php echo $b; ?>" <?php echo ($personel['banka_adi']??'')===$b?'selected':''; ?>><?php echo $b; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-grup form-span-2">
          <label class="form-et">IBAN</label>
          <input type="text" class="form-alan" name="banka_iban" value="<?php echo val($personel,'banka_iban'); ?>"
                 placeholder="TR00 0000 0000 0000 0000 0000 00" maxlength="32"
                 oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'').replace(/(.{4})/g,'$1 ').trim()">
        </div>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 7 — SAĞLIK & İSG
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-7">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">🏥 Sağlık & İş Güvenliği</div></div>
      <div class="form-grid-3">
        <div class="form-grup">
          <label class="form-et">Sağlık Raporu</label>
          <select class="form-alan" name="saglik_raporu_var">
            <option value="0" <?php echo !($personel['saglik_raporu_var']??0)?'selected':''; ?>>Henüz Alınmadı</option>
            <option value="1" <?php echo ($personel['saglik_raporu_var']??0)?'selected':''; ?>>✓ Alındı / Mevcut</option>
          </select>
        </div>
        <div class="form-grup">
          <label class="form-et">İSG Eğitim Tarihi</label>
          <input type="date" class="form-alan" name="isg_egitim_tarihi" value="<?php echo val($personel,'isg_egitim_tarihi'); ?>">
        </div>
        <div class="form-grup">
          <label class="form-et">İSG Eğitim Süresi (Saat)</label>
          <input type="number" class="form-alan" name="isg_egitim_sure" value="<?php echo val($personel,'isg_egitim_sure'); ?>" min="0" placeholder="0">
        </div>
      </div>
      <div class="form-grup" style="margin-top:8px">
        <label class="form-et">Notlar</label>
        <textarea class="form-alan" name="notlar" rows="3" placeholder="Sağlık durumu, kronik hastalık, allerji, özel durum..."><?php echo val($personel,'notlar'); ?></textarea>
      </div>
    </div>
  </div>

  <!-- ════════════════════════════════════════════
       SEKME 8 — ÖZLÜK DOSYASI
  ════════════════════════════════════════════ -->
  <div class="form-sekme" id="sekme-8">
    <div class="kart">
      <div class="kart-ust"><div class="kart-bas">📁 Özlük Dosyası Kontrol Listesi</div></div>
      <div style="font-size:13px;color:var(--m2);margin-bottom:16px">
        Saklama süreleri: Vergi → 5 yıl &nbsp;|&nbsp; SGK → 10 yıl &nbsp;|&nbsp; İSG → 15 yıl
      </div>

      <?php
      $ozluk_kategoriler = [
        'kisisel'     => ['ad'=>'👤 Kişisel Belgeler', 'renkler'=>['#E0F2FE','#0284C7'], 'kalemler'=>[
          'Nüfus Cüzdanı Fotokopisi','İkametgah Belgesi','Vesikalık Fotoğraf','Adli Sicil Kaydı'
        ]],
        'egitim'      => ['ad'=>'🎓 Eğitim & Mesleki', 'renkler'=>['#D1FADF','#0A8F4E'], 'kalemler'=>[
          'Diploma Fotokopisi','Sertifikalar','Özgeçmiş (CV)'
        ]],
        'is_iliskisi' => ['ad'=>'📋 İş İlişkisi', 'renkler'=>['#FEF0C7','#B45309'], 'kalemler'=>[
          'İş Sözleşmesi','SGK İşe Giriş Bildirgesi','Aile Durum Bildirim Formu','Askerlik Durum Belgesi'
        ]],
        'saglik'      => ['ad'=>'🏥 Sağlık & Güvenlik', 'renkler'=>['#FEE4E2','#F04438'], 'kalemler'=>[
          'Sağlık Raporu (İşe Giriş)','İSG Eğitim Belgesi','İSG Taahhütnamesi'
        ]],
        'is_sureci'   => ['ad'=>'⚙️ İş Süreci', 'renkler'=>['#F4F5F7','#667085'], 'kalemler'=>[
          'Kıyafet & Ekipman Zimmet Formu','İşe Giriş Oryantasyon Tutanağı','Gizlilik Sözleşmesi'
        ]],
      ];
      ?>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
      <?php foreach ($ozluk_kategoriler as $kat_key => $kat): ?>
      <div style="background:<?php echo $kat['renkler'][0]; ?>;border:1px solid <?php echo $kat['renkler'][0]; ?>;border-radius:var(--r-lg);padding:14px">
        <div style="font-size:13px;font-weight:700;color:<?php echo $kat['renkler'][1]; ?>;margin-bottom:10px"><?php echo $kat['ad']; ?></div>
        <?php foreach ($kat['kalemler'] as $i => $kalem): ?>
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:7px;cursor:pointer;font-size:13px">
          <input type="checkbox" name="belge_<?php echo $kat_key; ?>[]" value="<?php echo htmlspecialchars($kalem); ?>"
                 style="accent-color:<?php echo $kat['renkler'][1]; ?>;width:15px;height:15px">
          <?php echo htmlspecialchars($kalem); ?>
        </label>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
      </div>

      <div style="background:var(--bg);border-radius:var(--r);padding:14px;margin-top:14px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);margin-bottom:8px">📝 Ek Notlar</div>
        <textarea class="form-alan" name="ozluk_notlar" rows="2" placeholder="Eksik belgeler, takip notu..."></textarea>
      </div>
    </div>
  </div>

  <!-- Alt butonlar -->
  <div class="form-alt-butonlar">
    <button type="button" class="btn btn-b" id="btnGeri" onclick="sekmeGeriIleri(-1)" style="display:none">← Geri</button>
    <div style="display:flex;align-items:center;gap:8px;margin-left:auto">
      <span id="sekmeGostergesi" style="font-size:12px;color:var(--m2)">Adım 1 / 8</span>
      <button type="button" class="btn btn-b" id="btnIleri" onclick="sekmeGeriIleri(1)">İleri →</button>
      <button type="submit" class="btn btn-t" id="btnKaydet" style="display:none">
        💾 <?php echo $duzenle_id ? 'Güncelle' : 'Personeli Kaydet'; ?>
      </button>
    </div>
  </div>
</form>
</div>

<style>
/* ── Sekme navigasyonu ── */
.form-sekme-nav{display:flex;align-items:center;background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:12px 16px;margin-bottom:16px;overflow-x:auto;gap:0;flex-wrap:nowrap}
.fsn{display:flex;align-items:center;gap:7px;padding:8px 12px;border:none;background:none;cursor:pointer;border-radius:var(--r);transition:all .15s;white-space:nowrap;font-family:inherit}
.fsn:hover{background:var(--kenar-a)}
.fsn.aktif .fsn-no{background:var(--t);color:#fff}
.fsn.aktif .fsn-ad{color:var(--t);font-weight:700}
.fsn.tamam .fsn-no{background:var(--bas);color:#fff}
.fsn.tamam .fsn-ad{color:var(--bas)}
.fsn-no{width:24px;height:24px;border-radius:50%;background:var(--kenar);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:var(--m2);flex-shrink:0;transition:all .15s}
.fsn-ad{font-size:13px;font-weight:600;color:var(--m2)}
.fsn-cizgi{width:20px;height:2px;background:var(--kenar);flex-shrink:0;margin:0 2px}

/* ── Sekme panelleri ── */
.form-sekme{display:none;animation:sekmeGir .2s ease}
.form-sekme.aktif{display:block}
@keyframes sekmeGir{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}

/* ── Alt butonlar ── */
.form-alt-butonlar{
  display:flex;align-items:center;
  background:var(--yuzey);border:1px solid var(--kenar);
  border-radius:var(--r-lg);padding:14px 16px;
  margin-top:14px;position:sticky;bottom:70px;
  box-shadow:0 -4px 20px rgba(0,0,0,.08);
}

/* Grid düzeltme */
.form-grid-3 .form-span-3{grid-column:span 3}
.form-grid-2 .form-span-2{grid-column:span 2}
</style>

<script>
var aktifSekme = 1;
var toplamSekme = 8;

// Tablo satırı yardımcısı
function satir(etiket, deger, tip, bordur) {
  var degerHtml = '';
  if (tip === 'mono')       degerHtml = '<span style="font-family:monospace;font-weight:800;font-size:15px;color:#101828;letter-spacing:1px">'+deger+'</span>';
  else if (tip === 'sifre') degerHtml = '<span style="font-family:monospace;font-weight:800;font-size:15px;color:#F04438;letter-spacing:1px">'+deger+'</span>';
  else if (tip === 'mono-blue') degerHtml = '<span style="font-family:monospace;font-weight:800;font-size:13px;color:#1D4ED8">'+deger+'</span>';
  else if (tip === 'badge-blue') degerHtml = '<span style="background:#EFF6FF;color:#2563EB;font-size:11px;font-weight:700;padding:3px 8px;border-radius:12px">'+deger+'</span>';
  else if (tip === 'link')  degerHtml = '<span style="font-size:12px;color:#F97316">'+deger+'</span>';
  else if (tip === 'link-blue') degerHtml = '<span style="font-size:12px;color:#2563EB">'+deger+'</span>';
  else degerHtml = '<span style="font-size:13px">'+deger+'</span>';
  var border = bordur ? 'border-bottom:1px solid '+bordur+';' : '';
  return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;'+border+'">'
    + '<span style="font-size:12px;color:#667085">'+etiket+'</span>'
    + degerHtml + '</div>';
}

function sekmeGit(no, btn) {
  // Aktif sekmeyi gizle
  var eski = document.getElementById('sekme-' + aktifSekme);
  if (eski) eski.classList.remove('aktif');

  // Eski sekme butonunu "tamam" yap
  var eskiBtn = document.querySelector('.fsn[data-sekme="' + aktifSekme + '"]');
  if (eskiBtn && aktifSekme < no) {
    eskiBtn.classList.remove('aktif');
    eskiBtn.classList.add('tamam');
  } else if (eskiBtn) {
    eskiBtn.classList.remove('aktif');
  }

  // Yeni sekmeyi göster
  aktifSekme = no;
  var yeni = document.getElementById('sekme-' + aktifSekme);
  if (yeni) yeni.classList.add('aktif');

  // Nav butonlarını güncelle
  var tumBtn = document.querySelectorAll('.fsn');
  for (var i = 0; i < tumBtn.length; i++) {
    var bno = parseInt(tumBtn[i].getAttribute('data-sekme'));
    if (bno === aktifSekme) {
      tumBtn[i].classList.add('aktif');
      tumBtn[i].classList.remove('tamam');
    }
  }

  // Geri/İleri/Kaydet butonları
  var btnGeri   = document.getElementById('btnGeri');
  var btnIleri  = document.getElementById('btnIleri');
  var btnKaydet = document.getElementById('btnKaydet');
  var gosterge  = document.getElementById('sekmeGostergesi');

  btnGeri.style.display  = aktifSekme > 1 ? '' : 'none';
  btnIleri.style.display  = aktifSekme < toplamSekme ? '' : 'none';
  btnKaydet.style.display = aktifSekme === toplamSekme ? '' : 'none';
  gosterge.textContent = 'Adım ' + aktifSekme + ' / ' + toplamSekme;

  // Sayfanın en üstüne scroll
  var formTop = document.querySelector('.form-sekme-nav');
  if (formTop) formTop.scrollIntoView({behavior:'smooth', block:'start'});
}

function sekmeGeriIleri(yon) {
  var hedef = aktifSekme + yon;
  if (hedef < 1 || hedef > toplamSekme) return;
  var btn = document.querySelector('.fsn[data-sekme="' + hedef + '"]');
  sekmeGit(hedef, btn);
}

function askerlikGoster() {
  var val = document.getElementById('askerlikDurum').value;
  var grup = document.getElementById('askerlikTarihGrup');
  if (grup) grup.style.display = (val==='yapildi'||val==='tecilli') ? '' : 'none';
}

// ── ERP Erişim Toggle ─────────────────────────────────
function erpErisimToggle() {
  var hiddenInput = document.getElementById('erpErisimAktif');
  var aktif = hiddenInput.value === '1';
  aktif = !aktif;
  hiddenInput.value = aktif ? '1' : '0';

  var kutu   = document.getElementById('erpErisimToggleKutu');
  var ikon   = document.getElementById('erpToggleIkon');
  var yazi   = document.getElementById('erpToggleYazi');
  var alt    = document.getElementById('erpToggleAlt');
  var sw     = document.getElementById('erpSwitch');
  var knob   = document.getElementById('erpSwitchKnob');
  var detay  = document.getElementById('erpErisimDetay');

  if (aktif) {
    kutu.style.borderColor  = '#3B82F6';
    kutu.style.background   = '#EFF6FF';
    ikon.textContent        = '🔓';
    ikon.style.background   = '#DBEAFE';
    yazi.textContent        = 'ERP Panel Erişimi Verilecek';
    yazi.style.color        = '#1D4ED8';
    alt.textContent         = 'Personel ERP yönetim paneline giriş yapabilecek';
    sw.style.background     = '#3B82F6';
    knob.style.left         = '25px';
    if (detay) detay.style.display = 'block';
    // Boşsa personel e-postasını kopyala
    var erpEmail = document.getElementById('erpEmail');
    if (erpEmail && !erpEmail.value) {
      var perEmail = document.querySelector('[name="email"]');
      if (perEmail && perEmail.value) erpEmail.value = perEmail.value;
    }
  } else {
    kutu.style.borderColor  = 'var(--kenar)';
    kutu.style.background   = '';
    ikon.textContent        = '🔒';
    ikon.style.background   = '#F0F4FF';
    yazi.textContent        = 'ERP Panel Erişimi Verilmeyecek';
    yazi.style.color        = 'var(--m)';
    alt.textContent         = 'Personel sadece personel portalına erişebilir';
    sw.style.background     = '#D1D5DB';
    knob.style.left         = '3px';
    if (detay) detay.style.display = 'none';
  }
}

function onizleFoto(input) {
  if (!input.files || !input.files[0]) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    var div = document.getElementById('fotoOnizleme');
    div.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover">';
  };
  reader.readAsDataURL(input.files[0]);
}

// Form gönder
document.getElementById('personelForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // Zorunlu alan kontrolü
  var zorunlu = document.querySelectorAll('[required]');
  var eksik = false;
  for (var i = 0; i < zorunlu.length; i++) {
    if (!zorunlu[i].value.trim()) {
      zorunlu[i].style.borderColor = 'var(--hat)';
      zorunlu[i].focus();
      eksik = true;
      // Hangi sekmede?
      var sekme = zorunlu[i].closest('.form-sekme');
      if (sekme) {
        var no = parseInt(sekme.id.replace('sekme-',''));
        sekmeGit(no, document.querySelector('.fsn[data-sekme="'+no+'"]'));
      }
      break;
    } else {
      zorunlu[i].style.borderColor = '';
    }
  }
  if (eksik) {
    alert('Zorunlu alanları doldurun (kırmızı ile işaretlenmiş).');
    return;
  }

  var btn = document.getElementById('btnKaydet');
  btn.disabled = true;
  btn.textContent = '⏳ Kaydediliyor...';

  var formData = new FormData(this);

  fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/personel-kaydet.php', {
    method: 'POST',
    headers: {'X-Requested-With':'XMLHttpRequest'},
    body: formData
  })
  .then(function(r){ return r.json(); })
  .then(function(r) {
    if (r.ok) {
      // Güvenli değerler
      var sicilNo     = r.sicil_no     || '—';
      var portalSifre = r.portal_sifre || null;
      var erpAktif    = r.erp_aktif    || false;
      var erpSifre    = r.erp_sifre    || null;
      var erpEmail    = r.erp_email    || '—';
      var erpRol      = r.erp_rol      || '—';

      // Güncelleme + ERP yok → bildirim + yönlendir
      if (!portalSifre && !erpSifre) {
        JT.bildirim(r.mesaj || 'Güncellendi!', 'basari');
        setTimeout(function(){ window.location.href = '<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personeller'; }, 1200);
        return;
      }

      var html = '<div id="kimlikModal" style="position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px">'
        + '<div style="background:#fff;border-radius:16px;padding:32px;max-width:500px;width:100%;box-shadow:0 24px 48px rgba(0,0,0,.25);max-height:90vh;overflow-y:auto">'
        + '<div style="text-align:center;margin-bottom:22px">'
        + '<div style="font-size:42px;margin-bottom:10px">🎉</div>'
        + '<div style="font-size:19px;font-weight:800;color:#101828">' + (r.mesaj || 'Kaydedildi!') + '</div>'
        + '<div style="margin-top:8px;font-size:13px;color:#F04438;font-weight:600;background:#FEE4E2;display:inline-block;padding:6px 14px;border-radius:20px">⚠️ Bu bilgileri not alın — tekrar gösterilmez!</div>'
        + '</div>';

      // ── Personel Portalı ──
      if (portalSifre) {
        html += '<div style="background:#FEF3E8;border:2px solid #FED7AA;border-radius:12px;padding:16px;margin-bottom:12px">'
          + '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.07em;color:#F97316;margin-bottom:12px">🧑‍💼 Personel Portalı</div>'
          + satir('Kullanıcı Adı (Sicil No)', sicilNo, 'mono', 'rgba(249,115,22,.15)')
          + satir('İlk Şifre', portalSifre, 'sifre', 'rgba(249,115,22,.15)')
          + satir('Giriş URL', 'portal/personel/giris.php', 'link', '')
          + '<div style="margin-top:8px;font-size:11px;color:#B45309;background:#FEF0C7;border-radius:6px;padding:6px 10px">⚠️ İlk girişte şifre değiştirmesi zorunludur</div>'
          + '</div>';
      }

      // ── ERP Paneli ──
      if (erpAktif && erpSifre) {
        html += '<div style="background:#EFF6FF;border:2px solid #BFDBFE;border-radius:12px;padding:16px;margin-bottom:12px">'
          + '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.07em;color:#2563EB;margin-bottom:12px">🖥️ ERP Yönetim Paneli</div>'
          + satir('E-posta (Kullanıcı Adı)', erpEmail, 'mono-blue', 'rgba(37,99,235,.12)')
          + satir('İlk Şifre', erpSifre, 'sifre', 'rgba(37,99,235,.12)')
          + satir('Rol', erpRol, 'badge-blue', 'rgba(37,99,235,.12)')
          + satir('Giriş URL', 'giris.php', 'link-blue', '')
          + '<div style="margin-top:8px;font-size:11px;color:#1E40AF;background:#DBEAFE;border-radius:6px;padding:6px 10px">⚠️ İlk girişte şifre değiştirmesi zorunludur</div>'
          + '</div>';
      }

      html += '<button onclick="document.getElementById(\'kimlikModal\').remove();window.location.href=\'<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personeller\'" '
        + 'style="width:100%;padding:14px;background:#12B76A;color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit">'
        + '✓ Bilgileri Not Aldım, Devam Et'
        + '</button>'
        + '</div></div>';

      document.body.insertAdjacentHTML('beforeend', html);

    } else {
      btn.disabled = false;
      btn.textContent = '💾 <?php echo $duzenle_id ? "Güncelle" : "Personeli Kaydet"; ?>';
      alert('Hata: ' + (r.hata || 'Bilinmeyen hata'));
    }
  })
  .catch(function(err) {
    btn.disabled = false;
    btn.textContent = '💾 <?php echo $duzenle_id ? "Güncelle" : "Personeli Kaydet"; ?>';
    alert('Bağlantı hatası: ' + err.message);
  });
});

function vardiyaTipiDegis(val) {
  const el = document.getElementById('aktifVardiyaGrup');
  if (el) el.style.display = val === '3lu' ? '' : 'none';
}
</script>
