<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

$hata_mesaji = '';
$ay    = (int)($_GET['ay']    ?? date('n'));
$yil   = (int)($_GET['yil']   ?? date('Y'));
$dept  = (int)($_GET['dept']  ?? 0);
$durum = $_GET['durum'] ?? '';
$arama = trim($_GET['arama'] ?? '');

try {
    $deptlar = $db->query("SELECT id,ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();
    $personeller_list = $db->query("SELECT id, CONCAT(ad,' ',soyad) ad_soyad, sicil_no FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();

    $where  = ["MONTH(dk.tarih)=?","YEAR(dk.tarih)=?"];
    $params = [$ay,$yil];
    if ($dept)  { $where[] = "p.departman_id=?"; $params[] = $dept; }
    if ($durum) { $where[] = "dk.durum=?";       $params[] = $durum; }
    if ($arama) { $where[] = "(CONCAT(p.ad,' ',p.soyad) LIKE ? OR p.sicil_no LIKE ?)";
                  $params[] = "%$arama%"; $params[] = "%$arama%"; }
    $w = implode(' AND ', $where);

    $kayitlar = $db->prepare("SELECT dk.id, dk.personel_id, dk.tarih, dk.giris_saati,
        dk.cikis_saati, dk.calisma_suresi, dk.durum, dk.giris_tipi, dk.notlar,
        CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no,
        IFNULL(p.vardiya_tipi,'tek') vardiya_tipi, d.ad dept_adi
        FROM devam_kayitlari dk
        JOIN personeller p ON dk.personel_id=p.id
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE $w ORDER BY dk.tarih DESC, p.ad");
    $kayitlar->execute($params); $kayitlar = $kayitlar->fetchAll();

    $ozet_q = $db->prepare("SELECT dk.durum, COUNT(*) n FROM devam_kayitlari dk
        JOIN personeller p ON dk.personel_id=p.id
        WHERE MONTH(dk.tarih)=? AND YEAR(dk.tarih)=? GROUP BY dk.durum");
    $ozet_q->execute([$ay,$yil]); $ozet = $ozet_q->fetchAll(PDO::FETCH_KEY_PAIR);

    // Toplam çalışma saati
    $w2 = str_replace("dk.durum=?", "1=1", $w); // durum filtresi olmadan saat topla
    $params2 = array_values($params);
    // durum param'ını çıkar
    $toplam_saat_q = $db->prepare("SELECT IFNULL(SUM(dk.calisma_suresi),0) FROM devam_kayitlari dk
        JOIN personeller p ON dk.personel_id=p.id
        WHERE MONTH(dk.tarih)=? AND YEAR(dk.tarih)=? AND dk.durum='geldi'");
    $toplam_saat_q->execute([$ay,$yil]);
    $toplam_saat = round((float)$toplam_saat_q->fetchColumn(), 1);

} catch(Throwable $e){
    $kayitlar=[]; $ozet=[]; $deptlar=[]; $personeller_list=[]; $toplam_saat=0;
    $hata_mesaji = $e->getMessage();
}

$aylar = ['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
$dr = ['geldi'=>['✅','#D1FAE5','#065F46','Geldi'],
       'gelmedi'=>['❌','#FEE2E2','#991B1B','Gelmedi'],
       'izinli'=>['🏖','#FEF3C7','#92400E','İzinli'],
       'gecikti'=>['⚠️','#FEF3C7','#B45309','Geç Geldi'],
       'eksik'=>['❓','#F3F4F6','#6B7280','Eksik']];
?>
<div class="s-bar">
  <div><h1 class="s-bas">✅ Devam Kayıtları</h1><div class="s-yol">İnsan Kaynakları / <b>Devam</b></div></div>
  <div style="display:flex;gap:8px">
    <button onclick="dtExcelIndir('dt-devam','DevamKayitlari',{tip:'devam'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
    <button onclick="modalAc()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:9px 16px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Kayıt Ekle</button>
  </div>
</div>

<div class="s-body">
<?php if (!empty($hata_mesaji)): ?>
<div style="background:#FEE2E2;color:#991B1B;padding:12px 16px;border-radius:8px;margin-bottom:12px;font-size:13px;font-weight:600">
  ❌ Sorgu hatası: <?php echo htmlspecialchars($hata_mesaji); ?>
</div>
<?php endif; ?>

<!-- Özet kartlar -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px">
  <?php foreach([['Geldi','geldi'],['Gelmedi','gelmedi'],['İzinli','izinli'],['Geç Geldi','gecikti']] as [$et,$k]):
    [$ikon,$bg,$fg,$lbl] = $dr[$k] ?? ['📋','#F3F4F6','#374151',$et]; $say = $ozet[$k] ?? 0; ?>
  <a href="?sayfa=ik-devam&ay=<?php echo $ay; ?>&yil=<?php echo $yil; ?>&durum=<?php echo $k; ?><?php echo $dept?"&dept=$dept":''; ?>" style="text-decoration:none">
    <div style="background:<?php echo $bg; ?>;border-radius:12px;padding:14px;text-align:center;border:2px solid <?php echo $durum===$k?$fg:'transparent'; ?>">
      <div style="font-size:22px;font-weight:900;color:<?php echo $fg; ?>"><?php echo $say; ?></div>
      <div style="font-size:11px;font-weight:700;color:<?php echo $fg; ?>"><?php echo $ikon.' '.$et; ?></div>
    </div>
  </a>
  <?php endforeach; ?>
  <div style="background:#EFF6FF;border-radius:12px;padding:14px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:#1D4ED8"><?php echo $toplam_saat; ?></div>
    <div style="font-size:11px;font-weight:700;color:#1D4ED8">⏱ Toplam Saat</div>
  </div>
  <div style="background:#F3F4F6;border-radius:12px;padding:14px;text-align:center">
    <div style="font-size:22px;font-weight:900;color:#374151"><?php echo count($kayitlar); ?></div>
    <div style="font-size:11px;font-weight:700;color:#374151">📋 Toplam Kayıt</div>
  </div>
</div>

<!-- Filtreler -->
<form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;align-items:center">
  <input type="hidden" name="sayfa" value="ik-devam">
  <select name="ay" class="form-alan" style="width:110px" onchange="this.form.submit()">
    <?php for($m=1;$m<=12;$m++): ?><option value="<?php echo $m; ?>" <?php echo $m==$ay?'selected':''; ?>><?php echo $aylar[$m]; ?></option><?php endfor; ?>
  </select>
  <select name="yil" class="form-alan" style="width:90px" onchange="this.form.submit()">
    <?php for($y=date('Y');$y>=date('Y')-3;$y--): ?><option value="<?php echo $y; ?>" <?php echo $y==$yil?'selected':''; ?>><?php echo $y; ?></option><?php endfor; ?>
  </select>
  <select name="dept" class="form-alan" style="width:160px" onchange="this.form.submit()">
    <option value="0">Tüm Departmanlar</option>
    <?php foreach($deptlar as $d): ?><option value="<?php echo $d['id']; ?>" <?php echo $d['id']==$dept?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option><?php endforeach; ?>
  </select>
  <select name="durum" class="form-alan" style="width:130px" onchange="this.form.submit()">
    <option value="">Tüm Durumlar</option>
    <?php foreach(['geldi'=>'✅ Geldi','gelmedi'=>'❌ Gelmedi','izinli'=>'🏖 İzinli','gecikti'=>'⚠️ Geç Geldi'] as $k=>$v): ?>
    <option value="<?php echo $k; ?>" <?php echo $k===$durum?'selected':''; ?>><?php echo $v; ?></option>
    <?php endforeach; ?>
  </select>
  <input type="text" name="arama" value="<?php echo htmlspecialchars($arama); ?>" class="form-alan" style="width:160px" placeholder="🔍 Personel ara...">
  <button type="submit" class="btn btn-b" style="padding:8px 14px">Filtrele</button>
  <?php if($durum||$dept||$arama): ?><a href="?sayfa=ik-devam&ay=<?php echo $ay; ?>&yil=<?php echo $yil; ?>" class="btn" style="padding:8px 14px;background:#F3F4F6;color:#374151;text-decoration:none">✕ Temizle</a><?php endif; ?>
</form>

<!-- Tablo -->
<div class="kart" style="overflow:hidden">
  <div style="overflow-y:auto;max-height:calc(100vh - 320px)">
  <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)"><table class="tablo" id="dt-devam" style="position:relative">
    <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)">
      <tr>
        <th>Personel</th><th>Departman</th><th style="width:110px">Tarih</th>
        <th style="width:75px;text-align:center">Giriş</th><th style="width:75px;text-align:center">Çıkış</th>
        <th style="width:70px;text-align:center">Süre</th><th style="width:80px">Tür</th>
        <th style="width:110px">Durum</th><th style="width:70px;text-align:center">İşlem</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($kayitlar as $k):
      [$ikon,$bg,$fg,$lbl] = $dr[$k['durum']] ?? ['❓','#F3F4F6','#6B7280',$k['durum']];
      $mesai_esik = ($k['vardiya_tipi']==='beyaz') ? 10 : 8;
      $fazla = $k['calisma_suresi'] > $mesai_esik ? round($k['calisma_suresi'] - $mesai_esik, 2) : 0;
    ?>
    <tr>
      <td style="white-space:nowrap">
        <span style="font-weight:700;font-size:13px"><?php echo htmlspecialchars($k['per_adi']); ?></span>
        <span style="font-size:11px;color:var(--m2);margin-left:6px"><?php echo htmlspecialchars($k['sicil_no']??''); ?></span>
      </td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($k['dept_adi']??'—'); ?></td>
      <td style="white-space:nowrap">
        <span style="font-size:13px;font-weight:600"><?php echo date('d.m.Y',strtotime($k['tarih'])); ?></span>
        <span style="font-size:11px;color:var(--m2);margin-left:5px"><?php $gun=['Mon'=>'Pzt','Tue'=>'Sal','Wed'=>'Çar','Thu'=>'Per','Fri'=>'Cum','Sat'=>'Cmt','Sun'=>'Paz']; echo $gun[date('D',strtotime($k['tarih']))]??''; ?></span>
      </td>
      <td style="text-align:center;font-family:monospace;font-weight:700;color:#065F46"><?php echo $k['giris_saati']?date('H:i',strtotime($k['giris_saati'])):'—'; ?></td>
      <td style="text-align:center;font-family:monospace;font-weight:700;color:#991B1B"><?php echo $k['cikis_saati']?date('H:i',strtotime($k['cikis_saati'])):'—'; ?></td>
      <td style="text-align:center">
        <?php if($k['calisma_suresi']): ?>
        <div style="font-size:12px;font-weight:700"><?php echo number_format($k['calisma_suresi'],1); ?>s</div>
        <?php if($fazla>0): ?><div style="font-size:10px;color:#F97316;font-weight:600">+<?php echo number_format($fazla,1); ?>s mesai</div><?php endif; ?>
        <?php else: ?>—<?php endif; ?>
      </td>
      <td style="font-size:11px;color:var(--m2)"><?php echo $k['giris_tipi']?ucfirst($k['giris_tipi']):'—'; ?></td>
      <td>
        <span style="background:<?php echo $bg; ?>;color:<?php echo $fg; ?>;font-size:11px;font-weight:700;padding:3px 8px;border-radius:20px">
          <?php echo $ikon.' '.$lbl; ?>
        </span>
      </td>
      <td style="text-align:center">
        <button onclick="duzenle(<?php echo htmlspecialchars(json_encode([
            'id'=>$k['id'],'personel_id'=>$k['personel_id'],'tarih'=>$k['tarih'],
            'giris'=>$k['giris_saati']?date('H:i',strtotime($k['giris_saati'])):'',
            'cikis'=>$k['cikis_saati']?date('H:i',strtotime($k['cikis_saati'])):'',
            'durum'=>$k['durum'],'notlar'=>$k['notlar']??''
        ],JSON_UNESCAPED_UNICODE)); ?>)"
          style="background:#EFF6FF;color:#1D4ED8;border:none;width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:13px">✏️</button>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(empty($kayitlar)): ?>
    <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--m2)">Bu kriterlere uygun kayıt bulunamadı.</td></tr>
    <?php endif; ?>
    </tbody>
  </table></div>
</div>
</div>
</div>

<!-- Kayıt Ekle/Düzenle Modal -->
<div id="devamModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:16px">
  <div style="background:rgba(255,255,255,.96);backdrop-filter:blur(12px);border-radius:14px;padding:24px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div style="font-size:15px;font-weight:800" id="devamModalBaslik">➕ Devam Kaydı Ekle</div>
      <button onclick="modalKapat()" style="background:var(--bg);border:1px solid var(--kenar);border-radius:8px;width:30px;height:30px;cursor:pointer">✕</button>
    </div>
    <div style="display:grid;gap:10px">
      <div>
        <label class="form-etiket">Personel *</label>
        <select id="dPersonel" class="form-alan">
          <option value="">— Seçin —</option>
          <?php foreach($personeller_list as $p): ?>
          <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['sicil_no'].' — '.$p['ad_soyad']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-etiket">Tarih *</label>
        <input type="date" id="dTarih" class="form-alan" value="<?php echo date('Y-m-d'); ?>">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label class="form-etiket">Giriş Saati</label>
          <input type="time" id="dGiris" class="form-alan">
        </div>
        <div>
          <label class="form-etiket">Çıkış Saati</label>
          <input type="time" id="dCikis" class="form-alan">
        </div>
      </div>
      <div>
        <label class="form-etiket">Durum *</label>
        <select id="dDurum" class="form-alan">
          <option value="geldi">✅ Geldi</option>
          <option value="gelmedi">❌ Gelmedi</option>
          <option value="izinli">🏖 İzinli</option>
          <option value="gecikti">⚠️ Geç Geldi</option>
          <option value="eksik">❓ Eksik</option>
        </select>
      </div>
      <div>
        <label class="form-etiket">Not</label>
        <textarea id="dNot" class="form-alan" rows="2" style="resize:none"></textarea>
      </div>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
      <button onclick="modalKapat()" style="padding:10px 20px;background:var(--bg);border:1px solid var(--kenar);border-radius:8px;cursor:pointer;font-family:inherit;font-weight:600">İptal</button>
      <button onclick="kaydet()" id="devamKaydetBtn" style="padding:10px 24px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;cursor:pointer;font-family:inherit;font-weight:700">💾 Kaydet</button>
    </div>
  </div>
</div>

<script>
var AJAX = '<?php echo BASE_URL; ?>/bolumler/ik/ajax/devam-erp-kayit.php';
var _editId = 0;

function modalAc() {
    _editId = 0;
    document.getElementById('devamModalBaslik').textContent = '➕ Devam Kaydı Ekle';
    document.getElementById('dPersonel').value = '';
    document.getElementById('dTarih').value = '<?php echo date('Y-m-d'); ?>';
    document.getElementById('dGiris').value = '';
    document.getElementById('dCikis').value = '';
    document.getElementById('dDurum').value = 'geldi';
    document.getElementById('dNot').value = '';
    document.getElementById('devamModal').style.display = 'flex';
}
function modalKapat() { document.getElementById('devamModal').style.display = 'none'; }

function duzenle(d) {
    _editId = d.id;
    document.getElementById('devamModalBaslik').textContent = '✏️ Kayıt Düzenle';
    document.getElementById('dPersonel').value = d.personel_id;
    document.getElementById('dTarih').value    = d.tarih;
    document.getElementById('dGiris').value    = d.giris;
    document.getElementById('dCikis').value    = d.cikis;
    document.getElementById('dDurum').value    = d.durum;
    document.getElementById('dNot').value      = d.notlar;
    document.getElementById('devamModal').style.display = 'flex';
}

function kaydet() {
    var pid   = document.getElementById('dPersonel').value;
    var tarih = document.getElementById('dTarih').value;
    var durum = document.getElementById('dDurum').value;
    if (!pid || !tarih) { alert('Personel ve tarih zorunlu'); return; }

    var btn = document.getElementById('devamKaydetBtn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';

    var fd = new FormData();
    fd.append('islem', _editId ? 'guncelle' : 'kayit');
    if (_editId) fd.append('id', _editId);
    fd.append('personel_id', pid);
    fd.append('tarih',  tarih);
    fd.append('giris',  document.getElementById('dGiris').value);
    fd.append('cikis',  document.getElementById('dCikis').value);
    fd.append('durum',  durum);
    fd.append('notlar', document.getElementById('dNot').value);
    fd.append('giris_tipi', 'manuel');

    // JSON olarak gönder
    var data = {};
    fd.forEach(function(v,k){ data[k]=v; });
    fetch(AJAX, {method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(data)})
    .then(function(r){return r.json();})
    .then(function(r){
        if (r.ok) location.reload();
        else { alert('Hata: '+(r.hata||r.mesaj||'?')); btn.disabled=false; btn.textContent='💾 Kaydet'; }
    }).catch(function(){ alert('Bağlantı hatası'); btn.disabled=false; btn.textContent='💾 Kaydet'; });
}

document.addEventListener('DOMContentLoaded', function(){ if(typeof dtInit==='function') dtInit('dt-devam'); });
</script>
