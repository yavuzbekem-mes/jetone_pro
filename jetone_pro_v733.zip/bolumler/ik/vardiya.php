<?php
/**
 * İK — Vardiya Yönetimi
 * bolumler/ik/vardiya.php
 */
if (!Auth::yetkiKontrol('ik','goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>'; return;
}

$hafta_bas = $_GET['hafta'] ?? date('Y-m-d', strtotime('monday this week'));
$hafta_bas = date('Y-m-d', strtotime('monday', strtotime($hafta_bas)));
$hafta_bit = date('Y-m-d', strtotime($hafta_bas.' +6 days'));
$onceki    = date('Y-m-d', strtotime($hafta_bas.' -7 days'));
$sonraki   = date('Y-m-d', strtotime($hafta_bas.' +7 days'));
$bu_hafta  = ($hafta_bas === date('Y-m-d', strtotime('monday this week')));

$kadro_f = $_GET['kadro'] ?? '';
$durak_f = $_GET['durak'] ?? '';

$vardiya_tanimlari = [
    1 => ['ad'=>'1. Vardiya', 'saat'=>'08:00–16:00', 'renk'=>'#D1FAE5', 'renk_k'=>'#065F46'],
    2 => ['ad'=>'2. Vardiya', 'saat'=>'16:00–00:00', 'renk'=>'#DBEAFE', 'renk_k'=>'#1E40AF'],
    3 => ['ad'=>'3. Vardiya', 'saat'=>'00:00–08:00', 'renk'=>'#F3E8FF', 'renk_k'=>'#6D28D9'],
];

$kadro_tr = ['beyaz_yaka'=>'Beyaz Yaka','endirekt'=>'Endirekt','direkt'=>'Direkt','stajyer'=>'Stajyer'];
$durak_tr = ['cerkezkoy'=>'Çerkezköy','kizilpinar'=>'Kızılpınar','kapakli'=>'Kapaklı','karaagac'=>'Karaağaç'];

try {
    $where_p = ["p.durum='aktif'","p.vardiya_tipi IS NOT NULL"];
    $params_p = [];
    if ($kadro_f) { $where_p[]="p.kadro=?"; $params_p[]=$kadro_f; }
    if ($durak_f) { $where_p[]="p.servis_durak=?"; $params_p[]=$durak_f; }

    $q = $db->prepare("SELECT p.*, d.ad dept_adi FROM personeller p
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE ".implode(' AND ',$where_p)."
        ORDER BY p.vardiya_tipi, p.aktif_vardiya, p.ad");
    $q->execute($params_p); $personeller=$q->fetchAll();

    // Bu hafta atamaları
    $va=$db->prepare("SELECT va.* FROM vardiya_atamalari va
        WHERE va.baslangic<=? AND (va.bitis IS NULL OR va.bitis>=?)");
    $va->execute([$hafta_bit,$hafta_bas]);
    $atamaMap=[];
    foreach($va->fetchAll() as $a) $atamaMap[$a['personel_id']]=(int)$a['vardiya_id'];
} catch(Throwable $e){ $personeller=[]; $atamaMap=[]; }

$tek_say   = count(array_filter($personeller,fn($p)=>($p['vardiya_tipi']??'')==='tek'));
$uclu_say  = count(array_filter($personeller,fn($p)=>($p['vardiya_tipi']??'')==='3lu'));
$beyaz_say = count(array_filter($personeller,fn($p)=>($p['vardiya_tipi']??'')==='beyaz'));
$tum_say  = count($personeller);
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">🗓 Vardiya Yönetimi</h1>
    <div class="s-yol">İnsan Kaynakları / <b>Vardiya Yönetimi</b></div>
  </div>
  <div style="display:flex;align-items:center;gap:8px">
    <div id="dt-toolbar-dt-vardiya" style="display:inline-flex;align-items:center;gap:6px"></div>
    <div style="display:flex;gap:8px">
      <button onclick="dtExcelIndir('dt-vardiya','VardiyaListesi',{tip:'vardiya'})" style="background:#217346;color:#fff;border:none;padding:10px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
      <button onclick="otomatikPlanla()" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">
        🔄 Sonraki Haftayı Otomatik Planla
      </button>
    </div>
  </div>
</div>

<div class="s-body">

  <!-- Hafta Nav -->
  <div style="display:flex;align-items:center;justify-content:space-between;background:var(--yuzey);border-radius:var(--r-lg);padding:14px 20px;margin-bottom:16px;box-shadow:var(--golge)">
    <a href="?sayfa=ik-vardiya&hafta=<?php echo $onceki; ?>&kadro=<?php echo $kadro_f; ?>&durak=<?php echo $durak_f; ?>" style="padding:8px 16px;border-radius:8px;background:var(--bg);color:var(--m);text-decoration:none;font-weight:600;font-size:13px">‹ Önceki</a>
    <div style="text-align:center">
      <div style="font-size:15px;font-weight:800"><?php echo date('d M',strtotime($hafta_bas)); ?> – <?php echo date('d M Y',strtotime($hafta_bit)); ?></div>
      <?php if($bu_hafta):?><span style="font-size:11px;background:var(--t);color:#fff;padding:2px 8px;border-radius:10px;font-weight:700">Bu Hafta</span><?php endif;?>
    </div>
    <a href="?sayfa=ik-vardiya&hafta=<?php echo $sonraki; ?>&kadro=<?php echo $kadro_f; ?>&durak=<?php echo $durak_f; ?>" style="padding:8px 16px;border-radius:8px;background:var(--bg);color:var(--m);text-decoration:none;font-weight:600;font-size:13px">Sonraki ›</a>
  </div>

  <!-- Özet -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:16px">
    <?php foreach([['Toplam',$tum_say,'#F3F4F6','#374151'],['Beyaz Yaka',$beyaz_say,'#D1FAE5','#065F46'],['Tek Vardiya',$tek_say,'#FEF3E8','#B45309'],['3lu Sistem',$uclu_say,'#DBEAFE','#1E40AF']] as [$et,$say,$bg,$fg]):?>
    <div style="background:<?php echo $bg; ?>;border-radius:12px;padding:14px;text-align:center">
      <div style="font-size:22px;font-weight:900;color:<?php echo $fg; ?>"><?php echo $say; ?></div>
      <div style="font-size:11px;font-weight:700;color:<?php echo $fg; ?>"><?php echo $et; ?></div>
    </div>
    <?php endforeach;?>
    <?php foreach($vardiya_tanimlari as $vid=>$vd):
      $say=count(array_filter($personeller,fn($p)=>($atamaMap[$p['id']]??($p['aktif_vardiya']??0))===$vid&&($p['vardiya_tipi']??'')==='3lu'));
    ?>
    <div style="background:<?php echo $vd['renk']; ?>;border-radius:12px;padding:14px;text-align:center">
      <div style="font-size:22px;font-weight:900;color:<?php echo $vd['renk_k']; ?>"><?php echo $say; ?></div>
      <div style="font-size:11px;font-weight:700;color:<?php echo $vd['renk_k']; ?>"><?php echo $vd['ad']; ?></div>
    </div>
    <?php endforeach;?>
  </div>

  <!-- Filtreler -->
  <div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
    <select onchange="location.href='?sayfa=ik-vardiya&hafta=<?php echo $hafta_bas; ?>&kadro='+this.value+'&durak=<?php echo $durak_f; ?>'" style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-size:13px;background:#fff">
      <option value="">Tüm Kadrolar</option>
      <?php foreach($kadro_tr as $k=>$v):?><option value="<?php echo $k; ?>" <?php echo $kadro_f===$k?'selected':''; ?>><?php echo $v; ?></option><?php endforeach;?>
    </select>
    <select onchange="location.href='?sayfa=ik-vardiya&hafta=<?php echo $hafta_bas; ?>&kadro=<?php echo $kadro_f; ?>&durak='+this.value" style="padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;font-size:13px;background:#fff">
      <option value="">Tüm Duraklar</option>
      <?php foreach($durak_tr as $k=>$v):?><option value="<?php echo $k; ?>" <?php echo $durak_f===$k?'selected':''; ?>><?php echo $v; ?></option><?php endforeach;?>
    </select>
  </div>

  <!-- Tablo -->
  <div class="kart" style="overflow:hidden">
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 320px)">
    <table class="tablo" style="min-width:680px">
      <thead style="position:sticky;top:0;z-index:2">
        <tr>
          <th>Personel</th><th>Kadro</th><th>Durak</th>
          <th>Sistem</th><th>Bu Hafta</th><th>Sonraki Hafta</th><th>İşlem</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($personeller as $p):
          $vt = $p['vardiya_tipi']??'';
          $av = (int)($atamaMap[$p['id']]??($p['aktif_vardiya']??0));
          // Rotasyon: 1→3→2→1 (bir önceki vardiyaya geçer)
          $sonraki_av = $vt==='3lu'&&$av ? ($av===1?3:($av===3?2:1)) : $av;
        ?>
        <tr>
          <td>
            <div style="font-weight:700"><?php echo htmlspecialchars($p['ad'].' '.$p['soyad']); ?></div>
            <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($p['sicil_no']??''); ?> · <?php echo htmlspecialchars($p['dept_adi']??''); ?></div>
          </td>
          <td><?php if($p['kadro']):?><span style="font-size:11px;background:#F3F4F6;padding:2px 8px;border-radius:6px;font-weight:600"><?php echo $kadro_tr[$p['kadro']]??$p['kadro']; ?></span><?php else:?>—<?php endif;?></td>
          <td style="font-size:12px"><?php echo $p['servis_durak']?('🚌 '.($durak_tr[$p['servis_durak']]??$p['servis_durak'])):'<span style="color:var(--m3)">Yok</span>'; ?></td>
          <td>
            <?php if($vt==='3lu'):?><span style="background:#DBEAFE;color:#1E40AF;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">🔄 3lu</span>
            <?php elseif($vt==='tek'):?><span style="background:#FEF3E8;color:#B45309;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">📅 Tek</span>
            <?php elseif($vt==='beyaz'):?><span style="background:#D1FAE5;color:#065F46;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">📅 Beyaz</span>
            <?php else:?><span style="color:var(--m3)">—</span><?php endif;?>
          </td>
          <td>
            <?php if($vt==='beyaz'):?>
              <span style="background:#D1FAE5;color:#065F46;font-size:12px;font-weight:700;padding:4px 10px;border-radius:8px">08:00–18:00</span>
            <?php elseif($vt==='tek'):?>
              <span style="background:#FEF3E8;color:#B45309;font-size:12px;font-weight:700;padding:4px 10px;border-radius:8px">08:00–16:00</span>
            <?php elseif($av&&isset($vardiya_tanimlari[$av])):$vd=$vardiya_tanimlari[$av];?>
              <span style="background:<?php echo $vd['renk']; ?>;color:<?php echo $vd['renk_k']; ?>;font-size:12px;font-weight:700;padding:4px 10px;border-radius:8px"><?php echo $vd['ad']; ?> <?php echo $vd['saat']; ?></span>
            <?php else:?><span style="color:var(--m3)">Atanmadı</span><?php endif;?>
          </td>
          <td>
            <?php if($vt==='beyaz'):?>
              <span style="font-size:11px;color:var(--m2)">08:00–18:00</span>
            <?php elseif($vt==='tek'):?>
              <span style="font-size:11px;color:var(--m2)">08:00–16:00</span>
            <?php elseif($sonraki_av&&isset($vardiya_tanimlari[$sonraki_av])):$vd2=$vardiya_tanimlari[$sonraki_av];?>
              <span style="background:<?php echo $vd2['renk']; ?>;color:<?php echo $vd2['renk_k']; ?>;font-size:11px;font-weight:700;padding:3px 8px;border-radius:8px"><?php echo $vd2['ad']; ?> <?php echo $vd2['saat']; ?></span>
            <?php else:?><span style="color:var(--m3)">—</span><?php endif;?>
          </td>
          <td>
            <?php if($vt!=='tek' && $vt!=='beyaz'):?>
            <button onclick="vardiyaDegistir(<?php echo $p['id']; ?>,<?php echo htmlspecialchars(json_encode($p['ad'].' '.$p['soyad'],JSON_UNESCAPED_UNICODE)); ?>,<?php echo $av; ?>,<?php echo $p['id']; ?>)"
              style="font-size:11px;padding:5px 10px;background:#EFF6FF;color:#1D4ED8;border:none;border-radius:6px;cursor:pointer;font-weight:600">✏️ Düzenle</button>
            <?php endif;?>
          </td>
        </tr>
        <?php endforeach;?>
        <?php if(empty($personeller)):?>
        <tr><td colspan="7" style="text-align:center;padding:30px;color:var(--m2)">
          <div style="font-size:32px;margin-bottom:8px">🗓</div>
          Vardiya tanımlanmış personel bulunamadı.<br>
          <a href="?sayfa=ik-ekle" style="color:var(--t);font-weight:600">Personel ekle/düzenle →</a>
        </td></tr>
        <?php endif;?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div id="varModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:16px;width:min(400px,100%);box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <h3 style="font-size:15px;font-weight:800" id="varModalBaslik">Vardiya Düzenle</h3>
      <button onclick="document.getElementById('varModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">✕</button>
    </div>
    <div style="padding:20px 22px">
      <input type="hidden" id="varPerId">
      <div style="margin-bottom:14px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:8px">Bu Hafta Vardiyası Seç</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px" id="varSecimler">
          <?php foreach($vardiya_tanimlari as $vid=>$vd):?>
          <div class="var-secim" data-vid="<?php echo $vid; ?>" onclick="varSec(<?php echo $vid; ?>)"
            style="padding:12px 6px;text-align:center;border-radius:10px;border:2px solid var(--kenar);cursor:pointer;transition:all .15s">
            <div style="font-size:12px;font-weight:800"><?php echo $vd['ad']; ?></div>
            <div style="font-size:11px;color:var(--m2);margin-top:2px"><?php echo $vd['saat']; ?></div>
          </div>
          <?php endforeach;?>
        </div>
        <input type="hidden" id="varSecilen" value="">
      </div>
      <div style="margin-bottom:16px">
        <div style="font-size:12px;font-weight:700;color:var(--m2);text-transform:uppercase;margin-bottom:6px">Geçerlilik Başlangıcı</div>
        <input type="date" id="varTarih" value="<?php echo $hafta_bas; ?>" style="width:100%;padding:10px;border:1.5px solid var(--kenar);border-radius:8px;font-family:inherit;font-size:14px">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <button onclick="document.getElementById('varModal').style.display='none'" style="padding:12px;background:var(--bg);border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">İptal</button>
        <button onclick="varKaydet()" style="padding:12px;background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">💾 Kaydet</button>
      </div>
    </div>
  </div>
</div>

<script>
<?php echo 'const SONRAKI_HAFTA="'.$sonraki.'";'; ?>
const VAR_TANIMLARI = <?php echo json_encode($vardiya_tanimlari,JSON_UNESCAPED_UNICODE); ?>;

function varSec(vid){
  document.getElementById('varSecilen').value=vid;
  document.querySelectorAll('.var-secim').forEach(function(el){
    const isSelected = parseInt(el.dataset.vid)===vid;
    const vd=VAR_TANIMLARI[vid]||{};
    if(isSelected){
      el.style.border='2px solid '+(vd.renk_k||'#F97316');
      el.style.background=vd.renk||'#FEF3E8';
    } else {
      el.style.border='2px solid var(--kenar)';
      el.style.background='#fff';
    }
  });
}

function vardiyaDegistir(pid, perAdi, mevcutVid, dummy){
  document.getElementById('varPerId').value=pid;
  document.getElementById('varModalBaslik').textContent=perAdi;
  document.getElementById('varSecilen').value='';
  document.querySelectorAll('.var-secim').forEach(function(el){
    el.style.border='2px solid var(--kenar)';
    el.style.background='#fff';
  });
  if(mevcutVid) varSec(mevcutVid);
  document.getElementById('varModal').style.display='flex';
}

function varKaydet(){
  const pid=document.getElementById('varPerId').value;
  const vid=document.getElementById('varSecilen').value;
  const tarih=document.getElementById('varTarih').value;
  if(!vid){alert('Vardiya seçin');return;}
  fetch(BASE_URL+'/bolumler/ik/ajax/vardiya-ata.php',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({personel_id:pid,vardiya_no:vid,baslangic:tarih})
  }).then(r=>r.json()).then(r=>{
    if(r.ok){document.getElementById('varModal').style.display='none';location.reload();}
    else alert('Hata: '+(r.hata||'Bilinmeyen'));
  }).catch(()=>alert('Baglanti hatasi'));
}

function otomatikPlanla(){
  if(!confirm('Sonraki hafta için 3lu vardiya rotasyonu otomatik planlanacak.\n1.Vardiya→3.Vardiya, 3.Vardiya→2.Vardiya, 2.Vardiya→1.Vardiya\n\nDevam edilsin mi?')) return;
  fetch(BASE_URL+'/bolumler/ik/ajax/vardiya-ata.php',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({otomatik:true,hafta:SONRAKI_HAFTA})
  }).then(r=>r.json()).then(r=>{
    if(r.ok){alert('✅ '+r.mesaj);location.href='?sayfa=ik-vardiya&hafta='+SONRAKI_HAFTA;}
    else alert('Hata: '+(r.hata||'Bilinmeyen'));
  }).catch(()=>alert('Baglanti hatasi'));
}
</script>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-vardiya');});
</script>