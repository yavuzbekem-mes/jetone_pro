<?php
/**
 * İK — Departman Yönetimi
 */
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','goruntule')) { echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>'; return; }

// Yeni departman ekle / düzenle
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id  = (int)($_POST['id']??0);
    $kod = trim($_POST['kod']??'');
    $ad  = trim($_POST['ad']??'');
    $ust = (int)($_POST['ust_departman_id']??0) ?: null;
    $mud = (int)($_POST['mudur_id']??0) ?: null;
    $ack = trim($_POST['aciklama']??'');
    $dur = (int)($_POST['durum']??1);
    if ($ad) {
        try {
            if ($id) {
                $db->prepare("UPDATE departmanlar SET kod=?,ad=?,ust_departman_id=?,mudur_id=?,aciklama=?,durum=? WHERE id=?")
                   ->execute([$kod,$ad,$ust,$mud,$ack,$dur,$id]);
            } else {
                $db->prepare("INSERT INTO departmanlar (kod,ad,ust_departman_id,mudur_id,aciklama,durum) VALUES (?,?,?,?,?,?)")
                   ->execute([$kod,$ad,$ust,$mud,$ack,$dur]);
            }
        } catch(Throwable $e){}
        $dept_redirect = true;
    }
}
if (isset($_GET['sil']) && is_numeric($_GET['sil'])) {
    $db->prepare("UPDATE departmanlar SET durum=0 WHERE id=?")->execute([(int)$_GET['sil']]);
    $dept_redirect = true;
}

try {
    $deptlar = $db->query("SELECT d.*, p.ad mud_ad, p.soyad mud_soyad,
        (SELECT COUNT(*) FROM personeller WHERE departman_id=d.id AND durum='aktif') per_say
        FROM departmanlar d
        LEFT JOIN personeller p ON d.mudur_id=p.id
        ORDER BY d.durum DESC, d.ad")->fetchAll();
    $yoneticiler = $db->query("SELECT id,CONCAT(ad,' ',soyad) ad_soyad,pozisyon FROM personeller WHERE durum='aktif' ORDER BY ad")->fetchAll();
} catch(Throwable $e){ $deptlar=[]; $yoneticiler=[]; }

$duz_id = (int)($_GET['duzenle']??0);
$duz = $duz_id ? array_filter($deptlar, fn($d)=>$d['id']==$duz_id) : [];
$duz = $duz ? array_values($duz)[0] : null;
?>
<?php if(!empty($dept_redirect)): ?><script>location.replace('?sayfa=ik-departmanlar');</script><?php endif; ?>
<div class="s-bar">
  <div><h1 class="s-bas">🏢 Departmanlar</h1><div class="s-yol">İnsan Kaynakları / <b>Departmanlar</b></div></div>
  <button onclick="document.getElementById('deptModal').style.display='flex'" style="background:var(--t);color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">+ Yeni Departman</button>

  <button onclick="dtExcelIndir('tbl-departmanlar','Departmanlar')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
  <!-- Özet -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:20px">
    <?php
    $aktif=count(array_filter($deptlar,fn($d)=>$d['durum']==1));
    $toplam_per=array_sum(array_column($deptlar,'per_say'));
    foreach([['Toplam Departman',count($deptlar),'#F3F4F6','#374151'],['Aktif',$aktif,'#D1FAE5','#065F46'],['Toplam Personel',$toplam_per,'#DBEAFE','#1E40AF']] as [$et,$say,$bg,$fg]):?>
    <div style="background:<?php echo $bg; ?>;border-radius:12px;padding:16px;text-align:center">
      <div style="font-size:26px;font-weight:900;color:<?php echo $fg; ?>"><?php echo $say; ?></div>
      <div style="font-size:11px;font-weight:700;color:<?php echo $fg; ?>"><?php echo $et; ?></div>
    </div>
    <?php endforeach;?>
  </div>
  <div class="kart">
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 200px)">
    <table class="tablo" id="tbl-departmanlar">
      <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)"><tr><th>Kod</th><th>Departman Adı</th><th>Müdür</th><th style="text-align:center">Personel</th><th>Durum</th><th style="width:100px">İşlem</th></tr></thead>
      <tbody>
        <?php foreach($deptlar as $d): ?>
        <tr style="<?php echo $d['durum']==0?'opacity:.5':''; ?>">
          <td><span style="font-size:11px;background:#F3F4F6;padding:2px 8px;border-radius:6px;font-family:monospace;font-weight:700"><?php echo htmlspecialchars($d['kod']??'—'); ?></span></td>
          <td style="font-weight:700"><?php echo htmlspecialchars($d['ad']); ?></td>
          <td style="font-size:13px"><?php echo $d['mud_ad']?htmlspecialchars($d['mud_ad'].' '.$d['mud_soyad']):'<span style="color:var(--m3)">Atanmamış</span>'; ?></td>
          <td style="text-align:center"><span style="background:#DBEAFE;color:#1E40AF;font-size:12px;font-weight:700;padding:2px 10px;border-radius:10px"><?php echo $d['per_say']; ?></span></td>
          <td><?php echo $d['durum']?'<span style="background:#D1FAE5;color:#065F46;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">Aktif</span>':'<span style="background:#FEE2E2;color:#991B1B;font-size:11px;font-weight:700;padding:2px 8px;border-radius:8px">Pasif</span>'; ?></td>
          <td>
            <div style="display:inline-flex;gap:4px">
              <button onclick="deptDuzenle(<?php echo htmlspecialchars(json_encode($d,JSON_UNESCAPED_UNICODE)); ?>,this)" title="Düzenle" style="width:30px;height:30px;border-radius:6px;background:#EFF6FF;color:#1D4ED8;border:none;cursor:pointer;font-size:14px;display:inline-flex;align-items:center;justify-content:center">✏️</button>
              <?php if($d['per_say']==0): ?>
              <a href="?sayfa=ik-departmanlar&sil=<?php echo $d['id']; ?>" onclick="return confirm('Pasife al?')" title="Pasife Al" style="width:30px;height:30px;border-radius:6px;background:#FEE2E2;color:#EF4444;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;font-size:14px">🗑</a>
              <?php endif;?>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div id="deptModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:16px;width:min(500px,100%);max-height:85vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:18px 22px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center">
      <h3 style="font-size:15px;font-weight:800" id="deptModalBaslik">Yeni Departman</h3>
      <button onclick="document.getElementById('deptModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">✕</button>
    </div>
    <form method="POST" style="padding:22px">
      <input type="hidden" name="id" id="deptId" value="0">
      <div style="display:grid;grid-template-columns:1fr 2fr;gap:12px;margin-bottom:12px">
        <div><label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:4px">KOD</label><input type="text" name="kod" id="deptKod" class="form-alan" placeholder="IK" maxlength="20"></div>
        <div><label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:4px">DEPARTMAN ADI *</label><input type="text" name="ad" id="deptAd" class="form-alan" required placeholder="Departman adı"></div>
      </div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:4px">DEPARTMAN MÜDÜRÜ</label>
        <select name="mudur_id" id="deptMudur" class="form-alan">
          <option value="">— Seçin —</option>
          <?php foreach($yoneticiler as $y):?><option value="<?php echo $y['id']; ?>"><?php echo htmlspecialchars($y['ad_soyad']); ?> — <?php echo htmlspecialchars($y['pozisyon']??''); ?></option><?php endforeach;?>
        </select>
      </div>
      <div style="margin-bottom:12px"><label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:4px">AÇIKLAMA</label><textarea name="aciklama" id="deptAck" class="form-alan" rows="2"></textarea></div>
      <div style="margin-bottom:16px"><label style="display:block;font-size:11px;font-weight:700;color:var(--m2);margin-bottom:4px">DURUM</label>
        <select name="durum" id="deptDurum" class="form-alan"><option value="1">Aktif</option><option value="0">Pasif</option></select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <button type="button" onclick="document.getElementById('deptModal').style.display='none'" style="padding:12px;background:var(--bg);border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">İptal</button>
        <button type="submit" style="padding:12px;background:linear-gradient(135deg,var(--t),var(--tk));color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit">💾 Kaydet</button>
      </div>
    </form>
  </div>
</div>
<script>
function deptDuzenle(d, btn){
  document.getElementById('deptModalBaslik').textContent='Departman Düzenle';
  document.getElementById('deptId').value=d.id;
  document.getElementById('deptKod').value=d.kod||'';
  document.getElementById('deptAd').value=d.ad||'';
  document.getElementById('deptMudur').value=d.mudur_id||'';
  document.getElementById('deptAck').value=d.aciklama||'';
  document.getElementById('deptDurum').value=d.durum;
  document.getElementById('deptModal').style.display='flex';
}
</script>

<script>
function deptExcel(){
  var p=new URLSearchParams(window.location.search);
  var _q='';
  var base=typeof BASE_URL!='undefined'?BASE_URL:'';
  window.location.href=base+'/bolumler/ik/ajax/excel-export.php?tip=departman'+_q;
}
</script>