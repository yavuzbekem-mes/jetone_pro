<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

$id = (int)($_GET['id'] ?? 0);
$d = null;
if ($id) {
    try {
        $q = $db->prepare("SELECT * FROM duyurular WHERE id=? LIMIT 1");
        $q->execute([$id]); $d = $q->fetch();
    } catch (Throwable $e) {}
}

$departmanlar = $db->query("SELECT id, ad FROM departmanlar ORDER BY ad")->fetchAll();
$hedef_ids = $d ? json_decode($d['hedef_ids'] ?? '[]', true) : [];
$v = function($k,$def='') use ($d) { return htmlspecialchars($d[$k] ?? $def); };
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Duyuru Düzenle' : 'Yeni Duyuru'; ?></h1>
    <div class="s-yol">İK / <a href="?sayfa=ik-duyuru-listesi" style="color:var(--t);text-decoration:none">Duyurular</a></div>
  </div>
  <a href="?sayfa=ik-duyuru-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Geri</a>
</div>

<div class="s-body">
<form id="duyuruForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">📢 Duyuru Bilgileri</div>
  <div style="display:grid;gap:12px">

    <div>
      <label class="form-etiket">Başlık <span style="color:#EF4444">*</span></label>
      <input type="text" class="form-alan" name="baslik" value="<?php echo $v('baslik'); ?>" placeholder="Duyuru başlığı..." required>
    </div>

    <div>
      <label class="form-etiket">İçerik <span style="color:#EF4444">*</span></label>
      <textarea class="form-alan" name="icerik" rows="6" placeholder="Duyuru metni..." required><?php echo $v('icerik'); ?></textarea>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
      <div>
        <label class="form-etiket">Öncelik</label>
        <select class="form-alan" name="oncelik">
          <?php foreach (['normal'=>'📋 Normal','onemli'=>'⭐ Önemli','acil'=>'🚨 Acil'] as $k=>$et): ?>
          <option value="<?php echo $k; ?>" <?php echo ($d['oncelik']??'normal')===$k?'selected':''; ?>><?php echo $et; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-etiket">Başlangıç Tarihi</label>
        <input type="date" class="form-alan" name="baslangic" value="<?php echo $v('baslangic',date('Y-m-d')); ?>">
      </div>
      <div>
        <label class="form-etiket">Bitiş Tarihi</label>
        <input type="date" class="form-alan" name="bitis" value="<?php echo $v('bitis'); ?>">
      </div>
    </div>

    <div>
      <label class="form-etiket">Aktif</label>
      <select class="form-alan" name="aktif" style="max-width:200px">
        <option value="1" <?php echo ($d['aktif']??1)?'selected':''; ?>>✅ Aktif</option>
        <option value="0" <?php echo isset($d['aktif'])&&!$d['aktif']?'selected':''; ?>>⏸ Pasif</option>
      </select>
    </div>
  </div>
</div>

<!-- Hedef Kitle -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">🎯 Hedef Kitle</div>

  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px">
    <?php foreach (['herkese'=>['👥','Herkese','Tüm personele'],'departman'=>['🏢','Departmana Özel','Belirli departmanlara'],'kadro'=>['👔','Kadroya Özel','Belirli kadrolara']] as $k=>[$ic,$et,$ac]): ?>
    <label id="hedefLbl_<?php echo $k; ?>" style="display:flex;align-items:center;gap:10px;padding:12px;border:2px solid <?php echo ($d['hedef']??'herkese')===$k?'var(--t)':'var(--kenar)'; ?>;border-radius:10px;cursor:pointer;background:<?php echo ($d['hedef']??'herkese')===$k?'var(--ta)':''; ?>">
      <input type="radio" name="hedef" value="<?php echo $k; ?>" <?php echo ($d['hedef']??'herkese')===$k?'checked':''; ?> onchange="hedefDegis(this)" style="accent-color:var(--t);width:18px;height:18px">
      <div>
        <div style="font-size:18px"><?php echo $ic; ?></div>
        <div style="font-weight:700;font-size:13px"><?php echo $et; ?></div>
        <div style="font-size:11px;color:var(--m2)"><?php echo $ac; ?></div>
      </div>
    </label>
    <?php endforeach; ?>
  </div>

  <!-- Departman seçimi -->
  <div id="dept_sec" style="<?php echo ($d['hedef']??'herkese')==='departman'?'':'display:none'; ?>">
    <label class="form-etiket">Departman Seçin</label>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;margin-top:8px">
      <?php foreach ($departmanlar as $dept): ?>
      <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;cursor:pointer;font-size:13px">
        <input type="checkbox" name="hedef_ids[]" value="<?php echo $dept['id']; ?>"
          <?php echo in_array($dept['id'],$hedef_ids)?'checked':''; ?>
          style="accent-color:var(--t);width:16px;height:16px">
        <?php echo htmlspecialchars($dept['ad']); ?>
      </label>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Kadro seçimi -->
  <div id="kadro_sec" style="<?php echo ($d['hedef']??'herkese')==='kadro'?'':'display:none'; ?>">
    <label class="form-etiket">Kadro Seçin</label>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin-top:8px">
      <?php foreach (['direkt'=>'Direkt','endirekt'=>'Endirekt','beyaz_yaka'=>'Beyaz Yaka','stajyer'=>'Stajyer','taşeron'=>'Taşeron'] as $k=>$et): ?>
      <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;border:1.5px solid var(--kenar);border-radius:8px;cursor:pointer;font-size:13px">
        <input type="checkbox" name="hedef_ids[]" value="<?php echo $k; ?>"
          <?php echo in_array($k,$hedef_ids)?'checked':''; ?>
          style="accent-color:var(--t);width:16px;height:16px">
        <?php echo $et; ?>
      </label>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div style="display:flex;gap:10px;justify-content:flex-end">
  <a href="?sayfa=ik-duyuru-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:12px 24px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px">İptal</a>
  <button type="button" onclick="kaydet()" id="kaydetBtn"
    style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:12px 28px;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit">
    💾 Yayınla
  </button>
</div>
</form>
</div>

<script>
function hedefDegis(el) {
    document.getElementById('dept_sec').style.display  = el.value==='departman' ? 'block' : 'none';
    document.getElementById('kadro_sec').style.display = el.value==='kadro'      ? 'block' : 'none';
    ['herkese','departman','kadro'].forEach(function(k){
        var lbl = document.getElementById('hedefLbl_'+k);
        if (!lbl) return;
        var sec = el.value === k;
        lbl.style.borderColor = sec ? 'var(--t)' : 'var(--kenar)';
        lbl.style.background  = sec ? 'var(--ta)' : '';
    });
}

function kaydet() {
    var btn = document.getElementById('kaydetBtn');
    btn.disabled=true; btn.textContent='Yayınlanıyor...';
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/duyuru-kaydet.php',{
        method:'POST', body:new FormData(document.getElementById('duyuruForm')), credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled=false; btn.textContent='💾 Yayınla';
        if(r.ok) location.href='?sayfa=ik-duyuru-listesi';
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){btn.disabled=false;btn.textContent='💾 Yayınla';alert('Bağlantı hatası');});
}
</script>
