<?php
/**
 * İK — Vardiya Atama & Otomatik Rotasyon  v3
 * Rotasyon: 1→3→2→1
 * - Beyaz yaka: rotasyona dahil değil
 * - İdempotent: aynı hafta tekrar çalıştırılırsa değişmez
 * - vardialar tablosuna bağımlı değil (no 1/2/3 direkt kullanılır)
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/push-gonder.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) {
    echo json_encode(['ok'=>false,'hata'=>'Yetkisiz.']); exit;
}

$d = json_decode(file_get_contents('php://input'),true) ?: [];

/**
 * vardialar tablosundan vardiya_id çek.
 * no (1/2/3) → vardialar.id
 * Tabloda 08:00,16:00,00:00 saatlerine göre eşler.
 * Bulamazsa no'nun kendisini döner (fallback).
 */
function getVardiyaId(PDO $db, int $no): int {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $rows = $db->query("SELECT id, baslangic FROM vardialar WHERE aktif=1 ORDER BY baslangic")->fetchAll();
            foreach ($rows as $r) {
                $s = substr($r['baslangic'], 0, 5);
                if     ($s === '08:00') $cache[1] = (int)$r['id'];
                elseif ($s === '16:00') $cache[2] = (int)$r['id'];
                elseif ($s === '00:00') $cache[3] = (int)$r['id'];
            }
            // Eksik varsa sıralamaya göre doldur
            $siralanmis = array_values(array_unique(array_map(fn($r)=>(int)$r['id'], $rows)));
            if (!isset($cache[1]) && isset($siralanmis[0])) $cache[1] = $siralanmis[0];
            if (!isset($cache[2]) && isset($siralanmis[1])) $cache[2] = $siralanmis[1];
            if (!isset($cache[3]) && isset($siralanmis[2])) $cache[3] = $siralanmis[2];
        } catch(Exception $e) {}
    }
    return $cache[$no] ?? $no; // fallback: no'nun kendisi
}

/**
 * vardialar.id → vardiya no (1/2/3)
 */
function getVardiyaNo(PDO $db, int $vid): int {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $rows = $db->query("SELECT id, baslangic FROM vardialar WHERE aktif=1 ORDER BY baslangic")->fetchAll();
            foreach ($rows as $r) {
                $s = substr($r['baslangic'], 0, 5);
                if     ($s === '08:00') $cache[(int)$r['id']] = 1;
                elseif ($s === '16:00') $cache[(int)$r['id']] = 2;
                elseif ($s === '00:00') $cache[(int)$r['id']] = 3;
            }
            // Sıralamaya göre doldur
            $siralanmis = array_values(array_map(fn($r)=>(int)$r['id'], $rows));
            foreach ($siralanmis as $i => $id) {
                if (!isset($cache[$id])) $cache[$id] = $i + 1;
            }
        } catch(Exception $e) {}
    }
    return $cache[$vid] ?? $vid;
}

/** Rotasyon: 1→3→2→1 */
function rotasyon(int $no): int {
    if ($no===1) return 3; // 1. → 3.
    if ($no===3) return 2; // 3. → 2.
    return 1;              // 2. → 1.
}

$kul_id = Auth::kullanici()['id'];

// ══════════════════════════════════════════════════════════════
// OTOMATİK ROTASYON
// ══════════════════════════════════════════════════════════════
if (!empty($d['otomatik'])) {
    $hafta = $d['hafta'] ?? date('Y-m-d', strtotime('monday next week'));
    $hafta = date('Y-m-d', strtotime('monday', strtotime($hafta)));
    $hafta_bit    = date('Y-m-d', strtotime($hafta.' +6 days'));
    $hafta_once   = date('Y-m-d', strtotime($hafta.' -1 day'));

    try {
        // 3'lü sistem + beyaz yaka hariç + aktif_vardiya tanımlı
        $q = $db->query("SELECT id, ad, soyad, aktif_vardiya, kadro
            FROM personeller
            WHERE durum='aktif'
              AND vardiya_tipi='3lu'
              AND (kadro IS NULL OR kadro NOT IN ('beyaz_yaka','Beyaz Yaka'))
            ORDER BY ad");
        $personeller = $q->fetchAll();

        if (empty($personeller)) {
            echo json_encode(['ok'=>false,'hata'=>"3'lü vardiya sistemi tanımlı personel bulunamadı."]);
            exit;
        }

        $atanan  = 0;
        $atlanan = 0;
        $log_detay = [];

        $db->beginTransaction();

        foreach ($personeller as $p) {
            $pid = (int)$p['id'];

            // ── İdempotent kontrol ──────────────────────────────
            // Bu hafta için zaten vardiya_atamalari kaydı var mı?
            $chk = $db->prepare("SELECT id FROM vardiya_atamalari WHERE personel_id=? AND baslangic=? LIMIT 1");
            $chk->execute([$pid, $hafta]);
            if ($chk->fetch()) {
                $atlanan++;
                $log_detay[] = "{$p['ad']} {$p['soyad']}: ATLANDI (zaten planlanmış)";
                continue;
            }

            // ── Mevcut vardiya no'sunu belirle ──────────────────
            // 1. Önce bu haftanın öncesindeki EN SON atamaya bak
            // 2. Yoksa personeller.aktif_vardiya'yı kullan
            $sonQ = $db->prepare("SELECT vardiya_id FROM vardiya_atamalari
                WHERE personel_id=? AND baslangic <= ?
                ORDER BY baslangic DESC LIMIT 1");
            $sonQ->execute([$pid, $hafta_once]);
            $sonRow = $sonQ->fetch();

            if ($sonRow) {
                $mevcut_no = getVardiyaNo($db, (int)$sonRow['vardiya_id']);
            } else {
                $mevcut_no = (int)$p['aktif_vardiya'];
            }

            // NULL veya geçersiz no'yu düzelt - 1. vardiyadan başlat
            if (!in_array($mevcut_no, [1,2,3])) $mevcut_no = 1;

            // ── Bu hafta ataması yoksa mevcut vardiyayı bu haftaya da ekle ──
            $bu_hafta_bas = date('Y-m-d', strtotime('monday this week'));
            $chkBu = $db->prepare("SELECT id FROM vardiya_atamalari WHERE personel_id=? AND baslangic=? LIMIT 1");
            $chkBu->execute([$pid, $bu_hafta_bas]);
            if (!$chkBu->fetch()) {
                $bu_v_id = getVardiyaId($db, $mevcut_no);
                if ($bu_v_id) {
                    $db->prepare("INSERT IGNORE INTO vardiya_atamalari (personel_id, vardiya_id, baslangic) VALUES (?,?,?)")
                       ->execute([$pid, $bu_v_id, $bu_hafta_bas]);
                    $db->prepare("UPDATE personeller SET aktif_vardiya=? WHERE id=?")
                       ->execute([$mevcut_no, $pid]);
                }
            }

            $sonraki_no = rotasyon($mevcut_no);
            $vardiya_id = getVardiyaId($db, $sonraki_no);

            // ── Önceki açık atamayı kapat ───────────────────────
            $db->prepare("UPDATE vardiya_atamalari SET bitis=? WHERE personel_id=? AND bitis IS NULL AND baslangic < ?")
               ->execute([$hafta_once, $pid, $hafta]);

            // ── Sonraki hafta atama INSERT ───────────────────────
            $db->prepare("INSERT INTO vardiya_atamalari (personel_id, vardiya_id, baslangic) VALUES (?, ?, ?)")
               ->execute([$pid, $vardiya_id, $hafta]);

            // ── personeller.aktif_vardiya sonraki haftaya güncelle ──
            $db->prepare("UPDATE personeller SET aktif_vardiya=? WHERE id=?")
               ->execute([$sonraki_no, $pid]);

            $atanan++;
            $log_detay[] = "{$p['ad']} {$p['soyad']}: {$mevcut_no}→{$sonraki_no} (vId={$vardiya_id})";
        }

        $db->commit();

        // Bildirim & push (sadece yeni atananlara, transaction dışında)
        if ($atanan > 0) {
            $vad_tr = [
                1=>'1. Vardiya (08:00–16:00)',
                2=>'2. Vardiya (16:00–00:00)',
                3=>'3. Vardiya (00:00–08:00)',
            ];
            // Yeni atamaları DB'den al
            $bilQ = $db->prepare("SELECT va.personel_id, va.vardiya_id
                FROM vardiya_atamalari va
                JOIN personeller p ON va.personel_id=p.id
                WHERE va.baslangic=?
                  AND p.vardiya_tipi='3lu'
                  AND (p.kadro IS NULL OR p.kadro!='beyaz_yaka')");
            $bilQ->execute([$hafta]);
            foreach ($bilQ->fetchAll() as $ya) {
                $a_no = getVardiyaNo($db, (int)$ya['vardiya_id']);
                if (!isset($vad_tr[$a_no])) continue;
                try {
                    $pk = $db->prepare("SELECT id FROM portal_kullanicilari WHERE ilgili_id=? AND tip='personel' LIMIT 1");
                    $pk->execute([$ya['personel_id']]); $pkRow=$pk->fetch();
                    $baslik = '📅 Vardiya Değişikliği';
                    $mesaj  = date('d.m.Y',strtotime($hafta)).' haftasından itibaren '.$vad_tr[$a_no].' vardiyasına geçtiniz.';
                    $db->prepare("INSERT IGNORE INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu) VALUES (?,?,?,?,?,?,0)")
                       ->execute([$pkRow['id']??null,'personel',$baslik,$mesaj,'bilgi','vardiya']);
                    pushGonder((int)$ya['personel_id'],$baslik,$mesaj,'bilgi');
                } catch(Exception $e){}
            }
        }

        error_log('[VardiyaOto] '.implode(' | ', $log_detay));
        Auth::logKaydet($kul_id,'vardiya_oto','ik',null,"$atanan atandı, $atlanan atlandı ($hafta)");

        $msg = $atanan > 0
            ? "$atanan personel için ".date('d.m.Y',strtotime($hafta))." haftası planlandı."
            : "Bu hafta için vardiyalar zaten planlanmış.";
        if ($atlanan > 0) $msg .= " ($atlanan personel atlandı)";

        echo json_encode(['ok'=>true,'mesaj'=>$msg,'atanan'=>$atanan,'atlanan'=>$atlanan]);

    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[VardiyaAta Oto Hata] '.$e->getMessage());
        echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════
// MANUEL TEK PERSONEL ATAMA
// ══════════════════════════════════════════════════════════════
$pid        = (int)($d['personel_id'] ?? 0);
$vardiya_no = (int)($d['vardiya_no']  ?? 0);
$baslangic  = $d['baslangic'] ?? date('Y-m-d');

if (!$pid || !$vardiya_no || !in_array($vardiya_no,[1,2,3])) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz parametre.']); exit;
}

try {
    $vardiya_id   = getVardiyaId($db, $vardiya_no);
    $baslangic_once = date('Y-m-d',strtotime($baslangic.' -1 day'));

    // Önceki açık atamayı kapat
    $db->prepare("UPDATE vardiya_atamalari SET bitis=?
        WHERE personel_id=? AND bitis IS NULL AND baslangic < ?")
       ->execute([$baslangic_once, $pid, $baslangic]);

    // Aynı tarih için güncelle veya ekle
    $mev = $db->prepare("SELECT id FROM vardiya_atamalari WHERE personel_id=? AND baslangic=? LIMIT 1");
    $mev->execute([$pid,$baslangic]);
    if ($row=$mev->fetch()) {
        $db->prepare("UPDATE vardiya_atamalari SET vardiya_id=? WHERE id=?")->execute([$vardiya_id,$row['id']]);
    } else {
        $db->prepare("INSERT INTO vardiya_atamalari (personel_id,vardiya_id,baslangic) VALUES (?,?,?)")
           ->execute([$pid,$vardiya_id,$baslangic]);
    }

    // personeller.aktif_vardiya güncelle
    $db->prepare("UPDATE personeller SET aktif_vardiya=? WHERE id=?")->execute([$vardiya_no,$pid]);

    Auth::logKaydet($kul_id,'vardiya_ata','ik',$pid,"$vardiya_no. vardiya → $baslangic");
    echo json_encode(['ok'=>true,'mesaj'=>"$vardiya_no. Vardiya atandı."]);

} catch (Throwable $e) {
    error_log('[VardiyaAta Manuel] '.$e->getMessage());
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
