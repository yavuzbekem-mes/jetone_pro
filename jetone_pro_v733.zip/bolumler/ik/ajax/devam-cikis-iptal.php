<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Devam Çıkış İptali
 * bolumler/ik/ajax/devam-cikis-iptal.php
 * 
 * Yanlışlıkla çıkış yapıldıysa, son 30 dakika içinde iptal edilebilir.
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean();
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_name('JETONE_PERSONEL');
    session_start();
}
if (empty($_SESSION['portal']['id']) || $_SESSION['portal']['tip'] !== 'personel') {
    echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz.']); exit;
}

$personelId = (int)($_SESSION['portal']['ilgili_id'] ?? 0);
$bugun      = date('Y-m-d');

try {
    // Bugünkü kaydı bul
    $stmt = $db->prepare("SELECT * FROM devam_kayitlari WHERE personel_id=? AND tarih=? AND cikis_saati IS NOT NULL ORDER BY id DESC LIMIT 1");
    $stmt->execute([$personelId, $bugun]);
    $kayit = $stmt->fetch();

    if (!$kayit) {
        echo json_encode(['ok'=>false,'hata'=>'Bugün çıkış kaydı bulunamadı.']); exit;
    }

    // 30 dakika içinde mi?
    $cikis_zaman = strtotime($bugun . ' ' . $kayit['cikis_saati']);
    $gecen_dk    = (time() - $cikis_zaman) / 60;

    if ($gecen_dk > 30) {
        echo json_encode([
            'ok'    => false,
            'hata'  => 'Çıkış iptali sadece 30 dakika içinde yapılabilir. (' . round($gecen_dk) . ' dakika geçmiş)',
        ]); exit;
    }

    // Çıkışı iptal et
    $db->prepare("UPDATE devam_kayitlari SET cikis_saati=NULL, calisma_suresi=NULL, cikis_tipi=NULL WHERE id=?")
       ->execute([$kayit['id']]);

    // Log
    try {
        $log_stmt = $db->prepare("INSERT INTO sistem_loglar (kullanici_id,ip,islem,modul,tablo_adi,kayit_id,aciklama,durum) VALUES (?,?,?,?,?,?,?,?)");
        $log_stmt->execute([null, $_SERVER['REMOTE_ADDR']??'', 'cikis_iptal', 'ik', 'devam_kayitlari', $kayit['id'], "Portal: çıkış iptal edildi (personel_id: $personelId)", 'basarili']);
    } catch (Exception $e) {}

    echo json_encode([
        'ok'    => true,
        'mesaj' => 'Çıkış iptal edildi. Tekrar çalışmaya devam edebilirsiniz.',
        'giris' => date('H:i', strtotime($kayit['giris_saati'])),
    ]);

} catch (Exception $e) {
    error_log('[CikisIptal] ' . $e->getMessage());
    echo json_encode(['ok'=>false,'hata'=>'İşlem hatası: ' . $e->getMessage()]);
}
