<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','sil')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);
$d = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id = (int)($d['id'] ?? 0);
if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);
try {
    $db->prepare("DELETE FROM personel_belgeler WHERE id=?")->execute([$id]);
    Auth::json(['ok'=>true]);
} catch (Exception $e) { Auth::json(['ok'=>false,'hata'=>$e->getMessage()]); }
