<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);
$d     = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id    = (int)($d['id'] ?? 0);
$islem = $d['islem'] ?? '';
if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);
try {
    $per = $db->prepare("SELECT * FROM personeller WHERE id=? LIMIT 1");
    $per->execute([$id]); $p = $per->fetch();
    if (!$p) Auth::json(['ok'=>false,'hata'=>'Personel bulunamadı.']);

    if ($islem === 'sifre_sifirla') {
        $yeni = ucfirst(strtolower($p['ad'][0])) . substr($p['soyad'],0,2) . rand(1000,9999) . '!';
        $hash = password_hash($yeni, PASSWORD_DEFAULT);
        $db->prepare("UPDATE portal_kullanicilari SET sifre_hash=? WHERE tip='personel' AND ilgili_id=?")
           ->execute([$hash, $id]);
        $db->prepare("UPDATE personeller SET sifre_degistirildi=0 WHERE id=?")->execute([$id]);
        Auth::logKaydet(Auth::kullanici()['id']??null,'portal_sifre_sifirla','ik',$id,"Şifre sıfırlandı: ".$p['sicil_no']);
        Auth::json(['ok'=>true,'yeni_sifre'=>$yeni,'mesaj'=>'Şifre sıfırlandı.']);

    } elseif ($islem === 'toggle_erisim') {
        $pk = $db->prepare("SELECT id,durum FROM portal_kullanicilari WHERE tip='personel' AND ilgili_id=? LIMIT 1");
        $pk->execute([$id]); $pkr = $pk->fetch();
        if ($pkr) {
            $yeni_durum = $pkr['durum'] ? 0 : 1;
            $db->prepare("UPDATE portal_kullanicilari SET durum=? WHERE id=?")->execute([$yeni_durum,$pkr['id']]);
            $msg = $yeni_durum ? 'Portal erişimi açıldı.' : 'Portal erişimi kapatıldı.';
            Auth::json(['ok'=>true,'mesaj'=>$msg,'aktif'=>(bool)$yeni_durum]);
        } else {
            Auth::json(['ok'=>false,'hata'=>'Portal kullanıcısı bulunamadı.']);
        }
    } else {
        Auth::json(['ok'=>false,'hata'=>'Geçersiz işlem.']);
    }
} catch (Exception $e) {
    Auth::json(['ok'=>false,'hata'=>$e->getMessage()]);
}
