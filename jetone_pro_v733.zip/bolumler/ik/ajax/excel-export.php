<?php
/**
 * Excel Export — HTML Table Formatı (her kolon ayrı hücre)
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();

Auth::zorunlu();

$tip  = $_GET['tip']  ?? 'personel';
$ay   = (int)($_GET['ay']   ?? date('n'));
$yil  = (int)($_GET['yil']  ?? date('Y'));
$dept = (int)($_GET['dept'] ?? 0);
$hafta = $_GET['hafta'] ?? date('Y-m-d', strtotime('monday this week'));
$durum = $_GET['durum'] ?? '';

$aylar_tr = ['','Ocak','Subat','Mart','Nisan','Mayis','Haziran','Temmuz','Agustos','Eylul','Ekim','Kasim','Aralik'];
$dosya_map = [
    'personel'=>'Personeller','devam'=>"Devam_{$aylar_tr[$ay]}_{$yil}",
    'izinler'=>'IzinTalepleri','mesai'=>"FazlaMesai_{$aylar_tr[$ay]}_{$yil}",
    'vardiya'=>'VardiyaListesi','oneri'=>'OneriSikayet',
    'bordro'=>"Bordro_{$aylar_tr[$ay]}_{$yil}",'turnover'=>"Turnover_{$yil}",
    'departman'=>'Departmanlar',
];
$dosya_adi = ($dosya_map[$tip] ?? 'export') . '.xls';

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $dosya_adi . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

// HTML Table Excel formatı
echo '<html><head><meta charset="UTF-8">';
echo '<style>th{font-weight:bold;background:#D9E1F2;font-size:12px}';
echo 'td,th{border:1px solid #BCC7E6;padding:5px 8px;font-size:12px;white-space:nowrap;vertical-align:middle}';
echo 'table{border-collapse:collapse;width:100%}</style></head><body>';
echo '<table>';

function xr(array $cells, bool $hdr=false): void {
    $t = $hdr ? 'th' : 'td';
    echo '<tr>';
    foreach ($cells as $c) {
        echo '<'.$t.' style="mso-number-format:\'@\'">'.htmlspecialchars((string)$c, ENT_QUOTES|ENT_HTML5, 'UTF-8').'</'.$t.'>';
    }
    echo "</tr>\n";
}

switch ($tip) {

    case 'personel':
        $where=["1=1"]; $params=[];
        if ($dept) { $where[]="p.departman_id=?"; $params[]=$dept; }
        $q=$db->prepare("SELECT p.sicil_no,p.ad,p.soyad,d.ad dept,p.pozisyon,p.unvan,
            p.kadro,p.servis_durak,p.vardiya_tipi,p.ise_baslama,p.brut_maas,p.email,p.telefon,p.durum
            FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id
            WHERE ".implode(' AND ',$where)." ORDER BY p.ad");
        $q->execute($params);
        xr(['Sicil No','Ad','Soyad','Departman','Pozisyon','Unvan','Kadro','Durak','Vardiya','Is Baslama','Brut Maas','Email','Telefon','Durum'],true);
        $kt=['beyaz_yaka'=>'Beyaz Yaka','endirekt'=>'Endirekt','direkt'=>'Direkt','stajyer'=>'Stajyer'];
        $dt=['cerkezkoy'=>'Cerkezkoy','kizilpinar'=>'Kizilpinar','kapakli'=>'Kapakli','karaagac'=>'Karaagac'];
        foreach($q->fetchAll() as $r) xr([$r['sicil_no']??'',$r['ad'],$r['soyad'],$r['dept']??'',$r['pozisyon']??'',$r['unvan']??'',$kt[$r['kadro']??'']??'',$dt[$r['servis_durak']??'']??'',$r['vardiya_tipi']??'',$r['ise_baslama']??'',number_format((float)$r['brut_maas'],2),$r['email']??'',$r['telefon']??'',$r['durum']??'']);
        break;

    case 'devam':
        $where=["MONTH(dk.tarih)=?","YEAR(dk.tarih)=?"]; $params=[$ay,$yil];
        if ($dept) { $where[]="p.departman_id=?"; $params[]=$dept; }
        if ($durum) { $where[]="dk.durum=?"; $params[]=$durum; }
        $q=$db->prepare("SELECT CONCAT(p.ad,' ',p.soyad) per,p.sicil_no,d.ad dept,dk.tarih,dk.giris_saati,dk.cikis_saati,dk.calisma_suresi,dk.durum,dk.giris_tipi FROM devam_kayitlari dk JOIN personeller p ON dk.personel_id=p.id LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE ".implode(' AND ',$where)." ORDER BY dk.tarih DESC");
        $q->execute($params);
        xr(['Personel','Sicil','Departman','Tarih','Giris','Cikis','Sure (sa)','Durum','Tur'],true);
        foreach($q->fetchAll() as $r) xr([$r['per'],$r['sicil_no']??'',$r['dept']??'',$r['tarih'],$r['giris_saati']?substr($r['giris_saati'],0,5):'',$r['cikis_saati']?substr($r['cikis_saati'],0,5):'',$r['calisma_suresi']?number_format($r['calisma_suresi'],1):'',ucfirst($r['durum']??''),$r['giris_tipi']??'']);
        break;

    case 'izinler':
        $where=["1=1"]; $params=[];
        if ($durum) { $where[]="i.durum=?"; $params[]=$durum; }
        $q=$db->prepare("SELECT CONCAT(p.ad,' ',p.soyad) per,p.sicil_no,d.ad dept,i.izin_turu,i.baslangic,i.bitis,i.gun_sayisi,i.durum,i.aciklama,i.olusturma FROM izin_talepleri i JOIN personeller p ON i.personel_id=p.id LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE ".implode(' AND ',$where)." ORDER BY i.olusturma DESC");
        $q->execute($params);
        $tt=['yillik'=>'Yillik','hastalik'=>'Hastalik','mazeret'=>'Mazeret','ucretsiz'=>'Ucretsiz','dogum'=>'Dogum','olum'=>'Vefat'];
        xr(['Personel','Sicil','Departman','Izin Turu','Baslangic','Bitis','Gun','Durum','Aciklama','Talep Tarihi'],true);
        foreach($q->fetchAll() as $r) xr([$r['per'],$r['sicil_no']??'',$r['dept']??'',$tt[$r['izin_turu']]??$r['izin_turu'],$r['baslangic'],$r['bitis'],(int)$r['gun_sayisi'],ucfirst($r['durum']),$r['aciklama']??'',date('d.m.Y',strtotime($r['olusturma']))]);
        break;

    case 'mesai':
        $where=["MONTH(dk.tarih)=?","YEAR(dk.tarih)=?","dk.calisma_suresi>8","dk.durum='geldi'"]; $params=[$ay,$yil];
        if ($dept) { $where[]="p.departman_id=?"; $params[]=$dept; }
        $q=$db->prepare("SELECT CONCAT(p.ad,' ',p.soyad) per,p.sicil_no,d.ad dept,dk.tarih,dk.giris_saati,dk.cikis_saati,dk.calisma_suresi,(dk.calisma_suresi-8) fazla,p.brut_maas FROM devam_kayitlari dk JOIN personeller p ON dk.personel_id=p.id LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE ".implode(' AND ',$where)." ORDER BY dk.tarih");
        $q->execute($params);
        xr(['Personel','Sicil','Departman','Tarih','Giris','Cikis','Toplam (sa)','Fazla (sa)','Saatlik Ucret','Fazla Odeme'],true);
        foreach($q->fetchAll() as $r){$sl=$r['brut_maas']>0?round($r['brut_maas']/225,2):0; xr([$r['per'],$r['sicil_no']??'',$r['dept']??'',$r['tarih'],$r['giris_saati']?substr($r['giris_saati'],0,5):'',$r['cikis_saati']?substr($r['cikis_saati'],0,5):'',number_format((float)$r['calisma_suresi'],1),number_format((float)$r['fazla'],1),number_format($sl,2),number_format($sl*$r['fazla']*1.5,2)]);}
        break;

    case 'vardiya':
        $hafta_bit=date('Y-m-d',strtotime($hafta.' +6 days'));
        $vmap=[]; try{$vr=$db->query("SELECT id,baslangic FROM vardialar WHERE aktif=1")->fetchAll();foreach($vr as $v){$s=substr($v['baslangic'],0,5);if($s==='08:00')$vmap[$v['id']]=1;elseif($s==='16:00')$vmap[$v['id']]=2;elseif($s==='00:00')$vmap[$v['id']]=3;}}catch(Exception $e){}
        $am=$db->prepare("SELECT va.personel_id,va.vardiya_id FROM vardiya_atamalari va WHERE va.baslangic<=? AND (va.bitis IS NULL OR va.bitis>=?)");$am->execute([$hafta_bit,$hafta]);$aMap=[];foreach($am->fetchAll() as $a)$aMap[$a['personel_id']]=$vmap[$a['vardiya_id']]??$a['vardiya_id'];
        $q=$db->query("SELECT p.id,CONCAT(p.ad,' ',p.soyad) per,p.sicil_no,d.ad dept,p.kadro,p.servis_durak,p.vardiya_tipi,p.aktif_vardiya FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.durum='aktif' AND p.vardiya_tipi IS NOT NULL ORDER BY p.ad");
        $vt=[1=>'1.Vardiya 08-16',2=>'2.Vardiya 16-00',3=>'3.Vardiya 00-08'];
        xr(['Personel','Sicil','Departman','Kadro','Durak','Sistem','Bu Hafta','Sonraki Hafta'],true);
        foreach($q->fetchAll() as $r){$vno=$aMap[$r['id']]??(int)$r['aktif_vardiya'];$sno=($r['vardiya_tipi']==='3lu'&&$vno)?($vno===1?3:($vno===3?2:1)):$vno;$bh=$r['vardiya_tipi']==='tek'?'Tek 08-16':($vt[$vno]??'Atanmadi');$sh=$r['vardiya_tipi']==='tek'?'Tek 08-16':($vt[$sno]??'');xr([$r['per'],$r['sicil_no']??'',$r['dept']??'',$r['kadro']??'',$r['servis_durak']??'',$r['vardiya_tipi']==='3lu'?'3lu Sistem':'Tek Vardiya',$bh,$sh]);}
        break;

    case 'oneri':
        $q=$db->query("SELECT CASE WHEN os.anonim=1 THEN 'Anonim' ELSE CONCAT(p.ad,' ',p.soyad) END per,p.sicil_no,os.tip,os.konu,os.aciklama,os.durum,os.odul_hakki,os.odul_tutari,os.inceleme_notu,os.olusturma FROM oneri_sikayet os JOIN personeller p ON os.personel_id=p.id ORDER BY os.olusturma DESC");
        $tt=['oneri'=>'Oneri','sikayet'=>'Sikayet','dilek'=>'Dilek'];
        xr(['Personel','Sicil','Tip','Konu','Aciklama','Durum','Odul','Odul Tutari','Not','Tarih'],true);
        foreach($q->fetchAll() as $r) xr([$r['per'],$r['sicil_no']??'',$tt[$r['tip']]??$r['tip'],$r['konu'],$r['aciklama'],ucfirst($r['durum']),$r['odul_hakki']?'Evet':'Hayir',$r['odul_tutari']>0?number_format($r['odul_tutari'],2):'',$r['inceleme_notu']??'',date('d.m.Y',strtotime($r['olusturma']))]);
        break;

    case 'bordro':
        $where=["p.durum='aktif'"]; $params=[$ay,$yil];
        if ($dept) { $where[]="p.departman_id=?"; $params[]=$dept; }
        $q=$db->prepare("SELECT p.sicil_no,CONCAT(p.ad,' ',p.soyad) per,d.ad dept,p.brut_maas,bf.dosya_adi,bf.olusturma FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id LEFT JOIN bordro_dosyalar bf ON bf.personel_id=p.id AND bf.ay=? AND bf.yil=? WHERE ".implode(' AND ',$where)." ORDER BY p.ad");
        $q->execute($params);
        xr(['Sicil','Personel','Departman','Brut Maas','Durum','Yuklenme'],true);
        foreach($q->fetchAll() as $r) xr([$r['sicil_no']??'',$r['per'],$r['dept']??'',number_format((float)$r['brut_maas'],2),$r['dosya_adi']?'Yuklendi':'Bekleniyor',$r['olusturma']?date('d.m.Y',strtotime($r['olusturma'])):'' ]);
        break;

    case 'turnover':
        $q=$db->prepare("SELECT CONCAT(p.ad,' ',p.soyad) per,p.sicil_no,d.ad dept,p.pozisyon,p.ise_baslama,p.isten_cikis_tarihi,p.isten_cikis_sebebi,DATEDIFF(COALESCE(p.isten_cikis_tarihi,CURDATE()),p.ise_baslama) gun FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE YEAR(p.isten_cikis_tarihi)=? OR YEAR(p.ise_baslama)=? ORDER BY p.isten_cikis_tarihi DESC");
        $q->execute([$yil,$yil]);
        xr(['Personel','Sicil','Departman','Pozisyon','Ise Baslama','Ayrilma','Sebep','Calisma (gun)'],true);
        foreach($q->fetchAll() as $r) xr([$r['per'],$r['sicil_no']??'',$r['dept']??'',$r['pozisyon']??'',$r['ise_baslama']??'',$r['isten_cikis_tarihi']??'',$r['isten_cikis_sebebi']??'',(int)$r['gun']]);
        break;

    case 'departman':
        $q=$db->query("SELECT d.kod,d.ad,CONCAT(p.ad,' ',p.soyad) mudur,(SELECT COUNT(*) FROM personeller WHERE departman_id=d.id AND durum='aktif') per_say,d.durum FROM departmanlar d LEFT JOIN personeller p ON d.mudur_id=p.id ORDER BY d.ad");
        xr(['Kod','Departman','Mudur','Personel Sayisi','Durum'],true);
        foreach($q->fetchAll() as $r) xr([$r['kod']??'',$r['ad'],$r['mudur']??'',(int)$r['per_say'],$r['durum']?'Aktif':'Pasif']);
        break;

    default:
        echo '<tr><td>Gecersiz tip</td></tr>';
}
echo '</table></body></html>';
