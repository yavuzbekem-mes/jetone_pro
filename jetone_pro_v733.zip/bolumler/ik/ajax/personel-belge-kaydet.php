<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','ekle')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);
$d = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$pid  = (int)($d['personel_id'] ?? 0);
$adi  = trim($d['belge_adi'] ?? '');
$kat  = $d['kategori'] ?? 'kisisel';
if (!$pid || !$adi) Auth::json(['ok'=>false,'hata'=>'Zorunlu alan eksik.']);
try {
    $db->prepare("INSERT INTO personel_belgeler (personel_id,kategori,belge_adi,gecerlilik,notlar,olusturan_id) VALUES (?,?,?,?,?,?)")
       ->execute([$pid,$kat,$adi,$d['gecerlilik']??null ?: null,trim($d['notlar']??'') ?: null,Auth::kullanici()['id']??null]);
    Auth::json(['ok'=>true]);
} catch (Exception $e) { Auth::json(['ok'=>false,'hata'=>$e->getMessage()]); }
