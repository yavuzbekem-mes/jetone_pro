<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Personel Portal — Devam Kayıt (Giriş/Çıkış)
 * bolumler/ik/ajax/devam-kayit.php
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/push-gonder.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
ob_clean();
header('Content-Type: application/json; charset=utf-8');

// ── Personel portal oturumu ───────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_name('JETONE_PERSONEL');
    session_start();
}
if (empty($_SESSION['portal']['id']) || $_SESSION['portal']['tip'] !== 'personel') {
    http_response_code(401);
    echo json_encode(['ok'=>false,'hata'=>'Oturum geçersiz. Lütfen tekrar giriş yapın.']);
    exit;
}

$d          = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$tip        = trim($d['tip'] ?? '');
$personelId = (int)($_SESSION['portal']['ilgili_id'] ?? 0);
$lat        = isset($d['lat']) ? (float)$d['lat'] : null;
$lng        = isset($d['lng']) ? (float)$d['lng'] : null;
$adres      = trim($d['adres'] ?? '');

if (!in_array($tip, ['giris','cikis']) || !$personelId) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz istek.']); exit;
}

// ── Geofence ayarlarını DB'den oku ───────────────────────
$geofence_aktif = false;
$is_yeri_lat    = 41.290089;
$is_yeri_lng    = 27.969982;
$is_yeri_yaricap= 200; // metre
$is_yeri_adi    = 'İş Yeri';

try {
    $gf = $db->query("SELECT lat, lng, yaricap_metre, ad FROM geofence_lokasyonlari WHERE aktif=1 ORDER BY id LIMIT 1")->fetch();
    if ($gf) {
        $is_yeri_lat    = (float)$gf['lat'];
        $is_yeri_lng    = (float)$gf['lng'];
        $is_yeri_yaricap= (int)($gf['yaricap_metre'] ?? 200);
        $is_yeri_adi    = $gf['ad'] ?? 'İş Yeri';
        $geofence_aktif = true;
    }
} catch (Exception $e) {}

// Geofence yoksa ayarlar tablosundan kontrol et
if (!$geofence_aktif) {
    try {
        $ayar = $db->query("SELECT deger FROM ayarlar WHERE anahtar='geofence_aktif' LIMIT 1")->fetchColumn();
        $geofence_aktif = (bool)$ayar;
    } catch (Exception $e) {}
}

// ── Mesafe hesabı (Haversine formülü) ─────────────────────
function haversine($lat1, $lng1, $lat2, $lng2) {
    $R = 6371000; // metre
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat/2)*sin($dLat/2) +
         cos(deg2rad($lat1))*cos(deg2rad($lat2))*
         sin($dLng/2)*sin($dLng/2);
    return $R * 2 * atan2(sqrt($a), sqrt(1-$a));
}

// ── Konum kontrolü ────────────────────────────────────────
$konum_ok      = true;
$mesafe_m      = null;
$giris_tipi    = 'portal';

if ($lat !== null && $lng !== null) {
    $mesafe_m = haversine($lat, $lng, $is_yeri_lat, $is_yeri_lng);
    if ($mesafe_m <= $is_yeri_yaricap) {
        $konum_ok   = true;
        $giris_tipi = 'geofence';
    } else {
        $konum_ok = false;
    }
} elseif ($geofence_aktif) {
    // Konum alınamadı ama geofence zorunlu
    $konum_ok = false;
}

// Geofence zorunlu mu? (Ayardan)
$geofence_zorunlu = false;
try {
    $gz = $db->query("SELECT deger FROM ayarlar WHERE anahtar='geofence_zorunlu' LIMIT 1")->fetchColumn();
    $geofence_zorunlu = (bool)$gz;
} catch (Exception $e) {}

if ($geofence_zorunlu && !$konum_ok && $lat !== null) {
    $mesafe_text = $mesafe_m ? round($mesafe_m) . 'm uzakta' : 'konum alınamadı';
    echo json_encode([
        'ok'     => false,
        'hata'   => "İş yerine çok uzaksınız. ($mesafe_text — max {$is_yeri_yaricap}m)",
        'mesafe' => $mesafe_m ? round($mesafe_m) : null,
        'konum_ok' => false,
    ]);
    exit;
}

// ── Devam kaydı ───────────────────────────────────────────
$bugun = date('Y-m-d');

try {
    $mevcut = $db->prepare("SELECT * FROM devam_kayitlari WHERE personel_id=? AND tarih=? LIMIT 1");
    $mevcut->execute([$personelId, $bugun]);
    $kayit = $mevcut->fetch();

    if ($tip === 'giris') {
        if ($kayit) {
            echo json_encode(['ok'=>false,'hata'=>'Bugün zaten giriş kaydı var ('.date('H:i',strtotime($kayit['giris_saati'])).').']); exit;
        }

        // lat/lng kolonları var mı kontrol et, yoksa olmadan ekle
        try {
            $db->prepare("INSERT INTO devam_kayitlari (personel_id,tarih,giris_saati,durum,lat,lng,giris_tipi) VALUES (?,?,NOW(),'geldi',?,?,?)")
               ->execute([$personelId,$bugun,$lat,$lng,$giris_tipi]);
        } catch (Exception $e) {
            // lat/lng kolonu yoksa olmadan dene
            $db->prepare("INSERT INTO devam_kayitlari (personel_id,tarih,giris_saati,durum,giris_tipi) VALUES (?,?,NOW(),'geldi',?)")
               ->execute([$personelId,$bugun,$giris_tipi]);
        }

        echo json_encode([
            'ok'      => true,
            'mesaj'   => 'Giriş kaydedildi.',
            'saat'    => date('H:i'),
            'konum_ok'=> $konum_ok,
            'mesafe'  => $mesafe_m ? round($mesafe_m) : null,
        ]);

    } else { // cikis
        if (!$kayit) {
            echo json_encode(['ok'=>false,'hata'=>'Bugün giriş kaydı bulunamadı.']); exit;
        }
        if ($kayit['cikis_saati']) {
            echo json_encode(['ok'=>false,'hata'=>'Çıkış zaten yapılmış ('.date('H:i',strtotime($kayit['cikis_saati'])).').']); exit;
        }
        $giris  = strtotime($bugun . ' ' . $kayit['giris_saati']);
        $sure   = round((time() - $giris) / 3600, 2);

        try {
            $db->prepare("UPDATE devam_kayitlari SET cikis_saati=NOW(), calisma_suresi=?, cikis_tipi='portal', cikis_lat=?, cikis_lng=? WHERE id=?")
               ->execute([$sure,$lat,$lng,$kayit['id']]);
        } catch (Exception $e) {
            $db->prepare("UPDATE devam_kayitlari SET cikis_saati=NOW(), calisma_suresi=?, cikis_tipi='portal' WHERE id=?")
               ->execute([$sure,$kayit['id']]);
        }

        echo json_encode([
            'ok'   => true,
            'mesaj'=> 'Çıkış kaydedildi.',
            'saat' => date('H:i'),
            'sure' => $sure,
        ]);
    }
} catch (Exception $e) {
    error_log('[DevamKayit] ' . $e->getMessage());
    echo json_encode(['ok'=>false,'hata'=>'Kayıt hatası: ' . $e->getMessage()]);
}
