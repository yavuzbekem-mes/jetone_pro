<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Personel Belge Yükleme AJAX
 * bolumler/ik/ajax/personel-belge-yukle.php
 *
 * Klasör yapısı:
 *   bolumler/ik/personel_belgeleri/
 *     └── P-00016_16/
 *         ├── kisisel/
 *         ├── egitim/
 *         ├── is_iliskisi/
 *         ├── saglik/
 *         ├── is_sureci/
 *         └── ayrilik/
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';

ob_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik', 'ekle')) {
    Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'], 403);
}

$kul_id      = Auth::kullanici()['id'] ?? null;
$personel_id = (int)($_POST['personel_id'] ?? 0);
$belge_adi   = trim($_POST['belge_adi']   ?? '');
$kategori    = trim($_POST['kategori']    ?? 'kisisel');
$gecerlilik  = ($_POST['gecerlilik'] ?? '') ?: null;
$notlar      = trim($_POST['notlar'] ?? '') ?: null;

if (!$personel_id || !$belge_adi) {
    Auth::json(['ok'=>false,'hata'=>'Personel ID ve belge adı zorunludur.']);
}

// Kategori güvenlik kontrolü
$izinli_kategori = ['kisisel','egitim','is_iliskisi','saglik','is_sureci','ayrilik'];
if (!in_array($kategori, $izinli_kategori)) $kategori = 'kisisel';

// Personeli çek
try {
    $per = $db->prepare("SELECT sicil_no, ad, soyad FROM personeller WHERE id=? LIMIT 1");
    $per->execute([$personel_id]);
    $personel = $per->fetch();
    if (!$personel) Auth::json(['ok'=>false,'hata'=>'Personel bulunamadı.']);
} catch (Exception $e) {
    Auth::json(['ok'=>false,'hata'=>'Veritabanı hatası: '.$e->getMessage()]);
}

// Güvenli klasör adı: P-00016_16
$sicil_temiz = preg_replace('/[^A-Za-z0-9\-]/', '', $personel['sicil_no']);
$klasor_adi  = $sicil_temiz . '_' . $personel_id;

// ── Doğru yol: bu dosya bolumler/ik/ajax/ altında ──────
// __DIR__                          = .../bolumler/ik/ajax
// dirname(__DIR__)                  = .../bolumler/ik
// dirname(dirname(__DIR__))         = .../bolumler
// dirname(dirname(dirname(__DIR__))) = .../jetone_pro  (ROOT_DIR)

$ik_dizin    = dirname(__DIR__);                       // bolumler/ik
$belge_koku  = $ik_dizin . '/personel_belgeleri';     // bolumler/ik/personel_belgeleri
$per_klasoru = $belge_koku . '/' . $klasor_adi;
$kat_klasoru = $per_klasoru . '/' . $kategori;

// Debug: yolları logla
error_log("[BelgeYukle] ik_dizin=$ik_dizin | belge_koku=$belge_koku | per=$per_klasoru");

// Klasörleri oluştur
foreach ([$belge_koku, $per_klasoru, $kat_klasoru] as $dir) {
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true)) {
            Auth::json(['ok'=>false,'hata'=>"Klasör oluşturulamadı: $dir — Sunucu yazma izni kontrol edilmeli."]);
        }
    }
}

// .htaccess güvenliği
$htaccess = $belge_koku . '/.htaccess';
if (!file_exists($htaccess)) {
    @file_put_contents($htaccess,
        "Options -Indexes\n<FilesMatch \"\\.php$\">\n  Require all denied\n</FilesMatch>\n"
    );
}

// Dosya yükleme
$dosya_adi_db  = null;
$dosya_yolu_db = null;

if (isset($_FILES['dosya']) && $_FILES['dosya']['error'] === UPLOAD_ERR_OK) {
    $dosya    = $_FILES['dosya'];
    $orijinal = $dosya['name'];
    $boyut    = $dosya['size'];
    $gecici   = $dosya['tmp_name'];
    $mime     = mime_content_type($gecici);

    $izinli_mime   = ['application/pdf','image/jpeg','image/jpg','image/png','image/gif','image/webp'];
    $izinli_uzanti = ['pdf','jpg','jpeg','png','gif','webp'];
    $uzanti        = strtolower(pathinfo($orijinal, PATHINFO_EXTENSION));

    if (!in_array($mime, $izinli_mime) || !in_array($uzanti, $izinli_uzanti)) {
        Auth::json(['ok'=>false,'hata'=>'Sadece PDF ve resim (JPG, PNG) yüklenebilir. MIME: '.$mime]);
    }
    if ($boyut > 10 * 1024 * 1024) {
        Auth::json(['ok'=>false,'hata'=>'Dosya 10MB sınırını aşıyor. ('.round($boyut/1048576,1).' MB)']);
    }

    // Benzersiz isim: 20260315_143022_abc123_BelgeAdi.pdf
    $zaman     = date('Ymd_His');
    $rast      = substr(md5(uniqid()), 0, 6);
    $temiz_ad  = preg_replace('/[^a-zA-Z0-9]/', '_', pathinfo($orijinal, PATHINFO_FILENAME));
    $temiz_ad  = substr($temiz_ad, 0, 40);
    $dosya_adi_db = $zaman . '_' . $rast . '_' . $temiz_ad . '.' . $uzanti;
    $hedef        = $kat_klasoru . '/' . $dosya_adi_db;

    if (!move_uploaded_file($gecici, $hedef)) {
        Auth::json(['ok'=>false,'hata'=>'Dosya sunucuya taşınamadı. Klasör: '.$kat_klasoru]);
    }

    // DB için göreli yol: P-00016_16/kisisel/20260315_...pdf
    $dosya_yolu_db = $klasor_adi . '/' . $kategori . '/' . $dosya_adi_db;

} elseif (isset($_FILES['dosya']) && $_FILES['dosya']['error'] !== UPLOAD_ERR_NO_FILE) {
    $upload_hatalar = [
        UPLOAD_ERR_INI_SIZE   => 'Dosya php.ini limitini aşıyor.',
        UPLOAD_ERR_FORM_SIZE  => 'Dosya form limitini aşıyor.',
        UPLOAD_ERR_PARTIAL    => 'Dosya kısmen yüklendi.',
        UPLOAD_ERR_NO_TMP_DIR => 'Geçici klasör yok.',
        UPLOAD_ERR_CANT_WRITE => 'Diske yazılamadı.',
        UPLOAD_ERR_EXTENSION  => 'PHP eklentisi engelledi.',
    ];
    $kod = $_FILES['dosya']['error'];
    Auth::json(['ok'=>false,'hata'=>$upload_hatalar[$kod] ?? "Upload hatası kodu: $kod"]);
}

// Veritabanına kaydet
try {
    $db->prepare("
        INSERT INTO personel_belgeler
            (personel_id, kategori, belge_adi, dosya_adi, dosya_yolu, gecerlilik, notlar, olusturan_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        $personel_id, $kategori, $belge_adi,
        $dosya_adi_db, $dosya_yolu_db,
        $gecerlilik, $notlar, $kul_id,
    ]);

    Auth::crudLog('ekle','ik','personel_belgeler',$db->lastInsertId(),null,
        ['belge'=>$belge_adi,'dosya'=>$dosya_adi_db,'pid'=>$personel_id],
        "Belge eklendi: $belge_adi ({$personel['sicil_no']})"
    );

    Auth::json([
        'ok'       => true,
        'dosya_var'=> !empty($dosya_adi_db),
        'klasor'   => $klasor_adi,
        'mesaj'    => $dosya_adi_db
            ? "Belge ve dosya yüklendi: $belge_adi ($klasor_adi)"
            : "Belge kaydedildi (dosyasız): $belge_adi",
    ]);

} catch (Exception $e) {
    if ($dosya_adi_db && file_exists($kat_klasoru . '/' . $dosya_adi_db)) {
        @unlink($kat_klasoru . '/' . $dosya_adi_db);
    }
    Auth::json(['ok'=>false,'hata'=>'DB hatası: '.$e->getMessage()]);
}
