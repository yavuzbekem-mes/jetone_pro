<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
// bolumler/ik/ajax/izin-onayla.php
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/push-gonder.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);

$d       = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id      = (int)($d['id']     ?? 0);
$islem   = $d['islem']         ?? ''; // onayla | reddet
$ret_sebebi = trim($d['ret_sebebi'] ?? '');

if (!$id || !in_array($islem, ['onayla','reddet'])) Auth::json(['ok'=>false,'hata'=>'Geçersiz istek.']);

$yeni_durum = $islem === 'onayla' ? 'onaylandi' : 'reddedildi';
$kul_id     = Auth::kullanici()['id'];

try {
    // İzin bilgisini çek + onaylayan kişi adını al
    $izinRow = $db->prepare("SELECT it.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.id per_id, pk.id portal_kul_id,
        CONCAT(k.ad,' ',COALESCE(k.soyad,'')) onaylayan_adi,
        (SELECT unvan FROM personeller WHERE email=k.email LIMIT 1) onaylayan_unvan
        FROM izin_talepleri it
        JOIN personeller p ON it.personel_id = p.id
        LEFT JOIN portal_kullanicilari pk ON pk.ilgili_id = p.id AND pk.tip='personel'
        LEFT JOIN kullanicilar k ON k.id = ?
        WHERE it.id = ? LIMIT 1");
    $izinRow->execute([$kul_id, $id]);
    $izin = $izinRow->fetch();

    $db->prepare("UPDATE izin_talepleri SET durum=?, onaylayan_id=?, onay_tarihi=NOW(), ret_sebebi=? WHERE id=?")
       ->execute([$yeni_durum, $kul_id, $ret_sebebi ?: null, $id]);

    // ── Personel portala bildirim ──────────────────────────────
    if ($izin) {
        $tur_tr = ['yillik'=>'Yıllık','hastalik'=>'Hastalık','mazeret'=>'Mazeret','ucretsiz'=>'Ücretsiz'];
        $tur    = $tur_tr[$izin['izin_turu']] ?? $izin['izin_turu'];
        $bas    = date('d.m.Y', strtotime($izin['baslangic']));
        $bit    = date('d.m.Y', strtotime($izin['bitis']));

        // Onaylayan kişi bilgisi
        $onaylayan_adi   = trim($izin['onaylayan_adi'] ?? '');
        $onaylayan_unvan = trim($izin['onaylayan_unvan'] ?? '');
        $onaylayan_str   = $onaylayan_adi
            ? ($onaylayan_unvan ? "$onaylayan_adi ($onaylayan_unvan)" : $onaylayan_adi)
            : 'Yöneticiniz';

        if ($islem === 'onayla') {
            $bil_baslik = '✅ İzin Talebiniz Onaylandı';
            $bil_mesaj  = "$tur izniniz ($bas – $bit) onaylandı.\nOnaylayan: $onaylayan_str";
            $bil_tip    = 'basari';
        } else {
            $ret_ac = $ret_sebebi ? "\nRed sebebi: $ret_sebebi" : '';
            $bil_baslik = '❌ İzin Talebiniz Reddedildi';
            $bil_mesaj  = "$tur izniniz ($bas – $bit) reddedildi.\nReddeden: $onaylayan_str$ret_ac";
            $bil_tip    = 'hata';
        }

        // Personel portala bildirim (portal_kullanicilari.id üzerinden)
        try {
            $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,link,okundu)
                          VALUES (?,?,?,?,?,?,?,0)")
               ->execute([
                   $izin['portal_kul_id'] ?: null,
                   'personel',
                   $bil_baslik,
                   $bil_mesaj,
                   $bil_tip,
                   'izin',
                   null,
               ]);

            // Push bildirim gönder (telefon/pc'ye anlık)
            pushGonder($izin['per_id'], $bil_baslik, $bil_mesaj, $bil_tip);

        } catch (Throwable $ignore) {}

        // ERP'de de bildirim — yöneticiye
        try {
            $yon = $db->prepare("SELECT yonetici_id FROM personeller WHERE id=? LIMIT 1");
            $yon->execute([$izin['per_id']]);
            $yonetici_per_id = $yon->fetchColumn();
            if ($yonetici_per_id) {
                // Yöneticinin ERP kullanıcısını bul
                $yon_kul = $db->prepare("SELECT k.id FROM kullanicilar k JOIN personeller p ON k.email=p.email WHERE p.id=? LIMIT 1");
                $yon_kul->execute([$yonetici_per_id]);
                $yon_kul_id = $yon_kul->fetchColumn();
                $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu)
                              VALUES (?,?,?,?,?,?,0)")
                   ->execute([
                       $yon_kul_id ?: null,
                       'erp',
                       "{$izin['per_adi']} — İzin " . ($islem==='onayla'?'Onaylandı':'Reddedildi'),
                       "$tur izni ($bas – $bit) " . ($islem==='onayla'?'onaylandı':'reddedildi') . ($ret_sebebi?" — $ret_sebebi":''),
                       $islem==='onayla'?'basari':'uyari',
                       'izin',
                   ]);
            }
        } catch (Throwable $ignore) {}
    }

    Auth::logKaydet($kul_id, 'izin_' . $islem, 'ik', $id, "İzin talebi #$id $yeni_durum");
    Auth::json(['ok'=>true,'durum'=>$yeni_durum]);
} catch (Throwable $e) {
    error_log('[IzinOnayla] ' . $e->getMessage());
    Auth::json(['ok'=>false,'hata'=>'İşlem sırasında hata.']);
}
