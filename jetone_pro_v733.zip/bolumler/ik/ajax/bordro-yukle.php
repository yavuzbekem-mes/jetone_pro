<?php
/**
 * İK — Bordro PDF Yükle
 * bolumler/ik/ajax/bordro-yukle.php
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) { echo json_encode(['ok'=>false,'hata'=>'Yetkisiz.']); exit; }

$pid  = (int)($_POST['personel_id'] ?? 0);
$ay   = (int)($_POST['ay']          ?? 0);
$yil  = (int)($_POST['yil']         ?? 0);
$kul  = Auth::kullanici()['id'];

if (!$pid || !$ay || !$yil) { echo json_encode(['ok'=>false,'hata'=>'Geçersiz parametreler.']); exit; }

// Dosya kontrolü
$dosya = $_FILES['bordro_pdf'] ?? null;
if (!$dosya || $dosya['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['ok'=>false,'hata'=>'Dosya yükleme hatası: '.($dosya['error']??'bilinmiyor')]); exit;
}

// PDF kontrolü
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime  = finfo_file($finfo, $dosya['tmp_name']);
finfo_close($finfo);
if ($mime !== 'application/pdf') {
    echo json_encode(['ok'=>false,'hata'=>'Sadece PDF dosyası yükleyebilirsiniz.']); exit;
}
if ($dosya['size'] > 10 * 1024 * 1024) {
    echo json_encode(['ok'=>false,'hata'=>'Dosya 10 MB\'dan büyük olamaz.']); exit;
}

// Personel bilgisi
try {
    $p = $db->prepare("SELECT sicil_no,ad,soyad FROM personeller WHERE id=? LIMIT 1");
    $p->execute([$pid]); $per=$p->fetch();
    if (!$per) { echo json_encode(['ok'=>false,'hata'=>'Personel bulunamadı.']); exit; }
} catch(Exception $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); exit; }

// Dosya yolu oluştur
$aylar = ['','Ocak','Subat','Mart','Nisan','Mayis','Haziran','Temmuz','Agustos','Eylul','Ekim','Kasim','Aralik'];
$guvenli_ad = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $per['sicil_no']??'P'.$pid);
$dosya_adi  = $guvenli_ad . '_' . $yil . '_' . sprintf('%02d',$ay) . '_Bordro.pdf';
$upload_dir = ROOT_DIR . '/uploads/bordrolar/';

if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

// Eski dosyayı sil (varsa)
try {
    $eski = $db->prepare("SELECT dosya_adi FROM bordro_dosyalar WHERE personel_id=? AND ay=? AND yil=? LIMIT 1");
    $eski->execute([$pid,$ay,$yil]); $eskiRow=$eski->fetch();
    if ($eskiRow && file_exists($upload_dir.$eskiRow['dosya_adi'])) {
        @unlink($upload_dir.$eskiRow['dosya_adi']);
    }
} catch(Exception $e){}

// Dosyayı taşı
if (!move_uploaded_file($dosya['tmp_name'], $upload_dir.$dosya_adi)) {
    echo json_encode(['ok'=>false,'hata'=>'Dosya kaydedilemedi.']); exit;
}

// DB kayıt (upsert)
try {
    $db->prepare("INSERT INTO bordro_dosyalar (personel_id,ay,yil,dosya_adi,dosya_yol,yukleyen_id)
        VALUES (?,?,?,?,?,?)")
       ->execute([$pid,$ay,$yil,$dosya_adi,$dosya_adi,$kul]);

    // Personele bildirim
    try {
        $aylar_tr=['','Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
        $pk=$db->prepare("SELECT id FROM portal_kullanicilari WHERE ilgili_id=? AND tip='personel' LIMIT 1");
        $pk->execute([$pid]); $pkRow=$pk->fetch();
        $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu) VALUES (?,?,?,?,?,?,0)")
           ->execute([$pkRow['id']??null,'personel',
               '📄 '.$aylar_tr[$ay].' '.$yil.' Bordronuz Hazır',
               $aylar_tr[$ay].' '.$yil.' dönemine ait bordronuz sisteme yüklendi. Portal üzerinden görüntüleyebilirsiniz.',
               'basari','bordro']);
    } catch(Exception $e){}

    Auth::logKaydet($kul,'bordro_yukle','ik',$pid,$dosya_adi." → $ay/$yil");
    echo json_encode(['ok'=>true,'dosya'=>$dosya_adi]);

} catch(Exception $e) {
    @unlink($upload_dir.$dosya_adi); // Hata durumunda dosyayı geri al
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
