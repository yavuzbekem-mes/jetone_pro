<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);
$d = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id    = (int)($d['id'] ?? 0);
$tarih = $d['cikis_tarihi'] ?? '';
$neden = trim($d['cikis_nedeni'] ?? '');
if (!$id || !$tarih || !$neden) Auth::json(['ok'=>false,'hata'=>'Zorunlu alanlar eksik.']);
try {
    $db->beginTransaction();
    $db->prepare("UPDATE personeller SET durum='ayrıldı', cikis_tarihi=?, cikis_nedeni=? WHERE id=?")
       ->execute([$tarih, $neden, $id]);
    if (!empty($d['portal_kapat'])) {
        $db->prepare("UPDATE portal_kullanicilari SET durum=0 WHERE tip='personel' AND ilgili_id=?")
           ->execute([$id]);
    }
    $stmt = $db->prepare("SELECT CONCAT(ad,' ',soyad) FROM personeller WHERE id=?");
    $stmt->execute([$id]); $ad = $stmt->fetchColumn();
    Auth::crudLog('cikis', 'ik', 'personeller', $id, null, ['durum'=>'ayrıldı','cikis_tarihi'=>$tarih,'cikis_nedeni'=>$neden], "$ad işten çıkış: $neden");
    $db->commit();
    Auth::json(['ok'=>true,'mesaj'=>"$ad çıkış işlemi tamamlandı."]);
} catch (Exception $e) {
    $db->rollBack();
    Auth::json(['ok'=>false,'hata'=>$e->getMessage()]);
}
