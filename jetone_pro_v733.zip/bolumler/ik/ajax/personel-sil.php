<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Personel Silme — DEVRE DIŞI
 * 
 * Yasal zorunluluk: SGK ve iş hukuku gereği personel kayıtları 
 * en az 10 yıl saklanmalıdır. Bu endpoint silme işlemi YAPMAZ.
 * Personel sadece "ayrıldı" statüsüne alınabilir (işten çıkış).
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
Auth::json([
    'ok'    => false,
    'hata'  => 'Personel kaydı silinemez. Yasal zorunluluk gereği (SGK: 10 yıl, İSG: 15 yıl) personel kayıtları arşivde saklanır. İşten çıkış için "İşten Çıkış" işlemini kullanın.',
    'kod'   => 'SILME_YASAK'
]);
