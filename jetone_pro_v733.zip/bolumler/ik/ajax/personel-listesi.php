<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
// bolumler/ik/ajax/personel-listesi.php
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','goruntule')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);

$arama = trim($_GET['arama'] ?? '');
$params = [];
$where  = '1=1';
if ($arama) {
    $where = "(p.ad LIKE ? OR p.soyad LIKE ? OR p.sicil_no LIKE ?)";
    $q = "%$arama%";
    $params = [$q,$q,$q];
}

$stmt = $db->prepare("SELECT p.id, p.sicil_no, p.ad, p.soyad, p.pozisyon, p.durum, d.ad departman_adi FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE $where ORDER BY p.ad LIMIT 50");
$stmt->execute($params);
Auth::json(['ok'=>true,'rows'=>$stmt->fetchAll()]);
