<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
$pid = (int)($_GET['personel_id'] ?? 0);
if (!$pid) { echo json_encode(['ok'=>false,'hata'=>'Personel ID gerekli']); exit; }

$aylar = ['','Ocak','Subat','Mart','Nisan','Mayis','Haziran','Temmuz','Agustos','Eylul','Ekim','Kasim','Aralik'];

try {
    $q = $db->prepare("SELECT id, ay, yil, dosya_adi, olusturma
        FROM bordro_dosyalar
        WHERE personel_id=?
        ORDER BY yil DESC, ay DESC, olusturma DESC");
    $q->execute([$pid]);
    $rows = $q->fetchAll();
    $bordrolar = array_map(function($r) use ($aylar) {
        return [
            'id'       => $r['id'],
            'ay'       => $r['ay'],
            'yil'      => $r['yil'],
            'ay_yil'   => ($aylar[$r['ay']] ?? $r['ay']) . ' ' . $r['yil'],
            'dosya_adi'=> $r['dosya_adi'],
            'url'      => BASE_URL . '/uploads/bordrolar/' . rawurlencode($r['dosya_adi']),
            'tarih'    => date('d.m.Y', strtotime($r['olusturma'])),
        ];
    }, $rows);
    echo json_encode(['ok'=>true,'bordrolar'=>$bordrolar]);
} catch(Exception $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
