<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$personel_id = (int)($p['personel_id'] ?? 0);
$ihtar_tarihi = $p['ihtar_tarihi'] ?? '';
if (!$personel_id || !$ihtar_tarihi) { echo json_encode(['ok'=>false,'hata'=>'Personel ve tarih zorunlu']); exit; }

// Personel bilgileri
$per = $db->prepare("SELECT p.kadro, p.unvan, d.ad dept_adi FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.id=?");
$per->execute([$personel_id]); $per = $per->fetch();

$nedenler = array_map('intval', $p['nedenler'] ?? []);
try {
    if ($id) {
        $db->prepare("UPDATE ihtar_tutanaklar SET personel_id=?,ihtar_tarihi=?,teblig_eden=?,sabit=?,nedenler=?,diger_neden=?,savunma=?,karar=?,durum=?,ik_sorumlu=?,fabrika_mudur=?,bolum=?,kadro=?,unvan=? WHERE id=?")
           ->execute([$personel_id,$ihtar_tarihi,trim($p['teblig_eden']??''),trim($p['sabit']??''),json_encode($nedenler),trim($p['diger_neden']??'')||null,trim($p['savunma']??'')||null,trim($p['karar']??'')||null,$p['durum']??'bekliyor',trim($p['ik_sorumlu']??''),trim($p['fabrika_mudur']??''),$per['dept_adi']??'',$per['kadro']??'',$per['unvan']??'',$id]);
    } else {
        $son = $db->query("SELECT MAX(id) FROM ihtar_tutanaklar")->fetchColumn();
        $no = 'IHT-'.date('Y').'-'.str_pad(($son+1),4,'0',STR_PAD_LEFT);
        $db->prepare("INSERT INTO ihtar_tutanaklar (tutanak_no,personel_id,ihtar_tarihi,teblig_eden,sabit,nedenler,diger_neden,savunma,karar,durum,ik_sorumlu,fabrika_mudur,bolum,kadro,unvan,kaydeden_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$no,$personel_id,$ihtar_tarihi,trim($p['teblig_eden']??''),trim($p['sabit']??''),json_encode($nedenler),trim($p['diger_neden']??'')||null,trim($p['savunma']??'')||null,trim($p['karar']??'')||null,$p['durum']??'bekliyor',trim($p['ik_sorumlu']??''),trim($p['fabrika_mudur']??''),$per['dept_adi']??'',$per['kadro']??'',$per['unvan']??'',$user['id']??null]);
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
