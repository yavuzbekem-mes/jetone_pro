<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$baslik = trim($p['baslik'] ?? '');
$icerik = trim($p['icerik'] ?? '');
if (!$baslik || !$icerik) { echo json_encode(['ok'=>false,'hata'=>'Başlık ve içerik zorunlu']); exit; }

$hedef_ids = $p['hedef_ids'] ?? [];
$hedef_ids_json = !empty($hedef_ids) ? json_encode($hedef_ids) : null;

$vals = [
    'baslik'    => $baslik,
    'icerik'    => $icerik,
    'hedef'     => $p['hedef'] ?? 'herkese',
    'hedef_ids' => $hedef_ids_json,
    'oncelik'   => $p['oncelik'] ?? 'normal',
    'baslangic' => $p['baslangic'] ?: null,
    'bitis'     => $p['bitis'] ?: null,
    'aktif'     => (int)($p['aktif'] ?? 1),
];
try {
    if ($id) {
        $set = implode('=?,', array_keys($vals)).'=?';
        $v2 = array_values($vals); $v2[] = $id;
        $db->prepare("UPDATE duyurular SET $set WHERE id=?")->execute($v2);
    } else {
        $vals['olusturan_id'] = $user['id'] ?? null;
        $cols = implode(',', array_keys($vals));
        $phs  = implode(',', array_fill(0, count($vals), '?'));
        $db->prepare("INSERT INTO duyurular ($cols) VALUES ($phs)")->execute(array_values($vals));
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
