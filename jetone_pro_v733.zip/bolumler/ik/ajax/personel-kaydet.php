<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Personel Kaydet AJAX
 * bolumler/ik/ajax/personel-kaydet.php
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';

ob_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik', 'ekle')) {
    Auth::json(['ok'=>false,'hata'=>'Yetkiniz yok.'], 403);
}

$kul_id = Auth::kullanici()['id'] ?? null;

// POST verisini al
$id            = (int)($_POST['id'] ?? 0);
$sicil_no      = trim($_POST['sicil_no'] ?? '');
$ad            = trim($_POST['ad'] ?? '');
$soyad         = trim($_POST['soyad'] ?? '');

if (!$sicil_no || !$ad || !$soyad) {
    Auth::json(['ok'=>false,'hata'=>'Ad, soyad ve sicil no zorunludur.']);
}

// Sicil no benzersizlik kontrolü
$stmt = $db->prepare("SELECT id FROM personeller WHERE sicil_no=? AND id!=?");
$stmt->execute([$sicil_no, $id]);
if ($stmt->fetch()) {
    Auth::json(['ok'=>false,'hata'=>"'$sicil_no' sicil numarası zaten kullanılıyor."]);
}

// Tüm alanlar
$alanlar = [
    'sicil_no'           => $sicil_no,
    'ad'                 => $ad,
    'soyad'              => $soyad,
    'tc_kimlik'          => trim($_POST['tc_kimlik'] ?? '') ?: null,
    'uyruk'              => trim($_POST['uyruk'] ?? 'T.C.') ?: 'T.C.',
    'dogum_tarihi'       => $_POST['dogum_tarihi'] ?? null ?: null,
    'dogum_yeri'         => trim($_POST['dogum_yeri'] ?? '') ?: null,
    'cinsiyet'           => $_POST['cinsiyet'] ?? null ?: null,
    'medeni_durum'       => trim($_POST['medeni_durum'] ?? '') ?: null,
    'cocuk_sayisi'       => (int)($_POST['cocuk_sayisi'] ?? 0),
    'kan_grubu'          => trim($_POST['kan_grubu'] ?? '') ?: null,
    'engellilik_durumu'  => (int)($_POST['engellilik_durumu'] ?? 0),
    'engellilik_orani'   => (int)($_POST['engellilik_orani'] ?? 0),
    // Organizasyonel
    'departman_id'       => (int)($_POST['departman_id'] ?? 0) ?: null,
    'pozisyon'           => trim($_POST['pozisyon'] ?? '') ?: null,
    'unvan'              => trim($_POST['unvan'] ?? '') ?: null,
    'yonetici_id'        => (int)($_POST['yonetici_id'] ?? 0) ?: null,
    'tedarikci_firma'    => trim($_POST['tedarikci_firma'] ?? '') ?: null,
    'calisma_yeri'       => trim($_POST['calisma_yeri'] ?? '') ?: null,
    'calısma_tipi'       => $_POST['calısma_tipi'] ?? 'tam_zamanli',
    'kadro'              => in_array($_POST['kadro']??'',['beyaz_yaka','endirekt','direkt','stajyer']) ? $_POST['kadro'] : null,
    'servis_durak'       => in_array($_POST['servis_durak']??'',['cerkezkoy','kizilpinar','kapakli','karaagac']) ? $_POST['servis_durak'] : null,
    'vardiya_tipi'       => in_array($_POST['vardiya_tipi']??'',['tek','3lu','beyaz']) ? $_POST['vardiya_tipi'] : null,
    'aktif_vardiya'      => in_array($_POST['aktif_vardiya']??'',['1','2','3']) ? (int)$_POST['aktif_vardiya'] : null,
    'ise_baslama'        => $_POST['ise_baslama'] ?? null ?: null,
    'deneme_bitis'       => $_POST['deneme_bitis'] ?? null ?: null,
    'is_sozlesmesi_tipi' => $_POST['is_sozlesmesi_tipi'] ?? 'belirsiz_sureli',
    // Eğitim
    'egitim_seviyesi'    => trim($_POST['egitim_seviyesi'] ?? '') ?: null,
    'okul_adi'           => trim($_POST['okul_adi'] ?? '') ?: null,
    'bolum'              => trim($_POST['bolum'] ?? '') ?: null,
    'mezuniyet_yili'     => (int)($_POST['mezuniyet_yili'] ?? 0) ?: null,
    'askerlik_durumu'    => trim($_POST['askerlik_durumu'] ?? '') ?: null,
    'askerlik_tarihi'    => $_POST['askerlik_tarihi'] ?? null ?: null,
    // İletişim
    'telefon'            => trim($_POST['telefon'] ?? '') ?: null,
    'tel_is'             => trim($_POST['tel_is'] ?? '') ?: null,
    'email'              => strtolower(trim($_POST['email'] ?? '')) ?: null,
    'adres'              => trim($_POST['adres'] ?? '') ?: null,
    'il'                 => trim($_POST['il'] ?? '') ?: null,
    'ilce'               => trim($_POST['ilce'] ?? '') ?: null,
    'posta_kodu'         => trim($_POST['posta_kodu'] ?? '') ?: null,
    'acil_kisi_ad'       => trim($_POST['acil_kisi_ad'] ?? '') ?: null,
    'acil_kisi_tel'      => trim($_POST['acil_kisi_tel'] ?? '') ?: null,
    'acil_kisi_yakinlik' => trim($_POST['acil_kisi_yakinlik'] ?? '') ?: null,
    // Fiziksel
    'ayakkabi_no'        => trim($_POST['ayakkabi_no'] ?? '') ?: null,
    'ust_beden'          => trim($_POST['ust_beden'] ?? '') ?: null,
    'pantolon_beden'     => trim($_POST['pantolon_beden'] ?? '') ?: null,
    // SGK
    'sgk_no'             => trim($_POST['sgk_no'] ?? '') ?: null,
    'durum'              => $_POST['durum'] ?? 'aktif',
    'cikis_tarihi'       => $_POST['cikis_tarihi'] ?? null ?: null,
    'cikis_nedeni'       => trim($_POST['cikis_nedeni'] ?? '') ?: null,
    // Finansal
    'maas'               => (float)str_replace(',','.', $_POST['maas'] ?? '0'),
    'brut_maas'          => (float)str_replace(',','.', $_POST['brut_maas'] ?? '0'),
    'yol_ucreti'         => (float)str_replace(',','.', $_POST['yol_ucreti'] ?? '0'),
    'yemek_ucreti'       => (float)str_replace(',','.', $_POST['yemek_ucreti'] ?? '0'),
    'banka_adi'          => trim($_POST['banka_adi'] ?? '') ?: null,
    'banka_iban'         => strtoupper(preg_replace('/\s+/','',$_POST['banka_iban'] ?? '')) ?: null,
    // Sağlık
    'saglik_raporu_var'  => (int)($_POST['saglik_raporu_var'] ?? 0),
    'isg_egitim_tarihi'  => $_POST['isg_egitim_tarihi'] ?? null ?: null,
    'isg_egitim_sure'    => (int)($_POST['isg_egitim_sure'] ?? 0) ?: null,
    'notlar'             => trim($_POST['notlar'] ?? '') ?: null,
    // Portal
    'portal_aktif'       => (int)($_POST['portal_aktif'] ?? 1),
    'sifre_degistirildi' => 0, // Yeni kayıt = tek kullanımlık şifre
    'olusturan_id'       => $kul_id,
];

try {
    $db->beginTransaction();

    // ── Tabloda hangi kolonlar gerçekten var? ──────────────
    // Olmayan kolonları $alanlar'dan çıkar — tablo_guncelle çalıştırılmamış olabilir
    $mevcut_kolonlar = [];
    try {
        $cols = $db->query("SHOW COLUMNS FROM personeller")->fetchAll(PDO::FETCH_COLUMN);
        $mevcut_kolonlar = array_flip($cols);
    } catch (Exception $ex) {}

    if (!empty($mevcut_kolonlar)) {
        foreach (array_keys($alanlar) as $k) {
            if (!isset($mevcut_kolonlar[$k])) {
                unset($alanlar[$k]);
            }
        }
    }

    if ($id) {
        // ── GÜNCELLE ─────────────────────────────────────────
        $eski = $db->prepare("SELECT * FROM personeller WHERE id=?");
        $eski->execute([$id]);
        $eski_veri = $eski->fetch();

        unset($alanlar['olusturan_id']);
        $alanlar['guncelleme'] = date('Y-m-d H:i:s');

        $set_parts = []; $values = [];
        foreach ($alanlar as $k => $v) { $set_parts[] = "`$k`=?"; $values[] = $v; }
        $values[] = $id;
        $db->prepare("UPDATE personeller SET " . implode(',', $set_parts) . " WHERE id=?")->execute($values);

        // ── ERP ERİŞİMİ — GÜNCELLEME SIRASINDA DA ÇALIŞIR ────
        $erp_erisim  = (int)($_POST['erp_erisim_aktif'] ?? 0);
        $erp_ilk_sifre = null;
        $erp_email_raw = '';
        $erp_rol_adi   = '';

        if ($erp_erisim) {
            $erp_rol_id    = (int)($_POST['erp_rol_id'] ?? 5);
            $erp_email_raw = trim($_POST['erp_email'] ?? '')
                          ?: strtolower(trim($_POST['email'] ?? ''))
                          ?: strtolower(str_replace('-','.',$sicil_no)) . '@jetone.pro';

            $erp_ilk_sifre = ucfirst(strtolower($ad[0])) . substr($soyad, 0, 2) . rand(1000,9999) . '@';
            $erp_ilk_hash  = password_hash($erp_ilk_sifre, PASSWORD_DEFAULT);

            // Rol adını al
            try {
                $rol_stmt = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
                $rol_stmt->execute([$erp_rol_id]);
                $erp_rol_adi = $rol_stmt->fetchColumn() ?: 'Kullanıcı';
            } catch (Exception $e) { $erp_rol_adi = 'Kullanıcı'; }

            $mevcut = $db->prepare("SELECT id FROM kullanicilar WHERE email=? LIMIT 1");
            $mevcut->execute([$erp_email_raw]);
            $mevcut_kul = $mevcut->fetch();

            if ($mevcut_kul) {
                $db->prepare("UPDATE kullanicilar SET sifre_hash=?, sifre_degistirildi=0, durum=1 WHERE id=?")
                   ->execute([$erp_ilk_hash, $mevcut_kul['id']]);
            } else {
                $db->prepare("INSERT INTO kullanicilar (ad,soyad,email,sifre_hash,rol_id,departman_id,pozisyon,durum,sifre_degistirildi) VALUES (?,?,?,?,?,?,?,1,0)")
                   ->execute([$ad,$soyad,$erp_email_raw,$erp_ilk_hash,$erp_rol_id,$alanlar['departman_id']??null,$alanlar['pozisyon']??null]);
            }
            Auth::logKaydet($kul_id,'erp_erisim_verildi','ik',$id,"$ad $soyad ERP erişimi (güncelleme): $erp_email_raw");
        }

        // Portal kullanıcısı bilgilerini çek
        $portal_kul_stmt = $db->prepare("SELECT kullanici_adi FROM portal_kullanicilari WHERE tip='personel' AND ilgili_id=? LIMIT 1");
        $portal_kul_stmt->execute([$id]);
        $portal_kul_row = $portal_kul_stmt->fetch();

        Auth::crudLog('guncelle','ik','personeller',$id,$eski_veri,$alanlar,"$ad $soyad güncellendi");
        $db->commit();

        Auth::json([
            'ok'          => true,
            'id'          => $id,
            'mesaj'       => "$ad $soyad güncellendi.",
            'sicil_no'    => $sicil_no,
            'portal_sifre'=> null, // Güncelleme = şifre gösterilmez
            'erp_aktif'   => (bool)$erp_erisim,
            'erp_sifre'   => $erp_ilk_sifre,
            'erp_email'   => $erp_email_raw,
            'erp_rol'     => $erp_rol_adi,
            'erp_bilgi'   => $erp_erisim ? "ERP: $erp_email_raw / $erp_ilk_sifre" : '',
        ]);

    } else {
        // ── YENİ KAYIT ───────────────────────────────────────
        $set_parts = [];
        $values = [];
        foreach ($alanlar as $k => $v) {
            $set_parts[] = "`$k`";
            $values[] = $v;
        }

        $sql = "INSERT INTO personeller (" . implode(',', $set_parts) . ") VALUES (" . implode(',', array_fill(0, count($values), '?')) . ")";
        $db->prepare($sql)->execute($values);
        $personel_id = $db->lastInsertId();

        // ── PERSONEL PORTAL ŞİFRESİ — ZORUNLU (HER ZAMAN OLUŞTUR) ──
        $portal_ilk_sifre = ucfirst(strtolower($ad[0])) . substr($soyad, 0, 2) . rand(1000,9999) . '!';
        $portal_ilk_hash  = password_hash($portal_ilk_sifre, PASSWORD_DEFAULT);
        $portal_aktif     = (int)($_POST['portal_aktif'] ?? 1);

        // Varsa sil, yeniden ekle
        $db->prepare("DELETE FROM portal_kullanicilari WHERE tip='personel' AND kullanici_adi=?")
           ->execute([$sicil_no]);

        $db->prepare("
            INSERT INTO portal_kullanicilari
                (tip, ilgili_id, kullanici_adi, email, sifre_hash, ad_soyad, telefon, durum)
            VALUES ('personel', ?, ?, ?, ?, ?, ?, ?)
        ")->execute([
            $personel_id,
            $sicil_no,
            strtolower(trim($_POST['email'] ?? '')) ?: null,
            $portal_ilk_hash,
            "$ad $soyad",
            trim($_POST['telefon'] ?? '') ?: null,
            $portal_aktif,
        ]);

        // ── ERP PANELİ KULLANICISI — OPSİYONEL ───────────────
        $erp_erisim    = (int)($_POST['erp_erisim_aktif'] ?? 0);
        $erp_ilk_sifre = null;
        $erp_email_raw = '';
        $erp_rol_adi   = '';
        $erp_bilgi     = '';

        if ($erp_erisim) {
            $erp_rol_id = (int)($_POST['erp_rol_id'] ?? 0);
            if (!$erp_rol_id) $erp_rol_id = 5;

            $erp_email_raw = trim($_POST['erp_email'] ?? '')
                          ?: strtolower(trim($_POST['email'] ?? ''))
                          ?: strtolower(str_replace('-','.',$sicil_no)) . '@jetone.pro';

            // Rol adını al
            try {
                $rq = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
                $rq->execute([$erp_rol_id]);
                $erp_rol_adi = $rq->fetchColumn() ?: 'Kullanıcı';
            } catch (Exception $e) { $erp_rol_adi = 'Kullanıcı'; }

            // ERP şifresi üret
            $erp_ilk_sifre = ucfirst(strtolower($ad[0])) . substr($soyad, 0, 2) . rand(1000,9999) . '@';
            $erp_ilk_hash  = password_hash($erp_ilk_sifre, PASSWORD_DEFAULT);

            // sifre_degistirildi kolonu yoksa ekle
            try {
                $db->exec("ALTER TABLE kullanicilar ADD COLUMN sifre_degistirildi TINYINT(1) DEFAULT 1");
            } catch (Exception $ex) { /* kolon zaten var */ }

            $mevcut = $db->prepare("SELECT id FROM kullanicilar WHERE email=? LIMIT 1");
            $mevcut->execute([$erp_email_raw]);
            $mevcut_kul = $mevcut->fetch();

            if ($mevcut_kul) {
                $db->prepare("UPDATE kullanicilar SET
                    sifre_hash=?, rol_id=?, departman_id=?, pozisyon=?,
                    ad=?, soyad=?, sifre_degistirildi=0, durum=1
                    WHERE id=?
                ")->execute([
                    $erp_ilk_hash, $erp_rol_id,
                    $alanlar['departman_id'] ?? null,
                    $alanlar['pozisyon'] ?? null,
                    $ad, $soyad, $mevcut_kul['id']
                ]);
            } else {
                $db->prepare("
                    INSERT INTO kullanicilar
                        (ad, soyad, email, sifre_hash, rol_id, departman_id, pozisyon, durum, sifre_degistirildi)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0)
                ")->execute([
                    $ad, $soyad, $erp_email_raw, $erp_ilk_hash,
                    $erp_rol_id,
                    $alanlar['departman_id'] ?? null,
                    $alanlar['pozisyon'] ?? null,
                ]);
            }

            $erp_bilgi = "ERP: $erp_email_raw / $erp_ilk_sifre";
            Auth::logKaydet($kul_id, 'erp_erisim_verildi', 'ik', $personel_id,
                "$ad $soyad ERP erişimi: $erp_email_raw / Rol: $erp_rol_adi");
        }

        // ── ÖZLÜK BELGELERİNİ KAYDET ─────────────────────────
        $kat_map = ['kisisel','egitim','is_iliskisi','saglik','is_sureci'];
        foreach ($kat_map as $kat) {
            $belgeler = $_POST["belge_$kat"] ?? [];
            foreach ($belgeler as $belge_adi) {
                $db->prepare("INSERT INTO personel_belgeler (personel_id, kategori, belge_adi, olusturan_id) VALUES (?,?,?,?)")
                   ->execute([$personel_id, $kat, trim($belge_adi), $kul_id]);
            }
        }

        Auth::crudLog('ekle', 'ik', 'personeller', $personel_id, null, $alanlar, "$ad $soyad eklendi");

        $db->commit();

        Auth::json([
            'ok'           => true,
            'id'           => $personel_id,
            'mesaj'        => "$ad $soyad başarıyla kaydedildi.",
            'sicil_no'     => $sicil_no,
            'portal_sifre' => $portal_ilk_sifre,
            'erp_aktif'    => (bool)$erp_erisim,
            'erp_sifre'    => $erp_ilk_sifre,
            'erp_email'    => $erp_email_raw,
            'erp_rol'      => $erp_rol_adi,
            'erp_bilgi'    => $erp_bilgi,
        ]);
    }

} catch (Exception $e) {
    $db->rollBack();
    error_log('[PersonelKaydet] ' . $e->getMessage());

    $hata_mesaj = $e->getMessage();
    if (strpos($hata_mesaj, 'Duplicate') !== false) {
        if (strpos($hata_mesaj, 'sicil_no') !== false)
            $hata_mesaj = "Bu sicil numarası zaten kullanılıyor.";
        elseif (strpos($hata_mesaj, 'tc_kimlik') !== false)
            $hata_mesaj = "Bu T.C. kimlik numarası zaten kayıtlı.";
    } elseif (strpos($hata_mesaj, "Unknown column") !== false) {
        // Tablo güncellenmemiş olabilir
        $hata_mesaj = "Veritabanı kolonu eksik. Lütfen önce 'personel_tablo_guncelle.sql' dosyasını çalıştırın.";
    }

    Auth::json(['ok'=>false, 'hata'=>$hata_mesaj]);
}
