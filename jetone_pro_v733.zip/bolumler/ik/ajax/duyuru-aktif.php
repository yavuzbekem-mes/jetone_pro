<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$id=(int)($_POST['id']??0); $aktif=(int)($_POST['aktif']??0);
if(!$id){echo json_encode(['ok'=>false,'hata'=>'ID zorunlu']);exit;}
try{$db->prepare("UPDATE duyurular SET aktif=? WHERE id=?")->execute([$aktif,$id]);echo json_encode(['ok'=>true]);}
catch(Throwable $e){echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);}
