<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean(); header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();
$user = Auth::kullanici();
$p = $_POST;
$id = (int)($p['id'] ?? 0);
$per_id = (int)($p['personel_id'] ?? 0);
$tarih   = $p['degerlendirme_tarihi'] ?? '';
if (!$per_id || !$tarih) { echo json_encode(['ok'=>false,'hata'=>'Personel ve tarih zorunlu']); exit; }

// Personel bilgileri
$per = $db->prepare("SELECT p.unvan, d.ad dept_adi FROM personeller p LEFT JOIN departmanlar d ON p.departman_id=d.id WHERE p.id=?");
$per->execute([$per_id]); $per = $per->fetch();

$ki = ['k11','k12','k13','k14','k15','k16','k17','k18'];
$di = ['d21','d22','d23','d24','d25','d26','d27','d28','d29','d210','d211'];
$ti = ['t31','t32','t33','t34','t35','t36'];

$int = function($k) use ($p) { $v=(int)($p[$k]??0); return ($v>=1&&$v<=4)?$v:null; };
$tk = array_sum(array_map(function($k) use ($p){ return (int)($p[$k]??0); }, $ki));
$td = array_sum(array_map(function($k) use ($p){ return (int)($p[$k]??0); }, $di));
$tt = array_sum(array_map(function($k) use ($p){ return (int)($p[$k]??0); }, $ti));

$vals = ['personel_id'=>$per_id,'degerlendiren'=>trim($p['degerlendiren']??''),'deg_bolum'=>trim($p['deg_bolum']??''),'deg_unvan'=>trim($p['deg_unvan']??''),'degerlendirme_tarihi'=>$tarih,'firma_adi'=>'','bolum'=>$per['dept_adi']??'','unvan'=>$per['unvan']??'','hazirlayan'=>trim($p['hazirlayan']??''),'onaylayan'=>trim($p['onaylayan']??''),'toplam_k'=>$tk,'toplam_d'=>$td,'toplam_t'=>$tt,'genel_toplam'=>$tk+$td+$tt,'kaydeden_id'=>$user['id']??null];
foreach ($ki as $k) $vals[$k] = $int($k);
foreach ($di as $k) $vals[$k] = $int($k);
foreach ($ti as $k) $vals[$k] = $int($k);

try {
    if ($id) {
        unset($vals['kaydeden_id']);
        $set = implode('=?,',array_keys($vals)).'=?';
        $v2 = array_values($vals); $v2[]=$id;
        $db->prepare("UPDATE performans_degerlendirme SET $set WHERE id=?")->execute($v2);
    } else {
        $cols = implode(',',array_keys($vals));
        $phs  = implode(',',array_fill(0,count($vals),'?'));
        $db->prepare("INSERT INTO performans_degerlendirme ($cols) VALUES ($phs)")->execute(array_values($vals));
        $id = (int)$db->lastInsertId();
    }
    echo json_encode(['ok'=>true,'id'=>$id]);
} catch (Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
