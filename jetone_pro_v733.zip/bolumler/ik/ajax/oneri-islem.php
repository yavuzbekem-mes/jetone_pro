<?php
/**
 * İK — Öneri/Şikayet İşlem (Onayla/Reddet/Uygula)
 * bolumler/ik/ajax/oneri-islem.php
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/push-gonder.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) { echo json_encode(['ok'=>false,'hata'=>'Yetkisiz.']); exit; }

$d      = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id     = (int)($d['id']     ?? 0);
$islem  = $d['islem']         ?? '';  // onayla | reddet | uygula | incele
$not    = trim($d['not']      ?? '');
$odul   = !empty($d['odul']);
$kul_id = Auth::kullanici()['id'];

if (!$id || !in_array($islem,['onayla','reddet','uygula','incele'])) {
    echo json_encode(['ok'=>false,'hata'=>'Geçersiz istek.']); exit;
}

$durum_map=['onayla'=>'onaylandi','reddet'=>'reddedildi','uygula'=>'uygulandi','incele'=>'incelemede'];
$yeni_durum = $durum_map[$islem];

try {
    // Mevcut kaydı çek
    $q = $db->prepare("SELECT os.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.id per_id,
        pk.id portal_kul_id
        FROM oneri_sikayet os
        JOIN personeller p ON os.personel_id = p.id
        LEFT JOIN portal_kullanicilari pk ON pk.ilgili_id = p.id AND pk.tip='personel'
        WHERE os.id = ? LIMIT 1");
    $q->execute([$id]);
    $oneri = $q->fetch();
    if (!$oneri) { echo json_encode(['ok'=>false,'hata'=>'Kayıt bulunamadı.']); exit; }

    // Onaylayan kişi adı
    $kul = Auth::kullanici();
    $kul_adi = trim(($kul['ad']??'').' '.($kul['soyad']??''));
    $kul_unvan = '';
    try {
        $u=$db->prepare("SELECT unvan FROM personeller WHERE email=? LIMIT 1");
        $u->execute([$kul['email']??'']); $kul_unvan=$u->fetchColumn()||'';
    } catch(Exception $e){}
    $kul_imza = $kul_adi . ($kul_unvan ? " ($kul_unvan)" : '');

    // Ödül bilgisi
    $odul_tutari = ($islem === 'onayla' && $odul) ? 2500.00 : ($yeni_durum==='uygulandi'&&$odul?2500.00:0);

    // Güncelle
    $db->prepare("UPDATE oneri_sikayet SET
        durum=?, inceleme_notu=?, inceleme_tarihi=NOW(), inceleyici_id=?,
        odul_hakki=CASE WHEN ? > 0 THEN 1 ELSE odul_hakki END,
        odul_tutari=CASE WHEN ? > 0 THEN ? ELSE odul_tutari END
        WHERE id=?")
       ->execute([$yeni_durum, $not?:null, $kul_id,
                  $odul_tutari, $odul_tutari, $odul_tutari, $id]);

    // ── Personele bildirim ──────────────────────────────────────
    $tip_tr = ['oneri'=>'Öneriniz','sikayet'=>'Şikayetiniz','dilek'=>'Dilek/İsteğiniz'];
    $tip_str = $tip_tr[$oneri['tip']] ?? 'İletiniz';

    if ($islem==='onayla')      $baslik='✅ '.$tip_str.' Onaylandı';
    elseif ($islem==='reddet')  $baslik='❌ '.$tip_str.' Reddedildi';
    elseif ($islem==='uygula')  $baslik='🎯 '.$tip_str.' Uygulandı!';
    elseif ($islem==='incele')  $baslik='🔍 '.$tip_str.' İncelemede';
    else                        $baslik='📋 '.$tip_str.' Güncellendi';

    if ($islem==='onayla')      $_mk2='başlıklı öneriniz onaylandı.';
    elseif ($islem==='reddet')  $_mk2='başlıklı iletiniz reddedildi.';
    elseif ($islem==='uygula')  $_mk2='başlıklı öneriniz hayata geçirildi! Tebrikler 🎉';
    elseif ($islem==='incele')  $_mk2='başlıklı iletiniz incelemeye alındı.';
    else                        $_mk2='güncellendi.';
    $mesaj_parts = ["\"{$oneri['konu']}\" " . $_mk2];

    if ($kul_adi) $mesaj_parts[] = "İşlemi yapan: $kul_imza";
    if ($not)     $mesaj_parts[] = "Not: $not";
    if ($odul_tutari > 0) $mesaj_parts[] = "🏆 ₺" . number_format($odul_tutari,0,'.',',') . " öneri ödülüne hak kazandınız!";

    $mesaj = implode("\n", $mesaj_parts);
    $bil_tip = ($islem==='onayla'||$islem==='uygula') ? 'basari' : ($islem==='reddet' ? 'hata' : 'bilgi');

    // bildirimler tablosuna ekle
    try {
        $db->prepare("INSERT INTO bildirimler (kullanici_id,portal_tipi,baslik,mesaj,tip,modul,okundu)
                      VALUES (?,?,?,?,?,?,0)")
           ->execute([$oneri['portal_kul_id']??null,'personel',$baslik,$mesaj,$bil_tip,'oneri']);
    } catch(Exception $e){}

    // Push bildirim gönder
    try {
        pushGonder($oneri['per_id'], $baslik, $mesaj, $bil_tip);
    } catch(Exception $e){ error_log('[OneriIslem Push] '.$e->getMessage()); }

    Auth::logKaydet($kul_id, 'oneri_'.$islem, 'ik', $id, "Öneri/Şikayet #$id $yeni_durum");
    echo json_encode(['ok'=>true,'durum'=>$yeni_durum,'mesaj'=>"İşlem tamamlandı: $yeni_durum"]);

} catch(Throwable $e) {
    error_log('[OneriIslem] '.$e->getMessage());
    echo json_encode(['ok'=>false,'hata'=>'İşlem sırasında hata: '.$e->getMessage()]);
}
