<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');
Auth::zorunlu();

$d      = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$islem  = $d['islem'] ?? $_POST['islem'] ?? '';

try {
    if ($islem === 'kayit' || $islem === 'guncelle') {
        $pid    = (int)($d['personel_id'] ?? 0);
        $tarih  = $d['tarih'] ?? date('Y-m-d');
        $giris  = !empty($d['giris'])  ? $d['giris'].':00'  : null;
        $cikis  = !empty($d['cikis'])  ? $d['cikis'].':00'  : null;
        $durum  = $d['durum']  ?? 'geldi';
        $notlar = trim($d['notlar'] ?? '');
        $id_upd = (int)($d['id'] ?? 0);

        if (!$pid && $islem === 'kayit') { echo json_encode(['ok'=>false,'hata'=>'Personel seçin']); exit; }

        // Çalışma süresi hesapla
        $sure = null;
        if ($giris && $cikis) {
            $g  = strtotime($tarih.' '.$giris);
            $c2 = strtotime($tarih.' '.$cikis);
            if ($c2 > $g) $sure = round(($c2 - $g) / 3600, 2);
        }

        if ($islem === 'guncelle' && $id_upd) {
            $db->prepare("UPDATE devam_kayitlari SET giris_saati=?,cikis_saati=?,calisma_suresi=?,durum=?,notlar=?,giris_tipi='manuel' WHERE id=?")
               ->execute([$giris,$cikis,$sure,$durum,$notlar,$id_upd]);
        } else {
            // Mevcut kayıt varsa güncelle yoksa ekle
            $mev = $db->prepare("SELECT id FROM devam_kayitlari WHERE personel_id=? AND tarih=? LIMIT 1");
            $mev->execute([$pid,$tarih]);
            if ($row = $mev->fetch()) {
                $db->prepare("UPDATE devam_kayitlari SET giris_saati=?,cikis_saati=?,calisma_suresi=?,durum=?,notlar=?,giris_tipi='manuel' WHERE id=?")
                   ->execute([$giris,$cikis,$sure,$durum,$notlar,$row['id']]);
            } else {
                $db->prepare("INSERT INTO devam_kayitlari (personel_id,tarih,giris_saati,cikis_saati,calisma_suresi,durum,notlar,giris_tipi) VALUES (?,?,?,?,?,?,?,'manuel')")
                   ->execute([$pid,$tarih,$giris,$cikis,$sure,$durum,$notlar]);
            }
        }
        echo json_encode(['ok'=>true]);

    } elseif ($islem === 'sil') {
        $id_sil = (int)($d['id'] ?? 0);
        $db->prepare("DELETE FROM devam_kayitlari WHERE id=?")->execute([$id_sil]);
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'hata'=>'Geçersiz işlem: '.$islem]);
    }
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
