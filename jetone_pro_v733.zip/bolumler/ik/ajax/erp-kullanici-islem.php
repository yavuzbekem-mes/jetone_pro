<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * ERP Kullanıcı İşlemleri AJAX
 * bolumler/ik/ajax/erp-kullanici-islem.php
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';

ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik', 'duzenle')) {
    Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'], 403);
}

$d         = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$islem     = $d['islem']      ?? '';
$erp_kul_id= (int)($d['erp_kul_id'] ?? 0);

if (!$erp_kul_id) Auth::json(['ok'=>false,'hata'=>'ERP kullanıcı ID eksik.']);

try {
    // ERP kullanıcısını doğrula
    $kul = $db->prepare("SELECT id, email, ad, soyad, durum FROM kullanicilar WHERE id=? LIMIT 1");
    $kul->execute([$erp_kul_id]);
    $erp = $kul->fetch();
    if (!$erp) Auth::json(['ok'=>false,'hata'=>'ERP kullanıcısı bulunamadı.']);

    if ($islem === 'sifre_sifirla') {
        // Yeni geçici şifre üret
        $yeni = ucfirst(strtolower($erp['ad'][0]??'A'))
               . substr($erp['soyad']??'X', 0, 2)
               . rand(1000, 9999) . '@';
        $hash = password_hash($yeni, PASSWORD_DEFAULT);

        $db->prepare("UPDATE kullanicilar SET sifre_hash=?, sifre_degistirildi=0 WHERE id=?")
           ->execute([$hash, $erp_kul_id]);

        Auth::logKaydet(
            Auth::kullanici()['id'] ?? null,
            'erp_sifre_sifirla', 'ik', $erp_kul_id,
            "ERP şifre sıfırlandı: {$erp['email']}"
        );

        Auth::json([
            'ok'        => true,
            'yeni_sifre'=> $yeni,
            'email'     => $erp['email'],
            'mesaj'     => 'ERP şifresi sıfırlandı.',
        ]);

    } elseif ($islem === 'toggle_erisim') {
        $yeni_durum = $erp['durum'] ? 0 : 1;
        $db->prepare("UPDATE kullanicilar SET durum=? WHERE id=?")
           ->execute([$yeni_durum, $erp_kul_id]);

        $mesaj = $yeni_durum
            ? "{$erp['email']} ERP erişimi açıldı."
            : "{$erp['email']} ERP erişimi kapatıldı.";

        Auth::logKaydet(
            Auth::kullanici()['id'] ?? null,
            'erp_erisim_toggle', 'ik', $erp_kul_id, $mesaj
        );

        Auth::json(['ok'=>true, 'aktif'=>(bool)$yeni_durum, 'mesaj'=>$mesaj]);

    } else {
        Auth::json(['ok'=>false,'hata'=>'Geçersiz işlem.']);
    }

} catch (Exception $e) {
    Auth::json(['ok'=>false,'hata'=>$e->getMessage()]);
}
