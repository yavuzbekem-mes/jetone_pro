<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');

Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) { echo json_encode(['ok'=>false,'hata'=>'Yetkisiz']); exit; }

$d = json_decode(file_get_contents('php://input'), true) ?: [];
$id = (int)($d['id'] ?? 0);
if (!$id) { echo json_encode(['ok'=>false,'hata'=>'ID gerekli']); exit; }

try {
    $q = $db->prepare("SELECT dosya_yol FROM bordro_dosyalar WHERE id=? LIMIT 1");
    $q->execute([$id]); $row = $q->fetch();
    if ($row) {
        $path = ROOT_DIR . '/uploads/bordrolar/' . $row['dosya_yol'];
        if (file_exists($path)) @unlink($path);
    }
    $db->prepare("DELETE FROM bordro_dosyalar WHERE id=?")->execute([$id]);
    echo json_encode(['ok'=>true]);
} catch(Exception $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
