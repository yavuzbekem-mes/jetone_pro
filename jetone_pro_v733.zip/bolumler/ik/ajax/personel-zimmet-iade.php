<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(0);
/**
 * Zimmet İade Al — SADECE DURUM GÜNCELLENİR, SİLİNMEZ
 * bolumler/ik/ajax/personel-zimmet-iade.php
 */
require_once dirname(dirname(dirname(__DIR__))) . '/core/config.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/db.php';
require_once dirname(dirname(dirname(__DIR__))) . '/core/auth.php';

ob_clean();
header('Content-Type: application/json');
Auth::zorunlu();
if (!Auth::yetkiKontrol('ik','duzenle')) Auth::json(['ok'=>false,'hata'=>'Yetkisiz.'],403);

$d  = json_decode(file_get_contents('php://input'),true) ?: $_POST;
$id = (int)($d['id'] ?? 0);
if (!$id) Auth::json(['ok'=>false,'hata'=>'ID eksik.']);

try {
    // Mevcut kaydı kontrol et
    $stmt = $db->prepare("SELECT * FROM personel_zimmetler WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
    $zimmet = $stmt->fetch();

    if (!$zimmet) Auth::json(['ok'=>false,'hata'=>'Zimmet kaydı bulunamadı.']);
    if ($zimmet['durum'] !== 'zimmetli') {
        Auth::json(['ok'=>false,'hata'=>"Bu zimmet zaten '{$zimmet['durum']}' durumunda."]);
    }

    // Sadece durum güncelle — kayıt SİLİNMEZ
    $db->prepare("UPDATE personel_zimmetler SET durum='iade', iade_tarihi=CURDATE() WHERE id=?")
       ->execute([$id]);

    Auth::crudLog('guncelle','ik','personel_zimmetler',$id,
        ['durum'=>'zimmetli'],
        ['durum'=>'iade','iade_tarihi'=>date('Y-m-d')],
        "Zimmet iade alındı: {$zimmet['kalem']}"
    );

    Auth::json([
        'ok'          => true,
        'mesaj'       => "'{$zimmet['kalem']}' iade alındı olarak işaretlendi.",
        'yeni_durum'  => 'iade',
        'iade_tarihi' => date('d.m.Y'),
    ]);

} catch (Exception $e) {
    Auth::json(['ok'=>false,'hata'=>$e->getMessage()]);
}
