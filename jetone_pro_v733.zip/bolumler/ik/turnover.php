<?php
/**
 * İK — Turnover (İşgücü Devir) Raporu
 * bolumler/ik/turnover.php
 */
if (!Auth::yetkiKontrol('ik', 'goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div>';
    return;
}

$yil   = (int)($_GET['yil']  ?? date('Y'));
$ay    = (int)($_GET['ay']   ?? 0); // 0 = tüm yıl
$dept  = (int)($_GET['dept'] ?? 0);

$yil_list = range(date('Y'), max(2020, date('Y')-5));

try {
    $deptlar = $db->query("SELECT id,ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();

    // ── Dönem filtresi ──────────────────────────────────────
    $donem_bas  = $ay ? "$yil-" . str_pad($ay,2,'0',STR_PAD_LEFT) . "-01" : "$yil-01-01";
    $donem_bitis= $ay ? date('Y-m-t', strtotime($donem_bas)) : "$yil-12-31";

    // ── Temel sayılar ───────────────────────────────────────
    // Dönem başı aktif personel
    $s = $db->prepare("SELECT COUNT(*) FROM personeller WHERE ise_baslama <= ? AND (cikis_tarihi IS NULL OR cikis_tarihi >= ?) " . ($dept?"AND departman_id=?":""));
    $params_bas = $dept ? [$donem_bas, $donem_bas, $dept] : [$donem_bas, $donem_bas];
    $s->execute($params_bas);
    $donem_bas_sayi = (int)$s->fetchColumn();

    // Dönem sonu aktif
    $s2 = $db->prepare("SELECT COUNT(*) FROM personeller WHERE ise_baslama <= ? AND (cikis_tarihi IS NULL OR cikis_tarihi > ?) " . ($dept?"AND departman_id=?":""));
    $params_son = $dept ? [$donem_bitis, $donem_bitis, $dept] : [$donem_bitis, $donem_bitis];
    $s2->execute($params_son);
    $donem_son_sayi = (int)$s2->fetchColumn();

    // Dönemde işe girenler
    $s3 = $db->prepare("SELECT COUNT(*) FROM personeller WHERE ise_baslama BETWEEN ? AND ? " . ($dept?"AND departman_id=?":""));
    $p3 = $dept ? [$donem_bas, $donem_bitis, $dept] : [$donem_bas, $donem_bitis];
    $s3->execute($p3);
    $giren = (int)$s3->fetchColumn();

    // Dönemde ayrılanlar
    $s4 = $db->prepare("SELECT COUNT(*) FROM personeller WHERE cikis_tarihi BETWEEN ? AND ? " . ($dept?"AND departman_id=?":""));
    $p4 = $dept ? [$donem_bas, $donem_bitis, $dept] : [$donem_bas, $donem_bitis];
    $s4->execute($p4);
    $ayrilan = (int)$s4->fetchColumn();

    // Ortalama personel sayısı
    $ort_personel = ($donem_bas_sayi + $donem_son_sayi) / 2;

    // Turnover oranı
    $turnover_orani = $ort_personel > 0 ? round(($ayrilan / $ort_personel) * 100, 1) : 0;
    $giris_orani    = $ort_personel > 0 ? round(($giren   / $ort_personel) * 100, 1) : 0;
    $net_degisim    = $giren - $ayrilan;

    // ── Aylık trend (tüm yıl için) ──────────────────────────
    $aylik_trend = [];
    for ($m = 1; $m <= 12; $m++) {
        $ay_bas   = "$yil-" . str_pad($m,2,'0',STR_PAD_LEFT) . "-01";
        $ay_bitis = date('Y-m-t', strtotime($ay_bas));
        $wh       = $dept ? "AND departman_id=$dept" : "";

        $gi = (int)$db->query("SELECT COUNT(*) FROM personeller WHERE ise_baslama BETWEEN '$ay_bas' AND '$ay_bitis' $wh")->fetchColumn();
        $ay_c = (int)$db->query("SELECT COUNT(*) FROM personeller WHERE cikis_tarihi BETWEEN '$ay_bas' AND '$ay_bitis' $wh")->fetchColumn();
        $aylik_trend[] = ['ay'=>$m,'isim'=>date('M',mktime(0,0,0,$m,1)),'giren'=>$gi,'ayrilan'=>$ay_c];
    }

    // ── Ayrılış nedenleri dağılımı ──────────────────────────
    $s5 = $db->prepare("SELECT cikis_nedeni, COUNT(*) n FROM personeller WHERE cikis_tarihi BETWEEN ? AND ? AND cikis_nedeni IS NOT NULL " . ($dept?"AND departman_id=?":"") . " GROUP BY cikis_nedeni ORDER BY n DESC");
    $s5->execute($p4);
    $neden_dagilim = $s5->fetchAll();

    // ── Departman bazlı turnover ────────────────────────────
    $dept_turnover = [];
    foreach ($deptlar as $d) {
        $did = $d['id'];
        $bas = (int)$db->query("SELECT COUNT(*) FROM personeller WHERE ise_baslama <= '$donem_bas' AND (cikis_tarihi IS NULL OR cikis_tarihi >= '$donem_bas') AND departman_id=$did")->fetchColumn();
        $son = (int)$db->query("SELECT COUNT(*) FROM personeller WHERE ise_baslama <= '$donem_bitis' AND (cikis_tarihi IS NULL OR cikis_tarihi > '$donem_bitis') AND departman_id=$did")->fetchColumn();
        $ayr = (int)$db->query("SELECT COUNT(*) FROM personeller WHERE cikis_tarihi BETWEEN '$donem_bas' AND '$donem_bitis' AND departman_id=$did")->fetchColumn();
        $ort = ($bas + $son) / 2;
        $oran = $ort > 0 ? round(($ayr / $ort) * 100, 1) : 0;
        if ($bas > 0 || $son > 0) {
            $dept_turnover[] = ['ad'=>$d['ad'],'bas'=>$bas,'son'=>$son,'ayrilan'=>$ayr,'oran'=>$oran];
        }
    }
    usort($dept_turnover, fn($a,$b) => $b['oran'] <=> $a['oran']);

    // ── Kıdem bazlı ayrılış ─────────────────────────────────
    $kidem_sql = "SELECT
        CASE
            WHEN DATEDIFF(cikis_tarihi, ise_baslama) < 90   THEN '0-3 Ay'
            WHEN DATEDIFF(cikis_tarihi, ise_baslama) < 365  THEN '3-12 Ay'
            WHEN DATEDIFF(cikis_tarihi, ise_baslama) < 730  THEN '1-2 Yıl'
            WHEN DATEDIFF(cikis_tarihi, ise_baslama) < 1825 THEN '2-5 Yıl'
            ELSE '5+ Yıl'
        END kidem_grubu,
        COUNT(*) n
        FROM personeller
        WHERE cikis_tarihi BETWEEN ? AND ? AND cikis_tarihi IS NOT NULL " . ($dept?"AND departman_id=?":"") . "
        GROUP BY kidem_grubu ORDER BY MIN(DATEDIFF(cikis_tarihi, ise_baslama))";
    $sk = $db->prepare($kidem_sql);
    $sk->execute($p4);
    $kidem_dagilim = $sk->fetchAll();

    // ── Ayrılan personel listesi ────────────────────────────
    $ayrilan_sql = "SELECT p.*, d.ad dept_ad FROM personeller p
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        WHERE p.cikis_tarihi BETWEEN ? AND ? " . ($dept?"AND p.departman_id=?":"") . "
        ORDER BY p.cikis_tarihi DESC LIMIT 50";
    $sa = $db->prepare($ayrilan_sql);
    $sa->execute($p4);
    $ayrilan_liste = $sa->fetchAll();

    // ── Ortalama çalışma süresi (ayrılanlar) ───────────────
    $ort_sure_sql = "SELECT AVG(DATEDIFF(COALESCE(cikis_tarihi,CURDATE()), ise_baslama)) FROM personeller WHERE cikis_tarihi BETWEEN ? AND ? " . ($dept?"AND departman_id=?":"");
    $os = $db->prepare($ort_sure_sql);
    $os->execute($p4);
    $ort_gun = (float)$os->fetchColumn();
    $ort_yil = floor($ort_gun / 365);
    $ort_ay  = floor(($ort_gun % 365) / 30);

} catch (Exception $e) {
    $turnover_orani = $giris_orani = $giren = $ayrilan = $donem_bas_sayi = $donem_son_sayi = 0;
    $aylik_trend = $neden_dagilim = $dept_turnover = $kidem_dagilim = $ayrilan_liste = [];
    $ort_yil = $ort_ay = $net_degisim = 0;
}

$turnover_renk = $turnover_orani <= 5 ? '#12B76A' : ($turnover_orani <= 15 ? '#F79009' : '#F04438');
$turnover_et   = $turnover_orani <= 5 ? 'Düşük (İyi)' : ($turnover_orani <= 15 ? 'Normal' : 'Yüksek (Dikkat!)');
?>

<div class="s-bar">
  <div>
    <h1 class="s-bas">📊 Turnover Raporu</h1>
    <div class="s-yol">İnsan Kaynakları / <b>İşgücü Devir Analizi</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <div id="dt-toolbar-dt-turnover" style="display:inline-flex;align-items:center;gap:6px"></div>
    <!-- Filtreler -->
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap" id="filterForm">
      <input type="hidden" name="sayfa" value="ik-turnover">
      <select name="yil" class="form-alan" style="width:90px" onchange="this.form.submit()">
        <?php foreach($yil_list as $y): ?>
        <option value="<?php echo $y; ?>" <?php echo $y==$yil?'selected':''; ?>><?php echo $y; ?></option>
        <?php endforeach; ?>
      </select>
      <select name="ay" class="form-alan" style="width:130px" onchange="this.form.submit()">
        <option value="0" <?php echo $ay==0?'selected':''; ?>>Tüm Yıl</option>
        <?php for($m=1;$m<=12;$m++): ?>
        <option value="<?php echo $m; ?>" <?php echo $ay==$m?'selected':''; ?>><?php echo date('F',mktime(0,0,0,$m,1)); ?></option>
        <?php endfor; ?>
      </select>
      <select name="dept" class="form-alan" style="width:160px" onchange="this.form.submit()">
        <option value="0">Tüm Departmanlar</option>
        <?php foreach($deptlar as $d): ?>
        <option value="<?php echo $d['id']; ?>" <?php echo $dept==$d['id']?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <button onclick="dtExcelIndir('dt-toolbar-dt-turnover','Turnover')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- ═══ ANA KPI KARTLAR ═══ -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:20px">

  <!-- Turnover Oranı — ana kart -->
  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:20px;text-align:center;position:relative;overflow:hidden;grid-column:span 1">
    <div style="position:absolute;top:0;left:0;right:0;height:4px;background:<?php echo $turnover_renk; ?>"></div>
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3);margin-bottom:8px">Turnover Oranı</div>
    <div style="font-size:42px;font-weight:900;letter-spacing:-2px;color:<?php echo $turnover_renk; ?>;line-height:1">%<?php echo $turnover_orani; ?></div>
    <div style="margin-top:6px">
      <span class="roz" style="background:<?php echo $turnover_renk; ?>20;color:<?php echo $turnover_renk; ?>;font-size:11px"><?php echo $turnover_et; ?></span>
    </div>
    <div style="font-size:11px;color:var(--m3);margin-top:6px">Sektör ort: %12-15</div>
  </div>

  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;gap:6px">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3)">Dönem Başı</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:-.5px"><?php echo $donem_bas_sayi; ?></div>
    <div style="font-size:12px;color:var(--m2)">Aktif personel</div>
  </div>

  <div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;gap:6px">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--m3)">Dönem Sonu</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:-.5px"><?php echo $donem_son_sayi; ?></div>
    <div style="font-size:12px;color:var(--m2)">Aktif personel
      <?php if($net_degisim!=0): ?>
      <span style="color:<?php echo $net_degisim>0?'var(--bas)':'var(--hat)'; ?>;font-weight:700">
        <?php echo $net_degisim>0?'↑ +'.$net_degisim:'↓ '.$net_degisim; ?>
      </span>
      <?php endif; ?>
    </div>
  </div>

  <div style="background:#D1FADF;border:1px solid #BBF7D0;border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;gap:6px">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#0A8F4E">İşe Girenler</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:-.5px;color:#0A8F4E"><?php echo $giren; ?></div>
    <div style="font-size:12px;color:#0A8F4E">Giriş oranı %<?php echo $giris_orani; ?></div>
  </div>

  <div style="background:#FEE4E2;border:1px solid #FCA5A5;border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;gap:6px">
    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#F04438">Ayrılanlar</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:-.5px;color:#F04438"><?php echo $ayrilan; ?></div>
    <div style="font-size:12px;color:#F04438">Ort. kıdem: <?php echo $ort_yil; ?>y <?php echo $ort_ay; ?>ay</div>
  </div>
</div>

<!-- ═══ ANALİZ SATIRLARI ═══ -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">

  <!-- Aylık Trend Grafik -->
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">📈 Aylık Giriş / Çıkış Trendi (<?php echo $yil; ?>)</div></div>
    <div style="overflow-x:auto">
      <div style="display:flex;align-items:flex-end;gap:4px;height:120px;padding:0 4px;min-width:400px">
        <?php
        $max_val = 1;
        foreach ($aylik_trend as $t) $max_val = max($max_val, $t['giren'], $t['ayrilan']);
        foreach ($aylik_trend as $t):
          $gi_h = $max_val > 0 ? round($t['giren']   / $max_val * 100) : 0;
          $ay_h = $max_val > 0 ? round($t['ayrilan'] / $max_val * 100) : 0;
          $aktif = $t['ay'] == $ay || ($ay==0 && $t['ay']==date('n'));
        ?>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">
          <div style="width:100%;display:flex;gap:2px;align-items:flex-end;height:90px">
            <div style="flex:1;background:#D1FADF;border-radius:3px 3px 0 0;height:<?php echo $gi_h; ?>%;min-height:<?php echo $t['giren']>0?'2px':'0'; ?>;transition:height .3s" title="Giriş: <?php echo $t['giren']; ?>"></div>
            <div style="flex:1;background:#FCA5A5;border-radius:3px 3px 0 0;height:<?php echo $ay_h; ?>%;min-height:<?php echo $t['ayrilan']>0?'2px':'0'; ?>;transition:height .3s" title="Çıkış: <?php echo $t['ayrilan']; ?>"></div>
          </div>
          <div style="font-size:9px;color:<?php echo $aktif?'var(--t)':'var(--m3)'; ?>;font-weight:<?php echo $aktif?'700':'400'; ?>"><?php echo $t['isim']; ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="display:flex;gap:12px;margin-top:6px;justify-content:center;font-size:11px">
        <span><span style="display:inline-block;width:10px;height:10px;background:#D1FADF;border-radius:2px;margin-right:3px"></span>Giriş</span>
        <span><span style="display:inline-block;width:10px;height:10px;background:#FCA5A5;border-radius:2px;margin-right:3px"></span>Çıkış</span>
      </div>
    </div>
  </div>

  <!-- Ayrılış Nedenleri -->
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">📋 Ayrılış Nedenleri</div></div>
    <?php if (empty($neden_dagilim)): ?>
    <div style="padding:20px;text-align:center;color:var(--m2)">Bu dönemde ayrılış yok</div>
    <?php else:
      $toplam_neden = array_sum(array_column($neden_dagilim, 'n'));
      $renkler = ['#F04438','#F79009','#3B82F6','#8B5CF6','#EC4899','#14B8A6','#F97316','#64748B'];
      foreach ($neden_dagilim as $ni => $nd):
        $pct = $toplam_neden > 0 ? round($nd['n']/$toplam_neden*100) : 0;
        $renk = $renkler[$ni % count($renkler)];
    ?>
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:3px">
        <span style="font-weight:600"><?php echo htmlspecialchars($nd['cikis_nedeni']??'Belirtilmemiş'); ?></span>
        <span style="color:var(--m2)"><?php echo $nd['n']; ?> kişi (%<?php echo $pct; ?>)</span>
      </div>
      <div style="height:6px;background:var(--kenar);border-radius:3px;overflow:hidden">
        <div style="width:<?php echo $pct; ?>%;height:100%;background:<?php echo $renk; ?>;border-radius:3px;transition:width .5s"></div>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>

</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">

  <!-- Departman Bazlı -->
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">🏢 Departman Bazlı Turnover</div></div>
    <?php if (empty($dept_turnover)): ?>
    <div style="padding:20px;text-align:center;color:var(--m2)">Veri yok</div>
    <?php else: ?>
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 280px)"><table class="tablo" id="dt-turnover">
      <thead style="position:sticky;top:0;z-index:2;background:var(--yuzey)"><tr><th>Departman</th><th>Baş.</th><th>Son</th><th>Ayrılan</th><th>Oran</th></tr></thead>
      <tbody>
      <?php foreach ($dept_turnover as $dt):
        $dr = $dt['oran'] <= 5 ? '#12B76A' : ($dt['oran'] <= 15 ? '#F79009' : '#F04438');
      ?>
      <tr>
        <td style="font-weight:600"><?php echo htmlspecialchars($dt['ad']); ?></td>
        <td><?php echo $dt['bas']; ?></td>
        <td><?php echo $dt['son']; ?></td>
        <td style="color:var(--hat);font-weight:700"><?php echo $dt['ayrilan']; ?></td>
        <td>
          <div style="display:flex;align-items:center;gap:6px">
            <div style="width:50px;height:5px;background:var(--kenar);border-radius:3px;overflow:hidden">
              <div style="width:<?php echo min(100,$dt['oran']*3); ?>%;height:100%;background:<?php echo $dr; ?>;border-radius:3px"></div>
            </div>
            <span style="font-size:12px;font-weight:700;color:<?php echo $dr; ?>">%<?php echo $dt['oran']; ?></span>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <!-- Kıdem Bazlı Ayrılış -->
  <div class="kart">
    <div class="kart-ust"><div class="kart-bas">⏱ Kıdem Bazlı Ayrılış</div></div>
    <?php if (empty($kidem_dagilim)): ?>
    <div style="padding:20px;text-align:center;color:var(--m2)">Bu dönemde ayrılış yok</div>
    <?php else:
      $toplam_kidem = array_sum(array_column($kidem_dagilim,'n'));
      $kidem_renkler = ['#F04438','#F79009','#3B82F6','#8B5CF6','#14B8A6'];
      foreach ($kidem_dagilim as $ki => $kd):
        $pct = $toplam_kidem > 0 ? round($kd['n']/$toplam_kidem*100) : 0;
        $renk = $kidem_renkler[$ki % 5];
        $yorum = '';
        if ($kd['kidem_grubu']==='0-3 Ay') $yorum = '— İşe uyum sorunu';
        elseif ($kd['kidem_grubu']==='3-12 Ay') $yorum = '— Deneme sonrası';
    ?>
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:3px">
        <span style="font-weight:600"><?php echo $kd['kidem_grubu']; ?> <span style="font-size:11px;color:var(--m3);font-weight:400"><?php echo $yorum; ?></span></span>
        <span style="color:var(--m2)"><?php echo $kd['n']; ?> kişi (%<?php echo $pct; ?>)</span>
      </div>
      <div style="height:6px;background:var(--kenar);border-radius:3px;overflow:hidden">
        <div style="width:<?php echo $pct; ?>%;height:100%;background:<?php echo $renk; ?>;border-radius:3px;transition:width .5s"></div>
      </div>
    </div>
    <?php endforeach; endif; ?>

    <!-- Uyarı kutusu -->
    <?php
    $erken_ayrilan = 0;
    foreach ($kidem_dagilim as $kd) {
        if (in_array($kd['kidem_grubu'],['0-3 Ay','3-12 Ay'])) $erken_ayrilan += $kd['n'];
    }
    if ($erken_ayrilan > 0 && $ayrilan > 0):
      $erken_pct = round($erken_ayrilan/$ayrilan*100);
    ?>
    <div style="background:#FEF0C7;border-radius:var(--r);padding:10px 12px;margin-top:10px;font-size:12.5px;color:#B45309">
      ⚠️ Ayrılanların <b>%<?php echo $erken_pct; ?></b>'i ilk 1 yıl içinde ayrılmış. İşe uyum sürecini gözden geçirin.
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- ═══ ARALIK TANIMI ═══ -->
<div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:var(--r-lg);padding:14px;margin-bottom:14px;display:flex;gap:20px;flex-wrap:wrap;align-items:center">
  <div style="display:flex;align-items:center;gap:8px">
    <div style="width:10px;height:10px;border-radius:50%;background:var(--t)"></div>
    <span style="font-size:12.5px"><b>Turnover Formülü:</b> (Dönemde Ayrılanlar / Ortalama Personel) × 100</span>
  </div>
  <div style="color:var(--m3);font-size:12px">
    Ortalama personel = (<?php echo $donem_bas_sayi; ?> + <?php echo $donem_son_sayi; ?>) / 2 = <?php echo $ort_personel; ?>
  </div>
  <div style="margin-left:auto">
    <span class="roz" style="background:var(--bas-a);color:var(--bas)">%0-5 İyi</span>&nbsp;
    <span class="roz" style="background:#FEF0C7;color:#B45309">%5-15 Normal</span>&nbsp;
    <span class="roz" style="background:var(--hat-a);color:var(--hat)">%15+ Yüksek</span>
  </div>
</div>

<!-- ═══ AYRILAN PERSONEL LİSTESİ ═══ -->
<div class="kart">
  <div class="kart-ust">
    <div class="kart-bas">🚪 Bu Dönemde Ayrılan Personel (<?php echo $ayrilan; ?> kişi)</div>
    <button class="btn btn-b btn-sm" onclick="exportAyrilan()">↓ Excel</button>
  </div>
  <?php if (empty($ayrilan_liste)): ?>
  <div style="padding:30px;text-align:center;color:var(--m2)">Bu dönemde ayrılan personel yok</div>
  <?php else: ?>
  <table class="tablo" id="ayrilanTable">
    <thead>
      <tr>
        <th>Sicil</th>
        <th>Ad Soyad</th>
        <th>Departman</th>
        <th>Pozisyon</th>
        <th>İşe Giriş</th>
        <th>Çıkış Tarihi</th>
        <th>Kıdem</th>
        <th>Ayrılış Nedeni</th>
        <th>Profil</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($ayrilan_liste as $p):
      $kd_gun = $p['cikis_tarihi'] && $p['ise_baslama'] ? (int)((strtotime($p['cikis_tarihi'])-strtotime($p['ise_baslama']))/86400) : 0;
      $kd_yil = floor($kd_gun/365); $kd_ay = floor(($kd_gun%365)/30);
      $neden_renk = '#667085';
      if ($p['cikis_nedeni']==='İstifa') $neden_renk='#F79009';
      elseif ($p['cikis_nedeni']==='İşveren Feshi') $neden_renk='#F04438';
      elseif ($p['cikis_nedeni']==='Emeklilik') $neden_renk='#3B82F6';
    ?>
    <tr>
      <td style="font-weight:700;color:var(--t);font-size:12px"><?php echo htmlspecialchars($p['sicil_no']); ?></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:28px;height:28px;border-radius:50%;background:#FEE4E2;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#F04438;flex-shrink:0">
            <?php echo mb_strtoupper(mb_substr($p['ad'],0,1).mb_substr($p['soyad'],0,1)); ?>
          </div>
          <div style="font-weight:600"><?php echo htmlspecialchars($p['ad'].' '.$p['soyad']); ?></div>
        </div>
      </td>
      <td style="font-size:12px"><?php echo htmlspecialchars($p['dept_ad']??'—'); ?></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($p['pozisyon']??'—'); ?></td>
      <td style="font-size:12px;color:var(--m2)"><?php echo $p['ise_baslama']?date('d.m.Y',strtotime($p['ise_baslama'])):'—'; ?></td>
      <td style="font-size:12px;font-weight:600;color:var(--hat)"><?php echo $p['cikis_tarihi']?date('d.m.Y',strtotime($p['cikis_tarihi'])):'—'; ?></td>
      <td style="font-size:12px">
        <?php if ($kd_gun>0): ?><?php echo $kd_yil; ?>y <?php echo $kd_ay; ?>ay<?php else: ?>—<?php endif; ?>
      </td>
      <td>
        <?php if ($p['cikis_nedeni']): ?>
        <span class="roz" style="background:<?php echo $neden_renk; ?>15;color:<?php echo $neden_renk; ?>;font-size:11px"><?php echo htmlspecialchars($p['cikis_nedeni']); ?></span>
        <?php else: ?><span style="color:var(--m3);font-size:12px">—</span><?php endif; ?>
      </td>
      <td>
        <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personel-detay&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-b" title="Profili Görüntüle">👁</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<!-- ═══ YASAL BİLGİ KUTUSU ═══ -->
<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:var(--r-lg);padding:14px;margin-top:14px;display:flex;gap:12px">
  <span style="font-size:20px;flex-shrink:0">ℹ️</span>
  <div style="font-size:13px;color:#1D4ED8">
    <b>Yasal Saklama Zorunluluğu:</b> Ayrılan personel kayıtları arşivde tutulur ve silinemez.
    <br>SGK → 10 yıl &nbsp;|&nbsp; İş Sağlığı ve Güvenliği → 15 yıl &nbsp;|&nbsp; Vergi → 5 yıl
  </div>
</div>

</div>

<script>
function exportAyrilan() {
  // SheetJS varsa client-side XLSX
  if (typeof XLSX !== 'undefined') {
    var headers = ['Sicil','Ad Soyad','Departman','Pozisyon','Is Giris','Cikis','Kidem','Ayrilik Nedeni'];
    var rows = [headers];
    document.querySelectorAll('#ayrilanTable tbody tr').forEach(function(tr) {
      var cols = tr.querySelectorAll('td');
      if (cols.length < 6) return;
      rows.push([
        cols[0].innerText.trim(),
        cols[1].innerText.trim(),
        cols[2].innerText.trim(),
        cols[3].innerText.trim(),
        cols[4].innerText.trim(),
        cols[5].innerText.trim(),
        cols[6] ? cols[6].innerText.trim() : '',
        cols[7] ? cols[7].innerText.trim() : ''
      ]);
    });
    var ws = XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = headers.map(function(){ return {wch:20}; });
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Turnover');
    XLSX.writeFile(wb, 'turnover_<?php echo $yil; ?>.xlsx');
    return;
  }
  // Fallback: server-side export
  var base = typeof BASE_URL !== 'undefined' ? BASE_URL : '';
  var p = new URLSearchParams(window.location.search);
  window.location.href = base + '/bolumler/ik/ajax/excel-export.php?tip=turnover&yil=' + (p.get('yil') || '<?php echo $yil; ?>');
}
</script>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-turnover');});
</script>