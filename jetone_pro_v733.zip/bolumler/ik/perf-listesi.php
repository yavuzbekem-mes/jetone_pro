<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();

try {
    $kayitlar = $db->query("SELECT pd.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no, d.ad dept_adi
        FROM performans_degerlendirme pd
        JOIN personeller p ON pd.personel_id=p.id
        LEFT JOIN departmanlar d ON p.departman_id=d.id
        ORDER BY pd.degerlendirme_tarihi DESC")->fetchAll();
} catch (Throwable $e) { $kayitlar = []; }

$toplam = count($kayitlar);
$ort = $toplam > 0 ? round(array_sum(array_column($kayitlar,'genel_toplam')) / $toplam, 1) : 0;

function puan_sinif($p) {
    if ($p >= 85) return ['#D1FAE5','#065F46','Mükemmel'];
    if ($p >= 70) return ['#DBEAFE','#1E40AF','İyi'];
    if ($p >= 50) return ['#FEF3C7','#92400E','Gelişmeli'];
    return ['#FEE2E2','#991B1B','Yetersiz'];
}
?>
<div class="s-bar">
  <div><h1 class="s-bas">📊 Performans Değerlendirmeleri</h1><div class="s-yol">İK / <b>Performans</b></div></div>
  <a href="?sayfa=ik-perf-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni Değerlendirme</a>

  <button onclick="dtExcelIndir('tbl-perf_listesi','Perf_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>
<div class="s-body">
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Toplam Değerlendirme</div><div style="font-size:28px;font-weight:900;color:var(--t)"><?php echo $toplam; ?></div></div>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Genel Ortalama</div><div style="font-size:28px;font-weight:900;color:#F97316"><?php echo $ort; ?> / 100</div></div>
  <div class="kart" style="padding:14px;text-align:center"><div style="font-size:11px;color:var(--m2);text-transform:uppercase;font-weight:700;margin-bottom:4px">Memnuniyet</div><div style="font-size:28px;font-weight:900;color:#059669">%<?php echo $ort; ?></div></div>
</div>
<?php if (!empty($e)): ?>
<div class="kart" style="padding:20px;text-align:center;color:#92400E;background:#FEF3C7;margin-bottom:14px">
  ⚠️ <strong>Tablo oluşturulmamış.</strong> Lütfen önce <code>tablo_guncelle.php</code> çalıştırın.
</div>
<?php endif; ?>
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Tüm Değerlendirmeler</div></div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-perf_listesi" style="width:100%">
    <thead><tr>
      <th>Personel</th><th>Bölüm</th><th>Değerlendiren</th><th>Tarih</th>
      <th style="text-align:center">Kişisel</th><th style="text-align:center">Davranış</th><th style="text-align:center">Teknik</th>
      <th style="text-align:center">Toplam</th><th style="text-align:center">Durum</th><th style="text-align:center">İşlem</th>
    </tr></thead>
    <tbody>
    <?php if (empty($kayitlar)): ?>
    <tr><td colspan="10" style="text-align:center;padding:40px;color:var(--m2)">Henüz değerlendirme yok.</td></tr>
    <?php else: foreach ($kayitlar as $k):
      $pc = puan_sinif($k['genel_toplam']??0);
    ?>
    <tr style="cursor:pointer" onclick="location.href='?sayfa=ik-perf-detay&id=<?php echo $k['id']; ?>'">
      <td><div style="font-weight:700"><?php echo htmlspecialchars($k['per_adi']); ?></div><div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($k['sicil_no']??''); ?></div></td>
      <td style="font-size:13px"><?php echo htmlspecialchars($k['dept_adi']??'—'); ?></td>
      <td style="font-size:13px"><?php echo htmlspecialchars($k['degerlendiren']??'—'); ?></td>
      <td style="font-size:13px"><?php echo $k['degerlendirme_tarihi']?date('d.m.Y',strtotime($k['degerlendirme_tarihi'])):'—'; ?></td>
      <td style="text-align:center;font-weight:700"><?php echo $k['toplam_k']??0; ?>/32</td>
      <td style="text-align:center;font-weight:700"><?php echo $k['toplam_d']??0; ?>/44</td>
      <td style="text-align:center;font-weight:700"><?php echo $k['toplam_t']??0; ?>/24</td>
      <td style="text-align:center;font-size:16px;font-weight:900;color:<?php echo $pc[1]; ?>"><?php echo $k['genel_toplam']??0; ?></td>
      <td style="text-align:center"><span style="background:<?php echo $pc[0]; ?>;color:<?php echo $pc[1]; ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px"><?php echo $pc[2]; ?></span></td>
      <td style="text-align:center" onclick="event.stopPropagation()">
        <a href="?sayfa=ik-perf-form&id=<?php echo $k['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none;margin-right:4px">✏️</a>
        <button onclick="sil(<?php echo $k['id']; ?>)" style="width:28px;height:28px;background:#FEE2E2;color:#EF4444;border:none;border-radius:6px;cursor:pointer;font-size:12px">🗑</button>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
</div>
</div>
<script>
function sil(id) {
    if (!confirm('Silinsin mi?')) return;
    var fd=new FormData(); fd.append('id',id);
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/perf-sil.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){if(r.ok)location.reload();else alert(r.hata);});
}
</script>
