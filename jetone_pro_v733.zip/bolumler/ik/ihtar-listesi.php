<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

try {
    $kayitlar = $db->query(
        "SELECT it.*, CONCAT(p.ad,' ',p.soyad) per_adi, p.sicil_no, d.ad dept_adi, p.kadro
         FROM ihtar_tutanaklar it
         JOIN personeller p ON it.personel_id = p.id
         LEFT JOIN departmanlar d ON p.departman_id = d.id
         ORDER BY it.ihtar_tarihi DESC"
    )->fetchAll();
} catch (Throwable $e) { $kayitlar = []; }

// Analiz
$toplam = count($kayitlar);
$bekleyen = count(array_filter($kayitlar, function($k){ return $k['durum']==='bekliyor'; }));
$savunma = count(array_filter($kayitlar, function($k){ return $k['durum']==='savunma_alindi'; }));
$kapali  = count(array_filter($kayitlar, function($k){ return $k['durum']==='kapatildi'; }));

$durum_cfg = [
    'bekliyor'       => ['#FEF3C7','#92400E','⏳ Bekliyor'],
    'savunma_alindi' => ['#DBEAFE','#1E40AF','📝 Savunma Alındı'],
    'kapatildi'      => ['#D1FAE5','#065F46','✅ Kapatıldı'],
];

// Bu yıl aylık dağılım
$aylik = [];
$buYil = date('Y');
foreach ($kayitlar as $k) {
    if (substr($k['ihtar_tarihi'],0,4) === $buYil) {
        $ay = (int)substr($k['ihtar_tarihi'],5,2);
        $aylik[$ay] = ($aylik[$ay] ?? 0) + 1;
    }
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">⚠️ İhtar Tutanakları</h1>
    <div class="s-yol">İnsan Kaynakları / <b>Disiplin</b></div>
  </div>
  <a href="?sayfa=ik-ihtar-form" style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;font-size:13px">+ Yeni İhtar</a>

  <button onclick="dtExcelIndir('tbl-ihtar_listesi','Ihtar_Listesi')" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px">📊 Excel</button>
</div>

<div class="s-body">

<!-- Özet -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
  <?php foreach ([
    [$toplam,'📋','Toplam','var(--t)'],
    [$bekleyen,'⏳','Savunma Bekliyor','#D97706'],
    [$savunma,'📝','Savunma Alındı','#2563EB'],
    [$kapali,'✅','Kapatıldı','#059669'],
  ] as [$say,$ic,$et,$rk]): ?>
  <div class="kart" style="padding:14px;text-align:center">
    <div style="font-size:22px"><?php echo $ic; ?></div>
    <div style="font-size:28px;font-weight:900;color:<?php echo $rk; ?>"><?php echo $say; ?></div>
    <div style="font-size:12px;color:var(--m2)"><?php echo $et; ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Aylık dağılım -->
<?php if (!empty($aylik)): ?>
<div class="kart" style="padding:16px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:14px"><?php echo $buYil; ?> Yılı Aylık Dağılım</div>
  <div style="display:flex;align-items:flex-end;gap:6px;height:100px">
    <?php $ay_adlari=['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
    $max_ay = max($aylik) ?: 1;
    for ($i=1;$i<=12;$i++):
      $say = $aylik[$i] ?? 0;
      $h = $say > 0 ? max(14, (int)(($say/$max_ay)*80)) : 0;
    ?>
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">
      <?php if ($say): ?><div style="font-size:10px;font-weight:700;color:var(--t)"><?php echo $say; ?></div><?php endif; ?>
      <div style="width:100%;background:<?php echo $say?'#FEF3C7':'var(--bg)'; ?>;border-radius:4px 4px 0 0;height:<?php echo $h ?: 4; ?>px;<?php echo $say?'border:1px solid #F59E0B':''; ?>"></div>
      <div style="font-size:9px;color:var(--m2)"><?php echo $ay_adlari[$i]; ?></div>
    </div>
    <?php endfor; ?>
  </div>
</div>
<?php endif; ?>

<!-- Liste -->
<div class="kart" style="overflow:hidden">
  <div class="kart-ust"><div class="kart-bas">Tüm Kayıtlar (<?php echo $toplam; ?>)</div></div>
  <div style="overflow-x:auto">
  <table class="tablo" id="tbl-ihtar_listesi" style="width:100%">
    <thead><tr>
      <th>Tutanak No</th><th>Personel</th><th>Bölüm</th><th>İhtar Tarihi</th>
      <th>Tebliğ Eden</th><th style="text-align:center">Durum</th><th style="text-align:center">İşlem</th>
    </tr></thead>
    <tbody>
      <?php if (empty($kayitlar)): ?>
      <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--m2)">Henüz ihtar kaydı yok.</td></tr>
      <?php else: foreach ($kayitlar as $k):
        $dc = $durum_cfg[$k['durum']] ?? ['#F3F4F6','#374151',$k['durum']];
      ?>
      <tr style="cursor:pointer" onclick="location.href='?sayfa=ik-ihtar-detay&id=<?php echo $k['id']; ?>'">
        <td style="font-weight:800;color:var(--t);font-family:monospace"><?php echo htmlspecialchars($k['tutanak_no']); ?></td>
        <td>
          <div style="font-weight:700"><?php echo htmlspecialchars($k['per_adi']); ?></div>
          <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($k['sicil_no']??''); ?></div>
        </td>
        <td style="font-size:13px"><?php echo htmlspecialchars($k['dept_adi']??'—'); ?></td>
        <td style="font-size:13px"><?php echo date('d.m.Y',strtotime($k['ihtar_tarihi'])); ?></td>
        <td style="font-size:13px"><?php echo htmlspecialchars($k['teblig_eden']??'—'); ?></td>
        <td style="text-align:center">
          <span style="background:<?php echo $dc[0]; ?>;color:<?php echo $dc[1]; ?>;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px"><?php echo $dc[2]; ?></span>
        </td>
        <td style="text-align:center" onclick="event.stopPropagation()">
          <a href="?sayfa=ik-ihtar-form&id=<?php echo $k['id']; ?>" style="display:inline-flex;width:28px;height:28px;align-items:center;justify-content:center;background:#FEF3E8;color:#B45309;border-radius:6px;text-decoration:none;margin-right:4px" title="Düzenle">✏️</a>
          <button onclick="sil(<?php echo $k['id']; ?>,this)" style="width:28px;height:28px;background:#FEE2E2;color:#EF4444;border:none;border-radius:6px;cursor:pointer;font-size:14px" title="Sil">🗑</button>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
</div>
</div>

<script>
function sil(id, btn) {
    if (!confirm('Bu ihtar tutanağı silinsin mi?')) return;
    var fd = new FormData(); fd.append('id', id);
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/ihtar-sil.php', {method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(function(r){
        if (r.ok) location.reload(); else alert(r.hata);
    });
}
</script>
