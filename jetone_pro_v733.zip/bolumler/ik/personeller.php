<?php
/**
 * İK — Personeller
 * bolumler/ik/personeller.php
 */
if (!Auth::yetkiKontrol('ik', 'goruntule')) {
    echo '<div class="s-bar"><div class="s-bas">Erişim Reddedildi</div></div><div class="s-body"><div class="kart" style="padding:30px;text-align:center;color:var(--m2)">⛔ Bu sayfayı görüntüleme yetkiniz yok.</div></div>';
    return;
}
// Filtre
$arama     = trim($_GET['arama']    ?? '');
$departman = (int)($_GET['departman'] ?? 0);
$durum     = $_GET['durum']          ?? '';

$where = ['1=1'];
$params = [];
if ($arama) { $where[] = "(p.ad LIKE ? OR p.soyad LIKE ? OR p.sicil_no LIKE ? OR p.email LIKE ?)"; $q = "%$arama%"; $params = array_merge($params, [$q,$q,$q,$q]); }
if ($departman) { $where[] = 'p.departman_id=?'; $params[] = $departman; }
if ($durum)     { $where[] = 'p.durum=?';        $params[] = $durum; }

$where_sql = implode(' AND ', $where);

try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM personeller p WHERE $where_sql");
    $stmt->execute($params);
    $toplam = (int)$stmt->fetchColumn();

    $stmt2 = $db->prepare("
        SELECT p.*, d.ad departman_adi
        FROM personeller p
        LEFT JOIN departmanlar d ON p.departman_id = d.id
        WHERE $where_sql
        ORDER BY p.ad, p.soyad
    ");
    $stmt2->execute($params);
    $personeller = $stmt2->fetchAll();

    $departmanlar = $db->query("SELECT id, ad FROM departmanlar WHERE durum=1 ORDER BY ad")->fetchAll();
} catch (Throwable $e) {
    $personeller = []; $toplam = 0; $toplam_sayfa = 1; $departmanlar = [];
}
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas">Personeller</h1>
    <div class="s-yol">İnsan Kaynakları / <b>Personeller</b></div>
  </div>
  <div style="display:flex;gap:8px;align-items:center">
    <div id="dt-toolbar-dt-personeller" style="display:inline-flex;align-items:center;gap:6px"></div>
    <button onclick="dtExcelIndir('dt-personeller','Personeller',{tip:'personel'})" style="background:#217346;color:#fff;border:none;padding:9px 14px;border-radius:8px;font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;display:inline-flex;align-items:center;gap:5px">📊 Excel</button>
    <?php if (Auth::yetkiKontrol('ik','ekle')): ?>
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-ekle" class="btn btn-t">+ Personel Ekle</a>
    <?php endif; ?>
  </div>
</div>

<div class="s-body">
  <!-- Filtreler -->
  <div class="kart" style="margin-bottom:14px;padding:12px 16px">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <input type="hidden" name="sayfa" value="ik-personeller">
      <input type="text" name="arama" class="form-alan" style="width:220px"
             placeholder="Ad, soyad, sicil veya email..." value="<?php echo htmlspecialchars($arama); ?>">
      <select name="departman" class="form-alan" style="width:180px">
        <option value="">Tüm Departmanlar</option>
        <?php foreach ($departmanlar as $d): ?>
        <option value="<?php echo $d['id']; ?>" <?php echo $departman==$d['id']?'selected':''; ?>><?php echo htmlspecialchars($d['ad']); ?></option>
        <?php endforeach; ?>
      </select>
      <select name="durum" class="form-alan" style="width:140px">
        <option value="">Tüm Durumlar</option>
        <option value="aktif"   <?php echo $durum==='aktif'?'selected':''; ?>>✓ Aktif</option>
        <option value="izinli"  <?php echo $durum==='izinli'?'selected':''; ?>>🏖 İzinli</option>
        <option value="ayrıldı" <?php echo $durum==='ayrıldı'?'selected':''; ?>>✗ Ayrıldı</option>
      </select>
      <button type="submit" class="btn btn-t">🔍 Filtrele</button>
      <?php if ($arama || $departman || $durum): ?>
      <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personeller" class="btn btn-b">✕ Temizle</a>
      <?php endif; ?>
      <span style="margin-left:auto;font-size:12px;color:var(--m2)"><?php echo number_format($toplam); ?> kayıt</span>
    </form>
  </div>

  <!-- Tablo -->
  <div class="kart" style="overflow:hidden">
    <div style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 260px)">
    <table class="tablo" id="dt-personeller">
      <thead style="position:sticky;top:0;z-index:2">
        <tr>
          <th>#</th>
          <th>Ad Soyad</th>
          <th>Sicil No</th>
          <th>Departman</th>
          <th>Pozisyon</th>
          <th>Telefon</th>
          <th>İşe Başlama</th>
          <th>Durum</th>
          <th>İşlemler</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($personeller)): ?>
        <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--m2)">
          <?php echo $arama ? "\"$arama\" için sonuç bulunamadı." : 'Henüz personel kaydı yok.'; ?>
        </td></tr>
        <?php else: foreach ($personeller as $i => $p):
          $durumRenk = ['aktif'=>['#D1FADF','#0A8F4E'],'izinli'=>['#FEF0C7','#B45309'],'ayrıldı'=>['#FEE4E2','#F04438']];
          $dr = $durumRenk[$p['durum']] ?? ['#F4F5F7','#667085'];
        ?>
        <tr>
          <td style="color:var(--m3);font-size:12px"><?php echo $i + 1; ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <?php if ($p['foto']): ?>
              <img src="<?php echo BASE_URL; ?>/bolumler/ik/resimler/<?php echo htmlspecialchars($p['foto']); ?>"
                   style="width:32px;height:32px;border-radius:50%;object-fit:cover" alt="">
              <?php else: ?>
              <div style="width:32px;height:32px;border-radius:50%;background:var(--t-a);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:var(--t);flex-shrink:0">
                <?php echo mb_strtoupper(mb_substr($p['ad'],0,1) . mb_substr($p['soyad'],0,1)); ?>
              </div>
              <?php endif; ?>
              <div>
                <div style="font-weight:700"><?php echo htmlspecialchars($p['ad'] . ' ' . $p['soyad']); ?></div>
                <div style="font-size:11px;color:var(--m2)"><?php echo htmlspecialchars($p['email'] ?? '—'); ?></div>
              </div>
            </div>
          </td>
          <td style="font-size:12px;font-weight:600;color:var(--t)"><?php echo htmlspecialchars($p['sicil_no']); ?></td>
          <td style="font-size:13px"><?php echo htmlspecialchars($p['departman_adi'] ?? '—'); ?></td>
          <td style="font-size:13px"><?php echo htmlspecialchars($p['pozisyon'] ?? '—'); ?></td>
          <td style="font-size:12px;color:var(--m2)"><?php echo htmlspecialchars($p['telefon'] ?? '—'); ?></td>
          <td style="font-size:12px;color:var(--m2)"><?php echo $p['ise_baslama'] ? date('d.m.Y', strtotime($p['ise_baslama'])) : '—'; ?></td>
          <td><span class="roz" style="background:<?php echo $dr[0]; ?>;color:<?php echo $dr[1]; ?>"><?php echo ucfirst($p['durum']); ?></span></td>
          <td>
            <div style="display:flex;gap:4px">
              <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personel-detay&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-b" title="Detay">👁</a>
              <?php if (Auth::yetkiKontrol('ik','duzenle')): ?>
              <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=ik-personel-duzenle&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-b" title="Düzenle">✏️</a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
    </div>

  </div>
</div>

<script>
function personelExport() {
  var p=new URLSearchParams(window.location.search);
  var dept=p.get('departman')||'0';
  var base=typeof BASE_URL!='undefined'?BASE_URL:'';
  window.location.href=base+'/bolumler/ik/ajax/excel-export.php?tip=personel&dept='+dept;
}

function excelIndir(tip){
  const p=new URLSearchParams(window.location.search);
  const dept=p.get('departman')||'0';
  window.location.href=(typeof BASE_URL!=='undefined'?BASE_URL:'')+'/bolumler/ik/ajax/excel-export.php?tip='+tip+'&dept='+dept;
}
</script>
<script>
document.addEventListener('DOMContentLoaded',function(){dtInit('dt-personeller');});
</script>