<?php
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
Auth::zorunlu();
$user = Auth::kullanici();

$id = (int)($_GET['id'] ?? 0);
$d = null;
if ($id) {
    try {
        $q = $db->prepare("SELECT * FROM performans_degerlendirme WHERE id=? LIMIT 1");
        $q->execute([$id]); $d = $q->fetch();
    } catch (Throwable $e) { $d = null; }
}
try { $firma_adi = $db->query("SELECT deger FROM ayarlar_kv WHERE anahtar='firma_adi' LIMIT 1")->fetchColumn() ?: 'Poliza'; } catch (Throwable $e) { $firma_adi = 'Poliza'; }
try {
    $personeller = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, p.sicil_no, p.kadro, p.unvan, dept.ad dept_adi, p.taseron_firma FROM personeller p LEFT JOIN departmanlar dept ON p.departman_id=dept.id WHERE p.durum='aktif' ORDER BY p.ad")->fetchAll();
} catch (Throwable $e) {
    $personeller = $db->query("SELECT p.id, CONCAT(p.ad,' ',p.soyad) ad_soyad, p.sicil_no, p.kadro, p.unvan, dept.ad dept_adi, NULL as taseron_firma FROM personeller p LEFT JOIN departmanlar dept ON p.departman_id=dept.id WHERE p.durum='aktif' ORDER BY p.ad")->fetchAll();
}
$v = function($k,$def=null) use ($d) { return $d[$k] ?? $def; };

$bolumler = [
    'K' => [
        'baslik' => '1 — KİŞİSEL KRİTERLER',
        'renk'   => '#3B82F6',
        'kriterler' => [
            'k11' => '1.1  İşyeri Kurallarına Uyum Sağlama ve İşyeri Menfaatlerini Koruma',
            'k12' => '1.2  Öğrenme ve Kendini Geliştirme',
            'k13' => '1.3  Kurumsal Kültür Ve Aidiyet Duygusu',
            'k14' => '1.4  İnisiyatif Sahibi Olma',
            'k15' => '1.5  İş Arkadaşları ile İlişkisi ve Ekip Çalışmasına Uyumu',
            'k16' => '1.6  İşe Dönük Merak ve İlgi',
            'k17' => '1.7  Kişisel Bakım ve Temizlik',
            'k18' => '1.8  İşçi Sağlığı ve İş Güvenliği Kurallarına Uyumu',
        ],
        'toplam_key' => 'toplam_k',
    ],
    'D' => [
        'baslik' => '2 — DAVRANIŞSAL KRİTERLER',
        'renk'   => '#10B981',
        'kriterler' => [
            'd21'  => '2.1   Yeni Sistem ve İş Değişikliklerine Uyum Sağlama',
            'd22'  => '2.2   Güvenilirlik ve Ahlaki Durum',
            'd23'  => '2.3   Sorumluluk Alma',
            'd24'  => '2.4   Kendini Geliştirme',
            'd25'  => '2.5   İletişim Becerisi ve Etki Yaratmak',
            'd26'  => '2.6   Yeni Fikirler Üretme',
            'd27'  => '2.7   Problem Çözme ve Analiz Yeteneği',
            'd28'  => '2.8   İşe Devam ve Mesai Saatine Uyum',
            'd29'  => '2.9   Strese Karşı Dayanıklılık',
            'd210' => '2.10  Sosyal İlişkiler',
            'd211' => '2.11  Konsantrasyon ve İşe Odaklanma',
        ],
        'toplam_key' => 'toplam_d',
    ],
    'T' => [
        'baslik' => '3 — TEKNİK KRİTERLER',
        'renk'   => '#8B5CF6',
        'kriterler' => [
            't31' => '3.1  Mesleki Bilgi Birikimi ve İş Tecrübesi',
            't32' => '3.2  Makine, Ekipman ve Donanımı Koruması',
            't33' => '3.3  İş Disiplini ve Düzenli Çalışma',
            't34' => '3.4  Farklı İşlerde Çalışabilme Becerisi',
            't35' => '3.5  İşi Doğru, Eksiksiz ve Tam Zamanında Yapma',
            't36' => '3.6  İşin Kalite ve Verimini Arttırmaya Yönelik Çalışma',
        ],
        'toplam_key' => 'toplam_t',
    ],
];
?>
<div class="s-bar">
  <div>
    <h1 class="s-bas"><?php echo $id ? 'Değerlendirme Düzenle' : 'Yeni Performans Değerlendirmesi'; ?></h1>
    <div class="s-yol">İK / <a href="?sayfa=ik-perf-listesi" style="color:var(--t);text-decoration:none">Değerlendirmeler</a></div>
  </div>
  <a href="?sayfa=ik-perf-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:9px 14px;border-radius:8px;font-weight:600;text-decoration:none;font-size:13px">← Geri</a>
</div>

<div class="s-body">
<form id="perfForm">
<?php if ($id): ?><input type="hidden" name="id" value="<?php echo $id; ?>"><?php endif; ?>

<!-- Çalışan Bilgileri -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">👤 Çalışan Bilgileri</div>
  <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:12px">
    <div>
      <label class="form-etiket">Çalışan Adı Soyadı <span style="color:#EF4444">*</span></label>
      <select class="form-alan" name="personel_id" id="perSec" onchange="perDoldur(this)" required>
        <option value="">— Personel Seçiniz —</option>
        <?php foreach ($personeller as $p): ?>
        <option value="<?php echo $p['id']; ?>"
          data-firma="<?php echo htmlspecialchars(!empty($p['taseron_firma']) ? $p['taseron_firma'] : ($firma_adi ?: 'Poliza')); ?>"
          data-dept="<?php echo htmlspecialchars($p['dept_adi']??''); ?>"
          data-unvan="<?php echo htmlspecialchars($p['unvan']??''); ?>"
          <?php echo ($d['personel_id']??'')==$p['id']?'selected':''; ?>>
          <?php echo htmlspecialchars($p['ad_soyad'].' ('.$p['sicil_no'].')'); ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div><label class="form-etiket">Firma</label><input class="form-alan" id="perFirma" readonly style="background:var(--bg)" value="<?php echo htmlspecialchars($v('firma_adi','')); ?>"></div>
    <div><label class="form-etiket">Bölüm</label><input class="form-alan" id="perBolum" readonly style="background:var(--bg)" value="<?php echo htmlspecialchars($v('bolum','')); ?>"></div>
    <div><label class="form-etiket">Ünvan</label><input class="form-alan" id="perUnvan" readonly style="background:var(--bg)" value="<?php echo htmlspecialchars($v('unvan','')); ?>"></div>
  </div>
</div>

<!-- Değerlendirenin Bilgileri -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:16px">🧑‍💼 Değerlendirenin Bilgileri</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px">
    <div style="grid-column:1/3">
      <label class="form-etiket">Adı Soyadı <span style="color:#EF4444">*</span></label>
      <input class="form-alan" name="degerlendiren" value="<?php echo htmlspecialchars($v('degerlendiren','')); ?>" placeholder="Değerlendirenin adı soyadı" required>
    </div>
    <div><label class="form-etiket">Bölümü</label><input class="form-alan" name="deg_bolum" value="<?php echo htmlspecialchars($v('deg_bolum','')); ?>"></div>
    <div><label class="form-etiket">Ünvanı</label><input class="form-alan" name="deg_unvan" value="<?php echo htmlspecialchars($v('deg_unvan','')); ?>"></div>
  </div>
</div>

<!-- Puan Başlıkları Açıklaması -->
<div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:10px;padding:10px 16px;margin-bottom:14px;display:flex;gap:16px;align-items:center;flex-wrap:wrap">
  <span style="font-size:12px;font-weight:700;color:var(--m2)">PUANLAMA:</span>
  <?php foreach ([[1,'Yetersiz','#FEE2E2','#991B1B'],[2,'Gelişmeli','#FEF3C7','#92400E'],[3,'Yeterli','#DBEAFE','#1E40AF'],[4,'Mükemmel','#D1FAE5','#065F46']] as [$p,$et,$bg,$rk]): ?>
  <span style="background:<?php echo $bg; ?>;color:<?php echo $rk; ?>;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px"><?php echo $p.' — '.$et; ?></span>
  <?php endforeach; ?>
</div>

<?php foreach ($bolumler as $harf => $bolum): ?>
<!-- Bölüm <?php echo $harf; ?> -->
<div class="kart" style="overflow:hidden;margin-bottom:14px">
  <div style="padding:12px 16px;font-size:14px;font-weight:800;color:#fff;background:<?php echo $bolum['renk']; ?>;display:flex;justify-content:space-between;align-items:center">
    <span><?php echo $bolum['baslik']; ?></span>
    <span style="font-size:13px;opacity:.9">Toplam: <span id="top_<?php echo $bolum['toplam_key']; ?>">0</span> / <?php echo count($bolum['kriterler'])*4; ?></span>
  </div>
  <table style="width:100%;border-collapse:collapse">
    <thead>
      <tr style="background:#F9FAFB;font-size:11px;font-weight:700;color:var(--m2)">
        <th style="padding:8px 16px;text-align:left;border-bottom:1px solid var(--kenar)">No</th>
        <th style="padding:8px 16px;text-align:left;border-bottom:1px solid var(--kenar)">KRİTER</th>
        <?php foreach ([1=>'Yetersiz',2=>'Gelişmeli',3=>'Yeterli',4=>'Mükemmel'] as $p=>$pt): ?>
        <th style="padding:8px 12px;text-align:center;border-bottom:1px solid var(--kenar);width:80px;color:<?php echo ['','#991B1B','#92400E','#1E40AF','#065F46'][$p]; ?>"><?php echo $p.'<br>'.$pt; ?></th>
        <?php endforeach; ?>
        <th style="padding:8px 16px;text-align:center;border-bottom:1px solid var(--kenar);width:70px;color:<?php echo $bolum['renk']; ?>">PUAN</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($bolum['kriterler'] as $key => $kriter_adi): ?>
      <tr style="border-bottom:1px solid var(--kenar)">
        <td style="padding:10px 16px;font-size:11px;font-weight:700;color:var(--m2);white-space:nowrap"><?php echo substr($kriter_adi,0,strpos($kriter_adi,' ',3)); ?></td>
        <td style="padding:10px 16px;font-size:13px"><?php echo htmlspecialchars(trim(substr($kriter_adi,strpos($kriter_adi,' ',3)))); ?></td>
        <?php $mevcut = (int)($v($key,0)); foreach ([1,2,3,4] as $p): 
          $renkler = [1=>['#FEE2E2','#991B1B'],2=>['#FEF3C7','#92400E'],3=>['#DBEAFE','#1E40AF'],4=>['#D1FAE5','#065F46']];
          $secili = $mevcut === $p;
        ?>
        <td style="padding:8px 12px;text-align:center">
          <label style="display:inline-flex;width:36px;height:36px;align-items:center;justify-content:center;border-radius:8px;border:2px solid <?php echo $secili?$renkler[$p][1]:'var(--kenar)'; ?>;background:<?php echo $secili?$renkler[$p][0]:'var(--bg)'; ?>;cursor:pointer;transition:all .15s;font-size:14px;font-weight:700;color:<?php echo $secili?$renkler[$p][1]:'var(--m2)'; ?>" id="lbl_<?php echo $key.'_'.$p; ?>">
            <input type="radio" name="<?php echo $key; ?>" value="<?php echo $p; ?>" <?php echo $secili?'checked':''; ?> onchange="puanSec('<?php echo $key; ?>',<?php echo $p; ?>,this)" style="display:none">
            <?php echo $p; ?>
          </label>
        </td>
        <?php endforeach; ?>
        <td style="padding:8px 16px;text-align:center;font-size:14px;font-weight:800" id="puan_<?php echo $key; ?>"><?php echo $mevcut ?: '—'; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr style="background:<?php echo $bolum['renk']; ?>20">
        <td colspan="6" style="padding:10px 16px;font-size:13px;font-weight:800;color:<?php echo $bolum['renk']; ?>">TOPLAM</td>
        <td style="padding:10px 16px;text-align:center;font-size:15px;font-weight:900;color:<?php echo $bolum['renk']; ?>" id="top_<?php echo $bolum['toplam_key']; ?>2">
          <?php echo array_sum(array_map(function($k) use ($v){ return (int)($v($k,0)); }, array_keys($bolum['kriterler']))); ?>
        </td>
      </tr>
    </tfoot>
  </table>
</div>
<?php endforeach; ?>

<!-- Genel Toplam -->
<div class="kart" style="padding:18px;margin-bottom:14px">
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;text-align:center">
    <?php foreach (['toplam_k'=>['#3B82F6','Kişisel (maks 32)'],'toplam_d'=>['#10B981','Davranışsal (maks 44)'],'toplam_t'=>['#8B5CF6','Teknik (maks 24)']] as $k=>[$rk,$et]): ?>
    <div style="background:var(--bg);border-radius:10px;padding:12px;border:1.5px solid var(--kenar)">
      <div style="font-size:11px;color:var(--m2);margin-bottom:4px"><?php echo $et; ?></div>
      <div style="font-size:24px;font-weight:900;color:<?php echo $rk; ?>" id="gs_<?php echo $k; ?>"><?php echo $v($k,0)?:0; ?></div>
    </div>
    <?php endforeach; ?>
    <div style="background:linear-gradient(135deg,#F97316,#EA6800);border-radius:10px;padding:12px;text-align:center">
      <div style="font-size:11px;color:rgba(255,255,255,.8);margin-bottom:4px">GENEL TOPLAM (maks 100)</div>
      <div style="font-size:28px;font-weight:900;color:#fff" id="gs_genel">
        <?php $gt=($v('toplam_k',0)+$v('toplam_d',0)+$v('toplam_t',0)); echo $gt?:0; ?>
      </div>
    </div>
  </div>
</div>

<!-- Hazırlayan / Onaylayan / Tarih -->
<div class="kart" style="padding:20px;margin-bottom:14px">
  <div class="kart-bas" style="margin-bottom:14px">🖊 İmzalar ve Tarih</div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
    <div><label class="form-etiket">Hazırlayan (İK Sorumlusu)</label><input class="form-alan" name="hazirlayan" value="<?php echo htmlspecialchars($v('hazirlayan','')); ?>"></div>
    <div><label class="form-etiket">Onaylayan (Genel Müdür)</label><input class="form-alan" name="onaylayan" value="<?php echo htmlspecialchars($v('onaylayan','')); ?>"></div>
    <div><label class="form-etiket">Değerlendirme Tarihi <span style="color:#EF4444">*</span></label><input type="date" class="form-alan" name="degerlendirme_tarihi" value="<?php echo $v('degerlendirme_tarihi',date('Y-m-d')); ?>" required></div>
  </div>
</div>

<div style="display:flex;gap:10px;justify-content:flex-end">
  <a href="?sayfa=ik-perf-listesi" style="background:var(--bg);color:var(--m);border:1.5px solid var(--kenar);padding:12px 24px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px">Temizle</a>
  <button type="button" onclick="kaydet()" id="kaydetBtn"
    style="background:linear-gradient(135deg,#F97316,#EA6800);color:#fff;border:none;padding:12px 28px;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit">
    💾 Kaydet
  </button>
</div>
</form>
</div>

<script>
var PUAN_RENK = {
    1:['#FEE2E2','#991B1B'],
    2:['#FEF3C7','#92400E'],
    3:['#DBEAFE','#1E40AF'],
    4:['#D1FAE5','#065F46']
};
var BOLUM_K = ['k11','k12','k13','k14','k15','k16','k17','k18'];
var BOLUM_D = ['d21','d22','d23','d24','d25','d26','d27','d28','d29','d210','d211'];
var BOLUM_T = ['t31','t32','t33','t34','t35','t36'];

function perDoldur(sel) {
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('perFirma').value = opt.dataset.firma||'Poliza';
    document.getElementById('perBolum').value = opt.dataset.dept||'';
    document.getElementById('perUnvan').value = opt.dataset.unvan||'';
}

function puanSec(key, puan, inp) {
    // Tüm radio label'larını sıfırla
    for (var p=1;p<=4;p++) {
        var lbl = document.getElementById('lbl_'+key+'_'+p);
        if (!lbl) continue;
        if (p === puan) {
            lbl.style.background = PUAN_RENK[p][0];
            lbl.style.borderColor = PUAN_RENK[p][1];
            lbl.style.color = PUAN_RENK[p][1];
            lbl.style.transform = 'scale(1.1)';
        } else {
            lbl.style.background = 'var(--bg)';
            lbl.style.borderColor = 'var(--kenar)';
            lbl.style.color = 'var(--m2)';
            lbl.style.transform = 'scale(1)';
        }
    }
    var puanEl = document.getElementById('puan_'+key);
    if (puanEl) puanEl.textContent = puan;
    hesapla();
}

function topla(keys) {
    return keys.reduce(function(s,k){
        var el = document.querySelector('input[name="'+k+'"]:checked');
        return s + (el ? parseInt(el.value)||0 : 0);
    },0);
}

function hesapla() {
    var tk = topla(BOLUM_K);
    var td = topla(BOLUM_D);
    var tt = topla(BOLUM_T);
    var gen = tk+td+tt;
    ['gs_toplam_k','top_toplam_k','top_toplam_k2'].forEach(function(id){
        var el=document.getElementById(id); if(el) el.textContent=tk;
    });
    ['gs_toplam_d','top_toplam_d','top_toplam_d2'].forEach(function(id){
        var el=document.getElementById(id); if(el) el.textContent=td;
    });
    ['gs_toplam_t','top_toplam_t','top_toplam_t2'].forEach(function(id){
        var el=document.getElementById(id); if(el) el.textContent=tt;
    });
    var gEl = document.getElementById('gs_genel');
    if (gEl) {
        gEl.textContent = gen;
        if (gen >= 80) gEl.style.color='#fff';
        else if (gen >= 60) gEl.style.color='#FEF9C3';
        else gEl.style.color='#FEE2E2';
    }
}

function kaydet() {
    // Tüm kriterler doldurulmuş mu?
    var tumKriter = BOLUM_K.concat(BOLUM_D).concat(BOLUM_T);
    var bos = tumKriter.filter(function(k){
        return !document.querySelector('input[name="'+k+'"]:checked');
    });
    if (bos.length > 0) {
        if (!confirm(bos.length+' kriter boş bırakıldı. Yine de kaydetmek ister misiniz?')) return;
    }
    var btn = document.getElementById('kaydetBtn');
    btn.disabled=true; btn.textContent='Kaydediliyor...';
    fetch('<?php echo BASE_URL; ?>/bolumler/ik/ajax/perf-kaydet.php',{
        method:'POST',body:new FormData(document.getElementById('perfForm')),credentials:'same-origin'
    }).then(function(r){return r.json();}).then(function(r){
        btn.disabled=false; btn.textContent='💾 Kaydet';
        if(r.ok) location.href='?sayfa=ik-perf-detay&id='+r.id;
        else alert('Hata: '+(r.hata||'?'));
    }).catch(function(){btn.disabled=false;btn.textContent='💾 Kaydet';alert('Bağlantı hatası');});
}

<?php if($d && $d['personel_id']): ?>perDoldur(document.getElementById('perSec'));<?php endif; ?>
hesapla();
</script>
