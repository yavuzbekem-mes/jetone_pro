<?php
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';

// MySQL'de IF NOT EXISTS kolonlar için mevcut yapıyı kontrol et
$mevcut = [];
try {
    $r = $db->query("SHOW COLUMNS FROM mps_plan");
    foreach($r->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $mevcut[] = $row['Field'];
    }
} catch(Exception $e) {
    die("mps_plan tablosu bulunamadı: " . $e->getMessage());
}

$eklenecekler = [
    'hat_sira_no'    => "ALTER TABLE mps_plan ADD COLUMN hat_sira_no INT DEFAULT 0",
    'uretim_emri_no' => "ALTER TABLE mps_plan ADD COLUMN uretim_emri_no VARCHAR(50) NULL",
    'kalan_miktar'   => "ALTER TABLE mps_plan ADD COLUMN kalan_miktar INT NULL",
    'kalan_vardiya'  => "ALTER TABLE mps_plan ADD COLUMN kalan_vardiya INT NULL",
];

foreach($eklenecekler as $kolon => $sql) {
    if(in_array($kolon, $mevcut)) {
        echo "MEVCUT: $kolon\n";
        continue;
    }
    try {
        $db->exec($sql);
        echo "EKLENDI: $kolon\n";
    } catch(Exception $e) {
        echo "HATA: $kolon — " . $e->getMessage() . "\n";
    }
}

// Index ekle (varsa atla)
try {
    $idx = $db->query("SHOW INDEX FROM mps_plan WHERE Key_name='idx_hat_sira'")->fetchAll();
    if(empty($idx)) {
        $db->exec("ALTER TABLE mps_plan ADD INDEX idx_hat_sira (hat_kodu, hat_sira_no)");
        echo "INDEX eklendi: idx_hat_sira\n";
    } else {
        echo "MEVCUT: idx_hat_sira\n";
    }
} catch(Exception $e) {
    echo "INDEX HATA: " . $e->getMessage() . "\n";
}

echo "Tamamlandı.\n";
