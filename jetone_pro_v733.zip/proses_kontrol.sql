-- ================================================================
-- PROSES KONTROL TABLOSU
-- phpMyAdmin'de çalıştırın
-- ================================================================
CREATE TABLE IF NOT EXISTS `proses_kontrol` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `urun_kodu`     VARCHAR(50)  NOT NULL,
  `urun_adi`      VARCHAR(200) NOT NULL DEFAULT '',
  `istasyon_kodu` VARCHAR(30)  NOT NULL DEFAULT '',
  `vardiya`       TINYINT(1)   NOT NULL DEFAULT 1,
  `tarih`         DATE         NOT NULL,

  -- Ölçüm değerleri
  `gramaj`        DECIMAL(10,3) DEFAULT NULL COMMENT 'Ölçülen gramaj',
  `map_gramaj`    DECIMAL(10,3) DEFAULT NULL COMMENT 'Map gramaj (DB/Tiger)',
  `gramaj_fark`   DECIMAL(10,3) DEFAULT NULL COMMENT 'gramaj - map_gramaj',

  `cevrim`        DECIMAL(10,2) DEFAULT NULL COMMENT 'Ölçülen çevrim sn',
  `map_cevrim`    DECIMAL(10,2) DEFAULT NULL COMMENT 'Map çevrim (DB/Tiger)',
  `cevrim_fark`   DECIMAL(10,2) DEFAULT NULL COMMENT 'cevrim - map_cevrim',

  `makina_tonaj`  DECIMAL(10,2) DEFAULT NULL COMMENT 'Makina tonajı (is_istasyonlari)',
  `map_tonaj`     DECIMAL(10,2) DEFAULT NULL COMMENT 'Map tonaj (DB/Tiger)',
  `tonaj_fark`    DECIMAL(10,2) DEFAULT NULL COMMENT 'makina_tonaj - map_tonaj',

  -- Görsel kontrol kriterleri: ok / nok / na
  `cizik_capak`   VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `kirik_catlak`  VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `cokuntu`       VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `hm_lekesi`     VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `yag_lekesi`    VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `eksik_enj`     VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `serpme`        VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `gazlanma`      VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `yanma`         VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `tirnak_pim`    VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `harelenme`     VARCHAR(5)   NOT NULL DEFAULT 'ok',
  `sonuc`         VARCHAR(5)   NOT NULL DEFAULT 'ok' COMMENT 'KARAR: ok/nok/na',

  `aciklama`      TEXT,
  `ekleyen`       VARCHAR(100) NOT NULL DEFAULT '',
  `kayit_zaman`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY `idx_tarih`     (`tarih`),
  KEY `idx_urun`      (`urun_kodu`),
  KEY `idx_istasyon`  (`istasyon_kodu`),
  KEY `idx_sonuc`     (`sonuc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;
