<?php
/**
 * JETONE.PRO — Güvenli Tablo Güncelleme
 * tablo_guncelle.php
 *
 * Tarayıcıdan açın: http://localhost:4459/jetone_pro/tablo_guncelle.php
 * Kolonları tek tek kontrol eder, yoksa ekler, varsa atlar.
 * Kullandıktan sonra silin!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı bağlantısı
$db_host  = 'localhost';
$db_adi   = 'jetone_pro';
$db_kul   = 'root';
$db_sifre = '';

try {
    $db = new PDO("mysql:host=$db_host;dbname=$db_adi;charset=utf8", $db_kul, $db_sifre);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $baglanti_ok = true;
} catch (Exception $e) {
    $baglanti_ok = false;
    $baglanti_hata = $e->getMessage();
}

$sonuclar = array();
$islem_tamam = false;

// Kolon var mı kontrol et
function kolon_var($db, $tablo, $kolon) {
    $stmt = $db->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME   = ?
           AND COLUMN_NAME  = ?"
    );
    $stmt->execute(array($tablo, $kolon));
    return (int)$stmt->fetchColumn() > 0;
}

// Tablo var mı kontrol et
function tablo_var($db, $tablo) {
    $stmt = $db->prepare(
        "SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME   = ?"
    );
    $stmt->execute(array($tablo));
    return (int)$stmt->fetchColumn() > 0;
}

// Kolon ekle (yoksa)
function kolon_ekle($db, &$sonuclar, $tablo, $kolon, $tanim) {
    global $db_adi;
    if (kolon_var($db, $tablo, $kolon)) {
        $sonuclar[] = array('durum'=>'atla', 'mesaj'=>"$tablo.$kolon — zaten mevcut, atlandı");
        return;
    }
    try {
        $db->exec("ALTER TABLE `$tablo` ADD COLUMN `$kolon` $tanim");
        $sonuclar[] = array('durum'=>'ok', 'mesaj'=>"$tablo.$kolon — eklendi ✓");
    } catch (Exception $e) {
        $sonuclar[] = array('durum'=>'hata', 'mesaj'=>"$tablo.$kolon — HATA: " . $e->getMessage());
    }
}

// Tablo oluştur (yoksa)
function tablo_olustur($db, &$sonuclar, $tablo, $sql) {
    if (tablo_var($db, $tablo)) {
        $sonuclar[] = array('durum'=>'atla', 'mesaj'=>"$tablo tablosu — zaten mevcut, atlandı");
        return;
    }
    try {
        $db->exec($sql);
        $sonuclar[] = array('durum'=>'ok', 'mesaj'=>"$tablo tablosu — oluşturuldu ✓");
    } catch (Exception $e) {
        $sonuclar[] = array('durum'=>'hata', 'mesaj'=>"$tablo tablosu — HATA: " . $e->getMessage());
    }
}

if ($baglanti_ok && isset($_POST['calistir'])) {

    // ════════════════════════════════════════════════════════
    // sistem_loglar — tablo_adi kolonu
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'sistem_loglar', 'tablo_adi',
        "VARCHAR(80) DEFAULT NULL AFTER `modul`");

    // ════════════════════════════════════════════════════════
    // personeller — organizasyonel alanlar
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'unvan',
        "VARCHAR(100) DEFAULT NULL AFTER `pozisyon`");
    kolon_ekle($db, $sonuclar, 'personeller', 'yonetici_id',
        "INT DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'tedarikci_firma',
        "VARCHAR(150) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'calisma_yeri',
        "VARCHAR(100) DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — kişisel ek bilgiler
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'uyruk',
        "VARCHAR(50) DEFAULT 'T.C.'");
    kolon_ekle($db, $sonuclar, 'personeller', 'dogum_yeri',
        "VARCHAR(100) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'medeni_durum',
        "VARCHAR(20) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'cocuk_sayisi',
        "TINYINT DEFAULT 0");
    kolon_ekle($db, $sonuclar, 'personeller', 'kan_grubu',
        "VARCHAR(5) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'engellilik_durumu',
        "TINYINT(1) DEFAULT 0");
    kolon_ekle($db, $sonuclar, 'personeller', 'engellilik_orani',
        "TINYINT DEFAULT 0");

    // ════════════════════════════════════════════════════════
    // personeller — askerlik
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'askerlik_durumu',
        "VARCHAR(30) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'askerlik_tarihi',
        "DATE DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — eğitim
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'egitim_seviyesi',
        "VARCHAR(30) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'okul_adi',
        "VARCHAR(200) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'bolum',
        "VARCHAR(150) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'mezuniyet_yili',
        "SMALLINT DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — iletişim
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'tel_is',
        "VARCHAR(20) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'adres',
        "TEXT DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'il',
        "VARCHAR(50) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'ilce',
        "VARCHAR(50) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'posta_kodu',
        "VARCHAR(10) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'acil_kisi_ad',
        "VARCHAR(150) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'acil_kisi_tel',
        "VARCHAR(20) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'acil_kisi_yakinlik',
        "VARCHAR(50) DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — fiziksel ölçüler
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'ayakkabi_no',
        "VARCHAR(5) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'ust_beden',
        "VARCHAR(10) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'pantolon_beden',
        "VARCHAR(10) DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — SGK & iş
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'sgk_no',
        "VARCHAR(20) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'is_sozlesmesi_tipi',
        "VARCHAR(30) DEFAULT 'belirsiz_sureli'");
    kolon_ekle($db, $sonuclar, 'personeller', 'deneme_bitis',
        "DATE DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'cikis_tarihi',
        "DATE DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'cikis_nedeni',
        "VARCHAR(100) DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — finansal
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'banka_adi',
        "VARCHAR(100) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'brut_maas',
        "DECIMAL(12,2) DEFAULT 0.00");
    kolon_ekle($db, $sonuclar, 'personeller', 'yol_ucreti',
        "DECIMAL(10,2) DEFAULT 0.00");
    kolon_ekle($db, $sonuclar, 'personeller', 'yemek_ucreti',
        "DECIMAL(10,2) DEFAULT 0.00");

    // ════════════════════════════════════════════════════════
    // personeller — sağlık & İSG
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'saglik_raporu_var',
        "TINYINT(1) DEFAULT 0");
    kolon_ekle($db, $sonuclar, 'personeller', 'isg_egitim_tarihi',
        "DATE DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'personeller', 'isg_egitim_sure',
        "INT DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // personeller — portal
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'personeller', 'taseron_firma',
        "VARCHAR(200) DEFAULT NULL COMMENT 'Taseron/tedarikci firma adi'");

    // Yeni kolonlar: kadro, servis_durak, vardiya_tipi, aktif_vardiya
    kolon_ekle($db, $sonuclar, 'personeller', 'kadro',
        "VARCHAR(30) DEFAULT NULL COMMENT 'beyaz_yaka,endirekt,direkt,stajyer'");
    kolon_ekle($db, $sonuclar, 'personeller', 'servis_durak',
        "VARCHAR(30) DEFAULT NULL COMMENT 'cerkezkoy,kizilpinar,kapakli,karaagac'");
    kolon_ekle($db, $sonuclar, 'personeller', 'vardiya_tipi',
        "VARCHAR(10) DEFAULT NULL COMMENT 'tek,3lu,beyaz'");
    kolon_ekle($db, $sonuclar, 'personeller', 'aktif_vardiya',
        "TINYINT(1) DEFAULT NULL COMMENT '1=08-16,2=16-00,3=00-08'");

    kolon_ekle($db, $sonuclar, 'personeller', 'portal_aktif',
        "TINYINT(1) DEFAULT 1");
    kolon_ekle($db, $sonuclar, 'personeller', 'sifre_degistirildi',
        "TINYINT(1) DEFAULT 0");

    // ════════════════════════════════════════════════════════
    // kullanicilar — ERP ilk giriş şifre kontrolü
    // ════════════════════════════════════════════════════════
    kolon_ekle($db, $sonuclar, 'kullanicilar', 'sifre_degistirildi',
        "TINYINT(1) DEFAULT 1 COMMENT '0=ilk sifre, 1=kullanici degistirdi'");
    kolon_ekle($db, $sonuclar, 'kullanicilar', 'son_giris',
        "DATETIME DEFAULT NULL");

    // ════════════════════════════════════════════════════════
    // Yeni tablolar
    // ════════════════════════════════════════════════════════
    tablo_olustur($db, $sonuclar, 'personel_zimmetler',
        "CREATE TABLE `personel_zimmetler` (
          `id`            INT AUTO_INCREMENT PRIMARY KEY,
          `personel_id`   INT           NOT NULL,
          `kalem`         VARCHAR(200)  NOT NULL,
          `seri_no`       VARCHAR(100)  DEFAULT NULL,
          `miktar`        INT           DEFAULT 1,
          `birim`         VARCHAR(20)   DEFAULT 'adet',
          `teslim_tarihi` DATE          DEFAULT NULL,
          `iade_tarihi`   DATE          DEFAULT NULL,
          `durum`         VARCHAR(20)   DEFAULT 'zimmetli',
          `notlar`        TEXT,
          `olusturma`     DATETIME      DEFAULT CURRENT_TIMESTAMP,
          INDEX `idx_personel` (`personel_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
    );

    tablo_olustur($db, $sonuclar, 'personel_belgeler',
        "CREATE TABLE `personel_belgeler` (
          `id`            INT AUTO_INCREMENT PRIMARY KEY,
          `personel_id`   INT           NOT NULL,
          `kategori`      VARCHAR(50)   NOT NULL,
          `belge_adi`     VARCHAR(200)  NOT NULL,
          `dosya_adi`     VARCHAR(300)  DEFAULT NULL,
          `dosya_yolu`    VARCHAR(500)  DEFAULT NULL,
          `gecerlilik`    DATE          DEFAULT NULL,
          `notlar`        TEXT,
          `olusturma`     DATETIME      DEFAULT CURRENT_TIMESTAMP,
          `olusturan_id`  INT           DEFAULT NULL,
          INDEX `idx_personel` (`personel_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
    );

    // geofence_lokasyonlari — aktif kolonu
    kolon_ekle($db, $sonuclar, 'geofence_lokasyonlari', 'aktif',
        "TINYINT(1) DEFAULT 1");

    // ayarlar — anahtar/deger yapısı
    kolon_ekle($db, $sonuclar, 'ayarlar', 'anahtar',
        "VARCHAR(100) DEFAULT NULL");

    // ayarlar_kv tablosu
    tablo_olustur($db, $sonuclar, 'ayarlar_kv',
        "CREATE TABLE IF NOT EXISTS `ayarlar_kv` (
            `id`          INT AUTO_INCREMENT PRIMARY KEY,
            `anahtar`     VARCHAR(100) NOT NULL UNIQUE,
            `deger`       TEXT,
            `guncelleme`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // vardialar — 3 vardiya tanımı ekle (yoksa)
    try {
        $sayac=$db->query("SELECT COUNT(*) FROM vardialar")->fetchColumn();
        if($sayac==0){
            $db->exec("INSERT INTO vardialar (ad,baslangic,bitis,renk) VALUES
                ('1. Vardiya','08:00:00','16:00:00','#D1FAE5'),
                ('2. Vardiya','16:00:00','00:00:00','#DBEAFE'),
                ('3. Vardiya','00:00:00','08:00:00','#F3E8FF')");
            $sonuclar[]=['durum'=>'ok','mesaj'=>'vardialar — 3 vardiya eklendi ✓'];
        } else {
            $sonuclar[]=['durum'=>'atla','mesaj'=>'vardialar — zaten '.($sayac).' kayıt var, atlandı'];
        }
    } catch(Exception $e){ $sonuclar[]=['durum'=>'hata','mesaj'=>'vardialar — '.$e->getMessage()]; }

    // push_subscriptions tablosu (Web Push bildirimleri için)
    tablo_olustur($db, $sonuclar, 'push_subscriptions',
        "CREATE TABLE IF NOT EXISTS `push_subscriptions` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `portal_kul_id` INT NOT NULL,
            `personel_id`   INT DEFAULT NULL,
            `endpoint`      TEXT NOT NULL,
            `p256dh`        VARCHAR(500) NOT NULL,
            `auth`          VARCHAR(200) NOT NULL,
            `user_agent`    VARCHAR(300) DEFAULT NULL,
            `aktif`         TINYINT(1) DEFAULT 1,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_pki` (`portal_kul_id`),
            INDEX `idx_pid` (`personel_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // bildirimler — portal_tipi ve ilgili_id kolonları
    kolon_ekle($db, $sonuclar, 'bildirimler', 'portal_tipi',
        "VARCHAR(20) DEFAULT 'erp' COMMENT 'erp,personel,musteri'");
    kolon_ekle($db, $sonuclar, 'bildirimler', 'modul',
        "VARCHAR(50) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'bildirimler', 'link',
        "VARCHAR(300) DEFAULT NULL");

    // oneri_sikayet tablosu
    tablo_olustur($db, $sonuclar, 'oneri_sikayet',
        "CREATE TABLE IF NOT EXISTS `oneri_sikayet` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `personel_id`     INT NOT NULL,
            `tip`             VARCHAR(20) DEFAULT 'oneri',
            `konu`            VARCHAR(200) NOT NULL,
            `aciklama`        TEXT,
            `durum`           VARCHAR(30) DEFAULT 'bekliyor',
            `anonim`          TINYINT(1) DEFAULT 0,
            `odul_hakki`      TINYINT(1) DEFAULT 0,
            `odul_tutari`     DECIMAL(10,2) DEFAULT 0,
            `inceleme_notu`   TEXT,
            `inceleme_tarihi` DATETIME DEFAULT NULL,
            `inceleyici_id`   INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_pid (personel_id), INDEX idx_d (durum), INDEX idx_t (tip)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // yedekleme tablosu

    // ════════════════════════════════════════════════════════
    // SATINALMA TALEP SİSTEMİ TABLOLARI
    // ════════════════════════════════════════════════════════

    // 1. Ana talep tablosu
    tablo_olustur($db, $sonuclar, 'satin_alma_talepler',
        "CREATE TABLE `satin_alma_talepler` (
            `id`                INT AUTO_INCREMENT PRIMARY KEY,
            `talep_no`          VARCHAR(20) NOT NULL UNIQUE COMMENT 'SAT-2024-0001',
            `talep_eden_id`     INT NOT NULL COMMENT 'kullanicilar.id',
            `talep_eden_adi`    VARCHAR(200) NOT NULL,
            `departman`         VARCHAR(200) DEFAULT NULL,
            `talep_turu`        ENUM('sarf_malzeme','teknik_satin_alma') NOT NULL DEFAULT 'sarf_malzeme',
            `oncelik`           ENUM('dusuk','normal','yuksek','acil') NOT NULL DEFAULT 'normal',
            `termin_tarihi`     DATE DEFAULT NULL,
            `aciklama`          TEXT DEFAULT NULL COMMENT 'Tedarikci onerileri, sartnameler',
            `durum`             ENUM('bekliyor','onayda','reddedildi','teklifte','siparisde','kismi_tedarik','tamamlandi','iptal') NOT NULL DEFAULT 'bekliyor',
            `onaylayan_id`      INT DEFAULT NULL COMMENT 'Onaylayan kullanici',
            `onay_tarihi`       DATETIME DEFAULT NULL,
            `onay_notu`         TEXT DEFAULT NULL,
            `ret_notu`          TEXT DEFAULT NULL,
            `atanan_kisi_id`    INT DEFAULT NULL COMMENT 'Idari isler sorumlusu',
            `teklif_notu`       TEXT DEFAULT NULL,
            `siparis_tarihi`    DATE DEFAULT NULL,
            `siparis_notu`      TEXT DEFAULT NULL,
            `teslim_tarihi`     DATE DEFAULT NULL,
            `tamamlanma_notu`   TEXT DEFAULT NULL,
            `toplam_miktar`     DECIMAL(10,3) DEFAULT 0,
            `toplam_tutar`      DECIMAL(12,2) DEFAULT NULL,
            `olusturma`         DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_talep_eden (talep_eden_id),
            INDEX idx_durum (durum),
            INDEX idx_olusturma (olusturma)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Satinalma talepleri ana tablosu'"
    );

    // satin_alma_talepler'e personel_id kolonu ekle
    kolon_ekle($db, $sonuclar, 'satin_alma_talepler', 'personel_id',
        "INT DEFAULT NULL COMMENT 'personeller.id - portal bildirimleri için'");

    // 2. Talep kalemleri (satırlar)
    tablo_olustur($db, $sonuclar, 'satin_alma_kalemler',
        "CREATE TABLE `satin_alma_kalemler` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `talep_id`      INT NOT NULL,
            `sira_no`       TINYINT NOT NULL DEFAULT 1,
            `urun_kodu`     VARCHAR(100) DEFAULT NULL COMMENT 'Urun veya malzeme kodu',
            `urun_adi`      VARCHAR(500) NOT NULL COMMENT 'Urun / Malzeme olcusu ve adi',
            `marka`         VARCHAR(200) DEFAULT NULL,
            `miktar`        DECIMAL(10,3) NOT NULL DEFAULT 1,
            `birim`         VARCHAR(50) NOT NULL DEFAULT 'Adet',
            `aciklama`      VARCHAR(500) DEFAULT NULL COMMENT 'Kullanim yeri / aciklama',
            `birim_fiyat`   DECIMAL(12,2) DEFAULT NULL,
            `toplam_fiyat`  DECIMAL(12,2) DEFAULT NULL,
            `kalem_durum`   ENUM('bekliyor','onaylandi','reddedildi','tedarik_edildi') NOT NULL DEFAULT 'bekliyor',
            `kalem_notu`    VARCHAR(500) DEFAULT NULL,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (talep_id) REFERENCES satin_alma_talepler(id) ON DELETE CASCADE,
            INDEX idx_talep (talep_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Talep kalemleri (satir bazli urunler)'"
    );

    // 3. Durum geçmişi / zaman çizelgesi
    tablo_olustur($db, $sonuclar, 'satin_alma_gecmis',
        "CREATE TABLE `satin_alma_gecmis` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `talep_id`      INT NOT NULL,
            `kullanici_id`  INT DEFAULT NULL,
            `kullanici_adi` VARCHAR(200) DEFAULT NULL,
            `eski_durum`    VARCHAR(50) DEFAULT NULL,
            `yeni_durum`    VARCHAR(50) NOT NULL,
            `not_metni`     TEXT DEFAULT NULL,
            `mail_gonderildi` TINYINT(1) DEFAULT 0,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (talep_id) REFERENCES satin_alma_talepler(id) ON DELETE CASCADE,
            INDEX idx_talep (talep_id),
            INDEX idx_olusturma (olusturma)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Talep durum degisim gecmisi ve notlar'"
    );

    // 4. Mail log tablosu (gönderilen tüm mailler)
    tablo_olustur($db, $sonuclar, 'satin_alma_mail_log',
        "CREATE TABLE `satin_alma_mail_log` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `talep_id`      INT NOT NULL,
            `alici`         VARCHAR(500) NOT NULL COMMENT 'Virgul ayrimli mailler',
            `konu`          VARCHAR(500) NOT NULL,
            `durum`         ENUM('gonderildi','hata') NOT NULL DEFAULT 'gonderildi',
            `hata_mesaji`   TEXT DEFAULT NULL,
            `tetikleyen`    VARCHAR(100) DEFAULT NULL COMMENT 'Hangi aksiyon mail attirdi',
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (talep_id) REFERENCES satin_alma_talepler(id) ON DELETE CASCADE,
            INDEX idx_talep (talep_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Gonderilen mail kayitlari'"
    );

    // 5. Ayarlar — satınalma sorumluları
    // (Mevcut ayarlar_kv tablosuna kayıt ekleyeceğiz, yeni tablo gerekmez)
    // Sorumlu e-posta adresleri: satin_alma_mudur_mail, idari_isler_mail





    // ════════════════════════════════════════════════════════
    // İHTAR TUTANAĞI
    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'ihtar_tutanaklar',
        "CREATE TABLE `ihtar_tutanaklar` (
            `id`                INT AUTO_INCREMENT PRIMARY KEY,
            `tutanak_no`        VARCHAR(30) NOT NULL UNIQUE COMMENT 'IHT-2024-0001',
            `personel_id`       INT NOT NULL,
            `ihtar_tarihi`      DATE NOT NULL,
            `teblig_eden`       VARCHAR(200) DEFAULT NULL,
            `sabit`             VARCHAR(200) DEFAULT NULL,
            `nedenler`          TEXT DEFAULT NULL COMMENT 'JSON array of selected reasons',
            `diger_neden`       VARCHAR(500) DEFAULT NULL,
            `savunma`           TEXT DEFAULT NULL,
            `karar`             TEXT DEFAULT NULL,
            `savunma_tarihi`    DATETIME DEFAULT NULL,
            `ik_sorumlu`        VARCHAR(200) DEFAULT NULL,
            `fabrika_mudur`     VARCHAR(200) DEFAULT NULL,
            `kaydeden_id`       INT DEFAULT NULL,
            `durum`             ENUM('bekliyor','savunma_alindi','kapatildi') DEFAULT 'bekliyor',
            `olusturma`         DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_personel (personel_id),
            INDEX idx_tarih (ihtar_tarihi)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // İhtar tablosuna eksik kolonları ekle (ALTER TABLE)
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'sabit',
        "VARCHAR(200) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'nedenler',
        "TEXT DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'diger_neden',
        "VARCHAR(500) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'karar',
        "TEXT DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'kaydeden_id',
        "INT DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'bolum',
        "VARCHAR(200) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'kadro',
        "VARCHAR(200) DEFAULT NULL");
    kolon_ekle($db, $sonuclar, 'ihtar_tutanaklar', 'unvan',
        "VARCHAR(200) DEFAULT NULL");

    // durum ENUM güncelle
    try {
        $db->exec("ALTER TABLE ihtar_tutanaklar MODIFY durum ENUM('bekliyor','savunma_alindi','kapatildi') DEFAULT 'bekliyor'");
    } catch (Throwable $e) {}

    // ════════════════════════════════════════════════════════
    // MEMNUNİYET ANKETİ
    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'anket_yanitlar',
        "CREATE TABLE `anket_yanitlar` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `portal_kul_id`   INT DEFAULT NULL,
            `anonim`          TINYINT(1) DEFAULT 1,
            `ad_soyad`        VARCHAR(200) DEFAULT NULL,
            `departman`       VARCHAR(200) DEFAULT NULL,
            -- Bölüm A (1-7)
            `a1` TINYINT DEFAULT NULL, `a2` TINYINT DEFAULT NULL,
            `a3` TINYINT DEFAULT NULL, `a4` TINYINT DEFAULT NULL,
            `a5` TINYINT DEFAULT NULL, `a6` TINYINT DEFAULT NULL,
            `a7` TINYINT DEFAULT NULL,
            -- Bölüm B (8-23)
            `b8`  TINYINT DEFAULT NULL, `b9`  TINYINT DEFAULT NULL,
            `b10` TINYINT DEFAULT NULL, `b11` TINYINT DEFAULT NULL,
            `b12` TINYINT DEFAULT NULL, `b13` TINYINT DEFAULT NULL,
            `b14` TINYINT DEFAULT NULL, `b15` TINYINT DEFAULT NULL,
            `b16` TINYINT DEFAULT NULL, `b17` TINYINT DEFAULT NULL,
            `b18` TINYINT DEFAULT NULL, `b19` TINYINT DEFAULT NULL,
            `b20` TINYINT DEFAULT NULL, `b21` TINYINT DEFAULT NULL,
            `b22` TINYINT DEFAULT NULL, `b23` TINYINT DEFAULT NULL,
            -- Bölüm C (24-30)
            `c24` TINYINT DEFAULT NULL, `c25` TINYINT DEFAULT NULL,
            `c26` TINYINT DEFAULT NULL, `c27` TINYINT DEFAULT NULL,
            `c28` TINYINT DEFAULT NULL, `c29` TINYINT DEFAULT NULL,
            `c30` TINYINT DEFAULT NULL,
            -- Açık uçlu
            `mutlu1`   VARCHAR(500) DEFAULT NULL,
            `mutlu2`   VARCHAR(500) DEFAULT NULL,
            `mutlu3`   VARCHAR(500) DEFAULT NULL,
            `sikayet1` VARCHAR(500) DEFAULT NULL,
            `sikayet2` VARCHAR(500) DEFAULT NULL,
            `sikayet3` VARCHAR(500) DEFAULT NULL,
            `genel_oneri` TEXT DEFAULT NULL,
            `olusturma`   DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_portal (portal_kul_id),
            INDEX idx_tarih (olusturma)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // ════════════════════════════════════════════════════════
    // SERVİS & YEMEK TABLOLARI
    tablo_olustur($db, $sonuclar, 'yemek_puanlar',
        "CREATE TABLE `yemek_puanlar` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `menu_id`       INT NOT NULL,
            `portal_kul_id` INT NOT NULL,
            `puan`          TINYINT NOT NULL COMMENT '1=Begenmedi 2=Orta 3=Begendi',
            `yorum`         VARCHAR(300) DEFAULT NULL,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_menu_kul (menu_id, portal_kul_id),
            INDEX idx_menu (menu_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );


    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'servis_araclar',
        "CREATE TABLE `servis_araclar` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `plaka`         VARCHAR(20) NOT NULL,
            `marka`         VARCHAR(100) DEFAULT NULL,
            `kapasite`      INT DEFAULT 0,
            `surucu_id`     INT DEFAULT NULL COMMENT 'personeller.id',
            `surucu_adi`    VARCHAR(200) DEFAULT NULL,
            `surucu_tel`    VARCHAR(50) DEFAULT NULL,
            `aktif`         TINYINT(1) DEFAULT 1,
            `notlar`        TEXT DEFAULT NULL,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'servis_rotalar',
        "CREATE TABLE `servis_rotalar` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `ad`            VARCHAR(200) NOT NULL,
            `yon`           ENUM('sabah','aksam','her_iki') DEFAULT 'her_iki',
            `vardiya`       TINYINT DEFAULT NULL COMMENT '1/2/3',
            `arac_id`       INT DEFAULT NULL,
            `kalkis_saati`  TIME DEFAULT NULL,
            `aktif`         TINYINT(1) DEFAULT 1,
            `notlar`        TEXT DEFAULT NULL,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (arac_id) REFERENCES servis_araclar(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'servis_duraklar',
        "CREATE TABLE `servis_duraklar` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `rota_id`       INT NOT NULL,
            `sira`          TINYINT DEFAULT 1,
            `ad`            VARCHAR(200) NOT NULL,
            `saat`          TIME DEFAULT NULL,
            `koordinat`     VARCHAR(100) DEFAULT NULL,
            FOREIGN KEY (rota_id) REFERENCES servis_rotalar(id) ON DELETE CASCADE,
            INDEX idx_rota (rota_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'yemek_menuler',
        "CREATE TABLE `yemek_menuler` (
            `id`            INT AUTO_INCREMENT PRIMARY KEY,
            `tarih`         DATE NOT NULL,
            `ogun`          ENUM('sabah','oglen','aksam') DEFAULT 'oglen',
            `yemek1`        VARCHAR(300) DEFAULT NULL,
            `yemek2`        VARCHAR(300) DEFAULT NULL,
            `yemek3`        VARCHAR(300) DEFAULT NULL,
            `yemek4`        VARCHAR(300) DEFAULT NULL,
            `corba`         VARCHAR(300) DEFAULT NULL,
            `tatli`         VARCHAR(300) DEFAULT NULL,
            `notlar`        VARCHAR(500) DEFAULT NULL,
            `kalori`        INT DEFAULT NULL,
            `olusturan_id`  INT DEFAULT NULL,
            `olusturma`     DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_tarih_ogun (tarih, ogun),
            INDEX idx_tarih (tarih)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // ════════════════════════════════════════════════════════
    // ARAÇ / FİLO YÖNETİMİ
    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'araclar',
        "CREATE TABLE `araclar` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `plaka`           VARCHAR(20) NOT NULL UNIQUE,
            `marka`           VARCHAR(100) DEFAULT NULL,
            `model`           VARCHAR(100) DEFAULT NULL,
            `yil`             YEAR DEFAULT NULL,
            `renk`            VARCHAR(50) DEFAULT NULL,
            `yakit_tipi`      ENUM('benzin','dizel','lpg','elektrik','hibrit') DEFAULT 'dizel',
            `cins`            VARCHAR(50) DEFAULT NULL COMMENT 'Binek, kamyonet, minibüs vb.',
            `motor_no`        VARCHAR(100) DEFAULT NULL,
            `sasi_no`         VARCHAR(100) DEFAULT NULL,
            `ruhsat_sahibi`   VARCHAR(200) DEFAULT NULL,
            `sigorta_bitis`   DATE DEFAULT NULL,
            `kasko_bitis`     DATE DEFAULT NULL,
            `muayene_bitis`   DATE DEFAULT NULL,
            `egzos_bitis`     DATE DEFAULT NULL,
            `km_guncel`       INT DEFAULT 0,
            `durum`           ENUM('aktif','bakim','pasif','hurda') DEFAULT 'aktif',
            `sorumlu_id`      INT DEFAULT NULL COMMENT 'personeller.id',
            `notlar`          TEXT DEFAULT NULL,
            `foto`            VARCHAR(300) DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_durum (durum)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'arac_bakimlar',
        "CREATE TABLE `arac_bakimlar` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `arac_id`         INT NOT NULL,
            `bakim_tipi`      ENUM('periyodik','ariza','kaza','muayene','lastik','fren','yag','diger') DEFAULT 'periyodik',
            `tarih`           DATE NOT NULL,
            `km`              INT DEFAULT NULL,
            `servis`          VARCHAR(200) DEFAULT NULL,
            `yapilan_isler`   TEXT DEFAULT NULL,
            `tutar`           DECIMAL(10,2) DEFAULT NULL,
            `sonraki_bakim_km` INT DEFAULT NULL,
            `sonraki_bakim_tarih` DATE DEFAULT NULL,
            `belge_no`        VARCHAR(100) DEFAULT NULL,
            `notlar`          TEXT DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (arac_id) REFERENCES araclar(id) ON DELETE CASCADE,
            INDEX idx_arac (arac_id),
            INDEX idx_tarih (tarih)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'arac_yakitlar',
        "CREATE TABLE `arac_yakitlar` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `arac_id`         INT NOT NULL,
            `tarih`           DATE NOT NULL,
            `km`              INT NOT NULL,
            `litre`           DECIMAL(8,2) NOT NULL,
            `birim_fiyat`     DECIMAL(8,3) DEFAULT NULL,
            `tutar`           DECIMAL(10,2) DEFAULT NULL,
            `istasyon`        VARCHAR(200) DEFAULT NULL,
            `surucu_id`       INT DEFAULT NULL COMMENT 'personeller.id',
            `notlar`          VARCHAR(500) DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (arac_id) REFERENCES araclar(id) ON DELETE CASCADE,
            INDEX idx_arac (arac_id),
            INDEX idx_tarih (tarih)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'arac_gorevler',
        "CREATE TABLE `arac_gorevler` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `arac_id`         INT NOT NULL,
            `surucu_id`       INT DEFAULT NULL COMMENT 'personeller.id',
            `baslangic`       DATETIME NOT NULL,
            `bitis`           DATETIME DEFAULT NULL,
            `kalkis_yeri`     VARCHAR(200) DEFAULT NULL,
            `varis_yeri`      VARCHAR(200) DEFAULT NULL,
            `amac`            VARCHAR(500) DEFAULT NULL,
            `km_baslangic`    INT DEFAULT NULL,
            `km_bitis`        INT DEFAULT NULL,
            `durum`           ENUM('planli','devam','tamamlandi','iptal') DEFAULT 'planli',
            `notlar`          TEXT DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (arac_id) REFERENCES araclar(id) ON DELETE CASCADE,
            INDEX idx_arac (arac_id),
            INDEX idx_surucu (surucu_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // ════════════════════════════════════════════════════════
    // TEKLİF & SÖZLEŞME
    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'teklifler',
        "CREATE TABLE `teklifler` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `teklif_no`       VARCHAR(30) NOT NULL UNIQUE COMMENT 'TKL-2024-0001',
            `tip`             ENUM('alinan','verilen') DEFAULT 'alinan',
            `ilgili_tip`      VARCHAR(50) DEFAULT NULL COMMENT 'satin_alma, musteri vb.',
            `ilgili_id`       INT DEFAULT NULL COMMENT 'satin_alma_talepler.id vb.',
            `tedarikci_adi`   VARCHAR(300) DEFAULT NULL,
            `tedarikci_email` VARCHAR(300) DEFAULT NULL,
            `tedarikci_tel`   VARCHAR(50) DEFAULT NULL,
            `konu`            VARCHAR(500) NOT NULL,
            `gecerlilik_tarihi` DATE DEFAULT NULL,
            `toplam_tutar`    DECIMAL(12,2) DEFAULT NULL,
            `para_birimi`     VARCHAR(10) DEFAULT 'TRY',
            `kdv_dahil`      TINYINT(1) DEFAULT 1,
            `durum`           ENUM('taslak','gonderildi','kabul','red','revize','suresi_doldu') DEFAULT 'taslak',
            `notlar`          TEXT DEFAULT NULL,
            `dosya_yolu`      VARCHAR(500) DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_durum (durum),
            INDEX idx_ilgili (ilgili_tip, ilgili_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'teklif_kalemleri',
        "CREATE TABLE `teklif_kalemleri` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `teklif_id`       INT DEFAULT NULL,
            `sira`            TINYINT DEFAULT 1,
            `urun_adi`        VARCHAR(500) NOT NULL,
            `miktar`          DECIMAL(10,3) DEFAULT 1,
            `birim`           VARCHAR(50) DEFAULT 'Adet',
            `birim_fiyat`     DECIMAL(12,2) DEFAULT NULL,
            `kdv_oran`        TINYINT DEFAULT 20,
            `indirim_oran`    DECIMAL(5,2) DEFAULT 0,
            `toplam`          DECIMAL(12,2) DEFAULT NULL,
            `notlar`          VARCHAR(500) DEFAULT NULL,
            INDEX idx_teklif (teklif_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'sozlesmeler',
        "CREATE TABLE `sozlesmeler` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `sozlesme_no`     VARCHAR(30) NOT NULL UNIQUE COMMENT 'SZL-2024-0001',
            `tip`             ENUM('tedarik','hizmet','kira','is','diger') DEFAULT 'tedarik',
            `konu`            VARCHAR(500) NOT NULL,
            `taraf_adi`       VARCHAR(300) NOT NULL,
            `taraf_email`     VARCHAR(300) DEFAULT NULL,
            `baslangic`       DATE DEFAULT NULL,
            `bitis`           DATE DEFAULT NULL,
            `sure_ay`         INT DEFAULT NULL,
            `tutar`           DECIMAL(12,2) DEFAULT NULL,
            `para_birimi`     VARCHAR(10) DEFAULT 'TRY',
            `yenileme`        TINYINT(1) DEFAULT 0 COMMENT 'Otomatik yenileme',
            `hatirlatma_gun`  INT DEFAULT 30 COMMENT 'Bitiş öncesi hatırlatma',
            `durum`           ENUM('taslak','aktif','suresi_doldu','feshedildi','yenilendi') DEFAULT 'taslak',
            `teklif_id`       INT DEFAULT NULL,
            `dosya_yolu`      VARCHAR(500) DEFAULT NULL,
            `imzali_dosya`    VARCHAR(500) DEFAULT NULL,
            `notlar`          TEXT DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_durum (durum),
            INDEX idx_bitis (bitis)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    // ════════════════════════════════════════════════════════
    // DEMİRBAŞ / ZİMMET
    // ════════════════════════════════════════════════════════

    tablo_olustur($db, $sonuclar, 'demirbaslar',
        "CREATE TABLE `demirbaslar` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `barkod`          VARCHAR(100) DEFAULT NULL UNIQUE,
            `adi`             VARCHAR(300) NOT NULL,
            `kategori`        VARCHAR(100) DEFAULT NULL,
            `marka`           VARCHAR(100) DEFAULT NULL,
            `model`           VARCHAR(100) DEFAULT NULL,
            `seri_no`         VARCHAR(200) DEFAULT NULL,
            `satin_alma_tarihi` DATE DEFAULT NULL,
            `satin_alma_tutar` DECIMAL(12,2) DEFAULT NULL,
            `tedarikci`       VARCHAR(200) DEFAULT NULL,
            `garanti_bitis`   DATE DEFAULT NULL,
            `amortisman_yil`  INT DEFAULT NULL,
            `durum`           ENUM('aktif','zimmetli','depoda','bakimda','hurdaya_ayrildi') DEFAULT 'aktif',
            `konum`           VARCHAR(200) DEFAULT NULL,
            `zimmet_personel_id` INT DEFAULT NULL COMMENT 'personeller.id',
            `zimmet_tarihi`   DATE DEFAULT NULL,
            `satin_alma_talep_id` INT DEFAULT NULL COMMENT 'satin_alma_talepler.id',
            `foto`            VARCHAR(300) DEFAULT NULL,
            `qr_kod`          VARCHAR(300) DEFAULT NULL,
            `notlar`          TEXT DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            `guncelleme`      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_durum (durum),
            INDEX idx_zimmet (zimmet_personel_id),
            INDEX idx_kategori (kategori)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'demirbas_hareketler',
        "CREATE TABLE `demirbas_hareketler` (
            `id`              INT AUTO_INCREMENT PRIMARY KEY,
            `demirbas_id`     INT NOT NULL,
            `hareket_tipi`    ENUM('zimmet','iade','devir','bakim','kayip','hurda') DEFAULT 'zimmet',
            `personel_id`     INT DEFAULT NULL COMMENT 'Zimmet/İade eden',
            `tarih`           DATE NOT NULL,
            `aciklama`        TEXT DEFAULT NULL,
            `belge_yolu`      VARCHAR(500) DEFAULT NULL,
            `olusturan_id`    INT DEFAULT NULL,
            `olusturma`       DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_demirbas (demirbas_id),
            INDEX idx_personel (personel_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    tablo_olustur($db, $sonuclar, 'yedekleme_kayitlari',
        "CREATE TABLE `yedekleme_kayitlari` (
          `id`               INT AUTO_INCREMENT PRIMARY KEY,
          `prefix`           VARCHAR(50)   NOT NULL,
          `tarih`            DATETIME      NOT NULL,
          `tip`              VARCHAR(20)   NOT NULL,
          `sure_sn`          DECIMAL(8,2)  DEFAULT NULL,
          `basarili_adimlar` TEXT          DEFAULT NULL,
          `hatalar`          TEXT          DEFAULT NULL,
          `boyut`            VARCHAR(20)   DEFAULT NULL,
          `durum`            VARCHAR(20)   NOT NULL DEFAULT 'basarili',
          `notlar`           TEXT,
          `olusturma`        DATETIME      DEFAULT CURRENT_TIMESTAMP,
          INDEX `idx_tarih`  (`tarih`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
    );

    $hatali = 0;
    foreach ($sonuclar as $s) {
        if ($s['durum'] === 'hata') $hatali++;
    }
    // malzeme_tanimlari tablosu
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `malzeme_tanimlari` (
            `malzeme_id`            INT AUTO_INCREMENT PRIMARY KEY,
            `malzeme_tur`           VARCHAR(20) DEFAULT NULL,
            `malzeme_group`         VARCHAR(25) DEFAULT NULL,
            `malzeme_firma`         VARCHAR(50) DEFAULT NULL,
            `malzeme_kod`           VARCHAR(100) DEFAULT NULL,
            `malzeme_ad`            TEXT,
            `malzeme_birim`         VARCHAR(20) DEFAULT 'ADET',
            `malzeme_stok`          VARCHAR(15) DEFAULT NULL,
            `map_makina_tonaj`      VARCHAR(15) DEFAULT NULL,
            `map_gramaj`            VARCHAR(10) DEFAULT NULL,
            `map_cevrim`            VARCHAR(10) DEFAULT NULL,
            `paket_miktari`         VARCHAR(10) DEFAULT NULL,
            `taban_miktari`         VARCHAR(15) DEFAULT NULL,
            `malzeme_ambalaj`       VARCHAR(30) DEFAULT NULL,
            `malzeme_ekleyen`       VARCHAR(100) DEFAULT NULL,
            `malzeme_tarihi`        DATETIME DEFAULT CURRENT_TIMESTAMP,
            `malzeme_update`        VARCHAR(100) DEFAULT NULL,
            `malzeme_update_tarihi` DATETIME DEFAULT NULL,
            INDEX `idx_kod` (`malzeme_kod`(20)),
            INDEX `idx_firma` (`malzeme_firma`(20)),
            INDEX `idx_tur` (`malzeme_tur`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
        $sonuclar[] = ['tablo'=>'malzeme_tanimlari','kolon'=>'tablo','durum'=>'ok','mesaj'=>'Tablo hazır'];

        // Örnek veri yoksa yükle
        $say = $db->query("SELECT COUNT(*) FROM malzeme_tanimlari")->fetchColumn();
        if ($say == 0) {
            $sql_dosya = __DIR__ . '/malzeme_converted.sql';
            if (file_exists($sql_dosya)) {
                $lines = file($sql_dosya, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                $current_insert = '';
                $yuklenen = 0;
                $hata_say = 0;
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (strpos($line, 'INSERT INTO') === 0) {
                        if ($current_insert) {
                            try { $db->exec(rtrim($current_insert,',')); $yuklenen++; } catch(Throwable $ex){ $hata_say++; }
                        }
                        $current_insert = $line . "
";
                    } else {
                        $current_insert .= $line . "
";
                        if (substr($line, -1) === ';') {
                            try { $db->exec(rtrim($current_insert)); $yuklenen++; } catch(Throwable $ex){ $hata_say++; }
                            $current_insert = '';
                        }
                    }
                }
                if ($current_insert) {
                    try { $db->exec(rtrim($current_insert,',') . ';'); $yuklenen++; } catch(Throwable $ex){ $hata_say++; }
                }
                $yeni_say = $db->query("SELECT COUNT(*) FROM malzeme_tanimlari")->fetchColumn();
                $sonuclar[] = ['tablo'=>'malzeme_tanimlari','kolon'=>'veri','durum'=>'ok','mesaj'=>"$yeni_say kayıt yüklendi ($yuklenen blok, $hata_say hata)"];
            } else {
                $sonuclar[] = ['tablo'=>'malzeme_tanimlari','kolon'=>'veri','durum'=>'atlandi','mesaj'=>'malzeme_converted.sql bulunamadı'];
            }
        } else {
            $sonuclar[] = ['tablo'=>'malzeme_tanimlari','kolon'=>'veri','durum'=>'atlandi','mesaj'=>"Zaten $say kayıt var"];
        }
    } catch(Throwable $e) { $sonuclar[] = ['tablo'=>'malzeme_tanimlari','kolon'=>'tablo','durum'=>'hata','mesaj'=>$e->getMessage()]; }

    // gorevler tablosu ve oncelik kolonu
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS `gorevler` (
            `id`           INT AUTO_INCREMENT PRIMARY KEY,
            `kullanici_id` INT NOT NULL,
            `metin`        VARCHAR(500) NOT NULL,
            `oncelik`      TINYINT(1) DEFAULT 2,
            `tamamlandi`   TINYINT(1) DEFAULT 0,
            `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_kul` (`kullanici_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
        $sonuclar[] = ['tablo'=>'gorevler','kolon'=>'tablo','durum'=>'ok','mesaj'=>'Tablo hazır'];
    } catch(Throwable $e) {
        $sonuclar[] = ['tablo'=>'gorevler','kolon'=>'tablo','durum'=>'hata','mesaj'=>$e->getMessage()];
    }
    $chk_onc = $db->query("SHOW COLUMNS FROM gorevler LIKE 'oncelik'")->fetch();
    if (!$chk_onc) {
        try {
            $db->exec("ALTER TABLE gorevler ADD COLUMN oncelik TINYINT(1) DEFAULT 2 AFTER metin");
            $sonuclar[] = ['tablo'=>'gorevler','kolon'=>'oncelik','durum'=>'ok','mesaj'=>'Eklendi'];
        } catch(Throwable $e) {
            $sonuclar[] = ['tablo'=>'gorevler','kolon'=>'oncelik','durum'=>'hata','mesaj'=>$e->getMessage()];
        }
    } else {
        $sonuclar[] = ['tablo'=>'gorevler','kolon'=>'oncelik','durum'=>'atlandi','mesaj'=>'Zaten var'];
    }

    $islem_tamam = ($hatali === 0);
}

// Mevcut kolon sayısı
$kolon_sayisi = 0;
if ($baglanti_ok) {
    try {
        $kolon_sayisi = $db->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='personeller'")->fetchColumn();
    } catch (Exception $e) {}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Tablo Güncelle</title>
<style>
body{font-family:Arial,sans-serif;background:#111;color:#ccc;padding:24px;font-size:13px;line-height:1.7}
h1{color:#f97316;font-size:16px;margin-bottom:4px}
h2{color:#58a6ff;font-size:13px;margin:16px 0 6px;border-bottom:1px solid #333;padding-bottom:3px}
.ok{color:#3fb950}.hata{color:#f85149}.atla{color:#888}
.uyari{background:#3d1a00;border:1px solid #f97316;border-radius:6px;padding:10px;margin:8px 0;color:#f97316}
.basari{background:#0d2818;border:1px solid #3fb950;border-radius:6px;padding:10px;margin:8px 0;color:#3fb950}
.bilgi{background:#1a1a2e;border:1px solid #333;border-radius:6px;padding:10px;margin:8px 0;color:#8ab4f8}
table{width:100%;border-collapse:collapse;margin-bottom:10px;font-size:12px}
th{background:#1a1a1a;color:#888;padding:5px 8px;border:1px solid #333;text-align:left}
td{padding:5px 8px;border:1px solid #333}
.btn{background:#f97316;color:#fff;border:none;padding:12px 24px;border-radius:6px;cursor:pointer;font-size:14px;font-weight:bold}
.btn-yesil{background:#3fb950}.btn:hover{opacity:.85}
</style>
</head>
<body>
<h1>Jetone.pro — Güvenli Tablo Güncelleme</h1>
<div class="uyari">Bu dosyayı kullandıktan sonra <strong>silin</strong>: <code>tablo_guncelle.php</code></div>

<?php if (!$baglanti_ok): ?>
<div class="uyari"><strong>Veritabanı bağlantı hatası:</strong><br><?php echo htmlspecialchars($baglanti_hata); ?></div>
<?php else: ?>
<div class="basari">Veritabanı bağlantısı başarılı — <?php echo $db_adi; ?></div>
<div class="bilgi">
    personeller tablosunda şu an <strong><?php echo $kolon_sayisi; ?></strong> kolon var.
    <br>Bu script <?php echo ($kolon_sayisi < 30) ? '<strong style="color:#f79009">eksik kolonlar ekleyecek</strong>' : 'kolonları kontrol edecek'; ?>.
</div>
<?php endif; ?>

<?php if (!empty($sonuclar)): ?>
<h2>İşlem Sonuçları</h2>
<?php
$ok_say = $hata_say = $atla_say = 0;
foreach ($sonuclar as $s) {
    if ($s['durum']==='ok')   $ok_say++;
    if ($s['durum']==='hata') $hata_say++;
    if ($s['durum']==='atla') $atla_say++;
}
?>
<div class="<?php echo $hata_say===0 ? 'basari' : 'uyari'; ?>">
    Eklenen: <strong><?php echo $ok_say; ?></strong> &nbsp;|&nbsp;
    Atlanan: <strong><?php echo $atla_say; ?></strong> &nbsp;|&nbsp;
    Hata: <strong><?php echo $hata_say; ?></strong>
    <?php if ($islem_tamam): ?><br><strong>✓ Tüm işlemler tamamlandı! Personel Ekle formunu kullanabilirsiniz.</strong><?php endif; ?>
</div>

<table>
<tr><th>Durum</th><th>Detay</th></tr>
<?php foreach ($sonuclar as $s): ?>
<tr>
    <td class="<?php echo $s['durum']; ?>"><?php echo $s['durum']==='ok'?'✓ Eklendi':($s['durum']==='atla'?'— Atlandı':'✗ Hata'); ?></td>
    <td><?php echo htmlspecialchars($s['mesaj']); ?></td>
</tr>
<?php endforeach; ?>
</table>

<?php if ($islem_tamam): ?>
<div class="basari">
    <strong>Şimdi ne yapabilirsiniz:</strong><br>
    Personel Ekle: <a href="http://localhost:4459/jetone_pro/panel.php?sayfa=ik-ekle" style="color:#3fb950">panel.php?sayfa=ik-ekle</a>
</div>
<?php endif; ?>
<?php endif; ?>

<?php if ($baglanti_ok && !$islem_tamam): ?>
<h2>Güncelleme</h2>
<p style="color:#888;margin-bottom:12px">
    Aşağıdaki butona tıklayın — tüm kolonlar tek tek kontrol edilip eksik olanlar eklenir.<br>
    Zaten var olan kolonlar atlanır, hata oluşmaz.
</p>
<form method="POST">
    <button type="submit" name="calistir" value="1" class="btn btn-yesil"
            onclick="return confirm('Tablo güncellenecek. Devam?')">
        Tabloları Güvenli Güncelle
    </button>
</form>
<?php elseif ($islem_tamam): ?>
<div class="uyari" style="margin-top:16px">
    🗑️ İşlem tamamlandı. Bu dosyayı silin: <code>tablo_guncelle.php</code>
</div>
<?php endif; ?>

</body>
</html>
