<?php
/**
 * JETONE.PRO -- Ana Panel
 * panel.php
 */
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/db.php';
require_once __DIR__ . '/core/auth.php';

Auth::zorunlu();
$kul = Auth::kullanici();
$sayfa = $_GET['sayfa'] ?? 'dashboard';

// POST işlemleri - HTML başlamadan önce yakala
if (!empty($_POST['tl_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/satis/toplama_listesi.php';
    exit;
}
if (!empty($_POST['jit_action']) || (isset($_GET['sayfa']) && $_GET['sayfa']==='satis-jit' && !empty($_FILES['dosya']))) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/satis/jit_siparisler.php';
    exit;
}
if (!empty($_POST['tuik_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/raporlar/tuik.php';
    exit;
}
if (!empty($_POST['tkl_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/satis/teklifler.php';
    exit;
}
if (!empty($_POST['sip_action']) || !empty($_FILES['dosya'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/satis/siparisler.php';
    exit;
}
if (!empty($_POST['gantt_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/planlama/mps_gantt.php';
    exit;
}
if (!empty($_POST['gp_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    include __DIR__ . '/bolumler/planlama/gunluk_plan.php';
    exit;
}
if (!empty($_POST['json_action'])) {
    ob_start();
    require_once __DIR__ . '/core/config.php';
    require_once __DIR__ . '/core/db.php';
    require_once __DIR__ . '/core/auth.php';
    require_once __DIR__ . '/core/baglanlogo.php';
    ob_end_clean();
    $sayfa_json = $_GET['sayfa'] ?? '';
    if ($sayfa_json === 'planlama-ue') {
        include __DIR__ . '/bolumler/planlama/ue_planlama.php';
    } else {
        include __DIR__ . '/bolumler/planlama/mps_oncelik.php';
    }
    exit;
}


?>
<!DOCTYPE html>
<html lang="tr" data-tema="acik">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title><?php echo htmlspecialchars($AYARLAR['firma_adi'] ?? 'Jetone.pro'); ?> -- ERP</title>
<link rel="icon" type="image/svg+xml" href="<?php echo BASE_URL; ?>/favicons/erp.svg">
<link rel="shortcut icon" href="<?php echo BASE_URL; ?>/favicons/erp.svg">
<link rel="apple-touch-icon" href="<?php echo BASE_URL; ?>/icon-192.png">
<link rel="manifest" href="<?php echo BASE_URL; ?>/manifest.json">
<meta name="theme-color" content="#F97316">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Jetone ERP">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <!-- DataTables - önce yükle ki sayfa CSS'i ezesin -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
<?php css_inline('uygulama.css'); ?>
<?php css_inline('panel.css'); ?>
  <style>
  /* DataTables - tr üzerindeki background korunur */
  /* DataTables - gunluk-plan tablosunun thead'ini koru */
  table.dataTable thead th { background:inherit; color:inherit; }
  /* DataTables renk override - tablo satır renkleri korunur */
  table.dataTable tbody tr td,
  table.dataTable tbody tr>td,
  table.dataTable.stripe tbody tr.odd td,
  table.dataTable.stripe tbody tr.even td,
  table.dataTable.display tbody tr.odd>td,
  table.dataTable.display tbody tr.even>td,
  table.dataTable.order-column tbody tr>td.sorting_1,
  table.dataTable.order-column tbody tr>td.sorting_2,
  table.dataTable.order-column tbody tr>td.sorting_3 {
    background-color: inherit !important;
  }
  table.dataTable.hover tbody tr:hover td,
  table.dataTable.display tbody tr:hover td {
    background-color: inherit !important;
    filter: brightness(.92);
  }
  /* Global yazdır - sidebar ve topbar gizle */
  @media print {
    .ana-sb, .ust-bar, .modul-sb,
    .dt-buttons, .s-bar button, .s-bar input,
    #syncBtn, #mailBtn { display:none!important; }
    body { background:#fff!important; }
    .panel-icerik { margin-left:0!important; }
    .icerik { padding:8px!important; }
    .kart > div { max-height:none!important; overflow:visible!important; }
  }
  </style>
  <!-- jQuery + DataTables + Buttons + SheetJS - HEAD'de yükle -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <style>
    /* DataTables özelleştirme */
    .dataTables_wrapper { font-family: inherit; }
    .dataTables_wrapper .dataTables_length select,
    .dataTables_wrapper .dataTables_filter input {
      border: 1.5px solid var(--kenar); border-radius: 8px; padding: 5px 10px;
      font-family: inherit; font-size: 13px; outline: none;
    }
    .dataTables_wrapper .dataTables_filter input:focus { border-color: var(--t); }
    table.dataTable thead th { position: sticky; top: 0; z-index: 2;
      background: var(--yuzey) !important; border-bottom: 2px solid var(--kenar) !important; }
    table.dataTable tbody tr:hover td { background: #F9FAFB; }
    .dataTables_wrapper .dataTables_info,
    .dataTables_wrapper .dataTables_paginate { font-size: 12px; color: var(--m2); padding: 10px 0; }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
      background: var(--t) !important; color: #fff !important; border-radius: 6px; border: none !important; }
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
      background: var(--ta) !important; color: var(--t) !important; border: none !important; border-radius: 6px; }
    .dt-buttons { margin-bottom: 6px; }
    .dt-excel-btn {
      background: #217346; color: #fff; border: none; padding: 8px 16px;
      border-radius: 8px; font-weight: 700; cursor: pointer; font-family: inherit;
      font-size: 13px; display: inline-flex; align-items: center; gap: 6px;
    }
    .dt-excel-btn:hover { background: #1a5c38; }
    .dt-import-btn {
      background: var(--bg); color: var(--m); border: 1.5px solid var(--kenar);
      padding: 8px 14px; border-radius: 8px; font-weight: 600; cursor: pointer;
      font-family: inherit; font-size: 13px; display: inline-flex; align-items: center; gap: 6px;
    }
  </style>
</head>
<body>
<?php include __DIR__ . '/paylasilan/bilesen/sidebar.php'; ?>

<div class="panel-icerik" id="panelIcerik">
  <?php include __DIR__ . '/paylasilan/bilesen/ust-bar.php'; ?>

  <main class="icerik" id="icerikAlani">
    <!-- Sayfa içeriği AJAX ile yüklenir -->
    <div id="sayfaIcerik">
      <?php
      // ── OTOMATİK ROUTER ──────────────────────────────────────────
      // Öncelik sırası:
      // 1. Sistem sayfaları (dashboard, profil, güvenlik - DB dışı)
      // 2. DB'den dosya_yolu (menu_sayfalar.dosya_yolu)
      // 3. Otomatik çözüm (sayfa_id -> klasör/dosya adı)

      // 1. Sadece DB dışı sistem sayfaları burada
      $sayfaMap_ozel = [
        'dashboard'        => 'paylasilan/bilesen/dashboard.php',
        'planlama-norm-personel'       => 'bolumler/planlama/norm_personel.php',
        'planlama-gunluk'              => 'bolumler/planlama/gunluk_plan.php',
        'planlama-gunluk-montaj'       => 'bolumler/planlama/gunluk_plan_montaj.php',
        'planlama-uretim-verimlilik'   => 'bolumler/planlama/uretim_verimlilik.php',
        'planlama-ikinci-kalite-rapor' => 'bolumler/planlama/ikinci_kalite.php',
        'planlama-ikinci-kalite'       => 'bolumler/planlama/ikinci_kalite_detay.php',
        'planlama-ik-tekrar'         => 'bolumler/planlama/ik_tekrar_kayit.php',
        'planlama-tekrar'            => 'bolumler/planlama/ik_tekrar_kayit.php',
        'kullanici-profil' => 'kullanici-profil.php',
        'guvenlik'         => 'guvenlik/index.php',
        'raporlar'                    => 'raporlar/index.php',
        'rapor-hareketsiz-stok'       => 'raporlar/hareketsiz_stok.php',
        'rapor-recetesiz-urunler'     => 'raporlar/recetesiz_urunler.php',
        'rapor-sayim-listesi'         => 'raporlar/sayim_listesi.php',
        'rapor-izlenebilirlik'        => 'raporlar/izlenebilirlik.php',
        'raporlar-tuik'               => 'raporlar/tuik.php',
        'raporlar-sayim'              => 'raporlar/sayim_performans.php',
        // İdari — Güvenlik
        'idari-guvenlik-dashboard'    => 'bolumler/idari/guvenlik_dashboard.php',
        'idari-guvenlik-arac'         => 'bolumler/idari/guvenlik_arac.php',
        'idari-guvenlik-servis'       => 'bolumler/idari/guvenlik_servis.php',
        'idari-guvenlik-tedarikci'    => 'bolumler/idari/guvenlik_tedarikci.php',
        'idari-guvenlik-ziyaretci'    => 'bolumler/idari/guvenlik_ziyaretci.php',
        'entegrasyonlar'   => 'entegrasyonlar/index.php',
        'ayarlar'          => 'ayarlar/index.php',
        'ayarlar-ai'       => 'ayarlar/ai-ayarlar.php',
        'ayarlar-token'    => 'ayarlar/token_yonetim.php',
        'ayarlar-mobil-bar'    => 'ayarlar/mobil_bar_ayar.php',
        'ayarlar-etiket-haric' => 'ayarlar/etiket_haric_kodlar.php',
        'ai-chat'          => 'bolumler/ai/chat.php',
        'planlama-kapasite-enj'   => 'bolumler/planlama/kapasite_enj.php',
        'planlama-kapasite-montaj' => 'bolumler/planlama/kapasite_montaj.php',
        'planlama-manuel-bom'      => 'bolumler/planlama/kapasite_manuel_bom.php',
        'planlama-tedarikci-forecast' => 'bolumler/planlama/tedarikci_forecast.php',
        'planlama-kasa-hesap'      => 'bolumler/planlama/kasa_hesaplama.php',
        // AJAX rotaları
        'ajax-ue-kontrol'  => 'bolumler/planlama/ajax/mps-ue-kontrol.php',
        'ajax-ik-sil'      => 'bolumler/planlama/ajax/ik_sil.php',
        'ajax-hat-sira'    => 'bolumler/planlama/ajax/mps-hat-sira.php',
        'ajax-is-ata'      => 'bolumler/planlama/ajax/mps-is-ata.php',
        'ajax-is-sil'      => 'bolumler/planlama/ajax/mps-is-sil.php',
        // Üretim - Verim Girişi
        // BSH Kit Üretim
        'uretim-kit-liste'           => 'bolumler/uretim/kit_liste.php',
        'uretim-kit-fis-liste'       => 'bolumler/uretim/kit_fis_liste.php',
        'uretim-kit-recete-fark'     => 'bolumler/uretim/kit_recete_fark.php',
        // MES Üretim Emirleri
        'uretim-mes-emri-liste'      => 'bolumler/uretim/mes_uretim_emri_liste.php',
        'uretim-mes-emri-detay'      => 'bolumler/uretim/mes_uretim_emri_detay.php',
        'uretim-durus-takip'          => 'bolumler/uretim/makine_durus_takip.php',
        'uretim-kalite-takip'         => 'bolumler/uretim/kalite_takip.php',
        'uretim-iptal-talepler'       => 'bolumler/uretim/iptal_talepler.php',
        'uretim-paketler'             => 'bolumler/uretim/paket_yonetim.php',
        'uretim-paket-manuel'         => 'bolumler/uretim/paket_manuel.php',
        'satinalma-etiket'            => 'bolumler/satinalma/satinalma_etiket.php',
        'satinalma-etiket-al'         => 'bolumler/satinalma/satinalma_etiket_al.php',
        'satinalma-gkk'               => 'bolumler/satinalma/gkk_kontrol.php',
        'satinalma-gkk-red'           => 'bolumler/satinalma/gkk_red_planlama.php',
        'kalite-gkk-liste'            => 'bolumler/kalite/gkk_liste.php',
        'kalite-gkk-detay'            => 'bolumler/kalite/gkk_detay.php',
        'kalite-gkk-surec'            => 'bolumler/kalite/gkk_red_surec.php',
        'satinalma-gkk-surec'         => 'bolumler/satinalma/gkk_red_surec.php',
        'satinalma-gkk-surec-test'    => 'bolumler/satinalma/gkk_red_surec_test.php',

        'uretim-kit-recete'          => 'bolumler/uretim/kit_recete.php',
        'uretim-kit-uret'            => 'bolumler/uretim/kit_uret.php',
        'uretim-kit-fis'             => 'bolumler/uretim/kit_fis.php',
        'uretim-oee'                  => 'bolumler/uretim/oee.php',
        // Kalite — Mıknatıs Test
        'ayarlar-ikon-rehberi'      => 'bolumler/ayarlar/ikon_rehberi.php',
        'uretim-kalip-baslat'      => 'bolumler/uretim/kalip_baslat.php',
        'uretim-kalip-ekle'         => 'bolumler/uretim/kalip_ekle.php',
        'uretim-kalip-devam'        => 'bolumler/uretim/kalip_devam.php',
        'uretim-kalip-tamamlanan'   => 'bolumler/uretim/kalip_tamamlanan.php',
        'uretim-kalip-ozet'         => 'bolumler/uretim/kalip_ozet.php',
        'kalite-dashboard'           => 'bolumler/kalite/dashboard.php',
        'kalite-denetim'             => 'bolumler/kalite/denetim.php',
        'kalite-denetim-form'        => 'bolumler/kalite/denetim_form.php',
        'kalite-denetim-detay'       => 'bolumler/kalite/denetim_detay.php',
        // DÖF
        'kalite-dof'                 => 'bolumler/kalite/dof.php',
        'kalite-dof-form'            => 'bolumler/kalite/dof_form.php',
        'kalite-dof-detay'           => 'bolumler/kalite/dof_detay.php',
        // 8D
        'kalite-8d'                  => 'bolumler/kalite/sekizd.php',
        'kalite-8d-form'             => 'bolumler/kalite/sekizd_form.php',
        'kalite-8d-detay'            => 'bolumler/kalite/sekizd_detay.php',
        // Kalite — Proje Yönetimi
        'kalite-proje'               => 'bolumler/kalite/proje_liste.php',
        'kalite-proje-form'          => 'bolumler/kalite/proje_form.php',
        'kalite-proje-detay'         => 'bolumler/kalite/proje_detay.php',
        'kalite-denetim'             => 'bolumler/kalite/denetim.php',
        'kalite-denetim-form'        => 'bolumler/kalite/denetim_form.php',
        'kalite-denetim-detay'       => 'bolumler/kalite/denetim_detay.php',
        // DÖF
        'kalite-dof'                 => 'bolumler/kalite/dof.php',
        'kalite-dof-form'            => 'bolumler/kalite/dof_form.php',
        'kalite-dof-detay'           => 'bolumler/kalite/dof_detay.php',
        // 8D
        'kalite-8d'                  => 'bolumler/kalite/sekizd.php',
        'kalite-8d-form'             => 'bolumler/kalite/sekizd_form.php',
        'kalite-8d-detay'            => 'bolumler/kalite/sekizd_detay.php',
        'kalite-hortum-test'           => 'bolumler/kalite/hortum_test.php',
        'kalite-tank-kapak-test'       => 'bolumler/kalite/tank_kapak_test.php',
        'kalite-hortum-ayarlar'         => 'bolumler/kalite/hortum_ayarlar.php',
        'kalite-hortum-sema'            => 'bolumler/kalite/hortum_sema.php',
        'kalite-hortum-recete'          => 'bolumler/kalite/hortum_recete.php',
        'kalite-hortum-gecmis'         => 'bolumler/kalite/hortum_gecmis.php',
        'kalite-miknatis-cihazlar'    => 'bolumler/kalite/miknatis_cihazlar.php',
        'kalite-miknatis-sema'         => 'bolumler/kalite/miknatis_sema.php',
        'kalite-miknatis-monitor'     => 'bolumler/kalite/miknatis_monitor.php',
        'kalite-miknatis-sonuclar'    => 'bolumler/kalite/miknatis_sonuclar.php',
        'kalite-kontrol'              => 'bolumler/kalite/kontrol.php',
        'kalite-final-kontrol'        => 'bolumler/kalite/final_kontrol.php',
        'kalite-final-liste'          => 'bolumler/kalite/final_kontrol_liste.php',
        'kalite-proses-ekle'           => 'bolumler/kalite/proses_ekle.php',
        'kalite-uygunsuzluk-liste'    => 'bolumler/kalite/uygunsuzluk_liste.php',
        'kalite-kalibrasyon-liste'        => 'bolumler/kalite/kalibrasyon_liste.php',
        'kalite-dokuman-listesi'         => 'bolumler/kalite/dokuman_listesi.php',
        'kalite-dis-iade-liste'          => 'bolumler/kalite/dis_iade_liste.php',
        'kalite-dis-iade-kontrol'        => 'bolumler/kalite/dis_iade_kontrol.php',
        'kalite-dis-iade-detay'          => 'bolumler/kalite/dis_iade_detay.php',
        'kalite-dis-iade-ozet'           => 'bolumler/kalite/dis_iade_ozet.php',
        'kalite-dokuman-listesi-pasif'   => 'bolumler/kalite/dokuman_listesi_pasif.php',
        'kalite-dokuman-duzenle'         => 'bolumler/kalite/dokuman_duzenle.php',
        'kalite-dokuman-test'           => 'bolumler/kalite/dokuman_test.php',
        'kalite-kalibrasyon-detay'         => 'bolumler/kalite/kalibrasyon_detay.php',
        'kalite-kalibrasyon-guncelle'      => 'bolumler/kalite/kalibrasyon_guncelle.php',
        'kalite-kalibrasyon-ekle'          => 'bolumler/kalite/kalibrasyon_guncelle.php',
        'kalite-kalibrasyon-kayit-ekle'    => 'bolumler/kalite/kalibrasyon_kayit_ekle.php',
        'kalite-uygunsuzluk-formu'    => 'bolumler/kalite/uygunsuzluk_formu.php',
        'kalite-uygunsuzluk-duzenle'  => 'bolumler/kalite/uygunsuzluk_duzenle.php',
        'kalite-uygunsuzluk-yazdir'   => 'bolumler/kalite/uygunsuzluk_yazdir.php',
        'uretim-verim-ekle'  => 'bolumler/uretim/verim_ekle.php',
        'uretim-verim-liste'      => 'bolumler/uretim/verim_liste.php',
        'uretim-verim-liste-tumu' => 'bolumler/uretim/verim_liste_tumu.php',
        'uretim-verim-montaj'       => 'bolumler/uretim/verim_ekle_montaj.php',
        'uretim-verim-liste-montaj'  => 'bolumler/uretim/verim_liste_montaj.php',
        'uretim-verim-personel'      => 'bolumler/uretim/verim_personel_rapor.php',
      ];

      // 2. Otomatik çözümleme: sayfa_id -> dosya yolu
      // Kural: modul-konu-alt -> bolumler/modul/konu_alt.php
      function sayfa_dosya_coz($sayfa_id, $base_dir) {
          // tire -> alt çizgi, ilk parça klasör adı
          $parcalar = explode('-', $sayfa_id);
          $modul    = $parcalar[0];
          $konu     = implode('_', array_slice($parcalar, 1));

          // Özel klasör eşlemeleri
          $klasor_map = [
              'ik'          => 'bolumler/ik',
              'satis'       => 'bolumler/satis',
              'satinalma'   => 'bolumler/satinalma',
              'depo'        => 'bolumler/depo',
              'uretim'      => 'bolumler/uretim',
              'planlama'    => 'bolumler/planlama',
              'kalite'      => 'bolumler/kalite',
              'idari'       => 'bolumler/idari',
              'tanim'       => 'bolumler/tanimlamalar',
              'raporlar'    => 'raporlar',
              'ayarlar'     => 'ayarlar',
          ];

          $klasor = $klasor_map[$modul] ?? null;
          if (!$klasor || !$konu) return null;

          $dosya = $base_dir . '/' . $klasor . '/' . $konu . '.php';
          return file_exists($dosya) ? $klasor . '/' . $konu . '.php' : null;
      }

      // 3. Route çözümle: önce özel map, sonra DB'den dosya_yolu, sonra otomatik
      $dosya = $sayfaMap_ozel[$sayfa] ?? null;
      if (!$dosya) {
          // DB'de dosya_yolu tanımlı mı?
          try {
              $dy = $db->prepare("SELECT dosya_yolu FROM menu_sayfalar WHERE sayfa_id=? AND dosya_yolu IS NOT NULL AND dosya_yolu != '' LIMIT 1");
              $dy->execute([$sayfa]);
              $dosya_db = $dy->fetchColumn();
              if ($dosya_db) $dosya = trim($dosya_db);
          } catch(Throwable $_dy) {}
      }
      if (!$dosya) {
          $dosya = sayfa_dosya_coz($sayfa, __DIR__);
      }

      // Windows/Linux uyumlu dosya yolu kontrolü
      $dosya_tam = null;
      if ($dosya) {
          $kontrol = [
              __DIR__ . '/' . $dosya,
              __DIR__ . '\\' . str_replace('/', '\\', $dosya),
              __DIR__ . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $dosya),
          ];
          foreach ($kontrol as $yol) {
              if (file_exists($yol)) { $dosya_tam = $yol; break; }
          }
          if (!$dosya_tam) {
              $rp = realpath(__DIR__ . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $dosya));
              if ($rp) $dosya_tam = $rp;
          }
      }
      if ($dosya_tam && file_exists($dosya_tam)) {
          // ── Yetki Kontrolü ──────────────────────────────────────────
          $kul    = Auth::kullanici();
          $rol_id = (int)($kul['rol_id'] ?? 0);
          $yetki_ok = false;

          // Herkese açık sayfalar
          $yetki_muaf = ['kullanici-profil', 'dashboard', 'guvenlik', 'ai-chat'];

          if (in_array($sayfa, $yetki_muaf)) {
              // Muaf sayfa — erişim serbest
              $yetki_ok = true;
          } else {
              // DB'den rol adını çek
              $_rol_adi_panel = '';
              try {
                  $rs = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
                  $rs->execute([$rol_id]);
                  $_rol_adi_panel = $rs->fetchColumn() ?: '';
              } catch(Throwable $_re) {}

              // Süper Admin -> tam yetki
              if ($rol_id === 1 || strtolower(trim($_rol_adi_panel)) === 'süper admin') {
                  $yetki_ok = true;
              } else {
                  // menu_rol_yetki'de bu role yetki var mı?
                  try {
                      $sp = $db->prepare("SELECT COUNT(*) FROM menu_rol_yetki WHERE rol=? AND sayfa_id=?");
                      $sp->execute([$_rol_adi_panel, $sayfa]);
                      $yetki_ok = ((int)$sp->fetchColumn() > 0);
                  } catch(Throwable $_me) {
                      // Tablo yoksa erişimi kapat
                      $yetki_ok = false;
                  }
              }
          }
          // ─────────────────────────────────────────────────────────────

          if ($yetki_ok) {
              // AJAX route ise sadece dosyayı çalıştır, HTML wrap etme
              if (strpos($sayfa, 'ajax-') === 0) {
                  include $dosya_tam;
                  exit;
              }
              include $dosya_tam;
          } else {
              echo '<div class="s-bar"><div><h1 class="s-bas">🔒 Erişim Reddedildi</h1></div></div>';
              echo '<div class="s-body"><div class="kart" style="padding:40px;text-align:center;color:var(--m2)">';
              echo '<div style="font-size:48px;margin-bottom:12px">🔒</div>';
              echo '<div style="font-size:16px;font-weight:700;margin-bottom:8px">Bu sayfaya erişim yetkiniz yok.</div>';
              echo '<div style="font-size:13px">Sistem yöneticinizle iletişime geçin.</div>';
              echo '</div></div>';
          }
      } else {
          if (isset($_GET['debug'])) {
              echo '<div style="background:#FEE2E2;padding:16px;border-radius:8px;margin:16px;font-family:monospace;font-size:12px">';
              echo '<b>DEBUG:</b><br>';
              echo 'sayfa: ' . htmlspecialchars($sayfa) . '<br>';
              echo '__DIR__: ' . htmlspecialchars(__DIR__) . '<br>';
              echo 'dosya: ' . htmlspecialchars($dosya ?? 'NULL') . '<br>';
              $test1 = __DIR__ . '/' . ($dosya ?? '');
              $test2 = __DIR__ . '\\' . str_replace('/', '\\', $dosya ?? '');
              echo 'test1: ' . htmlspecialchars($test1) . ' -> ' . (file_exists($test1)?'VAR':'YOK') . '<br>';
              echo 'test2: ' . htmlspecialchars($test2) . ' -> ' . (file_exists($test2)?'VAR':'YOK') . '<br>';
              echo 'dosya_tam: ' . htmlspecialchars($dosya_tam ?? 'NULL') . '<br>';
              echo '</div>';
          }
          include __DIR__ . '/paylasilan/bilesen/dashboard.php';
      }
      ?>
    </div>
  </main>
</div>

<?php include __DIR__ . '/paylasilan/bilesen/sag-panel.php'; ?>

<!-- Mobil overlay -->
<div class="mob-overlay" id="mobOverlay" onclick="drawerKapat()"></div>
<!-- Mobil drawer -->
<div class="mob-drawer" id="mobDrawer">
  <!-- JS ile doldurulur -->
</div>
<!-- Mobil alt bar -->
<div class="mob-alt-bar"><div class="mob-alt-ic" id="mobAltBar"></div></div>

<script>
  const BASE_URL    = '<?php echo BASE_URL; ?>';
  const KULLANICI   = JSON.parse(atob('<?php echo base64_encode(json_encode($kul)); ?>'));
  const AKTIF_SAYFA = '<?php echo htmlspecialchars($sayfa); ?>';

<?php
// -- DB'den menüyü çek, yetki filtrele, MODULLER JS değişkenine inject et --
try {
    $kul_m    = Auth::kullanici();
    $rol_id_m = (int)($kul_m['rol_id'] ?? 0);

    // Rol adını çek
    $rs_m = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
    $rs_m->execute([$rol_id_m]);
    $rol_adi_m = $rs_m->fetchColumn() ?: '';
    $super_m = ($rol_id_m === 1 || strtolower(trim($rol_adi_m)) === 'süper admin');

    // Yetkili sayfa_id listesi
    $yetkili_m = [];
    if (!$super_m) {
        $ry_m = $db->prepare("SELECT sayfa_id FROM menu_rol_yetki WHERE rol=?");
        $ry_m->execute([$rol_adi_m]);
        $yetkili_m = array_column($ry_m->fetchAll(PDO::FETCH_ASSOC), 'sayfa_id');
    }

    // Modülleri çek
    $mod_m = $db->query("SELECT modul_id,baslik,ikon,renk FROM menu_moduller WHERE aktif=1 ORDER BY sira")->fetchAll(PDO::FETCH_ASSOC);
    $grp_m = $db->query("SELECT id,modul_id,grup_adi FROM menu_gruplar WHERE aktif=1 ORDER BY modul_id,sira")->fetchAll(PDO::FETCH_ASSOC);
    $spy_m = $db->query("SELECT grup_id,modul_id,sayfa_id,baslik,ikon FROM menu_sayfalar WHERE aktif=1 ORDER BY grup_id,sira")->fetchAll(PDO::FETCH_ASSOC);

    // Sayfaları grup bazlı grupla ? yetki filtreli
    $spy_by_grp = [];
    foreach ($spy_m as $s) {
        if (!$super_m && !empty($yetkili_m) && !in_array($s['sayfa_id'], $yetkili_m)) continue;
        $spy_by_grp[$s['grup_id']][] = ['i'=>$s['ikon'],'m'=>$s['baslik'],'id'=>$s['sayfa_id']];
    }

    // Grupları modül bazlı grupla
    $grp_by_mod = [];
    foreach ($grp_m as $g) {
        if (empty($spy_by_grp[$g['id']])) continue;
        $grp_by_mod[$g['modul_id']][] = ['ad'=>$g['grup_adi'],'sayfalar'=>$spy_by_grp[$g['id']]];
    }

    // MODULLER objesi oluştur
    $moduller_js = [];
    foreach ($mod_m as $m) {
        $mid = $m['modul_id'];
        if (empty($grp_by_mod[$mid])) continue;
        $moduller_js[$mid] = [
            'baslik'  => $m['baslik'],
            'ikon'    => $m['ikon'],
            'renk'    => $m['renk'],
            'gruplar' => $grp_by_mod[$mid],
        ];
    }

    // Mobil bar ayarlarını çek
    $mob_ayar = [];
    try {
        $ma = $db->query("SELECT modul_id, sayfa_id FROM mobil_bar_ayarlar WHERE aktif=1 ORDER BY modul_id,sira");
        foreach($ma->fetchAll(PDO::FETCH_ASSOC) as $ma_r) {
            $mob_ayar[$ma_r['modul_id']][] = $ma_r['sayfa_id'];
        }
    } catch(Throwable $e_ma){}

    // Mobil bar sayfalarını MODULLER'e 'mob' bayrağı olarak işaretle
    foreach($moduller_js as $mid => &$mod_data) {
        $mob_ids = $mob_ayar[$mid] ?? [];
        if(!empty($mob_ids)) {
            // Tüm sayfalara mob bayrağı ve sıra ekle
            foreach($mod_data['gruplar'] as &$grp) {
                foreach($grp['sayfalar'] as &$sp) {
                    $mob_sira = array_search($sp['id'], $mob_ids);
                    $sp['mob'] = ($mob_sira !== false);
                    $sp['mob_sira'] = ($mob_sira !== false) ? (int)$mob_sira : 99;
                }
                unset($sp);
            }
            unset($grp);
        }
    }
    unset($mod_data);

    echo "  var MODULLER = JSON.parse(atob('" . base64_encode(json_encode($moduller_js)) . "'));\n";
    echo "  var MOB_AYAR = JSON.parse(atob('" . base64_encode(json_encode($mob_ayar)) . "'));\n";

} catch(Throwable $e_m) {
    // DB hatası -> panel.js'deki statik MODULLER kullanılır
    echo "  // DB menü yüklenemedi: " . htmlspecialchars($e_m->getMessage()) . "\n";
    echo "  var MODULLER = null;\n";
}
?>
</script>
<script src="<?php echo BASE_URL; ?>/paylasilan/js/uygulama.js?v=104"></script>
<script src="<?php echo BASE_URL; ?>/paylasilan/js/panel.js?v=104"></script>
  <!-- SheetJS (XLSX zaten head'e taşındı) -->
<!-- ── PWA Install Popup ─────────────────────────────────────────── -->
<style>
#pwa-install-box {
  position:fixed;bottom:20px;left:50%;transform:translateX(-50%);
  width:calc(100% - 32px);max-width:420px;
  background:linear-gradient(135deg,#1E293B 0%,#0F172A 100%);
  color:#fff;padding:16px 18px;border-radius:16px;
  display:none;z-index:9999;
  box-shadow:0 8px 32px rgba(0,0,0,.45);
  border:1px solid rgba(249,115,22,.3);
  animation:pwa-slide-up .4s ease;
}
@keyframes pwa-slide-up{from{opacity:0;transform:translateX(-50%) translateY(20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
#pwa-install-box .pwa-title{font-size:14px;font-weight:700;margin-bottom:4px;display:flex;align-items:center;gap:8px}
#pwa-install-box .pwa-desc{font-size:12px;color:#94A3B8;margin-bottom:12px}
#pwa-install-box .pwa-btns{display:flex;gap:8px}
#pwa-install-btn{flex:1;padding:10px;border:none;border-radius:10px;
  background:linear-gradient(135deg,#F97316,#EA580C);color:#fff;
  font-weight:700;font-size:13px;cursor:pointer}
#pwa-install-btn:hover{background:linear-gradient(135deg,#EA580C,#C2410C)}
#pwa-later-btn{padding:10px 14px;border:1px solid rgba(255,255,255,.2);
  border-radius:10px;background:transparent;color:#94A3B8;font-size:12px;cursor:pointer}
#pwa-close-btn{position:absolute;top:10px;right:12px;background:none;border:none;
  color:#64748B;font-size:18px;cursor:pointer;line-height:1;padding:2px 6px}
#pwa-close-btn:hover{color:#fff}
</style>

<div id="pwa-install-box">
  <button id="pwa-close-btn" onclick="pwaKapat(true)">✕</button>
  <div class="pwa-title">
    <img src="<?php echo BASE_URL;?>/icon-192.png" style="width:28px;height:28px;border-radius:6px"> Jetone ERP'yi Yükle
  </div>
  <div class="pwa-desc">📲 Telefon veya bilgisayarına uygulama olarak ekle -- hızlı, çevrimdışı erişim</div>
  <div class="pwa-btns">
    <button id="pwa-install-btn">⬇ Yükle</button>
    <button id="pwa-later-btn" onclick="pwaKapat(false)">Daha sonra</button>
  </div>
</div>

<script>
// Service Worker kayıt
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('<?php echo BASE_URL;?>/service-worker.js')
      .catch(function(){});
  });
}

// PWA Install Prompt
var _pwaPrompt = null;
window.addEventListener('beforeinstallprompt', function(e) {
  e.preventDefault();
  _pwaPrompt = e;
  // 24 saat geçmediyse gösterme
  var shown = localStorage.getItem('pwa_install_shown');
  var now = Date.now();
  if (!shown || (now - parseInt(shown)) > 86400000) {
    setTimeout(function() {
      document.getElementById('pwa-install-box').style.display = 'block';
    }, 3000);
  }
});

document.getElementById('pwa-install-btn').addEventListener('click', function() {
  if (!_pwaPrompt) return;
  _pwaPrompt.prompt();
  _pwaPrompt.userChoice.then(function(r) {
    document.getElementById('pwa-install-box').style.display = 'none';
    if (r.outcome === 'accepted') localStorage.setItem('pwa_install_shown', '99999999999999');
  });
  _pwaPrompt = null;
});

function pwaKapat(kalici) {
  document.getElementById('pwa-install-box').style.display = 'none';
  if (kalici) {
    localStorage.setItem('pwa_install_shown', Date.now().toString());
  }
}

// iOS Safari için ayrı mesaj
window.addEventListener('load', function() {
  var isIos = /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());
  var isStandalone = window.navigator.standalone === true;
  if (isIos && !isStandalone) {
    var shown = localStorage.getItem('pwa_ios_shown');
    if (!shown) {
      setTimeout(function() {
        var box = document.getElementById('pwa-install-box');
        box.querySelector('.pwa-title').innerHTML = '<img src="<?php echo BASE_URL;?>/icon-192.png" style="width:28px;height:28px;border-radius:6px"> iPhone\'a Ekle';
        box.querySelector('.pwa-desc').innerHTML = 'Ana ekrana ekle secenegini kullanin';
        box.querySelector('#pwa-install-btn').style.display = 'none';
        box.style.display = 'block';
        localStorage.setItem('pwa_ios_shown', '1');
      }, 3000);
    }
  }
});
</script>
<!-- ── AI CHAT WIDGET ─────────────────────────────────────────── -->
<style>
#ai-fab{position:fixed;bottom:24px;right:24px;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#667EEA,#764BA2);border:none;cursor:pointer;box-shadow:0 4px 20px rgba(102,126,234,.5);display:flex;align-items:center;justify-content:center;z-index:998;transition:transform .2s}
#ai-fab:hover{transform:scale(1.1)}
#ai-fab svg{width:26px;height:26px;fill:#fff}
#ai-panel{position:fixed;bottom:88px;right:24px;width:380px;max-width:calc(100vw - 32px);height:520px;max-height:calc(100vh - 110px);background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.2);display:none;flex-direction:column;z-index:999;border:1px solid #E2E8F0;overflow:hidden}
#ai-panel.acik{display:flex}
#ai-header{background:linear-gradient(135deg,#667EEA,#764BA2);padding:14px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0}
#ai-header-ikon{width:36px;height:36px;background:rgba(255,255,255,.2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px}
#ai-header-info{flex:1}
#ai-header-baslik{color:#fff;font-weight:700;font-size:13px}
#ai-header-durum{color:rgba(255,255,255,.7);font-size:10px}
#ai-kapat{background:none;border:none;color:rgba(255,255,255,.7);cursor:pointer;font-size:18px;padding:4px;line-height:1}
#ai-kapat:hover{color:#fff}
#ai-mesajlar{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px;background:#F8FAFC}
.ai-msg{max-width:88%;padding:9px 13px;border-radius:12px;font-size:12.5px;line-height:1.5;word-break:break-word}
.ai-msg.user{align-self:flex-end;background:#667EEA;color:#fff;border-radius:12px 12px 2px 12px}
.ai-msg.bot{align-self:flex-start;background:#fff;color:#1E293B;border:1px solid #E2E8F0;border-radius:12px 12px 12px 2px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.ai-msg.bot table{border-collapse:collapse;width:100%;margin:6px 0;font-size:11px}
.ai-msg.bot table th{background:#F1F5F9;padding:4px 8px;border:1px solid #CBD5E1;text-align:left}
.ai-msg.bot table td{padding:4px 8px;border:1px solid #E2E8F0}
.ai-msg.bot code{background:#F1F5F9;padding:1px 5px;border-radius:3px;font-size:11px}
.ai-msg.bot pre{background:#1E293B;color:#E2E8F0;padding:8px 10px;border-radius:6px;overflow-x:auto;font-size:11px;margin:4px 0}
.ai-msg.bot ul,.ai-msg.bot ol{padding-left:16px;margin:4px 0}
.ai-msg.bot li{margin:2px 0}
.ai-msg.bot strong{font-weight:700}
.ai-typing{align-self:flex-start;background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:10px 14px;display:flex;gap:4px;align-items:center}
.ai-typing span{width:7px;height:7px;background:#94A3B8;border-radius:50%;animation:aiBounce 1.2s infinite}
.ai-typing span:nth-child(2){animation-delay:.2s}
.ai-typing span:nth-child(3){animation-delay:.4s}
@keyframes aiBounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}}
#ai-footer{padding:10px 12px;border-top:1px solid #E2E8F0;display:flex;gap:8px;align-items:center;background:#fff;flex-shrink:0}
#ai-input{flex:1;border:1px solid #E2E8F0;border-radius:20px;padding:8px 14px;font-size:12px;outline:none;font-family:inherit;resize:none;max-height:80px;overflow-y:auto;line-height:1.4}
#ai-input:focus{border-color:#667EEA}
#ai-gonder{width:36px;height:36px;border-radius:50%;background:#667EEA;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .2s}
#ai-gonder:hover{background:#5B6FD1}
#ai-gonder:disabled{background:#CBD5E1;cursor:not-allowed}
#ai-gonder svg{width:16px;height:16px;fill:#fff}
.ai-oneri-btn{background:#EEF2FF;color:#667EEA;border:1px solid #C7D2FE;border-radius:16px;padding:5px 11px;font-size:11px;cursor:pointer;white-space:nowrap;transition:background .15s}
.ai-oneri-btn:hover{background:#E0E7FF}
#ai-oneriler{padding:0 12px 8px;display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0}
</style>

<!-- FAB Butonu -->
<button id="ai-fab" onclick="aiToggle()" title="AI Asistan">
  <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/><path d="M0 0h24v24H0z" fill="none"/><path d="M9 9h2v6H9zm4 0h2v6h-2z" style="display:none"/></svg>
  <svg viewBox="0 0 24 24" style="position:absolute"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
</button>

<!-- Chat Panel -->
<div id="ai-panel">
  <div id="ai-header">
    <div id="ai-header-ikon">🤖</div>
    <div id="ai-header-info">
      <div id="ai-header-baslik">Jetone AI Asistan</div>
      <div id="ai-header-durum">● Çevrimiçi · Veritabanına erişimli</div>
    </div>
    <button id="ai-kapat" onclick="aiToggle()" style="background:none;border:none;color:rgba(255,255,255,.7);cursor:pointer;font-size:18px;padding:4px;line-height:1">✕</button>
    <button onclick="aiTemizle()" title="Konuşmayı sıfırla" style="background:none;border:none;color:rgba(255,255,255,.5);cursor:pointer;font-size:13px;padding:4px;line-height:1" title="Sıfırla">🔄</button>
  </div>
  <div id="ai-mesajlar">
    <div class="ai-msg bot">Merhaba! 👋 Ben Jetone ERP asistanıyım.<br><br>Sipariş durumlarını, üretim planını, personel bilgilerini ve stok verilerini gerçek zamanlı veritabanı verilerine dayanarak cevaplayabilirim.<br><br>Ne öğrenmek istersiniz?</div>
  </div>
  <div id="ai-oneriler">
    <button class="ai-oneri-btn" onclick="aiSor(this.textContent)">📦 Aktif siparişler</button>
    <button class="ai-oneri-btn" onclick="aiSor(this.textContent)">🏭 Üretim durumu</button>
    <button class="ai-oneri-btn" onclick="aiSor(this.textContent)">👷 Bugün kaç kişi geldi?</button>
    <button class="ai-oneri-btn" onclick="aiSor(this.textContent)">⚠️ Kritik stoklar</button>
  </div>
  <div id="ai-footer">
    <textarea id="ai-input" placeholder="Soru sorun..." rows="1"
      onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();aiGonder()}"></textarea>
    <button id="ai-gonder" onclick="aiGonder()">
      <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
    </button>
  </div>
</div>

<script>
var _aiGecmis = [];
var _aiAcik = false;
var _aiYukleniyor = false;

function aiTemizle() {
  _aiGecmis = [];
  var m = document.getElementById('ai-mesajlar');
  m.innerHTML = '<div class="ai-msg bot">Konuşma sıfırlandı. Yeni soru sorabilirsiniz.</div>';
  document.getElementById('ai-oneriler').style.display = 'flex';
}

function aiToggle() {
  _aiAcik = !_aiAcik;
  document.getElementById('ai-panel').classList.toggle('acik', _aiAcik);
  if (_aiAcik) {
    setTimeout(function(){ document.getElementById('ai-input').focus(); }, 100);
  }
}

function aiSor(metin) {
  document.getElementById('ai-input').value = metin;
  aiGonder();
}

function aiGonder() {
  if (_aiYukleniyor) return;
  var inp = document.getElementById('ai-input');
  var soru = inp.value.trim();
  if (!soru) return;
  inp.value = '';
  inp.style.height = '';
  aiMesajEkle('user', soru);
  aiCagir(soru, null);
}

function aiCagir(soru, sql_run) {
  _aiYukleniyor = true;
  document.getElementById('ai-gonder').disabled = true;
  document.getElementById('ai-oneriler').style.display = 'none';

  var typing = document.createElement('div');
  typing.className = 'ai-typing';
  typing.id = 'ai-typing';
  typing.innerHTML = '<span></span><span></span><span></span>';
  if (sql_run) {
    var bilgi = document.createElement('div');
    bilgi.style.cssText = 'font-size:10px;color:#667EEA;padding:2px 4px';
    bilgi.textContent = '[ARA] Veritabanı sorgulanıyor...';
    typing.appendChild(bilgi);
  }
  document.getElementById('ai-mesajlar').appendChild(typing);
  aiScrollAlt();

  var fd = new FormData();
  fd.append('soru', soru);
  fd.append('gecmis', JSON.stringify(_aiGecmis));
  if (sql_run) fd.append('sql_run', JSON.stringify(sql_run));

  fetch('<?php echo BASE_URL;?>/bolumler/planlama/ajax/ai_chat.php', {
    method: 'POST', body: fd, credentials: 'same-origin',
    headers: {'X-Requested-With': 'XMLHttpRequest'}
  })
  .then(function(r){ return r.text().then(function(txt){
    try { return JSON.parse(txt); }
    catch(e){ return {ok:false, msg:'Sunucu hatasi: ' + txt.substring(0,300)}; }
  }); })
  .then(function(d) {
    var t = document.getElementById('ai-typing');
    if (t) t.remove();
    _aiYukleniyor = false;
    document.getElementById('ai-gonder').disabled = false;
    if (!d.ok) { aiMesajEkle('bot', '[HATA] ' + (d.msg||'Hata')); return; }

    if (!sql_run) _aiGecmis.push({role:'user', content:soru});
    _aiGecmis.push({role:'assistant', content:d.cevap});
    if (_aiGecmis.length > 20) _aiGecmis = _aiGecmis.slice(-20);

    if (d.action === 'navigate' && d.navigate) {
      aiMesajEkle('bot', '[SOR] ' + d.cevap);
      setTimeout(function(){ window.location.href = BASE_URL + '/panel.php?sayfa=' + d.navigate; }, 800);
    } else if (d.action === 'query' && d.sql_run && !sql_run) {
      // Sadece 1 tur sorgu ? sql_run zaten varsa (2. tur) tekrar sorgu döngüsüne girme
      aiMesajEkle('bot', '[ARA] ' + d.cevap);
      setTimeout(function(){ aiCagir(soru, d.sql_run); }, 200);
    } else if (d.action === 'query' && d.sql_run && sql_run) {
      // 2. turda tekrar query geldi ? zorla normal cevap olarak göster
      aiMesajEkle('bot', d.cevap || 'Sorgu tamamlandı.');
    } else if (d.action === 'ask' && d.ask) {
      aiMesajEkle('bot', d.cevap);
      var inp2 = document.getElementById('ai-input');
      if (d.ask_ipucu) { inp2.placeholder = d.ask_ipucu; setTimeout(function(){ inp2.placeholder='Soru sorun...'; }, 10000); }
      inp2.focus();
    } else {
      aiMesajEkle('bot', d.cevap);
    }
    if (d.debug_ctx) {
      var dbg = document.createElement('div');
      dbg.style.cssText = 'font-size:10px;color:#94A3B8;padding:2px 13px;font-style:italic';
      dbg.textContent = '[VER] ' + d.debug_ctx;
      document.getElementById('ai-mesajlar').appendChild(dbg);
    }
  })
  .catch(function(e) {
    var t = document.getElementById('ai-typing');
    if (t) t.remove();
    _aiYukleniyor = false;
    document.getElementById('ai-gonder').disabled = false;
    aiMesajEkle('bot', '[HATA] Baglanti hatasi: ' + e.message);
  });
}
function aiMesajEkle(rol, metin) {
  var el = document.createElement('div');
  el.className = 'ai-msg ' + rol;
  if (rol === 'bot') {
    el.innerHTML = aiMarkdown(metin);
  } else {
    el.textContent = metin;
  }
  document.getElementById('ai-mesajlar').appendChild(el);
  aiScrollAlt();
}

function aiScrollAlt() {
  var m = document.getElementById('ai-mesajlar');
  m.scrollTop = m.scrollHeight;
}

// Basit Markdown render
function aiMarkdown(text) {
  // Kod blokları
  text = text.replace(/```[\w]*\n?([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
  // İnline kod
  text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Bold
  text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  // Başlıklar
  text = text.replace(/^### (.+)$/gm, '<strong style="font-size:13px;color:#1E3A5F">$1</strong>');
  text = text.replace(/^## (.+)$/gm, '<strong style="font-size:14px;color:#1E3A5F">$1</strong>');
  text = text.replace(/^# (.+)$/gm, '<strong style="font-size:15px;color:#1E3A5F">$1</strong>');
  // Liste
  text = text.replace(/^\* (.+)$/gm, '<li>$1</li>');
  text = text.replace(/^- (.+)$/gm, '<li>$1</li>');
  text = text.replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>');
  text = text.replace(/(<li>[\s\S]+<\/li>)/g, '<ul>$1</ul>');
  // Tablo (basit)
  var lines = text.split('\n');
  var result = [];
  var inTable = false;
  var tableRows = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.startsWith('|') && line.endsWith('|')) {
      if (!inTable) { inTable = true; tableRows = []; }
      if (!line.match(/^\|[-:| ]+\|$/)) tableRows.push(line);
    } else {
      if (inTable) {
        result.push(aiRenderTablo(tableRows));
        inTable = false; tableRows = [];
      }
      result.push(line);
    }
  }
  if (inTable) result.push(aiRenderTablo(tableRows));
  text = result.join('\n');
  // Satır sonları
  text = text.replace(/\n/g, '<br>');
  // Çift br temizle
  text = text.replace(/(<br>){3,}/g, '<br><br>');
  return text;
}

function aiRenderTablo(rows) {
  if (!rows.length) return '';
  var html = '<table>';
  rows.forEach(function(row, i) {
    var cells = row.split('|').filter(function(c){ return c.trim() !== ''; });
    var tag = i === 0 ? 'th' : 'td';
    html += '<tr>' + cells.map(function(c){ return '<'+tag+'>'+c.trim()+'</'+tag+'>'; }).join('') + '</tr>';
  });
  return html + '</table>';
}

// Textarea otomatik yükseklik
document.getElementById('ai-input').addEventListener('input', function() {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 80) + 'px';
});
</script>
</body>
</html>
