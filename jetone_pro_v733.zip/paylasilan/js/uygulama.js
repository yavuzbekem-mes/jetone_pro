/**
 * JETONE.PRO — Ortak JS Yardımcıları
 * paylasilan/js/uygulama.js
 */

const JT = {

  /** AJAX POST isteği (JSON döndürür) */
  ajax: async function(url, veri = {}, metot = 'POST') {
    try {
      const res = await fetch(url, {
        method:      metot,
        credentials: 'same-origin',
        headers:     { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body:        metot !== 'GET' ? JSON.stringify(veri) : undefined,
      });

      if (res.status === 401) {
        JT.bildirim('Oturum süreniz doldu. Yönlendiriliyorsunuz...', 'uyari');
        const loginUrl = typeof BASE_URL !== 'undefined' ? BASE_URL + '/giris.php' : '/giris.php';
        setTimeout(() => window.location.href = loginUrl, 2000);
        return { ok: false };
      }

      // JSON olmayan yanıt varsa (PHP hatası HTML döndürdüyse)
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('json')) {
        const text = await res.text();
        console.error('[JT.ajax] JSON değil:', text.substring(0, 200));
        return { ok: false, hata: 'Sunucu JSON döndürmedi (PHP hatası olabilir)' };
      }

      return await res.json();
    } catch (e) {
      console.error('[JT.ajax]', e);
      JT.bildirim('Bağlantı hatası: ' + e.message, 'hata');
      return { ok: false, hata: e.message };
    }
  },

  /** Bildirim toast */
  bildirim: function(mesaj, tip = 'bilgi', sure = 3500) {
    const renkler = {
      basari: { bg: '#D1FADF', renk: '#0A8F4E', ikon: '✅' },
      hata:   { bg: '#FEE4E2', renk: '#F04438', ikon: '❌' },
      uyari:  { bg: '#FEF0C7', renk: '#B45309', ikon: '⚠️' },
      bilgi:  { bg: '#E0F2FE', renk: '#0284C7', ikon: 'ℹ️' },
    };
    const r = renkler[tip] || renkler.bilgi;

    const el = document.createElement('div');
    el.style.cssText = `
      position:fixed; bottom:80px; right:20px; z-index:9999;
      background:${r.bg}; color:${r.renk};
      padding:12px 20px; border-radius:10px;
      font-weight:700; font-size:13px;
      box-shadow:0 8px 24px rgba(0,0,0,.15);
      border-left:4px solid ${r.renk};
      display:flex; align-items:center; gap:8px;
      animation:slideIn .3s ease; max-width:360px; word-break:break-word;
      font-family:'Plus Jakarta Sans',sans-serif;
    `;
    el.innerHTML = `<span>${r.ikon}</span><span>${mesaj}</span>`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), sure);
  },

  /** Onay dialogu */
  onayla: function(mesaj, onYes) {
    if (confirm(mesaj)) onYes();
  },

  /** Formu nesneye çevir */
  formVeri: function(formId) {
    const form = typeof formId === 'string'
      ? document.getElementById(formId)
      : formId;
    return Object.fromEntries(new FormData(form));
  },

  /** Yükleniyor durumu */
  yukle: function(el, durum = true) {
    if (!el) return;
    if (durum) {
      el._orgText = el.innerHTML;
      el.disabled = true;
      el.innerHTML = '<span style="opacity:.6">⏳ Yükleniyor...</span>';
    } else {
      el.disabled  = false;
      el.innerHTML = el._orgText || el.innerHTML;
    }
  },

  /** Para formatla */
  para: function(tutar, birim = '₺') {
    return birim + ' ' + parseFloat(tutar || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2 });
  },

  /** Tarih formatla */
  tarih: function(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    return d.toLocaleDateString('tr-TR');
  },

  /** Sayfa yüklenirken form kaydet olaylarını bağla */
  formKaydetBagla: function() {
    document.querySelectorAll('form[data-ajax]').forEach(form => {
      form.addEventListener('submit', async e => {
        e.preventDefault();
        const url = form.dataset.ajax;
        const btn = form.querySelector('[type=submit]');
        JT.yukle(btn, true);
        const r = await JT.ajax(url, JT.formVeri(form));
        JT.yukle(btn, false);
        if (r.ok) {
          JT.bildirim(r.mesaj || 'Kaydedildi!', 'basari');
          if (r.yonlendir) setTimeout(() => location.href = r.yonlendir, 1000);
        } else {
          JT.bildirim(r.hata || 'Hata oluştu.', 'hata');
        }
      });
    });
  }
};

// CSS animasyon
const style = document.createElement('style');
style.textContent = `@keyframes slideIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`;
document.head.appendChild(style);

// Form kaydet olaylarını otomatik bağla
document.addEventListener('DOMContentLoaded', () => JT.formKaydetBagla());
