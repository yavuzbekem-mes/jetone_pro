/**
 * JETONE.PRO — Panel JS
 * paylasilan/js/panel.js
 */

/* ── MODÜL VERİSİ ── */
// MODULLER panel.php'den PHP/DB ile inject edilir (var MODULLER = {...})
// Inject edilmemişse veya null ise aşağıdaki statik fallback kullanılır
if (typeof MODULLER === 'undefined' || MODULLER === null) {
var MODULLER = {
  dashboard:   { baslik:'Dashboard', ikon:'🏠', renk:'#FEF3E8', gruplar:[{ad:'GENEL',sayfalar:[{i:'🏠',m:'Dashboard',id:'dashboard',a:true},{i:'📊',m:'Analitik',id:'analitik'},{i:'📈',m:'KPI',id:'kpi'}]}]},
  ik:          { baslik:'İnsan Kaynakları', ikon:'👥', renk:'#E0F2FE', gruplar:[
    {ad:'PERSONEL',sayfalar:[{i:'👤',m:'Personeller',id:'ik-personeller',a:true},{i:'🆕',m:'Personel Ekle',id:'ik-ekle'},{i:'🏢',m:'Departmanlar',id:'ik-departmanlar'}]},
    {ad:'DEVAM & İZİN',sayfalar:[{i:'✅',m:'Devam Kayıtları',id:'ik-devam',a:true},{i:'📊',m:'Günlük Özet',id:'ik-devam-ozet'},{i:'🏖',m:'İzin Talepleri',id:'ik-izinler'},{i:'⏰',m:'Fazla Mesai',id:'ik-mesai'},{i:'🗓',m:'Vardiya',id:'ik-vardiya'},{i:'💡',m:'Öneri & Şikayet',id:'ik-oneri'}]},
    {ad:'BORDRO',sayfalar:[{i:'📋',m:'Bordro',id:'ik-bordro'}]},
    {ad:'ANALİZ',sayfalar:[{i:'📊',m:'Turnover Raporu',id:'ik-turnover'},{i:'😊',m:'Memnuniyet Anketi',id:'ik-anket',a:true}]},
    {ad:'DİSİPLİN',sayfalar:[{i:'⚠️',m:'İhtar Tutanakları',id:'ik-ihtar-listesi',a:true},{i:'➕',m:'Yeni İhtar',id:'ik-ihtar-form'}]},
    {ad:'DUYURULAR',sayfalar:[{i:'📢',m:'Duyurular',id:'ik-duyuru-listesi',a:true},{i:'➕',m:'Yeni Duyuru',id:'ik-duyuru-form'}]},
    {ad:'PERFORMANS',sayfalar:[{i:'📊',m:'Değerlendirmeler',id:'ik-perf-listesi',a:true},{i:'➕',m:'Yeni Değerlendirme',id:'ik-perf-form'}]}
  ]},
  satis:       { baslik:'Satış & CRM', ikon:'💼', renk:'#D1FADF', gruplar:[
    {ad:'SATIŞ',sayfalar:[{i:'📊',m:'Dashboard',id:'satis-dashboard',a:true}]},
    {ad:'GENEL SİPARİŞLER',sayfalar:[{i:'🛍',m:'Siparişler',id:'satis-siparisler'},{i:'⚡',m:'JIT Siparişler',id:'satis-jit-siparisler'}]},
    {ad:'TOPLAMA',sayfalar:[{i:'🚛',m:'Genel Toplama Listesi',id:'satis-siparisler'},{i:'🚛',m:'JIT Toplama Listesi',id:'satis-jit-toplama'}]},
    {ad:'KONTROL',sayfalar:[{i:'📊',m:'JIT Günlük Stok Kontrol',id:'satis-jit-stok-kontrol'},{i:'⏱',m:'JIT Saatlik Kontrol',id:'satis-jit-saatlik'},{i:'📦',m:'Genel Stok Kontrol',id:'satis-stok-kontrol'}]},
    {ad:'RAPORLAR',sayfalar:[{i:'📊',m:'Satış + Sipariş Durumu',id:'satis-siparis-durum'}]},
    {ad:'MÜŞTERİLER',sayfalar:[{i:'👥',m:'Müşteri Listesi',id:'satis-musteriler'},{i:'📄',m:'Teklifler',id:'satis-teklifler'}]},
    {ad:'PACKING LIST',sayfalar:[{i:'📦',m:'Packing List',id:'satis-packing-list'}]},
    {ad:'İRSALİYE',sayfalar:[{i:'📦',m:'Yeni İrsaliyeler',id:'satis-yeni-irsaliye'},{i:'✅',m:'Düşülen İrsaliyeler',id:'satis-dusule-irsaliye'},{i:'↩️',m:'İade İrsaliyeleri',id:'satis-iade-irsaliyeler'}]}
  ]},
  satinalma:   { baslik:'Satınalma', ikon:'🛒', renk:'#FEF0C7', gruplar:[
    {ad:'GENEL',sayfalar:[{i:'📊',m:'Dashboard',id:'satinalma-dashboard',a:true}]},
    {ad:'SİPARİŞLER',sayfalar:[{i:'🛒',m:'Açık Siparişler',id:'satinalma-acik-sip'},{i:'✅',m:'Tamamlanan Siparişler',id:'satinalma-tam-sip'}]},
    {ad:'İRSALİYE',sayfalar:[{i:'📥',m:'Satınalma İrsaliyeleri',id:'satinalma-irs'},{i:'↩️',m:'İade İrsaliyeleri',id:'satinalma-iade-irs'}]},
    {ad:'MRP',sayfalar:[{i:'📊',m:'Malzeme İhtiyaç Analizi',id:'satinalma-mrp'},{i:'🧮',m:'Malzeme İhtiyaç Hesaplama',id:'satinalma-mih'}]},
    {ad:'ORTEL İHTİYAÇ',sayfalar:[{i:'🔧',m:'Ortel Reçeteler',id:'satinalma-ortel-recete'},{i:'📊',m:'Ortel İhtiyaç',id:'satinalma-ortel-ihtiyac'}]},
    {ad:'SEFER TAKİP',sayfalar:[{i:'🚛',m:'İstanbul Sefer Takip',id:'satinalma-sefer'}]},
    {ad:'TEDARİKÇİLER',sayfalar:[{i:'🏭',m:'Tedarikçiler',id:'satinalma-tedarikciler'},{i:'🔧',m:'Tanımlı Kodlar',id:'satinalma-tanimli-ted'},{i:'📈',m:'Tedarikçi Performansı',id:'satinalma-performans'}]}
  ]},
  uretim:      { baslik:'Üretim', ikon:'🏭', renk:'#FEE4E2', gruplar:[
    {ad:'PLANLAMA',sayfalar:[{i:'⚙',m:'İş Emirleri',id:'uretim-is-emirleri',a:true},{i:'📐',m:'Reçeteler',id:'uretim-recete'},{i:'🗓',m:'Çizelge',id:'uretim-cizelge'}]},
    {ad:'VERİMLİLİK',sayfalar:[{i:'📊',m:'OEE',id:'uretim-oee'}]}
  ]},
  planlama:    { baslik:'Planlama', ikon:'🗂', renk:'#E0F2FE', gruplar:[
    {ad:'MRP/MPS',sayfalar:[{i:'🔄',m:'MRP',id:'planlama-mrp',a:true},{i:'📦',m:'Malzeme İhtiyaç',id:'planlama-mih'},{i:'🎯',m:'Öncelik Analizi',id:'planlama-oncelik'},{i:'📅',m:'MPS',id:'planlama-mps'}]},
    {ad:'ENJEKSİYON',sayfalar:[{i:'📊',m:'Gantt Planı',id:'planlama-gantt'},{i:'📋',m:'Günlük Plan',id:'planlama-gunluk'},{i:'🏭',m:'ÜE Planlama',id:'planlama-ue'}]},
    {ad:'MONTAJ',sayfalar:[{i:'🔧',m:'Montaj Planı',id:'planlama-montaj'}]},
    {ad:'KAPASİTE',sayfalar:[{i:'🏭',m:'Kapasite',id:'planlama-kapasite'}]},
    {ad:'KPI',sayfalar:[{i:'📊',m:'KPI Özet',id:'planlama-kpi-ozet'}]}
  ]},
  kalite:      { baslik:'Kalite', ikon:'✅', renk:'#D1FADF', gruplar:[
    {ad:'KONTROL',sayfalar:[{i:'🔍',m:'Kontrol',id:'kalite-kontrol',a:true},{i:'⚠',m:'DÖF',id:'kalite-dof'}]},
    {ad:'DENETİM',sayfalar:[{i:'🎯',m:'Denetimler',id:'kalite-denetim'}]}
  ]},
  depo:        { baslik:'Depo & Sevkiyat', ikon:'📦', renk:'#FEF0C7', gruplar:[
    {ad:'STOK',sayfalar:[{i:'📦',m:'Stok Raporu',id:'depo-stok',a:true},{i:'📍',m:'Adresli Stok',id:'depo-adresli-stok'},{i:'↕',m:'Stok Hareketleri',id:'depo-hareketler'},{i:'📦',m:'Paket Hareketleri',id:'depo-paket-hareketler'},{i:'📟',m:'Terminal Kullanım',id:'depo-terminal'}]},
    {ad:'SEVKİYAT',sayfalar:[{i:'🚚',m:'Sevkiyat',id:'depo-sevkiyat'},{i:'📄',m:'İrsaliyeler',id:'depo-irsaliye'}]}
  ]},
  idari:       { baslik:'İdari İşler', ikon:'🏢', renk:'#F4F5F7', gruplar:[
    {ad:'İDARİ',sayfalar:[{i:'🏢',m:'Firma Bilgileri',id:'idari-firma',a:true},{i:'📋',m:'Evrak Takibi',id:'idari-evrak',a:true}]},
    {ad:'ORGANİZASYON',sayfalar:[{i:'🚌',m:'Servis Yönetimi',id:'idari-servis',a:true},{i:'🍽',m:'Yemek & Menü',id:'idari-yemek'},{i:'🎉',m:'Etkinlikler',id:'idari-etkinlik'}]},
    {ad:'SATINALMA',sayfalar:[{i:'🛒',m:'Satınalma Talepleri',id:'idari-satin-talepler'},{i:'➕',m:'Yeni Talep',id:'idari-satin-yeni'}]},
    {ad:'ARAÇ & FİLO',sayfalar:[{i:'🚗',m:'Araçlar',id:'idari-arac-listesi',a:true},{i:'⛽',m:'Yakıt Takibi',id:'idari-arac-yakit'},{i:'🔧',m:'Bakım Kayıtları',id:'idari-arac-bakim'},{i:'📍',m:'Görev / Seferler',id:'idari-arac-gorev'}]},
    {ad:'TEKLİF & SÖZLEŞME',sayfalar:[{i:'📋',m:'Teklifler',id:'idari-teklif-listesi',a:true},{i:'📄',m:'Sözleşmeler',id:'idari-sozlesme-listesi'}]}
  ]},
  raporlar:    { baslik:'Raporlar', ikon:'📊', renk:'#E0F2FE', gruplar:[
    {ad:'RAPORLAR',sayfalar:[{i:'📊',m:'Genel',id:'raporlar-genel',a:true},{i:'📋',m:'TÜİK Verileri',id:'raporlar-tuik'},{i:'🔢',m:'Sayım Performansı',id:'raporlar-sayim'}]}
  ]},
  tanimlamalar: { baslik:'Tanımlamalar', ikon:'📐', renk:'#EFF6FF', gruplar:[
    {ad:'ÜRETİM TANIMLARI',sayfalar:[{i:'🧱',m:'Malzeme Tanımları',id:'tanim-malzeme',a:true},{i:'⚙️',m:'Operasyon Tanımları',id:'tanim-operasyon'},{i:'📋',m:'Reçete Tanımları',id:'tanim-recete'},{i:'🏭',m:'İş İstasyonu Tanımları',id:'tanim-istasyon'},{i:'📦',m:'Stok Durumu',id:'tanim-stok'},{i:'🏭',m:'Üretim Emirleri',id:'tanim-ue'}]}
  ]},
  ayarlar:     { baslik:'Ayarlar', ikon:'⚙️', renk:'#F4F5F7', gruplar:[{ad:'AYARLAR',sayfalar:[
    {i:'🏢',m:'Firma Bilgileri',id:'ayarlar-firma'},{i:'🌍',m:'Bölgesel',id:'ayarlar-bolgesel'},
    {i:'🎭',m:'Roller & Yetkiler',id:'ayarlar-roller'},{i:'👤',m:'ERP Kullanıcıları',id:'ayarlar-kullanici'},
    {i:'🌐',m:'Portal Kullanıcıları',id:'ayarlar-portal'},{i:'📍',m:'Geofence',id:'ayarlar-geofence'},
    {i:'🔌',m:'Entegrasyonlar',id:'ayarlar-enteg'}
  ]}]}
}; } // end MODULLER fallback

var aktifModul = 'dashboard';
var aktifAltBarSayfa = 'dashboard';

/* ── MODÜL SEÇ — sidebar PHP ile render edildi, JS sadece geçiş için ── */
function modulSec(id, btn) {
  aktifModul = id;

  // Masaüstü ikon aktif
  var tumMb = document.querySelectorAll('.mb');
  for (var i = 0; i < tumMb.length; i++) tumMb[i].classList.remove('aktif');
  if (btn) {
    btn.classList.add('aktif');
  } else {
    var b = document.querySelector('.mb[data-tip="' + (MODULLER[id] ? MODULLER[id].baslik : '') + '"]');
    if (b) b.classList.add('aktif');
  }

  // Sidebar zaten PHP ile dolu - sadece farklı modüle geçişte sayfaya git
  var sb = document.getElementById('modulSb');
  if (!sb) return;

  // Sidebar zaten bu modülün içeriğini gösteriyorsa sadece aktif sınıfı düzelt
  var mevcutAd = sb.querySelector('.msb-ad');
  var veri = MODULLER[id];
  if (mevcutAd && veri && mevcutAd.textContent.trim() === veri.baslik) {
    // Aynı modül - sadece nav-it aktif sınıfını güncelle
    var tumNavIt = sb.querySelectorAll('.nav-it');
    for (var i = 0; i < tumNavIt.length; i++) {
      tumNavIt[i].classList.toggle('aktif', tumNavIt[i].dataset.sayfa === aktifAltBarSayfa);
    }
    return;
  }

  // Farklı modüle geçiş - ilk sayfaya git
  if (!veri) return;
  // dashboard için özel: direkt dashboard sayfasına git
  if (id === 'dashboard') {
    if (aktifAltBarSayfa !== 'dashboard') {
      window.location.href = BASE_URL + '/panel.php?sayfa=dashboard';
    }
    return;
  }
  // Sidebar'ı JS ile doldur
  if (veri.gruplar) {
    var ilkSayfa = null;
    for (var g = 0; g < veri.gruplar.length; g++) {
      for (var s = 0; s < veri.gruplar[g].sayfalar.length; s++) {
        if (veri.gruplar[g].sayfalar[s].a) { ilkSayfa = veri.gruplar[g].sayfalar[s].id; break; }
      }
      if (ilkSayfa) break;
    }
    if (!ilkSayfa && veri.gruplar[0] && veri.gruplar[0].sayfalar[0]) ilkSayfa = veri.gruplar[0].sayfalar[0].id;

    // Aktif sayfa bu modülde mi? (prefix kontrolü)
    var aktifBuModulde = (aktifAltBarSayfa === id) || aktifAltBarSayfa.startsWith(id + '-');
    // Aktif sayfa tüm modül sayfaları arasında mı?
    var aktifListede = false;
    for (var g2 = 0; g2 < veri.gruplar.length; g2++) {
      for (var s2 = 0; s2 < veri.gruplar[g2].sayfalar.length; s2++) {
        if (veri.gruplar[g2].sayfalar[s2].id === aktifAltBarSayfa) { aktifListede = true; break; }
      }
    }

    if (aktifBuModulde || aktifListede) {
      // Bu modüldeyiz - sidebar'ı doldur ama redirect yapma
      var sbHtml = '<div class="msb-baslik" style="justify-content:space-between;cursor:pointer" onclick="toggleModulSb()" title="Menüyü gizle/göster">'
        + '<div style="display:flex;align-items:center;gap:10px;overflow:hidden">'
        + '<div class="msb-ikon" style="background:' + (veri.renk||'#E0F2FE') + '">' + (veri.ikon||'🗂') + '</div>'
        + '<div class="msb-ad">' + veri.baslik + '</div>'
        + '</div>'
        + '<button id="sbToggleBtn" onclick="event.stopPropagation();toggleModulSb()" style="background:none;border:none;cursor:pointer;color:var(--m2);font-size:16px;padding:4px 6px;border-radius:6px;flex-shrink:0;line-height:1" title="Menüyü gizle">◀</button>'
        + '</div>'
        + '<div class="msb-ic">';
      for (var g3 = 0; g3 < veri.gruplar.length; g3++) {
        var grp = veri.gruplar[g3];
        sbHtml += '<div class="msb-grup"><div class="msb-grup-ad">' + (grp.ad||'') + '</div>';
        for (var s3 = 0; s3 < grp.sayfalar.length; s3++) {
          var sp = grp.sayfalar[s3];
          var aktifClass = sp.id === aktifAltBarSayfa ? ' aktif' : '';
          sbHtml += '<a class="nav-it' + aktifClass + '" data-sayfa="' + sp.id + '" href="' + BASE_URL + '/panel.php?sayfa=' + encodeURIComponent(sp.id) + '">'
            + '<span class="ni-ikon">' + (sp.i||'') + '</span>'
            + '<span class="ni-metin">' + (sp.m||'') + '</span></a>';
        }
        sbHtml += '</div>';
      }
      sbHtml += '</div>';
      sb.innerHTML = sbHtml;
      if (typeof toggleModulSb === 'function') sb.style.display = '';
    } else {
      // Farklı modüle geçiş - ilk sayfaya git
      if (ilkSayfa && ilkSayfa !== aktifAltBarSayfa) {
        window.location.href = BASE_URL + '/panel.php?sayfa=' + encodeURIComponent(ilkSayfa);
      }
    }
  }
}


/* ── MODÜL SIDEBAR TOGGLE ── */
function toggleModulSb() {
  var sb = document.getElementById('modulSb');
  var acBtn = document.getElementById('sbAcBtn');
  var togBtn = document.getElementById('sbToggleBtn');
  if (!sb) return;
  var kapali = sb.classList.toggle('kapali');
  localStorage.setItem('modulSbKapali', kapali ? '1' : '0');
  // Cookie ile PHP'ye bildir (sayfa yenilenince sidebar class'ı PHP ekler)
  document.cookie = 'modulSbKapali=' + (kapali ? '1' : '0') + ';path=/;max-age=31536000';
  if (acBtn) acBtn.style.display = kapali ? 'block' : 'none';
  if (togBtn) togBtn.textContent = kapali ? '▶' : '◀';
}

/* ── SAYFA YÜKLENİNCE SIDEBAR BUTON DURUMUNU GÜNCELLE ── */
/* Sidebar CSS class'ı PHP cookie ile ayarlanır - JS sadece butonları günceller */
document.addEventListener('DOMContentLoaded', function() {
  var sb = document.getElementById('modulSb');
  if (!sb) return;
  var kapali = sb.classList.contains('kapali');
  var acBtn  = document.getElementById('sbAcBtn');
  var togBtn = document.getElementById('sbToggleBtn');
  if (acBtn)  acBtn.style.display  = kapali ? 'block' : 'none';
  if (togBtn) togBtn.textContent   = kapali ? '▶' : '◀';
});

/* ── SAYFAYA GİT — sadece link, döngü yok ── */
function sayfaGit(id, el, ek) {
  if (!id) return;
  if (typeof AKTIF_SAYFA !== 'undefined' && id === AKTIF_SAYFA && !ek) return;
  var url = BASE_URL + '/panel.php?sayfa=' + encodeURIComponent(id);
  if (ek) url += '&' + ek;
  window.location.href = url;
}

/* ── SAĞ PANEL ── */
function sagPanelToggle() {
  var el = document.getElementById('sagPanel');
  if (el) {
    el.classList.toggle('acik');
    // Panel açıldıysa ve todo sekmesi aktifse yükle
    if (el.classList.contains('acik')) {
      var aktifSekme = document.querySelector('.sp-sekme.aktif');
      if (aktifSekme && aktifSekme.textContent.indexOf('Görev') >= 0 && typeof todoYukle === 'function') {
        todoYukle();
      }
    }
  }
}

// Alias — bildirim butonu da kullanıyor
function panelToggle() {
  sagPanelToggle();
}

function spSekme(id, el) {
  var sekmeler = document.querySelectorAll('.sp-sekme');
  for (var i = 0; i < sekmeler.length; i++) sekmeler[i].classList.remove('aktif');
  el.classList.add('aktif');
  var paneller = ['mesai','todo','log'];
  for (var i = 0; i < paneller.length; i++) {
    var p = document.getElementById('sp-' + paneller[i]);
    if (p) p.style.display = (paneller[i] === id) ? 'block' : 'none';
  }
  // Todo sekmesi açılınca yükle
  if (id === 'todo' && typeof todoYukle === 'function') todoYukle();
}

/* ── TEMA ── */


/* ── TODO — DB versiyonu sag-panel.php'de tanımlı ── */

/* ── SAAT ── */
var saatTimer = null;
function saatGuncelle() {
  var n = new Date();
  var s = ('0'+n.getHours()).slice(-2) + ':' + ('0'+n.getMinutes()).slice(-2);
  var el = document.getElementById('saatEl');
  if (el) el.textContent = s;
  // clearTimeout ile önceki zamanlayıcıyı iptal et
  if (saatTimer) clearTimeout(saatTimer);
  saatTimer = setTimeout(saatGuncelle, 30000);
}

/* ── MOBİL DRAWER ── */
function mobil_ikon_serit_olustur() {
  var drawer = document.getElementById('mobDrawer');
  if (!drawer) return;

  var kisaAd = typeof AYARLAR !== 'undefined' ? (AYARLAR.firma_kisa_adi || 'J') : 'J';
  var html = '<div class="mob-ikon-serit">'
    + '<div class="mob-is-logo">' + kisaAd.substring(0,2) + '</div>'
    + '<button class="mob-is-kapat" onclick="drawerKapat()">✕</button>'
    + '<div class="mob-is-sep"></div>';

  var modulIds = Object.keys(MODULLER);
  for (var i = 0; i < modulIds.length; i++) {
    var mid = modulIds[i];
    var mv = MODULLER[mid];
    var aktifClass = (mid === aktifModul) ? ' aktif' : '';
    var badge = (mid === 'ik' || mid === 'uretim') ? '<span class="mib-b"></span>' : '';
    html += '<button class="mob-ikon-btn' + aktifClass + '" id="mib-' + mid + '" data-tip="' + mv.baslik + '" onclick="mobIkonTikla(\'' + mid + '\')">'
      + '<span class="mib-i">' + mv.ikon + '</span>' + badge + '</button>';
  }

  html += '<div class="mob-is-alt">'
    + (MODULLER['ayarlar'] ? '<button class="mob-ikon-btn" data-tip="Ayarlar" onclick="mobIkonTikla(\'ayarlar\')"><span class="mib-i">⚙️</span></button>' : '')
    + '<a href="' + BASE_URL + '/cikis.php" class="mob-ikon-btn" data-tip="Çıkış"><span class="mib-i">🚪</span></a>'
    + '</div></div>'
    + '<div class="mob-sayfa-panel" id="mobSayfaPanel">'
    + '<div class="mob-sp-baslik">'
    + '<div class="mob-sp-ikon" id="mobSpIkon"></div>'
    + '<div class="mob-sp-ad" id="mobSpAd">—</div>'
    + '<button class="mob-sp-kapat" onclick="mobSayfaPanelKapat()">✕</button>'
    + '</div>'
    + '<div class="mob-sp-ic" id="mobSbIc"></div>'
    + '</div>';

  drawer.innerHTML = html;
}

function mobIkonTikla(id) {
  var panel = document.getElementById('mobSayfaPanel');
  var aktifBtn = document.getElementById('mib-' + id);

  var tumIkon = document.querySelectorAll('.mob-ikon-btn');
  for (var i = 0; i < tumIkon.length; i++) tumIkon[i].classList.remove('aktif');
  if (aktifBtn) aktifBtn.classList.add('aktif');

  aktifModul = id;
  mobil_sayfa_panel_doldur(id);
  if (panel) panel.classList.add('acik');
}

function mobil_sayfa_panel_doldur(id) {
  var veri = MODULLER[id];
  if (!veri) return;
  var ikonEl = document.getElementById('mobSpIkon');
  var adEl   = document.getElementById('mobSpAd');
  var ic     = document.getElementById('mobSbIc');
  if (ikonEl) { ikonEl.style.background = veri.renk; ikonEl.textContent = veri.ikon; }
  if (adEl)   adEl.textContent = veri.baslik;
  if (!ic) return;

  var html = '';
  // Aktif sayfanın hangi grupta olduğunu bul
  var aktifGrupIdx = 0;
  for (var g = 0; g < veri.gruplar.length; g++) {
    for (var s = 0; s < veri.gruplar[g].sayfalar.length; s++) {
      if (veri.gruplar[g].sayfalar[s].id === AKTIF_SAYFA) { aktifGrupIdx = g; break; }
    }
  }
  for (var g = 0; g < veri.gruplar.length; g++) {
    var grup = veri.gruplar[g];
    var acik = (g === aktifGrupIdx) ? ' acc-acik' : '';
    html += '<div class="mob-grp-ad acc-baslik' + acik + '" onclick="accToggle(this)">'
      + grup.ad
      + '<span class="acc-ok">' + (g === aktifGrupIdx ? '▲' : '▼') + '</span>'
      + '</div>';
    html += '<div class="acc-govde' + acik + '">';
    for (var s = 0; s < grup.sayfalar.length; s++) {
      var sp = grup.sayfalar[s];
      var roz = sp.r ? '<span class="mob-nav-roz">' + sp.r + '</span>' : '';
      html += '<div class="mob-nav-it" onclick="mobSayfaGit(\'' + sp.id + '\',this)"><span class="mob-nav-it-i">' + sp.i + '</span>' + sp.m + roz + '</div>';
    }
    html += '</div>';
  }
  ic.innerHTML = html;
}

function mobSayfaPanelKapat() {
  var panel = document.getElementById('mobSayfaPanel');
  if (panel) panel.classList.remove('acik');
  var tumIkon = document.querySelectorAll('.mob-ikon-btn');
  for (var i = 0; i < tumIkon.length; i++) tumIkon[i].classList.remove('aktif');
  var btn = document.getElementById('mib-' + aktifModul);
  if (btn) btn.classList.add('aktif');
}

function mobSayfaGit(sayfaId, el) {
  drawerKapat();
  window.location.href = BASE_URL + '/panel.php?sayfa=' + encodeURIComponent(sayfaId);
}

function drawerToggle() {
  var d = document.getElementById('mobDrawer');
  var h = document.getElementById('hamburger');
  var o = document.getElementById('mobOverlay');
  if (!d) return;

  var aciliyordu = !d.classList.contains('acik');
  if (aciliyordu) {
    mobil_ikon_serit_olustur();
    setTimeout(function() {
      mobil_sayfa_panel_doldur(aktifModul);
      var panel = document.getElementById('mobSayfaPanel');
      if (panel) panel.classList.add('acik');
      var mib = document.getElementById('mib-' + aktifModul);
      if (mib) mib.classList.add('aktif');
    }, 30);
  }

  d.classList.toggle('acik');
  if (h) h.classList.toggle('acik');
  if (o) o.classList.toggle('aktif');
  document.body.style.overflow = d.classList.contains('acik') ? 'hidden' : '';
}

function drawerKapat() {
  var d = document.getElementById('mobDrawer');
  var h = document.getElementById('hamburger');
  var o = document.getElementById('mobOverlay');
  if (d) d.classList.remove('acik');
  if (h) h.classList.remove('acik');
  if (o) o.classList.remove('aktif');
  document.body.style.overflow = '';
}

/* ── MOBİL ALT BAR ── */
function mobil_alt_bar_guncelle(modulId) {
  var bar  = document.getElementById('mobAltBar');
  var veri = MODULLER && MODULLER[modulId];
  if (!bar) return;

  var sayfalar = [];

  // Önce DB ayarlarına bak (MOB_AYAR)
  if (typeof MOB_AYAR !== 'undefined' && MOB_AYAR && MOB_AYAR[modulId] && MOB_AYAR[modulId].length > 0) {
    var mob_ids = MOB_AYAR[modulId]; // sıralı sayfa_id listesi
    if (veri) {
      for (var mi = 0; mi < mob_ids.length; mi++) {
        var bulundu = false;
        for (var g = 0; g < veri.gruplar.length && !bulundu; g++) {
          for (var s = 0; s < veri.gruplar[g].sayfalar.length && !bulundu; s++) {
            var sp = veri.gruplar[g].sayfalar[s];
            if (sp.id === mob_ids[mi]) {
              sayfalar.push(sp);
              bulundu = true;
            }
          }
        }
      }
    }
  } else if (veri) {
    // DB ayarı yoksa ilk 4 sayfayı al (eski davranış)
    for (var g = 0; g < veri.gruplar.length; g++) {
      for (var s = 0; s < veri.gruplar[g].sayfalar.length; s++) {
        sayfalar.push(veri.gruplar[g].sayfalar[s]);
        if (sayfalar.length >= 4) break;
      }
      if (sayfalar.length >= 4) break;
    }
  }

  var html = '<button class="mab' + (AKTIF_SAYFA === 'dashboard' ? ' aktif' : '') + '" onclick="window.location.href=\'' + BASE_URL + '/panel.php?sayfa=dashboard\'">'
    + '<span class="mab-i">🏠</span><span class="mab-l">Ana</span></button>';

  for (var i = 0; i < sayfalar.length; i++) {
    var sp = sayfalar[i];
    var aktifClass = (sp.id === AKTIF_SAYFA) ? ' aktif' : '';
    var roz = sp.r ? '<span class="mab-badge"></span>' : '';
    html += '<button class="mab' + aktifClass + '" onclick="window.location.href=\'' + BASE_URL + '/panel.php?sayfa=' + sp.id + '\'">'
      + '<span class="mab-i">' + sp.i + '</span>'
      + '<span class="mab-l">' + (sp.m||sp.baslik||'').substring(0,8) + '</span>' + roz + '</button>';
  }

  html += '<button class="mab" onclick="drawerToggle()">'
    + '<span class="mab-i">☰</span><span class="mab-l">Menü</span></button>';

  bar.innerHTML = html;
}

/* ── BAŞLANGIÇ ── */
document.addEventListener('DOMContentLoaded', function() {

  // Tema
  try {
    var kayitliTema = localStorage.getItem('jt_tema');
    if (kayitliTema) {
      document.documentElement.setAttribute('data-tema', kayitliTema);
      var temaBtn = document.getElementById('temaBtn');
      if (temaBtn) temaBtn.textContent = kayitliTema === 'koyu' ? '🌙' : '☀️';
    }
  } catch(e) {}

  // Aktif modülü belirle
  var aktifSayfaDeger = typeof AKTIF_SAYFA !== 'undefined' ? AKTIF_SAYFA : 'dashboard';
  aktifAltBarSayfa = aktifSayfaDeger;
  var modId = aktifSayfaDeger.split('-')[0];
  // Kısa prefix → tam modül adı eşlemesi
  var prefixMap = {'tanim':'tanimlamalar','idari':'idari','ik':'ik','satis':'satis',
    'uretim':'uretim','kalite':'kalite','planlama':'planlama','raporlar':'raporlar','ayarlar':'ayarlar','satinalma':'satinalma'};
  if (prefixMap[modId]) modId = prefixMap[modId];
  // Modül dışı sayfalar (profil, sistem vb.) - redirect yapma
  var modulDisiSayfalar = ['kullanici-profil','guvenlik','ai-chat','ayarlar-ai'];
  if (modulDisiSayfalar.indexOf(aktifSayfaDeger) !== -1) {
    // Bu sayfalar için sidebar güncelleme yap ama redirect yok
    aktifModul = null;
  } else if (MODULLER[modId]) {
    aktifModul = modId;
  } else {
    // Tüm modüllerde sayfa ara
    aktifModul = 'dashboard';
    for (var mid in MODULLER) {
      var gruplar = MODULLER[mid].gruplar || [];
      for (var gi = 0; gi < gruplar.length; gi++) {
        var sayfalar = gruplar[gi].sayfalar || [];
        for (var si = 0; si < sayfalar.length; si++) {
          if (sayfalar[si].id === aktifSayfaDeger) {
            aktifModul = mid;
            break;
          }
        }
        if (aktifModul !== 'dashboard') break;
      }
      if (aktifModul !== 'dashboard') break;
    }
  }

  // Sidebari doldur (yonlendirme olmadan) - modül dışı sayfalarda atla
  if (aktifModul !== null) {
    var aktifBtn = document.querySelector('.mb[data-tip="' + (MODULLER[aktifModul] ? MODULLER[aktifModul].baslik : '') + '"]');
    modulSec(aktifModul, aktifBtn);
  }

  // Aktif nav-it işaretle
  var aktifNavIt = document.querySelector('.nav-it[onclick*="' + aktifSayfaDeger + '"]');
  if (aktifNavIt) {
    var tumNavIt = document.querySelectorAll('.nav-it');
    for (var i = 0; i < tumNavIt.length; i++) tumNavIt[i].classList.remove('aktif');
    aktifNavIt.classList.add('aktif');
  }

  // Alt bar
  mobil_alt_bar_guncelle(aktifModul);

  // Saat — sadece bir kez başlat
  saatGuncelle();

  // Ctrl+K
  document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      var ara = document.getElementById('aramaInput');
      if (ara) ara.focus();
    }
    if (e.key === 'Escape') drawerKapat();
  });

  // Sağ panel — kapalı başlar, kullanıcı ☰ butonuyla açar
  // (otomatik açma kaldırıldı)

  // Dinamik rozet yükle
  rozetYukle();
  setInterval(rozetYukle, 60000); // Her dakika güncelle
});

/* ── DİNAMİK ROZET SİSTEMİ ── */
function rozetYukle() {
  fetch(BASE_URL + '/paylasilan/api/rozet.php', {credentials:'same-origin'})
    .then(function(r){ return r.json(); })
    .then(function(data) {
      if (!data.ok || !data.rozet) return;
      var r = data.rozet;

      // Personel sayısı
      rozetGuncelle('ik-personeller', r['ik-personeller']);

      // Bekleyen izin talepleri
      rozetGuncelle('ik-izinler', r['ik-izinler']);

      // Bekleyen öneri/şikayet
      rozetGuncelle('ik-oneri', r['ik-oneri']);

      // Bildirim rozeti (üst bar)
      var bilEl = document.querySelector('.ub-bil-roz');
      if (bilEl) {
        if (r['bildirim'] > 0) {
          bilEl.textContent = r['bildirim'] > 99 ? '99+' : r['bildirim'];
          bilEl.style.display = 'flex';
        } else {
          bilEl.style.display = 'none';
        }
      }
    }).catch(function(){});
}

function rozetGuncelle(sayfaId, sayi) {
  // data-sayfa attribute'u ile tüm nav item'larını bul
  document.querySelectorAll('[data-sayfa="' + sayfaId + '"]').forEach(function(item) {
    var roz = item.querySelector('.nav-roz, .mob-nav-roz');
    if (!roz) {
      roz = document.createElement('span');
      roz.className = 'nav-roz';
      roz.style.cssText = 'background:#EF4444;color:#fff;font-size:9px;font-weight:800;min-width:17px;height:17px;border-radius:9px;padding:0 3px;display:inline-flex;align-items:center;justify-content:center;margin-left:4px;flex-shrink:0';
      item.appendChild(roz);
    }
    if (sayi > 0) {
      roz.textContent = sayi > 99 ? '99+' : sayi;
      roz.style.display = 'inline-flex';
    } else {
      roz.style.display = 'none';
    }
  });
}

/* ══════════════════════════════════════════════════════════
   DataTable Yardımcısı — dtInit(tableId)
   jQuery/DataTables varsa kullanır, yoksa native scroll
   ══════════════════════════════════════════════════════════ */
var _dtInstances = {};

function dtInit(tableId) {
  var tbl = document.getElementById(tableId);
  if (!tbl) return null;

  // Native scroll wrapper
  var parent = tbl.parentElement;
  if (parent && !parent.getAttribute('data-dt-wrapped')) {
    parent.setAttribute('data-dt-wrapped','1');
    if (!parent.style.overflowX) { parent.style.overflowX = 'auto'; }
    if (!parent.style.overflowY) { parent.style.overflowY = 'auto'; }
    if (!parent.style.maxHeight) { parent.style.maxHeight = 'calc(100vh - 280px)'; }
  }

  // jQuery + DataTables varsa kullan
  if (typeof $ === 'undefined' || !$.fn || !$.fn.DataTable) {
    return null;
  }
  // Colspan olan tablolarda DataTables çalışmaz - atla
  var hasTd = tbl.querySelector('tbody td[colspan]');
  var firstTh = tbl.querySelectorAll('thead th').length;
  var firstTd = tbl.querySelector('tbody tr') ? tbl.querySelector('tbody tr').querySelectorAll('td').length : firstTh;
  if (hasTd || (firstTd > 0 && firstTd !== firstTh)) {
    return null; // DataTables baslatma, native scroll ile devam
  }
  if ($.fn.DataTable.isDataTable('#' + tableId)) {
    _dtInstances[tableId] = $('#' + tableId).DataTable();
    return _dtInstances[tableId];
  }

  var dt = $('#' + tableId).DataTable({
    paging:         false,
    scrollX:        false,
    scrollCollapse: false,
    order:          [],
    autoWidth:      false,
    language: {
      search:      'Ara:',
      info:        '_TOTAL_ kayıttan _START_–_END_',
      infoEmpty:   'Kayıt yok',
      zeroRecords: 'Eşleşen yok',
      emptyTable:  'Veri yok'
    },
    dom: 'ft',
    initComplete: function() {
      var filter  = document.querySelector('#' + tableId + '_filter');
      var toolbar = document.getElementById('dt-toolbar-' + tableId);
      if (filter && toolbar) {
        var inp = filter.querySelector('input');
        if (inp) {
          inp.placeholder = '🔍 Ara...';
          inp.style.cssText = 'border:1.5px solid var(--kenar);border-radius:8px;padding:6px 12px;font-family:inherit;font-size:13px;outline:none;width:180px';
        }
        filter.style.margin = '0';
        toolbar.appendChild(filter);
      }
    }
  });
  _dtInstances[tableId] = dt;
  return dt;
}

function dtExcelIndir(tableId, dosyaAdi, opts) {
  opts = opts || {};
  // SheetJS (XLSX) varsa client-side
  if (typeof XLSX !== 'undefined') {
    var tbl = document.getElementById(tableId);
    if (!tbl) return;
    var headers = [];
    var hiddenIdx = [];
    var ths = tbl.querySelectorAll('thead th');
    ths.forEach(function(th, i) {
      var txt = (th.textContent || '').trim();
      if (txt === 'İşlem' || txt === '#' || txt === '') {
        hiddenIdx.push(i);
      } else {
        headers.push(txt);
      }
    });
    var rows = [headers];
    tbl.querySelectorAll('tbody tr').forEach(function(tr) {
      var cells = tr.querySelectorAll('td');
      var row = [];
      cells.forEach(function(td, i) {
        if (hiddenIdx.indexOf(i) === -1) {
          row.push((td.textContent || '').trim().replace(/\s+/g,' '));
        }
      });
      if (row.some(function(v){return v !== '';})) rows.push(row);
    });
    var ws = XLSX.utils.aoa_to_sheet(rows);
    var maxW = 25;
    ws['!cols'] = headers.map(function(){ return {wch: maxW}; });
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Veri');
    XLSX.writeFile(wb, (dosyaAdi || 'export') + '.xlsx');
    return;
  }
  // Fallback: server-side
  var p = new URLSearchParams(window.location.search);
  var ay   = p.get('ay')  || (new Date().getMonth() + 1);
  var yil  = p.get('yil') || new Date().getFullYear();
  var dept = p.get('dept') || p.get('departman') || '0';
  var base = typeof BASE_URL !== 'undefined' ? BASE_URL : '';
  window.location.href = base + '/bolumler/ik/ajax/excel-export.php?tip=' + (opts.tip||'personel') + '&ay=' + ay + '&yil=' + yil + '&dept=' + dept;
}

function dtImport(tableId, input) {
  if (!input.files || !input.files[0]) return;
  if (typeof XLSX === 'undefined') { alert('SheetJS yuklenemedi'); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var data = new Uint8Array(e.target.result);
    var wb = XLSX.read(data, {type:'array'});
    var ws = wb.Sheets[wb.SheetNames[0]];
    var rows = XLSX.utils.sheet_to_json(ws, {header:1, defval:''});
    if (!rows.length) return;
    var headers = rows[0];
    var dataRows = rows.slice(1).filter(function(r){return r.some(function(x){return x!=='';});});
    var html = '<div style="overflow:auto;max-height:400px"><table class="tablo" style="min-width:600px"><thead style="position:sticky;top:0;background:#fff"><tr>';
    headers.forEach(function(h){html+='<th>'+String(h)+'</th>';});
    html+='</tr></thead><tbody>';
    dataRows.forEach(function(row){
      html+='<tr>';
      headers.forEach(function(_,i){html+='<td>'+String(row[i]||'')+'</td>';});
      html+='</tr>';
    });
    html+='</tbody></table></div>';
    html+='<p style="margin-top:10px;font-size:13px;color:var(--m2)">'+dataRows.length+' satir okundu.</p>';
    var modal = document.getElementById('importModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'importModal';
      modal.setAttribute('style','display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center;padding:20px');
      var inner = document.createElement('div');
      inner.setAttribute('style','background:#fff;border-radius:16px;width:min(800px,100%);max-height:85vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.2)');
      var head = document.createElement('div');
      head.setAttribute('style','padding:16px 20px;border-bottom:1px solid var(--kenar);display:flex;justify-content:space-between;align-items:center');
      head.innerHTML = '<h3 style="font-size:15px;font-weight:800">Iceaktarma Onizlemesi</h3>';
      var closeBtn = document.createElement('button');
      closeBtn.setAttribute('style','border:none;background:none;font-size:20px;cursor:pointer');
      closeBtn.textContent = 'x';
      closeBtn.onclick = function(){modal.style.display='none';};
      head.appendChild(closeBtn);
      var body = document.createElement('div');
      body.id = 'importModalContent';
      body.setAttribute('style','padding:20px;overflow:auto;flex:1');
      inner.appendChild(head);
      inner.appendChild(body);
      modal.appendChild(inner);
      document.body.appendChild(modal);
    }
    document.getElementById('importModalContent').innerHTML = html;
    modal.style.display = 'flex';
    input.value = '';
  };
  reader.readAsArrayBuffer(input.files[0]);
}
function accToggle(baslik) {
  var govde = baslik.nextElementSibling;
  var ok    = baslik.querySelector('.acc-ok');
  var acik  = baslik.classList.contains('acc-acik');
  // Aynı container içindeki tüm açıkları kapat
  var parent = baslik.parentElement;
  var tumBaslik = parent.querySelectorAll('.acc-baslik');
  for (var i = 0; i < tumBaslik.length; i++) {
    tumBaslik[i].classList.remove('acc-acik');
    var o = tumBaslik[i].querySelector('.acc-ok');
    if (o) o.textContent = '▼';
    var g = tumBaslik[i].nextElementSibling;
    if (g && g.classList.contains('acc-govde')) g.classList.remove('acc-acik');
  }
  // Tıklanan kapalıysa aç
  if (!acik) {
    baslik.classList.add('acc-acik');
    if (ok) ok.textContent = '▲';
    if (govde) govde.classList.add('acc-acik');
  }
}

function sbAccToggle(baslik) {
  var govde = baslik.nextElementSibling;
  var ok    = baslik.querySelector('.acc-ok');
  var acik  = baslik.classList.contains('acc-acik');
  var parent = baslik.closest('.msb-ic');
  if (parent) {
    var tumBaslik = parent.querySelectorAll('.acc-baslik');
    for (var i = 0; i < tumBaslik.length; i++) {
      tumBaslik[i].classList.remove('acc-acik');
      var o = tumBaslik[i].querySelector('.acc-ok');
      if (o) o.textContent = '▼';
      var g = tumBaslik[i].nextElementSibling;
      if (g && g.classList.contains('acc-govde')) g.classList.remove('acc-acik');
    }
  }
  if (!acik) {
    baslik.classList.add('acc-acik');
    if (ok) ok.textContent = '▲';
    if (govde) govde.classList.add('acc-acik');
  }
}
