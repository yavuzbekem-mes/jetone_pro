<?php
/**
 * Panel Rozet Sayıları — Dinamik
 * paylasilan/api/rozet.php
 */
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_clean(); header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store');

if (!Auth::girisYapilmisMi()) { echo json_encode(['ok'=>false]); exit; }

$kul_id = (int)(Auth::kullanici()['id'] ?? 0);

try {
    $rozet = [];

    // Aktif personel sayısı
    $rozet['ik-personeller'] = (int)$db->query(
        "SELECT COUNT(*) FROM personeller WHERE durum='aktif'"
    )->fetchColumn();

    // Bekleyen izin talepleri
    $rozet['ik-izinler'] = (int)$db->query(
        "SELECT COUNT(*) FROM izin_talepleri WHERE durum='bekliyor'"
    )->fetchColumn();

    // Bekleyen öneri/şikayet (tablo yoksa 0)
    try {
        $rozet['ik-oneri'] = (int)$db->query(
            "SELECT COUNT(*) FROM oneri_sikayet WHERE durum='bekliyor'"
        )->fetchColumn();
    } catch(Exception $e){ $rozet['ik-oneri'] = 0; }

    // Okunmamış ERP bildirimleri
    $bilQ = $db->prepare("SELECT COUNT(*) FROM bildirimler 
        WHERE (kullanici_id=? OR kullanici_id IS NULL) 
          AND portal_tipi='erp' AND okundu=0");
    $bilQ->execute([$kul_id]);
    $rozet['bildirim'] = (int)$bilQ->fetchColumn();

    echo json_encode(['ok'=>true,'rozet'=>$rozet]);

} catch(Throwable $e) {
    echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]);
}
