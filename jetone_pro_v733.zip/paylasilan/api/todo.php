<?php
ob_start(); ini_set('display_errors',0); error_reporting(0);
require_once dirname(dirname(__DIR__)) . '/core/config.php';
require_once dirname(dirname(__DIR__)) . '/core/db.php';
require_once dirname(dirname(__DIR__)) . '/core/auth.php';
ob_end_clean();
header('Content-Type: application/json; charset=utf-8');

// ERP oturumu - auth.php zaten session'ı açtı
$uid = (int)($_SESSION['kullanici']['id'] ?? 0);
if (!$uid) { echo json_encode(['ok'=>false,'hata'=>'Oturum bulunamadi','sid'=>session_id()]); exit; }

// Tablo kontrol - yok ise tablo_guncelle'de yapılacak, burada sadece çalıştır
try {
    $db->exec("CREATE TABLE IF NOT EXISTS `gorevler` (
        `id`           INT AUTO_INCREMENT PRIMARY KEY,
        `kullanici_id` INT NOT NULL,
        `metin`        VARCHAR(500) NOT NULL,
        `oncelik`      TINYINT(1) DEFAULT 2 COMMENT '1=dusuk 2=normal 3=yuksek',
        `tamamlandi`   TINYINT(1) DEFAULT 0,
        `olusturma`    DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_kul` (`kullanici_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");
} catch(Throwable $e) {}

$raw = file_get_contents('php://input');
$d   = json_decode($raw, true) ?: [];
$islem = $d['islem'] ?? 'listele';

try {
    if ($islem === 'listele') {
        // oncelik kolonu var mı?
        try {
            $rows = $db->prepare("SELECT id, metin, tamamlandi, oncelik, olusturma FROM gorevler WHERE kullanici_id=? ORDER BY tamamlandi ASC, oncelik DESC, olusturma DESC");
        } catch(Throwable $e) {
            $rows = $db->prepare("SELECT id, metin, tamamlandi, 2 oncelik, olusturma FROM gorevler WHERE kullanici_id=? ORDER BY tamamlandi ASC, olusturma DESC");
        }
        $rows->execute([$uid]);
        echo json_encode(['ok'=>true,'gorevler'=>$rows->fetchAll()]);

    } elseif ($islem === 'ekle') {
        $metin   = trim($d['metin'] ?? '');
        $oncelik = (int)($d['oncelik'] ?? 2);
        if (!$metin) { echo json_encode(['ok'=>false,'hata'=>'Metin boş']); exit; }
        try {
            $db->prepare("INSERT INTO gorevler (kullanici_id,metin,oncelik) VALUES (?,?,?)")->execute([$uid,$metin,$oncelik]);
        } catch(Throwable $e) {
            $db->prepare("INSERT INTO gorevler (kullanici_id,metin) VALUES (?,?)")->execute([$uid,$metin]);
        }
        echo json_encode(['ok'=>true,'id'=>(int)$db->lastInsertId()]);

    } elseif ($islem === 'toggle') {
        $id = (int)($d['id'] ?? 0);
        $db->prepare("UPDATE gorevler SET tamamlandi=1-tamamlandi WHERE id=? AND kullanici_id=?")->execute([$id,$uid]);
        echo json_encode(['ok'=>true]);

    } elseif ($islem === 'sil') {
        $id = (int)($d['id'] ?? 0);
        $db->prepare("DELETE FROM gorevler WHERE id=? AND kullanici_id=?")->execute([$id,$uid]);
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'hata'=>'Gecersiz islem: '.$islem]);
    }
} catch(Throwable $e) { echo json_encode(['ok'=>false,'hata'=>$e->getMessage()]); }
