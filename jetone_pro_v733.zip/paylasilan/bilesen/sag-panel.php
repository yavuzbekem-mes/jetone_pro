<?php /** Sağ Panel — paylasilan/bilesen/sag-panel.php */ ?>
<aside class="sag-panel" id="sagPanel">
  <div class="sp-bas">
    <div class="sp-bas-ad">⚡ Hızlı Panel</div>
    <button class="sp-kapat" onclick="sagPanelToggle()">✕</button>
  </div>
  <div class="sp-sekme-bar">
    <button class="sp-sekme aktif" onclick="spSekme('mesai',this)">🕐 Mesai</button>
    <button class="sp-sekme" onclick="spSekme('todo',this)">☑ Görevler</button>
    <button class="sp-sekme" onclick="spSekme('log',this)">📋 Log</button>
  </div>
  <div class="sp-ic">
    <!-- Mesai -->
    <div id="sp-mesai" class="sp-bolum">
      <div class="sp-b-bas">Mesai Durumu</div>
      <div class="mes-kart">
        <div class="mes-dur">
          <div class="mes-n" style="background:var(--bas)"></div>
          <div class="mes-nm" style="color:var(--bas)">✓ İşteyim</div>
        </div>
        <div class="mes-saat" id="saatEl"><?php echo date('H:i'); ?></div>
        <div class="mes-t"><?php echo date('d.m.Y'); ?></div>
        <button class="mes-btn mes-c">⏹ Çıkış Yap</button>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
        <div style="background:var(--bg);border:1px solid var(--kenar);border-radius:var(--r);padding:10px;text-align:center">
          <div style="font-size:18px;font-weight:800;color:var(--t)">—</div>
          <div style="font-size:10px;color:var(--m2)">Çalışma</div>
        </div>
        <div style="background:var(--bg);border:1px solid var(--kenar);border-radius:var(--r);padding:10px;text-align:center">
          <div style="font-size:18px;font-weight:800;color:var(--mavi)" id="izinGunSayisi">—</div>
          <div style="font-size:10px;color:var(--m2)">İzin Günü</div>
        </div>
      </div>
      <div class="sp-b-bas">Bildirimler</div>
      <?php
      $bildirimler = [];
      try {
        $kul = Auth::kullanici();
        $stmt = $db->prepare("SELECT * FROM bildirimler WHERE (kullanici_id=? OR kullanici_id IS NULL) AND okundu=0 AND portal_tipi='erp' ORDER BY olusturma DESC LIMIT 5");
        $stmt->execute([$kul['id']]);
        $bildirimler = $stmt->fetchAll();
      } catch (Exception $e) {}
      $bilRenkler = ['bilgi'=>['#E0F2FE','#0284C7'],'uyari'=>['#FEF0C7','#B45309'],'hata'=>['#FEE4E2','#F04438'],'basari'=>['#D1FADF','#0A8F4E']];
      if (empty($bildirimler)):
      ?>
      <div style="font-size:12px;color:var(--m2);padding:8px 0">Yeni bildirim yok 🎉</div>
      <?php else: foreach ($bildirimler as $b):
        $r = $bilRenkler[$b['tip']] ?? $bilRenkler['bilgi'];
      ?>
      <div class="bil-k" style="background:<?php echo $r[0]; ?>;border-left-color:<?php echo $r[1]; ?>;<?php echo !empty($b['link'])?'cursor:pointer':'' ?>"
           <?php if(!empty($b['link'])): ?>
           onclick="location.href='<?php echo htmlspecialchars($b['link']); ?>';panelToggle('bildirimler')"
           <?php endif; ?>>
        <div class="bil-b" style="color:<?php echo $r[1]; ?>"><?php echo htmlspecialchars($b['baslik']); ?></div>
        <div class="bil-t"><?php echo htmlspecialchars(mb_substr($b['mesaj'] ?? '', 0, 80)); ?></div>
        <?php if(!empty($b['link'])): ?><div style="font-size:10px;color:<?php echo $r[1]; ?>;margin-top:2px;opacity:.7">Detaya git →</div><?php endif; ?>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <!-- Todo -->
    <div id="sp-todo" class="sp-bolum" style="display:none">
      <div class="sp-b-bas">Görev Listesi <span id="todoSayac" style="font-size:10px;color:var(--m2)"></span></div>
      <div style="display:flex;gap:6px;margin-bottom:8px">
        <select id="todoOncelik" style="width:38px;padding:4px 2px;border:1px solid var(--kenar);border-radius:6px;font-size:13px;background:var(--kart);cursor:pointer;text-align:center" title="Öncelik">
          <option value="3">🔴</option>
          <option value="2" selected>🟡</option>
          <option value="1">⚪</option>
        </select>
        <input class="todo-inp" id="todoInput" placeholder="Yeni görev ekle..." onkeypress="if(event.key==='Enter')todoEkle()" style="flex:1">
        <button class="todo-ekb" onclick="todoEkle()">+</button>
      </div>
      <div id="todoListesi" style="margin-top:6px">
        <div style="font-size:12px;color:var(--m2);padding:12px 0;text-align:center" id="todoYukleniyor">Yükleniyor...</div>
      </div>
    </div>

<script>
window.TODO_URL = '<?php echo BASE_URL; ?>/paylasilan/api/todo.php';
var _todoYukleniyor = false;

function todoYukle() {
  if (_todoYukleniyor) return;
  _todoYukleniyor = true;
  fetch(window.TODO_URL, {method:'POST', credentials:'same-origin',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({islem:'listele'})})
  .then(function(r){return r.json();})
  .then(function(r){
    _todoYukleniyor = false;
    if (r.ok) todoRender(r.gorevler||[]);
    else {
      var el = document.getElementById('todoYukleniyor');
      if (el) el.textContent = 'Hata: ' + (r.hata||'?');
    }
  }).catch(function(e){ _todoYukleniyor = false; var el=document.getElementById('todoYukleniyor'); if(el) el.textContent='Bağlantı hatası';});
}

function todoRender(gorevler) {
  var el = document.getElementById('todoListesi');
  if (!gorevler.length) {
    el.innerHTML = '<div style="font-size:12px;color:var(--m2);padding:12px 0;text-align:center">Henüz görev yok. Yukarıdan ekleyin.</div>';
    var sayac = document.getElementById('todoSayac');
    if (sayac) sayac.textContent = '';
    return;
  }
  var bekleyen = gorevler.filter(function(g){return !g.tamamlandi;}).length;
  var sayac = document.getElementById('todoSayac');
  if (sayac) sayac.textContent = bekleyen > 0 ? bekleyen + ' bekliyor' : '✅ Tümü tamamlandı';
  var html = '';
  var oncelikMap = {3:{ikon:'🔴',renk:'#EF4444'},2:{ikon:'🟡',renk:'#F59E0B'},1:{ikon:'⚪',renk:'#9CA3AF'}};
  gorevler.forEach(function(g) {
    var onc = oncelikMap[g.oncelik||2]||oncelikMap[2];
    var tarihStr = '';
    if (g.olusturma) {
      var t = new Date(g.olusturma.replace(' ','T'));
      tarihStr = ('0'+t.getDate()).slice(-2)+'.'
               + ('0'+(t.getMonth()+1)).slice(-2)+'.'
               + t.getFullYear()+' '
               + ('0'+t.getHours()).slice(-2)+':'
               + ('0'+t.getMinutes()).slice(-2);
    }
    html += '<div class="todo-m" style="opacity:'+(g.tamamlandi?.55:1)+';border-left:3px solid '+(g.tamamlandi?'#E5E7EB':onc.renk)+'" data-id="'+g.id+'">';
    html += '<div class="todo-k" style="'+(g.tamamlandi?'background:var(--bas);border-color:var(--bas)':'')+'" onclick="todoToggle('+g.id+')"></div>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div class="todo-mt" style="'+(g.tamamlandi?'text-decoration:line-through;color:var(--m2)':'')+'" onclick="todoToggle('+g.id+')">'+onc.ikon+' '+escHtml(g.metin)+'</div>';
    if (tarihStr) html += '<div style="font-size:10px;color:var(--m2);margin-top:2px">'+tarihStr+'</div>';
    html += '</div>';
    html += '<button class="todo-sl" onclick="todoSil('+g.id+')">✕</button>';
    html += '</div>';
  });
  el.innerHTML = html;
}

function escHtml(t) {
  return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function todoEkle() {
  var inp = document.getElementById('todoInput');
  if (!inp) { alert('todoInput bulunamadı!'); return; }
  var metin = inp.value.trim();
  if (!metin) return;
  var oncelikEl = document.getElementById('todoOncelik');
  var oncelik = oncelikEl ? parseInt(oncelikEl.value)||2 : 2;
  inp.value = '';
  var payload = JSON.stringify({islem:'ekle', metin:metin, oncelik:oncelik});
  fetch(window.TODO_URL, {method:'POST', credentials:'same-origin',
    headers:{'Content-Type':'application/json'},
    body:payload})
  .then(function(r){return r.text();})
  .then(function(txt){
    console.log('TODO raw:', txt);
    try {
      var r = JSON.parse(txt);
      if (r.ok) todoYukle();
      else alert('Hata: '+(r.hata||txt));
    } catch(e) { alert('Parse hatası: '+txt.substring(0,300)); }
  }).catch(function(e){ alert('Fetch hatası: '+String(e)); });
}

function todoToggle(id) {
  fetch(window.TODO_URL, {method:'POST', credentials:'same-origin',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({islem:'toggle', id:id})})
  .then(function(r){return r.json();})
  .then(function(r){ if(r.ok) todoYukle(); });
}

function todoSil(id) {
  fetch(window.TODO_URL, {method:'POST', credentials:'same-origin',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({islem:'sil', id:id})})
  .then(function(r){return r.json();})
  .then(function(r){ if(r.ok) todoYukle(); });
}
</script>

    <!-- Log -->
    <div id="sp-log" class="sp-bolum" style="display:none">
      <div class="sp-b-bas">Sistem Logları</div>
      <?php
      try {
        $kul = Auth::kullanici();
        $loglar = $db->query("SELECT * FROM sistem_loglar ORDER BY tarih DESC LIMIT 10")->fetchAll();
        $logRenk = ['giris'=>'var(--bas)','cikis'=>'var(--m2)','kaydet'=>'var(--t)','sil'=>'var(--hat)','guncelle'=>'var(--mavi)'];
        foreach ($loglar as $l):
          $renk = $logRenk[$l['islem']] ?? 'var(--m3)';
      ?>
      <div class="log-m">
        <div class="log-n" style="background:<?php echo $renk; ?>"></div>
        <div>
          <div class="log-mt"><?php echo htmlspecialchars($l['aciklama'] ?: ucfirst($l['islem'])); ?></div>
          <div class="log-z"><?php echo date('d.m H:i', strtotime($l['tarih'])); ?></div>
        </div>
      </div>
      <?php endforeach;
      } catch (Exception $e) {
        echo '<div style="font-size:12px;color:var(--m2)">Log verisi alınamadı.</div>';
      } ?>
    </div>
  </div>
</aside>
