<?php
/**
 * Ana Dashboard — paylasilan/bilesen/dashboard.php
 * İK, İdari, Satış, Satınalma, Planlama, Sevkiyat özetleri
 */
$bugun = date('Y-m-d');
$ay_bas = date('Y-m-01');
$tiger_ok = !empty($tigerdb_pdo);
$mes_ok   = !empty($mes_pdo);
$tigerdb_pdo = $tigerdb_pdo ?? null;
$mes_pdo     = $mes_pdo     ?? null;
function db_val($db,$sql,$p=[],$def=0){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetchColumn()??$def;}catch(Throwable $e){return $def;}}
function db_row($db,$sql,$p=[]){try{$s=$db->prepare($sql);$s->execute($p);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return[];}}
function tiger_val($db,$sql,$def=0){try{return $db->query($sql)->fetchColumn()??$def;}catch(Throwable $e){return $def;}}

// ── İK ──────────────────────────────────────────────────────────
$ik_personel   = db_val($db,"SELECT COUNT(*) FROM personeller WHERE durum='aktif'");
$ik_izin_bugün = db_val($db,"SELECT COUNT(*) FROM izin_talepleri WHERE durum='onaylandi' AND ? BETWEEN baslangic_tarihi AND bitis_tarihi",[$bugun]);
$ik_yeni_ihtar = db_val($db,"SELECT COUNT(*) FROM ihtar_tutanaklari WHERE MONTH(tarih)=MONTH(NOW()) AND YEAR(tarih)=YEAR(NOW())");
$ik_mesai_bekl = db_val($db,"SELECT COUNT(*) FROM fazla_mesai WHERE durum='bekliyor'");

// ── Satış ────────────────────────────────────────────────────────
$satis_bugun   = db_val($db,"SELECT COUNT(*) FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)=? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$satis_geciken = db_val($db,"SELECT COUNT(*) FROM siparis WHERE sip_statu='Aktif' AND DATE(sip_teslim_tarihi)<? AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0",[$bugun]);
$satis_acik    = db_val($db,"SELECT COUNT(*) FROM siparis WHERE sip_statu='Aktif' AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0");
$jit_24        = db_val($db,"SELECT COUNT(*) FROM jit_siparis WHERE jit_sip_statu='Aktif' AND CONCAT(jit_sip_teslim_tarihi,' ',jit_sip_saati)<=? AND (jit_sip_miktar-COALESCE(jit_sip_sevk_miktari,0))>0",[date('Y-m-d H:i:s',strtotime('+24 hours'))]);
$satis_son5    = db_row($db,"SELECT musteri_firma_adi,sip_kodu,sip_teslim_tarihi,(sip_miktar-COALESCE(sip_sevk_miktari,0)) kalan FROM siparis WHERE sip_statu='Aktif' AND (sip_miktar-COALESCE(sip_sevk_miktari,0))>0 ORDER BY sip_teslim_tarihi ASC LIMIT 5");

// ── Satınalma ────────────────────────────────────────────────────
$satin_acik     = 0; $satin_geciken = 0; $satin_bugun = 0;
if ($tiger_ok) {
    $satin_acik     = tiger_val($tigerdb_pdo,"SELECT COUNT(*) FROM LG_222_02_ORFLINE WITH(NOLOCK) WHERE TRCODE=2 AND SHIPPEDAMOUNT<AMOUNT");
    $satin_geciken  = tiger_val($tigerdb_pdo,"SELECT COUNT(*) FROM LG_222_02_ORFLINE OL WITH(NOLOCK) LEFT JOIN LG_222_02_ORFICHE ORF WITH(NOLOCK) ON OL.ORDFICHEREF=ORF.LOGICALREF WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT<OL.AMOUNT AND OL.DUEDATE<GETDATE()");
    $satin_bugun    = tiger_val($tigerdb_pdo,"SELECT COUNT(*) FROM LG_222_02_ORFLINE OL WITH(NOLOCK) WHERE OL.TRCODE=2 AND OL.SHIPPEDAMOUNT<OL.AMOUNT AND CAST(OL.DUEDATE AS DATE)=CAST(GETDATE() AS DATE)");
}

// ── Planlama / KPI ───────────────────────────────────────────────
$ay_adi_tr = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'][(int)date('n')-1];
$plan_sayim_gercek = db_val($db,"SELECT gerceklesen_sayim FROM aylik_kpi_stok WHERE ay=? AND yil=?",[$ay_adi_tr,date('Y')]);
$plan_sayim_hedef  = db_val($db,"SELECT hedef_sayim_adedi FROM aylik_kpi_stok WHERE ay=? AND yil=?",[$ay_adi_tr,date('Y')],50);
$plan_sayim_uyum   = db_val($db,"SELECT hedefe_uyum FROM aylik_kpi_stok WHERE ay=? AND yil=?",[$ay_adi_tr,date('Y')]);

// ── Depo / Sevkiyat ──────────────────────────────────────────────
$depo_aktif_paket = 0;
if ($mes_ok) {
    try { $depo_aktif_paket = $mes_pdo->query("SELECT COUNT(*) FROM MES..PAKETLER WHERE AKTIF=0")->fetchColumn(); } catch(Throwable $e){}
}

// ── İdari ────────────────────────────────────────────────────────
$idari_arac_disari = 0;
try {
    $arac_son=[];
    $arr=$db->query("SELECT * FROM arac_giris_cikis ORDER BY c_zaman DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach($arr as $a){$p=$a['plaka'];if(!isset($arac_son[$p])||strtotime($a['c_zaman'])>strtotime($arac_son[$p]['c_zaman']))$arac_son[$p]=$a;}
    foreach($arac_son as $a){if(empty($a['g_zaman']))$idari_arac_disari++;}
} catch(Throwable $e){}

$sayfatarihi = date('d.m.Y H:i');
?>
<style>
.db-grid{display:grid;gap:12px;margin-bottom:14px}
.db-g4{grid-template-columns:repeat(4,1fr)}
.db-g3{grid-template-columns:repeat(3,1fr)}
.db-g2{grid-template-columns:1fr 1fr}
.db-g5{grid-template-columns:repeat(5,1fr)}
@media(max-width:1100px){.db-g5,.db-g4{grid-template-columns:repeat(2,1fr)}}
@media(max-width:700px){.db-g5,.db-g4,.db-g3,.db-g2{grid-template-columns:1fr}}
.db-modul-kart{background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;overflow:hidden}
.db-modul-baslik{padding:10px 14px;font-size:12px;font-weight:800;letter-spacing:.4px;display:flex;align-items:center;justify-content:space-between}
.db-modul-ic{padding:10px 14px}
.db-stat-row{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px}
.db-stat{flex:1;min-width:80px;border-radius:8px;padding:10px 12px;text-align:center}
.db-stat .v{font-size:22px;font-weight:900;line-height:1}
.db-stat .l{font-size:10px;font-weight:700;margin-top:3px;text-transform:uppercase;letter-spacing:.4px;opacity:.8}
.db-mini-tablo{width:100%;border-collapse:collapse;font-size:11px}
.db-mini-tablo th{background:#1E3A5F;color:#fff;padding:5px 8px;text-align:left;white-space:nowrap}
.db-mini-tablo td{padding:5px 8px;border-bottom:1px solid var(--kenar);white-space:nowrap}
.db-link{display:block;text-align:right;font-size:11px;font-weight:700;color:#1E3A5F;text-decoration:none;margin-top:6px;opacity:.7}
.db-link:hover{opacity:1}
.db-bos{padding:20px;text-align:center;color:var(--m2);font-size:12px}
.db-acil{background:#FEF2F2;border-left:3px solid #DC2626}
.db-uyari{background:#FFFBEB;border-left:3px solid #F59E0B}
.db-iyi{background:#F0FDF4;border-left:3px solid #16A34A}
</style>

<div class="s-bar" style="flex-wrap:wrap;gap:8px">
  <div>
    <h1 class="s-bas">🏠 Ana Dashboard</h1>
    <div class="s-yol">Anasayfa · <?php echo $sayfatarihi;?></div>
  </div>
  <button onclick="location.reload()" style="background:var(--bg);border:1px solid var(--kenar);padding:6px 14px;border-radius:6px;font-size:12px;cursor:pointer">🔄 Yenile</button>
</div>

<!-- ── ÜSTTE 5 ANA KPI ─────────────────────────────────────────── -->
<div class="db-grid db-g5" style="margin-bottom:14px">
  <?php
  $ozet_kartlar = [
    ['👥','İK','Aktif Personel',$ik_personel,'ik-personeller','#E0F2FE','#1D4ED8'],
    ['📦','Satış','Açık Sipariş',$satis_acik,'satis-siparisler','#D1FAE5','#16A34A'],
    ['🛒','Satınalma','Açık P.O.',$satin_acik,'satinalma-acik-sip','#FEF0C7','#D97706'],
    ['⚡','JIT 24s','Acil Sevk',$jit_24,'satis-jit','#FEE2E2','#DC2626'],
    ['📊','KPI Sayım',$ay_adi_tr.' Hedef',($plan_sayim_hedef>0?round($plan_sayim_gercek/$plan_sayim_hedef*100).'%':'-'),'raporlar-sayim','#EFF6FF','#2563EB'],
  ];
  foreach($ozet_kartlar as [$ikon,$modul,$etiket,$deger,$link,$renk,$renk2]):?>
  <a href="<?php echo BASE_URL;?>/panel.php?sayfa=<?php echo $link;?>"
    style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:14px 16px;text-decoration:none;color:inherit;display:block;transition:.15s"
    onmouseover="this.style.boxShadow='0 4px 14px rgba(0,0,0,.1)';this.style.transform='translateY(-2px)'"
    onmouseout="this.style.boxShadow='';this.style.transform=''">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
      <div style="width:36px;height:36px;border-radius:8px;background:<?php echo $renk;?>;display:flex;align-items:center;justify-content:center;font-size:18px"><?php echo $ikon;?></div>
      <span style="font-size:10px;font-weight:700;color:<?php echo $renk2;?>;background:<?php echo $renk;?>;padding:2px 8px;border-radius:10px"><?php echo $modul;?></span>
    </div>
    <div style="font-size:26px;font-weight:900;color:<?php echo $renk2;?>;line-height:1"><?php echo $deger;?></div>
    <div style="font-size:11px;color:var(--m2);margin-top:4px;font-weight:600"><?php echo $etiket;?></div>
  </a>
  <?php endforeach;?>
</div>

<!-- ── SATIR 1: Satış + Satınalma + İK ────────────────────────── -->
<div class="db-grid db-g3">

  <!-- SATIŞ -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#1E3A5F;color:#fff">
      <span>💼 Satış & Sevkiyat</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satis-dashboard" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $satis_geciken;?></div><div class="l">Geciken</div>
        </div>
        <div class="db-stat" style="background:#DBEAFE;color:#1D4ED8">
          <div class="v"><?php echo $satis_bugun;?></div><div class="l">Bugün</div>
        </div>
        <div class="db-stat" style="background:#FEF9C3;color:#92400E">
          <div class="v"><?php echo $jit_24;?></div><div class="l">JIT 24s</div>
        </div>
        <div class="db-stat" style="background:#D1FAE5;color:#065F46">
          <div class="v"><?php echo $satis_acik;?></div><div class="l">Toplam Açık</div>
        </div>
      </div>
      <?php if(!empty($satis_son5)):?>
      <table class="db-mini-tablo">
        <thead><tr><th>Firma</th><th>Termin</th><th style="text-align:right">Kalan</th></tr></thead>
        <tbody>
        <?php foreach($satis_son5 as $r):
          $gec = strtotime($r['sip_teslim_tarihi']) < strtotime($bugun);
          $bg  = $gec ? 'background:#FFF5F5' : '';
        ?>
        <tr style="<?php echo $bg;?>">
          <td style="font-size:10px;max-width:110px;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars(mb_strimwidth($r['musteri_firma_adi']??'',0,18,'…'));?></td>
          <td style="color:<?php echo $gec?'#DC2626':'#374151';?>;font-weight:<?php echo $gec?'700':'400';?>"><?php echo date('d.m',strtotime($r['sip_teslim_tarihi']));?></td>
          <td style="text-align:right;font-weight:700"><?php echo number_format((float)$r['kalan'],0,'','.');?></td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
      <?php else:?>
      <div class="db-bos">Açık sipariş yok ✅</div>
      <?php endif;?>
    </div>
  </div>

  <!-- SATINALMA -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#92400E;color:#fff">
      <span>🛒 Satınalma</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-dashboard" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $satin_geciken;?></div><div class="l">Geciken P.O.</div>
        </div>
        <div class="db-stat" style="background:#FEF9C3;color:#92400E">
          <div class="v"><?php echo $satin_bugun;?></div><div class="l">Bugün Beklenen</div>
        </div>
        <div class="db-stat" style="background:#E0F2FE;color:#0369A1">
          <div class="v"><?php echo $satin_acik;?></div><div class="l">Toplam Açık</div>
        </div>
      </div>
      <?php if(!$tiger_ok):?>
      <div style="background:#FEF9C3;padding:8px 10px;border-radius:6px;font-size:11px;color:#92400E;font-weight:600">⚠️ Tiger DB bağlantısı yok</div>
      <?php else:?>
      <div style="display:flex;flex-direction:column;gap:6px;margin-top:4px">
        <?php if($satin_geciken>0):?>
        <div class="db-acil" style="border-radius:6px;padding:8px 10px;font-size:12px;font-weight:600">
          🔴 <?php echo $satin_geciken;?> geciken satınalma siparişi var
        </div>
        <?php endif;?>
        <?php if($satin_bugun>0):?>
        <div class="db-uyari" style="border-radius:6px;padding:8px 10px;font-size:12px;font-weight:600">
          🟡 Bugün <?php echo $satin_bugun;?> sipariş teslim alınacak
        </div>
        <?php endif;?>
        <?php if($satin_geciken===0&&$satin_bugun===0):?>
        <div class="db-iyi" style="border-radius:6px;padding:8px 10px;font-size:12px;font-weight:600">
          ✅ Gecikmiş sipariş yok
        </div>
        <?php endif;?>
      </div>
      <?php endif;?>
      <a class="db-link" href="<?php echo BASE_URL;?>/panel.php?sayfa=satinalma-acik-sip">Açık Siparişler →</a>
    </div>
  </div>

  <!-- İK -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#065F46;color:#fff">
      <span>👥 İnsan Kaynakları</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ik-personeller" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#D1FAE5;color:#065F46">
          <div class="v"><?php echo $ik_personel;?></div><div class="l">Aktif Personel</div>
        </div>
        <div class="db-stat" style="background:#DBEAFE;color:#1D4ED8">
          <div class="v"><?php echo $ik_izin_bugün;?></div><div class="l">Bugün İzinli</div>
        </div>
        <div class="db-stat" style="background:#FEF9C3;color:#92400E">
          <div class="v"><?php echo $ik_mesai_bekl;?></div><div class="l">Mesai Bekl.</div>
        </div>
        <div class="db-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $ik_yeni_ihtar;?></div><div class="l">Bu Ay İhtar</div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:5px">
        <?php if($ik_mesai_bekl>0):?>
        <div class="db-uyari" style="border-radius:6px;padding:7px 10px;font-size:11px;font-weight:600;display:flex;justify-content:space-between">
          <span>⏰ <?php echo $ik_mesai_bekl;?> fazla mesai onay bekliyor</span>
          <a href="<?php echo BASE_URL;?>/panel.php?sayfa=ik-mesai" style="color:#92400E;font-weight:700">Git →</a>
        </div>
        <?php endif;?>
        <?php if($ik_izin_bugün>0):?>
        <div class="db-iyi" style="border-radius:6px;padding:7px 10px;font-size:11px;font-weight:600">
          🏖 Bugün <?php echo $ik_izin_bugün;?> personel izinli
        </div>
        <?php endif;?>
      </div>
      <a class="db-link" href="<?php echo BASE_URL;?>/panel.php?sayfa=ik-devam">Devam Kayıtları →</a>
    </div>
  </div>

</div>

<!-- ── SATIR 2: Planlama KPI + Depo + İdari ───────────────────── -->
<div class="db-grid db-g3">

  <!-- PLANLAMA / KPI -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#7C3AED;color:#fff">
      <span>📊 KPI — <?php echo $ay_adi_tr;?></span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=planlama-kpi-ozet" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#EDE9FE;color:#7C3AED">
          <div class="v"><?php echo $plan_sayim_gercek;?>/<?php echo $plan_sayim_hedef;?></div><div class="l">Sayım Gerç./Hedef</div>
        </div>
        <div class="db-stat" style="<?php echo floatval($plan_sayim_uyum)>=85?'background:#D1FAE5;color:#065F46':'background:#FEE2E2;color:#991B1B';?>">
          <div class="v"><?php echo $plan_sayim_uyum>0?number_format(floatval($plan_sayim_uyum),0).'%':'—';?></div><div class="l">Hedefe Uyum</div>
        </div>
      </div>
      <!-- Hızlı KPI çubukları -->
      <?php
      $kpi_items = [
        ['14 - Sevkiyat','—','#2563EB',0],
        ['17 - Stok Sayım',$plan_sayim_uyum>0?floatval($plan_sayim_uyum):0,'#16A34A',85],
        ['25 - Tedarikçi','—','#D97706',87],
      ];
      foreach($kpi_items as [$lbl,$val,$renk,$hedef]):
        $pct = is_numeric($val) ? min(100,(float)$val) : 0;
      ?>
      <div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;font-size:11px;font-weight:600;margin-bottom:3px">
          <span><?php echo $lbl;?></span>
          <span style="color:<?php echo $pct>=$hedef&&$pct>0?'#16A34A':($pct>0?'#DC2626':'#94A3B8');?>"><?php echo is_numeric($val)&&$val>0?number_format((float)$val,0).'%':'—';?></span>
        </div>
        <div style="height:6px;border-radius:3px;background:#E2E8F0;overflow:hidden">
          <div style="height:100%;border-radius:3px;width:<?php echo $pct;?>%;background:<?php echo $renk;?>;transition:width .5s"></div>
        </div>
      </div>
      <?php endforeach;?>
      <a class="db-link" href="<?php echo BASE_URL;?>/panel.php?sayfa=raporlar-sayim">Sayım Performansı →</a>
    </div>
  </div>

  <!-- DEPO & STOK -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#0369A1;color:#fff">
      <span>📦 Depo & Sevkiyat</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-sevkiyat-dashboard" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#DBEAFE;color:#1D4ED8">
          <div class="v"><?php echo number_format($depo_aktif_paket,0,'','.');?></div><div class="l">Aktif Paket</div>
        </div>
        <div class="db-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $satis_geciken;?></div><div class="l">Geciken Sevk</div>
        </div>
        <div class="db-stat" style="background:#FEF9C3;color:#92400E">
          <div class="v"><?php echo $satis_bugun;?></div><div class="l">Bugün Sevk</div>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:6px">
        <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-stok"
          style="flex:1;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:8px;text-align:center;text-decoration:none;font-size:11px;font-weight:700;color:#1D4ED8">
          📦 Stok Raporu
        </a>
        <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-paket-sayim"
          style="flex:1;background:#F0FDF4;border:1px solid #86EFAC;border-radius:8px;padding:8px;text-align:center;text-decoration:none;font-size:11px;font-weight:700;color:#16A34A">
          📱 Paket Sayım
        </a>
        <a href="<?php echo BASE_URL;?>/panel.php?sayfa=depo-stok-farki"
          style="flex:1;background:#FFFBEB;border:1px solid #FDE68A;border-radius:8px;padding:8px;text-align:center;text-decoration:none;font-size:11px;font-weight:700;color:#92400E">
          ⚖️ MES Farkı
        </a>
      </div>
    </div>
  </div>

  <!-- İDARİ -->
  <div class="db-modul-kart">
    <div class="db-modul-baslik" style="background:#374151;color:#fff">
      <span>🏢 İdari & Araçlar</span>
      <a href="<?php echo BASE_URL;?>/panel.php?sayfa=idari-firma" style="color:rgba(255,255,255,.7);font-size:10px;text-decoration:none">Detay →</a>
    </div>
    <div class="db-modul-ic">
      <div class="db-stat-row">
        <div class="db-stat" style="background:#FEE2E2;color:#991B1B">
          <div class="v"><?php echo $idari_arac_disari;?></div><div class="l">Dışarıdaki Araç</div>
        </div>
        <div class="db-stat" style="background:#D1FAE5;color:#065F46">
          <div class="v"><?php echo 4-$idari_arac_disari;?></div><div class="l">Depoda Araç</div>
        </div>
      </div>
      <?php
      $plakalar=[['59 JD 820','MERCEDES'],['59 AIR 496','İVECO'],['59 AT 979','FORD'],['59 JF 911','FİORİNO']];
      foreach($plakalar as [$plaka,$marka]):
        $son=$arac_son[$plaka]??null;
        $disari=$son&&empty($son['g_zaman']);
      ?>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--kenar);font-size:11px">
        <span style="font-weight:700"><?php echo $plaka;?></span>
        <span style="font-size:9px;color:var(--m2)"><?php echo $marka;?></span>
        <span style="background:<?php echo $disari?'#DC2626':'#16A34A';?>;color:#fff;padding:2px 7px;border-radius:8px;font-size:10px;font-weight:700">
          <?php echo $disari?'Dışarıda':'İçeride';?>
        </span>
      </div>
      <?php endforeach;?>
      <a class="db-link" href="<?php echo BASE_URL;?>/panel.php?sayfa=idari-arac-listesi">Araç Yönetimi →</a>
    </div>
  </div>

</div>

<!-- ── HIZLI ERİŞİM ────────────────────────────────────────────── -->
<div style="background:var(--yuzey);border:1px solid var(--kenar);border-radius:12px;padding:14px">
  <div style="font-size:12px;font-weight:800;color:#374151;margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px">⚡ Hızlı Erişim</div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <?php
    $hizli = [
      ['satis-dashboard','📊','Satış DB','#D1FADF','#065F46'],
      ['satinalma-dashboard','📊','Satınalma DB','#FEF0C7','#92400E'],
      ['depo-sevkiyat-dashboard','🚛','Sevkiyat DB','#DBEAFE','#1D4ED8'],
      ['planlama-kpi-ozet','📈','KPI Özet','#EDE9FE','#7C3AED'],
      ['ik-devam','✅','Devam Kayıtları','#D1FAE5','#065F46'],
      ['depo-stok','📦','Stok Raporu','#FEF0C7','#92400E'],
      ['satinalma-performans','🏭','Ted. Performans','#E0F2FE','#0369A1'],
      ['raporlar-sayim','🔢','Sayım KPI','#EDE9FE','#7C3AED'],
    ];
    foreach($hizli as [$link,$ikon,$ad,$bg,$color]):?>
    <a href="<?php echo BASE_URL;?>/panel.php?sayfa=<?php echo $link;?>"
      style="background:<?php echo $bg;?>;color:<?php echo $color;?>;border:1px solid <?php echo $color;?>30;border-radius:8px;padding:7px 14px;text-decoration:none;font-size:12px;font-weight:700;display:flex;align-items:center;gap:6px;transition:.15s"
      onmouseover="this.style.opacity='.8'" onmouseout="this.style.opacity='1'">
      <?php echo $ikon;?> <?php echo $ad;?>
    </a>
    <?php endforeach;?>
  </div>
</div>
