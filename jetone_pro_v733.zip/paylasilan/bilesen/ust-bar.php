<?php
/**
 * Üst Bar Bileşeni
 * paylasilan/bilesen/ust-bar.php
 */
$kul = Auth::kullanici();
// Okunmamış bildirim sayısı
$bilSay = 0;
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM bildirimler WHERE (kullanici_id=? OR kullanici_id IS NULL) AND okundu=0 AND portal_tipi='erp'");
    $stmt->execute([$kul['id']]);
    $bilSay = (int)$stmt->fetchColumn();
} catch (Exception $e) {}
?>
<header class="ust-bar">
  <button class="hamburger" id="hamburger" onclick="drawerToggle()">
    <span></span><span></span><span></span>
  </button>

  <div class="arama">
    <span style="color:var(--m3);font-size:14px">🔍</span>
    <input placeholder="Ara... (Ctrl+K)" id="aramaInput" autocomplete="off">
    <span class="arama-k">⌘K</span>
  </div>

  <div class="ub-ak">
    <button class="ub-btn" title="Mesajlar">✉️</button>
    <button class="ub-btn" title="Bildirimler" onclick="panelToggle('bildirimler')" style="position:relative">
      🔔
      <?php if ($bilSay > 0): ?>
      <span class="ub-bant"></span>
      <?php endif; ?>
    </button>
    <button class="ub-btn" title="Takvim">📅</button>
    <div class="divider-v"></div>
    <a href="<?php echo BASE_URL; ?>/panel.php?sayfa=kullanici-profil" style="text-decoration:none" title="Profilim">
      <div class="av">
        <?php echo mb_strtoupper(mb_substr($kul['ad_soyad'] ?? 'U', 0, 2)); ?>
        <div class="av-dot"></div>
      </div>
    </a>
    <div class="ub-kul" style="cursor:pointer" onclick="window.location='<?php echo BASE_URL; ?>/panel.php?sayfa=kullanici-profil'">
      <div class="ub-kul-ad"><?php echo htmlspecialchars($kul['ad_soyad'] ?? ''); ?></div>
      <div class="ub-kul-rol">
        <?php
        $rolAd = '';
        try { $rolAd = $db->query("SELECT ad FROM roller WHERE id={$kul['rol_id']} LIMIT 1")->fetchColumn(); } catch(Throwable $e){}
        echo htmlspecialchars($rolAd ?: 'Kullanıcı');
        ?>
      </div>
    </div>
    <button class="panel-btn" onclick="sagPanelToggle()" title="Hızlı Panel">☰</button>
  </div>
</header>
