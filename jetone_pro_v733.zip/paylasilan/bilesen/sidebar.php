<?php
/**
 * Sidebar Bileşeni
 * paylasilan/bilesen/sidebar.php
 */
$_sayfa_prefix = !empty($_GET['sayfa']) ? explode('-', $_GET['sayfa'])[0] : 'dashboard';
// Kısa prefix → tam modül ID eşlemesi
$_prefix_map = ['tanim'=>'tanimlamalar','idari'=>'idari','ik'=>'ik','satis'=>'satis',
    'satinalma'=>'satinalma','uretim'=>'uretim','kalite'=>'kalite','planlama'=>'planlama',
    'depo'=>'depo','raporlar'=>'raporlar','ayarlar'=>'ayarlar','dashboard'=>'dashboard'];
$aktifModul = $_GET['modul'] ?? ($_prefix_map[$_sayfa_prefix] ?? $_sayfa_prefix);
$aktifSayfa = $_GET['sayfa'] ?? '';
?>
<!-- ANA SIDEBAR -->
<nav class="ana-sb" id="anaSb">
  <div class="sb-marka" onclick="sayfaYukle('dashboard')" data-tip="<?php echo htmlspecialchars($AYARLAR['firma_adi'] ?? 'Jetone.Pro'); ?>">
    <svg width="26" height="26" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <!-- J harfi stilize - köşeli modern -->
      <rect x="6" y="4" width="6" height="18" rx="1.5" fill="white" opacity="0.95"/>
      <rect x="4" y="20" width="10" height="5" rx="2" fill="white" opacity="0.95"/>
      <!-- nokta -->
      <circle cx="22" cy="8" r="4" fill="white" opacity="0.7"/>
      <!-- çizgi detay -->
      <rect x="16" y="14" width="12" height="3" rx="1.5" fill="white" opacity="0.5"/>
      <rect x="18" y="20" width="8" height="3" rx="1.5" fill="white" opacity="0.35"/>
    </svg>
  </div>
  <div class="modul-liste" id="masaustuModulListe">
    <?php
    $moduller = [
      ['id'=>'dashboard', 'ikon'=>'🏠', 'etiket'=>'Ana',   'tip'=>'Ana Panel'],
      ['id'=>'ik',        'ikon'=>'👥', 'etiket'=>'İK',    'tip'=>'İnsan Kaynakları', 'badge'=>true],
      ['id'=>'satis',     'ikon'=>'💼', 'etiket'=>'Satış', 'tip'=>'Satış & CRM'],
      ['id'=>'satinalma', 'ikon'=>'🛒', 'etiket'=>'Satın', 'tip'=>'Satınalma'],
      ['id'=>'uretim',    'ikon'=>'🏭', 'etiket'=>'Üret',  'tip'=>'Üretim', 'badge'=>true],
      ['id'=>'planlama',  'ikon'=>'🗂',  'etiket'=>'Plan',  'tip'=>'Planlama'],
      ['id'=>'kalite',    'ikon'=>'✅',  'etiket'=>'Kalit', 'tip'=>'Kalite'],
      ['id'=>'depo',      'ikon'=>'📦', 'etiket'=>'Depo',  'tip'=>'Depo & Sevkiyat'],
      ['id'=>'idari',     'ikon'=>'🏢', 'etiket'=>'İdari', 'tip'=>'İdari İşler'],
      ['id'=>'raporlar',  'ikon'=>'📊', 'etiket'=>'Rapor', 'tip'=>'Raporlar'],
      ['id'=>'tanimlamalar','ikon'=>'📐','etiket'=>'Tanım', 'tip'=>'Tanımlamalar'],
      ['id'=>'ai',        'ikon'=>'🤖', 'etiket'=>'AI',    'tip'=>'AI Asistan', 'direkt'=>'ai-chat'],
    ];
    // Modül ikonları yetki filtresi
    $_kul_sid = $_SESSION['kullanici'] ?? [];
    $_rol_id_sb = (int)($_kul_sid['rol_id'] ?? 0);
    // Her zaman DB'den rol adını çek (session'a güvenme)
    $_rol_adi_sb = '';
    try {
        $rs = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
        $rs->execute([$_rol_id_sb]);
        $_rol_adi_sb = $rs->fetchColumn() ?: '';
    } catch(Throwable $_e) {}
    $_super_admin = ($_rol_id_sb === 1 || strtolower($_rol_adi_sb) === 'süper admin');

    // Yetkili modülleri çek
    $_yetkili_moduller = [];
    if (!$_super_admin && $_rol_adi_sb !== '') {
        try {
            $ym = $db->prepare("SELECT DISTINCT ms.modul_id FROM menu_sayfalar ms
                INNER JOIN menu_rol_yetki mrk ON ms.sayfa_id=mrk.sayfa_id
                WHERE mrk.rol=?");
            $ym->execute([$_rol_adi_sb]);
            $_yetkili_moduller = array_column($ym->fetchAll(PDO::FETCH_ASSOC),'modul_id');
        } catch(Throwable $_e) {}
    }

    foreach ($moduller as $m):
      if (!$_super_admin && !in_array($m['id'], $_yetkili_moduller) && empty($m['direkt'])) continue;
      $aktifClass = ($sayfa === ($m['direkt'] ?? '')) || strpos($aktifModul ?? '', $m['id']) === 0 ? ' aktif' : '';
      $onclick = !empty($m['direkt'])
          ? "sayfaGit('" . htmlspecialchars($m['direkt']) . "',this)"
          : "modulSec('" . $m['id'] . "',this)";
    ?>
    <button class="mb<?php echo $aktifClass; ?>"
            onclick="<?php echo $onclick; ?>"
            data-tip="<?php echo $m['tip']; ?>">
      <span class="mb-i"><?php echo $m['ikon']; ?></span>
      <span class="mb-l"><?php echo $m['etiket']; ?></span>
      <?php if (!empty($m['badge'])): ?><span class="mb-b"></span><?php endif; ?>
    </button>
    <?php endforeach; ?>
  </div>

  <div class="sb-alt">
    <?php
    // Ayarlar butonu — sadece yetkili kullanıcılara göster
    if ($_super_admin ?? true) {
        echo '<button class="sb-alt-btn" onclick="modulSec(\'ayarlar\',this)" data-tip="Ayarlar">⚙️</button>';
    } else {
        // Ayarlar modülüne yetkisi var mı?
        $_ay_yetki = in_array('ayarlar', $_yetkili_moduller ?? []);
        if ($_ay_yetki) {
            echo '<button class="sb-alt-btn" onclick="modulSec(\'ayarlar\',this)" data-tip="Ayarlar">⚙️</button>';
        }
    }
    ?>
    <a href="<?php echo BASE_URL; ?>/cikis.php" class="sb-alt-btn" data-tip="Çıkış" style="text-decoration:none">🚪</a>
  </div>
</nav>

<!-- Yan menü kapalıyken göster butonu -->
<div id="sbAcBtn" style="display:<?php echo ($sb_kapali && !$_sb_gizle) ? "block" : "none"; ?>;position:fixed;top:70px;left:68px;z-index:200;background:var(--t);color:#fff;border:none;border-radius:0 8px 8px 0;padding:10px 8px;cursor:pointer;font-size:14px;writing-mode:vertical-rl;font-weight:700;box-shadow:3px 0 8px rgba(0,0,0,.15)" onclick="toggleModulSb()" title="Menüyü aç">▶</div>

<!-- MODÜL SIDEBAR -->
<?php
$_modul_disi = ['kullanici-profil','guvenlik'];
$_sb_gizle = in_array($aktifSayfa ?? '', $_modul_disi);
$sb_kapali = ($_COOKIE["modulSbKapali"] ?? "0") === "1";
?>
<aside class="modul-sb<?php echo ($sb_kapali||$_sb_gizle) ? " kapali" : ""; ?>" id="modulSb" <?php if($_sb_gizle) echo 'style="display:none"'; ?>>
<?php
// Aktif modülün menüsünü PHP ile render et - JS flicker olmaz
// ── Menüyü DB'den çek, yoksa PHP fallback ──────────────────────────
$php_moduller = [];
try {
    // DB'den modülleri çek
    $db_mod = $db->query("SELECT modul_id,baslik,ikon,renk FROM menu_moduller WHERE aktif=1 ORDER BY sira")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($db_mod)) {
        // Grupları tek sorguda çek
        $db_grp = $db->query("SELECT id,modul_id,grup_adi FROM menu_gruplar WHERE aktif=1 ORDER BY modul_id,sira")->fetchAll(PDO::FETCH_ASSOC);
        // Sayfaları tek sorguda çek
        $db_say = $db->query("SELECT grup_id,modul_id,sayfa_id,baslik,ikon FROM menu_sayfalar WHERE aktif=1 ORDER BY grup_id,sira")->fetchAll(PDO::FETCH_ASSOC);

        // Sayfa yetki filtresi — DB'den rol adını çek
        $_kul = $_SESSION['kullanici'] ?? [];
        $_rol_id  = (int)($_kul['rol_id'] ?? 0);
        // DB'den taze rol adı
        $_rol_adi_sub = '';
        try {
            $rs2 = $db->prepare("SELECT ad FROM roller WHERE id=? LIMIT 1");
            $rs2->execute([$_rol_id]);
            $_rol_adi_sub = $rs2->fetchColumn() ?: '';
        } catch(Throwable $_e2) {}
        $_super_admin2 = ($_rol_id === 1 || strtolower($_rol_adi_sub) === 'süper admin');

        $yetkili = [];
        $tam_yetki = $_super_admin2;

        if (!$tam_yetki && $_rol_adi_sub !== '') {
            $ry = $db->prepare("SELECT sayfa_id FROM menu_rol_yetki WHERE rol=?");
            $ry->execute([$_rol_adi_sub]);
            $yetkili = array_column($ry->fetchAll(PDO::FETCH_ASSOC),'sayfa_id');
            // Yetki kaydı yoksa → erişim yok (güvenli default)
        }

        // Sayfaları grup bazlı grupla
        $sayfa_by_grup = [];
        foreach ($db_say as $s) {
            if (!$tam_yetki && !in_array($s['sayfa_id'], $yetkili)) continue;
            $sayfa_by_grup[$s['grup_id']][] = ['i'=>$s['ikon'],'m'=>$s['baslik'],'id'=>$s['sayfa_id']];
        }

        // Grupları modül bazlı grupla
        $grup_by_modul = [];
        foreach ($db_grp as $g) {
            if (empty($sayfa_by_grup[$g['id']])) continue;
            $grup_by_modul[$g['modul_id']][] = ['ad'=>$g['grup_adi'],'sayfalar'=>$sayfa_by_grup[$g['id']]];
        }

        // Modülleri oluştur
        foreach ($db_mod as $m) {
            $mid = $m['modul_id'];
            if (empty($grup_by_modul[$mid])) continue;
            $php_moduller[$mid] = [
                'baslik'  => $m['baslik'],
                'ikon'    => $m['ikon'],
                'renk'    => $m['renk'],
                'gruplar' => $grup_by_modul[$mid],
            ];
        }
    }
} catch(Throwable $_e) {}

// DB boşsa PHP statik menüye fallback
if (empty($php_moduller)) {
$php_moduller = [
  'dashboard'    => ['baslik'=>'Ana Panel', 'ikon'=>'🏠','renk'=>'#F0FDF4','gruplar'=>[
    ['ad'=>'GENEL','sayfalar'=>[
      ['i'=>'🏠','m'=>'Dashboard','id'=>'dashboard'],
    ]],
  ]],
    'ik'           => ['baslik'=>'İnsan Kaynakları', 'ikon'=>'👥','renk'=>'#E0F2FE','gruplar'=>[
    ['ad'=>'PERSONEL','sayfalar'=>[
      ['i'=>'👤','m'=>'Personeller','id'=>'ik-personeller'],
      ['i'=>'🆕','m'=>'Personel Ekle','id'=>'ik-ekle'],
      ['i'=>'🏢','m'=>'Departmanlar','id'=>'ik-departmanlar'],
    ]],
    ['ad'=>'DEVAM & İZİN','sayfalar'=>[
      ['i'=>'✅','m'=>'Devam Kayıtları','id'=>'ik-devam'],
      ['i'=>'📊','m'=>'Günlük Özet','id'=>'ik-devam-ozet'],
      ['i'=>'🏖','m'=>'İzin Talepleri','id'=>'ik-izinler'],
      ['i'=>'⏰','m'=>'Fazla Mesai','id'=>'ik-mesai'],
      ['i'=>'🗓','m'=>'Vardiya','id'=>'ik-vardiya'],
      ['i'=>'💡','m'=>'Öneri & Şikayet','id'=>'ik-oneri'],
    ]],
    ['ad'=>'BORDRO','sayfalar'=>[
      ['i'=>'📋','m'=>'Bordro','id'=>'ik-bordro'],
    ]],
    ['ad'=>'ANALİZ','sayfalar'=>[
      ['i'=>'📊','m'=>'Turnover Raporu','id'=>'ik-turnover'],
      ['i'=>'😊','m'=>'Memnuniyet Anketi','id'=>'ik-anket'],
    ]],
    ['ad'=>'DİSİPLİN','sayfalar'=>[
      ['i'=>'⚠️','m'=>'İhtar Tutanakları','id'=>'ik-ihtar-listesi'],
      ['i'=>'➕','m'=>'Yeni İhtar','id'=>'ik-ihtar-form'],
    ]],
    ['ad'=>'DUYURULAR','sayfalar'=>[
      ['i'=>'📢','m'=>'Duyurular','id'=>'ik-duyuru-listesi'],
      ['i'=>'➕','m'=>'Yeni Duyuru','id'=>'ik-duyuru-form'],
    ]],
    ['ad'=>'PERFORMANS','sayfalar'=>[
      ['i'=>'📊','m'=>'Değerlendirmeler','id'=>'ik-perf-listesi'],
      ['i'=>'➕','m'=>'Yeni Değerlendirme','id'=>'ik-perf-form'],
    ]],
  ]],
  'idari'        => ['baslik'=>'İdari İşler',      'ikon'=>'🏢','renk'=>'#FFF7ED','gruplar'=>[
    ['ad'=>'İDARİ','sayfalar'=>[['i'=>'🏢','m'=>'Firma Bilgileri','id'=>'idari-firma'],['i'=>'📋','m'=>'Evrak Takibi','id'=>'idari-evrak']]],
    ['ad'=>'ORGANİZASYON','sayfalar'=>[['i'=>'🚌','m'=>'Servis Yönetimi','id'=>'idari-servis'],['i'=>'🍽','m'=>'Yemek & Menü','id'=>'idari-yemek'],['i'=>'🎉','m'=>'Etkinlikler','id'=>'idari-etkinlik']]],
    ['ad'=>'SATINALMA','sayfalar'=>[['i'=>'🛒','m'=>'Satınalma Talepleri','id'=>'idari-satin-talepler'],['i'=>'➕','m'=>'Yeni Talep','id'=>'idari-satin-yeni']]],
    ['ad'=>'ARAÇ & FİLO','sayfalar'=>[['i'=>'🚗','m'=>'Araçlar','id'=>'idari-arac-listesi'],['i'=>'⛽','m'=>'Yakıt Takibi','id'=>'idari-arac-yakit'],['i'=>'🔧','m'=>'Bakım Kayıtları','id'=>'idari-arac-bakim'],['i'=>'📍','m'=>'Görev / Seferler','id'=>'idari-arac-gorev']]],
    ['ad'=>'TEKLİF & SÖZLEŞME','sayfalar'=>[['i'=>'📋','m'=>'Teklifler','id'=>'idari-teklif-listesi'],['i'=>'📄','m'=>'Sözleşmeler','id'=>'idari-sozlesme-listesi']]],
  ]],
  'tanimlamalar' => ['baslik'=>'Tanımlamalar',     'ikon'=>'📐','renk'=>'#EFF6FF','gruplar'=>[
    ['ad'=>'ÜRETİM TANIMLARI','sayfalar'=>[
      ['i'=>'🧱','m'=>'Malzeme Tanımları',     'id'=>'tanim-malzeme'],
      ['i'=>'⚙️','m'=>'Operasyon Tanımları',   'id'=>'tanim-operasyon'],
      ['i'=>'📋','m'=>'Reçete Tanımları',      'id'=>'tanim-recete'],
      ['i'=>'🏭','m'=>'İş İstasyonu Tanımları','id'=>'tanim-istasyon'],
      ['i'=>'📦','m'=>'Stok Durumu','id'=>'tanim-stok'],
      ['i'=>'🏭','m'=>'Üretim Emirleri','id'=>'tanim-ue'],
    ]],
  ]],
  'ayarlar'      => ['baslik'=>'Ayarlar',          'ikon'=>'⚙️','renk'=>'#F8FAFC','gruplar'=>[
    ['ad'=>'GENEL','sayfalar'=>[['i'=>'🏢','m'=>'Firma Bilgileri','id'=>'ayarlar-firma'],['i'=>'🌍','m'=>'Bölgesel','id'=>'ayarlar-bolgesel']]],
    ['ad'=>'KULLANICI','sayfalar'=>[['i'=>'🎭','m'=>'Roller & Yetkiler','id'=>'ayarlar-roller'],['i'=>'👤','m'=>'ERP Kullanıcıları','id'=>'ayarlar-kullanici'],['i'=>'🌐','m'=>'Portal Kullanıcıları','id'=>'ayarlar-portal']]],
    ['ad'=>'MENÜ','sayfalar'=>[['i'=>'📋','m'=>'Menü Yönetimi','id'=>'ayarlar-menu']]],
    ['ad'=>'MENÜ','sayfalar'=>[['i'=>'🗂','m'=>'Menü Yönetimi','id'=>'ayarlar-menu']]],
    ['ad'=>'SİSTEM','sayfalar'=>[['i'=>'📍','m'=>'Geofence','id'=>'ayarlar-geofence'],['i'=>'🔌','m'=>'Entegrasyonlar','id'=>'ayarlar-enteg'],['i'=>'⚡','m'=>'SQL Konsolu','id'=>'ayarlar-sql']]],
  ]],
];

$php_moduller_ekstra = [
  'satis' => ['baslik'=>'Satış & CRM','ikon'=>'💼','renk'=>'#D1FADF','gruplar'=>[
    ['ad'=>'SATIŞ','sayfalar'=>[
      ['i'=>'📊','m'=>'Dashboard','id'=>'satis-dashboard'],
    ]],
    ['ad'=>'GENEL SİPARİŞLER','sayfalar'=>[
      ['i'=>'🛍','m'=>'Siparişler','id'=>'satis-siparisler'],
      ['i'=>'⚡','m'=>'JIT Siparişler','id'=>'satis-jit'],
    ]],
    ['ad'=>'TOPLAMA','sayfalar'=>[
      ['i'=>'🚛','m'=>'Genel Toplama Listesi','id'=>'satis-siparisler'],
      ['i'=>'🚛','m'=>'JIT Toplama Listesi','id'=>'satis-toplama'],
    ]],
    ['ad'=>'KONTROL','sayfalar'=>[
      ['i'=>'📊','m'=>'JIT Günlük Stok Kontrol','id'=>'satis-jit-gunluk'],
      ['i'=>'⏱','m'=>'JIT Saatlik Kontrol','id'=>'satis-jit-saatlik'],
      ['i'=>'📦','m'=>'Genel Stok Kontrol','id'=>'satis-stok-kontrol'],
    ]],
    ['ad'=>'RAPORLAR','sayfalar'=>[
      ['i'=>'📊','m'=>'Satış + Sipariş Durumu','id'=>'satis-sip-durum'],
    ]],
    ['ad'=>'MÜŞTERİLER','sayfalar'=>[
      ['i'=>'👥','m'=>'Müşteri Listesi','id'=>'satis-musteriler'],
      ['i'=>'📄','m'=>'Teklifler','id'=>'satis-teklifler'],
    ]],
    ['ad'=>'PACKING LIST','sayfalar'=>[
      ['i'=>'📦','m'=>'Packing List','id'=>'satis-packing-list'],
    ]],
    ['ad'=>'İRSALİYE','sayfalar'=>[
      ['i'=>'📦','m'=>'Yeni İrsaliyeler','id'=>'satis-yeni-irs'],
      ['i'=>'✅','m'=>'Düşülen İrsaliyeler','id'=>'satis-dusulen-irs'],
      ['i'=>'↩️','m'=>'İade İrsaliyeleri','id'=>'satis-iade-irs'],
    ]],
  ]],
  'satinalma' => ['baslik'=>'Satınalma','ikon'=>'🛒','renk'=>'#FEF0C7','gruplar'=>[
    ['ad'=>'GENEL','sayfalar'=>[
      ['i'=>'📊','m'=>'Dashboard','id'=>'satinalma-dashboard'],
    ]],
    ['ad'=>'SİPARİŞLER','sayfalar'=>[
      ['i'=>'🛒','m'=>'Açık Siparişler','id'=>'satinalma-acik-sip'],
      ['i'=>'✅','m'=>'Tamamlanan Siparişler','id'=>'satinalma-tam-sip'],
    ]],
    ['ad'=>'İRSALİYE','sayfalar'=>[
      ['i'=>'📥','m'=>'Satınalma İrsaliyeleri','id'=>'satinalma-irs'],
      ['i'=>'↩️','m'=>'İade İrsaliyeleri','id'=>'satinalma-iade-irs'],
    ]],
    ['ad'=>'MRP','sayfalar'=>[
      ['i'=>'📊','m'=>'Malzeme İhtiyaç Analizi','id'=>'satinalma-mrp'],
      ['i'=>'🧮','m'=>'Malzeme İhtiyaç Hesaplama','id'=>'satinalma-mih'],
    ]],
    ['ad'=>'ORTEL İHTİYAÇ','sayfalar'=>[
      ['i'=>'🔧','m'=>'Ortel Reçeteler','id'=>'satinalma-ortel-recete'],
      ['i'=>'📊','m'=>'Ortel İhtiyaç','id'=>'satinalma-ortel-ihtiyac'],
    ]],
    ['ad'=>'SEFER TAKİP','sayfalar'=>[
      ['i'=>'🚛','m'=>'İstanbul Sefer Takip','id'=>'satinalma-sefer'],
    ]],

    ['ad'=>'TEDARİKÇİLER','sayfalar'=>[
      ['i'=>'🏭','m'=>'Tedarikçiler','id'=>'satinalma-tedarikciler'],
      ['i'=>'🔧','m'=>'Tanımlı Kodlar','id'=>'satinalma-tanimli-ted'],
      ['i'=>'📈','m'=>'Tedarikçi Performansı','id'=>'satinalma-performans'],
    ]],
  ]],
  'uretim' => ['baslik'=>'Üretim','ikon'=>'🏭','renk'=>'#FEE4E2','gruplar'=>[
    ['ad'=>'PLANLAMA','sayfalar'=>[
      ['i'=>'⚙','m'=>'İş Emirleri','id'=>'uretim-is-emirleri'],
      ['i'=>'📐','m'=>'Reçeteler','id'=>'uretim-recete'],
      ['i'=>'🗓','m'=>'Çizelge','id'=>'uretim-cizelge'],
    ]],
    ['ad'=>'VERİMLİLİK & KALİTE','sayfalar'=>[
      ['i'=>'📈','m'=>'Üretim Verimlilik','id'=>'planlama-uretim-verimlilik'],
      ['i'=>'⚠️','m'=>'İkinci Kalite Raporu','id'=>'planlama-ikinci-kalite-rapor'],
      ['i'=>'⚠️','m'=>'İkinci Kalite Detay','id'=>'planlama-ikinci-kalite'],
      ['i'=>'🔴','m'=>'Tekrar IK Kayıtlar','id'=>'planlama-ik-tekrar'],
    ]],
    ['ad'=>'VERİMLİLİK','sayfalar'=>[
      ['i'=>'📊','m'=>'OEE','id'=>'uretim-oee'],
    ]],
  ]],
  'planlama' => ['baslik'=>'Planlama','ikon'=>'🗂','renk'=>'#E0F2FE','gruplar'=>[
    ['ad'=>'MRP/MPS','sayfalar'=>[
      ['i'=>'🔄','m'=>'MRP','id'=>'planlama-mrp'],
      ['i'=>'📦','m'=>'Malzeme İhtiyaç','id'=>'planlama-mih'],
      ['i'=>'🎯','m'=>'Öncelik Analizi','id'=>'planlama-oncelik'],
      ['i'=>'📅','m'=>'MPS','id'=>'planlama-mps'],
    ]],
    ['ad'=>'ENJEKSİYON','sayfalar'=>[
      ['i'=>'📊','m'=>'Gantt Planı','id'=>'planlama-gantt'],
      ['i'=>'🏭','m'=>'Günlük Üretim Girişleri','id'=>'planlama-uretim-giris'],
      ['i'=>'📋','m'=>'Enjeksiyon Planı','id'=>'planlama-gunluk'],
      ['i'=>'🏭','m'=>'ÜE Planlama','id'=>'planlama-ue'],
    ]],
    ['ad'=>'MONTAJ','sayfalar'=>[
      ['i'=>'🔧','m'=>'Montaj Planı','id'=>'planlama-montaj'],
      ['i'=>'📋','m'=>'Günlük Girişler','id'=>'planlama-montaj-gunluk'],
      ['i'=>'🏭','m'=>'Günlük Montaj Planı','id'=>'planlama-gunluk-montaj'],
    ]],
    ['ad'=>'KAPASİTE','sayfalar'=>[
      ['i'=>'🏭','m'=>'Kapasite','id'=>'planlama-kapasite'
      ],['i'=>'🏭','m'=>'Enj.Kapasite','id'=>'planlama-kapasite-enj'
      ],['i'=>'🔧','m'=>'Montaj Kapasite','id'=>'planlama-kapasite-montaj'],
      ['i'=>'🔩','m'=>'Manuel BOM','id'=>'planlama-manuel-bom'],
      ['i'=>'📦','m'=>'Kasa Hesaplama','id'=>'planlama-kasa-hesap'],
      ['i'=>'🚚','m'=>'Tedarikçi Forecast','id'=>'planlama-tedarikci-forecast'],
    ]],
    ['ad'=>'NORM HESAPLAMA','sayfalar'=>[
      ['i'=>'👥','m'=>'Norm Personel','id'=>'planlama-norm-personel'],
    ]],
    ['ad'=>'KPI','sayfalar'=>[
      ['i'=>'📊','m'=>'Dashboard','id'=>'planlama-dashboard'],
      ['i'=>'📊','m'=>'KPI Özet','id'=>'planlama-kpi-ozet'],
    ]],
  ]],
  'kalite' => ['baslik'=>'Kalite','ikon'=>'✅','renk'=>'#D1FADF','gruplar'=>[
    ['ad'=>'KONTROL','sayfalar'=>[
      ['i'=>'🔍','m'=>'Kontrol','id'=>'kalite-kontrol'],
      ['i'=>'⚠','m'=>'DÖF','id'=>'kalite-dof'],
    ]],
    ['ad'=>'DENETİM','sayfalar'=>[
      ['i'=>'🎯','m'=>'Denetimler','id'=>'kalite-denetim'],
    ]],
  ]],
  'depo' => ['baslik'=>'Depo & Sevkiyat','ikon'=>'📦','renk'=>'#FEF0C7','gruplar'=>[
    ['ad'=>'SEVKİYAT','sayfalar'=>[
      ['i'=>'📊','m'=>'Dashboard','id'=>'depo-sevkiyat-dashboard'],
      ['i'=>'🚚','m'=>'Sevkiyat','id'=>'depo-sevkiyat'],
      ['i'=>'📄','m'=>'İrsaliyeler','id'=>'depo-irsaliye'],
    ]],
    ['ad'=>'SİPARİŞLER','sayfalar'=>[
      ['i'=>'🛒','m'=>'Sipariş Listesi','id'=>'depo-siparis'],
      ['i'=>'⚡','m'=>'JIT / KMI Listesi','id'=>'depo-jit'],
    ]],
    ['ad'=>'STOK','sayfalar'=>[
      ['i'=>'📦','m'=>'Stok Raporu','id'=>'depo-stok'],
      ['i'=>'📍','m'=>'Adresli Stok','id'=>'depo-adresli-stok'],
      ['i'=>'📋','m'=>'Paketler','id'=>'depo-paketler'],
    ]],
    ['ad'=>'SAYIM','sayfalar'=>[
      ['i'=>'🔇','m'=>'Paket Pasif Et','id'=>'depo-paket-pasif'],
      ['i'=>'📱','m'=>'Paket Sayım','id'=>'depo-paket-sayim'],
      ['i'=>'⚖️','m'=>'Logo-MES Farkı','id'=>'depo-stok-farki'],
    ]],
    ['ad'=>'ANALİZ','sayfalar'=>[
      ['i'=>'↕','m'=>'Stok Hareketleri','id'=>'depo-hareketler'],
      ['i'=>'📦','m'=>'Paket Hareketleri','id'=>'depo-paket-hareketler'],
      ['i'=>'📟','m'=>'Terminal Kullanım','id'=>'depo-terminal'],
    ]],
  ]],
  'raporlar' => ['baslik'=>'Raporlar','ikon'=>'📊','renk'=>'#E0F2FE','gruplar'=>[
    ['ad'=>'AI ASISTAN','sayfalar'=>[
      ['i'=>'🤖','m'=>'AI Sohbet','id'=>'ai-chat'],
      ['i'=>'⚙️','m'=>'AI Ayarları','id'=>'ayarlar-ai'],
    ]],
    ['ad'=>'RAPORLAR','sayfalar'=>[
      ['i'=>'📊','m'=>'Genel','id'=>'raporlar-genel'],
      ['i'=>'📋','m'=>'TÜİK Verileri','id'=>'raporlar-tuik'],
      ['i'=>'🔢','m'=>'Sayım Performansı','id'=>'raporlar-sayim'],
    ]],
  ]],
];
foreach ($php_moduller_ekstra as $_mid => $_veri) {
    if (!isset($php_moduller[$_mid])) {
        $php_moduller[$_mid] = $_veri;
    }
}
} // end fallback

$_aktif = $aktifModul ?? 'dashboard';
$_veri  = $php_moduller[$_aktif] ?? null;

if ($_veri && !empty($_veri['gruplar'])):
    $aktifSayfa = $_GET['sayfa'] ?? '';
?>
<div class="msb-baslik" style="justify-content:space-between;cursor:pointer" onclick="toggleModulSb()" title="Menüyü gizle/göster">
  <div style="display:flex;align-items:center;gap:10px;overflow:hidden">
    <div class="msb-ikon" style="background:<?php echo $_veri['renk']; ?>"><?php echo $_veri['ikon']; ?></div>
    <div class="msb-ad"><?php echo htmlspecialchars($_veri['baslik']); ?></div>
  </div>
  <button id="sbToggleBtn" onclick="event.stopPropagation();toggleModulSb()" style="background:none;border:none;cursor:pointer;color:var(--m2);font-size:16px;padding:4px 6px;border-radius:6px;flex-shrink:0;line-height:1" title="Menüyü gizle"><?php echo $sb_kapali ? "▶" : "◀"; ?></button>
</div>
<div class="msb-ic">
  <?php
  // Aktif grubun index'ini bul
  $aktifGrupIdx = 0;
  foreach ($_veri['gruplar'] as $gi => $_grp_check) {
    foreach ($_grp_check['sayfalar'] as $_sp_check) {
      if ($_sp_check['id'] === $aktifSayfa) { $aktifGrupIdx = $gi; break 2; }
    }
  }
  ?>
  <?php foreach ($_veri['gruplar'] as $gi => $_grp): ?>
  <?php $grp_acik = ($gi === $aktifGrupIdx); ?>
  <div class="nav-grp acc-baslik<?php echo $grp_acik ? ' acc-acik' : ''; ?>"
       onclick="sbAccToggle(this)">
    <?php echo htmlspecialchars($_grp['ad']); ?>
    <span class="acc-ok"><?php echo $grp_acik ? '▲' : '▼'; ?></span>
  </div>
  <div class="acc-govde<?php echo $grp_acik ? ' acc-acik' : ''; ?>">
  <?php foreach ($_grp['sayfalar'] as $_sp): ?>
  <a class="nav-it<?php echo $_sp['id'] === $aktifSayfa ? ' aktif' : ''; ?>"
     href="<?php echo BASE_URL; ?>/panel.php?sayfa=<?php echo htmlspecialchars($_sp['id']); ?><?php echo !empty($_sp['ek']) ? '&'.htmlspecialchars($_sp['ek']) : ''; ?>"
     data-sayfa="<?php echo htmlspecialchars($_sp['id']); ?>"
     onclick="sayfaGit('<?php echo htmlspecialchars($_sp['id']); ?>',this<?php echo !empty($_sp['ek']) ? ",'".addslashes($_sp['ek'])."'" : ''; ?>);return false;">
    <span class="nav-it-i"><?php echo $_sp['i']; ?></span><?php echo htmlspecialchars($_sp['m']); ?>
    <span class="nav-roz" style="display:none"></span>
  </a>
  <?php endforeach; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
</aside>
