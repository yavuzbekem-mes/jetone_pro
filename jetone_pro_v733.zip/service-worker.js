const CACHE_NAME = 'jetone-erp-v1';
const OFFLINE_URL = '/jetone_pro/giris.php';

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll([OFFLINE_URL]);
    }).catch(() => {})
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  clients.claim();
});

self.addEventListener('fetch', event => {
  // Sadece GET istekleri
  if (event.request.method !== 'GET') return;
  // API ve POST isteklerini cache'leme
  if (event.request.url.includes('gp_action')) return;
  // Network-first strateji
  event.respondWith(
    fetch(event.request).catch(() => caches.match(OFFLINE_URL))
  );
});
