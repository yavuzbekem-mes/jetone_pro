CREATE TABLE IF NOT EXISTS `hortum_test_kayit` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `recete_adi`      VARCHAR(100) DEFAULT NULL,
  `operatör`        VARCHAR(100) DEFAULT NULL,
  `test_baslangic`  DATETIME NOT NULL,
  `test_bitis`      DATETIME NOT NULL,
  `sure_sn`         INT DEFAULT 0,
  -- Aşama 1: Kaçak testi
  `asama1_sonuc`    TINYINT(1) DEFAULT NULL COMMENT '1=GEÇTI, 0=KALDI',
  `asama1_hedef_bar` DECIMAL(6,3) DEFAULT NULL,
  `asama1_dusus_bar` DECIMAL(6,3) DEFAULT NULL,
  `asama1_sure_sn`   INT DEFAULT NULL,
  -- Aşama 2: Tıkanıklık testi
  `asama2_sonuc`    TINYINT(1) DEFAULT NULL COMMENT '1=GEÇTI, 0=KALDI',
  `asama2_akis_ldk` DECIMAL(6,2) DEFAULT NULL,
  `asama2_min_akis` DECIMAL(6,2) DEFAULT NULL,
  `asama2_sure_sn`  INT DEFAULT NULL,
  -- Genel
  `genel_sonuc`     TINYINT(1) NOT NULL DEFAULT 0,
  `piston_durum`    VARCHAR(20) DEFAULT 'KAPALI',
  `kayit_tarihi`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_tarih`   (`kayit_tarihi`),
  KEY `idx_sonuc`   (`genel_sonuc`),
  KEY `idx_gun`     (`test_baslangic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `hortum_test_recete` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `recete_adi`       VARCHAR(100) NOT NULL,
  `hedef_basinc`     DECIMAL(5,3) DEFAULT 2.500,
  `kacak_esigi`      DECIMAL(5,3) DEFAULT 0.050,
  `bekle_sure`       INT DEFAULT 10,
  `min_akis`         DECIMAL(5,2) DEFAULT 8.00,
  `stabilize_sure`   INT DEFAULT 3,
  `aktif`            TINYINT(1) DEFAULT 1,
  `olusturma_tarihi` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `hortum_test_recete` (id,recete_adi,hedef_basinc,kacak_esigi,bekle_sure,min_akis,stabilize_sure)
VALUES (1,'Standart Hortum',2.500,0.050,10,8.00,3),
       (2,'Uzun Hortum',3.000,0.080,15,6.00,5),
       (3,'İnce Hortum',1.500,0.030,8,4.00,2);
